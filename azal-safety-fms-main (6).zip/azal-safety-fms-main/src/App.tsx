import React, { useState, useEffect } from 'react';
import { supabase } from './services/supabaseClient';

export default function App() {
  const [reports, setReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [newTitle, setNewTitle] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // جلب البلاغات من Supabase
  const fetchReports = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('incident_statements') // اسم جدول البلاغات في قاعدة البيانات
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching reports:', error);
      } else if (data) {
        setReports(data);
      }
    } catch (err) {
      console.error('Unexpected error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReports();
  }, []);

  // إضافة بلاغ جديد تجريبي أو فعلي
  const handleAddReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    try {
      setSubmitting(true);
      const { error } = await supabase
        .from('incident_statements')
        .insert([{ title: newTitle, status: 'جديد' }]);

      if (error) {
        alert('خطأ أثناء إرسال البلاغ: ' + error.message);
      } else {
        setNewTitle('');
        fetchReports(); // تحديث القائمة فوراً
      }
    } catch (err) {
      console.error('Error inserting report:', err);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 p-4 font-sans" dir="rtl">
      <header className="bg-white shadow rounded-xl p-4 mb-6 flex justify-between items-center max-w-4xl mx-auto">
        <h1 className="text-xl font-bold text-slate-800">إدارة السلامة والمرافق - مستشفى آزال</h1>
        <span className="text-xs bg-green-100 text-green-800 px-3 py-1 rounded-full font-medium">النظام متصل سحابياً</span>
      </header>

      <main className="max-w-4xl mx-auto space-y-6">
        {/* نموذج إضافة بلاغ سريع */}
        <div className="bg-white shadow rounded-xl p-6">
          <h2 className="text-md font-semibold mb-3 text-slate-700">إضافة بلاغ أو خطر جديد (تجريبي)</h2>
          <form onSubmit={handleAddReport} className="flex gap-2">
            <input
              type="text"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              placeholder="اكتب وصف الخطر (مثال: أسطوانة أكسجين غير مثبتة)..."
              className="flex-1 border border-slate-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
            />
            <button
              type="submit"
              disabled={submitting}
              className="bg-green-600 text-white px-5 py-2 rounded-lg text-sm font-medium hover:bg-green-700 transition disabled:opacity-50"
            >
              {submitting ? 'جاري الإرسال...' : 'إرسال البلاغ'}
            </button>
          </form>
        </div>

        {/* قائمة البلاغات السابقة */}
        <div className="bg-white shadow rounded-xl p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold text-slate-700">سجل إشعارات المخاطر والبلاغات السابقة</h2>
            <button 
              onClick={fetchReports} 
              className="text-xs bg-slate-100 hover:bg-slate-200 text-slate-600 px-3 py-1.5 rounded-lg transition"
            >
              تحديث القائمة 🔄
            </button>
          </div>

          {loading ? (
            <div className="text-center py-10 text-slate-500">جاري جلب البلاغات من السحابة...</div>
          ) : reports.length === 0 ? (
            <p className="text-slate-400 text-center py-6">لا توجد بلاغات مسجلة حالياً في قاعدة البيانات.</p>
          ) : (
            <ul className="divide-y divide-slate-100">
              {reports.map((report: any, index: number) => (
                <li key={report.id || index} className="py-3 flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
                    <span className="text-slate-800 font-medium">{report.title || report.description || 'بلاغ سلامة'}</span>
                  </div>
                  <span className="text-xs text-slate-400">
                    {report.created_at ? new Date(report.created_at).toLocaleString('ar-SA') : 'حديث'}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </main>
    </div>
  );
}
