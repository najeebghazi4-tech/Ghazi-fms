import { AuditCheckItem, MonthlyAuditItemRecord, DepartmentAuditRecord } from '../types';

export interface DepartmentAuditTemplate {
  departmentId: string;
  departmentNameAr: string;
  departmentCategoryAr: string;
  codePrefix: string;
  floorLocation: string;
  defaultItems: Omit<AuditCheckItem, 'id' | 'status' | 'defectDescription' | 'photoUrl'>[];
}

export const AUDIT_DEPARTMENTS: DepartmentAuditTemplate[] = [
  // 1. LAUNDRY
  {
    departmentId: 'LAUNDRY',
    departmentNameAr: 'المغسلة المركزية للمستشفى (LAUNDRY)',
    departmentCategoryAr: 'الخدمات المساندة وهندسة المرافق',
    codePrefix: 'LND',
    floorLocation: 'القبو الفني - ممر الخدمات العامة',
    defaultItems: [
      {
        code: 'LND-01',
        standardRef: 'CBAHI',
        category: 'الحاجز الهيكلي والتدفق',
        clauseText: 'وجود حاجز هيكلي فاصل بين منطقة استلام المفارش الملوثة ومنطقة التجفيف والكي والتسليم النظيف لمنع التلوث العكسي (One-way Flow).',
      },
      {
        code: 'LND-02',
        standardRef: 'JCI',
        category: 'درجة حرارة التعقيم',
        clauseText: 'وصول درجات حرارة دورات الغسيل للكتان الطبي إلى 71°C على الأقل لمدة كافية للقضاء على الميكروبات ومسببات العدوى.',
      },
      {
        code: 'LND-03',
        standardRef: 'OSHA',
        category: 'السلامة الميكانيكية ومصائد الوبر',
        clauseText: 'عمل قواطع ومفاتيح التوقف الطارئ للغسالات والمجففات البخارية مع تنظيف مصائد الوبر (Lint Traps) يومياً لمنع مخاطر الاشتعال.',
      },
      {
        code: 'LND-04',
        standardRef: 'FMS',
        category: 'مكافحة الحريق والتهوية',
        clauseText: 'توفر طفايات الحريق الملائمة وجهاز كاشف الدخان ومروحة طرد الهواء الساخن والرطوبة بكفاءة عالية.',
      },
      {
        code: 'LND-05',
        standardRef: 'OSHA',
        category: 'معدات الوقاية الشخصية PPE',
        clauseText: 'التزام عمال المغسلة بارتداء معدات الوقاية الشخصية الكاملة (مآزر بلاستيكية، قفازات ثقيلة مقاومة للمواد الكيماوية، أحذية أمان مانعة للانزلاق، وكمامات).',
      }
    ]
  },

  // 2. RADIOLOGY
  {
    departmentId: 'RADIOLOGY',
    departmentNameAr: 'قسم الأشعة والتصوير الطبي (RADIOLOGY)',
    departmentCategoryAr: 'الأقسام التشخيصية والعلاجية',
    codePrefix: 'RAD',
    floorLocation: 'الدور الأرضي - الجناح الأيمن',
    defaultItems: [
      {
        code: 'RAD-01',
        standardRef: 'CBAHI',
        category: 'الوقاية الإشعاعية والعزل',
        clauseText: 'تبطين الجدران والأبواب بالرصاص الواقي والتأكد من سلامة العزل الإشعاعي وخلوه من أي تسرب للغرف المجاورة أو الممرات.',
      },
      {
        code: 'RAD-02',
        standardRef: 'JCI',
        category: 'بطاقات قياس الجرعات TLD',
        clauseText: 'توفر بطاقات قياس الجرعات الإشعاعية الشخصية (TLD Badges) لجميع الفنيين والأطباء وسريان قراءتها وتقاريرها الدورية.',
      },
      {
        code: 'RAD-03',
        standardRef: 'CBAHI',
        category: 'معدات الوقاية من الرصاص',
        clauseText: 'فحص السترات الواقية من الرصاص والواقيات الحلقية والتأكد من خلوها من التشققات الداخلية بالأشعة وتسجيل فحصها السنوي.',
      },
      {
        code: 'RAD-04',
        standardRef: 'JCI',
        category: 'أنظمة التوقف الطارئ',
        clauseText: 'جاهزية زر التوقف الطارئ (Emergency Stop) لأجهزة الأشعة المقطعية والرنين المغناطيسي وقسطرة القلب والتصوير التداخلي.',
      },
      {
        code: 'RAD-05',
        standardRef: 'CBAHI',
        category: 'التحذير الإرشادي والإنارة',
        clauseText: 'عمل اللمبة الحمراء التحذيرية فوق أبواب غرف التصوير فور بدء التعريض الإشعاعي مع ملصقات التحذير الصارمة للحوامل.',
      }
    ]
  },

  // 3. CSSD
  {
    departmentId: 'CSSD',
    departmentNameAr: 'قسم التعقيم المركزي (CSSD)',
    departmentCategoryAr: 'مكافحة العدوى والخدمات المساندة',
    codePrefix: 'CSSD',
    floorLocation: 'الدور الأول - بجوار غرف العمليات الجراحية',
    defaultItems: [
      {
        code: 'CSSD-01',
        standardRef: 'CBAHI',
        category: 'الفصل والتدفق أحادي الاتجاه',
        clauseText: 'الفصل الهندسي التام بين منطقة الاستلام غير المعقمة (Decontamination) ومنطقة التجهيز والتغليف ومنطقة التخزين المعقم (Clean Storage).',
      },
      {
        code: 'CSSD-02',
        standardRef: 'JCI',
        category: 'التهوية وفروق الضغط',
        clauseText: 'نظام الضغط التفاضلي لتدفق الهواء (Differential Pressure) بحالة سليمة ومطابق للمواصفات (ضغط سالب بمنطقة الغسيل، موجب بمنطقة التعقيم).',
      },
      {
        code: 'CSSD-03',
        standardRef: 'CBAHI',
        category: 'المؤشرات البيولوجية والكيميائية',
        clauseText: 'توثيق نتائج الاختبارات الكيميائية والبيولوجية اليومية لدورات الأوتوكلاف في سجل رسمي معتمد والاحتفاظ بشرائط الاختبار.',
      },
      {
        code: 'CSSD-04',
        standardRef: 'OSHA',
        category: 'السلامة الكيميائية وغسيل العيون',
        clauseText: 'جاهزية محطة غسيل العين الطارئة وتوفر صحائف بيانات سلامة المواد الكيميائية (MSDS) للمطهرات والمنظفات الإنزيمية.',
      },
      {
        code: 'CSSD-05',
        standardRef: 'CBAHI',
        category: 'تغليف المعقمات وتتبع الصلاحية',
        clauseText: 'سلامة عبوات التغليف وطباعة تاريخ التعقيم وتاريخ الانتهاء ورقم الدورة واسم الفاحص بجهاز الترميز الآلي على كل مغلف.',
      }
    ]
  },

  // 4. PHARMACY
  {
    departmentId: 'PHARMACY',
    departmentNameAr: 'الصيدلية المركزية ومستودع الأدوية (PHARMACY)',
    departmentCategoryAr: 'الخدمات الصيدلانية والعلاجية',
    codePrefix: 'PHARM',
    floorLocation: 'الدور الأرضي - مقابل بهو الاستقبال',
    defaultItems: [
      {
        code: 'PHARM-01',
        standardRef: 'CBAHI',
        category: 'سلسلة التبريد والثلاجات',
        clauseText: 'مراقبة وتسجيل درجات الحرارة والرطوبة لثلاجات حفظ الأدوية (2°C - 8°C) وأجهزة التسجيل المستمر مع جهاز إنذار صوتي عند الانحراف.',
      },
      {
        code: 'PHARM-02',
        standardRef: 'JCI',
        category: 'أدوية خطرة ومخدرة (Narcotics)',
        clauseText: 'تأمين خزانة الأدوية المخدرة والمراقبة بنظام قفل ثنائي محكم وحصر المفاتيح مع الصيدلي المسؤول المصرح له رسمياً.',
      },
      {
        code: 'PHARM-03',
        standardRef: 'OSHA',
        category: 'أطقم مكافحة الانسكاب الدوائي',
        clauseText: 'توفر أطقم مكافحة الانسكابات الدوائية والكيماوية (Spill Kits) وجاهزية محطة غسيل العيون وتوفر صحائف السلامة (MSDS).',
      },
      {
        code: 'PHARM-04',
        standardRef: 'CBAHI',
        category: 'مكافحة الحريق ورشاشات الإطفاء',
        clauseText: 'خلو الممرات بين الرفوف وجاهزية طفايات البودرة وCO2 وعدم ملاصقة الكراتين لرشاشات الحريق المائية (45 سم مسافة حرة رأسياً).',
      },
      {
        code: 'PHARM-05',
        standardRef: 'JCI',
        category: 'الأدوية عالية الخطورة وLASA',
        clauseText: 'فرز أدوية الليزر وشبيهة الشكل والاسم (LASA) وتطبيق ملصقات التمييز التحذيرية عالية الخطورة (High-Alert Medications).',
      }
    ]
  },

  // 5. ONCOLOGY
  {
    departmentId: 'ONCOLOGY',
    departmentNameAr: 'وحدة الأورام والعلاج الكيماوي (ONCOLOGY)',
    departmentCategoryAr: 'الرعاية التخصصية المتقدمة',
    codePrefix: 'ONC',
    floorLocation: 'الدور الثالث - الجناح التخصصي للأورام',
    defaultItems: [
      {
        code: 'ONC-01',
        standardRef: 'CBAHI',
        category: 'كبائن السلامة البيولوجية',
        clauseText: 'فحص كابينة السلامة الحيوية البيولوجية (Biosafety Cabinet Class II Type B2) والتأكد من صلاحية فلاتر HEPA وسريان شهادة المعايرة السنوية.',
      },
      {
        code: 'ONC-02',
        standardRef: 'JCI',
        category: 'أطقم الانسكابات السامة للخلايا',
        clauseText: 'توفر أطقم معالجة انسكابات المواد السامة للخلايا (Cytotoxic Spill Kits) مع ملصقات وإرشادات واضحة وسريعة الوصول داخل غرفة التحضير.',
      },
      {
        code: 'ONC-03',
        standardRef: 'CBAHI',
        category: 'نفايات العلاج الكيماوي',
        clauseText: 'حاويات مخصصة ومقاومة للثقب ومعلمة بالرمز البنفسجي للنفايات الناتجة عن العلاج الكيماوي وفصلها التام عن بقية النفايات الطبية.',
      },
      {
        code: 'ONC-04',
        standardRef: 'OSHA',
        category: 'أدوات الحماية PPE المزدوجة',
        clauseText: 'ارتداء طاقم التمريض والصيادلة لمعدات الحماية الشخصية المزدوجة المقاومة للكيماويات (Double gloves, Gowns, Respirators) أثناء التحضير والحقن.',
      },
      {
        code: 'ONC-05',
        standardRef: 'OSHA',
        category: 'محطة غسيل العيون والدش الطارئ',
        clauseText: 'جاهزية محطة غسيل العين والدش الطارئ داخل غرفة تحضير العلاج الكيماوي وفحص تدفقها واختبارها أسبوعياً.',
      }
    ]
  },

  // 6. WASTE_STORE
  {
    departmentId: 'WASTE_STORE',
    departmentNameAr: 'غرفة تجميع النفايات الطبية الخطرة (WASTE_STORE)',
    departmentCategoryAr: 'مكافحة العدوى وإدارة البيئة',
    codePrefix: 'WASTE',
    floorLocation: 'الفناء الخلفي - محطة معالجة وتخزين النفايات',
    defaultItems: [
      {
        code: 'WASTE-01',
        standardRef: 'CBAHI',
        category: 'الفرز والترميز اللوني',
        clauseText: 'الالتزام التام بالفرز اللوني (أكياس صفراء للنفايات الطبية الخطرة، صناديق أمان صفراء للحقن والمشارط، أكياس سوداء للنفايات العادية).',
      },
      {
        code: 'WASTE-02',
        standardRef: 'JCI',
        category: 'أمان وتكييف غرفة التجميع',
        clauseText: 'غرفة التجميع المركزي مغلقة ومكيفة (أقل من 20°C) وتخضع لقفل أمني يمنع دخول غير المصرح لهم أو الحشرات والقوارض.',
      },
      {
        code: 'WASTE-03',
        standardRef: 'OSHA',
        category: 'معدات الحماية الشخصية للعمال',
        clauseText: 'ارتداء عمال النفايات للبدلات الواقية والقفازات الجلدية المقاومة للثقب والأحذية الواقية الطويلة والكمامات المتخصصة.',
      },
      {
        code: 'WASTE-04',
        standardRef: 'CBAHI',
        category: 'سجل التوثيق وبوليصات النقل',
        clauseText: 'توثيق أوزان النفايات المنقولة وبوليصات الاستلام لشركة التخلص المعتمدة وسجل التتبع والوزن اليومي بدقة.',
      },
      {
        code: 'WASTE-05',
        standardRef: 'FMS',
        category: 'غسيل وتطهير الحاويات',
        clauseText: 'توفر مصدر مياه ومصرف أرضي لغسيل وتطهير حاويات وعربات النفايات الطبية يومياً بمحلول الكلور ومواد التطهير المعتمدة.',
      }
    ]
  },

  // 7. GAS_MANIFOLD
  {
    departmentId: 'GAS_MANIFOLD',
    departmentNameAr: 'محطة الغازات الطبية المركزية (GAS_MANIFOLD)',
    departmentCategoryAr: 'المرافق الهندسية الحيوية',
    codePrefix: 'MGAS',
    floorLocation: 'المبنى الفني الخارجي الملحق بالمستشفى',
    defaultItems: [
      {
        code: 'MGAS-01',
        standardRef: 'CBAHI',
        category: 'تثبيت الأسطوانات بالسلاسل',
        clauseText: 'تثبيت جميع أسطوانات الأكسجين والهواء الطبي بالسلاسل المعدنية المقاومة للهزات في وضع رأسي سليم وجاف ومحكم.',
      },
      {
        code: 'MGAS-02',
        standardRef: 'JCI',
        category: 'لوحات وصمامات العزل الطارئة',
        clauseText: 'سلامة لوحات وصمامات العزل الطارئة (Zone Valves) ووضوح البطاقات التعريفية الملونة لكل خط غاز في المحطة والأقسام.',
      },
      {
        code: 'MGAS-03',
        standardRef: 'CBAHI',
        category: 'نظام الإنذار المركزي للمراقبة',
        clauseText: 'فحص واختبار أجهزة الإنذار السمعية والبصرية لضغط الغازات المرتفع والمنخفض وتوصيلها بغرفة المراقبة وغرفة التحكم الهندسية.',
      },
      {
        code: 'MGAS-04',
        standardRef: 'FMS',
        category: 'منع الاشتعال والزيوت والشحوم',
        clauseText: 'منع تام لوجود أي زيوت أو شحوم أو مصادر لهب بالقرب من مخارج وأنابيب الأكسجين مع لوحات تحذيرية صارمة (ممنوع التدخين والزيوت).',
      },
      {
        code: 'MGAS-05',
        standardRef: 'FMS',
        category: 'مضخات الشفط والضاغطات',
        clauseText: 'فحص نسبة تفريغ مضخات الشفط الطبي (Vacuum) وضواغط الهواء الطبي (Medical Air) وتصريف مكثفات الرطوبة تلقائياً.',
      }
    ]
  },

  // 8. GENERATORS
  {
    departmentId: 'GENERATORS',
    departmentNameAr: 'غرف المولدات والمحولات الكهربائية (GENERATORS)',
    departmentCategoryAr: 'المرافق الهندسية والطاقة',
    codePrefix: 'GEN',
    floorLocation: 'القبو الفني الخارجي - غرفة الطاقة المركزية',
    defaultItems: [
      {
        code: 'GEN-01',
        standardRef: 'CBAHI',
        category: 'التحويل التلقائي للتيار ATS',
        clauseText: 'اختبار جهاز التحويل التلقائي للتيار (ATS) وبدء تغذية المولدات للأقسام الحرجة خلال أقل من 10 ثوانٍ عند انقطاع التيار العمومي.',
      },
      {
        code: 'GEN-02',
        standardRef: 'JCI',
        category: 'مكافحة الحريق والإطفاء الغازي',
        clauseText: 'جاهزية منظومة الإطفاء التلقائي بالغاز النظيف / ثاني أكسيد الكربون (CO2) وسلامة كواشف الحرارة ولوحات التحكم.',
      },
      {
        code: 'GEN-03',
        standardRef: 'OSHA',
        category: 'البسط العازلة ومنع التسريب',
        clauseText: 'فرش البسط العازلة للكهرباء (Rubber Mats) أمام لوحات التوزيع الرئيسية وخلو الأرضيات من أي تسريب للديزل أو الزيوت.',
      },
      {
        code: 'GEN-04',
        standardRef: 'FMS',
        category: 'المداخن والعوادم',
        clauseText: 'خروج عوادم المولدات عبر مداخن نظامية مرتفعة بعيداً عن مداخل ومآخذ هواء التكييف المركزي للمستشفى.',
      },
      {
        code: 'GEN-05',
        standardRef: 'FMS',
        category: 'مستوى وقود الديزل والبطاريات',
        clauseText: 'فحص مستوى وقود الديزل في الخزان اليومي والرئيسي (لا يقل عن 80%) وسلامة بطاريات البدء وشاحنها الذاتي المستمر.',
      }
    ]
  },

  // 9. IT_SERVERS
  {
    departmentId: 'IT_SERVERS',
    departmentNameAr: 'غرفة السيرفرات وتقنية المعلومات IT (IT_SERVERS)',
    departmentCategoryAr: 'الأنظمة والتحكم الرقمي',
    codePrefix: 'IT',
    floorLocation: 'الدور الأرضي - قسم تقنية المعلومات',
    defaultItems: [
      {
        code: 'IT-01',
        standardRef: 'FMS',
        category: 'الإطفاء الغازي النظيف',
        clauseText: 'سلامة منظومة الإطفاء الغازي النظيف (FM200 / Aerosol) وخلو الغرفة تماماً من الرشاشات المائية أو أنابيب المياه المارة فوق السيرفرات.',
      },
      {
        code: 'IT-02',
        standardRef: 'JCI',
        category: 'التكييف الدقيق وضبط الحرارة',
        clauseText: 'استقرار درجة حرارة الغرفة (18-21°C) عبر مكيفات دقيقة متبادلة وتوفر إنذار حراري متصل بهواتف مسؤولي الصيانة والطوارئ.',
      },
      {
        code: 'IT-03',
        standardRef: 'CBAHI',
        category: 'التحكم بالدخول والأمان المادي',
        clauseText: 'قفل الباب إلكترونياً ببصمة أو بطاقة ذكية مع سجل توثيق لكافة الزائرين والفنيين المصرح لهم بالدخول.',
      },
      {
        code: 'IT-04',
        standardRef: 'OSHA',
        category: 'تنظيم وترتيب كابلات الطاقة والشبكة',
        clauseText: 'تنظيم وترتيب كابلات الشبكة والطاقة داخل حوامل منظمة وعدم وجود أي توصيلات عشوائية أو مكشوفة أو أحمال زائدة.',
      },
      {
        code: 'IT-05',
        standardRef: 'FMS',
        category: 'أجهزة الـ UPS وبنك البطاريات',
        clauseText: 'سلامة أجهزة عدم انقطاع التيار (UPS) المركزية وبنك البطاريات وقدرتها على تشغيل أنظمة المستشفى الإلكترونية والشبكة عند الطوارئ.',
      }
    ]
  },

  // 10. INPATIENT
  {
    departmentId: 'INPATIENT',
    departmentNameAr: 'أقسام الرقود وتنويم المرضى (INPATIENT)',
    departmentCategoryAr: 'أقسام التنويم والرعاية السريرية',
    codePrefix: 'INP',
    floorLocation: 'الأدوار الثاني والثالث والرابع والخامس',
    defaultItems: [
      {
        code: 'INP-01',
        standardRef: 'CBAHI',
        category: 'أمان الأسرة وحواجز السقوط',
        clauseText: 'فحص حواجز وفرامل الأسرة (Side Rails & Wheel Locks) لجميع أسرة التنويم للوقاية من مخاطر سقوط المرضى.',
      },
      {
        code: 'INP-02',
        standardRef: 'JCI',
        category: 'أزرار استدعاء التمريض ودورات المياه',
        clauseText: 'سلامة أزرار استدعاء التمريض ومقابض الإسناد (Grab Bars) وأرضيات مانعة للانزلاق بدورات مياه المرضى.',
      },
      {
        code: 'INP-03',
        standardRef: 'CBAHI',
        category: 'صناديق عزل الغازات الطبية',
        clauseText: 'سلامة أغطية ومحابس صناديق عزل الغازات بالجناح (Zone Valve Boxes) واستقرار قراءة ضغط الأكسجين والشفط الجداري.',
      },
      {
        code: 'INP-04',
        standardRef: 'FMS',
        category: 'مفارش ونقالات الإخلاء السريع',
        clauseText: 'توفر وجاهزية نقالات ومفارش الإخلاء السريع لطريحي الفراش (Evacuation Sleds / Sheets) عند مخارج الطوارئ.',
      },
      {
        code: 'INP-05',
        standardRef: 'CBAHI',
        category: 'ممرات الرقود ومخارج الطوارئ',
        clauseText: 'خلو ممرات الرقود ومخارج الطوارئ من أي أسرة أو كراسي متحركة إضافية مع عمل لوحات الخروج المضيئة.',
      }
    ]
  },

  // 11. EMERGENCY
  {
    departmentId: 'EMERGENCY',
    departmentNameAr: 'قسم الطوارئ والإسعاف (EMERGENCY)',
    departmentCategoryAr: 'أقسام الطوارئ والرعاية العاجلة',
    codePrefix: 'ER',
    floorLocation: 'الدور الأرضي - المدخل الرئيسي للطوارئ',
    defaultItems: [
      {
        code: 'ER-01',
        standardRef: 'CBAHI',
        category: 'ممرات وسلالم الإخلاء',
        clauseText: 'خلو مسارات الإخلاء ومداخل سيارات الإسعاف وباب الطوارئ رقم 2 من أي أسرة أو كراسي متحركة أو مركبات عائقة.',
      },
      {
        code: 'ER-02',
        standardRef: 'JCI',
        category: 'عربة الإنعاش Crash Cart',
        clauseText: 'سلامة القفل البلاستيكي المرقم لعربة الإنعاش القلبي وفحص بطارية جهاز الصدمات الكهربائية وأسطوانة الأكسجين المدمجة.',
      },
      {
        code: 'ER-03',
        standardRef: 'CBAHI',
        category: 'أبواب الطوارئ والإنارة البديلة',
        clauseText: 'إضاءة لوحات الخروج (Emergency Exit Signs) وعملها على البطارية الذاتية عند انقطاع التيار الكهربائي.',
      },
      {
        code: 'ER-04',
        standardRef: 'JCI',
        category: 'غرفة العزل التنفسي بالطوارئ',
        clauseText: 'معايرة مقياس الضغط السالب لغرفة العزل التنفسي بالطوارئ وعمل جهاز التهوئة المتجددة وفلاتر HEPA.',
      },
      {
        code: 'ER-05',
        standardRef: 'OSHA',
        category: 'الفرز البصري ومكافحة العدوى',
        clauseText: 'توفر مستلزمات الحماية الشخصية للفرز البصري عند مدخل الطوارئ واستعداد كوادر الطوارئ لبروتوكول الرموز (Code Blue/Red).',
      }
    ]
  },

  // 12. OR
  {
    departmentId: 'OR',
    departmentNameAr: 'قسم العمليات الجراحية (OR)',
    departmentCategoryAr: 'الأقسام الجراحية والحرجة',
    codePrefix: 'OR',
    floorLocation: 'الدور الأول - جناح العمليات الكبرى',
    defaultItems: [
      {
        code: 'OR-01',
        standardRef: 'CBAHI',
        category: 'الضغط الإيجابي وفلاتر HEPA',
        clauseText: 'فحص الضغط الإيجابي لغرف العمليات ونظام التدفق الصفائحي (Laminar Air Flow) وفلاتر HEPA بنسبة كفاءة 99.97%.',
      },
      {
        code: 'OR-02',
        standardRef: 'JCI',
        category: 'مخاطر حرائق العمليات Surgical Fire',
        clauseText: 'تقييم مخاطر حرائق العمليات والتنسيق بين التخدير والجراحين وتأمين أجهزة الكي الكهربائي وسوائل التعقيم الكحولية.',
      },
      {
        code: 'OR-03',
        standardRef: 'OSHA',
        category: 'الأرضيات المبددة للشحنات Antistatic',
        clauseText: 'فحص الأرضيات الموصلة أو المبددة للشحنات الكهروستاتيكية (Antistatic Flooring) لمنع حدوث شرر كهربائي أثناء الجراحة.',
      },
      {
        code: 'OR-04',
        standardRef: 'FMS',
        category: 'مكافحة الحريق بطفايات CO2 النظيفة',
        clauseText: 'توفر طفايات غاز CO2 النظيفة وسهولة الوصول لمخارج الطوارئ المباشرة دون عوائق.',
      },
      {
        code: 'OR-05',
        standardRef: 'CBAHI',
        category: 'معلقات الغازات وصمامات العزل السريع',
        clauseText: 'فحص منافذ الغازات الطبية السقفية (Pendants) ولوحة الإنذار الفرعية وصمامات العزل السريع لغرف العمليات.',
      }
    ]
  },

  // 13. ICU
  {
    departmentId: 'ICU',
    departmentNameAr: 'وحدة العناية المركزة (ICU)',
    departmentCategoryAr: 'العنايات الفائقة والحرجة',
    codePrefix: 'ICU',
    floorLocation: 'الدور الثاني - جناح العناية الفائقة',
    defaultItems: [
      {
        code: 'ICU-01',
        standardRef: 'CBAHI',
        category: 'صناديق عزل الأكسجين والغازات',
        clauseText: 'فحص صناديق ومحابس العزل الطارئة (Zone Valves) للأكسجين والغازات بمدخل وحدة العناية واستقرار الضغط (4.2 بار).',
      },
      {
        code: 'ICU-02',
        standardRef: 'JCI',
        category: 'التيار غير المنقطع UPS لكل سرير',
        clauseText: 'تأمين أجهزة التنفس الاصطناعي ومضخات المحاليل على مخارج التيار غير المنقطع (UPS) المستقلة لكل سرير.',
      },
      {
        code: 'ICU-03',
        standardRef: 'CBAHI',
        category: 'عربات الإنعاش والديبريليتور',
        clauseText: 'فحص وجاهزية عربتي الإنعاش القلبي والرئوي وتأكيد شحن جهاز الديفيبريليتور والأدوية الحرجة وفحصها يومياً.',
      },
      {
        code: 'ICU-04',
        standardRef: 'FMS',
        category: 'مخرج الإخلاء ومصعد الأسرة',
        clauseText: 'جاهزية باب مخرج الطوارئ وعمل مصعد الإخلاء الطبي الاحتياطي الخاص بنقل الأسرة الحرجة.',
      },
      {
        code: 'ICU-05',
        standardRef: 'OSHA',
        category: 'نظافة وتطهير الأيدي والوقاية من العدوى',
        clauseText: 'التزام كوادر العناية بنظافة وتطهير الأيدي وتوفر معقمات الأيدي الكحولية عند كل سرير لمنع العدوى المكتسبة (HAI).',
      }
    ]
  },

  // 14. OBSTETRICS
  {
    departmentId: 'OBSTETRICS',
    departmentNameAr: 'قسم التوليد وأمراض النساء (OBSTETRICS)',
    departmentCategoryAr: 'الأقسام السريرية الحرجة',
    codePrefix: 'OBGYN',
    floorLocation: 'الدور الرابع - جناح الولادة',
    defaultItems: [
      {
        code: 'OBGYN-01',
        standardRef: 'CBAHI',
        category: 'منافذ الغازات الحيوية المزدوجة',
        clauseText: 'توفر منافذ مزدوجة للأكسجين والشفط الجداري لكل سرير ولادة وجاهزية أكياس الإنعاش للأم والمولود.',
      },
      {
        code: 'OBGYN-02',
        standardRef: 'JCI',
        category: 'أمان ومنع اختطاف المواليد Code Pink',
        clauseText: 'تفعيل نظام الحماية وأساور التتبع للمواليد والأمهات مع كاميرات المراقبة على أبواب وممرات الجناح (Code Pink).',
      },
      {
        code: 'OBGYN-03',
        standardRef: 'CBAHI',
        category: 'مسار العمليات القيصرية الطارئة',
        clauseText: 'خلو الممر الرابط بين غرف التوليد وقسم العمليات الجراحية القيصرية من أي عوائق لسرعة النقل والتدخل الطارئ.',
      },
      {
        code: 'OBGYN-04',
        standardRef: 'FMS',
        category: 'مكافحة الحريق ومخارج الطوارئ',
        clauseText: 'جاهزية خراطيم الإطفاء وطفايات CO2 في ممرات القسم وخلو السلالم المؤدية للأدوار السفلية.',
      },
      {
        code: 'OBGYN-05',
        standardRef: 'CBAHI',
        category: 'حاضنات النقل الدافئة للمواليد',
        clauseText: 'توفر حاضنات النقل الدافئة للمواليد وفحص بطارياتها وأسطوانات الأكسجين المدمجة بها وجاهزيتها الدائمة.',
      }
    ]
  },

  // 15. CAFETERIA
  {
    departmentId: 'CAFETERIA',
    departmentNameAr: 'كافتيريا وبوفية المستشفى (CAFETERIA)',
    departmentCategoryAr: 'الضيافة والخدمات العامة',
    codePrefix: 'CAF',
    floorLocation: 'الفناء الخارجي - بجوار حديقة الزوار',
    defaultItems: [
      {
        code: 'CAF-01',
        standardRef: 'CBAHI',
        category: 'أسطوانات الغاز وصمامات الأمان',
        clauseText: 'وضع أسطوانات الغاز خارج الكافتيريا في قفص معدني مهوى ومثبتة بالسلاسل مع محبس قفل سريع وصمامات أمان معتمدة.',
      },
      {
        code: 'CAF-02',
        standardRef: 'FMS',
        category: 'طفايات الحريق وبطانية الإخماد',
        clauseText: 'توفر طفاية حريق بودرة 6 كجم وبطانية حريق (Fire Blanket) معلقة في متناول يد الطهاة داخل المطبخ.',
      },
      {
        code: 'CAF-03',
        standardRef: 'MOH',
        category: 'الشهادات الصحية والزي الواقي',
        clauseText: 'سريان الشهادات الصحية لجميع العاملين وارتداء أغطية الرأس والقفازات والزي الموحد النظيف بانتظام.',
      },
      {
        code: 'CAF-04',
        standardRef: 'OSHA',
        category: 'التمديدات الكهربائية والقواطع',
        clauseText: 'سلامة كابلات أجهزة التسخين والعصارات وعدم وجود أي أسلاك مكشوفة أو أحمال زائدة على المقابس وتوفر قاطع تفاضلي.',
      },
      {
        code: 'CAF-05',
        standardRef: 'FMS',
        category: 'فلاتر الهود والتخلص من الزيوت',
        clauseText: 'فحص نظافة مداخن الشفط والتخلص السليم من الزيوت المستهلكة في براميل محكمة وعدم سكبها في شبكة الصرف العام.',
      }
    ]
  },

  // Additional Specialized Hospital Departments
  {
    departmentId: 'LABORATORY',
    departmentNameAr: 'المختبرات المركزية وبنك الدم (LABORATORY)',
    departmentCategoryAr: 'الأقسام التشخيصية والمخبرية',
    codePrefix: 'LAB',
    floorLocation: 'الدور الأرضي - الجناح الأوسط',
    defaultItems: [
      {
        code: 'LAB-01',
        standardRef: 'OSHA',
        category: 'دش ومغسلة الطوارئ',
        clauseText: 'جاهزية دش الطوارئ ومغسلة العيون وخلو المسار إليها من أي عوائق وفحص تدفق مياهها أسبوعياً.',
      },
      {
        code: 'LAB-02',
        standardRef: 'CBAHI',
        category: 'كبائن السلامة الحيوية',
        clauseText: 'صلاحية وفحص كبائن السلامة الحيوية (Biosafety Cabinets) والتأكد من اتجاه تدفق الهواء السليم.',
      },
      {
        code: 'LAB-03',
        standardRef: 'JCI',
        category: 'ثلاجات بنك الدم',
        clauseText: 'مراقبة درجات حرارة ثلاجات حفظ الدم وحاضنات الصفائح مع جهاز إنذار صوتي فوري عند حدوث خلل.',
      },
      {
        code: 'LAB-04',
        standardRef: 'CBAHI',
        category: 'أطقم الانسكاب الكيماوي',
        clauseText: 'توفر أطقم مكافحة الانسكابات البيولوجية والكيماوية وتدريب كوادر المختبر على آلية التعامل معها.',
      }
    ]
  },
  {
    departmentId: 'RESTAURANT',
    departmentNameAr: 'المطعم والمطبخ المركزي بالدور السادس (RESTAURANT)',
    departmentCategoryAr: 'الإعاشة والضيافة الكبرى',
    codePrefix: 'REST6',
    floorLocation: 'الدور السادس - البرج الرئيسي',
    defaultItems: [
      {
        code: 'REST6-01',
        standardRef: 'FMS',
        category: 'نظام إخماد الهود Ansul System',
        clauseText: 'فحص وجاهزية نظام الإخماد الكيميائي الرطب التلقائي (Ansul System) فوق شوايات وأفران الطهي بالهود.',
      },
      {
        code: 'REST6-02',
        standardRef: 'CBAHI',
        category: 'محابس الغاز الطارئة',
        clauseText: 'سلامة صمام الإغلاق السريع للغاز المركزي (Manual Gas Shut-off) وتوفر كواشف تسرب الغاز الصامتة.',
      },
      {
        code: 'REST6-03',
        standardRef: 'OSHA',
        category: 'نظافة المداخن والفلاتر',
        clauseText: 'نظافة فلاتر الهود وخلوها من التراكمات الدهنية القابلة للاشتعال وجدولة التنظيف الشامل الدوري.',
      },
      {
        code: 'REST6-04',
        standardRef: 'FMS',
        category: 'طفايات الزيوت Class K',
        clauseText: 'توفر طفاية حريق الرغوة الكيميائية الرطبة المخصصة لحرائق المطابخ والزيوت (Class K) بحالة صالحة.',
      }
    ]
  },
  {
    departmentId: 'NICU',
    departmentNameAr: 'العناية المركزة لحديثي الولادة (NICU)',
    departmentCategoryAr: 'الأقسام الحرجة التخصصية',
    codePrefix: 'NICU',
    floorLocation: 'الدور الرابع - جناح حديثي الولادة',
    defaultItems: [
      {
        code: 'NICU-01',
        standardRef: 'CBAHI',
        category: 'أمان الحاضنات واستقرار الحرارة',
        clauseText: 'فحص الحاضنات وأجهزة التدفئة المشعة والتأكد من استقرار درجات الحرارة وأجهزة الإنذار المدمجة.',
      },
      {
        code: 'NICU-02',
        standardRef: 'JCI',
        category: 'الغازات الطبية وتنظيم الأكسجين',
        clauseText: 'سلامة خلاطات الأكسجين والهواء الطبي (Oxygen Blenders) لضبط النسب بدقة ومنع تسمم الأكسجين لدى الخدج.',
      },
      {
        code: 'NICU-03',
        standardRef: 'FMS',
        category: 'عزل الصوت والضوء',
        clauseText: 'التحكم بمستويات الضوضاء والإضاءة بما يتوافق مع معايير حماية الجهاز العصبي لحديثي الولادة.',
      }
    ]
  },
  {
    departmentId: 'GENERAL_FMS',
    departmentNameAr: 'الاستمارة العامة لإدارة المرافق والسلامة (GENERAL_FMS)',
    departmentCategoryAr: 'السلامة العامة وهندسة المرافق',
    codePrefix: 'FMS',
    floorLocation: 'كافة أدوار ومباني المستشفى والمحيط العام',
    defaultItems: [
      {
        code: 'FMS-01',
        standardRef: 'CBAHI',
        category: 'مخارج وسلالم الطوارئ',
        clauseText: 'خلو جميع ممرات الهروب وسلالم الطوارئ من أي عوائق وعمل أبواب مقاومة الحريق المغلقة ذاتياً بانتظام.',
      },
      {
        code: 'FMS-02',
        standardRef: 'JCI',
        category: 'الإنذار وكواشف الدخان',
        clauseText: 'اختبار كواشف الدخان والحرارة وأزرار كسر الإنذار اليدوية (Break Glass) وربطها باللوحة المركزية.',
      },
      {
        code: 'FMS-03',
        standardRef: 'FMS',
        category: 'لوحات الإخلاء المعتمدة',
        clauseText: 'تحديث وتثبيت لوحات ومخططات مسارات الإخلاء ونقاط التجمع في كافة الممرات وبجوار المصاعد بوضوح.',
      },
      {
        code: 'FMS-04',
        standardRef: 'OSHA',
        category: 'إنارة الطوارئ',
        clauseText: 'فحص عمل وحدات إنارة الطوارئ الذاتية (Emergency Lights) في الممرات والسلالم عند انقطاع التيار.',
      },
      {
        code: 'FMS-05',
        standardRef: 'CBAHI',
        category: 'المصاعد وبطاقات الصيانة',
        clauseText: 'سريان شهادات الفحص الهندسي الدوري لكافة مصاعد المرضى والخدمات وتوفر نظام الهبوط التلقائي عند الطوارئ.',
      }
    ]
  }
];

// Helper to normalize department ID (supporting legacy lowercase IDs)
export function normalizeDepartmentId(id: string): string {
  if (!id) return 'LAUNDRY';
  const upper = id.toUpperCase();
  const map: Record<string, string> = {
    'CENTRAL_LAUNDRY': 'LAUNDRY',
    'LAUNDRY': 'LAUNDRY',
    'RADIOLOGY': 'RADIOLOGY',
    'CSSD': 'CSSD',
    'PHARMACY': 'PHARMACY',
    'ONCOLOGY': 'ONCOLOGY',
    'MEDICAL_WASTE': 'WASTE_STORE',
    'WASTE_STORE': 'WASTE_STORE',
    'MED_GAS_STATION': 'GAS_MANIFOLD',
    'GAS_MANIFOLD': 'GAS_MANIFOLD',
    'GENERATORS_TRANSFORMERS': 'GENERATORS',
    'GENERATORS': 'GENERATORS',
    'IT_SERVERS': 'IT_SERVERS',
    'INPATIENT_WARDS': 'INPATIENT',
    'INPATIENT': 'INPATIENT',
    'EMERGENCY_ER': 'EMERGENCY',
    'EMERGENCY': 'EMERGENCY',
    'OR_SURGICAL': 'OR',
    'OR': 'OR',
    'ICU': 'ICU',
    'OBSTETRICS_DELIVERY': 'OBSTETRICS',
    'OBSTETRICS': 'OBSTETRICS',
    'YARD_CAFETERIA': 'CAFETERIA',
    'CAFETERIA': 'CAFETERIA',
    'LABORATORIES': 'LABORATORY',
    'LABORATORY': 'LABORATORY',
    'RESTAURANT_6TH_FLOOR': 'RESTAURANT',
    'RESTAURANT': 'RESTAURANT',
    'NICU': 'NICU',
    'GENERAL_FMS': 'GENERAL_FMS'
  };
  return map[upper] || upper;
}

// Flat list of items pre-seeded for table `monthly_audit_items`
export const DEFAULT_MONTHLY_AUDIT_ITEMS: MonthlyAuditItemRecord[] = AUDIT_DEPARTMENTS.flatMap((dept) => 
  dept.defaultItems.map((item, idx) => ({
    id: `mai-${dept.departmentId}-${item.code}`,
    department_id: dept.departmentId,
    code: item.code,
    standard_ref: item.standardRef,
    category: item.category,
    clause_text: item.clauseText,
    order_index: idx + 1
  }))
);

export const INITIAL_DEPARTMENT_AUDITS: DepartmentAuditRecord[] = [];
