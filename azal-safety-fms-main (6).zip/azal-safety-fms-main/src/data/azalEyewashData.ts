import { EyewashFlushRecord } from '../types';

export interface EyewashStation {
  id: string;
  stationCode: string;
  department: string;
  locationDetail: string;
  type: 'combination_shower_eyewash' | 'wall_mounted_eyewash' | 'faucet_mounted';
  lastFlushDate: string;
  status: 'compliant' | 'due' | 'maintenance';
}

export const AZAL_EYEWASH_STATIONS: EyewashStation[] = [
  {
    id: 'ew-01',
    stationCode: 'EW-LAB-01',
    department: 'المختبر المركزي والسموم',
    locationDetail: 'بجوار وحدة تحضير العينات الكيميائية - الدور الأول',
    type: 'combination_shower_eyewash',
    lastFlushDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    status: 'compliant'
  },
  {
    id: 'ew-02',
    stationCode: 'EW-CHEMO-02',
    department: 'صيدلية تحضير العلاج الكيماوي',
    locationDetail: 'غرفة الضغط السالب لتحضير السيتوتوكسيك',
    type: 'wall_mounted_eyewash',
    lastFlushDate: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    status: 'compliant'
  },
  {
    id: 'ew-03',
    stationCode: 'EW-BLOOD-03',
    department: 'بنك الدم ومشتقاته',
    locationDetail: 'وحدة فصل مكونات الدم ومحاليل التفاعل',
    type: 'wall_mounted_eyewash',
    lastFlushDate: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    status: 'due'
  },
  {
    id: 'ew-04',
    stationCode: 'EW-HAZMAT-04',
    department: 'مستودع المواد الخطرة والمشعة HAZMAT',
    locationDetail: 'بجوار مستودع الأحماض والمطهرات المركزة - القبو',
    type: 'combination_shower_eyewash',
    lastFlushDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    status: 'compliant'
  },
  {
    id: 'ew-05',
    stationCode: 'EW-ENDOSCOPY-05',
    department: 'وحدة تعقيم مناظير الجهاز الهضمي',
    locationDetail: 'غرفة التعقيم الكيميائي بمحاليل الجلوترالدهيد',
    type: 'faucet_mounted',
    lastFlushDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    status: 'compliant'
  }
];

export const INITIAL_EYEWASH_FLUSH_LOGS: EyewashFlushRecord[] = [
  {
    id: 'ew-log-001',
    stationId: 'EW-LAB-01',
    location: 'المختبر المركزي - وحدة العينات الكيميائية',
    flushDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    flushDurationSeconds: 180,
    waterFlowAdequate: true,
    waterCleanAndClear: true,
    waterTemperatureTepid: true,
    drainageWorking: true,
    dustCoversIntact: true,
    signageVisible: true,
    pathwayUnobstructed: true,
    status: 'pass',
    inspectorName: 'م/ نجيب غازي',
    notes: 'تم تصريف الخط لمدة 3 دقائق كاملة، تدفق منتظم ومياه نقية وخالية من الصدأ.',
    createdAt: Date.now() - 3 * 24 * 60 * 60 * 1000
  },
  {
    id: 'ew-log-002',
    stationId: 'EW-CHEMO-02',
    location: 'صيدلية تحضير العلاج الكيماوي - غرفة السيتوتوكسيك',
    flushDate: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    flushDurationSeconds: 180,
    waterFlowAdequate: true,
    waterCleanAndClear: true,
    waterTemperatureTepid: true,
    drainageWorking: true,
    dustCoversIntact: true,
    signageVisible: true,
    pathwayUnobstructed: true,
    status: 'pass',
    inspectorName: 'م/ نجيب غازي',
    notes: 'أغطية الحماية ضد الأتربة تعمل تلقائياً عند فتح الصمام. التدفق مطابق لمعيار ANSI Z358.1.',
    createdAt: Date.now() - 4 * 24 * 60 * 60 * 1000
  },
  {
    id: 'ew-log-003',
    stationId: 'EW-HAZMAT-04',
    location: 'مستودع المواد الخطرة HAZMAT - القبو',
    flushDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    flushDurationSeconds: 180,
    waterFlowAdequate: true,
    waterCleanAndClear: true,
    waterTemperatureTepid: true,
    drainageWorking: true,
    dustCoversIntact: true,
    signageVisible: true,
    pathwayUnobstructed: true,
    status: 'pass',
    inspectorName: 'فهد الأصبحي (مفتش سلامة)',
    notes: 'دش الطوارئ وغسول العيون جاهزان بنسبة 100%. تم سحب ذراع الطوارئ والتأكد من استمرار التدفق.',
    createdAt: Date.now() - 2 * 24 * 60 * 60 * 1000
  }
];
