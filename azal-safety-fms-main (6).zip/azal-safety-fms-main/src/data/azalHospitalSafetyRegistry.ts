import { FireExtinguisherItem, SafetyTourRecord } from '../types';

/**
 * Standard Safety Inspection Checkpoints & Patrol Routes for Azal Model Hospital
 * أماكن ومسارات جولات السلامة المعتمدة
 */
export interface HospitalPatrolCheckpoint {
  id: string;
  department: string;
  zone: string;
  floor: string;
  checkpointName: string;
  tasks: string[];
  inspectorName: string;
  inspectorRole: string;
  scheduledTime: string;
  status: 'completed' | 'scheduled' | 'in_progress' | 'attention_required';
  statusAr: string;
  lastChecked: string;
  notes: string;
  hasViolation: boolean;
}

export const AZAL_HOSPITAL_PATROL_CHECKPOINTS: HospitalPatrolCheckpoint[] = [
  {
    id: 'PATROL-CHK-01',
    department: 'قسم الطوارئ والإسعاف',
    zone: 'الجناح الشرقي - مدخل سيارات الإسعاف ومسار الفرز',
    floor: 'الدور الأرضي',
    checkpointName: 'مسار طوارئ الإسعاف، بوابات الإخلاء وصناديق الحريق',
    tasks: ['فحص خلو مخارج الطوارئ من العوائق', 'فحص إنارة الطوارئ واللوحات الإرشادية', 'فحص صناديق الإطفاء والضغط'],
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    scheduledTime: '08:00 ص - يومياً',
    status: 'completed',
    statusAr: 'منجز ومطابق 🟢',
    lastChecked: '2026-09-13 08:30 ص',
    notes: 'المخارج سالكة بالكامل، إنارة الطوارئ تعمل بكفاءة، الطفايات مفحوصة وصالحة.',
    hasViolation: false
  },
  {
    id: 'PATROL-CHK-02',
    department: 'العمليات الجراحية الكبرى',
    zone: 'الجناح الجراحي المعقم - غرف العمليات 1-4',
    floor: 'الدور الثاني',
    checkpointName: 'ستائر الحريق، مخارج الإخلاء المعقمة، ومحابس الغازات',
    tasks: ['فحص أجهزة الإنذار ومحابس الغازات الطبية', 'فحص أبواب الطوارئ المانعة للحرائق', 'فحص طفايات ثاني أكسيد الكربون'],
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    scheduledTime: '09:00 ص - دوري',
    status: 'completed',
    statusAr: 'منجز ومطابق 🟢',
    lastChecked: '2026-09-13 09:15 ص',
    notes: 'الضغوط طبيعية، مخارج الإخلاء مفتوحة بنظام البطاقات الممغنطة وتعمل عند الطوارئ.',
    hasViolation: false
  },
  {
    id: 'PATROL-CHK-03',
    department: 'العناية المركزة (ICU & CCU)',
    zone: 'الجناح الغربي - أسرة العناية المركزة والممرات',
    floor: 'الدور الثاني',
    checkpointName: 'لوحات القواطع المعزولة ومنحدر الإخلاء السريع للأسرة',
    tasks: ['فحص منحدر إخلاء مرضى العناية', 'فحص القواطع الكهربائية المعزولة ضد الشرر', 'فحص أسطوانات الأكسجين الاحتياطية'],
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    scheduledTime: '09:45 ص - يومياً',
    status: 'completed',
    statusAr: 'منجز ومطابق 🟢',
    lastChecked: '2026-09-13 10:00 ص',
    notes: 'مسار المنحدر خالي من العوائق، أسطوانات الأكسجين مثبتة بسلاسل الأمان المعتمدة.',
    hasViolation: false
  },
  {
    id: 'PATROL-CHK-04',
    department: 'محطة الغازات الطبية وتوليد الأكسجين',
    zone: 'الفناء الخلفي والمبنى الفني للغازات الطبية',
    floor: 'الساحة الفنية الخارجية',
    checkpointName: 'خزان الأكسجين السائل ومحطة التعبئة ومحابس الأمان',
    tasks: ['فحص حساسات تسريب الأكسجين والغازات', 'فحص عربات الإطفاء البودرة 25 كجم', 'فحص صمامات التنفيس ومسافة الأمان'],
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    scheduledTime: '10:30 ص - مرتان يومياً',
    status: 'completed',
    statusAr: 'منجز ومطابق 🟢',
    lastChecked: '2026-09-13 10:45 ص',
    notes: 'الضغوط مطابقة للمواصفات الدولية، عربة الإطفاء جاهزة ومؤشر الضغط في النطاق الأخضر.',
    hasViolation: false
  },
  {
    id: 'PATROL-CHK-05',
    department: 'محطة المولدات والكهرباء الرئيسية',
    zone: 'القبو - غرفة القواطع الرئيسية (MDB) وغرفة المولدات',
    floor: 'القبو (Basement)',
    checkpointName: 'لوحة القواطع الرئيسية DB-G04 ونظام الغمر التلقائي CO2',
    tasks: ['فحص حرارة الكابلات والقواطع', 'فحص خلو محيط المولدات من الزيوت', 'فحص أسطوانات ثاني أكسيد الكربون ونظام الإطفاء التلقائي'],
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    scheduledTime: '11:15 ص - دوري',
    status: 'attention_required',
    statusAr: 'يتطلب صيانة عاجلة ⚠️',
    lastChecked: '2026-09-13 11:30 ص',
    notes: 'تم رصد حاجة لإصلاح قفل الباب الداخلي للوحة DB-G04 وإلزام الصيانة بإنهائه.',
    hasViolation: true
  },
  {
    id: 'PATROL-CHK-06',
    department: 'مبنى الخدمات المساندة والمغسلة المركزية',
    zone: 'مبنى الخدمات - مراجل البخار ومستودع البياضات',
    floor: 'الدور الأرضي - الخدمات',
    checkpointName: 'مراجل البخار، مستودع المواد الكيميائية ومخارج الطوارئ',
    tasks: ['فحص تهوية مستودع المواد الكيميائية', 'فحص مخارج الطوارئ الخلفية', 'فحص مطافئ الرغوة AFFF'],
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    scheduledTime: '12:00 م - يومياً',
    status: 'attention_required',
    statusAr: 'ملاحظة ومتابعة إدارية 🔴',
    lastChecked: '2026-09-13 12:15 م',
    notes: 'تم توجيه إشعار لقسم الخدمات برفع أكياس البياضات المعيقة للمخرج الخلفي فوراً.',
    hasViolation: true
  },
  {
    id: 'PATROL-CHK-07',
    department: 'المطبخ والتغذية العلاجية',
    zone: 'الجناح الخدمي - منطقة أفران الطهي والمداخن',
    floor: 'الدور الأرضي',
    checkpointName: 'نظام إطفاء هود الطهي (Wet Chemical) ومحابس الغاز السريع',
    tasks: ['فحص نظام الإطفاء الرطب Wet Chemical', 'فحص محبس الإغلاق الطارئ للغاز', 'فحص بطانيات الحريق ومطافئ البودرة'],
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    scheduledTime: '01:00 م - يومياً',
    status: 'completed',
    statusAr: 'منجز ومطابق 🟢',
    lastChecked: '2026-09-13 01:15 م',
    notes: 'نظام Wet Chemical مفحوص وشهادة المعايرة سارية، محبس الغاز الطارئ سليم وسهل الوصول.',
    hasViolation: false
  },
  {
    id: 'PATROL-CHK-08',
    department: 'قسم التعقيم المركزي (CSSD)',
    zone: 'الجناح الشمالي - أجهزة الأوتوكلاف والتخزين المعقم',
    floor: 'الدور الأول',
    checkpointName: 'أجهزة التعقيم بالبخار ومسار الإخلاء والتهوية الإيجابية',
    tasks: ['فحص ضغوط البخار وأجهزة الإنذار', 'فحص مخارج الطوارئ المؤدية للدرج الشرقي', 'فحص مطافئ ثاني أكسيد الكربون'],
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    scheduledTime: '02:00 م - دوري',
    status: 'completed',
    statusAr: 'منجز ومطابق 🟢',
    lastChecked: '2026-09-13 02:15 م',
    notes: 'المسارات سالكة بالكامل، أنظمة الإنذار تعمل بكفاءة عالية، مطافئ الحريق ممتازة.',
    hasViolation: false
  },
  {
    id: 'PATROL-CHK-09',
    department: 'المختبر المركزي وبنك الدم',
    zone: 'الدور الأول - غرف الكيمياء وبنك الدم وثلاجات الحفظ',
    floor: 'الدور الأول',
    checkpointName: 'ثلاجات حفظ الدم، أجهزة الطرد المركزي ومطافئ CO2',
    tasks: ['فحص دش الطوارئ وغسيل العيون', 'فحص مطافئ ثاني أكسيد الكربون للأجهزة الدقيقة', 'فحص خطة احتواء الانسكابات الكيميائية'],
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    scheduledTime: '03:30 م - دوري',
    status: 'completed',
    statusAr: 'منجز ومطابق 🟢',
    lastChecked: '2026-09-13 03:45 م',
    notes: 'أطقم الانسكابات الكيميائية مكتملة، دش الطوارئ مفحوص، الطفايات صالحة.',
    hasViolation: false
  },
  {
    id: 'PATROL-CHK-10',
    department: 'قسم الأشعة التشخيصية والتصوير الطبقي',
    zone: 'الدور الأول - غرف الرنين المغناطيسي والأشعة المقطعية',
    floor: 'الدور الأول',
    checkpointName: 'غرفة الرنين (MRI) ومطافئ الـ Non-Magnetic ومخارج الطوارئ',
    tasks: ['فحص مطافئ الحريق غير الممغنطة المعتمدة للرنين', 'فحص مسارات الهروب الخالية من العوائق', 'فحص إغلاق أبواب العزل الإشعاعي'],
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    scheduledTime: '05:00 م - مجدول',
    status: 'scheduled',
    statusAr: 'مجدول للوردية المسائية 🔵',
    lastChecked: 'مجدول اليوم 05:00 م',
    notes: 'ضمن جدول التفتيش المسائي الدوري المعتمد.',
    hasViolation: false
  }
];

/**
 * Master Fire Extinguishers Registry & Comprehensive Census for Azal Model Hospital
 * سجل وحصر مطافئ الحريق الشامل بمستشفى آزال النموذجي
 * Total: 28 Extinguishers spanning all types, capacities, and hospital zones
 */
export const AZAL_MASTER_FIRE_EXTINGUISHERS: FireExtinguisherItem[] = [
  // 1. Emergency Department & Ground Floor
  {
    id: 'EXT-AZAL-001',
    serialNumber: 'EXT-AZAL-001',
    location: 'الدور الأرضي - مدخل طوارئ الإسعاف الرئيسي بجانب الباب الإلكتروني',
    zone: 'قسم الطوارئ والإسعاف',
    floor: 'الدور الأرضي',
    capacity: '6 كجم',
    weight: '6 كجم',
    type: 'dry_powder',
    typeAr: 'بودرة جافة (Dry Powder)',
    gaugeStatus: 'normal',
    conditionStatus: 'valid',
    expiryDate: '2027-08-15',
    lastInspectedAt: '2026-09-05',
    nextInspectionDue: '2026-10-05',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-001',
    notes: 'مؤشر الضغط في النطاق الأخضر، مسمار الأمان وسلك الرصاص سليم، الخرطوم مرن.',
    synced: true
  },
  {
    id: 'EXT-AZAL-002',
    serialNumber: 'EXT-AZAL-002',
    location: 'الدور الأرضي - ممر إنعاش الطوارئ (Resuscitation Room) بجانب مخرج الطوارئ رقم 1',
    zone: 'قسم الطوارئ والإسعاف',
    floor: 'الدور الأرضي',
    capacity: '5 كجم',
    weight: '5 كجم',
    type: 'co2',
    typeAr: 'ثاني أكسيد الكربون (CO2)',
    gaugeStatus: 'normal',
    conditionStatus: 'valid',
    expiryDate: '2027-09-01',
    lastInspectedAt: '2026-09-05',
    nextInspectionDue: '2026-10-05',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-002',
    notes: 'مخصصة للأجهزة والمعدات الحيوية الحساسة، البوق سليم وجاهزية تامة.',
    synced: true
  },
  {
    id: 'EXT-AZAL-003',
    serialNumber: 'EXT-AZAL-003',
    location: 'الدور الأرضي - صالة الاستقبال والتسجيل الرئيسية بجانب الباب الزجاجي',
    zone: 'الاستقبال والعيادات الخارجية',
    floor: 'الدور الأرضي',
    capacity: '6 كجم',
    weight: '6 كجم',
    type: 'dry_powder',
    typeAr: 'بودرة جافة (Dry Powder)',
    gaugeStatus: 'normal',
    conditionStatus: 'valid',
    expiryDate: '2027-07-20',
    lastInspectedAt: '2026-09-06',
    nextInspectionDue: '2026-10-06',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-003',
    notes: 'مثبتة على الحامل الجداري بارتفاع 1.2م طبقاً لاشتراطات الدفاع المدني.',
    synced: true
  },
  {
    id: 'EXT-AZAL-004',
    serialNumber: 'EXT-AZAL-004',
    location: 'الدور الأرضي - الصيدلية المركزية بجانب مستودع المحاليل',
    zone: 'الصيدلية المركزية',
    floor: 'الدور الأرضي',
    capacity: '2 كجم',
    weight: '2 كجم',
    type: 'co2',
    typeAr: 'ثاني أكسيد الكربون (CO2)',
    gaugeStatus: 'normal',
    conditionStatus: 'valid',
    expiryDate: '2027-10-10',
    lastInspectedAt: '2026-09-06',
    nextInspectionDue: '2026-10-06',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-004',
    notes: 'أسطوانة خفيفة مخصصة للأجهزة الحاسوبية وثلاجات حفظ الأدوية.',
    synced: true
  },

  // 2. Central Kitchen & Nutrition (Class K & Wet Chemical)
  {
    id: 'EXT-AZAL-005',
    serialNumber: 'EXT-AZAL-005',
    location: 'الدور الأرضي - المطبخ والتغذية العلاجية بجانب محطة القلي والأفران الرئيسية',
    zone: 'المطبخ المركزي',
    floor: 'الدور الأرضي',
    capacity: '6 لتر',
    weight: '6 لتر',
    type: 'wet_chemical',
    typeAr: 'مواد كيميائية رطبة (Wet Chemical - K)',
    gaugeStatus: 'normal',
    conditionStatus: 'valid',
    expiryDate: '2027-06-30',
    lastInspectedAt: '2026-09-07',
    nextInspectionDue: '2026-10-07',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-005',
    notes: 'مخصصة لحرائق زيوت وشحوم الطهي (فئة K)، الفوهة نظيفة، الضغط سليم.',
    synced: true
  },
  {
    id: 'EXT-AZAL-006',
    serialNumber: 'EXT-AZAL-006',
    location: 'الدور الأرضي - المطبخ والتغذية العلاجية عند مخرج التوزيع الخلفي',
    zone: 'المطبخ المركزي',
    floor: 'الدور الأرضي',
    capacity: '9 لتر',
    weight: '9 لتر',
    type: 'foam',
    typeAr: 'رغوة ميكانيكية (Foam AFFF)',
    gaugeStatus: 'normal',
    conditionStatus: 'valid',
    expiryDate: '2027-05-15',
    lastInspectedAt: '2026-09-07',
    nextInspectionDue: '2026-10-07',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-006',
    notes: 'جاهزة، مناسبة للحرائق الصلبة والسائلة.',
    synced: true
  },

  // 3. First Floor: Laboratories, Blood Bank & Diagnostic Radiology
  {
    id: 'EXT-AZAL-007',
    serialNumber: 'EXT-AZAL-007',
    location: 'الدور الأول - المختبر المركزي بجانب أجهزة التحليل الآلي وبنك الدم',
    zone: 'المختبر المركزي وبنك الدم',
    floor: 'الدور الأول',
    capacity: '5 كجم',
    weight: '5 كجم',
    type: 'co2',
    typeAr: 'ثاني أكسيد الكربون (CO2)',
    gaugeStatus: 'normal',
    conditionStatus: 'valid',
    expiryDate: '2027-08-01',
    lastInspectedAt: '2026-09-08',
    nextInspectionDue: '2026-10-08',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-007',
    notes: 'أسطوانة مخصصة لحماية أجهزة التحليل الحساسة دون ترك بقايا.',
    synced: true
  },
  {
    id: 'EXT-AZAL-008',
    serialNumber: 'EXT-AZAL-008',
    location: 'الدور الأول - ممر المختبر المركزي الرئيسي بجانب مخرج الطوارئ رقم 2',
    zone: 'المختبر المركزي',
    floor: 'الدور الأول',
    capacity: '6 كجم',
    weight: '6 كجم',
    type: 'dry_powder',
    typeAr: 'بودرة جافة (Dry Powder)',
    gaugeStatus: 'normal',
    conditionStatus: 'valid',
    expiryDate: '2027-09-12',
    lastInspectedAt: '2026-09-08',
    nextInspectionDue: '2026-10-08',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-008',
    notes: 'الضغط في الأخضر، الصمام مؤمّن بسديلة الأمان.',
    synced: true
  },
  {
    id: 'EXT-AZAL-009',
    serialNumber: 'EXT-AZAL-009',
    location: 'الدور الأول - قسم الأشعة التشخيصية بجانب غرفة التحكم في الأشعة المقطعية (CT)',
    zone: 'الأشعة والتصوير المقطعي',
    floor: 'الدور الأول',
    capacity: '5 كجم',
    weight: '5 كجم',
    type: 'co2',
    typeAr: 'ثاني أكسيد الكربون (CO2)',
    gaugeStatus: 'normal',
    conditionStatus: 'valid',
    expiryDate: '2027-06-25',
    lastInspectedAt: '2026-09-08',
    nextInspectionDue: '2026-10-08',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-009',
    notes: 'مفحوصة ونظيفة، مخصصة لحماية الأجهزة الإلكترونية والمحولات الدقيقة.',
    synced: true
  },
  {
    id: 'EXT-AZAL-010',
    serialNumber: 'EXT-AZAL-010',
    location: 'الدور الأول - قسم التعقيم المركزي (CSSD) بجانب مدخل الأوتوكلاف',
    zone: 'التعقيم المركزي',
    floor: 'الدور الأول',
    capacity: '9 لتر',
    weight: '9 لتر',
    type: 'water',
    typeAr: 'ماء تحت الضغط (Water)',
    gaugeStatus: 'normal',
    conditionStatus: 'valid',
    expiryDate: '2027-04-10',
    lastInspectedAt: '2026-09-08',
    nextInspectionDue: '2026-10-08',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-010',
    notes: 'مخصصة لحرائق المواد الصلبة والبياضات والأوراق، الضغط طبيعي.',
    synced: true
  },

  // 4. Second Floor: Intensive Care (ICU) & Major Operating Theaters
  {
    id: 'EXT-AZAL-011',
    serialNumber: 'EXT-AZAL-011',
    location: 'الدور الثاني - جناح العمليات الكبرى بجانب غرفة التعقيم والتحضير',
    zone: 'العمليات الجراحية الكبرى',
    floor: 'الدور الثاني',
    capacity: '5 كجم',
    weight: '5 كجم',
    type: 'co2',
    typeAr: 'ثاني أكسيد الكربون (CO2)',
    gaugeStatus: 'normal',
    conditionStatus: 'valid',
    expiryDate: '2027-11-01',
    lastInspectedAt: '2026-09-09',
    nextInspectionDue: '2026-10-09',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-011',
    notes: 'أسطوانة معقمة للبيئات الجراحية الحساسة، البوق سليم.',
    synced: true
  },
  {
    id: 'EXT-AZAL-012',
    serialNumber: 'EXT-AZAL-012',
    location: 'الدور الثاني - ممر العمليات الجراحية بجانب مخرج الطوارئ رقم 3',
    zone: 'العمليات الجراحية الكبرى',
    floor: 'الدور الثاني',
    capacity: '6 كجم',
    weight: '6 كجم',
    type: 'dry_powder',
    typeAr: 'بودرة جافة (Dry Powder)',
    gaugeStatus: 'normal',
    conditionStatus: 'valid',
    expiryDate: '2027-07-15',
    lastInspectedAt: '2026-09-09',
    nextInspectionDue: '2026-10-09',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-012',
    notes: 'جاهزية تامة، موقع استراتيجي على مسار الإخلاء.',
    synced: true
  },
  {
    id: 'EXT-AZAL-013',
    serialNumber: 'EXT-AZAL-013',
    location: 'الدور الثاني - مدخل العناية المركزة (ICU) عند محطة التمريض الرئيسية',
    zone: 'العناية المركزة (ICU)',
    floor: 'الدور الثاني',
    capacity: '5 كجم',
    weight: '5 كجم',
    type: 'co2',
    typeAr: 'ثاني أكسيد الكربون (CO2)',
    gaugeStatus: 'normal',
    conditionStatus: 'valid',
    expiryDate: '2027-08-20',
    lastInspectedAt: '2026-09-09',
    nextInspectionDue: '2026-10-09',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-013',
    notes: 'مخصصة لحماية أجهزة التنفس الاصطناعي وشاشات المراقبة الحيوية.',
    synced: true
  },
  {
    id: 'EXT-AZAL-014',
    serialNumber: 'EXT-AZAL-014',
    location: 'الدور الثاني - منحدر إخلاء العناية المركزة بجانب باب مخرج الطوارئ',
    zone: 'العناية المركزة (ICU)',
    floor: 'الدور الثاني',
    capacity: '6 كجم',
    weight: '6 كجم',
    type: 'dry_powder',
    typeAr: 'بودرة جافة (Dry Powder)',
    gaugeStatus: 'normal',
    conditionStatus: 'valid',
    expiryDate: '2027-09-05',
    lastInspectedAt: '2026-09-09',
    nextInspectionDue: '2026-10-09',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-014',
    notes: 'مؤشر الضغط ممتاز، تم اختبار حركة المقبض.',
    synced: true
  },

  // 5. Third Floor: Inpatient Wards, Dialysis & Maternity
  {
    id: 'EXT-AZAL-015',
    serialNumber: 'EXT-AZAL-015',
    location: 'الدور الثالث - مركز الغسيل الكلوي بجانب غرفة محطة معالجة المياه (RO)',
    zone: 'مركز الغسيل الكلوي',
    floor: 'الدور الثالث',
    capacity: '6 كجم',
    weight: '6 كجم',
    type: 'dry_powder',
    typeAr: 'بودرة جافة (Dry Powder)',
    gaugeStatus: 'normal',
    conditionStatus: 'valid',
    expiryDate: '2027-07-01',
    lastInspectedAt: '2026-09-10',
    nextInspectionDue: '2026-10-10',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-015',
    notes: 'حالة ممتازة، مثبتة بالقرب من مخارج الطوارئ.',
    synced: true
  },
  {
    id: 'EXT-AZAL-016',
    serialNumber: 'EXT-AZAL-016',
    location: 'الدور الثالث - قسم النساء والتوليد وحواضن الأطفال بجانب محطة التمريض',
    zone: 'النساء والتوليد والحواضن',
    floor: 'الدور الثالث',
    capacity: '2 كجم',
    weight: '2 كجم',
    type: 'co2',
    typeAr: 'ثاني أكسيد الكربون (CO2)',
    gaugeStatus: 'normal',
    conditionStatus: 'valid',
    expiryDate: '2027-10-05',
    lastInspectedAt: '2026-09-10',
    nextInspectionDue: '2026-10-10',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-016',
    notes: 'مخصصة لحواضن الأطفال وأجهزة التنفس لحديثي الولادة.',
    synced: true
  },
  {
    id: 'EXT-AZAL-017',
    serialNumber: 'EXT-AZAL-017',
    location: 'الدور الثالث - ممر رقود المرضى (الجناح العام) بجانب مخرج الطوارئ رقم 4',
    zone: 'أقسام رقود المرضى',
    floor: 'الدور الثالث',
    capacity: '6 كجم',
    weight: '6 كجم',
    type: 'dry_powder',
    typeAr: 'بودرة جافة (Dry Powder)',
    gaugeStatus: 'normal',
    conditionStatus: 'valid',
    expiryDate: '2027-08-10',
    lastInspectedAt: '2026-09-10',
    nextInspectionDue: '2026-10-10',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-017',
    notes: 'صلاحية سارية، الفحص الشهري منتظم.',
    synced: true
  },

  // 6. Fourth Floor: Hospital Administration & IT Server Room
  {
    id: 'EXT-AZAL-018',
    serialNumber: 'EXT-AZAL-018',
    location: 'الدور الرابع - غرفة السيرفرات الرئيسية وتقنية المعلومات (IT Server Room)',
    zone: 'تقنية المعلومات والإدارة',
    floor: 'الدور الرابع',
    capacity: '5 كجم',
    weight: '5 كجم',
    type: 'co2',
    typeAr: 'ثاني أكسيد الكربون (CO2)',
    gaugeStatus: 'normal',
    conditionStatus: 'valid',
    expiryDate: '2027-12-01',
    lastInspectedAt: '2026-09-11',
    nextInspectionDue: '2026-10-11',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-018',
    notes: 'مخصصة لحماية الخوادم وشبكة المستشفى المركزية.',
    synced: true
  },
  {
    id: 'EXT-AZAL-019',
    serialNumber: 'EXT-AZAL-019',
    location: 'الدور الرابع - ممر الإدارة العامة بجانب مكتب المدير العام ومخرج الطوارئ',
    zone: 'الإدارة العامة للمستشفى',
    floor: 'الدور الرابع',
    capacity: '6 كجم',
    weight: '6 كجم',
    type: 'dry_powder',
    typeAr: 'بودرة جافة (Dry Powder)',
    gaugeStatus: 'normal',
    conditionStatus: 'valid',
    expiryDate: '2027-06-15',
    lastInspectedAt: '2026-09-11',
    nextInspectionDue: '2026-10-11',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-019',
    notes: 'جاهزة ومؤشر الضغط مثالي في النطاق الأخضر.',
    synced: true
  },

  // 7. Basement & Electromechanical Plant (Critical High-Risk Zone)
  {
    id: 'EXT-AZAL-020',
    serialNumber: 'EXT-AZAL-020',
    location: 'القبو - غرفة لوحات الكهرباء والقواطع الرئيسية (MDB Panel Room)',
    zone: 'محطة الكهرباء الرئيسية',
    floor: 'القبو (Basement)',
    capacity: '10 كجم',
    weight: '10 كجم',
    type: 'co2',
    typeAr: 'ثاني أكسيد الكربون (CO2)',
    gaugeStatus: 'normal',
    conditionStatus: 'valid',
    expiryDate: '2027-05-20',
    lastInspectedAt: '2026-09-02',
    nextInspectionDue: '2026-10-02',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-020',
    notes: 'أسطوانة ضخمة مزدوجة المقبض مخصصة للقواطع عالية الجهد.',
    synced: true
  },
  {
    id: 'EXT-AZAL-021',
    serialNumber: 'EXT-AZAL-021',
    location: 'القبو - محطة المولدات الكهربائية الكبرى (Diesel Generators Room)',
    zone: 'محطة المولدات والكهرباء',
    floor: 'القبو (Basement)',
    capacity: '50 كجم (عربة)',
    weight: '50 كجم',
    type: 'dry_powder',
    typeAr: 'بودرة جافة (عربة متنقلة Wheel Cart)',
    gaugeStatus: 'normal',
    conditionStatus: 'valid',
    expiryDate: '2027-04-15',
    lastInspectedAt: '2026-09-02',
    nextInspectionDue: '2026-10-02',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-021',
    notes: 'عربة إطفاء متنقلة ذات عجلات لخزانات الديزل والمولدات، الضغط مشحون بدقة.',
    synced: true
  },
  {
    id: 'EXT-AZAL-022',
    serialNumber: 'EXT-AZAL-022',
    location: 'القبو - ممر الخدمات الكهروميكانيكية بجانب مضخات شفط المياه',
    zone: 'الخدمات الكهروميكانيكية',
    floor: 'القبو (Basement)',
    capacity: '9 كجم',
    weight: '9 كجم',
    type: 'dry_powder',
    typeAr: 'بودرة جافة (Dry Powder)',
    gaugeStatus: 'low',
    conditionStatus: 'needs_maintenance',
    expiryDate: '2026-11-20',
    lastInspectedAt: '2026-09-02',
    nextInspectionDue: '2026-09-20 (عاجل)',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-022',
    notes: '🔴 مؤشر الضغط في النطاق الأصفر/المنخفض، تم إدراجها ضمن أمر الشحن والتعبئة الفوري.',
    synced: true
  },

  // 8. Oxygen Plant & External Support Buildings
  {
    id: 'EXT-AZAL-023',
    serialNumber: 'EXT-AZAL-023',
    location: 'الساحة الخلفية - محطة توليد وتعبئة الغازات الطبية والأكسجين بجانب الصهريج',
    zone: 'محطة الأكسجين الطبي',
    floor: 'الساحة الخارجية',
    capacity: '25 كجم (عربة)',
    weight: '25 كجم',
    type: 'dry_powder',
    typeAr: 'بودرة جافة (عربة متنقلة Wheel Cart)',
    gaugeStatus: 'normal',
    conditionStatus: 'valid',
    expiryDate: '2027-08-30',
    lastInspectedAt: '2026-09-03',
    nextInspectionDue: '2026-10-03',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-023',
    notes: 'عربة مخصصة لمنطقة صهريج الأكسجين، العجلات وسلك التأريض والخرطوم سليم.',
    synced: true
  },
  {
    id: 'EXT-AZAL-024',
    serialNumber: 'EXT-AZAL-024',
    location: 'الساحة الخلفية - مدخل مبنى تعبئة أسطوانات الأكسجين الطبي',
    zone: 'محطة الأكسجين الطبي',
    floor: 'المبنى الفني',
    capacity: '9 كجم',
    weight: '9 كجم',
    type: 'dry_powder',
    typeAr: 'بودرة جافة (Dry Powder)',
    gaugeStatus: 'normal',
    conditionStatus: 'valid',
    expiryDate: '2027-07-25',
    lastInspectedAt: '2026-09-03',
    nextInspectionDue: '2026-10-03',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-024',
    notes: 'مؤشر الضغط ممتاز، مسمار الأمان محكم.',
    synced: true
  },
  {
    id: 'EXT-AZAL-025',
    serialNumber: 'EXT-AZAL-025',
    location: 'مبنى الخدمات المساندة - المغسلة المركزية ومستودع البياضات بجانب مراجل البخار',
    zone: 'مبنى الخدمات والمغسلة',
    floor: 'الدور الأرضي - الخدمات',
    capacity: '25 لتر (عربة)',
    weight: '25 لتر',
    type: 'foam',
    typeAr: 'رغوة ميكانيكية (عربة AFFF)',
    gaugeStatus: 'normal',
    conditionStatus: 'valid',
    expiryDate: '2027-03-15',
    lastInspectedAt: '2026-09-04',
    nextInspectionDue: '2026-10-04',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-025',
    notes: 'عربة رغوة ميكانيكية لعزل أي اشتعال سائل أو مواد تكسية.',
    synced: true
  },
  {
    id: 'EXT-AZAL-026',
    serialNumber: 'EXT-AZAL-026',
    location: 'مبنى الخدمات المساندة - مستودع المواد الكيميائية ومساحيق التعقيم',
    zone: 'مبنى الخدمات والمغسلة',
    floor: 'الدور الأرضي - الخدمات',
    capacity: '9 كجم',
    weight: '9 كجم',
    type: 'dry_powder',
    typeAr: 'بودرة جافة (Dry Powder)',
    gaugeStatus: 'low',
    conditionStatus: 'needs_maintenance',
    expiryDate: '2026-12-05',
    lastInspectedAt: '2026-09-04',
    nextInspectionDue: '2026-09-25 (عاجل)',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-026',
    notes: '⚠️ مؤشر الضغط تحت المستوى الطبيعي قليلاً، تتطلب إعادة تعاير ضغط النيتروجين.',
    synced: true
  },
  {
    id: 'EXT-AZAL-027',
    serialNumber: 'EXT-AZAL-027',
    location: 'السطح العلوي (Roof) - بجانب محطة مضخات شبكة الإطفاء المائية وخزانات المياه',
    zone: 'السطح ومضخات الحريق',
    floor: 'السطح (Roof)',
    capacity: '9 لتر',
    weight: '9 لتر',
    type: 'water',
    typeAr: 'ماء تحت الضغط (Water)',
    gaugeStatus: 'normal',
    conditionStatus: 'valid',
    expiryDate: '2027-05-01',
    lastInspectedAt: '2026-09-01',
    nextInspectionDue: '2026-10-01',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-027',
    notes: 'مضخة الحريق تعمل بكفاءة، الطفاية صالحة ومغلفة بغطاء واقي من الشمس والأمطار.',
    synced: true
  },
  {
    id: 'EXT-AZAL-028',
    serialNumber: 'EXT-AZAL-028',
    location: 'الساحة الغربية - محطة محرقة النفايات الطبية الخطرة',
    zone: 'محرقة النفايات الطبية',
    floor: 'الساحة الخارجية',
    capacity: '9 لتر',
    weight: '9 لتر',
    type: 'wet_chemical',
    typeAr: 'مواد كيميائية رطبة (Wet Chemical)',
    gaugeStatus: 'normal',
    conditionStatus: 'valid',
    expiryDate: '2027-09-15',
    lastInspectedAt: '2026-09-01',
    nextInspectionDue: '2026-10-01',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    signatureProof: 'OSH-AZAL-SEAL-028',
    notes: 'مثبتة خارج غرفة الفرن، مجدولة للفحص الدوري الأسبوعي.',
    synced: true
  }
];

/**
 * Baseline tours records derived from patrol checkpoints
 */
export const AZAL_MASTER_SAFETY_TOURS: SafetyTourRecord[] = [
  {
    id: 'TOUR-2026-09-01',
    department: 'قسم الطوارئ والإسعاف',
    customDepartment: 'مخارج الطوارئ ومسار الإسعاف',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    tourDate: '2026-09-13',
    timestamp: Date.now() - 3600000 * 5,
    tasks: [
      'فحص مخارج الطوارئ ومسارات الهروب وخلوها من العوائق',
      'فحص لوحات وقواطع الكهرباء والمولدات الاحتياطية',
      'فحص رشاشات الحريق وكواشف الدخان والإنذار'
    ],
    hasViolation: false,
    notes: 'جولة تفتيشية صباحية شاملة. جميع مخارج الطوارئ سالكة ونظام الإنذار يعمل بكفاءة.',
    synced: true,
    checkpointName: 'مسار طوارئ الإسعاف، بوابات الإخلاء وصناديق الحريق',
    routeZone: 'الجناح الشرقي - الدور الأرضي',
    routeStatus: 'completed'
  },
  {
    id: 'TOUR-2026-09-02',
    department: 'العمليات الجراحية الكبرى',
    customDepartment: 'الجناح الجراحي المعقم',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    tourDate: '2026-09-13',
    timestamp: Date.now() - 3600000 * 4,
    tasks: [
      'فحص أسطوانات الغاز ومحابس شبكة الغازات الطبية',
      'فحص الممرات ومصاعد المستشفى وإنارة الطوارئ',
      'فحص طفايات الحريق في ممرات الجناح الجراحي'
    ],
    hasViolation: false,
    notes: 'التدقيق على محابس شبكة الغازات الطبية وطفايات ثاني أكسيد الكربون CO2. الجاهزية 100%.',
    synced: true,
    checkpointName: 'ستائر الحريق، مخارج الإخلاء المعقمة، ومحابس الغازات',
    routeZone: 'الجناح الجراحي - الدور الثاني',
    routeStatus: 'completed'
  },
  {
    id: 'TOUR-2026-09-03',
    department: 'العناية المركزة (ICU)',
    customDepartment: 'العناية المركزة ومنحدر الإخلاء',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    tourDate: '2026-09-13',
    timestamp: Date.now() - 3600000 * 3,
    tasks: [
      'فحص مخارج الطوارئ ومسارات الهروب وخلوها من العوائق',
      'فحص أسطوانات الغاز ومحابس شبكة الغازات الطبية',
      'فحص صناديق الإسعافات الأولية والتجهيزات الوقائية'
    ],
    hasViolation: false,
    notes: 'منحدر الإخلاء سالك بالكامل وجاهز لنقل أسرة العناية وقت الطوارئ.',
    synced: true,
    checkpointName: 'لوحات القواطع المعزولة ومنحدر الإخلاء السريع للأسرة',
    routeZone: 'الجناح الغربي - الدور الثاني',
    routeStatus: 'completed'
  },
  {
    id: 'TOUR-2026-09-04',
    department: 'محطة الغازات الطبية وتوليد الأكسجين',
    customDepartment: 'محطة الأكسجين والصهريج المركزي',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    tourDate: '2026-09-13',
    timestamp: Date.now() - 3600000 * 2,
    tasks: [
      'فحص أسطوانات الغاز ومحابس شبكة الغازات الطبية',
      'فحص رشاشات الحريق وكواشف الدخان والإنذار',
      'فحص عربات الإطفاء 25 كجم بودرة جافة'
    ],
    hasViolation: false,
    notes: 'فحص صمامات الأمان وعربة الإطفاء 25 كجم. الضغوط مطابقة للمواصفات الدولية.',
    synced: true,
    checkpointName: 'خزان الأكسجين السائل ومحطة التعبئة ومحابس الأمان',
    routeZone: 'الساحة الفنية الخارجية',
    routeStatus: 'completed'
  },
  {
    id: 'TOUR-2026-09-05',
    department: 'محطة المولدات والكهرباء الرئيسية',
    customDepartment: 'غرفة القواطع الكهربائية MDB',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    tourDate: '2026-09-13',
    timestamp: Date.now() - 3600000 * 1,
    tasks: [
      'فحص لوحات وقواطع الكهرباء والمولدات الاحتياطية',
      'فحص رشاشات الحريق وكواشف الدخان والإنذار'
    ],
    hasViolation: true,
    violationId: 'AZAL-VIO-2026-002',
    notes: 'لوحة القواطع الكهربائية الرئيسية بحاجة لإصلاح القفل وتأمين الأسلاك الداخلية.',
    synced: true,
    checkpointName: 'لوحة القواطع الرئيسية DB-G04 ونظام الغمر التلقائي CO2',
    routeZone: 'القبو - المحطة الكهروميكانيكية',
    routeStatus: 'attention_required'
  },
  {
    id: 'TOUR-2026-09-06',
    department: 'المغسلة المركزية ومستودع البياضات',
    customDepartment: 'مبنى الخدمات المساندة والمغسلة',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم الأمن والسلامة',
    tourDate: '2026-09-13',
    timestamp: Date.now() - 1800000,
    tasks: [
      'فحص مخارج الطوارئ ومسارات الهروب وخلوها من العوائق',
      'فحص الممرات ومصاعد المستشفى وإنارة الطوارئ'
    ],
    hasViolation: true,
    violationId: 'AZAL-VIO-2026-001',
    notes: 'تكديس أكياس بياضات أمام مخرج الطوارئ بممر المغسلة. تم تحرير إشعار مخالفة عاجل.',
    synced: true,
    checkpointName: 'مراجل البخار، مستودع المواد الكيميائية ومخارج الطوارئ',
    routeZone: 'مبنى الخدمات المساندة',
    routeStatus: 'attention_required'
  }
];

/**
 * Compute detailed statistical breakdown for extinguishers census
 */
export function calculateCensusBreakdown(extinguishers: FireExtinguisherItem[]) {
  const total = extinguishers.length;

  // Breakdown by Type
  const byType: Record<string, { count: number; labelAr: string; labelEn: string; iconColor: string }> = {
    dry_powder: { count: 0, labelAr: 'بودرة جافة', labelEn: 'Dry Powder (ABC)', iconColor: 'text-blue-400' },
    co2: { count: 0, labelAr: 'ثاني أكسيد الكربون', labelEn: 'Carbon Dioxide (CO2)', iconColor: 'text-slate-300' },
    foam: { count: 0, labelAr: 'رغوة ميكانيكية', labelEn: 'Mechanical Foam (AFFF)', iconColor: 'text-amber-400' },
    water: { count: 0, labelAr: 'ماء تحت الضغط', labelEn: 'Pressurized Water', iconColor: 'text-cyan-400' },
    wet_chemical: { count: 0, labelAr: 'مواد كيميائية رطبة', labelEn: 'Wet Chemical (Class K)', iconColor: 'text-emerald-400' },
  };

  // Breakdown by Capacity
  const byCapacity: Record<string, number> = {};

  // Status breakdown
  let operationalCount = 0;
  let needsMaintenanceCount = 0;
  let expiredCount = 0;

  extinguishers.forEach((item) => {
    // Type normalization
    const t = (item.type || 'dry_powder').toLowerCase();
    if (byType[t]) {
      byType[t].count += 1;
    } else {
      if (t.includes('powder') || t.includes('بودرة')) byType.dry_powder.count += 1;
      else if (t.includes('co2') || t.includes('كربون')) byType.co2.count += 1;
      else if (t.includes('foam') || t.includes('رغوة')) byType.foam.count += 1;
      else if (t.includes('water') || t.includes('ماء')) byType.water.count += 1;
      else if (t.includes('wet') || t.includes('رطب') || t.includes('chemical')) byType.wet_chemical.count += 1;
      else byType.dry_powder.count += 1;
    }

    // Capacity normalization
    const cap = item.capacity || item.weight || '6 كجم';
    byCapacity[cap] = (byCapacity[cap] || 0) + 1;

    // Condition
    const isOperational = (item.conditionStatus === 'valid' || !item.conditionStatus) && 
                          (item.gaugeStatus === 'normal' || !item.gaugeStatus);
    if (isOperational) {
      operationalCount += 1;
    } else if (item.conditionStatus === 'expired') {
      expiredCount += 1;
      needsMaintenanceCount += 1;
    } else {
      needsMaintenanceCount += 1;
    }
  });

  const operationalRate = total > 0 ? Math.round((operationalCount / total) * 100) : 100;

  return {
    total,
    operationalCount,
    needsMaintenanceCount,
    expiredCount,
    operationalRate,
    byType,
    byCapacity,
  };
}
