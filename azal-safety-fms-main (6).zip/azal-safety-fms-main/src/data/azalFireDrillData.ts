import { FireDrillRecord, AnnualCbahieExecutiveSummary } from '../types';

/**
 * Initial Fire Drill Records for Azal Model Hospital
 * تجارب الحريق والإخلاء الفرضية المعتمدة وفق السياسات FMS-PLAN-008EA و FMS-PLAN-0011EA
 */
export const INITIAL_FIRE_DRILL_RECORDS: FireDrillRecord[] = [
  {
    id: 'DRILL-2026-001',
    drillCode: 'FD-2026-01',
    policyCodes: ['FMS-PLAN-008EA', 'FMS-PLAN-0011EA'],
    title: 'فرضية حريق وإخلاء طارئ - العناية المركزة (ICU)',
    scenario: 'اشتعال لهب ودخان مفاجئ ناتج عن تماس كهربائي في محول جهاز التنفس الاصطناعي بغرفة العزل رقم (2) في قسم العناية المركزة بالدور الثاني.',
    date: '2026-06-18',
    shift: 'morning',
    department: 'العناية المركزة (ICU)',
    floor: 'الدور الثاني - الجناح الغربي',
    evacuationType: 'horizontal',
    assemblyPointLocation: 'الجناح الجراحي المجاور خلف أبواب الحريق الدخانية المعزولة (المنطقة الآمنة)',
    codeRedAnnouncedAt: '10:04:15',
    fireTeamArrivedAt: '10:06:20',
    evacuationCompletedAt: '10:09:40',
    drillEndedAt: '10:18:00',
    calculatedEvacuationMinutes: 5.4,
    calculatedResponseMinutes: 2.1,
    totalParticipantsCount: 24,
    simulatedPatientsCount: 4,
    emptyRoomTagsVerified: true,
    emptyRoomTagsNotes: 'تم تعليق بطاقات (خالية / Empty) الفسفورية على أبواب غرف العزل والعناية التي تم تفريغها بالكامل.',
    raceAudit: {
      rescue: {
        status: 'compliant',
        score: 25,
        notes: 'تم نقل 4 حالات حرجة عبر أسرة الطوارئ مع أسطوانات الأكسجين المحمولة وحقائب الإنعاش دون أي تأخير.'
      },
      alarm: {
        status: 'compliant',
        score: 25,
        notes: 'تم كسر زجاج الإنذار فوراً وإطلاق النداء الداخلي "Code Red - ICU Ward" عبر الإذاعة الداخلية والسنترال.'
      },
      confine: {
        status: 'compliant',
        score: 25,
        notes: 'تم إغلاق أبواب الغرف وإسدال ستائر الحريق وإيقاف محبس الأكسجين الفرعي (Zone Valve) للمنطقة المشتعلة فقط.'
      },
      evacuate: {
        status: 'compliant',
        score: 22,
        notes: 'تم الإخلاء الأفقي المنظم بنجاح تام، وسجل زمن إخلاء قياسي قدره 5 دقائق و25 ثانية.'
      }
    },
    passAudit: {
      pull: true,
      aim: true,
      squeeze: true,
      sweep: true,
      usedExtinguisherType: 'ثاني أكسيد الكربون CO2 (5 كجم) مخصصة للأجهزة الطبية الحساسة',
      techniqueCompliant: true,
      notes: 'قام التمريض ورجل السلامة بمحاكاة الإطفاء بدقة متناهية من مسافة 2 متر باتجاه قاعدة اللهب.'
    },
    focusPdca: {
      find: 'رصد بطء طفيف في فك وصلة الغاز الجدارية لأحد أجهزة المراقبة أثناء سرعة النقل.',
      organize: 'فريق السلامة المهنية + مشرف تمريض العناية المركزة + مهندس الصيانة الطبية.',
      clarify: 'مراجعة دليل فك وتركيب الأجهزة الطبية في حالات الإخلاء الفوري.',
      understand: 'عدم وجود علامة بارزة وسريعة على قفل الوصلة السريعة (Quick Connector).',
      select: 'تزويد جميع وصلات أجهزة العناية بأشرطة سحب سريعة فسفورية.',
      plan: 'تنظيم ورشة تدريب مصغرة لتمريض نوبة المساء والليل على التحرير السريع للأجهزة.',
      do: 'تم تركيب المشابك السريعة وتدريب 18 ممرضاً وممرضة ميدانياً.',
      check: 'إعادة اختبار سرعة النقل في الفرضية القادمة والتحقق من بقاء الزمن تحت 4 دقائق.',
      act: 'اعتماد شريط التحرير السريع ضمن قائمة فحص السلامة الدورية لأجهزة العناية المركزة.'
    },
    totalScore: 97,
    rating: 'ممتاز (Excellent)',
    safetyOfficerName: 'م/ نجيب غازي',
    safetyOfficerRole: 'رئيس قسم السلامة والصحة المهنية',
    safetyOfficerSigned: true,
    safetyOfficerSignedAt: '2026-06-18 11:30',
    medicalDirectorName: 'د/ محمد السراجي',
    medicalDirectorRole: 'مدير عام المستشفى ورئيس لجنة السلامة العليا',
    medicalDirectorSigned: true,
    medicalDirectorSignedAt: '2026-06-18 12:45',
    status: 'approved',
    createdAt: '2026-06-18T10:30:00Z',
    updatedAt: '2026-06-18T12:45:00Z'
  },
  {
    id: 'DRILL-2026-002',
    drillCode: 'FD-2026-02',
    policyCodes: ['FMS-PLAN-008EA', 'FMS-PLAN-0011EA'],
    title: 'فرضية إخلاء رأسي شامل - قسم رقود الجراحة (الدور الثالث)',
    scenario: 'تصاعد أدخنة كثيفة في مستودع المستلزمات الطبية والكتان بالدور الثالث مع انطلاق كاشف الدخان وتعذر الإخلاء الأفقي بسبب انتشار الدخان في الممر.',
    date: '2026-08-25',
    shift: 'morning',
    department: 'قسم رقود الجراحة والنساء',
    floor: 'الدور الثالث',
    evacuationType: 'vertical',
    assemblyPointLocation: 'نقطة التجمع الخارجية رقم (1) - الساحة الرئيسية أمام مدخل الطوارئ',
    codeRedAnnouncedAt: '11:15:00',
    fireTeamArrivedAt: '11:17:45',
    evacuationCompletedAt: '11:23:30',
    drillEndedAt: '11:35:00',
    calculatedEvacuationMinutes: 8.5,
    calculatedResponseMinutes: 2.75,
    totalParticipantsCount: 38,
    simulatedPatientsCount: 8,
    emptyRoomTagsVerified: true,
    emptyRoomTagsNotes: 'تم التحقق من تعليق علامات "خالية" وتأكد قادة المجموعات من خلو جميع دورات المياه والمكاتب.',
    raceAudit: {
      rescue: {
        status: 'compliant',
        score: 25,
        notes: 'استخدام كراسي الإخلاء الدرجية (Evac-Chairs) لنزول المرضى عبر الدرج الشرقي المانع للحريق.'
      },
      alarm: {
        status: 'compliant',
        score: 25,
        notes: 'الاستجابة لإنذار الحريق الآلي وتأكيده بالنداء الشفهي واللاسلكي لفريق الطوارئ.'
      },
      confine: {
        status: 'compliant',
        score: 23,
        notes: 'تم إغلاق الباب المقاوم للحريق للمستودع، ولوحظ ارتداد طفيف لباب الدرج استوجب إحكامه يدوياً.'
      },
      evacuate: {
        status: 'compliant',
        score: 22,
        notes: 'إخلاء 8 مرضى و 12 مرافقاً و 18 من الطاقم إلى نقطة التجمع الخارجية بانتظام وهدوء.'
      }
    },
    passAudit: {
      pull: true,
      aim: true,
      squeeze: true,
      sweep: true,
      usedExtinguisherType: 'بودرة كيميائية جافة ABC (6 كجم)',
      techniqueCompliant: true,
      notes: 'تمت تجربة طفاية بودرة بدقة مع اختبار ضغط الخرطوم والوقوف مع اتجاه الريح.'
    },
    focusPdca: {
      find: 'بطء بسيط في غلق أحد الأبواب المانعة للدخان بسبب ثقل زنبرك الإغلاق الهيدروليكي (Door Closer).',
      organize: 'مسؤول السلامة + فني الصيانة المعمارية.',
      clarify: 'مراجعة دورية ضبط مغاليق الأبواب الأوتوماتيكية في طوابق الرقود.',
      understand: 'تراكم الغبار على ذراع الغالق واحتياجه إلى تزييت وضبط سرعة الإغلاق.',
      select: 'صيانة فورية شاملة لكافة مغاليق أبواب الطوارئ بالدور الثالث.',
      plan: 'إدراج مغاليق أبواب الطوارئ في الجولة التفتيشية الأسبوعية بدلاً من الشهرية.',
      do: 'تم ضبط الغالق وتزييته واختبار إحكام الغلق تلقائياً 5 مرات متتالية بنجاح.',
      check: 'فحص الإغلاق التلقائي في جولة التفتيش القادمة مع قياس قوة الإحكام.',
      act: 'تثبيت الإجراء في جدول الصيانة الوقائية (PPM) لجميع أبواب مخارج الطوارئ.'
    },
    totalScore: 95,
    rating: 'ممتاز (Excellent)',
    safetyOfficerName: 'م/ نجيب غازي',
    safetyOfficerRole: 'رئيس قسم السلامة والصحة المهنية',
    safetyOfficerSigned: true,
    safetyOfficerSignedAt: '2026-08-25 12:30',
    medicalDirectorName: 'د/ محمد السراجي',
    medicalDirectorRole: 'مدير عام المستشفى ورئيس لجنة السلامة العليا',
    medicalDirectorSigned: true,
    medicalDirectorSignedAt: '2026-08-25 14:00',
    status: 'approved',
    createdAt: '2026-08-25T11:45:00Z',
    updatedAt: '2026-08-25T14:00:00Z'
  },
  {
    id: 'DRILL-2026-003',
    drillCode: 'FD-2026-03',
    policyCodes: ['FMS-PLAN-008EA', 'FMS-PLAN-0011EA'],
    title: 'فرضية انسكاب كيميائي وحريق محدود - قسم التعقيم المركزي (CSSD)',
    scenario: 'انسكاب مادة مطهرة كيميائية مع حدوث وميض كهربائي من جهاز التعقيم الحراري بالقبو، استدعى تفعيل كود أورانج وكود ريد في آن واحد.',
    date: '2026-09-08',
    shift: 'morning',
    department: 'قسم التعقيم المركزي (CSSD)',
    floor: 'الدور الأرضي / القبو الفني',
    evacuationType: 'horizontal',
    assemblyPointLocation: 'الممر الفني الخارجي المؤدي إلى ساحة الخدمات المفتوحة',
    codeRedAnnouncedAt: '09:20:10',
    fireTeamArrivedAt: '09:22:15',
    evacuationCompletedAt: '09:25:30',
    drillEndedAt: '09:40:00',
    calculatedEvacuationMinutes: 5.33,
    calculatedResponseMinutes: 2.08,
    totalParticipantsCount: 16,
    simulatedPatientsCount: 0,
    emptyRoomTagsVerified: true,
    emptyRoomTagsNotes: 'تم إخلاء منطقة التعقيم والغسيل وتعليق لوحة الغرفة خالية على الباب الفولاذي.',
    raceAudit: {
      rescue: {
        status: 'compliant',
        score: 25,
        notes: 'إبعاد العاملين فوراً وارتداء كمامات التنفس الكيميائية ذات الفلاتر العضوية.'
      },
      alarm: {
        status: 'compliant',
        score: 25,
        notes: 'ضغط كاسر الإنذار اليدوي وإشعار غرفة التحكم المركزية وسنترال المستشفى.'
      },
      confine: {
        status: 'compliant',
        score: 25,
        notes: 'فصل التيار الكهربائي عن جهاز التعقيم ونشر بودرة المحايدة لمنع الأبخرة.'
      },
      evacuate: {
        status: 'compliant',
        score: 23,
        notes: 'خروج جميع أفراد التعقيم إلى الساحة المفتوحة وحصر الحضور عبر كشف النوبة.'
      }
    },
    passAudit: {
      pull: true,
      aim: true,
      squeeze: true,
      sweep: true,
      usedExtinguisherType: 'ثاني أكسيد الكربون CO2 سعة 5 كجم',
      techniqueCompliant: true,
      notes: 'تمت محاكاة إخماد الوميض الكهربائي دون تلويث منطقة التعقيم المعقمة.'
    },
    focusPdca: {
      find: 'حاجة فني التعقيم الجديد إلى تجديد التوعية بنوع طفاية الحريق المناسبة للكهرباء.',
      organize: 'مسؤول السلامة ومسؤولة التعقيم المركزي.',
      clarify: 'التأكيد على عدم استخدام الماء أو الرغوة على المعدات الكهربائية والإلكترونية.',
      understand: 'الموظف انضم حديثاً ولم يستكمل بعد برنامج التهيئة العام للسلامة.',
      select: 'إلزام جميع الموظفين الجدد بحضور دورة الطفايات العملية قبل استلام المهام.',
      plan: 'إدراج فنيي التعقيم في تدريب عملي أسبوعي على الطفايات واستخدام MSDS.',
      do: 'تم إخضاع الفني لتدريب فوري مع تطبيق عملي مباشر على طفاية CO2.',
      check: 'اختبار الفني شفهياً وعملياً في جولة السلامة القادمة.',
      act: 'ربط تصريح مباشرة العمل في التعقيم ببطاقة اجتياز تدريب السلامة الميداني.'
    },
    totalScore: 98,
    rating: 'ممتاز (Excellent)',
    safetyOfficerName: 'م/ نجيب غازي',
    safetyOfficerRole: 'رئيس قسم السلامة والصحة المهنية',
    safetyOfficerSigned: true,
    safetyOfficerSignedAt: '2026-09-08 10:15',
    medicalDirectorName: 'د/ محمد السراجي',
    medicalDirectorRole: 'مدير عام المستشفى ورئيس لجنة السلامة العليا',
    medicalDirectorSigned: true,
    medicalDirectorSignedAt: '2026-09-08 11:30',
    status: 'approved',
    createdAt: '2026-09-08T09:45:00Z',
    updatedAt: '2026-09-08T11:30:00Z'
  }
];

/**
 * Generates an official Annual CBAHI Executive Summary based on actual database stats
 */
export function generateAnnualCbahieSummary(
  drillRecords: FireDrillRecord[] = INITIAL_FIRE_DRILL_RECORDS,
  totalIncidents: number = 42,
  resolvedIncidents: number = 39,
  criticalIncidents: number = 2
): AnnualCbahieExecutiveSummary {
  const drillsCount = drillRecords.length;
  const avgTime = drillsCount > 0
    ? Number((drillRecords.reduce((acc, d) => acc + d.calculatedEvacuationMinutes, 0) / drillsCount).toFixed(1))
    : 5.5;
  const avgScore = drillsCount > 0
    ? Math.round(drillRecords.reduce((acc, d) => acc + d.totalScore, 0) / drillsCount)
    : 96;

  const resolutionRate = totalIncidents > 0
    ? Math.round((resolvedIncidents / totalIncidents) * 100)
    : 93;

  return {
    reportYear: 2026,
    generatedDate: '2026-09-15',
    hospitalName: 'مستشفى أزال النموذجي - صنعاء',
    code: 'CBAHI-FMS-ANNUAL-2026',
    incidentsStats: {
      totalReported: totalIncidents,
      resolvedCount: resolvedIncidents,
      resolutionRate,
      criticalIncidents,
      averageClosureTimeHours: 3.8
    },
    criticalAreasAudit: {
      icuStatus: 'مطابق للمواصفات 100% - مسارات إخلاء سالكة وتثبيت الأسطوانات بالسلاسل',
      cssdStatus: 'مطابق 98% - صيانة دورية للمراجل وسريان معايرة صمامات الأمان',
      centralLabStatus: 'مطابق 99% - فحص دوش الطوارئ وغسيل العيون أسبوعياً وتوفر MSDS',
      medicalGasPlantStatus: 'مطابق 100% - ضغوط الأكسجين والنيتروز ضمن المعايير وحساسات التسريب معايرة',
      incineratorStatus: 'مطابق 97% - التخلص الآمن من الرماد الطبي وانبعاثات المداخن مفحوصة',
      overallCompliancePercentage: 98.8
    },
    engineeringLifeSafety: {
      backupGeneratorWeeklyRunRate: 98.5,
      generatorSimulatedLoadTestPassed: true,
      facpPanelInspectionsCount: 52,
      facpOperationalRate: 100,
      extinguishersAuditedCount: 78,
      extinguishersValidPercentage: 100
    },
    fireDrillsSummary: {
      totalDrillsExecuted: drillsCount,
      averageEvacuationTimeMinutes: avgTime,
      averageScore: avgScore,
      passedRoundsPercentage: 100,
      keyImprovementFocus: 'تطوير سرعة فك الوصلات الجدارية للأجهزة الطبية وتزويدها بأشرطة سحب فسفورية مع استمرار تدريب النوبات المسائية والليلية بموجب نموذج FOCUS-PDCA.'
    },
    signatures: {
      qualityCoordinator: {
        name: 'د/ علي الظبيبي',
        title: 'منسق الجودة والاعتماد',
        signed: true,
        date: '2026-09-15'
      },
      medicalDirector: {
        name: 'د/ أحمد الأهدل',
        title: 'المدير الطبي',
        signed: true,
        date: '2026-09-15'
      },
      safetyOfficer: {
        name: 'م/ نجيب غازي',
        title: 'رئيس لجنة السلامة وإدارة المرافق (FMS)',
        signed: true,
        date: '2026-09-15'
      },
      generalDirector: {
        name: 'د/ محمد السراجي',
        title: 'مدير عام المستشفى',
        signed: true,
        date: '2026-09-15'
      }
    }
  };
}
