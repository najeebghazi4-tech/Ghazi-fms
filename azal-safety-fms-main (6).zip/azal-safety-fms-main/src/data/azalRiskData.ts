import { 
  HospitalRiskItem, 
  RiskCategory, 
  RiskLikelihood, 
  RiskSeverity, 
  RiskLevel 
} from '../types';

export interface LikelihoodScaleInfo {
  score: RiskLikelihood;
  labelAr: string;
  labelEn: string;
  description: string;
  frequencyDesc: string;
}

export interface SeverityScaleInfo {
  score: RiskSeverity;
  labelAr: string;
  labelEn: string;
  description: string;
  impactDesc: string;
}

export const LIKELIHOOD_SCALES: LikelihoodScaleInfo[] = [
  {
    score: 1,
    labelAr: 'نادر جداً',
    labelEn: 'Rare',
    description: 'غير متوقع الحدوث إلا في ظروف وظواهر استثنائية وقاهرة.',
    frequencyDesc: 'احتمال حدوث أقل من مرة كل 5 سنوات'
  },
  {
    score: 2,
    labelAr: 'غير محتمل',
    labelEn: 'Unlikely',
    description: 'قد يحدث في بعض الحالات النادرة أو المنعزلة.',
    frequencyDesc: 'احتمال حدوث مرة كل سنتين إلى 5 سنوات'
  },
  {
    score: 3,
    labelAr: 'محتمل',
    labelEn: 'Possible',
    description: 'قد يحدث في أوقات متفرقة خلال العام التشغيلي.',
    frequencyDesc: 'احتمال حدوث مرة إلى مرتين في السنة'
  },
  {
    score: 4,
    labelAr: 'مرجح / متوقع',
    labelEn: 'Likely',
    description: 'يتكرر حدوثه بانتظام ما لم يتم اتخاذ تدابير استباقية صارمة.',
    frequencyDesc: 'احتمال حدوث شهرياً أو فصلياً (عدة مرات في السنة)'
  },
  {
    score: 5,
    labelAr: 'متكرر جداً / شبه مؤكد',
    labelEn: 'Almost Certain',
    description: 'يحدث بشكل مستمر وموثق أو شبه يومي/أسبوعي دون تدخل.',
    frequencyDesc: 'احتمال حدوث أسبوعي أو يومي مستمر'
  }
];

export const SEVERITY_SCALES: SeverityScaleInfo[] = [
  {
    score: 1,
    labelAr: 'تافه / لا يذكر',
    labelEn: 'Insignificant',
    description: 'لا توجد إصابات أو خسائر، توقف تشغيلي لا يتجاوز دقائق.',
    impactDesc: 'أثر مالي ومادي معدوم، لا تأثير على رعاية المرضى'
  },
  {
    score: 2,
    labelAr: 'طفيف / بسيط',
    labelEn: 'Minor',
    description: 'إسعافات أولية موقعية بسيطة، توقف خدمات غير حرجة لأقل من ساعة.',
    impactDesc: 'خسارة مادية طفيفة، شكوى غير رسمية'
  },
  {
    score: 3,
    labelAr: 'متوسط',
    labelEn: 'Moderate',
    description: 'إصابة تتطلب علاجاً طبياً أو إجازة مرضية، توقف مؤقت لخدمة مساندة.',
    impactDesc: 'تأخير في إجراءات علاجية، تكلفة إصلاح متوسطة'
  },
  {
    score: 4,
    labelAr: 'كبير / حرج',
    labelEn: 'Major',
    description: 'إصابة بليغة / حروق / عجز مؤقت، توقف قسم حيوي (طوارئ/عمليات/عناية).',
    impactDesc: 'خسارة مالية كبيرة، مخالفة تنظيمية حرجة لمعايير الجودة وسباهي'
  },
  {
    score: 5,
    labelAr: 'كارثي',
    labelEn: 'Catastrophic',
    description: 'حالة وفاة، عجز دائم، حريق عام، انهيار كامل للبنية التحتية وإخلاء.',
    impactDesc: 'توقف المستشفى كلياً، مساءلة قانونية وخسائر فادحة'
  }
];

export const RISK_CATEGORIES: { id: RiskCategory; nameAr: string; icon: string; description: string }[] = [
  {
    id: 'facilities',
    nameAr: 'المرافق الهندسية والتشغيل (USM)',
    icon: 'Building2',
    description: 'الكهرباء، مولدات الطوارئ، محطات المياه، التكييف، والصرف الصحي'
  },
  {
    id: 'fire_safety',
    nameAr: 'مكافحة الحريق والسلامة العامة (FMS)',
    icon: 'Flame',
    description: 'أنظمة الإنذار والإطفاء، مخارج الطوارئ، ومضخات الحريق'
  },
  {
    id: 'medical_equipment',
    nameAr: 'الأجهزة والمعدات الطبية (MEM)',
    icon: 'Activity',
    description: 'أجهزة العناية المركزة، الصدمات، التخدير، وحاضنات الأطفال'
  },
  {
    id: 'hazardous_materials',
    nameAr: 'المواد الخطرة والنفايات (HAZMAT)',
    icon: 'Biohazard',
    description: 'المواد الكيميائية، الغازات الطبية، النفايات المشعة والمعدية'
  },
  {
    id: 'security',
    nameAr: 'الأمن وحراسات السلامة (SEC)',
    icon: 'ShieldCheck',
    description: 'كاميرات المراقبة، التحكم بالأبواب، مكافحة العنف والاختطاف'
  },
  {
    id: 'clinical_safety',
    nameAr: 'سلامة المرضى والبيئة السريرية',
    icon: 'HeartPulse',
    description: 'السقوط، العدوى المكتسبة، غرف العزل بالضغط السالب'
  }
];

export function calculateRiskScore(likelihood: number, severity: number): number {
  const l = Math.min(Math.max(Number(likelihood) || 1, 1), 5);
  const s = Math.min(Math.max(Number(severity) || 1, 1), 5);
  return l * s;
}

export function getRiskLevel(score: number): {
  level: RiskLevel;
  labelAr: string;
  labelEn: string;
  colorBg: string;
  colorText: string;
  colorBorder: string;
  badgeClass: string;
  descriptionAr: string;
} {
  if (score >= 20) {
    return {
      level: 'critical',
      labelAr: 'حرج / شديد الخطورة',
      labelEn: 'Extreme / Critical Risk',
      colorBg: 'bg-rose-950/80',
      colorText: 'text-rose-300',
      colorBorder: 'border-rose-600',
      badgeClass: 'bg-rose-600 text-white border-rose-500 shadow-rose-900/50',
      descriptionAr: 'يتطلب إجراءات وقائية وتصحيحية فورية وإيقاف النشاط وإخطار الإدارة العليا'
    };
  } else if (score >= 10) {
    return {
      level: 'high',
      labelAr: 'عالي الخطورة',
      labelEn: 'High Risk',
      colorBg: 'bg-amber-950/80',
      colorText: 'text-amber-300',
      colorBorder: 'border-amber-600',
      badgeClass: 'bg-amber-600 text-white border-amber-500 shadow-amber-900/50',
      descriptionAr: 'يتطلب خطة عمل تنفيذية عاجلة وتدخل إداري خلال 24-48 ساعة'
    };
  } else if (score >= 5) {
    return {
      level: 'moderate',
      labelAr: 'متوسط الخطورة',
      labelEn: 'Moderate Risk',
      colorBg: 'bg-yellow-950/70',
      colorText: 'text-yellow-300',
      colorBorder: 'border-yellow-600',
      badgeClass: 'bg-yellow-500 text-slate-950 font-black border-yellow-400',
      descriptionAr: 'تتم السيطرة عبر الإجراءات التشغيلية القياسية والمتابعة الدورية'
    };
  } else {
    return {
      level: 'low',
      labelAr: 'منخفض الخطورة',
      labelEn: 'Low Risk',
      colorBg: 'bg-emerald-950/70',
      colorText: 'text-emerald-300',
      colorBorder: 'border-emerald-600',
      badgeClass: 'bg-emerald-600 text-white border-emerald-500',
      descriptionAr: 'مقبول ضمن الحدود التشغيلية المعتادة مع الاستمرار في الفحص الوقائي'
    };
  }
}

export function getMatrixCellBg(score: number): string {
  if (score >= 20) return 'bg-rose-600 hover:bg-rose-500 text-white';
  if (score >= 10) return 'bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold';
  if (score >= 5) return 'bg-yellow-400 hover:bg-yellow-300 text-slate-950 font-bold';
  return 'bg-emerald-600 hover:bg-emerald-500 text-white font-bold';
}

// Pre-seeded accredited Hospital Risk Register for Azal Hospital
export const DEFAULT_HOSPITAL_RISKS: HospitalRiskItem[] = [
  {
    id: 'RSK-AZAL-001',
    risk_code: 'RSK-2026-001',
    department: 'قسم العمليات والعناية المركزة ICU',
    category: 'facilities',
    category_name_ar: 'المرافق الهندسية والتشغيل (USM)',
    title: 'انقطاع التيار الكهربائي الرئيسي وتأخر تحويل لوحة ATS للمولدات الاحتياطية',
    hazard_description: 'توقف مفاجئ لخط التغذية الكهربائية الحكومي الرئيسي مع احتمال تعثر التحويل التلقائي للوحة ATS إلى مولدات الطوارئ خلال 10 ثوانٍ المحددة بمعايير CBAHI FMS.31.',
    consequences: 'توقف أجهزة التنفس الصناعي وحواضن الأطفال ومضخات المحاليل، مما يشكل خطراً مباشراً على حياة المرضى الحرجين.',
    initial_likelihood: 4,
    initial_severity: 5,
    initial_risk_score: 20,
    initial_risk_level: 'critical',
    current_controls: 'فحص أسبوعي للمولدات ومستوى الديزل، بطاريات UPS داخلية بكل جهاز طبي تعمل لمدة 30-60 دقيقة، لوحة ATS مزدوجة.',
    action_plan: 'تثبيت نظام UPS مركزي بقوة 120kVA لأجنحة العناية المركزة والعمليات، وإجراء فحص حمل أسبوعي حقيقي للـ ATS وتوثيقه في سجل سباهي.',
    responsible_person: 'م/ نجيب غازي (مدير السلامة والمرافق)',
    responsible_dept: 'قسم الصيانة العامة والكهرباء',
    target_date: '2026-10-15',
    completion_percentage: 85,
    residual_likelihood: 2,
    residual_severity: 3,
    residual_risk_score: 6,
    residual_risk_level: 'moderate',
    status: 'in_progress',
    last_review_date: '2026-09-18',
    reviewed_by: 'لجنة السلامة وإدارة المخاطر',
    created_at: '2026-08-10T08:00:00Z',
    updated_at: '2026-09-18T11:30:00Z'
  },
  {
    id: 'RSK-AZAL-002',
    risk_code: 'RSK-2026-002',
    department: 'محطة الغازات الطبية المركزية',
    category: 'hazardous_materials',
    category_name_ar: 'المواد الخطرة والنفايات (HAZMAT)',
    title: 'انخفاض ضغط شبكة الأكسجين الطبي المركزي في الطوابق العليا',
    hazard_description: 'احتمال حدوث تسريب في شبكة خطوط الأنابيب النحاسية للأكسجين أو خلل في صمامات تخفيض الضغط الرئيسية بمحطة المانيفولد مما يسبب هبوط الضغط عن 4.0 Bar.',
    consequences: 'انقطاع تدفق الأكسجين عن مرضى العناية والطوارئ وحدوث إنذار كود أحمر طبي.',
    initial_likelihood: 3,
    initial_severity: 5,
    initial_risk_score: 15,
    initial_risk_level: 'high',
    current_controls: 'نظام مانيفولد أوتوماتيكي مع خط احتياطي طوارئ (Secondary Supply)، وصافرات إنذار صوتية ومرئية في محطة التمريض.',
    action_plan: 'استبدال حساسات الضغط الرقمية وتوصيلها بنظام المراقبة SCADA مع عقد صيانة وقائية شهرية معتمدة من الشركة الموردة.',
    responsible_person: 'م. فني الغازات الطبية / م. نجيب غازي',
    responsible_dept: 'قسم شبكة الغازات الطبية',
    target_date: '2026-10-01',
    completion_percentage: 90,
    residual_likelihood: 1,
    residual_severity: 4,
    residual_risk_score: 4,
    residual_risk_level: 'low',
    status: 'in_progress',
    last_review_date: '2026-09-15',
    reviewed_by: 'د. السراجي / م. نجيب غازي',
    created_at: '2026-08-15T09:00:00Z',
    updated_at: '2026-09-15T14:20:00Z'
  },
  {
    id: 'RSK-AZAL-003',
    risk_code: 'RSK-2026-003',
    department: 'غرف العزل الطبي (Isolation Rooms)',
    category: 'clinical_safety',
    category_name_ar: 'سلامة المرضى والبيئة السريرية',
    title: 'فقدان تدرج الضغط السالب في غرف العزل التنفسي للأمراض المعدية',
    hazard_description: 'احتمال انسداد فلاتر HEPA أو خلل في مروحة السحب (Exhaust Fan) يؤدي لتحول الضغط إلى موجب وتسرب الهواء الملوث لممرات المستشفى.',
    consequences: 'انتشار العدوى المنقولة بالهواء بين الكوادر الطبية والمراجعين ومرضى الأقسام المجاورة.',
    initial_likelihood: 3,
    initial_severity: 4,
    initial_risk_score: 12,
    initial_risk_level: 'high',
    current_controls: 'مقياس ضغط تفاضلي Magnehelic على باب كل غرفة، وجدول فحص دخاني Smoke Test شهري.',
    action_plan: 'استبدال فلاتر HEPA الدورية كل 6 أشهر، وتفعيل بوابة التحقق الرقمي عبر الباركود يومياً قبل دخول التمريض.',
    responsible_person: 'فريق مكافحة العدوى / قسم التكييف USM',
    responsible_dept: 'مكافحة العدوى والسلامة',
    target_date: '2026-09-30',
    completion_percentage: 100,
    residual_likelihood: 1,
    residual_severity: 2,
    residual_risk_score: 2,
    residual_risk_level: 'low',
    status: 'controlled',
    last_review_date: '2026-09-20',
    reviewed_by: 'منسق الجودة والاعتماد',
    created_at: '2026-08-01T10:00:00Z',
    updated_at: '2026-09-20T16:00:00Z'
  },
  {
    id: 'RSK-AZAL-004',
    risk_code: 'RSK-2026-004',
    department: 'المختبر المركزي وبنك الدم',
    category: 'hazardous_materials',
    category_name_ar: 'المواد الخطرة والنفايات (HAZMAT)',
    title: 'انسكاب مواد كيميائية حارقة أو عينات بيولوجية شديدة الخطورة',
    hazard_description: 'احتمال سقوط أو كسر عبوات الفورمالين أو الأحماض المركزة أثناء التحضير دون ارتداء كامل معدات الوقاية PPE.',
    consequences: 'إصابات كيميائية للجلد والعينين، وتلوث البيئة الداخلية للمختبر.',
    initial_likelihood: 3,
    initial_severity: 3,
    initial_risk_score: 9,
    initial_risk_level: 'moderate',
    current_controls: 'توفر أطقم معالجة الانسكابات Chemical Spill Kit، ودش الطوارئ ومغسلة العيون، وكتيبات MSDS.',
    action_plan: 'تدريب عملي شهري لكافة فنيي المختبر على استخدام Spill Kit وتحديث شهادات الـ MSDS وإعادة فحص دش الطوارئ أسبوعياً.',
    responsible_person: 'د. رئيس المختبر / مسؤول السلامة الكيميائية',
    responsible_dept: 'المختبر والسلامة العامة',
    target_date: '2026-10-10',
    completion_percentage: 75,
    residual_likelihood: 1,
    residual_severity: 3,
    residual_risk_score: 3,
    residual_risk_level: 'low',
    status: 'in_progress',
    last_review_date: '2026-09-10',
    reviewed_by: 'لجنة السلامة',
    created_at: '2026-08-20T11:00:00Z',
    updated_at: '2026-09-10T12:00:00Z'
  },
  {
    id: 'RSK-AZAL-005',
    risk_code: 'RSK-2026-005',
    department: 'طوارئ المستشفى والمداخل الرئيسية',
    category: 'security',
    category_name_ar: 'الأمن وحراسات السلامة (SEC)',
    title: 'اعتداء لفظي أو جسدي على الكادر الطبي ومحاولة اقتحام مناطق الفرز',
    hazard_description: 'تزاحم أهالي ومرافقي المرضى في حالات الحوادث الكبرى وإمكانية حدوث شجار أو تخريب ممتلكات.',
    consequences: 'إصابة الكوادر الطبية والتمريضية، تعطيل تقديم الإسعافات العاجلة للمصابين، وتلف الأجهزة.',
    initial_likelihood: 4,
    initial_severity: 3,
    initial_risk_score: 12,
    initial_risk_level: 'high',
    current_controls: 'تواجد حراس أمن على مدار الساعة، كاميرات مراقبة CCTV، وأزرار إنذار صامت Panic Buttons.',
    action_plan: 'تركيب أبواب دخول ذكية بالبطاقات الممغنطة (Access Control) لقسم الطوارئ الداخلي، وتفعيل الربط المباشر مع النجدة وتدريب الحراس على نزع فتيل النزاعات.',
    responsible_person: 'مشرف الأمن والسلامة / رئيس قسم الطوارئ',
    responsible_dept: 'إدارة الأمن والسلامة',
    target_date: '2026-10-25',
    completion_percentage: 70,
    residual_likelihood: 2,
    residual_severity: 2,
    residual_risk_score: 4,
    residual_risk_level: 'low',
    status: 'in_progress',
    last_review_date: '2026-09-12',
    reviewed_by: 'م. نجيب غازي',
    created_at: '2026-08-05T08:00:00Z',
    updated_at: '2026-09-12T10:00:00Z'
  },
  {
    id: 'RSK-AZAL-006',
    risk_code: 'RSK-2026-006',
    department: 'كافة أدوار ومباني المستشفى',
    category: 'fire_safety',
    category_name_ar: 'مكافحة الحريق والسلامة العامة (FMS)',
    title: 'نشوب حريق في لوحات التوزيع الكهربائية أو مطبخ المستشفى',
    hazard_description: 'احتمال زيادة الحمل الكهربائي في اللوحات الفرعية أو اشتعال زيوت الطهي في مدخنة المطبخ المركزي.',
    consequences: 'تصاعد الدخان، تهديد سلامة المرضى، وإخلاء المبنى كلياً أو جزئياً.',
    initial_likelihood: 3,
    initial_severity: 5,
    initial_risk_score: 15,
    initial_risk_level: 'high',
    current_controls: 'شبكة كواشف دخان وحرارة مربوطة باللوحة الرئيسية، طفايات حريق بودرة وCO2 ونظام FM200 بغرفة السيرفرات ونظام رطب Wet Chemical بالمطبخ.',
    action_plan: 'إجراء تجارب إخلاء وهمية فصلية (Fire Drill) لجميع النوبات، وفحص حراري دوري بالأشعة تحت الحمراء (Thermal Imaging) للوحات الكهرباء الرئيسية.',
    responsible_person: 'م/ نجيب غازي (مسؤول FMS)',
    responsible_dept: 'قسم السلامة ومكافحة الحريق',
    target_date: '2026-11-01',
    completion_percentage: 80,
    residual_likelihood: 1,
    residual_severity: 3,
    residual_risk_score: 3,
    residual_risk_level: 'low',
    status: 'in_progress',
    last_review_date: '2026-09-14',
    reviewed_by: 'لجنة السلامة والجودة',
    created_at: '2026-08-12T07:30:00Z',
    updated_at: '2026-09-14T09:15:00Z'
  }
];
