import { MedicalRecallNotice } from '../types';

export const INITIAL_MEDICAL_RECALLS: MedicalRecallNotice[] = [
  {
    id: 'SMDA-AZAL-2026-001',
    source: 'تعميم الهيئة العليا للأدوية والمستلزمات الطبية (SFDA Recall #26/104)',
    deviceName: 'مضخة تسريب وريدي ذكية (Smart Infusion Pump)',
    modelNumber: 'Alaris Infusion System Plus v3',
    manufacturer: 'CareFusion / BD Medical',
    serialNumber: 'SN-BD-994182',
    lotBatchNumber: 'LOT-2025-X09',
    assetTag: 'AZAL-MED-042',
    department: 'قسم العناية المركزة (ICU)',
    hazardClass: 'class_1',
    defectDescription: 'خلل برمجي يؤدي إلى خطأ في احتساب معدل الجرعات الفائقة (Over-infusion risk) وتوقف التنبيه الصوتي.',
    actionTaken: 'سحب فوري للجهاز من سرير ICU-04، فصل كابل الطاقة وتثبيت ملصق العزل الأحمر، والإيداع بمستودع التحريز الطبي.',
    quarantinedLocation: 'قفص العزل والتحريز الطبي - مستودع الهندسة الطبية (الدور الأرضي)',
    quarantinedBy: 'م/ عمار اليافعي (مهندس المعدات الطبية)',
    quarantineDate: new Date(Date.now() - 1000 * 60 * 60 * 48).toISOString().split('T')[0],
    status: 'quarantined',
    stickerPrinted: true,
    notes: 'تم إشعار رئيس التمريض وإدارة الجودة وتزويد القسم بجهاز بديل معاير.',
    createdAt: Date.now() - 1000 * 60 * 60 * 48,
    synced: true
  },
  {
    id: 'SMDA-AZAL-2026-002',
    source: 'بلاغ تحريز داخلي إثر عطل سريري (Internal SMDA Clinical Incident)',
    deviceName: 'جهاز صدمات القلب ومزيل الرجفان (Defibrillator & Monitor)',
    modelNumber: 'HeartStart XL+ Bi-Phasic',
    manufacturer: 'Philips Healthcare',
    serialNumber: 'SN-PH-88310',
    lotBatchNumber: 'N/A',
    assetTag: 'AZAL-MED-108',
    department: 'طوارئ المستشفى (ER Resuscitation)',
    hazardClass: 'smda_clinical_incident',
    defectDescription: 'رسالة خطأ عند التفريغ على 200 جول وعدم اكتمال شحن المكثف الداخلي أثناء محاولة إنعاش.',
    actionTaken: 'تحريز فوري ومصادرة الجهاز بعد الحادثة مباشرة، وتثبيت ملصق العزل الأحمر وتأمين جهاز بديل فوري.',
    quarantinedLocation: 'مستودع التحريز الطبي المحكم',
    quarantinedBy: 'م/ نجيب غازي وم/ عمار اليافعي',
    quarantineDate: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString().split('T')[0],
    status: 'under_investigation',
    stickerPrinted: true,
    notes: 'قيد الفحص الفني الداخلي والتواصل مع الوكيل المعتمد في صنعاء لإجراء المعايرة واستبدال المكثف.',
    createdAt: Date.now() - 1000 * 60 * 60 * 24,
    synced: true
  }
];
