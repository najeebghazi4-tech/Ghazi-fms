import { NegativePressureLog } from '../types';

export const INITIAL_NEGATIVE_PRESSURE_ROOMS = [
  {
    roomCode: 'AIIR-ICU-01',
    roomName: 'غرفة عزل العناية المركزة الجوي (1) - Airborne Isolation Room',
    department: 'العناية المركزة (ICU)',
    floor: 'الدور الثاني',
    targetPressure: '<= -2.5 Pa',
    minAch: 12
  },
  {
    roomCode: 'AIIR-ICU-02',
    roomName: 'غرفة عزل العناية المركزة الجوي (2)',
    department: 'العناية المركزة (ICU)',
    floor: 'الدور الثاني',
    targetPressure: '<= -2.5 Pa',
    minAch: 12
  },
  {
    roomCode: 'AIIR-ER-01',
    roomName: 'غرفة العزل السريع بطوارئ المستشفى',
    department: 'طوارئ المستشفى (ER)',
    floor: 'الدور الأرضي',
    targetPressure: '<= -2.5 Pa',
    minAch: 12
  },
  {
    roomCode: 'ENDO-SUITE-01',
    roomName: 'وحدة غسيل ومعالجة مناظير الجهاز الهضمي والتنفسي',
    department: 'قسم المناظير التخصصية',
    floor: 'الدور الأول',
    targetPressure: '<= -2.5 Pa',
    minAch: 10
  },
  {
    roomCode: 'TB-LAB-01',
    roomName: 'مختبر الدرن وعصيات السل (BSL-3 Negative Suite)',
    department: 'المختبر المركزي وبنك الدم',
    floor: 'الدور الأرضي',
    targetPressure: '<= -5.0 Pa',
    minAch: 15
  },
  {
    roomCode: 'AIIR-MED-01',
    roomName: 'غرفة عزل قسم رقود الباطنية',
    department: 'جناح الرقود - الدور الثالث',
    floor: 'الدور الثالث',
    targetPressure: '<= -2.5 Pa',
    minAch: 12
  }
];

export const INITIAL_NEGATIVE_PRESSURE_LOGS: NegativePressureLog[] = [
  {
    id: 'npl-2026-001',
    roomCode: 'AIIR-ICU-01',
    roomName: 'غرفة عزل العناية المركزة الجوي (1) - Airborne Isolation Room',
    department: 'العناية المركزة (ICU)',
    floor: 'الدور الثاني',
    inspectionDate: new Date().toISOString().split('T')[0],
    inspectionTime: '08:30',
    pressureValuePa: -6.4,
    pressureUnit: 'Pa',
    gaugeReadingStatus: 'normal_negative',
    smokeTestResult: 'pass_inward',
    doorSweepSealIntact: true,
    anteroomDoorClosed: true,
    exhaustFanOperational: true,
    hepaFilterDifferentialOk: true,
    airChangesPerHour: 14.2,
    overallStatus: 'compliant',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم السلامة وإدارة المرافق FMS',
    inspectorBadgeNumber: 'AZAL-FMS-01',
    correctiveAction: 'الضغط السلبي مستقر وتدفق شريط الدخان للداخل بانسيابية كاملة.',
    createdAt: Date.now() - 1000 * 60 * 60 * 5,
    synced: true
  },
  {
    id: 'npl-2026-002',
    roomCode: 'TB-LAB-01',
    roomName: 'مختبر الدرن وعصيات السل (BSL-3 Negative Suite)',
    department: 'المختبر المركزي وبنك الدم',
    floor: 'الدور الأرضي',
    inspectionDate: new Date().toISOString().split('T')[0],
    inspectionTime: '09:15',
    pressureValuePa: -8.1,
    pressureUnit: 'Pa',
    gaugeReadingStatus: 'normal_negative',
    smokeTestResult: 'pass_inward',
    doorSweepSealIntact: true,
    anteroomDoorClosed: true,
    exhaustFanOperational: true,
    hepaFilterDifferentialOk: true,
    airChangesPerHour: 16.0,
    overallStatus: 'compliant',
    inspectorName: 'م/ نجيب غازي',
    inspectorRole: 'رئيس قسم السلامة وإدارة المرافق FMS',
    inspectorBadgeNumber: 'AZAL-FMS-01',
    correctiveAction: 'مطابق لمعايير سباهي BSL-3 وسحب الهواء العادم عبر كابينة الأمان الحيوي ومروحة الطرد الخارجية.',
    createdAt: Date.now() - 1000 * 60 * 60 * 4,
    synced: true
  },
  {
    id: 'npl-2026-003',
    roomCode: 'ENDO-SUITE-01',
    roomName: 'وحدة غسيل ومعالجة مناظير الجهاز الهضمي والتنفسي',
    department: 'قسم المناظير التخصصية',
    floor: 'الدور الأول',
    inspectionDate: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString().split('T')[0],
    inspectionTime: '11:00',
    pressureValuePa: -3.8,
    pressureUnit: 'Pa',
    gaugeReadingStatus: 'normal_negative',
    smokeTestResult: 'pass_inward',
    doorSweepSealIntact: true,
    anteroomDoorClosed: true,
    exhaustFanOperational: true,
    hepaFilterDifferentialOk: true,
    airChangesPerHour: 11.5,
    overallStatus: 'compliant',
    inspectorName: 'أ/ وفاء الشرعبي',
    inspectorRole: 'مشرفة مكافحة العدوى IPC',
    inspectorBadgeNumber: 'AZAL-IPC-03',
    correctiveAction: 'تم فحص مسار طرد أبخرة الجلوترالدهيد والتعقيم الكيميائي، التدفق سليم للداخل.',
    createdAt: Date.now() - 1000 * 60 * 60 * 26,
    synced: true
  }
];
