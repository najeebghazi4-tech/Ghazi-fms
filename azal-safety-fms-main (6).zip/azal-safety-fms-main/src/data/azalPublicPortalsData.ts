import { 
  ContractorPermitNotice, 
  IncineratorOperationNotice, 
  NewHiresTrainingNotice, 
  TrainingNominationNotice 
} from '../types';

export const INITIAL_CONTRACTOR_PERMITS: ContractorPermitNotice[] = [];

export const INITIAL_INCINERATOR_NOTICES: IncineratorOperationNotice[] = [];

export const INITIAL_NEW_HIRES_NOTICES: NewHiresTrainingNotice[] = [];

export const INITIAL_TRAINING_NOMINATIONS: TrainingNominationNotice[] = [];

