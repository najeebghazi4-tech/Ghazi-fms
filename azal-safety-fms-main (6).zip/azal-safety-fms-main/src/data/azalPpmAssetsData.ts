export interface PpmChecklistStep {
  id: number;
  step_text: string;
  expected_value?: string;
}

export type PpmDepartmentCategory = 
  | 'general_facilities' 
  | 'biomedical' 
  | 'it_networks' 
  | 'medical_gases' 
  | 'cctv_security' 
  | 'contractor_assets';

export interface PpmAsset {
  id: string;
  asset_tag: string;
  name: string;
  nameEn?: string;
  category: PpmDepartmentCategory;
  categoryNameAr: string;
  location: string;
  frequency: 'يومي' | 'أسبوعي' | 'شهري' | 'كل 3 أشهر' | 'كل 6 أشهر' | 'سنوي' | 'موسمي';
  frequencyDays: number;
  last_pm_date: string;
  next_pm_due: string;
  responsible_role: string;
  model?: string;
  serial_number?: string;
  total_units?: number | string;
  notes?: string;
  checklist_steps: PpmChecklistStep[];
}

export const PPM_DEPARTMENTS: {
  id: PpmDepartmentCategory;
  nameAr: string;
  nameEn: string;
  iconName: string;
  color: string;
  badgeBg: string;
  badgeText: string;
}[] = [
  {
    id: 'general_facilities',
    nameAr: 'قسم الصيانة العامة وخدمات المنافع',
    nameEn: 'General & Facilities',
    iconName: 'Building2',
    color: '#0284c7',
    badgeBg: 'bg-sky-50 dark:bg-sky-950/40 border-sky-200 dark:border-sky-800',
    badgeText: 'text-sky-700 dark:text-sky-300'
  },
  {
    id: 'biomedical',
    nameAr: 'الصيانة الطبية',
    nameEn: 'Biomedical Engineering',
    iconName: 'Activity',
    color: '#16a34a',
    badgeBg: 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800',
    badgeText: 'text-emerald-700 dark:text-emerald-300'
  },
  {
    id: 'it_networks',
    nameAr: 'صيانة الـ IT والشبكات',
    nameEn: 'IT & Networks',
    iconName: 'Cpu',
    color: '#8b5cf6',
    badgeBg: 'bg-purple-50 dark:bg-purple-950/40 border-purple-200 dark:border-purple-800',
    badgeText: 'text-purple-700 dark:text-purple-300'
  },
  {
    id: 'medical_gases',
    nameAr: 'شبكة الأكسجين والغازات الطبية',
    nameEn: 'Medical Gases & Oxygen',
    iconName: 'Wind',
    color: '#0d9488',
    badgeBg: 'bg-teal-50 dark:bg-teal-950/40 border-teal-200 dark:border-teal-800',
    badgeText: 'text-teal-700 dark:text-teal-300'
  },
  {
    id: 'cctv_security',
    nameAr: 'كاميرات المراقبة والأنظمة الأمنية',
    nameEn: 'CCTV & Security Systems',
    iconName: 'ShieldAlert',
    color: '#ea580c',
    badgeBg: 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800',
    badgeText: 'text-amber-700 dark:text-amber-300'
  },
  {
    id: 'contractor_assets',
    nameAr: 'أجهزة ومعدات الشركات',
    nameEn: 'Contractor Medical Assets',
    iconName: 'Briefcase',
    color: '#d97706',
    badgeBg: 'bg-orange-50 dark:bg-orange-950/40 border-orange-200 dark:border-orange-800',
    badgeText: 'text-orange-700 dark:text-orange-300'
  }
];

export const MASTER_PPM_ASSETS: PpmAsset[] = [
  // ==========================================
  // 1. قسم الصيانة العامة وخدمات المنافع (General & Facilities)
  // ==========================================
  {
    id: 'ppm-gen-01',
    asset_tag: 'AZ-GEN-01',
    name: 'المولدات الكهربائية الكبرى ولوحات التحويل ATS',
    nameEn: 'Emergency Generators & ATS Panels',
    category: 'general_facilities',
    categoryNameAr: 'قسم الصيانة العامة وخدمات المنافع',
    location: 'محطة التوليد المركزية - الفناء الخلفي',
    frequency: 'أسبوعي',
    frequencyDays: 7,
    last_pm_date: '2026-09-14',
    next_pm_due: '2026-09-21', // Due today!
    responsible_role: 'فني ميكانيك وكهرباء منشآت',
    model: 'Cummins QSK60-G4 / 1500 kVA',
    serial_number: 'CUM-2024-8841',
    total_units: '2 مولدات كبار',
    notes: 'فحص أسبوعي إلزامي تحت الحمل وعمرة فلترة مسبقة',
    checklist_steps: [
      { id: 1, step_text: 'فحص مستوى الوقود (الديزل) في الخزان الرئيسي واليومي', expected_value: 'أعلى من 80%' },
      { id: 2, step_text: 'فحص مستوى وضغط زيت المحرك ومستوى سائل التبريد (الرديتر)', expected_value: 'طبيعي ومطابق' },
      { id: 3, step_text: 'فحص جهد البطاريات ونظام الشحن التلقائي (Dynamo)', expected_value: '24V - 27V' },
      { id: 4, step_text: 'التحقق من عدم وجود تسريبات (وقود، زيت، ماء)', expected_value: 'سليم 100%' },
      { id: 5, step_text: 'اختبار لوحة التحويل الأوتوماتيكية ATS وزمن الاستجابة', expected_value: 'أقل من 10 ثوانٍ' }
    ]
  },
  {
    id: 'ppm-ups-01',
    asset_tag: 'AZ-UPS-01',
    name: 'بنوك بطاريات الـ UPS المركزية',
    nameEn: 'Central UPS Battery Banks',
    category: 'general_facilities',
    categoryNameAr: 'قسم الصيانة العامة وخدمات المنافع',
    location: 'غرفة الطاقة المركزية - الدور الأرضي',
    frequency: 'شهري',
    frequencyDays: 30,
    last_pm_date: '2026-08-20',
    next_pm_due: '2026-09-19', // Overdue by 2 days!
    responsible_role: 'فني كهرباء منشآت',
    model: 'Schneider Galaxy 300 80kVA',
    serial_number: 'UPS-SCH-9021',
    total_units: '3 بنوك بطاريات',
    notes: 'تأمين الطاقة المستمرة لغرف العمليات والعنايات المركزة',
    checklist_steps: [
      { id: 1, step_text: 'فحص درجة حرارة الغرفة وضبطها', expected_value: 'بين 20°C - 22°C' },
      { id: 2, step_text: 'التحقق من عدم وجود انتفاخ أو تسريب سائل في أي بطارية', expected_value: 'خالية تماماً من التشوه' },
      { id: 3, step_text: 'مراقبة شاشة التحكم وقراءة الحمل الحالي وجهد الشحن', expected_value: 'مستقر ومتوازن' },
      { id: 4, step_text: 'فحص سلامة توصيلات الكابلات ونظافة أقطاب البطاريات', expected_value: 'مشدودة وخالية من الأكسدة' },
      { id: 5, step_text: 'التحقق من عدم وجود إنذارات أو تنبيهات على اللوحة الرئيسية', expected_value: 'خالية من الإنذارات' }
    ]
  },
  {
    id: 'ppm-sub-01',
    asset_tag: 'AZ-SUB-01',
    name: 'المحولات والقواطع واللوحات الكهربائية الكبرى',
    nameEn: 'Main Electrical Transformers & Switchboards',
    category: 'general_facilities',
    categoryNameAr: 'قسم الصيانة العامة وخدمات المنافع',
    location: 'محطة التحويل والتوزيع الرئيسية',
    frequency: 'كل 6 أشهر',
    frequencyDays: 180,
    last_pm_date: '2026-06-10',
    next_pm_due: '2026-12-10', // Compliant
    responsible_role: 'مهندس كهرباء مستشفيات',
    model: 'ABB UniGear ZS1 11kV',
    serial_number: 'ABB-TRF-404',
    total_units: '2 محولات رئيسية + 6 لوحات فرعية',
    checklist_steps: [
      { id: 1, step_text: 'الفحص البصري للمفاتيح والقواطع للتأكد من عدم وجود تفحم أو حرارة', expected_value: 'سليم وخالٍ من السخونة' },
      { id: 2, step_text: 'مراقبة قراءات شاشات القياس الرقمية (الجهد، التيار، معامل القدرة)', expected_value: 'Cos φ ≥ 0.92' },
      { id: 3, step_text: 'التحقق من سلامة نظام التأريض ونظافة غرف التوزيع الكبرى', expected_value: 'مقاومة التأريض < 2 أوم' },
      { id: 4, step_text: 'فحص لوحات تحسين معامل القدرة (Capacitor Banks)', expected_value: 'تعمل تلقائياً' },
      { id: 5, step_text: 'التأكد من إغلاق اللوحات بإحكام لمنع دخول الأتربة أو الحشرات', expected_value: 'محكمة الإغلاق' }
    ]
  },
  {
    id: 'ppm-hvac-01',
    asset_tag: 'AZ-HVAC-01',
    name: 'وحدات مناولة الهواء (AHU) للمناطق الحرجة',
    nameEn: 'Air Handling Units (AHU) for Critical Areas',
    category: 'general_facilities',
    categoryNameAr: 'قسم الصيانة العامة وخدمات المنافع',
    location: 'أسطح مباني العمليات والعنايات المركزة',
    frequency: 'شهري',
    frequencyDays: 30,
    last_pm_date: '2026-09-01',
    next_pm_due: '2026-10-01', // Compliant
    responsible_role: 'فني تكييف وتهوية مركزية',
    model: 'Carrier 39HQ Custom AHU',
    serial_number: 'CAR-AHU-551',
    total_units: '50 وحدة مستقلة ومركزية',
    checklist_steps: [
      { id: 1, step_text: 'فحص ونظافة الفلاتر الأولية (Pre-Filters) واستبدالها إن لزم الأمر', expected_value: 'نظيفة ومطابقة' },
      { id: 2, step_text: 'التحقق من سلامة السيور (Belts) ومحاور الدوران ومستوى الاهتزاز', expected_value: 'مشدودة ولا اهتزاز' },
      { id: 3, step_text: 'قياس درجة الحرارة والرطوبة النسبية لتدفق الهواء بالقسم المعني', expected_value: '21°C ± 1°C / 45-55% RH' },
      { id: 4, step_text: 'التأكد من عمل مانومتر قياس فرق الضغط بشكل سليم وتوثيق القراءة', expected_value: 'قراءة موجبة معتمدة' },
      { id: 5, step_text: 'فحص خط تصريف المياه المكثفة (Drain) لضمان عدم وجود انسداد', expected_value: 'تصريف حر تماماً' }
    ]
  },
  {
    id: 'ppm-chl-01',
    asset_tag: 'AZ-CHL-01',
    name: 'المبردات المركزية (Chillers) ومضخات التبريد',
    nameEn: 'Central Chillers & Chilled Water Pumps',
    category: 'general_facilities',
    categoryNameAr: 'قسم الصيانة العامة وخدمات المنافع',
    location: 'محطة التبريد المركزية - السطح',
    frequency: 'شهري',
    frequencyDays: 30,
    last_pm_date: '2026-09-10',
    next_pm_due: '2026-10-10',
    responsible_role: 'فني تكييف وتبريد مركزي',
    model: 'York YVAA Air-Cooled Chiller',
    serial_number: 'YRK-CHL-201',
    total_units: '2 شيلرات مركزية',
    checklist_steps: [
      { id: 1, step_text: 'مراقبة ضغوط غاز التبريد (الفريون) في خطوط السحب والطرد', expected_value: 'ضمن الحدود المصنعية' },
      { id: 2, step_text: 'فحص مستوى وضغط مياه التبريد ومعدل التدفق عبر المضخات', expected_value: 'تدفق كافٍ 4.5 Bar' },
      { id: 3, step_text: 'التحقق من سلامة كراسي التحميل وعزل الأنابيب الخارجية', expected_value: 'عزل تام ولا تكثف' },
      { id: 4, step_text: 'فحص نظافة ملفات المكثف (Condenser Coils) من الأتربة', expected_value: 'نظيفة ومغسولة' },
      { id: 5, step_text: 'مراقبة لوحة التحكم للتأكد من عدم وجود أي رموز أعطال أو إنذارات', expected_value: 'خالية من الأعطال' }
    ]
  },
  {
    id: 'ppm-fil-01',
    asset_tag: 'AZ-FIL-01',
    name: 'فلاتر الهواء فائقة الكفاءة HEPA لغرف العمليات',
    nameEn: 'HEPA Filters for Operating Rooms & ICU',
    category: 'general_facilities',
    categoryNameAr: 'قسم الصيانة العامة وخدمات المنافع',
    location: 'أسقف غرف العمليات والعناية المشددة',
    frequency: 'كل 3 أشهر',
    frequencyDays: 90,
    last_pm_date: '2026-06-25',
    next_pm_due: '2026-09-23', // Due in 2 days
    responsible_role: 'فني تكييف طبي + مسؤول مكافحة العدوى',
    model: 'Camfil Megalam H14 HEPA',
    serial_number: 'CAM-H14-77',
    checklist_steps: [
      { id: 1, step_text: 'قراءة وتسجيل مانومتر فرق الضغط للتأكد من عدم انسداد الفلتر', expected_value: '< 250 Pa' },
      { id: 2, step_text: 'الفحص الظاهري لإطار الفلتر وموانع التسريب المحيطة به (Gaskets)', expected_value: 'محكم بنسبة 100%' },
      { id: 3, step_text: 'التحقق من معدل تدفق الهواء وتوزيعه بانتظام داخل الغرفة الحرجة', expected_value: 'تدفق طبقي Laminar' },
      { id: 4, step_text: 'التأكد من سلامة كشافات الإنذار الخاصة بامتلاء الفلاتر', expected_value: 'سليمة وتعمل' },
      { id: 5, step_text: 'مطابقة القراءات بحدود معيار سباهي للمناطق عالية الخطورة', expected_value: 'مطابق لـ CBAHI FMS' }
    ]
  },
  {
    id: 'ppm-wtr-01',
    asset_tag: 'AZ-WTR-01',
    name: 'خزانات المياه الرئيسية وشبكات الضخ والصرف',
    nameEn: 'Main Water Reservoirs & Pumping Networks',
    category: 'general_facilities',
    categoryNameAr: 'قسم الصيانة العامة وخدمات المنافع',
    location: 'الخزانات الأرضية والعلوية للمستشفى',
    frequency: 'شهري',
    frequencyDays: 30,
    last_pm_date: '2026-08-25',
    next_pm_due: '2026-09-25',
    responsible_role: 'فني سباكة منشآت وصحة عامة',
    model: 'Grundfos Hydro MPC Booster',
    serial_number: 'GRN-WTR-303',
    checklist_steps: [
      { id: 1, step_text: 'فحص مستوى المياه في الخزانات لضمان توفير مخزون طوارئ كافٍ', expected_value: 'مخزون يكفي 72 ساعة' },
      { id: 2, step_text: 'التحقق من عمل مضخات الرفع ومضخات التدوير (Booster Pumps)', expected_value: 'ضغط ثابت 3.8 Bar' },
      { id: 3, step_text: 'سحب عينة وقياس نسبة الكلور الحر المتبقي للتأكد من التعقيم الآمن', expected_value: '0.2 - 0.5 ملغم/لتر' },
      { id: 4, step_text: 'الفحص البصري لإغلاق الخزانات بإحكام لمنع أي تلوث خارجي', expected_value: 'أقفال محكمة ومعقمة' },
      { id: 5, step_text: 'التحقق من سلامة خطوط الصرف العام وغرف التفتيش وعدم وجود ارتداد', expected_value: 'سليم وخالٍ من الانسداد' }
    ]
  },
  {
    id: 'ppm-blr-01',
    asset_tag: 'AZ-BLR-01',
    name: 'الغلايات المركزية للبخار والماء الساخن',
    nameEn: 'Central Steam & Hot Water Boilers',
    category: 'general_facilities',
    categoryNameAr: 'قسم الصيانة العامة وخدمات المنافع',
    location: 'محطة الغلايات المركزية - البدروم',
    frequency: 'شهري',
    frequencyDays: 30,
    last_pm_date: '2026-08-15',
    next_pm_due: '2026-09-15', // Overdue by 6 days!
    responsible_role: 'فني ميكانيك حراري وغلايات',
    model: 'Babcock Wanson VAP Vapor Boiler',
    serial_number: 'BLR-BW-109',
    checklist_steps: [
      { id: 1, step_text: 'فحص مستوى المياه داخل الغلاية وعمل صمامات العوامة الأوتوماتيكية', expected_value: 'مستوى آمن وتغذية مستمرة' },
      { id: 2, step_text: 'التحقق من سلامة صمامات الأمان ومعايرة ضغط الانفجار', expected_value: 'تفريغ آمن عند 8 Bar' },
      { id: 3, step_text: 'فحص ونظافة حارق الوقود (Burner) والتحقق من كفاءة الاحتراق', expected_value: 'لهب أزرق نقي' },
      { id: 4, step_text: 'مراقبة قراءات مستشعرات ومقاييس الحرارة والضغط وثباتها', expected_value: 'ضمن النطاق المسموح' },
      { id: 5, step_text: 'التحقق من كفاءة مضخات تغذية المياه وعدم وجود تسريبات بالخطوط', expected_value: 'لا تسريب نهائياً' },
      { id: 6, step_text: 'عمل اختبار طرد الرواسب (Blowdown) للتخلص من الأملاح المترسبة', expected_value: 'تم الطرد بنجاح' }
    ]
  },
  {
    id: 'ppm-wht-01',
    asset_tag: 'AZ-WHT-01',
    name: 'سخانات المياه المركزية والفرعية',
    nameEn: 'Central & Sub Water Heaters',
    category: 'general_facilities',
    categoryNameAr: 'قسم الصيانة العامة وخدمات المنافع',
    location: 'غرف الخدمات والمنافع بجميع الأدوار',
    frequency: 'كل 6 أشهر',
    frequencyDays: 180,
    last_pm_date: '2026-04-10',
    next_pm_due: '2026-10-10',
    responsible_role: 'فني سباكة وكهرباء',
    checklist_steps: [
      { id: 1, step_text: 'الفحص البصري لجسم السخان للتأكد من عدم وجود أي تهريب مائي', expected_value: 'سليم تماماً' },
      { id: 2, step_text: 'التحقق من عمل ثرموستات التحكم في الحرارة وفصل السخان', expected_value: 'يفصل عند 60°C' },
      { id: 3, step_text: 'فحص كفاءة عمل صمام الأمان (رداد ومنفس الضغط الزائد)', expected_value: 'يعمل بسلاسة' },
      { id: 4, step_text: 'التحقق من سلامة التوصيلات الكهربائية وقواطع الحماية', expected_value: 'قواطع معزولة ومؤرضة' },
      { id: 5, step_text: 'فحص وقياس سحب التيار الكهربائي لعناصر التسخين', expected_value: 'تيار متطابق مع الحمل' }
    ]
  },
  {
    id: 'ppm-htr-01',
    asset_tag: 'AZ-HTR-01',
    name: 'الدفايات وأنظمة التدفئة الملحقة ومراوح التوزيع',
    nameEn: 'Space Heaters & Seasonal HVAC Distribution',
    category: 'general_facilities',
    categoryNameAr: 'قسم الصيانة العامة وخدمات المنافع',
    location: 'غرف التمريض والمكاتب الإدارية',
    frequency: 'موسمي',
    frequencyDays: 90,
    last_pm_date: '2026-07-01',
    next_pm_due: '2026-10-01',
    responsible_role: 'مشرف الصيانة العامة',
    total_units: '20 دفاية + 50 مروحة',
    checklist_steps: [
      { id: 1, step_text: 'التحقق من سلامة الكابلات والقوابس الخارجية للتأكد من عدم وجود ذوبان', expected_value: 'كابلات سميكة وسليمة' },
      { id: 2, step_text: 'فحص عمل مفاتيح الأمان والحماية عند الانقلاب (Tip-Over Switch)', expected_value: 'تفصل فور الإمالة' },
      { id: 3, step_text: 'التحقق من نظافة شبكات التوزيع والمراوح وخلوها من الأتربة', expected_value: 'نظيفة وخالية من الغبار' },
      { id: 4, step_text: 'مراقبة استقرار ثرموستات ضبط الحرارة وتوزيع الهواء بانتظام', expected_value: 'توزيع حراري منتظم' },
      { id: 5, step_text: 'التأكد من وضع الدفايات في أماكن آمنة بعيدة عن المواد القابلة للاشتعال', expected_value: 'مسافة أمان > 1 متر' }
    ]
  },
  {
    id: 'ppm-ktl-01',
    asset_tag: 'AZ-KTL-01',
    name: 'غلايات الشاهي والأجهزة الكهربائية المكتبية',
    nameEn: 'Electric Kettles & Office Appliances',
    category: 'general_facilities',
    categoryNameAr: 'قسم الصيانة العامة وخدمات المنافع',
    location: 'جميع المكاتب الإدارية واستراحات الكوادر',
    frequency: 'أسبوعي',
    frequencyDays: 7,
    last_pm_date: '2026-09-17',
    next_pm_due: '2026-09-24',
    responsible_role: 'ضابط السلامة وإدارة المرافق',
    total_units: '100 غلاية مكاتب',
    checklist_steps: [
      { id: 1, step_text: 'فحص سلامة السلك الكهربائي والقابس (الفيش) وخلوه من التعرية', expected_value: 'سليم ومؤرض' },
      { id: 2, step_text: 'التحقق من ميزة الفصل الأوتوماتيكي عند غليان الماء (Auto-Off)', expected_value: 'يفصل تلقائياً' },
      { id: 3, step_text: 'التأكد من وضع الغلاية على سطح مستوٍ وثابت وغير قابل للاشتعال', expected_value: 'بعيداً عن المستندات' },
      { id: 4, step_text: 'فحص القاعدة الكهربائية والتأكد من جفافها تماماً لمنع الشورت', expected_value: 'جافة 100%' },
      { id: 5, step_text: 'التحقق من نظافة الغلاية من الداخل وخلوها من التكلسات الكثيفة', expected_value: 'نظيفة ومعقمة' },
      { id: 6, step_text: 'التأكد من فصل الغلاية من القابس بعد انتهاء الدوام الرسمي', expected_value: 'مفصولة تماماً' }
    ]
  },

  // ==========================================
  // 2. الصيانة الطبية (Biomedical)
  // ==========================================
  {
    id: 'ppm-bio-01',
    asset_tag: 'AZ-BIO-01',
    name: 'أجهزة التخدير وغرف العمليات',
    nameEn: 'Anesthesia Workstations',
    category: 'biomedical',
    categoryNameAr: 'الصيانة الطبية',
    location: 'جناح العمليات الجراحية الرئيسي - الدور الثالث',
    frequency: 'كل 3 أشهر',
    frequencyDays: 90,
    last_pm_date: '2026-07-20',
    next_pm_due: '2026-10-20',
    responsible_role: 'مهندس الصيانة الطبية',
    model: 'Dräger Fabius Plus / Primus',
    serial_number: 'DRG-FAB-1014',
    checklist_steps: [
      { id: 1, step_text: 'التحقق من ضغوط غازات المداخل الرئيسية (O2, N2O, Air) وثباتها عند 4 Bar', expected_value: '4.0 Bar ثابت' },
      { id: 2, step_text: 'اختبار فحص التسريب المركزي للدائرة التنفسية (Low-Pressure Leak Test)', expected_value: 'تسريب < 50 ml/min' },
      { id: 3, step_text: 'معايرة مستشعر الأكسجين (O2 Cell Calibration 21% & 100%)', expected_value: 'مطابق للمعيار' },
      { id: 4, step_text: 'فحص وحدة امتصاص ثاني أكسيد الكربون (Soda Lime) وتغير لون الحبيبات', expected_value: 'حبيبات بيضاء طازجة' },
      { id: 5, step_text: 'اختبار كفاءة عمل المنفسة الملحقة ومفاتيح الطوارئ (O2 Flush)', expected_value: 'استجابة فورية 45 L/min' },
      { id: 6, step_text: 'فحص سلامة عمل جهاز التبخير (Vaporizers Interlock System) وإحكام قفله', expected_value: 'قفل تبادلي محكم' }
    ]
  },
  {
    id: 'ppm-bio-02',
    asset_tag: 'AZ-BIO-02',
    name: 'أجهزة الكي الكهربائي وجراحة التخثير ESU',
    nameEn: 'Electrosurgical Units (ESU)',
    category: 'biomedical',
    categoryNameAr: 'الصيانة الطبية',
    location: 'غرف العمليات الجراحية 1 إلى 6',
    frequency: 'كل 6 أشهر',
    frequencyDays: 180,
    last_pm_date: '2026-03-22',
    next_pm_due: '2026-09-22', // Due tomorrow!
    responsible_role: 'مهندس الصيانة الطبية',
    model: 'Medtronic Covidien Force FX',
    serial_number: 'FX-MED-5509',
    checklist_steps: [
      { id: 1, step_text: 'فحص كابل ومجس القطب المحايد (Patient Return Electrode / REM Test)', expected_value: 'نظام REM يعمل بدقة' },
      { id: 2, step_text: 'قياس طاقة الخرج الفعلية للقطع أحادي القطب (Monopolar Cut)', expected_value: 'دقة ± 5% عند 300W' },
      { id: 3, step_text: 'قياس طاقة الخرج الفعلي للتخثير ثنائي القطب (Bipolar Coagulation)', expected_value: 'دقة ± 5% عند 70W' },
      { id: 4, step_text: 'اختبار مفاتيح الأرجل (Footswitches) وأزرار القلم اليدوي', expected_value: 'استجابة فورية' },
      { id: 5, step_text: 'قياس التيارات المتسربة عالية التردد (RF Leakage Current)', expected_value: '< 150 mA RMS' },
      { id: 6, step_text: 'التحقق من عمل صافرات التنبيه السمعية عند تفعيل طاقة الكي', expected_value: 'مسموعة وواضحة' }
    ]
  },
  {
    id: 'ppm-bio-03',
    asset_tag: 'AZ-BIO-03',
    name: 'أجهزة التنفس الصناعي (Ventilator)',
    nameEn: 'Mechanical Intensive Care Ventilators',
    category: 'biomedical',
    categoryNameAr: 'الصيانة الطبية',
    location: 'العناية المركزة ICU + العناية القلبية CCU',
    frequency: 'شهري',
    frequencyDays: 30,
    last_pm_date: '2026-09-21', // Inspected today!
    next_pm_due: '2026-10-21', // Compliant
    responsible_role: 'مهندس الصيانة الطبية',
    model: 'Hamilton-G5 / Puritan Bennett 980',
    serial_number: 'HAM-G5-2241',
    checklist_steps: [
      { id: 1, step_text: 'إجراء الفحص الذاتي المبدئي عند التشغيل (Pre-Use Self Test / SST)', expected_value: 'Passed All Tests' },
      { id: 2, step_text: 'فحص وتنظيف صمامات الزفير والشهيق ومستشعرات التدفق', expected_value: 'معقمة ومختبرة' },
      { id: 3, step_text: 'معايرة مستشعرات التدفق والحجم (Flow Sensors Calibration)', expected_value: 'معايرة ناجحة' },
      { id: 4, step_text: 'التحقق من كفاءة عمل المرطب (Humidifier) وحرارة السخانات', expected_value: '37°C في المجرى' },
      { id: 5, step_text: 'اختبار بطارية الجهاز الاحتياطية تحت الحمل', expected_value: 'تعمل لمدة ≥ 60 دقيقة' },
      { id: 6, step_text: 'اختبار إنذارات انقطاع الغاز والضغط العالي وانفصال المريض', expected_value: 'إنذار فوري' }
    ]
  },
  {
    id: 'ppm-bio-04',
    asset_tag: 'AZ-BIO-04',
    name: 'شاشات مراقبة المرضى والمؤشرات الحيوية',
    nameEn: 'Patient Monitors (Multi-Parameter)',
    category: 'biomedical',
    categoryNameAr: 'الصيانة الطبية',
    location: 'جميع أسرة العناية المركزة والطوارئ',
    frequency: 'كل 6 أشهر',
    frequencyDays: 180,
    last_pm_date: '2026-03-10',
    next_pm_due: '2026-09-10', // Overdue by 11 days!
    responsible_role: 'فني الصيانة الطبية',
    model: 'Mindray BeneVision N15',
    serial_number: 'MIN-N15-998',
    checklist_steps: [
      { id: 1, step_text: 'فحص كابل تخطيط القلب ECG واختبار جودة الإشارة بالمحاكي', expected_value: 'إشارة خالية من التشويش' },
      { id: 2, step_text: 'التحقق من دقة قراءة ضغط الدم NIBP باستخدام كمّات مختلفة', expected_value: 'دقة ± 3 mmHg' },
      { id: 3, step_text: 'فحص كابل وحساس نسبة الأكسجين بالدم SpO2 ومطابقة النبض', expected_value: 'تطابق تام' },
      { id: 4, step_text: 'التحقق من قراءات مستشعر الحرارة Temperature Probe', expected_value: 'دقة ± 0.1°C' },
      { id: 5, step_text: 'تنظيف وتطهير الشاشة الخارجية ومنافذ الكابلات بمسحات طبية', expected_value: 'نظيفة ومعقمة' },
      { id: 6, step_text: 'ضبط حدود الإنذارات العليا والدنيا لكافة المؤشرات الحيوية', expected_value: 'مضبوطة وفق البروتوكول' }
    ]
  },
  {
    id: 'ppm-bio-05',
    asset_tag: 'AZ-BIO-05',
    name: 'أجهزة صدمات القلب وإزالة الرجفان Defibrillator',
    nameEn: 'Cardiac Defibrillators',
    category: 'biomedical',
    categoryNameAr: 'الصيانة الطبية',
    location: 'عربات الإنعاش Crash Carts بالطوارئ والأقسام',
    frequency: 'أسبوعي',
    frequencyDays: 7,
    last_pm_date: '2026-09-20',
    next_pm_due: '2026-09-27', // Compliant
    responsible_role: 'التمريض + مهندس الصيانة الطبية',
    model: 'Zoll R Series Plus',
    serial_number: 'ZOL-R-4411',
    checklist_steps: [
      { id: 1, step_text: 'إجراء اختبار التفريغ الذاتي اليومي وطباعة التقرير', expected_value: 'Passed 30J Test' },
      { id: 2, step_text: 'قياس طاقة الصدمة الفعلية المفرغة عند 50 و 100 و 200 جول', expected_value: 'دقة ± 5%' },
      { id: 3, step_text: 'فحص سلامة عازلية ومقاومة مجاديف الصدمات اليدوية Paddles', expected_value: 'خالية من الخدوش' },
      { id: 4, step_text: 'التحقق من كفاءة نمط المزامنة Sync Mode لمرضى الرجفان', expected_value: 'تزامن دقيق مع موجة R' },
      { id: 5, step_text: 'فحص شحن وتفريغ البطارية والوصول لأقصى طاقة في < 7 ثوانٍ', expected_value: 'شحن في 5.2 ثانية' },
      { id: 6, step_text: 'تأمين وجود ورق طباعة حراري كافٍ وجل التوصيل', expected_value: 'متوفر وصالح' }
    ]
  },
  {
    id: 'ppm-bio-06',
    asset_tag: 'AZ-BIO-06',
    name: 'أجهزة ومحطات غسيل الكلى (Hemodialysis)',
    nameEn: 'Hemodialysis Machines',
    category: 'biomedical',
    categoryNameAr: 'الصيانة الطبية',
    location: 'مركز الغسيل الكلوي التخصصي - الدور الثاني',
    frequency: 'شهري',
    frequencyDays: 30,
    last_pm_date: '2026-08-28',
    next_pm_due: '2026-09-28',
    responsible_role: 'فني الديلزة والصيانة الطبية',
    model: 'Fresenius 5008S CorDiax',
    serial_number: 'FRS-5008-612',
    checklist_steps: [
      { id: 1, step_text: 'التحقق من قراءة وجاذبية الموصلية الكهربائية لسائل الغسيل', expected_value: '13.8 - 14.2 mS/cm' },
      { id: 2, step_text: 'معايرة ومراقبة درجة حرارة سائل الديلزة وثباتها', expected_value: '36.5°C - 37.0°C' },
      { id: 3, step_text: 'اختبار كاشف تسريب الدم في سائل الغسيل (Blood Leak Detector)', expected_value: 'حساسية < 0.35 ml/min' },
      { id: 4, step_text: 'فحص مضخة الدم ومضخة الهيبارين ومعايرة معدلات التدفق', expected_value: 'دقة تامة ± 2%' },
      { id: 5, step_text: 'اختبار صمامات الحماية ومصائد الهواء لمنع الانصمام الهوائي', expected_value: 'إيقاف فوري للتدفق' },
      { id: 6, step_text: 'التحقق من تنفيذ دورات التطهير الكيميائي والحراري اليومية', expected_value: 'موثقة في السجل' }
    ]
  },
  {
    id: 'ppm-bio-07',
    asset_tag: 'AZ-BIO-07',
    name: 'حاضنات أطفال حديثي الولادة (Infant Incubators)',
    nameEn: 'Infant Incubators',
    category: 'biomedical',
    categoryNameAr: 'الصيانة الطبية',
    location: 'وحدة العناية المركزة لحديثي الولادة NICU',
    frequency: 'كل 3 أشهر',
    frequencyDays: 90,
    last_pm_date: '2026-06-30',
    next_pm_due: '2026-09-30',
    responsible_role: 'مهندس الصيانة الطبية',
    model: 'Dräger Isolette C2000',
    serial_number: 'DRG-ISO-3301',
    checklist_steps: [
      { id: 1, step_text: 'قياس وتدقيق حرارة الهواء الداخلي ومطابقتها مع الحساس الجلدي', expected_value: 'دقة ± 0.2°C' },
      { id: 2, step_text: 'فحص نظام التحكم ونسبة الرطوبة النسبية داخل المقصورة', expected_value: '50% - 85% RH' },
      { id: 3, step_text: 'قياس مستوى الضوضاء الداخلي لضمان راحة الرضيع', expected_value: '< 50 dBA' },
      { id: 4, step_text: 'التحقق من سلامة قفل وتأمين الأبواب الجانبية والفتحات Handports', expected_value: 'إغلاق محكم وسلس' },
      { id: 5, step_text: 'فحص فلتر الهواء الملحق واستبداله إن كان ملوثاً', expected_value: 'فلتر نقي 100%' },
      { id: 6, step_text: 'اختبار إنذار ارتفاع الحرارة الزائد وفصل السخان', expected_value: 'إنذار عند > 38.5°C' }
    ]
  },
  {
    id: 'ppm-bio-08',
    asset_tag: 'AZ-BIO-08',
    name: 'أجهزة التحليل الكيميائي المختبري التلقائي',
    nameEn: 'Clinical Chemistry Analyzers',
    category: 'biomedical',
    categoryNameAr: 'الصيانة الطبية',
    location: 'المختبر المركزي - قسم الكيمياء الحيوية',
    frequency: 'شهري',
    frequencyDays: 30,
    last_pm_date: '2026-09-18',
    next_pm_due: '2026-10-18',
    responsible_role: 'أخصائي المختبر + مهندس الصيانة',
    model: 'Roche Cobas c 311 / c 501',
    serial_number: 'RCH-COB-702',
    checklist_steps: [
      { id: 1, step_text: 'التحقق من استقرار درجة حرارة الحواضن الداخلية', expected_value: '37°C ± 0.1°C' },
      { id: 2, step_text: 'فحص سلامة ونظافة الإبر والمجسات الناقلة للعينات Pipettes', expected_value: 'خالية من الانسداد' },
      { id: 3, step_text: 'مراقبة جودة وكفاءة نظام الغسيل التلقائي لمنع التلوث الخلطي', expected_value: 'غسيل بالموجات الصوتية' },
      { id: 4, step_text: 'فحص لمبة الكاشف الضوئي Photometer Lamp وشدة الإضاءة', expected_value: 'جهد وامتصاصية مستقرة' },
      { id: 5, step_text: 'مراجعة سجلات المعايرة ومنحنيات ضبط الجودة Levey-Jennings', expected_value: 'ضمن ± 2 SD' },
      { id: 6, step_text: 'تنظيف خطوط سحب السوائل وخلو الأنابيب من الفقاعات', expected_value: 'خالية من الهواء' }
    ]
  },
  {
    id: 'ppm-bio-10',
    asset_tag: 'AZ-BIO-10',
    name: 'مضخات الحقن والمحاليل الوريدية (Infusion Pumps)',
    nameEn: 'Infusion & Syringe Pumps',
    category: 'biomedical',
    categoryNameAr: 'الصيانة الطبية',
    location: 'جميع الأقسام التمريضية والعنايات',
    frequency: 'كل 6 أشهر',
    frequencyDays: 180,
    last_pm_date: '2026-05-15',
    next_pm_due: '2026-11-15',
    responsible_role: 'فني الصيانة الطبية',
    model: 'B. Braun Space Infusomat',
    serial_number: 'BBR-SPC-882',
    checklist_steps: [
      { id: 1, step_text: 'معايرة واختبار معدل التدفق الفعلي باستخدام جهاز المعايرة', expected_value: 'دقة ± 2% عند 100 ml/h' },
      { id: 2, step_text: 'اختبار حساس اكتشاف فقاعات الهواء داخل الأنبوب', expected_value: 'إنذار عند فقاعة ≥ 50 μl' },
      { id: 3, step_text: 'فحص آلية وقبضة تثبيت المحقنة أو المغذي وضمان عدم انزلاقها', expected_value: 'إحكام وقفل آمن' },
      { id: 4, step_text: 'التحقق من عمل البطارية الداخلية وتشغيل المضخة لـ 4 ساعات', expected_value: 'سليمة وتعمل' },
      { id: 5, step_text: 'تنظيف الهيكل ومستشعرات الضغط من بقايا المحاليل المجففة', expected_value: 'نظيفة تماماً' },
      { id: 6, step_text: 'اختبار إنذار نهاية المحلول واقتراب نفاد الجرعة', expected_value: 'إنذار مسبق 15 دقيقة' }
    ]
  },
  {
    id: 'ppm-bio-11',
    asset_tag: 'AZ-BIO-11',
    name: 'أجهزة عيادة العيون (المصباح الشقي وقياس الضغط)',
    nameEn: 'Slit Lamp & Non-Contact Tonometer',
    category: 'biomedical',
    categoryNameAr: 'الصيانة الطبية',
    location: 'العيادات الخارجية - عيادة طب وجراحة العيون',
    frequency: 'كل 6 أشهر',
    frequencyDays: 180,
    last_pm_date: '2026-06-15',
    next_pm_due: '2026-12-15',
    responsible_role: 'فني الصيانة الطبية',
    model: 'Topcon SL-D7 Slit Lamp',
    serial_number: 'TPC-SL-118',
    checklist_steps: [
      { id: 1, step_text: 'فحص المصباح الشقي ونظافة العدسات والمرايا وحرية حركة المحاور', expected_value: 'حركة سلسة وعدسات نقية' },
      { id: 2, step_text: 'معايرة جهاز قياس ضغط العين بالنفخة وضبط المحاكاة', expected_value: 'دقة ± 1 mmHg' },
      { id: 3, step_text: 'التحقق من دقة قراءات مقياس انكسار العين التلقائي Auto-Refractor', expected_value: 'مطابقة للعين النموذجية' },
      { id: 4, step_text: 'تنظيف وتعقيم الأجزاء الملامسة لذقن وجبهة المريض لمكافحة العدوى', expected_value: 'معقمة ومغطاة' },
      { id: 5, step_text: 'التحقق من عمل محول الطاقة وثبات الجهد المغذي لكرسي الفحص', expected_value: 'جهد مستقر 220V' }
    ]
  },
  {
    id: 'ppm-bio-13',
    asset_tag: 'AZ-BIO-13',
    name: 'أجهزة الأوتوكلاف والتعقيم المركزي بالبخار CSSD',
    nameEn: 'CSSD Steam Sterilizers & Autoclaves',
    category: 'biomedical',
    categoryNameAr: 'الصيانة الطبية + العامة',
    location: 'قسم التعقيم المركزي CSSD - البدروم',
    frequency: 'أسبوعي',
    frequencyDays: 7,
    last_pm_date: '2026-09-15',
    next_pm_due: '2026-09-22', // Due tomorrow
    responsible_role: 'مهندس الصيانة المشتركة',
    model: 'Getinge GSS67H Steam Sterilizer',
    serial_number: 'GTG-67H-401',
    checklist_steps: [
      { id: 1, step_text: 'فحص سلامة الجوانات Gaskets وإحكام قفل الأبواب لمنع أي تسريب بخار', expected_value: 'إحكام تام تحت 3.5 Bar' },
      { id: 2, step_text: 'معايرة مستشعرات الحرارة وثباتها عند 121°C أو 134°C', expected_value: 'دقة ± 0.5°C' },
      { id: 3, step_text: 'التحقق من قراءات مقاييس الضغط لغرفة التعقيم والجاكيت', expected_value: 'مطابقة للشاشة الرقمية' },
      { id: 4, step_text: 'فحص مضخة تفريغ الهواء ومصائد التكثيف لجفاف الأدوات تماماً', expected_value: 'تفريغ عميق وجفاف تام' },
      { id: 5, step_text: 'التأكد من عمل الطابعة الورقية التي توثق منحنى الدورة والباراميترات', expected_value: 'طباعة واضحة وموثقة' }
    ]
  },

  // ==========================================
  // 3. صيانة الـ IT والشبكات (IT & Networks)
  // ==========================================
  {
    id: 'ppm-it-01',
    asset_tag: 'AZ-IT-01',
    name: 'خوادم المستشفى الرئيسية وسيرفرات النظام الطبي (HIS)',
    nameEn: 'Main Hospital Servers & HIS Data Center',
    category: 'it_networks',
    categoryNameAr: 'صيانة الـ IT والشبكات',
    location: 'مركز البيانات الرئيسي (Data Center) - الدور الثالث',
    frequency: 'شهري',
    frequencyDays: 30,
    last_pm_date: '2026-09-05',
    next_pm_due: '2026-10-05',
    responsible_role: 'مهندس الشبكات والأنظمة',
    model: 'Dell PowerEdge R750 Cluster',
    serial_number: 'DEL-PE-902',
    checklist_steps: [
      { id: 1, step_text: 'فحص درجات حرارة كبائن السيرفرات ومستشعرات التكييف الدقيق', expected_value: '19°C - 21°C' },
      { id: 2, step_text: 'التحقق من سلامة مصفوفات الأقراص الصلبة RAID وعدم وجود أقراص معطوبة', expected_value: 'RAID Optimal 100%' },
      { id: 3, step_text: 'تدقيق أخذ النسخ الاحتياطية اليومية التلقائية لقواعد بيانات المرضى', expected_value: 'Backup Success' },
      { id: 4, step_text: 'فحص وحدات إمداد الطاقة المزدوجة (Redundant PSU) ومسارات الكهرباء', expected_value: 'كلا المسارين نشط' },
      { id: 5, step_text: 'مراجعة سجلات الأمان وجدار الحماية (Firewall) ومنع محاولات الاختراق', expected_value: 'خالٍ من التهديدات' }
    ]
  },
  {
    id: 'ppm-it-02',
    asset_tag: 'AZ-IT-02',
    name: 'كبائن سويتشات الشبكة وألياف الفايبر الضوئية',
    nameEn: 'Core Switches & Fiber Distribution Racks',
    category: 'it_networks',
    categoryNameAr: 'صيانة الـ IT والشبكات',
    location: 'نقاط التوزيع الفرعية (IDF) بجميع الأدوار',
    frequency: 'شهري',
    frequencyDays: 30,
    last_pm_date: '2026-08-18',
    next_pm_due: '2026-09-18', // Overdue by 3 days!
    responsible_role: 'فني دعم فني وشبكات',
    model: 'Cisco Catalyst 9300 / 9500 Core',
    serial_number: 'CSCO-CAT-410',
    checklist_steps: [
      { id: 1, step_text: 'الفحص البصري للمؤشرات الضوئية (LEDs) للسويتشات والمنافذ النشطة', expected_value: 'جميع المؤشرات خضراء' },
      { id: 2, step_text: 'فحص مراوح التبريد الداخلية للكبائن وتنظيف مرشحات الأتربة', expected_value: 'نظيفة ومروحة تعمل' },
      { id: 3, step_text: 'قياس استقرار كابلات الألياف الضوئية (Fiber Optic) ومستوى الإشارة', expected_value: 'فقد الإشارة < 0.5 dB' },
      { id: 4, step_text: 'التحقق من سلامة بطاريات الـ UPS الصغيرة المخصصة لكل كابينة', expected_value: 'جهد بطارية سليم' },
      { id: 5, step_text: 'ترتيب وتنظيم كابلات الشبكة (Patch Cords) وترقيم المنافذ', expected_value: 'منظمة ومرقمة' }
    ]
  },
  {
    id: 'ppm-it-03',
    asset_tag: 'AZ-IT-03',
    name: 'السنترال الهاتفي وشبكة الاتصال الداخلي والنداء الصوتي',
    nameEn: 'IP PBX & Internal Hospital Telephony',
    category: 'it_networks',
    categoryNameAr: 'صيانة الـ IT والشبكات',
    location: 'غرفة السنترال الرئيسي - الدور الأرضي',
    frequency: 'شهري',
    frequencyDays: 30,
    last_pm_date: '2026-09-10',
    next_pm_due: '2026-10-10',
    responsible_role: 'مهندس اتصالات وشبكات',
    model: 'Grandstream UCM6308 IP-PBX',
    serial_number: 'GS-UCM-119',
    checklist_steps: [
      { id: 1, step_text: 'اختبار خطوط الطوارئ والخط الساخن للأمن والسلامة (Code Blue / Red)', expected_value: 'رنين فوري وتوجيه آلي' },
      { id: 2, step_text: 'فحص نقاء الصوت في أجهزة النداء الإداري ومكبرات الصوت بالأقسام', expected_value: 'صوت نقي وواضح' },
      { id: 3, step_text: 'التحقق من كفاءة مزامنة بوابات الـ SIP وسعة الخطوط الخارجية', expected_value: 'جميع القنوات متاحة' },
      { id: 4, step_text: 'مراجعة سجلات الاتصال وعدم وجود مكالمات معلقة في الطابور', expected_value: 'طبيعي' }
    ]
  },

  // ==========================================
  // 4. شبكة الأكسجين والغازات الطبية (Medical Gases & Oxygen)
  // ==========================================
  {
    id: 'ppm-gas-01',
    asset_tag: 'AZ-GAS-01',
    name: 'محطة وخزان الأكسجين السائل المركزي ولوحات العزل',
    nameEn: 'Central Liquid Oxygen Tank & Manifolds',
    category: 'medical_gases',
    categoryNameAr: 'شبكة الأكسجين والغازات الطبية',
    location: 'محطة الغازات الطبية المركزية - الفناء الخارجي',
    frequency: 'يومي',
    frequencyDays: 1,
    last_pm_date: '2026-09-20',
    next_pm_due: '2026-09-21', // Due today!
    responsible_role: 'فني غازات طبية متخصص',
    model: 'Air Liquide 10,000L Cryogenic Tank',
    serial_number: 'ALQ-CRYO-10K',
    total_units: 'خزان 10 آلاف لتر + 2 بنوك أسطوانات',
    checklist_steps: [
      { id: 1, step_text: 'مراقبة مستوى الأكسجين السائل في الخزان الرئيسي وتوثيق النسبة', expected_value: '> 40% من السعة' },
      { id: 2, step_text: 'فحص منظمات الضغط لخطوط التوزيع والتأكد من ثباتها عند 4.0 - 4.5 Bar', expected_value: '4.2 Bar مستقر' },
      { id: 3, step_text: 'اختبار كفاءة نظام التبديل الأوتوماتيكي مع المجموعات الاحتياطية Manifolds', expected_value: 'تبديل آلي فوري' },
      { id: 4, step_text: 'التحقق من عمل صافرات إنذار انخفاض/ارتفاع الضغط في لوحات الأقسام', expected_value: 'صافرات تعمل' },
      { id: 5, step_text: 'فحص المحابس الرئيسية وصمامات الأمان ضد وجود أي تسريب أو جليد', expected_value: 'خالية من التسريب' }
    ]
  },
  {
    id: 'ppm-comp-01',
    asset_tag: 'AZ-COMP-01',
    name: 'مكبس ومجفف الهواء الطبي ومضخات الشفط (Vacuum)',
    nameEn: 'Medical Air Compressors & Vacuum Plant',
    category: 'medical_gases',
    categoryNameAr: 'شبكة الأكسجين والغازات الطبية',
    location: 'محطة الضواغط المركزية - المبنى الفني',
    frequency: 'أسبوعي',
    frequencyDays: 7,
    last_pm_date: '2026-09-17',
    next_pm_due: '2026-09-24',
    responsible_role: 'فني غازات منشآت وميكانيك',
    model: 'Atlas Copco Medical Air Plant (Scroll)',
    serial_number: 'ATC-MED-771',
    checklist_steps: [
      { id: 1, step_text: 'فحص قراءة ضغط الهواء الطبي والتأكد من مطابقته للمعيار نظامياً', expected_value: '4.0 Bar للتنفس / 7 Bar للأدوات' },
      { id: 2, step_text: 'فحص كفاءة عمل مجفف الهواء ومصائد الرطوبة الأوتوماتيكية', expected_value: 'نقطة ندى < -40°C' },
      { id: 3, step_text: 'التحقق من مستوى الزيت في الكمبريسور ونظافة مرشح سحب الهواء', expected_value: 'زيت نظيف وفلتر نقي' },
      { id: 4, step_text: 'مراقبة درجات حرارة التشغيل للوحدة ومستوى الضوضاء والاهتزاز', expected_value: 'حرارة طبيعية < 65°C' },
      { id: 5, step_text: 'اختبار كفاءة نظام الشفط الطبي والتفريغ المصاحب للمحطة', expected_value: 'تفريغ ثابت -60 kPa' }
    ]
  },
  {
    id: 'ppm-ro-01',
    asset_tag: 'AZ-RO-01',
    name: 'محطة تحلية ومعالجة مياه غسيل الكلى (RO Plant)',
    nameEn: 'Hemodialysis Reverse Osmosis (RO) Water Plant',
    category: 'medical_gases',
    categoryNameAr: 'شبكة الأكسجين والغازات الطبية + المنافع',
    location: 'وحدة معالجة المياه الملحقة بقسم الغسيل الكلوي',
    frequency: 'يومي',
    frequencyDays: 1,
    last_pm_date: '2026-09-21',
    next_pm_due: '2026-09-22',
    responsible_role: 'مشغل المحطة الفني + مهندس الصيانة',
    model: 'DWA ultraPure RO System',
    serial_number: 'DWA-RO-550',
    checklist_steps: [
      { id: 1, step_text: 'مراقبة جودة ونقاء المياه المنتجة وقراءة نسبة الأملاح الذائبة TDS', expected_value: 'TDS < 10 ppm' },
      { id: 2, step_text: 'فحص ضغوط التشغيل قبل وبعد الأغشية الخلوية Membranes', expected_value: 'فرق ضغط طبيعي' },
      { id: 3, step_text: 'التحقق من كفاءة ونظافة الفلاتر الأولية (الرملية، الكربونية، القطنية)', expected_value: 'غسيل عكسي منتظم' },
      { id: 4, step_text: 'تأكيد عمل مضخة الحقن ومستوى المواد الكيميائية المضادة للترسب', expected_value: 'مضخة تعمل والمحلول كافٍ' },
      { id: 5, step_text: 'التحقق من عدم وجود أي تسريبات مائية في خطوط الربط الحلقي', expected_value: 'خالٍ من أي تسريب' }
    ]
  },

  // ==========================================
  // 5. كاميرات المراقبة والأنظمة الأمنية (CCTV & Security Systems)
  // ==========================================
  {
    id: 'ppm-cctv-01',
    asset_tag: 'AZ-CCTV-01',
    name: 'منظومة كاميرات المراقبة التلفزيونية CCTV',
    nameEn: 'IP CCTV Surveillance Cameras System',
    category: 'cctv_security',
    categoryNameAr: 'كاميرات المراقبة والأنظمة الأمنية',
    location: 'جميع المداخل والممرات والصيدليات والمحيط الخارجي',
    frequency: 'شهري',
    frequencyDays: 30,
    last_pm_date: '2026-08-15',
    next_pm_due: '2026-09-15', // Overdue by 6 days!
    responsible_role: 'مشرف الأمن والسلامة والأنظمة الإلكترونية',
    model: 'Hikvision / Dahua 4K IP Network Cameras',
    serial_number: 'HIK-CAM-600',
    total_units: '128 كاميرا نشطة',
    checklist_steps: [
      { id: 1, step_text: 'فحص وضوح ونظافة عدسات الكاميرات وخلوها من الأتربة وشباك العناكب', expected_value: 'رؤية واضحة 100%' },
      { id: 2, step_text: 'التحقق من زاوية التغطية (Field of View) وعدم وجود أي عوائق بصرية', expected_value: 'تغطية شاملة' },
      { id: 3, step_text: 'اختبار عمل الكاميرات في الرؤية الليلية والأشعة تحت الحمراء IR', expected_value: 'رؤية ليلية مفعلة' },
      { id: 4, step_text: 'فحص التوصيلات وكابلات الشبكة PoE وعدم وجود رخاوة أو تعرض للعوامل الجوية', expected_value: 'معزولة ومثبتة' },
      { id: 5, step_text: 'التأكد من دقة التاريخ والوقت وظهوره بشكل متزامن على كافة الكاميرات', expected_value: 'متزامن مع NTP' }
    ]
  },
  {
    id: 'ppm-sec-02',
    asset_tag: 'AZ-SEC-02',
    name: 'أجهزة التسجيل الرقمي NVR وسيرفرات أرشفة الفيديو',
    nameEn: 'Network Video Recorders (NVR) & Storage Matrix',
    category: 'cctv_security',
    categoryNameAr: 'كاميرات المراقبة والأنظمة الأمنية',
    location: 'غرفة التحكم والمراقبة الأمنية المركزية (Control Room)',
    frequency: 'شهري',
    frequencyDays: 30,
    last_pm_date: '2026-08-28',
    next_pm_due: '2026-09-28',
    responsible_role: 'فني أمن إلكتروني',
    model: 'Dahua 64-Channel Super NVR',
    serial_number: 'DH-NVR-640',
    checklist_steps: [
      { id: 1, step_text: 'فحص فترة الاحتفاظ بالأرشيف لضمان عدم نقص مدة التسجيل عن 90 يوماً', expected_value: 'احتفاظ ≥ 90 يوماً' },
      { id: 2, step_text: 'التحقق من صحة أقراص التخزين Western Digital Purple وعدم وجود Bad Sectors', expected_value: 'حالة الأقراص Good' },
      { id: 3, step_text: 'فحص درجة حرارة أجهزة الـ NVR وكفاءة مراوح التهوية الخلفية', expected_value: 'حرارة طبيعية' },
      { id: 4, step_text: 'اختبار استرجاع عينة فيديو عشوائية من الأسبوع الماضي وسرعة العرض', expected_value: 'استرجاع فوري وسلس' }
    ]
  },
  {
    id: 'ppm-acc-03',
    asset_tag: 'AZ-ACC-03',
    name: 'أنظمة التحكم بالدخول والأقفال المغناطيسية للأبواب',
    nameEn: 'Access Control & Magnetic Door Locks',
    category: 'cctv_security',
    categoryNameAr: 'كاميرات المراقبة والأنظمة الأمنية',
    location: 'أبواب غرف العمليات، العناية، الصيدلية المركزية، وحاضنات الأطفال',
    frequency: 'شهري',
    frequencyDays: 30,
    last_pm_date: '2026-09-12',
    next_pm_due: '2026-10-12',
    responsible_role: 'فني أنظمة أمنية',
    model: 'ZKTeco ProCapture-X / Magnetic Locks 600lbs',
    serial_number: 'ZKT-ACC-331',
    checklist_steps: [
      { id: 1, step_text: 'فحص قوة الإمساك للأقفال الكهرومغناطيسية (Magnetic Locks) وعدم سهولة الفتح بالقوة', expected_value: 'قوة إمساك 280 كجم' },
      { id: 2, step_text: 'اختبار قارئات البطاقات الذكية والبصمة وزمن الفتح', expected_value: 'استجابة < 1 ثانية' },
      { id: 3, step_text: 'اختبار زر الخروج في حالات الطوارئ (Emergency Break Glass / Exit Button)', expected_value: 'تحرير فوري للقفل' },
      { id: 4, step_text: 'التحقق من ارتباط الأقفال بنظام إنذار الحريق لفتح الأبواب تلقائياً عند Code Red', expected_value: 'فتح آلي عند الحريق' }
    ]
  },

  // ==========================================
  // 6. أجهزة ومعدات الشركات (Contractor Medical Assets)
  // ==========================================
  {
    id: 'ppm-bio-09',
    asset_tag: 'AZ-BIO-09',
    name: 'جهاز الأشعة المقطعية المتقدم (CT Scan 128-Slice)',
    nameEn: 'CT Scan 128-Slice (Contractor Maintenance)',
    category: 'contractor_assets',
    categoryNameAr: 'أجهزة ومعدات الشركات المتعاقدة',
    location: 'قسم الأشعة التشخيصية - الطابق الأرضي',
    frequency: 'كل 6 أشهر',
    frequencyDays: 180,
    last_pm_date: '2026-04-15',
    next_pm_due: '2026-10-15',
    responsible_role: 'مهندس الشركة الوكيلة المعتمدة + مشرف الأشعة',
    model: 'GE Revolution EVO 128-Slice',
    serial_number: 'GE-CT-128X',
    notes: 'صيانة دورية معتمدة وفق عقد الصيانة الشامل مع الوكيل',
    checklist_steps: [
      { id: 1, step_text: 'التحقق من كفاءة عمل منظومة تبريد أنبوب الأشعة X-Ray Tube Cooling', expected_value: 'تبريد مستقر وتدفق سليم' },
      { id: 2, step_text: 'اختبار دقة حركة وسلاسة طاولة المريض Patient Table Alignment', expected_value: 'حركة ميكانيكية دقيقة' },
      { id: 3, step_text: 'عمل اختبار جودة الصورة اليومي باستخدام الفانتوم Daily Phantom QA', expected_value: 'تباين ونقاء مطابق للمعيار' },
      { id: 4, step_text: 'التحقق من قواطع الأمان وأزرار التوقف الطارئ Emergency Stops', expected_value: 'توقف فوري عند الضغط' },
      { id: 5, step_text: 'مراجعة منظومة فحص وتسجيل جرعات الأشعة Dose Optimization', expected_value: 'وفق معايير الحماية من الإشعاع' },
      { id: 6, step_text: 'التأكد من عمل كشافات التحذير الخارجية المثبتة على أبواب الغرفة', expected_value: 'تضيء بالأحمر أثناء التعريض' }
    ]
  },
  {
    id: 'ppm-bio-12',
    asset_tag: 'AZ-BIO-12',
    name: 'منظومة ليزر العيون المتقدمة (Ophthalmic LASIK / YAG Laser)',
    nameEn: 'Ophthalmic LASIK / YAG Laser System',
    category: 'contractor_assets',
    categoryNameAr: 'أجهزة ومعدات الشركات المتعاقدة',
    location: 'مركز طب وجراحة العيون والليزك',
    frequency: 'كل 3 أشهر',
    frequencyDays: 90,
    last_pm_date: '2026-07-15',
    next_pm_due: '2026-10-15',
    responsible_role: 'مهندس شركة الليزر المختص + استشاري العيون',
    model: 'Alcon WaveLight EX500 / Zeiss VisuMax',
    serial_number: 'ALC-EX500-88',
    checklist_steps: [
      { id: 1, step_text: 'قياس ومعايرة طاقة مخرج شعاع الليزر الفعلي بمقياس طاقة معتمد', expected_value: 'طاقة دقيقة ± 1%' },
      { id: 2, step_text: 'التحقق من دقة خط ومسار شعاع التصويب المساعد Aiming Beam', expected_value: 'تطابق بؤري تام' },
      { id: 3, step_text: 'فحص كفاءة نظام التبريد السائل والحراري الداخلي لمنع السخونة', expected_value: 'حرارة مستقرة' },
      { id: 4, step_text: 'اختبار مفاتيح الإغلاق الذاتي الطارئة للحماية Safety Interlocks', expected_value: 'إيقاف فوري للنبضات' },
      { id: 5, step_text: 'التأكد من توفر ونظافة نظارات الحماية الخاصة بالطبيب والطاقم', expected_value: 'نظارات سليمة ومطابقة للطول الموجي' }
    ]
  },
  {
    id: 'ppm-mri-01',
    asset_tag: 'AZ-MRI-01',
    name: 'جهاز الرنين المغناطيسي (MRI 1.5 Tesla)',
    nameEn: 'Magnetic Resonance Imaging (MRI 1.5T)',
    category: 'contractor_assets',
    categoryNameAr: 'أجهزة ومعدات الشركات المتعاقدة',
    location: 'جناح الرنين المغناطيسي - مبنى الأشعة التخصصي',
    frequency: 'كل 3 أشهر',
    frequencyDays: 90,
    last_pm_date: '2026-08-01',
    next_pm_due: '2026-11-01',
    responsible_role: 'مهندس شركة Siemens الوكيلة + فيزيائي طبي',
    model: 'Siemens MAGNETOM Altea 1.5T',
    serial_number: 'SIE-MRI-150',
    checklist_steps: [
      { id: 1, step_text: 'مراقبة مستوى الهيليوم السائل ومعدل الضغط (Coldhead Operation)', expected_value: 'مستوى هيليوم > 85%' },
      { id: 2, step_text: 'التحقق من كفاءة خط التبريد المائي المخصص (Dedicated Chiller)', expected_value: 'تدفق وحرارة مياه تبريد 8°C' },
      { id: 3, step_text: 'فحص سلامة قفص فاراداي (RF Shielding) وخلو الغرفة من تسريب الترددات', expected_value: 'عزل كهرومغناطيسي تام' },
      { id: 4, step_text: 'اختبار زر التفريغ الطارئ المغناطيسي (Emergency Quench Button)', expected_value: 'غطاء أمان سليم وسجل تدقيق' },
      { id: 5, step_text: 'فحص كاشف المعادن على الباب الرئيسي لمنع دخول الأجسام الحديدية', expected_value: 'حساسية عالية وصافرة تعمل' }
    ]
  }
];
