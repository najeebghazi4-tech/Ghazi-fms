import { 
  EmergencyCodeDefinition, 
  ActiveEmergencyAlert, 
  SafetyInspectionItem, 
  SafetyIncidentReport, 
  SecurityShiftHandover 
} from '../types';

export const AZAL_HOSPITAL_LOCATIONS = [
  'قسم الطوارئ والإسعاف - الدور الأرضي',
  'العناية المركزة (ICU) - الدور الأول',
  'جناح العمليات الكبرى (OR) - الدور الثاني',
  'محطة الأكسجين والغازات الطبية المركزية - الفناء الخلفي',
  'غرفة المولدات الكهربائية ولوحات التوزيع الرئيسية',
  'جناح التنويم الباطني والجراحي - الدور الثالث',
  'مختبر بنك الدم والتحاليل الطبية - الدور الأرضي',
  'قسم الأشعة والرنين المغناطيسي - القبو',
  'البوابة الرئيسية وحراسة الاستقبال (Gate 1)',
  'بوابة الطوارئ ومسار سيارات الإسعاف (Gate 2)',
  'صيدلية المستشفى الرئيسية ومخزن الأدوية المخدرة',
];

export const AZAL_EMERGENCY_CODES: EmergencyCodeDefinition[] = [
  {
    type: 'code_red',
    nameAr: 'كود أحمر (Code Red)',
    nameEn: 'Fire / Smoke Emergency',
    meaningAr: 'حريق أو انبعاث دخان أو حرارة مرتفعة تستدعي الإخلاء',
    colorClass: 'text-rose-400',
    bgClass: 'bg-rose-950/80',
    borderClass: 'border-rose-700',
    actionProtocolAr: 'تفعيل بروتوكول RACE: إنقاذ المحاصرين، إطلاق الإنذار، احتواء النيران بغلق الأبواب، وإخلاء المنطقة فوراً.',
  },
  {
    type: 'code_blue',
    nameAr: 'كود أزرق (Code Blue)',
    nameEn: 'Cardiac Arrest / Medical Emergency',
    meaningAr: 'توقف القلب أو التنفس لمريض أو مراجع أو موظف',
    colorClass: 'text-sky-400',
    bgClass: 'bg-sky-950/80',
    borderClass: 'border-sky-700',
    actionProtocolAr: 'استدعاء فريق الإنعاش القلبي الرئوي (CPR Team)، نقل عربة الإنعاش وجهاز الصدمات لموقع البلاغ خلال 60 ثانية.',
  },
  {
    type: 'code_yellow',
    nameAr: 'كود أصفر (Code Yellow)',
    nameEn: 'Internal Disaster / HAZMAT / Gas Leak',
    meaningAr: 'كارثة داخلية / تسرب أكسجين أو غاز أو مواد كيميائية خطرة أو انقطاع كهرباء',
    colorClass: 'text-amber-400',
    bgClass: 'bg-amber-950/80',
    borderClass: 'border-amber-700',
    actionProtocolAr: 'عزل المنطقة المتأثرة، إغلاق صمامات الغازات الطارئة (Shut-off Valves)، وارتداء معدات الحماية الشخصية PPE.',
  },
  {
    type: 'code_black',
    nameAr: 'كود أسود (Code Black)',
    nameEn: 'Security Threat / Armed Intruder',
    meaningAr: 'تهديد أمني حرج / سلاح / اعتداء جسدي عنيف / جسم مشبوه',
    colorClass: 'text-slate-200',
    bgClass: 'bg-slate-900',
    borderClass: 'border-slate-600',
    actionProtocolAr: 'تحرك سريع لكافة حراس الأمن، إحكام إغلاق المنافذ، حماية الكادر والمرضى، وإبلاغ شرطة النجدة فوراً.',
  },
  {
    type: 'code_pink',
    nameAr: 'كود وردي (Code Pink)',
    nameEn: 'Infant / Child Abduction',
    meaningAr: 'اشتباه اختطاف أو فقدان رضيع أو طفل داخل المستشفى',
    colorClass: 'text-pink-400',
    bgClass: 'bg-pink-950/80',
    borderClass: 'border-pink-700',
    actionProtocolAr: 'إغلاق كامل لجميع مخارج وبوابات مستشفى أزال، تفتيش أمتعة وحقائب كل المغادرين، ومراقبة كاميرات CCTV.',
  },
  {
    type: 'code_orange',
    nameAr: 'كود برتقالي (Code Orange)',
    nameEn: 'External Mass Casualty Disaster (MCI)',
    meaningAr: 'كارثة خارجية وحادث جماعي يستدعي استقبال عشرات المصابين',
    colorClass: 'text-orange-400',
    bgClass: 'bg-orange-950/80',
    borderClass: 'border-orange-700',
    actionProtocolAr: 'استدعاء القوة التمريضية والطبية الاحتياطية، فتح مسارات الفرز (Triage)، وتجهيز غرف العمليات وبنك الدم.',
  },
  {
    type: 'code_grey',
    nameAr: 'كود رمادي (Code Grey)',
    nameEn: 'Combative / Aggressive Person',
    meaningAr: 'شخص عدائي أو مشاجرة عنيفة غير مسلحة بقسم الطوارئ أو الاستقبال',
    colorClass: 'text-slate-300',
    bgClass: 'bg-zinc-900',
    borderClass: 'border-zinc-700',
    actionProtocolAr: 'تطويق الموقع بهدوء واحتواء الشخص دبلوماسياً وأمنياً لمنع تضرر المرضى والممتلكات.',
  },
];

export const INITIAL_ACTIVE_ALERTS: ActiveEmergencyAlert[] = [];

export const INITIAL_SAFETY_INSPECTIONS: SafetyInspectionItem[] = [];

export const INITIAL_SAFETY_INCIDENTS: SafetyIncidentReport[] = [];

export const INITIAL_SECURITY_HANDOVERS: SecurityShiftHandover[] = [];

