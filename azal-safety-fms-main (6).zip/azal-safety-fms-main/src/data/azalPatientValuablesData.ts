import { LostAndFoundItemRecord } from '../types';

export const INITIAL_PATIENT_VALUABLES: LostAndFoundItemRecord[] = [
  {
    id: 'pv-001',
    itemReference: 'VAL-2026-001',
    foundDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    foundLocation: 'العناية المركزة ICU - سرير 4',
    itemCategory: 'jewelry_watch',
    description: 'خاتم ذهب عيار 21 + ساعة رولكس رجالية ذهبية + محفظة جلدية',
    finderName: 'سناء القدسي (رئيسة تمريض ICU)',
    custodyLocation: 'خزنة الأمانات الفولاذية رقم 1 - مكتب الأمن',
    status: 'safekeeping',
    patientValuables: {
      patientName: 'سالم عبدالله أحمد الماوري',
      patientMrn: 'MRN-84920',
      patientAdmissionDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      holdingDeadlineDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000 + 180 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      is180DayHoldingExceeded: false,
      goldOrJewelryDetails: 'خاتم ذهب أصفر عيار 21 بدون فصوص، وساعة يد رولكس صلب وذهب',
      cashAmountYemen: 450000,
      cashAmountSaudi: 2500,
      cashAmountDollar: 600,
      electronicsDetails: 'هاتف آيفون 15 برو ماكس رمادي تيتانيوم مقفل برمز',
      securityBagSealNumber: 'SEAL-AZAL-99214',
      witnessStaffName: 'د. مروان الشامي (طبيب مقيم ICU)'
    },
    notes: 'تم استلام الأمانات عند إدخال المريض في غيبوبة تنفسية وحفظها في كيس أمانات مشمع برقم تسلسلي.',
    createdAt: Date.now() - 15 * 24 * 60 * 60 * 1000
  },
  {
    id: 'pv-002',
    itemReference: 'VAL-2026-002',
    foundDate: new Date(Date.now() - 40 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    foundLocation: 'قسم طوارئ الجراحة - غرفة إنعاش 2',
    itemCategory: 'money',
    description: 'مبلغ نقدي محكم في ظرف أمانات + هاتف سامسونج ألترا',
    finderName: 'مطيع العواضي (ضابط أمن الطوارئ)',
    custodyLocation: 'خزنة الأمانات الفولاذية رقم 2',
    status: 'safekeeping',
    patientValuables: {
      patientName: 'صادق يحيى محمد الحرازي',
      patientMrn: 'MRN-77312',
      patientAdmissionDate: new Date(Date.now() - 40 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      holdingDeadlineDate: new Date(Date.now() - 40 * 24 * 60 * 60 * 1000 + 180 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      is180DayHoldingExceeded: false,
      cashAmountYemen: 120000,
      cashAmountSaudi: 1000,
      electronicsDetails: 'هاتف سامسونج S24 ألترا رمادي مع شاحن وسماعة',
      securityBagSealNumber: 'SEAL-AZAL-88301',
      witnessStaffName: 'أروى العنسي (تمريض الطوارئ)'
    },
    notes: 'أمانات مريض مصاب في حادث مروري، تم إيداعها بمحضر رسمي بانتظار استكمال العلاج.',
    createdAt: Date.now() - 40 * 24 * 60 * 60 * 1000
  },
  {
    id: 'pv-003',
    itemReference: 'VAL-2025-089',
    foundDate: new Date(Date.now() - 195 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    foundLocation: 'جناح التنويم الباطني - غرفة 312',
    itemCategory: 'jewelry_watch',
    description: 'حقيبة يد صغيرة بداخلها مصوغات فضية وساعة ومبلغ رمزي',
    finderName: 'إدارة شؤون المرضى',
    custodyLocation: 'الخزنة المركزية بإشراف الشؤون القانونية',
    status: 'safekeeping',
    patientValuables: {
      patientName: 'فاطمة قاسم حسن الشرفي',
      patientMrn: 'MRN-60412',
      patientAdmissionDate: new Date(Date.now() - 195 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      holdingDeadlineDate: new Date(Date.now() - 195 * 24 * 60 * 60 * 1000 + 180 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      is180DayHoldingExceeded: true,
      goldOrJewelryDetails: 'سوارين فضة يمنية قديمة وعقد خرز وساعة يد يابانية',
      cashAmountYemen: 35000,
      securityBagSealNumber: 'SEAL-AZAL-71042',
      witnessStaffName: 'بشرى النجار (مشرفة التمريض)'
    },
    notes: 'تنبيه نظامي: تجاوزت هذه الأمانة المهلة النظامية القانونية (180 يوماً). تم رفع مذكرة لإدارة المستندات والشؤون القانونية للتواصل النهائي أو التحويل وفق الأطر النظامية.',
    createdAt: Date.now() - 195 * 24 * 60 * 60 * 1000
  }
];
