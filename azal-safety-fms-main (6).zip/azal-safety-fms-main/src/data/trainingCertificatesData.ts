import { TrainingCertificateRecord } from '../types';

export const DEFAULT_TRAINING_CERTIFICATES: TrainingCertificateRecord[] = [
  {
    id: 'cert-001',
    certificate_serial: 'AZAL-FMS-CERT-2026-0101',
    trainee_name: 'أحمد علي النهمي',
    department: 'قسم الطوارئ والإسعاف',
    job_title: 'ممرض طوارئ أول',
    course_name: 'التدريب العملي على خطة الإخلاء ومكافحة الحرائق (Code Red)',
    training_date: '2026-02-15',
    duration_hours: 4,
    trainer_name: 'م. نجيب قاسم غازي',
    safety_head_name: 'م/ نجيب قاسم غازي',
    general_manager_name: 'د/ محمد السراجي',
    issue_date: '2026-02-16',
    grade_or_evaluation: 'ممتاز (Excellent)',
    qr_code_payload: 'AZAL-FMS-CERT-2026-0101|احمد علي النهمي|الطوارئ|خطة الاخلاء ومكافحة الحرائق|2026-02-15|معتمد',
  },
  {
    id: 'cert-002',
    certificate_serial: 'AZAL-FMS-CERT-2026-0102',
    trainee_name: 'خالد عبدالملك الصبري',
    department: 'قسم الصيانة العامة والهندسية',
    job_title: 'فني كهرباء ومولدات',
    course_name: 'السلامة المهنية وإجراءات تصاريح العمل الساخن (Hot Work Permit)',
    training_date: '2026-02-22',
    duration_hours: 3,
    trainer_name: 'م. عارف الصلوي',
    safety_head_name: 'م/ نجيب قاسم غازي',
    general_manager_name: 'د/ محمد السراجي',
    issue_date: '2026-02-23',
    grade_or_evaluation: 'اجتياز بتفوق',
    qr_code_payload: 'AZAL-FMS-CERT-2026-0102|خالد عبدالملك الصبري|الصيانة|تصاريح العمل الساخن|2026-02-22|معتمد',
  },
  {
    id: 'cert-003',
    certificate_serial: 'AZAL-FMS-CERT-2026-0103',
    trainee_name: 'فاطمة محمد العنسي',
    department: 'العمليات الجراحية الكبرى',
    job_title: 'أخصائية تمريض عمليات',
    course_name: 'سلامة الغازات الطبية وصمامات العزل في الطوارئ والعمليات',
    training_date: '2026-03-01',
    duration_hours: 4,
    trainer_name: 'م. نجيب قاسم غازي',
    safety_head_name: 'م/ نجيب قاسم غازي',
    general_manager_name: 'د/ محمد السراجي',
    issue_date: '2026-03-02',
    grade_or_evaluation: 'ممتاز (Excellent)',
    qr_code_payload: 'AZAL-FMS-CERT-2026-0103|فاطمة محمد العنسي|العمليات|سلامة الغازات الطبية|2026-03-01|معتمد',
  },
  {
    id: 'cert-004',
    certificate_serial: 'AZAL-FMS-CERT-2026-0104',
    trainee_name: 'يحيى مسعد الوادعي',
    department: 'قسم الأجهزة الطبية والهندسة الحيوية',
    job_title: 'مهندس أجهزة طبية',
    course_name: 'السلامة من الإشعاع والوقاية في أقسام الأشعة والمختبر',
    training_date: '2026-03-05',
    duration_hours: 3,
    trainer_name: 'م. معتز الحميري',
    safety_head_name: 'م/ نجيب قاسم غازي',
    general_manager_name: 'د/ محمد السراجي',
    issue_date: '2026-03-06',
    grade_or_evaluation: 'اجتياز بنجاح',
    qr_code_payload: 'AZAL-FMS-CERT-2026-0104|يحيى مسعد الوادعي|الاجهزة الطبية|السلامة من الاشعاع|2026-03-05|معتمد',
  },
  {
    id: 'cert-005',
    certificate_serial: 'AZAL-FMS-CERT-2026-0105',
    trainee_name: 'سمية نبيل الشرعبي',
    department: 'قسم المختبر المركزي وبنك الدم',
    job_title: 'فنية مختبرات طبية',
    course_name: 'إدارة وتداول المواد الكيميائية الخطرة وصحائف السلامة (MSDS & Hazmat)',
    training_date: '2026-03-10',
    duration_hours: 4,
    trainer_name: 'م. نجيب قاسم غازي',
    safety_head_name: 'م/ نجيب قاسم غازي',
    general_manager_name: 'د/ محمد السراجي',
    issue_date: '2026-03-11',
    grade_or_evaluation: 'ممتاز (Excellent)',
    qr_code_payload: 'AZAL-FMS-CERT-2026-0105|سمية نبيل الشرعبي|المختبر المركزي|المواد الكيميائية MSDS|2026-03-10|معتمد',
  },
  {
    id: 'cert-006',
    certificate_serial: 'AZAL-FMS-CERT-2026-0106',
    trainee_name: 'عبدالله هائل الارياني',
    department: 'المغسلة المركزية والخدمات العامة',
    job_title: 'مشرف المغسلة المركزية',
    course_name: 'توجيه الموظفين الجدد لمعايير السلامة المهنية ومهمات الوقاية (Orientation)',
    training_date: '2026-03-12',
    duration_hours: 3,
    trainer_name: 'م. عارف الصلوي',
    safety_head_name: 'م/ نجيب قاسم غازي',
    general_manager_name: 'د/ محمد السراجي',
    issue_date: '2026-03-13',
    grade_or_evaluation: 'اجتياز بنجاح',
    qr_code_payload: 'AZAL-FMS-CERT-2026-0106|عبدالله هائل الارياني|المغسلة المركزية|توجيه الموظفين Orientation|2026-03-12|معتمد',
  },
];

/**
 * Generates the next unique certificate serial code
 * Pattern: AZAL-FMS-CERT-2026-XXXX
 */
export function generateNextCertificateSerial(existingCerts: TrainingCertificateRecord[] = []): string {
  const currentYear = new Date().getFullYear();
  const prefix = `AZAL-FMS-CERT-${currentYear}-`;

  // Find max serial number from existing
  let maxNum = 106;
  existingCerts.forEach((c) => {
    if (c.certificate_serial && c.certificate_serial.startsWith(prefix)) {
      const parts = c.certificate_serial.split('-');
      const numPart = parseInt(parts[parts.length - 1], 10);
      if (!isNaN(numPart) && numPart > maxNum) {
        maxNum = numPart;
      }
    }
  });

  const nextNum = maxNum + 1;
  return `${prefix}${String(nextNum).padStart(4, '0')}`;
}

/**
 * Loads stored certificates with localStorage persistence
 */
export function loadStoredCertificates(): TrainingCertificateRecord[] {
  if (typeof window === 'undefined') return DEFAULT_TRAINING_CERTIFICATES;
  try {
    const saved = localStorage.getItem('azal_training_certificates');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (err) {
    console.warn('[Storage] Error loading azal_training_certificates:', err);
  }
  return DEFAULT_TRAINING_CERTIFICATES;
}

/**
 * Saves certificates to localStorage
 */
export function saveStoredCertificates(certs: TrainingCertificateRecord[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem('azal_training_certificates', JSON.stringify(certs));
  } catch (err) {
    console.warn('[Storage] Error saving azal_training_certificates:', err);
  }
}
