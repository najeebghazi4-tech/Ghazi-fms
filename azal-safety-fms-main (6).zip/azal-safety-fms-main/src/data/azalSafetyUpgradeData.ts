import { 
  SafetyTourRecord, 
  SafetyViolationNotice, 
  FireExtinguisherItem, 
  PublicSafetyReport, 
  DbMigration 
} from '../types';
import { 
  AZAL_MASTER_FIRE_EXTINGUISHERS, 
  AZAL_MASTER_SAFETY_TOURS 
} from './azalHospitalSafetyRegistry';

export const AZAL_DEPARTMENTS = [
  'قسم الطوارئ والإسعاف',
  'العناية المركزة (ICU)',
  'العمليات الجراحية الكبرى',
  'قسم النساء والتوليد والحواضن',
  'المختبر المركزي وبنك الدم',
  'قسم الأشعة التشخيصية والتصوير الطبقي',
  'الصيدلية المركزية ومستودع الأدوية',
  'مركز الغسيل الكلوي',
  'قسم التعقيم المركزي (CSSD)',
  'وحدة المناظير',
  'العيادات الخارجية والاستقبال',
  'محطة الغازات الطبية وتوليد الأكسجين',
  'محطة المولدات والكهرباء الرئيسية',
  'المطبخ والتغذية العلاجية',
  'المغسلة المركزية ومستودع البياضات',
  'إدارة المستشفى والمكاتب الإدارية'
];

export const SAFETY_TOUR_TASKS = [
  'فحص مخارج الطوارئ ومسارات الهروب وخلوها من العوائق',
  'فحص لوحات وقواطع الكهرباء والمولدات الاحتياطية',
  'فحص الممرات ومصاعد المستشفى وإنارة الطوارئ',
  'فحص أسطوانات الغاز ومحابس شبكة الغازات الطبية',
  'فحص رشاشات الحريق وكواشف الدخان والإنذار',
  'فحص صناديق الإسعافات الأولية والتجهيزات الوقائية'
];

export const ASSIGNED_PARTIES = [
  'قسم الصيانة العامة والهندسية',
  'إدارة التمريض والخدمات الطبية',
  'إدارة الخدمات المساندة والنظافة',
  'الهندسة الطبية والأجهزة',
  'قسم السلامة والصحة المهنية',
  'إدارة الموارد البشرية والشؤون الإدارية'
];

export const INITIAL_FIRE_EXTINGUISHERS: FireExtinguisherItem[] = AZAL_MASTER_FIRE_EXTINGUISHERS;

export const INITIAL_SAFETY_TOURS: SafetyTourRecord[] = AZAL_MASTER_SAFETY_TOURS;

// Real Violations Registry - Clean and persistent (Real Supabase / Field Inspections)
export const INITIAL_VIOLATIONS: SafetyViolationNotice[] = [
  {
    id: 'AZAL-VIO-2026-BD646A8B',
    tourId: 'TOUR-AZAL-2026-0921',
    department: 'قسم الأشعة التشخيصية والتصوير الطبقي',
    locationDetail: 'صالة الطب النووي',
    description: 'غسيل الجدار بالماء مما يسبب شرت كهربائي وحريق لايحمل عقباه',
    severity: 'critical',
    requiredAction: 'منع غسيل الجدران بالماء حول القواطع والأسلاك، وتأمين التمديدات فوراً، والاعتماد على التنظيف الجاف المعتمد',
    assignedTo: 'قسم الصيانة العامة والهندسية',
    assignedToCustom: 'م/ مسؤول الصيانة والتشغيل',
    deadlineHours: 72,
    deadlineAt: '2026-09-24T20:51:00.000Z',
    createdAt: '2026-09-21T20:51:00.000Z',
    timestamp: 1758487860000,
    status: 'pending',
    statusAr: 'قيد المتابعة',
    synced: true,
    publicToken: 'AZAL-VIO-2026-BD646A8B'
  }
];

export const INITIAL_PUBLIC_REPORTS: PublicSafetyReport[] = [];


export const INITIAL_MIGRATIONS: DbMigration[] = [
  {
    id: 'mig-001',
    version: '20260910_001',
    name: '0001_initial_safety_schema',
    appliedAt: '2026-09-10 06:00:00 (PostgreSQL & IndexedDB Synced)',
    status: 'applied',
    details: 'إنشاء جداول السلامة: safety_tours, safety_violations, fire_extinguishers, public_reports مع الفهارس والقيود الكاملة.'
  },
  {
    id: 'mig-002',
    version: '20260910_002',
    name: '0002_add_resolution_and_escalation',
    appliedAt: '2026-09-10 06:15:00 (PostgreSQL & IndexedDB Synced)',
    status: 'applied',
    details: 'إضافة أعمدة إفادة الإنجاز العامة، روابط التحقق بدون تسجيل دخول، وحالات الإنذار الثاني وتتبع المهلة.'
  },
  {
    id: 'mig-003',
    version: '20260910_003',
    name: '0003_fire_extinguisher_audit_revamp',
    appliedAt: '2026-09-10 06:30:00 (PostgreSQL & IndexedDB Synced)',
    status: 'applied',
    details: 'تحديث مخطط طفايات الحريق، حصر الاعتماد على مسؤول الأمن والسلامة فقط، وإلغاء خانة مدير المركز نهائياً.'
  }
];
