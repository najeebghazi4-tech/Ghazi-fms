import * as XLSX from 'xlsx';
import { PpmAsset, PpmDepartmentCategory } from '../data/azalPpmAssetsData';
import { computeNextDueDate } from './ppmDueEngine';

export interface ParseResult {
  success: boolean;
  importedAssets: PpmAsset[];
  errors: string[];
  totalRowsProcessed: number;
}

/**
 * Normalizes user/excel input into one of the 6 official PPM departments
 */
export function normalizePpmDepartment(rawDept?: string): { category: PpmDepartmentCategory; nameAr: string } {
  if (!rawDept) {
    return { category: 'general_facilities', nameAr: 'قسم الصيانة العامة وخدمات المنافع' };
  }
  const clean = rawDept.toLowerCase().trim();

  if (clean.includes('طب') || clean.includes('bio') || clean.includes('med') || clean.includes('حاضن') || clean.includes('تنفس')) {
    return { category: 'biomedical', nameAr: 'الصيانة الطبية' };
  }
  if (clean.includes('غاز') || clean.includes('أكسجين') || clean.includes('اكسجين') || clean.includes('gas') || clean.includes('oxygen') || clean.includes('شفط') || clean.includes('ro') || clean.includes('تحلية')) {
    return { category: 'medical_gases', nameAr: 'شبكة الأكسجين والغازات الطبية' };
  }
  if (clean.includes('it') || clean.includes('شبك') || clean.includes('سيرفر') || clean.includes('خوادم') || clean.includes('سنترال') || clean.includes('كمبيوتر')) {
    return { category: 'it_networks', nameAr: 'صيانة الـ IT والشبكات' };
  }
  if (clean.includes('كامير') || clean.includes('cctv') || clean.includes('أمن') || clean.includes('امن') || clean.includes('مراقبة') || clean.includes('بواب') || clean.includes('قفل')) {
    return { category: 'cctv_security', nameAr: 'كاميرات المراقبة والأنظمة الأمنية' };
  }
  if (clean.includes('شرك') || clean.includes('وكيل') || clean.includes('عقد') || clean.includes('رنين') || clean.includes('مقطعي') || clean.includes('contractor') || clean.includes('vendor') || clean.includes('ليزر')) {
    return { category: 'contractor_assets', nameAr: 'أجهزة ومعدات الشركات' };
  }

  return { category: 'general_facilities', nameAr: 'قسم الصيانة العامة وخدمات المنافع' };
}

/**
 * Normalizes frequency string into standard values
 */
export function normalizeFrequency(rawFreq?: string): { freq: PpmAsset['frequency']; days: number } {
  if (!rawFreq) return { freq: 'شهري', days: 30 };
  const clean = rawFreq.toLowerCase().trim();

  if (clean.includes('يوم') || clean.includes('day') || clean.includes('نوبة')) {
    return { freq: 'يومي', days: 1 };
  }
  if (clean.includes('أسبوع') || clean.includes('اسبوع') || clean.includes('week')) {
    return { freq: 'أسبوعي', days: 7 };
  }
  if (clean.includes('3') || clean.includes('ربع') || clean.includes('quarter')) {
    return { freq: 'كل 3 أشهر', days: 90 };
  }
  if (clean.includes('6') || clean.includes('نصف') || clean.includes('semi')) {
    return { freq: 'كل 6 أشهر', days: 180 };
  }
  if (clean.includes('سنو') || clean.includes('year') || clean.includes('annual')) {
    return { freq: 'سنوي', days: 365 };
  }
  if (clean.includes('موسم') || clean.includes('season')) {
    return { freq: 'موسمي', days: 90 };
  }

  return { freq: 'شهري', days: 30 };
}

/**
 * Flexible column locator by searching aliases
 */
function findValueByAliases(row: Record<string, any>, aliases: string[]): any {
  const keys = Object.keys(row);
  for (const alias of aliases) {
    const matchedKey = keys.find(k => k.trim().toLowerCase() === alias.toLowerCase() || k.trim().includes(alias));
    if (matchedKey && row[matchedKey] !== undefined && row[matchedKey] !== null && String(row[matchedKey]).trim() !== '') {
      return row[matchedKey];
    }
  }
  return undefined;
}

/**
 * Parses an Excel or CSV file
 */
export async function parseExcelOrCsvFile(file: File): Promise<ParseResult> {
  const errors: string[] = [];
  const importedAssets: PpmAsset[] = [];

  try {
    const arrayBuffer = await file.arrayBuffer();
    const workbook = XLSX.read(arrayBuffer, { type: 'array' });
    
    if (!workbook.SheetNames || workbook.SheetNames.length === 0) {
      return { success: false, importedAssets: [], errors: ['الملف فارغ أو لا يحتوي على أوراق عمل'], totalRowsProcessed: 0 };
    }

    const firstSheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[firstSheetName];
    const rawRows = XLSX.utils.sheet_to_json<Record<string, any>>(worksheet, { defval: '' });

    if (!rawRows || rawRows.length === 0) {
      return { success: false, importedAssets: [], errors: ['لم يتم العثور على أسطر بيانات في ورقة العمل الأولى'], totalRowsProcessed: 0 };
    }

    const todayStr = new Date().toISOString().split('T')[0];

    rawRows.forEach((row, idx) => {
      // Find asset code / tag
      const assetTag = findValueByAliases(row, [
        'كود الأصل', 'كود الاصل', 'كود الجهاز', 'كود المعدة', 'رمز الأصل', 'رمز', 'كود', 'asset tag', 'asset id', 'tag', 'code', 'id'
      ]);

      // Find equipment name
      const name = findValueByAliases(row, [
        'اسم المعدة', 'اسم الجهاز', 'اسم النظام', 'المعدة', 'الجهاز', 'النظام التفتيشي', 'اسم الأصل', 'equipment name', 'device name', 'name', 'asset name'
      ]);

      if (!name && !assetTag) {
        // Skip empty row
        return;
      }

      const rawDept = findValueByAliases(row, [
        'القسم المسؤول', 'القسم', 'الإدارة', 'department', 'dept', 'category', 'program'
      ]);

      const rawFreq = findValueByAliases(row, [
        'دورية الفحص', 'الدورية', 'التكرار', 'frequency', 'period'
      ]);

      const location = findValueByAliases(row, [
        'الموقع', 'المكان', 'نطاق وتغطية', 'الغرفة', 'الدور', 'location', 'coverage', 'room', 'floor'
      ]) || 'مباني المستشفى الرئيسية';

      const model = findValueByAliases(row, [
        'الموديل', 'طراز', 'الشركة المصنعة', 'model', 'manufacturer'
      ]) || '';

      const serial = findValueByAliases(row, [
        'الرقم التسلسلي', 'السيريال', 'serial number', 's/n', 'sn'
      ]) || '';

      const notes = findValueByAliases(row, [
        'طبيعة الفحص', 'الملاحظات', 'ملاحظات', 'notes', 'inspection nature'
      ]) || '';

      const responsible = findValueByAliases(row, [
        'مسؤولية التنفيذ المباشر', 'المسؤول', 'الفني', 'responsible', 'engineer'
      ]) || 'مهندس الصيانة والمرافق FMS';

      const generatedTag = String(assetTag || `AZ-DEV-${String(idx + 1).padStart(3, '0')}`).trim();
      const generatedName = String(name || `معدة فنية رقم ${idx + 1}`).trim();
      
      const { category, nameAr } = normalizePpmDepartment(String(rawDept || ''));
      const { freq, days } = normalizeFrequency(String(rawFreq || ''));

      const nextDue = computeNextDueDate(todayStr, freq);

      const parsedAsset: PpmAsset = {
        id: `imp-${Date.now()}-${idx}-${Math.random().toString(36).substring(2, 6)}`,
        asset_tag: generatedTag,
        name: generatedName,
        category,
        categoryNameAr: nameAr,
        location: String(location).trim(),
        frequency: freq,
        frequencyDays: days,
        last_pm_date: todayStr,
        next_pm_due: nextDue,
        responsible_role: String(responsible).trim(),
        model: String(model).trim() || undefined,
        serial_number: String(serial).trim() || undefined,
        notes: String(notes).trim() || undefined,
        checklist_steps: [
          { id: 1, step_text: 'الفحص البصري والتشغيلي العام للهيكل والتوصيلات', expected_value: 'سليم ومطابق' },
          { id: 2, step_text: 'اختبار كفاءة التشغيل تحت الحمل والأداء القياسي', expected_value: 'يعمل بكفاءة 100%' },
          { id: 3, step_text: 'معايرة المؤشرات وقراءات السلامة الكهربائية والميكانيكية', expected_value: 'معاير ومطابق للمعايير' },
          { id: 4, step_text: 'التأكد من نظافة الفلاتر أو المكونات الداخلية وتأريض الجهاز', expected_value: 'نظيف ومؤرض بالكامل' },
          { id: 5, step_text: 'توثيق ملصق الفحص الدوري وتحديث تاريخ الصيانة القادمة', expected_value: 'ملصق معتمد' }
        ]
      };

      importedAssets.push(parsedAsset);
    });

    return {
      success: importedAssets.length > 0,
      importedAssets,
      errors,
      totalRowsProcessed: rawRows.length
    };
  } catch (err: any) {
    return {
      success: false,
      importedAssets: [],
      errors: [`فشل في قراءة ومعالجة الملف: ${err?.message || 'تنسيق غير مدعوم'}`],
      totalRowsProcessed: 0
    };
  }
}

/**
 * Parses text extracted from a PDF or text file
 */
export async function parsePdfOrTextFile(file: File): Promise<ParseResult> {
  try {
    const text = await file.text();
    const lines = text.split(/\r?\n/).map(l => l.trim()).filter(l => l.length > 0);
    
    const importedAssets: PpmAsset[] = [];
    const todayStr = new Date().toISOString().split('T')[0];

    // Regex to match Azal asset codes like AZ-HVAC-01, AZ-GEN-01, AZ-BIO-03, etc.
    const tagRegex = /AZ-([A-Z0-9]+)-([0-9]+)/i;

    let currentTag = '';
    let currentName = '';

    lines.forEach((line, idx) => {
      const match = line.match(tagRegex);
      if (match) {
        currentTag = match[0].toUpperCase();
        // The rest of the line or next tokens could be name
        const cleanName = line.replace(tagRegex, '').replace(/[—\-:•]/g, '').trim();
        currentName = cleanName || `معدة / نظام ${currentTag}`;

        const { category, nameAr } = normalizePpmDepartment(line);
        const { freq, days } = normalizeFrequency(line);

        importedAssets.push({
          id: `imp-pdf-${Date.now()}-${idx}`,
          asset_tag: currentTag,
          name: currentName,
          category,
          categoryNameAr: nameAr,
          location: 'مبنى مستشفى آزال النموذجي',
          frequency: freq,
          frequencyDays: days,
          last_pm_date: todayStr,
          next_pm_due: computeNextDueDate(todayStr, freq),
          responsible_role: 'فني الصيانة والمرافق المختص',
          checklist_steps: [
            { id: 1, step_text: 'الفحص الميداني الدقيق ومطابقة معايير السلامة', expected_value: 'مطابق' },
            { id: 2, step_text: 'اختبار الأداء التشغيلي ومعايرة القراءات', expected_value: 'ناجح' },
            { id: 3, step_text: 'توثيق الفحص واعتماد ملصق الصيانة الوقائية', expected_value: 'معتمد' }
          ]
        });
      }
    });

    if (importedAssets.length === 0) {
      // Fallback: try parsing CSV style lines
      return parseExcelOrCsvFile(file);
    }

    return {
      success: true,
      importedAssets,
      errors: [],
      totalRowsProcessed: lines.length
    };
  } catch (err: any) {
    return {
      success: false,
      importedAssets: [],
      errors: [`تعذر استخراج البيانات من ملف PDF/نص: ${err?.message || ''}`],
      totalRowsProcessed: 0
    };
  }
}
