import { SafetyViolationNotice } from '../types';

export interface OverdueAnalysis {
  isOverdue: boolean; // Past deadline and not resolved/responded
  isPastDeadline: boolean;
  overdueDays: number; // e.g. 1, 2, 3...
  overdueHours: number;
  overdueBadgeText: string; // e.g. "⚠️ منتهية المهلة - متأخر عن التنفيذ"
  overdueDaysText: string; // e.g. "متأخر 3 أيام"
  deadlineFormatted: string; // Clean readable deadline
  deadlineTimestamp: number;
}

/**
 * Parses deadline from date string, timestamp, or hours offset
 */
export function parseDeadlineTimestamp(
  deadlineAt?: string,
  createdTimestamp?: number,
  deadlineHours?: number
): number {
  // 1. If timestamp & deadlineHours exist, calculate precisely
  if (createdTimestamp && deadlineHours && deadlineHours > 0) {
    const calculated = createdTimestamp + deadlineHours * 3600 * 1000;
    if (!isNaN(calculated) && calculated > 0) {
      return calculated;
    }
  }

  if (!deadlineAt) {
    return createdTimestamp ? createdTimestamp + 24 * 3600 * 1000 : Date.now();
  }

  // Normalize Arabic-Indic digits ٠-٩ to 0-9
  const normalized = deadlineAt
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 1632))
    .replace(/[ص]/g, 'AM')
    .replace(/[م]/g, 'PM')
    .trim();

  // Try direct Date parsing
  const parsed = new Date(normalized).getTime();
  if (!isNaN(parsed) && parsed > 0) {
    return parsed;
  }

  // Match YYYY-MM-DD or YYYY/MM/DD
  const matchYMD = normalized.match(/(\d{4})[/-](\d{1,2})[/-](\d{1,2})/);
  if (matchYMD) {
    const year = parseInt(matchYMD[1], 10);
    const month = parseInt(matchYMD[2], 10) - 1;
    const day = parseInt(matchYMD[3], 10);
    return new Date(year, month, day, 23, 59, 59).getTime();
  }

  // Match DD-MM-YYYY or DD/MM/YYYY
  const matchDMY = normalized.match(/(\d{1,2})[/-](\d{1,2})[/-](\d{4})/);
  if (matchDMY) {
    const day = parseInt(matchDMY[1], 10);
    const month = parseInt(matchDMY[2], 10) - 1;
    const year = parseInt(matchDMY[3], 10);
    return new Date(year, month, day, 23, 59, 59).getTime();
  }

  // Match hours from text: "24 ساعة" or "48 ساعة"
  const matchHours = normalized.match(/(\d+)\s*ساعة/);
  if (matchHours && createdTimestamp) {
    return createdTimestamp + parseInt(matchHours[1], 10) * 3600 * 1000;
  }

  // Match days: "3 أيام"
  const matchDays = normalized.match(/(\d+)\s*يوم/);
  if (matchDays && createdTimestamp) {
    return createdTimestamp + parseInt(matchDays[1], 10) * 24 * 3600 * 1000;
  }

  return createdTimestamp ? createdTimestamp + 24 * 3600 * 1000 : Date.now();
}

/**
 * Smart engine calculating deadline status, overdue delay, and human-readable badges
 */
export function analyzeViolationDeadline(violation: SafetyViolationNotice): OverdueAnalysis {
  const isResolved =
    violation.status === 'resolved' ||
    violation.status === 'responded' ||
    violation.status === 'تمت المعالجة' ||
    (violation as any).status === 'Closed' ||
    Boolean(violation.resolvedAt && violation.resolutionNote);
  const deadlineTimestamp = parseDeadlineTimestamp(
    violation.deadlineAt,
    violation.timestamp,
    violation.deadlineHours
  );

  const now = Date.now();
  const diffMs = now - deadlineTimestamp;
  const isPastDeadline = diffMs > 0;
  const isOverdue = !isResolved && (isPastDeadline || violation.status === 'overdue');

  if (!isOverdue) {
    return {
      isOverdue: false,
      isPastDeadline,
      overdueDays: 0,
      overdueHours: 0,
      overdueBadgeText: isResolved ? '🟢 تمت المعالجة' : '🟡 قيد المتابعة ضمن المهلة',
      overdueDaysText: '',
      deadlineFormatted: violation.deadlineAt || 'ضمن المهلة',
      deadlineTimestamp,
    };
  }

  const overdueHours = Math.max(1, Math.floor(diffMs / (1000 * 60 * 60)));
  const calculatedDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  // If overdue but less than 24h, it's 1 day overdue minimum or several hours
  const overdueDays = Math.max(1, calculatedDays);

  let overdueDaysText = '';
  if (overdueDays === 1) {
    overdueDaysText = 'متأخر يوم واحد';
  } else if (overdueDays === 2) {
    overdueDaysText = 'متأخر يومين';
  } else if (overdueDays >= 3 && overdueDays <= 10) {
    overdueDaysText = `متأخر ${overdueDays} أيام`;
  } else {
    overdueDaysText = `متأخر ${overdueDays} يوماً`;
  }

  return {
    isOverdue: true,
    isPastDeadline: true,
    overdueDays,
    overdueHours,
    overdueBadgeText: '⚠️ منتهية المهلة - متأخر عن التنفيذ',
    overdueDaysText,
    deadlineFormatted: violation.deadlineAt || 'منقضية',
    deadlineTimestamp,
  };
}

/**
 * Common hospital departments for safety & facility management filter
 */
export const POPULAR_DEPARTMENTS = [
  { id: 'all', name: 'عرض كافة الأقسام (الكل)', label: 'كافة الأقسام', icon: '🏥' },
  { id: 'الطوارئ', name: 'الطوارئ والإسعاف', label: 'الطوارئ', icon: '🚨' },
  { id: 'الصيانة العامة', name: 'الصيانة العامة والهندسية', label: 'الصيانة العامة', icon: '🔧' },
  { id: 'الأجهزة الطبية', name: 'الأجهزة الطبية والهندسة الطبية', label: 'الأجهزة الطبية', icon: '🩺' },
  { id: 'العمليات', name: 'العمليات الجراحية الكبرى', label: 'العمليات', icon: '🔪' },
  { id: 'المغسلة', name: 'المغسلة المركزية ومستودع البياضات', label: 'المغسلة', icon: '🧺' },
  { id: 'الأشعة', name: 'الأشعة التشخيصية والتصوير الطبقي', label: 'الأشعة', icon: '🩻' },
  { id: 'العناية المركزة', name: 'العناية المركزة (ICU)', label: 'العناية المركزة', icon: '🫀' },
  { id: 'المختبر وبنك الدم', name: 'المختبر المركزي وبنك الدم', label: 'بنك الدم والمختبر', icon: '🩸' },
  { id: 'الصيدلية', name: 'الصيدلية المركزية ومستودع الأدوية', label: 'الصيدلية', icon: '💊' },
  { id: 'التعقيم المركزي', name: 'التعقيم المركزي (CSSD)', label: 'التعقيم المركزي', icon: '🧼' },
  { id: 'المطبخ', name: 'المطبخ والتغذية العلاجية', label: 'المطبخ', icon: '🍲' },
];
