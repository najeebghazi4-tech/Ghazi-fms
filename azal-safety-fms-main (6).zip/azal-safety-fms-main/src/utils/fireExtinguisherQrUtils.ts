import QRCode from 'qrcode';
import { FireExtinguisherItem } from '../types';
import { AZAL_MASTER_FIRE_EXTINGUISHERS } from '../data/azalHospitalSafetyRegistry';

/**
 * Parses raw decoded QR/Barcode text and matches it to a registered FireExtinguisherItem
 */
export function parseExtinguisherCode(
  rawText: string,
  extinguishers: FireExtinguisherItem[] = []
): FireExtinguisherItem | null {
  if (!rawText || !rawText.trim()) return null;

  const cleaned = rawText.trim();
  const searchPool = extinguishers.length > 0 ? extinguishers : AZAL_MASTER_FIRE_EXTINGUISHERS;

  // 1. Direct ID / Serial exact or lowercase match
  const directMatch = searchPool.find(
    (item) =>
      item.id.toLowerCase() === cleaned.toLowerCase() ||
      item.serialNumber.toLowerCase() === cleaned.toLowerCase()
  );
  if (directMatch) return directMatch;

  // 2. Try parsing JSON if payload is a JSON string
  if (cleaned.startsWith('{') && cleaned.endsWith('}')) {
    try {
      const parsed = JSON.parse(cleaned);
      const targetId = parsed.id || parsed.serialNumber || parsed.serial || parsed.extId;
      if (targetId) {
        const jsonMatch = searchPool.find(
          (item) =>
            item.id.toLowerCase() === String(targetId).toLowerCase() ||
            item.serialNumber.toLowerCase() === String(targetId).toLowerCase()
        );
        if (jsonMatch) return jsonMatch;
      }
    } catch {
      // ignore json parse failure
    }
  }

  // 3. Try parsing URL parameters or hash (#ext=... or ?ext=...)
  if (cleaned.includes('http') || cleaned.includes('#') || cleaned.includes('?')) {
    try {
      const urlLike = cleaned.replace(/^.*[#?]/, '');
      const params = new URLSearchParams(urlLike);
      const extParam = params.get('ext') || params.get('id') || params.get('serial') || params.get('ref');
      if (extParam) {
        const urlMatch = parseExtinguisherCode(extParam, searchPool);
        if (urlMatch) return urlMatch;
      }
    } catch {
      // ignore url parse failure
    }
  }

  // 4. Regex extraction for EXT-AZAL-XXX or EXT-XXX or AZAL-EXT-XXX
  const extRegex = /(?:EXT-AZAL-|EXT-|AZAL-EXT-)(\d{1,3})/i;
  const match = cleaned.match(extRegex);
  if (match && match[1]) {
    const num = parseInt(match[1], 10);
    const formattedCode = `EXT-AZAL-${String(num).padStart(3, '0')}`;
    const found = searchPool.find(
      (item) =>
        item.serialNumber.toLowerCase() === formattedCode.toLowerCase() ||
        item.id.toLowerCase() === formattedCode.toLowerCase()
    );
    if (found) return found;
  }

  // 5. Standalone number match (e.g. "1" or "01" or "28")
  const numOnly = cleaned.replace(/[^0-9]/g, '');
  if (numOnly && numOnly.length <= 3) {
    const num = parseInt(numOnly, 10);
    if (num >= 1 && num <= 28) {
      const formattedCode = `EXT-AZAL-${String(num).padStart(3, '0')}`;
      const found = searchPool.find(
        (item) =>
          item.serialNumber.toLowerCase() === formattedCode.toLowerCase() ||
          item.id.toLowerCase() === formattedCode.toLowerCase()
      );
      if (found) return found;
    }
  }

  // 6. Substring or partial location match as last resort
  const partial = searchPool.find(
    (item) =>
      cleaned.toLowerCase().includes(item.serialNumber.toLowerCase()) ||
      item.serialNumber.toLowerCase().includes(cleaned.toLowerCase())
  );
  if (partial) return partial;

  return null;
}

/**
 * Generates high-res Data URL for a Fire Extinguisher QR code
 */
export async function generateExtinguisherQrDataUrl(serialNumber: string): Promise<string> {
  try {
    return await QRCode.toDataURL(serialNumber.trim(), {
      errorCorrectionLevel: 'M',
      margin: 2,
      width: 280,
      color: {
        dark: '#0f172a',
        light: '#ffffff',
      },
    });
  } catch (err) {
    console.error('Error generating QR code for extinguisher:', err);
    return '';
  }
}
