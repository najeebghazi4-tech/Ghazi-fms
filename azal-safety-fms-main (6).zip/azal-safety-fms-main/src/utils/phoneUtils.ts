/**
 * Utilities for Contact Picker and Yemeni Phone Number formatting,
 * Native Device SMS Protocol (sms:967XXXXXXXXX?body=...) & WhatsApp Intent / Scheme Generation
 */

export const AZAL_SAFETY_OFFICIAL_PHONE = '96777738138';
export const AZAL_SAFETY_LOCAL_PHONE = '777738138';

export function cleanYemeniPhoneNumber(input: string): string {
  if (!input) return '';
  // Remove all non-digits
  let digits = input.replace(/\D/g, '');

  // If starts with 00967, replace with 967
  if (digits.startsWith('00967')) {
    digits = digits.substring(2);
  }

  // If already starts with 967, keep it
  if (digits.startsWith('967')) {
    return digits;
  }

  // If starts with 0 (e.g. 0771234567)
  if (digits.startsWith('0')) {
    digits = digits.substring(1);
  }

  // If it's a 9-digit Yemeni local mobile number (starts with 7)
  if (digits.startsWith('7') && digits.length === 9) {
    return `967${digits}`;
  }

  // If it has 8 or 9 digits without country code
  if (digits.length <= 9) {
    return `967${digits}`;
  }

  return digits;
}

export async function pickContactPhoneNumber(): Promise<{ name?: string; phone?: string } | null> {
  // Check if Contact Picker API is supported
  if (typeof navigator !== 'undefined' && 'contacts' in navigator && 'ContactsManager' in window) {
    try {
      const props = ['name', 'tel'];
      const contacts = await (navigator as any).contacts.select(props, { multiple: false });
      if (contacts && contacts.length > 0) {
        const contact = contacts[0];
        const rawPhone = contact.tel && contact.tel.length > 0 ? contact.tel[0] : '';
        const name = contact.name && contact.name.length > 0 ? contact.name[0] : '';
        return {
          name,
          phone: cleanYemeniPhoneNumber(rawPhone)
        };
      }
    } catch (err) {
      console.warn('Contact picker was cancelled or failed:', err);
    }
  }
  return null;
}

/**
 * Dynamic Public Shared Resolution URL (Hash Router)
 * Uses dynamic origin (window.location.origin) with fallback to official domain:
 * `${window.location.origin}/#resolve?id=${incident.id}`
 */
export function getPublicResolveUrl(
  violationOrIncident: {
    id: string | number;
    publicToken?: string;
    locationDetail?: string;
    department?: string;
    location?: string;
    [key: string]: any;
  } | string | number,
  _useRootQuery: boolean = false
): string {
  let rawId = '';
  if (typeof violationOrIncident === 'object' && violationOrIncident !== null) {
    rawId = String(violationOrIncident.id ?? violationOrIncident.publicToken ?? 'AZAL-VIO-001');
  } else {
    rawId = String(violationOrIncident);
  }
  const id = encodeURIComponent(rawId);
  return `https://azal-safety.netlify.app/#statement?ref=${id}`;
}

export const OFFICIAL_PUBLIC_APP_URL = 'https://azal-safety.netlify.app';
export const OFFICIAL_ADMIN_APP_URL = 'https://azal-safety.ai.studio';

export function getPublicAppBaseUrl(): string {
  // Use the verified production URL for all public endpoints, QR codes, and external access
  return OFFICIAL_PUBLIC_APP_URL;
}

export function getPublicReportUrl(): string {
  return `${OFFICIAL_PUBLIC_APP_URL}/#report`;
}

export function getPublicStatementUrl(refId?: string, location?: string): string {
  const refParam = refId ? `?ref=${encodeURIComponent(refId)}` : '';
  const locParam = location ? `${refParam ? '&' : '?'}loc=${encodeURIComponent(location)}` : '';
  return `${OFFICIAL_PUBLIC_APP_URL}/#statement${refParam}${locParam}`;
}

export function getContractorPermitUrl(): string {
  return `${OFFICIAL_PUBLIC_APP_URL}/#contractor`;
}

export function getAdminDashboardUrl(): string {
  return OFFICIAL_ADMIN_APP_URL;
}

/**
 * Calculates human-readable overdue duration in Arabic
 * Example: 'ساعتين و 15 دقيقة', '3 أيام', '4 ساعات'
 */
export function formatOverdueDurationAr(deadlineAt?: string): string {
  if (!deadlineAt) return '';
  const deadlineTime = new Date(deadlineAt).getTime();
  if (isNaN(deadlineTime)) return '';
  const now = Date.now();
  if (deadlineTime >= now) return '';
  const diffMs = now - deadlineTime;
  const diffMinutes = Math.floor(diffMs / (1000 * 60));
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  if (diffDays > 0) {
    const remHours = diffHours % 24;
    if (diffDays === 1) {
      return remHours > 0 ? `يوم واحد و ${remHours} ساعة` : 'يوم واحد';
    }
    if (diffDays === 2) {
      return remHours > 0 ? `يومين و ${remHours} ساعة` : 'يومين';
    }
    return remHours > 0 ? `${diffDays} أيام و ${remHours} ساعة` : `${diffDays} أيام`;
  }
  if (diffHours > 0) {
    const remMinutes = diffMinutes % 60;
    if (diffHours === 1) {
      return remMinutes > 0 ? `ساعة واحدة و ${remMinutes} دقيقة` : 'ساعة واحدة';
    }
    if (diffHours === 2) {
      return remMinutes > 0 ? `ساعتين و ${remMinutes} دقيقة` : 'ساعتين';
    }
    return `${diffHours} ساعة`;
  }
  return `${Math.max(1, diffMinutes)} دقيقة`;
}

/**
 * Arabic translation for severity levels
 */
export function formatSeverityArabic(severity?: string): string {
  switch (severity?.toLowerCase()) {
    case 'critical':
      return 'حرج جداً';
    case 'high':
      return 'مرتفع';
    case 'medium':
      return 'متوسط';
    case 'low':
      return 'منخفض';
    default:
      return severity || 'مرتفع';
  }
}

/**
 * Official Structured Safety Violation Notice Text Template
 * Formatted with line breaks and dynamic fields:
 * 
 * إشعار وضع مخالف للسلامة
 * رقم الإشعار: {id}
 * المخالفة: {violation_description}
 * الموقع: {location}
 * القسم: {department}
 * الخطورة: {severity}
 * وقت الالتقاط: {capture_timestamp}
 * الإجراء المطلوب: {required_action}
 * رابط إفادة الإنجاز: ${window.location.origin}/#resolve?id={id} (أو https://azal-safety.ai.studio/#resolve?id={id})
 * يرجى فتح الرابط وإرسال إفادة إنجاز العمل من خلال النظام.
 */
export function generateOfficialViolationNoticeText(
  violation: {
    id: string;
    description: string;
    locationDetail?: string;
    department?: string;
    severity?: string;
    createdAt?: string;
    timestamp?: number;
    requiredAction?: string;
    assignedTo?: string;
    assignedToCustom?: string;
    deadlineHours?: number;
    deadlineAt?: string;
  },
  customResolveUrl?: string
): string {
  const id = violation.id;
  const violation_description = violation.description || 'ملاحظة ومخالفة سلامة مرصودة';
  const location = violation.locationDetail || violation.department || 'مستشفى آزال النموذجي';
  
  let deadlineText = '';
  if (violation.deadlineHours) {
    deadlineText = `${violation.deadlineHours} ساعة${violation.deadlineAt ? ` (تنتهي: ${violation.deadlineAt})` : ''}`;
  } else if (violation.deadlineAt) {
    deadlineText = violation.deadlineAt;
  } else {
    deadlineText = 'خلال 24 ساعة';
  }

  const resolveUrl = customResolveUrl || `https://azal-safety.netlify.app/#statement?ref=${encodeURIComponent(id)}`;

  return `مستشفى آزال النموذجي
قسم الأمن والسلامة وإدارة المرافق (FMS)

إشعار معالجة مخاطر:
الرقم المرجعي: ${id}
الموقع: ${location}
الخلل: ${violation_description}
المهلة الزمنية للإنجاز: ${deadlineText}

رابط إفادة الإنجاز والمعالجة:
${resolveUrl}`;
}

/**
 * Official SMS Text for Violations
 */
export function generateOfficialViolationSMSText(
  violation: {
    id: string;
    description: string;
    locationDetail?: string;
    department?: string;
    severity?: string;
    createdAt?: string;
    timestamp?: number;
    requiredAction?: string;
    assignedTo?: string;
    assignedToCustom?: string;
    deadlineHours?: number;
    deadlineAt?: string;
  },
  customResolveUrl?: string
): string {
  return generateOfficialViolationNoticeText(violation, customResolveUrl);
}

/**
 * Official Escalation Warning SMS Text
 */
export function generateEscalationWarningSMSText(
  violation: {
    id: string;
    description: string;
    locationDetail?: string;
    department?: string;
    severity?: string;
    createdAt?: string;
    timestamp?: number;
    requiredAction?: string;
    assignedTo?: string;
    assignedToCustom?: string;
    deadlineAt?: string;
  },
  customResolveUrl?: string
): string {
  const id = violation.id;
  const violation_description = violation.description || 'ملاحظة ومخالفة سلامة مرصودة';
  const location = violation.locationDetail || violation.department || 'مستشفى آزال النموذجي';
  const resolveUrl = customResolveUrl || `https://azal-safety.netlify.app/#statement?ref=${encodeURIComponent(id)}`;

  return `مستشفى آزال النموذجي
قسم الأمن والسلامة وإدارة المرافق (FMS)

إشعار معالجة مخاطر [إنذار عاجل لتجاوز المهلة]:
الرقم المرجعي: ${id}
الموقع: ${location}
الخلل: ${violation_description}
المهلة الزمنية للإنجاز: منقضية (تجاوزت المهلة المقررة: ${violation.deadlineAt || '24 ساعة'})

رابط إفادة الإنجاز والمعالجة:
${resolveUrl}`;
}

/**
 * 3. Short & Clean SMS Template for Incidents
 */
export function generateIncidentSMSText(
  incident: {
    id: string | number;
    categoryAr: string;
    locationDetail: string;
    deadlineAt?: string;
    description?: string;
    department?: string;
    [key: string]: any;
  },
  customResolveUrl?: string
): string {
  const id = String(incident.id);
  const location = incident.locationDetail || incident.department || 'مستشفى آزال النموذجي';
  const description = incident.categoryAr + (incident.description ? ` - ${incident.description}` : '');
  const deadlineText = incident.deadlineAt || 'خلال 24 ساعة';
  const resolveLink = customResolveUrl || `https://azal-safety.netlify.app/#statement?ref=${encodeURIComponent(id)}`;

  return `مستشفى آزال النموذجي
قسم الأمن والسلامة وإدارة المرافق (FMS)

إشعار معالجة مخاطر:
الرقم المرجعي: ${id}
الموقع: ${location}
الخلل: ${description}
المهلة الزمنية للإنجاز: ${deadlineText}

رابط إفادة الإنجاز والمعالجة:
${resolveLink}`;
}

/**
 * 4. Formatted & Detailed WhatsApp Template for Incidents
 */
export function generateIncidentWhatsAppText(
  incident: {
    id: string | number;
    categoryAr: string;
    locationDetail: string;
    department?: string;
    severity?: string;
    reportedAt?: string;
    immediateAction?: string;
    deadlineAt?: string;
    description?: string;
    [key: string]: any;
  },
  customResolveUrl?: string
): string {
  return generateIncidentSMSText(incident, customResolveUrl);
}

/**
 * Generates an SMS URI with encodeURIComponent for direct native launch
 */
export function getIncidentSMSUri(phone: string | undefined, text: string): string {
  const encodedText = encodeURIComponent(text);
  const isIOS = typeof navigator !== 'undefined' && /iPad|iPhone|iPod/.test(navigator.userAgent);
  if (!phone || !phone.trim() || phone === '967') {
    return isIOS ? `sms:;?body=${encodedText}` : `sms:?body=${encodedText}`;
  }
  const cleanedPhone = cleanYemeniPhoneNumber(phone);
  return isIOS
    ? `sms:${cleanedPhone};?body=${encodedText}`
    : `sms:${cleanedPhone}?body=${encodedText}`;
}

/**
 * Generates a WhatsApp URL with encodeURIComponent for direct launching
 */
export function getIncidentWhatsAppUrl(phone: string | undefined, text: string): string {
  const encodedText = encodeURIComponent(text);
  if (!phone || !phone.trim() || phone === '967') {
    return `https://wa.me/?text=${encodedText}`;
  }
  const cleanedPhone = cleanYemeniPhoneNumber(phone);
  return `https://wa.me/${cleanedPhone}?text=${encodedText}`;
}

export function openIncidentSMS(phone: string | undefined, text: string) {
  const smsUri = getIncidentSMSUri(phone, text);
  try {
    const link = document.createElement('a');
    link.href = smsUri;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    setTimeout(() => {
      if (document.body.contains(link)) {
        document.body.removeChild(link);
      }
    }, 500);
  } catch {
    window.location.href = smsUri;
  }
}

export function openIncidentWhatsApp(phone: string | undefined, text: string) {
  const waUrl = getIncidentWhatsAppUrl(phone, text);
  window.open(waUrl, '_blank', 'noopener,noreferrer');
}

export function generateIncidentAlertSMSText(
  incident: {
    id?: string;
    codeNumber: string;
    categoryAr: string;
    locationDetail: string;
    severity?: string;
    immediateAction?: string;
    [key: string]: any;
  }
): string {
  return generateIncidentSMSText({
    id: incident.id || incident.codeNumber || '1',
    categoryAr: incident.categoryAr,
    locationDetail: incident.locationDetail,
  });
}

/**
 * Native Device SMS URI Protocol:
 * Android / RFC 5724: sms:967XXXXXXXXX?body=...
 * iOS: sms:967XXXXXXXXX;?body=...
 */
export function getNativeSMSUri(phone: string, text: string): string {
  const cleanedPhone = cleanYemeniPhoneNumber(phone);
  const encodedText = encodeURIComponent(text);
  const isIOS = typeof navigator !== 'undefined' && /iPad|iPhone|iPod/.test(navigator.userAgent);

  return isIOS
    ? `sms:${cleanedPhone};?body=${encodedText}`
    : `sms:${cleanedPhone}?body=${encodedText}`;
}

/**
 * Invokes the Native Device SMS Application directly
 * Pre-populating recipient and message body for 1-tap SIM card sending
 */
export function openNativeSMSDirect(phone: string, text: string) {
  const smsUri = getNativeSMSUri(phone, text);

  try {
    const link = document.createElement('a');
    link.href = smsUri;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    setTimeout(() => {
      if (document.body.contains(link)) {
        document.body.removeChild(link);
      }
    }, 500);
  } catch (e) {
    window.location.href = smsUri;
  }
}

/**
 * Official WhatsApp Text for Violations
 * Exactly matches the requested structure:
 * 
 * إشعار وضع مخالف للسلامة
 * رقم الإشعار: {id}
 * المخالفة: {violation_description}
 * الموقع: {location}
 * القسم: {department}
 * الخطورة: {severity}
 * وقت الالتقاط: {capture_timestamp}
 * الإجراء المطلوب: {required_action}
 * رابط إفادة الإنجاز: ${window.location.origin}/#resolve?id={id} (أو https://azal-safety.ai.studio/#resolve?id={id})
 * يرجى فتح الرابط وإرسال إفادة إنجاز العمل من خلال النظام.
 */
export function generateOfficialViolationWhatsAppText(
  violation: {
    id: string;
    description: string;
    locationDetail?: string;
    department?: string;
    severity?: string;
    createdAt?: string;
    timestamp?: number;
    requiredAction?: string;
    assignedTo?: string;
    assignedToCustom?: string;
    deadlineHours?: number;
    deadlineAt?: string;
  },
  customResolveUrl?: string
): string {
  return generateOfficialViolationNoticeText(violation, customResolveUrl);
}

/**
 * Official Escalation Warning WhatsApp Text
 * Firm reminder and escalation to GM with exact delay counter
 */
export function generateEscalationWarningWhatsAppText(
  violation: {
    id: string;
    description: string;
    locationDetail?: string;
    department?: string;
    severity?: string;
    createdAt?: string;
    timestamp?: number;
    requiredAction?: string;
    assignedTo?: string;
    assignedToCustom?: string;
    deadlineHours?: number;
    deadlineAt?: string;
  },
  customResolveUrl?: string
): string {
  const id = violation.id;
  const violation_description = violation.description || 'ملاحظة ومخالفة سلامة مرصودة';
  const location = violation.locationDetail || violation.department || 'مستشفى آزال';
  const department = violation.department || 'القسم المعني';
  const severity = formatSeverityArabic(violation.severity);
  const party = violation.assignedToCustom || violation.assignedTo || 'رئيس القسم المكلف';
  const overdueDuration = formatOverdueDurationAr(violation.deadlineAt);
  const delayCounterText = overdueDuration ? `(متأخرة منذ: ${overdueDuration})` : '(متجاوزة للمهلة المحددة)';
  const resolveUrl = customResolveUrl || getPublicResolveUrl(violation);

  return `🚨 *إنذار وتذكير شديد اللهجة - تجاوز مهلة المعالجة وتصعيد للإدارة العليا* 🚨
*إدارة الأمن والسلامة والصحة المهنية - مستشفى آزال النموذجي*

إلى الأخ المكلف / رئيس قسم: *${party}*
نفيدكم بأن مهلة المعالجة الممنوحة لإشعار السلامة رقم: *${id}* قد *انتهت تماماً ${delayCounterText}* دون تسجيل إفادة إنجاز معتمدة حتى هذه اللحظة!

📌 *تفاصيل المخالفة المعلقة:*
• رقم الإشعار: ${id}
• القسم: ${department}
• الموقع: ${location}
• وصف المخالفة: ${violation_description}
• درجة الخطورة: ${severity}
• المهلة المحددة: ${violation.deadlineAt || 'منقضية'}
• عداد التأخير الحالي: 🔴 *${overdueDuration || 'متجاوز للمهلة'}*

⚠️ *المطلوب فوراً وبشكل عاجل:*
معالجة وتصحيح وضع المخالفة فوراً دون أي إبطاء، وتأمين الموقع، ورفع إفادة الإنجاز والصورة بعد التصحيح عبر الرابط المعتمد أدناه لتفادي الرفع المباشر للمدير العام وتطبيق الإجراءات والمساءلة الإدارية:

🔗 *رابط إفادة الإنجاز السريع:*
${resolveUrl}

_ملاحظة: هذا الإشعار مسجل ومؤرخ في المنظومة الرقابية الإلكترونية لمستشفى آزال._`;
}

/**
 * Returns the universal WhatsApp direct URL for sending
 */
export function getWhatsAppDirectUrl(phone: string, text: string): string {
  const cleanedPhone = cleanYemeniPhoneNumber(phone);
  const encodedText = encodeURIComponent(text);
  return `https://api.whatsapp.com/send?phone=${cleanedPhone}&text=${encodedText}`;
}

/**
 * Opens the WhatsApp application directly with clean URL-encoded text
 */
export function openWhatsAppDirect(phone: string, text: string) {
  const cleanedPhone = cleanYemeniPhoneNumber(phone);
  const encodedText = encodeURIComponent(text);

  const apiWebUrl = `https://api.whatsapp.com/send?phone=${cleanedPhone}&text=${encodedText}`;
  const schemeUrl = `whatsapp://send?phone=${cleanedPhone}&text=${encodedText}`;
  const intentUrl = `intent://send?phone=${cleanedPhone}&text=${encodedText}#Intent;package=com.whatsapp;scheme=whatsapp;end;`;

  const isAndroid = typeof navigator !== 'undefined' && /android/i.test(navigator.userAgent);
  const isIOS = typeof navigator !== 'undefined' && /iphone|ipad|ipod/i.test(navigator.userAgent);

  if (isAndroid) {
    try {
      window.location.href = schemeUrl;
      setTimeout(() => {
        try {
          window.location.href = intentUrl;
        } catch {
          window.open(apiWebUrl, '_blank');
        }
      }, 400);
      return;
    } catch (e) {
      window.open(apiWebUrl, '_blank');
      return;
    }
  }

  if (isIOS) {
    window.location.href = schemeUrl;
    setTimeout(() => {
      window.open(apiWebUrl, '_blank');
    }, 800);
    return;
  }

  // Desktop or browser fallback:
  window.open(apiWebUrl, '_blank');
}
