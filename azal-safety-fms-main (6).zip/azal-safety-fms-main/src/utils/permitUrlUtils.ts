import { ContractorPermitNotice } from '../types';
import { getPublicAppBaseUrl } from './phoneUtils';

export const STANDARD_SAFETY_PRECAUTIONS = [
  'توفير طفاية حريق يدوية مناسبة بالموقع (بودرة كيميائية جافة / CO2) صالحة للاستخدام',
  'إلزام كافة العمال بارتداء مهمات الوقاية الشخصية PPE الكاملة (خوذة، حذاء أمان، قفازات، نظارات)',
  'تصريح أعمال ساخنة إضافي معتمد (Hot Work Permit) ومراقبة مستمرة لموقع اللحام والقص',
  'فصل وتأمين مصادر الطاقة الكهربائية وتطبيق إجراءات العزل الآمن (Lockout / Tagout)',
  'عزل وتطويق منطقة العمل بأشرطة تحذيرية صفراء ومنع دخول المرضى أو الزوار للموقع',
  'تأمين التهوية الميكانيكية المناسبة في الأماكن المغلقة ومراقبة نسبة الأكسجين والغازات',
  'تعيين مراقب سلامة مؤهل من طرف المقاول يتواجد بالموقع طوال فترة سريان الأعمال',
  'إيقاف الأعمال فوراً عند سماع جرس الإنذار أو إعلان أي رمز طوارئ بالمستشفى (مثل كود أحمر)',
  'حظر التدخين أو إشعال أي لهب مكشوف حظراً قاطعاً في كافة مرافق ومباني المستشفى',
  'تنظيف الموقع وإخلائه يومياً من أي مخلفات سريعة الاشتعال أو زيوت قبل مغادرة الوردية',
  'التنسيق المباشر مع رئيس القسم وضابط أمن المستشفى قبل الدخول بالمعدات الثقيلة'
];

/**
 * Builds a standalone, self-contained verification URL for contractor permit.
 * Carries all critical approval parameters in query strings so that even if opened
 * on a phone without localStorage (e.g. security gate guard), it renders immediately!
 */
export function buildPermitVerificationUrl(
  permit: ContractorPermitNotice,
  baseUrl?: string
): string {
  const origin = baseUrl || getPublicAppBaseUrl();

  const params = new URLSearchParams();
  params.set('id', permit.id);

  if (permit.permitNumber) {
    params.set('pno', permit.permitNumber);
  } else {
    params.set('pno', `AZAL-PERMIT-2026-${permit.id.replace(/\D/g, '').slice(-4) || '1088'}`);
  }

  params.set('cname', permit.contractorName);
  params.set('dept', permit.department);
  params.set('wtype', permit.workType);
  params.set('scope', permit.workDescription);
  params.set('wcount', String(permit.workersCount || 1));
  params.set('workers', permit.workersNames || '');
  params.set('start', permit.expectedStartDate);
  params.set('end', permit.expectedEndDate);

  if (permit.workingHours) {
    params.set('hours', permit.workingHours);
  } else {
    params.set('hours', '08:00 صباحاً - 04:00 عصراً');
  }

  params.set('status', permit.status);
  params.set('by', permit.approvedBy || 'رئيس قسم الأمن والسلامة / م. نجيب غازي');

  if (permit.approvedAt) {
    params.set('at', permit.approvedAt);
  }

  const precautions =
    permit.approvalPrecautions && permit.approvalPrecautions.length > 0
      ? permit.approvalPrecautions
      : permit.safetyMeasures && permit.safetyMeasures.length > 0
      ? permit.safetyMeasures
      : STANDARD_SAFETY_PRECAUTIONS.slice(0, 4);

  params.set('precautions', JSON.stringify(precautions));

  if (permit.contactPhone) {
    params.set('phone', permit.contactPhone);
  }

  if (permit.safetyNotes) {
    params.set('notes', permit.safetyNotes);
  }

  return `${origin}/#permit?${params.toString()}`;
}

/**
 * Parses permit parameters from URL search string or hash
 */
export function parsePermitFromUrl(urlPathOrHash: string): Partial<ContractorPermitNotice> | null {
  if (!urlPathOrHash) return null;

  let queryStr = '';
  if (urlPathOrHash.includes('?')) {
    queryStr = urlPathOrHash.split('?')[1];
  } else if (urlPathOrHash.includes('#')) {
    const afterHash = urlPathOrHash.split('#')[1];
    if (afterHash.includes('?')) {
      queryStr = afterHash.split('?')[1];
    }
  }

  if (!queryStr) return null;

  const params = new URLSearchParams(queryStr);
  const id = params.get('id') || params.get('permitId') || params.get('pno');
  if (!id) return null;

  let parsedPrecautions: string[] = [];
  const rawPrecautions = params.get('precautions');
  if (rawPrecautions) {
    try {
      parsedPrecautions = JSON.parse(rawPrecautions);
    } catch {
      parsedPrecautions = rawPrecautions.split(',').map((s) => s.trim()).filter(Boolean);
    }
  }

  return {
    id: id,
    permitNumber: params.get('pno') || undefined,
    contractorName: params.get('cname') || 'مقاول معتمد',
    department: params.get('dept') || 'مستشفى آزال النموذجي',
    workType: (params.get('wtype') as any) || 'civil_maintenance',
    workDescription: params.get('scope') || 'أعمال هندسية وصيانة مصرح بها',
    workersCount: Number(params.get('wcount')) || 1,
    workersNames: params.get('workers') || 'العمال المصرح لهم بموجب الهويات المرفقة',
    expectedStartDate: params.get('start') || new Date().toISOString(),
    expectedEndDate: params.get('end') || new Date().toISOString(),
    workingHours: params.get('hours') || '08:00 صباحاً - 04:00 عصراً',
    status: (params.get('status') as any) || 'approved',
    approvedBy: params.get('by') || 'رئيس قسم الأمن والسلامة / م. نجيب غازي',
    approvedAt: params.get('at') || undefined,
    approvalPrecautions: parsedPrecautions.length > 0 ? parsedPrecautions : undefined,
    safetyMeasures: parsedPrecautions,
    contactPhone: params.get('phone') || '',
    safetyNotes: params.get('notes') || undefined,
  };
}

/**
 * Generates an official WhatsApp formatted message for contractor / gate approval
 */
export function getPermitWhatsAppShareText(
  permit: ContractorPermitNotice,
  permitUrl: string
): string {
  const pno = permit.permitNumber || `AZAL-PERMIT-2026-${permit.id.replace(/\D/g, '').slice(-4) || '1088'}`;
  const hours = permit.workingHours || '08:00 صباحاً - 04:00 عصراً';
  const precautions =
    permit.approvalPrecautions && permit.approvalPrecautions.length > 0
      ? permit.approvalPrecautions
      : permit.safetyMeasures || [];

  const topPrecautions = precautions.slice(0, 4).map((p) => `• ${p}`).join('\n');

  return `🏥 *مستشفى آزال النموذجي - إدارة الأمن والسلامة المهنية*
📋 *تصريح عمل ودخول مقاول معتمد (تصريح رسمي)*

✅ *رقم الاعتماد الرسمي:* ${pno}
🏢 *المقاول / الجهة المنفذة:* ${permit.contractorName}
📍 *القسم والموقع:* ${permit.department}
🔨 *طبيعة الأعمال المصرح بها:* ${permit.workDescription}
👥 *عدد العمال المصرح لهم:* (${permit.workersCount}) عمال
⏰ *ساعات العمل المصرح بها:* ${hours}
📅 *تاريخ التصريح:* من ${permit.expectedStartDate.replace('T', ' ')} إلى ${permit.expectedEndDate.replace('T', ' ')}

⚠️ *اشتراطات السلامة الإلزامية المطلوب التقيد بها:*
${topPrecautions}

🛡️ *رابط وثيقة التصريح الرقمية المعتمدة (فحص مباشر):*
${permitUrl}

📌 *توجيه لحراسة البوابة الأمنية بالمستشفى:*
يُسمح للمقاول والعمال المذكورين بالدخول ومباشرة الأعمال المحددة بعد التحقق من بطاقات الهوية والتزامهم بمهمات الوقاية PPE.

✍️ *رئيس قسم الأمن والسلامة:*
م. نجيب غازي - مستشفى آزال النموذجي`;
}
