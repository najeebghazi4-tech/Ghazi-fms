/**
 * Print & PDF Utilities for Azal Model Hospital Safety & Security System
 * Provides robust printing across mobile browsers, desktop, and iframe preview environments
 * with official institutional letterhead, pure white high-contrast styling, and verified leadership signatures.
 */

export interface PrintDocumentOptions {
  title: string;
  subtitle?: string;
  refNumber?: string;
  date?: string;
  inspectorName?: string;
  department?: string;
  customHeaderHtml?: string;
  customFooterHtml?: string;
}

const AZAL_LOGO_SVG = `
<svg width="220" height="92" viewBox="0 0 1120 480" fill="none" xmlns="http://www.w3.org/2000/svg" style="background: transparent; display: block; margin: 0 auto; max-width: 100%; height: auto; max-height: 90px;">
  <defs>
    <linearGradient id="printLeafGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#88C542" />
      <stop offset="45%" stop-color="#65B334" />
      <stop offset="100%" stop-color="#2E8E28" />
    </linearGradient>
    <linearGradient id="printLightLeaf" x1="0%" y1="100%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#72BA3B" />
      <stop offset="50%" stop-color="#8CE03C" />
      <stop offset="100%" stop-color="#B2F562" />
    </linearGradient>
    <linearGradient id="printRoseGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#EF4444" />
      <stop offset="40%" stop-color="#DC2626" />
      <stop offset="100%" stop-color="#991B1B" />
    </linearGradient>
    <radialGradient id="printOrangeDot" cx="35%" cy="30%" r="70%">
      <stop offset="0%" stop-color="#FFAE34" />
      <stop offset="55%" stop-color="#F58220" />
      <stop offset="100%" stop-color="#C84800" />
    </radialGradient>
  </defs>

  <!-- Left: Official Framed Paper Shield (From Official Hospital Stationery) -->
  <g transform="translate(42, 16)">
    <!-- Outer Shield Body: Rounded Top-Left (R=48) & Rounded Bottom-Right (R=48) -->
    <path d="M 88 10 L 330 10 L 330 330 A 48 48 0 0 1 282 378 L 40 378 L 40 58 A 48 48 0 0 1 88 10 Z" fill="#FFFFFF" stroke="#65B334" stroke-width="3" />
    <path d="M 92 18 L 322 18 L 322 322 A 40 40 0 0 1 282 368 L 48 368 L 48 60 A 40 40 0 0 1 92 18 Z" fill="none" stroke="#88C542" stroke-width="1.2" opacity="0.9" />

    <!-- Floral Loop & Z Leaves Inside Shield -->
    <g transform="translate(18, 0)">
      <path d="M 168 238 C 118 238, 70 204, 56 154 C 42 98, 68 46, 122 22 C 168 2, 224 12, 260 50 C 272 64, 276 82, 272 98 C 266 120, 246 132, 226 132 C 202 132, 188 116, 194 96 C 200 82, 214 72, 230 70 C 210 44, 162 36, 126 50 C 84 70, 68 116, 80 158 C 90 196, 132 218, 176 218 C 192 218, 206 212, 218 204 L 228 218 C 212 234, 194 238, 168 238 Z" fill="url(#printLeafGrad)" />
      <path d="M 68 144 C 60 108, 76 72, 114 52 C 148 34, 192 40, 222 62 C 210 64, 198 72, 194 84 C 158 60, 108 68, 88 102 C 76 122, 74 141, 77 156 Z" fill="url(#printLightLeaf)" opacity="0.9" />
      <!-- Crimson Rosebud -->
      <path d="M 236 96 C 232 74, 246 58, 262 52 C 260 66, 262 84, 252 98 Z" fill="#65B334" />
      <path d="M 246 84 C 244 64, 262 48, 278 42 C 286 50, 288 66, 282 80 C 274 94, 258 100, 246 84 Z" fill="url(#printRoseGrad)" />
      <path d="M 268 84 C 280 74, 288 62, 292 48 C 294 62, 290 78, 278 92 Z" fill="#3B9928" />
      <path d="M 250 100 C 240 132, 216 166, 196 196 C 192 202, 188 206, 182 212" fill="none" stroke="#65B334" stroke-width="6" stroke-linecap="round" />
      <!-- Z Leaves -->
      <path d="M 220 142 C 186 124, 150 130, 128 146 C 152 152, 190 154, 214 150 Z" fill="url(#printLightLeaf)" />
      <path d="M 204 148 L 164 204" stroke="#72BA3B" stroke-width="5" stroke-linecap="round" />
      <path d="M 164 201 C 184 206, 214 216, 228 236 C 210 236, 184 228, 166 212 Z" fill="url(#printLightLeaf)" />
      <path d="M 204 174 C 168 164, 136 178, 118 200 C 142 202, 176 196, 198 182 Z" fill="url(#printLeafGrad)" />
      <!-- Typography -->
      <g transform="translate(168, 294)">
        <text x="0" y="0" font-family="'Arial Black', 'Montserrat', Impact, sans-serif" font-size="44" font-weight="900" letter-spacing="6" fill="#000000" text-anchor="middle">AZAL</text>
        <text x="0" y="32" font-family="'Segoe UI', 'Montserrat', Arial, sans-serif" font-size="23" font-weight="700" letter-spacing="1.5" fill="#000000" text-anchor="middle">Hospital</text>
      </g>
    </g>

    <!-- Bottom Green Accent Banner Tab -->
    <g transform="translate(48, 392)">
      <path d="M 14 0 L 260 0 A 14 14 0 0 1 274 14 L 274 24 A 14 14 0 0 1 260 38 L 22 38 A 22 22 0 0 1 0 16 L 0 14 A 14 14 0 0 1 14 0 Z" fill="#88C542" stroke="#65B334" stroke-width="1.5" />
      <text x="137" y="25" font-family="'Cairo', 'Tajawal', Arial, sans-serif" font-size="14" font-weight="800" fill="#FFFFFF" letter-spacing="0.5" text-anchor="middle">الـرعــايـة الـكـامـلـة • COMPLETE CARE</text>
    </g>
  </g>

  <!-- Center Divider Line -->
  <line x1="435" y1="35" x2="435" y2="445" stroke="#94A3B8" stroke-width="2.5" stroke-linecap="round" opacity="0.8" />

  <!-- Right: Arabic Identity -->
  <g transform="translate(480, 20)">
    <g fill="#000000">
      <circle cx="330" cy="38" r="6.5" />
      <circle cx="356" cy="38" r="6.5" />
      <circle cx="382" cy="38" r="6.5" />
      <circle cx="408" cy="38" r="6.5" />
      <circle cx="434" cy="38" r="6.5" />
      <circle cx="460" cy="38" r="6.5" />
    </g>
    <text x="520" y="86" font-family="'Cairo', 'Tajawal', 'Almarai', Arial, sans-serif" font-size="58" font-weight="900" fill="#000000" direction="rtl" text-anchor="end">مُـسْـتَـشْـفَى</text>

    <!-- Geometric Name أزال -->
    <g transform="translate(60, 130)">
      <rect x="424" y="20" width="34" height="132" rx="16" fill="#000000" />
      <path d="M 334 20 L 334 100 C 334 134, 308 152, 274 152 C 260 152, 248 146, 240 137 C 233 129, 237 118, 248 118 C 256 118, 265 123, 274 123 C 292 123, 300 110, 300 95 L 300 20 C 300 11, 308 3, 317 3 C 326 3, 334 11, 334 20 Z" fill="#000000" />
      <circle cx="317" cy="-24" r="22" fill="url(#printOrangeDot)" />
      <path d="M 276 -52 C 296 -74, 342 -74, 362 -54 C 334 -47, 305 -46, 276 -52 Z" fill="url(#printLeafGrad)" />
      <path d="M 288 -54 C 304 -66, 335 -66, 350 -56 C 330 -52, 308 -52, 288 -54 Z" fill="url(#printLightLeaf)" opacity="0.8" />
      <rect x="180" y="20" width="34" height="132" rx="16" fill="#000000" />
      <path d="M 90 20 L 90 108 C 90 134, 72 152, 46 152 L 16 152 C 7 152, 0 145, 0 136 C 0 127, 7 120, 16 120 L 44 120 C 52 120, 56 114, 56 106 L 56 20 C 56 11, 64 3, 73 3 C 82 3, 90 11, 90 20 Z" fill="#000000" />
    </g>

    <text x="520" y="410" font-family="'Cairo', 'Tajawal', 'Almarai', Arial, sans-serif" font-size="46" font-weight="800" fill="#000000" direction="rtl" text-anchor="end">الـرعــايـة الـكـامـلـة</text>
  </g>
</svg>
`;

/**
 * Builds standard Azal Hospital institutional print wrapper HTML
 */
export function buildPrintableHtml(contentHtml: string, options: PrintDocumentOptions): string {
  const dateStr = options.date || new Date().toLocaleDateString('ar-YE', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
  const refCode = options.refNumber || `AZAL-DOC-${Date.now().toString().slice(-6)}`;
  const subtitle = options.subtitle || 'إدارة الأمن والسلامة المهنية وإدارة المرافق (FMS) • معتمد لمعايير CBAHI';

  return `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>${options.title} - مستشفى آزال النموذجي</title>
  <style>
    @page {
      size: A4 portrait;
      margin: 12mm 10mm 15mm 10mm;
    }
    *, *::before, *::after {
      box-sizing: border-box;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, Tahoma, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #ffffff;
      color: #0f172a;
      line-height: 1.5;
      font-size: 12px;
      direction: rtl;
    }
    .print-wrapper {
      width: 100%;
      max-width: 210mm;
      margin: 0 auto;
      padding: 12px;
      position: relative;
    }
    /* Official Corner Registration Marks (as on Azal Hospital stationery) */
    .corner-mark {
      position: absolute;
      width: 16px;
      height: 16px;
      border-color: #94a3b8;
      border-style: solid;
      pointer-events: none;
      opacity: 0.8;
    }
    .corner-mark.top-right { top: 2px; right: 2px; border-width: 2px 2px 0 0; }
    .corner-mark.top-left { top: 2px; left: 2px; border-width: 2px 0 0 2px; }
    .corner-mark.bottom-right { bottom: 2px; right: 2px; border-width: 0 2px 2px 0; }
    .corner-mark.bottom-left { bottom: 2px; left: 2px; border-width: 0 0 2px 2px; }

    /* Official Institutional Letterhead */
    .hospital-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-bottom: 2.5px solid #65b334;
      padding-bottom: 12px;
      margin-bottom: 16px;
    }
    .header-right {
      text-align: right;
      line-height: 1.4;
      width: 32%;
    }
    .header-right .country { font-size: 11px; font-weight: bold; color: #475569; }
    .header-right .ministry { font-size: 12px; font-weight: bold; color: #0f172a; }
    .header-right .hospital-name { font-size: 16px; font-weight: 900; color: #000000; margin-top: 2px; }
    .header-right .fms-dept { font-size: 11px; font-weight: 700; color: #334155; }
    .header-center {
      text-align: center;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      width: 38%;
    }
    .header-left {
      text-align: left;
      font-size: 11px;
      line-height: 1.4;
      color: #475569;
      font-family: monospace, sans-serif;
      direction: ltr;
      width: 30%;
    }
    .header-left .badge {
      display: inline-block;
      background-color: #f0fdf4;
      border: 1px solid #16a34a;
      color: #166534;
      font-weight: bold;
      padding: 2px 8px;
      border-radius: 4px;
      margin-bottom: 4px;
    }
    /* Document Title Banner */
    .document-title-banner {
      background-color: #f8fafc;
      border: 1px solid #cbd5e1;
      border-right: 5px solid #0f766e;
      padding: 10px 14px;
      border-radius: 6px;
      margin-bottom: 16px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .document-title {
      font-size: 15px;
      font-weight: 900;
      color: #0f172a;
      margin: 0;
    }
    .document-subtitle {
      font-size: 11px;
      color: #64748b;
      margin-top: 2px;
    }
    /* Table Styling */
    table {
      width: 100%;
      border-collapse: collapse;
      margin: 12px 0;
      font-size: 11px;
      page-break-inside: auto;
    }
    tr {
      page-break-inside: avoid;
      break-inside: avoid;
    }
    th {
      background-color: #f1f5f9;
      color: #0f172a;
      font-weight: bold;
      border: 1px solid #94a3b8;
      padding: 6px 8px;
      text-align: right;
    }
    td {
      border: 1px solid #cbd5e1;
      padding: 6px 8px;
      color: #1e293b;
      text-align: right;
    }
    tr:nth-child(even) td {
      background-color: #f8fafc;
    }
    /* Status Badges */
    .badge-success { background: #dcfce7; color: #166534; padding: 2px 6px; border-radius: 4px; font-weight: bold; }
    .badge-danger { background: #fee2e2; color: #991b1b; padding: 2px 6px; border-radius: 4px; font-weight: bold; }
    .badge-warning { background: #fef3c7; color: #92400e; padding: 2px 6px; border-radius: 4px; font-weight: bold; }
    /* Cards and Grids */
    .summary-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 8px;
      margin-bottom: 14px;
    }
    .summary-card {
      background-color: #f8fafc;
      border: 1px solid #cbd5e1;
      padding: 8px 10px;
      border-radius: 6px;
      text-align: center;
    }
    .summary-card .val {
      font-size: 16px;
      font-weight: 900;
      color: #0f766e;
    }
    .summary-card .lbl {
      font-size: 10px;
      color: #64748b;
      font-weight: 600;
    }
    /* Signatures Footer */
    .signatures-footer {
      border-top: 1.5px solid #0f766e;
      margin-top: 24px;
      padding-top: 12px;
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 8px;
      text-align: center;
      page-break-inside: avoid;
      break-inside: avoid;
    }
    .sig-block {
      border: 1px dashed #cbd5e1;
      padding: 8px 6px;
      border-radius: 6px;
      background-color: #ffffff;
    }
    .sig-title { font-size: 9.5px; color: #64748b; font-weight: bold; margin-bottom: 4px; }
    .sig-name { font-size: 11.5px; font-weight: 900; color: #0f172a; margin-bottom: 8px; }
    .sig-line { font-size: 9px; color: #94a3b8; }
    .watermark-note {
      text-align: center;
      font-size: 10px;
      color: #64748b;
      margin-top: 12px;
      padding-top: 6px;
      border-top: 1px solid #e2e8f0;
      font-weight: 600;
    }
    @media print {
      html, body { 
        background: #ffffff !important; 
        color: #0f172a !important; 
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
      }
      .print-wrapper {
        border: none !important;
        box-shadow: none !important;
        padding: 0 !important;
        margin: 0 !important;
        max-width: 100% !important;
        background: #ffffff !important;
      }
      .no-print { display: none !important; }
    }
  </style>
</head>
<body>
  <div class="print-wrapper">
    <!-- Official Corner Marks -->
    <div class="corner-mark top-right"></div>
    <div class="corner-mark top-left"></div>
    <div class="corner-mark bottom-right"></div>
    <div class="corner-mark bottom-left"></div>

    <!-- Header -->
    <div class="hospital-header">
      <div class="header-right">
        <div class="country">الجمهورية اليمنية</div>
        <div class="hospital-name">مستشفى آزال النموذجي - صنعاء</div>
        <div class="fms-dept">إدارة الأمن والسلامة وإدارة المرافق (FMS)</div>
        <div style="font-size: 10.5px; font-weight: 800; color: #16a34a; margin-top: 2px;">الرعاية الكاملة • CBAHI ACCREDITED</div>
      </div>
      <div class="header-center">
        ${AZAL_LOGO_SVG}
      </div>
      <div class="header-left">
        <div class="badge">CBAHI ACCREDITED</div>
        <div>Ref: ${refCode}</div>
        <div>Date: ${dateStr}</div>
        <div>Security & Safety Dept</div>
      </div>
    </div>

    <!-- Title Banner -->
    <div class="document-title-banner">
      <div>
        <h1 class="document-title">${options.title}</h1>
        <div class="document-subtitle">${subtitle}</div>
      </div>
      ${options.department ? `<div style="font-weight:bold; font-size:11px; background:#e2e8f0; padding:4px 8px; border-radius:4px;">القسم: ${options.department}</div>` : ''}
    </div>

    <!-- Main Content -->
    <div class="document-body">
      ${contentHtml}
    </div>

    <!-- Verified Leadership Signatures (CBAHI FMS Mandate) -->
    <div class="signatures-footer">
      <div class="sig-block">
        <div class="sig-title">منسق الجودة والاعتماد:</div>
        <div class="sig-name">د/ علي الظبيبي</div>
        <div class="sig-line">التوقيع والختم: ________________</div>
      </div>

      <div class="sig-block">
        <div class="sig-title">المدير الطبي:</div>
        <div class="sig-name">د/ أحمد الأهدل</div>
        <div class="sig-line">التوقيع والختم: ________________</div>
      </div>

      <div class="sig-block">
        <div class="sig-title">رئيس قسم السلامة وإدارة المرافق (FMS):</div>
        <div class="sig-name">م/ نجيب قاسم غازي</div>
        <div class="sig-line">التوقيع والختم: ________________</div>
      </div>

      <div class="sig-block">
        <div class="sig-title">مدير عام المستشفى:</div>
        <div class="sig-name">د/ محمد السراجي</div>
        <div class="sig-line">التوقيع والختم: ________________</div>
      </div>
    </div>

    <div class="watermark-note">
      تم إنشاء وتصدير هذا المستند الرسمي عبر نظام "أمن آزال" لإدارة السلامة والمرافق • هاتف طوارئ السلامة المعتمد: 96777738138
    </div>
  </div>
</body>
</html>`;
}

/**
 * Prints the given HTML content using an isolated hidden iframe for clean rendering,
 * with fallbacks for mobile and popup-blocking environments.
 */
export function printHtmlViaIframe(fullHtml: string, documentTitle: string = 'وثيقة مستشفى آزال'): boolean {
  try {
    if (typeof window === 'undefined') return false;

    // Create a hidden iframe
    const iframeId = 'azal-print-isolated-iframe';
    const oldIframe = document.getElementById(iframeId);
    if (oldIframe) {
      document.body.removeChild(oldIframe);
    }

    const iframe = document.createElement('iframe');
    iframe.id = iframeId;
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = '0';
    iframe.style.visibility = 'hidden';
    document.body.appendChild(iframe);

    const doc = iframe.contentWindow?.document || iframe.contentDocument;
    if (!doc) {
      throw new Error('Unable to access iframe document');
    }

    doc.open();
    doc.write(fullHtml);
    doc.close();

    // Give browser time to parse styles and images
    setTimeout(() => {
      try {
        iframe.contentWindow?.focus();
        iframe.contentWindow?.print();
        
        // Remove iframe after print dialog completes
        setTimeout(() => {
          if (iframe.parentNode) {
            iframe.parentNode.removeChild(iframe);
          }
        }, 1500);
      } catch (printErr) {
        console.warn('[Print] Iframe print trigger failed, falling back to window print', printErr);
        fallbackPrintDirect(fullHtml, documentTitle);
      }
    }, 250);

    return true;
  } catch (err) {
    console.warn('[Print] Failed to print via iframe, falling back:', err);
    fallbackPrintDirect(fullHtml, documentTitle);
    return false;
  }
}

/**
 * Fallback direct print method by opening window or standard window.print()
 */
function fallbackPrintDirect(fullHtml: string, title: string) {
  try {
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.open();
      printWindow.document.write(fullHtml);
      printWindow.document.close();
      printWindow.focus();
      setTimeout(() => {
        printWindow.print();
        printWindow.close();
      }, 350);
      return;
    }
  } catch {}

  // Last resort
  window.print();
}

/**
 * High-level printing helper for any report section
 */
export function executeSmartPrint(contentHtml: string, options: PrintDocumentOptions) {
  const finalHtml = buildPrintableHtml(contentHtml, options);
  return printHtmlViaIframe(finalHtml, options.title);
}

/**
 * Grabs an existing HTML element by ID, cleans out buttons and inputs,
 * wraps in official letterhead, and sends to print.
 */
export function printExistingElementById(elementId: string, options: PrintDocumentOptions): boolean {
  if (typeof document === 'undefined') return false;
  const el = document.getElementById(elementId);
  if (!el) {
    console.warn(`[Print] Element #${elementId} not found, using window.print()`);
    window.print();
    return false;
  }

  // Clone node to avoid mutating live UI
  const clone = el.cloneNode(true) as HTMLElement;
  // Remove buttons, icons with class no-print, search inputs, etc.
  clone.querySelectorAll('.no-print, button, input[type="search"], select').forEach(node => {
    node.parentNode?.removeChild(node);
  });

  return executeSmartPrint(clone.innerHTML, options);
}
