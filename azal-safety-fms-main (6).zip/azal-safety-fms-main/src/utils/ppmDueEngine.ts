import { PpmAsset } from '../data/azalPpmAssetsData';

export type PpmStatusType = 'completed' | 'due_today' | 'overdue';

export interface PpmStatusResult {
  status: PpmStatusType;
  statusLabelAr: string;
  badgeBg: string;
  badgeBorder: string;
  badgeText: string;
  overdueDays: number;
  remainingDays: number;
  isCompliant: boolean;
}

export interface AntiFraudScanProof {
  token: string;
  assetTag: string;
  timestamp: number;
  formattedTime: string;
  cameraVerified: boolean;
  scannerType: 'LIVE_MEDIASTREAM_CAMERA';
  integrityHash: string;
}

/**
 * Calculates PPM due status and delay days according to FMS & CBAHI rules
 */
export function calculatePpmStatus(asset: PpmAsset, referenceDateStr?: string): PpmStatusResult {
  // Use today or passed reference date
  const now = referenceDateStr ? new Date(referenceDateStr) : new Date();
  // Strip time for exact calendar day comparison
  const todayZero = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();

  const nextDueDate = new Date(asset.next_pm_due);
  const dueZero = new Date(nextDueDate.getFullYear(), nextDueDate.getMonth(), nextDueDate.getDate()).getTime();

  const diffMs = todayZero - dueZero;
  const diffDays = Math.round(diffMs / (1000 * 60 * 60 * 24));

  if (diffDays > 0) {
    // Overdue by diffDays!
    return {
      status: 'overdue',
      statusLabelAr: `متأخر ❌ (${diffDays} يوم)`,
      badgeBg: 'bg-rose-500/15',
      badgeBorder: 'border-rose-500/50',
      badgeText: 'text-rose-500 font-bold',
      overdueDays: diffDays,
      remainingDays: 0,
      isCompliant: false
    };
  }

  if (diffDays === 0) {
    // Due today!
    return {
      status: 'due_today',
      statusLabelAr: 'مستحق اليوم ⏳',
      badgeBg: 'bg-amber-500/15',
      badgeBorder: 'border-amber-500/50',
      badgeText: 'text-amber-500 font-bold',
      overdueDays: 0,
      remainingDays: 0,
      isCompliant: true
    };
  }

  // Ahead of schedule / Completed for current cycle
  const remaining = Math.abs(diffDays);
  return {
    status: 'completed',
    statusLabelAr: 'منجز ✅',
    badgeBg: 'bg-emerald-500/15',
    badgeBorder: 'border-emerald-500/50',
    badgeText: 'text-emerald-500 font-bold',
    overdueDays: 0,
    remainingDays: remaining,
    isCompliant: true
  };
}

/**
 * Calculates the next PM due date given frequency
 */
export function computeNextDueDate(fromIsoDate: string, frequency: PpmAsset['frequency']): string {
  const base = new Date(fromIsoDate);
  const next = new Date(base);

  switch (frequency) {
    case 'يومي':
      next.setDate(base.getDate() + 1);
      break;
    case 'أسبوعي':
      next.setDate(base.getDate() + 7);
      break;
    case 'شهري':
      next.setMonth(base.getMonth() + 1);
      break;
    case 'كل 3 أشهر':
      next.setMonth(base.getMonth() + 3);
      break;
    case 'كل 6 أشهر':
      next.setMonth(base.getMonth() + 6);
      break;
    case 'سنوي':
      next.setFullYear(base.getFullYear() + 1);
      break;
    case 'موسمي':
      next.setMonth(base.getMonth() + 3);
      break;
    default:
      next.setMonth(base.getMonth() + 1);
  }

  return next.toISOString().split('T')[0];
}

/**
 * Generates an anti-fraud live scan proof token from direct hardware camera stream
 */
export function generateLiveScanProof(assetTag: string): AntiFraudScanProof {
  const ts = Date.now();
  const nonce = Math.random().toString(36).substring(2, 9).toUpperCase();
  const rawSig = `${assetTag}|${ts}|LIVE_CAM|${nonce}`;
  
  // Create a verifiable hash
  let hash = 0;
  for (let i = 0; i < rawSig.length; i++) {
    hash = ((hash << 5) - hash) + rawSig.charCodeAt(i);
    hash |= 0;
  }
  const integrityHash = `AZAL-LIVE-${Math.abs(hash).toString(16).toUpperCase()}-${nonce}`;

  const dateObj = new Date(ts);
  const formattedTime = dateObj.toLocaleTimeString('ar-YE', { 
    hour: '2-digit', 
    minute: '2-digit', 
    second: '2-digit' 
  });

  return {
    token: `LIVE-TOKEN-${ts}-${assetTag}`,
    assetTag,
    timestamp: ts,
    formattedTime,
    cameraVerified: true,
    scannerType: 'LIVE_MEDIASTREAM_CAMERA',
    integrityHash
  };
}

/**
 * Validates that a scan proof was generated live and is not expired (within 10 minutes)
 */
export function validateScanProof(proof?: AntiFraudScanProof | null): boolean {
  if (!proof) return false;
  if (!proof.cameraVerified || proof.scannerType !== 'LIVE_MEDIASTREAM_CAMERA') return false;
  
  // Maximum age: 10 minutes
  const maxAgeMs = 10 * 60 * 1000;
  const elapsed = Date.now() - proof.timestamp;
  return elapsed >= 0 && elapsed <= maxAgeMs;
}
