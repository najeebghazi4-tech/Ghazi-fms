import { HospitalRiskItem } from '../types';
import { executeSmartPrint } from './printUtils';
import { getRiskLevel } from '../data/azalRiskData';

interface RiskPrintStats {
  total: number;
  critical: number;
  high: number;
  moderate: number;
  low: number;
  controlled: number;
  controlRate: number;
}

export function printHospitalRiskRegisterPdf(
  risks: HospitalRiskItem[],
  stats: RiskPrintStats,
  meta?: {
    filterDept?: string;
    filterLevel?: string;
    printedBy?: string;
  }
) {
  const printDate = new Date().toLocaleDateString('ar-YE', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
  const printTime = new Date().toLocaleTimeString('ar-YE', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true
  });

  const htmlContent = `
    <div style="font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif; direction: rtl; padding: 25px; color: #0f172a; max-width: 1100px; margin: 0 auto; background: #ffffff;">
      
      <!-- Official Header -->
      <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 3px solid #0284c7; padding-bottom: 15px; margin-bottom: 20px;">
        <div style="display: flex; align-items: center; gap: 15px;">
          <div style="width: 55px; height: 55px; border-radius: 12px; background: #0284c7; color: #ffffff; display: flex; align-items: center; justify-content: center; font-size: 24px; font-weight: bold; border: 2px solid #38bdf8;">
            🏥
          </div>
          <div>
            <h1 style="margin: 0; font-size: 20px; font-weight: 800; color: #0f172a;">مستشفى آزال النموذجي الحديث</h1>
            <p style="margin: 2px 0 0; font-size: 13px; color: #0369a1; font-weight: bold;">الإدارة العامة للجودة وسلامة المرضى وإدارة المرافق (FMS)</p>
            <p style="margin: 2px 0 0; font-size: 11px; color: #64748b;">سجل ومصفوفة تقييم المخاطر الشاملة (Hospital Risk Assessment & Matrix Register)</p>
          </div>
        </div>
        
        <div style="text-align: left; font-size: 11px; color: #475569; line-height: 1.5; border-right: 2px solid #e2e8f0; padding-right: 15px;">
          <div><strong>الرمز الوثائقي:</strong> AZAL-FMS-RSK-2026</div>
          <div><strong>معايير الامتثال:</strong> CBAHI FMS.1 / JCI / OSHA</div>
          <div><strong>تاريخ الطباعة:</strong> ${printDate}</div>
          <div><strong>وقت التقرير:</strong> ${printTime}</div>
          <div><strong>المستخدم المسؤول:</strong> ${meta?.printedBy || 'م. نجيب غازي (مسؤول FMS)'}</div>
        </div>
      </div>

      <!-- Executive KPIs Summary Cards -->
      <div style="display: grid; grid-template-columns: repeat(6, 1fr); gap: 10px; margin-bottom: 20px;">
        <div style="background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 10px; padding: 10px; text-align: center;">
          <div style="font-size: 10px; color: #64748b; font-weight: bold;">إجمالي المخاطر</div>
          <div style="font-size: 20px; font-weight: 900; color: #0f172a; margin-top: 4px;">${stats.total}</div>
          <div style="font-size: 9px; color: #94a3b8;">خطر مرصود</div>
        </div>

        <div style="background: #fff1f2; border: 1px solid #fecdd3; border-radius: 10px; padding: 10px; text-align: center;">
          <div style="font-size: 10px; color: #be123c; font-weight: bold;">حرجة (20-25)</div>
          <div style="font-size: 20px; font-weight: 900; color: #e11d48; margin-top: 4px;">${stats.critical}</div>
          <div style="font-size: 9px; color: #f43f5e;">أولوية قصوى</div>
        </div>

        <div style="background: #fffbeb; border: 1px solid #fde68a; border-radius: 10px; padding: 10px; text-align: center;">
          <div style="font-size: 10px; color: #b45309; font-weight: bold;">عالية (10-16)</div>
          <div style="font-size: 20px; font-weight: 900; color: #d97706; margin-top: 4px;">${stats.high}</div>
          <div style="font-size: 9px; color: #f59e0b;">متابعة عاجلة</div>
        </div>

        <div style="background: #fefce8; border: 1px solid #fef08a; border-radius: 10px; padding: 10px; text-align: center;">
          <div style="font-size: 10px; color: #a16207; font-weight: bold;">متوسطة (5-9)</div>
          <div style="font-size: 20px; font-weight: 900; color: #ca8a04; margin-top: 4px;">${stats.moderate}</div>
          <div style="font-size: 9px; color: #eab308;">إجراءات روتينية</div>
        </div>

        <div style="background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 10px; padding: 10px; text-align: center;">
          <div style="font-size: 10px; color: #15803d; font-weight: bold;">منخفضة (1-4)</div>
          <div style="font-size: 20px; font-weight: 900; color: #16a34a; margin-top: 4px;">${stats.low}</div>
          <div style="font-size: 9px; color: #22c55e;">مستوى مقبول</div>
        </div>

        <div style="background: #f0fdf4; border: 2px solid #16a34a; border-radius: 10px; padding: 10px; text-align: center;">
          <div style="font-size: 10px; color: #166534; font-weight: bold;">نسبة السيطرة</div>
          <div style="font-size: 20px; font-weight: 900; color: #15803d; margin-top: 4px;">${stats.controlRate}%</div>
          <div style="font-size: 9px; color: #16a34a;">${stats.controlled} خطر مسيطر عليه</div>
        </div>
      </div>

      <!-- Filter Notice if Applied -->
      ${meta?.filterDept && meta.filterDept !== 'all' ? `
        <div style="background: #f1f5f9; padding: 6px 12px; border-radius: 6px; font-size: 11px; margin-bottom: 15px; color: #334155;">
          <strong>تصفية حسب القسم:</strong> ${meta.filterDept}
        </div>
      ` : ''}

      <!-- Detailed Risk Register Table -->
      <table style="width: 100%; border-collapse: collapse; font-size: 10px; text-align: right; margin-bottom: 25px;">
        <thead>
          <tr style="background: #0f172a; color: #ffffff;">
            <th style="padding: 8px 6px; border: 1px solid #334155; width: 65px; text-align: center;">الكود</th>
            <th style="padding: 8px 6px; border: 1px solid #334155; width: 110px;">القسم والتصنيف</th>
            <th style="padding: 8px 6px; border: 1px solid #334155;">وصف الخطر والتهديد المحتمل</th>
            <th style="padding: 8px 6px; border: 1px solid #334155; width: 65px; text-align: center;">التقييم الأولي (L×S)</th>
            <th style="padding: 8px 6px; border: 1px solid #334155;">الضوابط وخطة العمل الوقائية (CAP)</th>
            <th style="padding: 8px 6px; border: 1px solid #334155; width: 100px;">المسؤول والموعد</th>
            <th style="padding: 8px 6px; border: 1px solid #334155; width: 65px; text-align: center;">التقييم المتبقي</th>
            <th style="padding: 8px 6px; border: 1px solid #334155; width: 65px; text-align: center;">الحالة والإنجاز</th>
          </tr>
        </thead>
        <tbody>
          ${risks.map((item, idx) => {
            const initialLevel = getRiskLevel(item.initial_risk_score);
            const residualScore = item.residual_risk_score || calculateResidual(item);
            const residualLevel = getRiskLevel(residualScore);
            const isEven = idx % 2 === 0;

            const initialBadgeColor = 
              initialLevel.level === 'critical' ? '#e11d48' :
              initialLevel.level === 'high' ? '#d97706' :
              initialLevel.level === 'moderate' ? '#ca8a04' : '#16a34a';

            const residualBadgeColor = 
              residualLevel.level === 'critical' ? '#e11d48' :
              residualLevel.level === 'high' ? '#d97706' :
              residualLevel.level === 'moderate' ? '#ca8a04' : '#16a34a';

            return `
              <tr style="background: ${isEven ? '#ffffff' : '#f8fafc'}; page-break-inside: avoid;">
                <td style="padding: 6px; border: 1px solid #cbd5e1; font-weight: bold; text-align: center; font-family: monospace; font-size: 10px; color: #0369a1;">
                  ${item.risk_code}
                </td>
                <td style="padding: 6px; border: 1px solid #cbd5e1;">
                  <strong style="color: #0f172a; display: block;">${item.department}</strong>
                  <span style="font-size: 9px; color: #64748b;">${item.category_name_ar}</span>
                </td>
                <td style="padding: 6px; border: 1px solid #cbd5e1; line-height: 1.35;">
                  <strong style="color: #1e293b; display: block; font-size: 10.5px;">${item.title}</strong>
                  <div style="color: #475569; margin-top: 2px; font-size: 9.5px;">${item.hazard_description}</div>
                  ${item.consequences ? `<div style="color: #991b1b; font-size: 8.5px; margin-top: 2px;">⚠️ الأثر: ${item.consequences}</div>` : ''}
                </td>
                <td style="padding: 6px; border: 1px solid #cbd5e1; text-align: center;">
                  <div style="font-size: 12px; font-weight: 900; color: ${initialBadgeColor};">
                    ${item.initial_risk_score}
                  </div>
                  <div style="font-size: 8.5px; color: #64748b; margin-top: 1px;">
                    (${item.initial_likelihood} × ${item.initial_severity})
                  </div>
                  <span style="display: inline-block; padding: 1px 4px; border-radius: 4px; background: ${initialBadgeColor}; color: #ffffff; font-size: 8px; font-weight: bold; margin-top: 2px;">
                    ${initialLevel.labelAr}
                  </span>
                </td>
                <td style="padding: 6px; border: 1px solid #cbd5e1; line-height: 1.35;">
                  <div style="font-size: 9px; color: #334155;"><strong>الضوابط:</strong> ${item.current_controls || 'تحت المراجعة'}</div>
                  <div style="font-size: 9px; color: #0369a1; margin-top: 2px;"><strong>خطة العمل:</strong> ${item.action_plan}</div>
                </td>
                <td style="padding: 6px; border: 1px solid #cbd5e1; font-size: 9px;">
                  <strong style="color: #0f172a; display: block;">${item.responsible_person}</strong>
                  <div style="color: #64748b; font-size: 8.5px;">${item.responsible_dept || ''}</div>
                  <div style="color: #d97706; font-weight: bold; margin-top: 3px;">📅 ${item.target_date}</div>
                </td>
                <td style="padding: 6px; border: 1px solid #cbd5e1; text-align: center;">
                  <div style="font-size: 11px; font-weight: 900; color: ${residualBadgeColor};">
                    ${residualScore}
                  </div>
                  <div style="font-size: 8px; color: #64748b;">
                    (${item.residual_likelihood || 1} × ${item.residual_severity || 2})
                  </div>
                  <span style="display: inline-block; padding: 1px 3px; border-radius: 4px; background: ${residualBadgeColor}; color: #ffffff; font-size: 7.5px; font-weight: bold; margin-top: 2px;">
                    ${residualLevel.labelAr}
                  </span>
                </td>
                <td style="padding: 6px; border: 1px solid #cbd5e1; text-align: center;">
                  <div style="font-weight: 900; font-size: 10.5px; color: ${item.completion_percentage === 100 ? '#16a34a' : '#0284c7'};">
                    ${item.completion_percentage}%
                  </div>
                  <div style="background: #e2e8f0; height: 5px; border-radius: 3px; overflow: hidden; margin: 3px auto; width: 90%;">
                    <div style="background: ${item.completion_percentage === 100 ? '#16a34a' : '#0284c7'}; height: 100%; width: ${item.completion_percentage}%;"></div>
                  </div>
                  <span style="font-size: 8px; font-weight: bold; color: ${item.status === 'controlled' ? '#15803d' : '#b45309'};">
                    ${item.status === 'controlled' ? 'تمت السيطرة ✓' : 'قيد المعالجة'}
                  </span>
                </td>
              </tr>
            `;
          }).join('')}
        </tbody>
      </table>

      <!-- 5x5 Matrix Methodology Note -->
      <div style="background: #f8fafc; border: 1px dashed #94a3b8; border-radius: 8px; padding: 10px; margin-bottom: 25px; font-size: 9.5px; color: #475569; line-height: 1.5;">
        <strong>معيار المصفوفة المعتمد (5×5 Risk Matrix):</strong>
        درجة الخطورة = الاحتمالية (1-5) × شدة الأثر (1-5). المخاطر بدرجة (20-25) تتطلب إجراءات إيقاف فورية وخطة طوارئ؛ المخاطر بدرجة (10-16) تتطلب تدخلاً عاجلاً خلال 48 ساعة؛ المخاطر بدرجة (5-9) تدار عبر الإجراءات التشغيلية؛ والمخاطر بدرجة (1-4) مقبولة مع المتابعة الوقائية الدورية.
      </div>

      <!-- Signatures & Endorsement Section -->
      <div style="display: flex; justify-content: space-between; margin-top: 30px; padding-top: 20px; border-top: 2px solid #cbd5e1; page-break-inside: avoid;">
        <div style="text-align: center; width: 30%;">
          <p style="margin: 0; font-size: 11px; color: #64748b; font-weight: bold;">إعداد ومتابعة مسؤول السلامة والمرافق (FMS)</p>
          <div style="height: 40px; margin: 5px 0;"></div>
          <p style="margin: 0; font-size: 12px; font-weight: bold; color: #0f172a;">م. نجيب غازي</p>
          <p style="margin: 0; font-size: 10px; color: #64748b;">رئيس قسم السلامة وإدارة المرافق</p>
        </div>

        <div style="text-align: center; width: 30%;">
          <p style="margin: 0; font-size: 11px; color: #64748b; font-weight: bold;">مراجعة وتدقيق إدارة الجودة والاعتماد (CBAHI)</p>
          <div style="height: 40px; margin: 5px 0;"></div>
          <p style="margin: 0; font-size: 12px; font-weight: bold; color: #0f172a;">د. محمد السراجي / أ. عارف الصلوي</p>
          <p style="margin: 0; font-size: 10px; color: #64748b;">منسق الجودة والاعتماد المؤسسي</p>
        </div>

        <div style="text-align: center; width: 30%;">
          <p style="margin: 0; font-size: 11px; color: #64748b; font-weight: bold;">اعتماد المدير العام لمستشفى آزال النموذجي</p>
          <div style="height: 40px; margin: 5px 0;"></div>
          <p style="margin: 0; font-size: 12px; font-weight: bold; color: #0f172a;">الإدارة العامة والتنفيذية</p>
          <p style="margin: 0; font-size: 10px; color: #64748b;">الختم الرسمي للمستشفى</p>
        </div>
      </div>

    </div>
  `;

  executeSmartPrint(htmlContent, {
    title: 'سجل_مصفوفة_المخاطر_مستشفى_آزال',
    subtitle: 'سجل المخاطر المعتمد لسباهي والجودة (CBAHI FMS Risk Register)',
    refNumber: 'AZAL-FMS-RSK-2026',
    department: meta?.filterDept || 'كافة أقسام المستشفى',
    inspectorName: meta?.printedBy || 'م. نجيب غازي'
  });
}

function calculateResidual(item: HospitalRiskItem): number {
  if (item.residual_risk_score) return item.residual_risk_score;
  const rl = item.residual_likelihood || Math.max(1, item.initial_likelihood - 2);
  const rs = item.residual_severity || Math.max(1, item.initial_severity - 1);
  return rl * rs;
}
