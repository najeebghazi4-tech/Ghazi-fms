import { 
  CbahiFireDrill, 
  CbahiGeneratorTest, 
  CbahiWaterTest, 
  CbahiSafetyCommitteeItem, 
  CbahiStandardItem 
} from '../types';
import { executeSmartPrint } from './printUtils';

/**
 * 1. FMS.18 Fire & Evacuation Drill Official Report Print Template
 */
export function printCbahiFireDrillReport(drill: CbahiFireDrill) {
  const shiftNameAr = drill.shift === 'morning' ? 'الوردية الصباحية (08:00 - 16:00)' :
                      drill.shift === 'evening' ? 'الوردية المسائية (16:00 - 00:00)' : 'الوردية الليلية (00:00 - 08:00)';
  const ratingBadge = drill.evaluation_rating === 'excellent' ? 'ممتاز (Excellent - تفوق)' :
                      drill.evaluation_rating === 'very_good' ? 'جيد جداً (Very Good - مطابق)' :
                      drill.evaluation_rating === 'good' ? 'جيد (Good)' : 'يحتاج تحسين (Needs Improvement)';
  const minutes = Math.floor(drill.evacuation_time_seconds / 60);
  const seconds = drill.evacuation_time_seconds % 60;
  const timeFormatted = `${minutes} دقيقة و ${seconds} ثانية (${drill.evacuation_time_seconds} ثانية)`;

  const html = `
    <div style="font-family: inherit; direction: rtl; text-align: right;">
      <div style="background: #f0fdf4; border: 2px solid #16a34a; border-radius: 8px; padding: 14px; margin-bottom: 16px; text-align: center;">
        <span style="font-size: 10px; font-weight: bold; color: #166534; letter-spacing: 1px; display: block;">سجل الامتثال لمعايير المركز السعودي لاعتماد المنشآت الصحية (CBAHI FMS.18)</span>
        <h2 style="margin: 4px 0; font-size: 18px; color: #14532d; font-weight: 900;">تقرير توثيق فرضية وتجربة الحريق والإخلاء الوهمية الرسمية</h2>
        <span style="font-size: 11px; color: #475569; font-weight: 600;">كود الفرضية: <strong>${drill.drill_code}</strong> | تاريخ التنفيذ: <strong>${drill.drill_date}</strong></span>
      </div>

      <!-- Basic Parameters Grid -->
      <table style="width: 100%; border-collapse: collapse; margin-bottom: 16px; font-size: 12px;">
        <tbody>
          <tr style="background: #f8fafc;">
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: bold; width: 25%; color: #334155;">القسم / الموقع:</td>
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: bold; color: #0f172a;">${drill.department}</td>
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: bold; width: 25%; color: #334155;">فترة الوردية:</td>
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: bold; color: #0f172a;">${shiftNameAr}</td>
          </tr>
          <tr>
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: bold; color: #334155;">زمن الإخلاء الفعلي:</td>
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: 900; color: #15803d; font-size: 13px;">${timeFormatted}</td>
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: bold; color: #334155;">التقييم العام للفرضية:</td>
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: bold; color: #0369a1;">${ratingBadge} (${drill.evaluation_score}%)</td>
          </tr>
          <tr style="background: #f8fafc;">
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: bold; color: #334155;">عدد المشاركين:</td>
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1;">${drill.participants_count} من الكوادر والمناوبين</td>
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: bold; color: #334155;">المصابين المحاكون:</td>
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1;">${drill.simulated_victims_count} حالات تم إخلاؤها بنجاح</td>
          </tr>
        </tbody>
      </table>

      <!-- RACE and PASS Audits -->
      <div style="display: flex; gap: 12px; margin-bottom: 16px;">
        <div style="flex: 1; border: 1px solid #e2e8f0; border-radius: 6px; padding: 10px; background: #ffffff;">
          <div style="border-bottom: 2px solid #ef4444; padding-bottom: 6px; margin-bottom: 8px; display: flex; justify-content: space-between; align-items: center;">
            <strong style="color: #b91c1c; font-size: 13px;">1. تطبيق بروتوكول RACE</strong>
            <span style="background: ${drill.race_applied ? '#dcfce7; color: #15803d' : '#fee2e2; color: #b91c1c'}; font-size: 10px; font-weight: bold; padding: 2px 8px; border-radius: 4px;">
              ${drill.race_applied ? `مطبق بنجاح (${drill.race_score}%)` : 'غير مكتمل'}
            </span>
          </div>
          <p style="font-size: 10px; color: #64748b; margin: 0 0 6px 0;"><strong>R</strong>escue • <strong>A</strong>larm • <strong>C</strong>onfine • <strong>E</strong>vacuate</p>
          <div style="background: #f8fafc; padding: 8px; border-radius: 4px; font-size: 11px; line-height: 1.4; color: #1e293b;">
            ${drill.race_notes || 'تم إنقاذ الحالات المعرضة للخطر، وسحب كاسر الإنذار ونداء الكود الأحمر، وعزل المنطقة بالأبواب المقاومة للحريق، والإخلاء المنظم.'}
          </div>
        </div>

        <div style="flex: 1; border: 1px solid #e2e8f0; border-radius: 6px; padding: 10px; background: #ffffff;">
          <div style="border-bottom: 2px solid #f59e0b; padding-bottom: 6px; margin-bottom: 8px; display: flex; justify-content: space-between; align-items: center;">
            <strong style="color: #b45309; font-size: 13px;">2. تطبيق بروتوكول PASS</strong>
            <span style="background: ${drill.pass_applied ? '#dcfce7; color: #15803d' : '#fee2e2; color: #b91c1c'}; font-size: 10px; font-weight: bold; padding: 2px 8px; border-radius: 4px;">
              ${drill.pass_applied ? `مطبق بنجاح (${drill.pass_score}%)` : 'غير مكتمل'}
            </span>
          </div>
          <p style="font-size: 10px; color: #64748b; margin: 0 0 6px 0;"><strong>P</strong>ull • <strong>A</strong>im • <strong>S</strong>queeze • <strong>S</strong>weep</p>
          <div style="background: #f8fafc; padding: 8px; border-radius: 4px; font-size: 11px; line-height: 1.4; color: #1e293b;">
            ${drill.pass_notes || 'تم استخدام طفايات الحريق اليدوية ومكافحة بؤرة الحريق الافتراضية مع الحفاظ على مسافة الأمان وسحب المسمار والتوجيه للقاعدة.'}
          </div>
        </div>
      </div>

      <!-- Isolation Check -->
      <table style="width: 100%; border-collapse: collapse; margin-bottom: 16px; font-size: 11px;">
        <thead>
          <tr style="background: #0f766e; color: #ffffff;">
            <th style="padding: 6px 10px; text-align: right; border: 1px solid #0f766e;">بند عزل المرافق أثناء الطوارئ</th>
            <th style="padding: 6px 10px; text-align: center; border: 1px solid #0f766e; width: 25%;">الحالة الفنية</th>
            <th style="padding: 6px 10px; text-align: right; border: 1px solid #0f766e;">ملاحظات التدقيق</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style="padding: 8px 10px; border: 1px solid #e2e8f0; font-weight: bold;">عزل شبكة الغازات الطبية وصمامات الزون (Zone Valves)</td>
            <td style="padding: 8px 10px; border: 1px solid #e2e8f0; text-align: center; font-weight: bold; color: ${drill.gas_isolated ? '#15803d' : '#b91c1c'};">
              ${drill.gas_isolated ? '✓ تم العزل الآمن بنجاح' : '✗ لم يتم العزل'}
            </td>
            <td style="padding: 8px 10px; border: 1px solid #e2e8f0; font-size: 10px; color: #64748b;">إغلاق صمامات المنطقة المتأثرة دون قطع الإمداد عن أجنحة الإنعاش الحرجة</td>
          </tr>
          <tr style="background: #f8fafc;">
            <td style="padding: 8px 10px; border: 1px solid #e2e8f0; font-weight: bold;">فصل التيار الكهربائي غير الطارئ وعمل دوائر الطوارئ</td>
            <td style="padding: 8px 10px; border: 1px solid #e2e8f0; text-align: center; font-weight: bold; color: ${drill.electricity_isolated ? '#15803d' : '#b91c1c'};">
              ${drill.electricity_isolated ? '✓ تم الفصل بنجاح' : '✗ لم يتم الفصل'}
            </td>
            <td style="padding: 8px 10px; border: 1px solid #e2e8f0; font-size: 10px; color: #64748b;">فصل القواطع العادية مع استمرار إنارة الطوارئ ومسارات الهروب مضاءة</td>
          </tr>
        </tbody>
      </table>

      <!-- Recommendations and Observations -->
      <div style="border: 1px solid #cbd5e1; border-radius: 6px; padding: 12px; margin-bottom: 16px; background: #ffffff;">
        <h4 style="margin: 0 0 6px 0; color: #0f172a; font-size: 12px;">الملاحظات والتوصيات الميدانية لخطط التحسين:</h4>
        <div style="font-size: 11px; line-height: 1.5; color: #334155; margin-bottom: 8px;">
          <strong>الملاحظات:</strong> ${drill.notes || 'لا توجد ملاحظات إضافية.'}
        </div>
        <div style="font-size: 11px; line-height: 1.5; color: #1e3a8a; background: #eff6ff; padding: 8px; border-radius: 4px; border-right: 3px solid #3b82f6;">
          <strong>توصيات فريق التدقيق:</strong> ${drill.recommendations || 'مواصلة تدريب الكوادر المناوبة وتثبيت مراجعة نقاط التجمع شهرياً.'}
        </div>
      </div>

      <!-- Signatures Footer -->
      <div style="margin-top: 24px; padding-top: 12px; border-top: 1px solid #cbd5e1; display: flex; justify-content: space-between;">
        <div style="text-align: center; width: 30%;">
          <div style="font-size: 11px; font-weight: bold; color: #475569;">منسق فرضية الإخلاء</div>
          <div style="font-size: 12px; font-weight: 900; color: #0f766e; margin-top: 4px;">${drill.supervisor_name}</div>
          <div style="font-size: 9px; color: #64748b;">رئيس قسم السلامة والأمن</div>
          <div style="margin-top: 8px; font-family: monospace; font-size: 10px; color: #059669;">[ توقيع واعتماد إلكتروني ]</div>
        </div>
        <div style="text-align: center; width: 30%;">
          <div style="font-size: 11px; font-weight: bold; color: #475569;">منسق الجودة والاعتماد</div>
          <div style="font-size: 12px; font-weight: 900; color: #0f172a; margin-top: 4px;">د/ نبيل عصار</div>
          <div style="font-size: 9px; color: #64748b;">إدارة الجودة وسلامة المرضى</div>
          <div style="margin-top: 8px; font-family: monospace; font-size: 10px; color: #059669;">[ تم التدقيق والتحقق ]</div>
        </div>
        <div style="text-align: center; width: 30%;">
          <div style="font-size: 11px; font-weight: bold; color: #475569;">اعتماد المدير العام</div>
          <div style="font-size: 12px; font-weight: 900; color: #0f172a; margin-top: 4px;">د/ محمد السراجي</div>
          <div style="font-size: 9px; color: #64748b;">المدير العام لمستشفى آزال</div>
          <div style="margin-top: 8px; font-family: monospace; font-size: 10px; color: #059669;">[ معتمد رسمياً CBAHI ]</div>
        </div>
      </div>
    </div>
  `;

  executeSmartPrint(html, {
    title: `تقرير فرضية الحريق والإخلاء FMS.18 - ${drill.drill_code}`,
    subtitle: 'سجل سباهي الرسمي لفرضيات وتجارب الإخلاء ومكافحة الحرائق (FMS.18)',
    refNumber: drill.drill_code,
    department: drill.department,
    inspectorName: drill.supervisor_name
  });
}

/**
 * 2. FMS.31 Generator & ATS Electrical Test Certificate Print Template
 */
export function printCbahiGeneratorTestReport(test: CbahiGeneratorTest) {
  const typeAr = test.test_type === 'weekly_no_load' ? 'فحص أسبوعي دوري بدون حمل (10 دقائق)' :
                 test.test_type === 'monthly_with_load' ? 'اختبار شهري بحمل تشغيلي كامل (30 دقيقة)' : 'فحص طارئ بعد أعمال الصيانة';

  const html = `
    <div style="font-family: inherit; direction: rtl; text-align: right;">
      <div style="background: #f0f9ff; border: 2px solid #0284c7; border-radius: 8px; padding: 14px; margin-bottom: 16px; text-align: center;">
        <span style="font-size: 10px; font-weight: bold; color: #0369a1; letter-spacing: 1px; display: block;">سجل الامتثال لمعايير المركز السعودي لاعتماد المنشآت الصحية (CBAHI FMS.31)</span>
        <h2 style="margin: 4px 0; font-size: 18px; color: #0c4a6e; font-weight: 900;">شهادة فحص واختبار المولدات الكهربائية ولوحات التحويل التلقائي ATS</h2>
        <span style="font-size: 11px; color: #475569; font-weight: 600;">كود الفحص: <strong>${test.test_code}</strong> | تاريخ الفحص: <strong>${test.test_date} - ${test.test_time}</strong></span>
      </div>

      <table style="width: 100%; border-collapse: collapse; margin-bottom: 16px; font-size: 12px;">
        <tbody>
          <tr style="background: #f8fafc;">
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: bold; width: 25%; color: #334155;">اسم المولد والمحرك:</td>
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: bold; color: #0f172a;">${test.generator_name}</td>
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: bold; width: 25%; color: #334155;">نوع الاختبار:</td>
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: bold; color: #0284c7;">${typeAr}</td>
          </tr>
          <tr>
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: bold; color: #334155;">زمن الإقلاع التلقائي (ATS):</td>
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: 900; color: ${test.auto_start_time_seconds <= 10 ? '#15803d' : '#b91c1c'}; font-size: 13px;">
              ${test.auto_start_time_seconds} ثانية (المعيار: ≤ 10 ثوانٍ)
            </td>
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: bold; color: #334155;">مدة التشغيل بالاختبار:</td>
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: bold;">${test.duration_minutes} دقيقة مستمرة</td>
          </tr>
          <tr style="background: #f8fafc;">
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: bold; color: #334155;">الفني القائم بالفحص:</td>
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1;">${test.operator_name} (قسم الصيانة)</td>
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: bold; color: #334155;">المشرف المعتمد:</td>
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: bold; color: #0f766e;">${test.supervisor_name}</td>
          </tr>
        </tbody>
      </table>

      <!-- Electrical & Mechanical Parameters Table -->
      <h4 style="margin: 0 0 8px 0; color: #0f172a; font-size: 13px;">القياسات الكهربائية والميكانيكية المعتمدة:</h4>
      <table style="width: 100%; border-collapse: collapse; margin-bottom: 16px; font-size: 11px;">
        <thead>
          <tr style="background: #0284c7; color: #ffffff;">
            <th style="padding: 8px; border: 1px solid #0284c7;">المؤشر المقاس</th>
            <th style="padding: 8px; border: 1px solid #0284c7;">القيمة المسجلة</th>
            <th style="padding: 8px; border: 1px solid #0284c7;">المجال المعياري المقبول</th>
            <th style="padding: 8px; border: 1px solid #0284c7;">حالة المطابقة</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; font-weight: bold;">الجهد الكهربائي (Voltage)</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; font-weight: 900;">${test.voltage_v} V</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0;">380 - 415 V (± 5%)</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; text-align: center; color: #15803d; font-weight: bold;">مطابق ✓</td>
          </tr>
          <tr style="background: #f8fafc;">
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; font-weight: bold;">التردد الكهربائي (Frequency)</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; font-weight: 900;">${test.frequency_hz} Hz</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0;">49.5 - 50.5 Hz</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; text-align: center; color: #15803d; font-weight: bold;">مطابق ✓</td>
          </tr>
          <tr>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; font-weight: bold;">ضغط زيت المحرك (Oil Pressure)</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; font-weight: 900;">${test.oil_pressure_bar} Bar</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0;">3.5 - 6.0 Bar</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; text-align: center; color: #15803d; font-weight: bold;">مطابق ✓</td>
          </tr>
          <tr style="background: #f8fafc;">
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; font-weight: bold;">حرارة سائل التبريد (Coolant Temp)</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; font-weight: 900;">${test.water_coolant_temp_c} °C</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0;">70 - 88 °C</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; text-align: center; color: #15803d; font-weight: bold;">مطابق ✓</td>
          </tr>
          <tr>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; font-weight: bold;">مستوى وقود الديزل (Fuel Level)</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; font-weight: 900;">${test.fuel_level_percentage}%</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0;">لا يقل عن 80% (معيار CBAHI)</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; text-align: center; color: #15803d; font-weight: bold;">مطابق ✓</td>
          </tr>
          <tr style="background: #f8fafc;">
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; font-weight: bold;">جهد بطاريات الإقلاع (Battery)</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; font-weight: 900;">${test.battery_voltage_v} V DC</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0;">24.0 - 27.5 V DC</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; text-align: center; color: #15803d; font-weight: bold;">مطابق ✓</td>
          </tr>
        </tbody>
      </table>

      <!-- Observations and Test Result Box -->
      <div style="background: #f1f5f9; border: 1px solid #cbd5e1; border-radius: 6px; padding: 10px; margin-bottom: 16px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
          <strong style="color: #0f172a; font-size: 12px;">الملاحظات والتشخيص الفني:</strong>
          <span style="background: #dcfce7; color: #15803d; font-weight: 900; font-size: 11px; padding: 2px 10px; border-radius: 4px; border: 1px solid #86efac;">
            النتيجة النهائية: اجتاز بنجاح تام (PASSED)
          </span>
        </div>
        <p style="margin: 0; font-size: 11px; color: #334155; line-height: 1.5;">${test.notes}</p>
      </div>

      <!-- Signatures Footer -->
      <div style="margin-top: 24px; padding-top: 12px; border-top: 1px solid #cbd5e1; display: flex; justify-content: space-between;">
        <div style="text-align: center; width: 30%;">
          <div style="font-size: 11px; font-weight: bold; color: #475569;">فني الكهرباء والمولدات</div>
          <div style="font-size: 12px; font-weight: 900; color: #0284c7; margin-top: 4px;">${test.operator_name}</div>
          <div style="font-size: 9px; color: #64748b;">قسم الصيانة الكهروميكانيكية</div>
          <div style="margin-top: 8px; font-family: monospace; font-size: 10px; color: #0284c7;">[ توقيع الفاحص ]</div>
        </div>
        <div style="text-align: center; width: 30%;">
          <div style="font-size: 11px; font-weight: bold; color: #475569;">رئيس قسم السلامة FMS</div>
          <div style="font-size: 12px; font-weight: 900; color: #0f766e; margin-top: 4px;">${test.supervisor_name}</div>
          <div style="font-size: 9px; color: #64748b;">إدارة الأمن والسلامة المهنية</div>
          <div style="margin-top: 8px; font-family: monospace; font-size: 10px; color: #059669;">[ تم التدقيق والاعتماد ]</div>
        </div>
        <div style="text-align: center; width: 30%;">
          <div style="font-size: 11px; font-weight: bold; color: #475569;">مدير الشؤون الفنية والصيانة</div>
          <div style="font-size: 12px; font-weight: 900; color: #0f172a; margin-top: 4px;">م/ عارف الصلوي</div>
          <div style="font-size: 9px; color: #64748b;">إدارة المرافق والخدمات الهندسية</div>
          <div style="margin-top: 8px; font-family: monospace; font-size: 10px; color: #059669;">[ معتمد CBAHI FMS.31 ]</div>
        </div>
      </div>
    </div>
  `;

  executeSmartPrint(html, {
    title: `شهادة فحص المولدات FMS.31 - ${test.test_code}`,
    subtitle: 'سجل سباهي الرسمي لاختبارات المولدات والأحمال الكهربائية التلقائية (FMS.31)',
    refNumber: test.test_code,
    department: 'محطة المولدات والكهرباء الاحتياطية',
    inspectorName: test.operator_name
  });
}

/**
 * 3. FMS.37 Biological & Chemical Water Quality Certificate Print Template
 */
export function printCbahiWaterTestReport(test: CbahiWaterTest) {
  const typeAr = test.test_type === 'bacterial' ? 'فحص بكتيري وميكروبي شهري (Bacterial Audit)' : 'فحص كيميائي شامل نصف سنوي (Chemical Audit)';

  const html = `
    <div style="font-family: inherit; direction: rtl; text-align: right;">
      <div style="background: #f0fdfa; border: 2px solid #0d9488; border-radius: 8px; padding: 14px; margin-bottom: 16px; text-align: center;">
        <span style="font-size: 10px; font-weight: bold; color: #0f766e; letter-spacing: 1px; display: block;">سجل الامتثال لمعايير المركز السعودي لاعتماد المنشآت الصحية (CBAHI FMS.37)</span>
        <h2 style="margin: 4px 0; font-size: 18px; color: #134e4a; font-weight: 900;">شهادة الفحص المخبري البكتيري والكيميائي لمياه المستشفى</h2>
        <span style="font-size: 11px; color: #475569; font-weight: 600;">كود العينة: <strong>${test.sample_code}</strong> | تاريخ السحب والفحص: <strong>${test.test_date}</strong></span>
      </div>

      <table style="width: 100%; border-collapse: collapse; margin-bottom: 16px; font-size: 12px;">
        <tbody>
          <tr style="background: #f8fafc;">
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: bold; width: 25%; color: #334155;">نقطة سحب العينة:</td>
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: bold; color: #0f172a;">${test.water_source_ar}</td>
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: bold; width: 25%; color: #334155;">نوع الفحص والتكرار:</td>
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: bold; color: #0d9488;">${typeAr}</td>
          </tr>
          <tr>
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: bold; color: #334155;">المختبر الفاحص:</td>
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: bold; color: #1e293b;">${test.laboratory_name}</td>
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1; font-weight: bold; color: #334155;">فريق سحب العينة:</td>
            <td style="padding: 8px 12px; border: 1px solid #cbd5e1;">${test.sample_collector}</td>
          </tr>
        </tbody>
      </table>

      <!-- Lab Results Table -->
      <h4 style="margin: 0 0 8px 0; color: #0f172a; font-size: 13px;">النتائج المخبرية المعتمدة ومطابقتها للمواصفات:</h4>
      <table style="width: 100%; border-collapse: collapse; margin-bottom: 16px; font-size: 11px;">
        <thead>
          <tr style="background: #0f766e; color: #ffffff;">
            <th style="padding: 8px; border: 1px solid #0f766e;">المحدد المخبري</th>
            <th style="padding: 8px; border: 1px solid #0f766e;">النتيجة المخبرية</th>
            <th style="padding: 8px; border: 1px solid #0f766e;">الحدود المعيارية المسموحة (WHO / CBAHI)</th>
            <th style="padding: 8px; border: 1px solid #0f766e;">المطابقة</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; font-weight: bold;">بكتيريا القولون الكلية (Total Coliform)</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; font-weight: 900; color: #15803d;">${test.total_coliform_cfu} CFU / 100 ml</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0;">0 CFU / 100 ml (خالٍ تماماً)</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; text-align: center; color: #15803d; font-weight: bold;">مطابق ✓</td>
          </tr>
          <tr style="background: #f8fafc;">
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; font-weight: bold;">بكتيريا الإشريكية القولونية (E. Coli)</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; font-weight: 900; color: #15803d;">${test.e_coli_cfu} CFU / 100 ml</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0;">0 CFU / 100 ml (خالٍ تماماً)</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; text-align: center; color: #15803d; font-weight: bold;">مطابق ✓</td>
          </tr>
          <tr>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; font-weight: bold;">فحص بكتيريا الليجيونيلا (Legionella)</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; font-weight: 900; color: #15803d;">
              ${test.legionella_tested ? (test.legionella_result === 'negative' ? 'سلبية (خالٍ تماماً Negative)' : 'إيجابية') : 'غير مطلوب في هذه العينة'}
            </td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0;">سلبي تام (< 1 CFU / 1000 ml)</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; text-align: center; color: #15803d; font-weight: bold;">مطابق ✓</td>
          </tr>
          <tr style="background: #f8fafc;">
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; font-weight: bold;">الرقم الهيدروجيني (pH Level)</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; font-weight: 900;">${test.ph_level}</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0;">6.5 - 8.5</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; text-align: center; color: #15803d; font-weight: bold;">مطابق ✓</td>
          </tr>
          <tr>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; font-weight: bold;">الكلور المتبقي الحر (Residual Chlorine)</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; font-weight: 900;">${test.residual_chlorine_ppm} ppm</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0;">0.2 - 0.5 ppm (مياه الشرب) / 0 ppm (RO)</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; text-align: center; color: #15803d; font-weight: bold;">مطابق ✓</td>
          </tr>
          <tr style="background: #f8fafc;">
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; font-weight: bold;">الأملاح الكلية الذائبة (TDS) والعكارة</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; font-weight: 900;">${test.tds_ppm} ppm | ${test.turbidity_ntu} NTU</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0;">TDS < 500 ppm | Turbidity < 5 NTU</td>
            <td style="padding: 6px 8px; border: 1px solid #e2e8f0; text-align: center; color: #15803d; font-weight: bold;">مطابق ✓</td>
          </tr>
        </tbody>
      </table>

      <!-- Compliance Summary Box -->
      <div style="background: #ecfdf5; border: 1px solid #a7f3d0; border-radius: 6px; padding: 10px; margin-bottom: 16px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
          <strong style="color: #065f46; font-size: 12px;">خلاصة التقرير المخبري:</strong>
          <span style="background: #059669; color: #ffffff; font-weight: 900; font-size: 11px; padding: 2px 10px; border-radius: 4px;">
            المياه صالحة وآمنة ومطابقة لمعايير سباهي (CBAHI Compliant)
          </span>
        </div>
        <p style="margin: 0; font-size: 11px; color: #047857; line-height: 1.5;">${test.notes}</p>
      </div>

      <!-- Signatures Footer -->
      <div style="margin-top: 24px; padding-top: 12px; border-top: 1px solid #cbd5e1; display: flex; justify-content: space-between;">
        <div style="text-align: center; width: 30%;">
          <div style="font-size: 11px; font-weight: bold; color: #475569;">مسؤول الفحوصات وسحب العينات</div>
          <div style="font-size: 12px; font-weight: 900; color: #0d9488; margin-top: 4px;">م/ نجيب غازي</div>
          <div style="font-size: 9px; color: #64748b;">قسم السلامة والصحة المهنية</div>
          <div style="margin-top: 8px; font-family: monospace; font-size: 10px; color: #0d9488;">[ توقيع الفاحص ]</div>
        </div>
        <div style="text-align: center; width: 30%;">
          <div style="font-size: 11px; font-weight: bold; color: #475569;">مدير المختبر المرجعي الفاحص</div>
          <div style="font-size: 12px; font-weight: 900; color: #0f172a; margin-top: 4px;">د/ فؤاد الزبيري</div>
          <div style="font-size: 9px; color: #64748b;">مختبر الصحة العامة المعتمد</div>
          <div style="margin-top: 8px; font-family: monospace; font-size: 10px; color: #059669;">[ مصادقة مخبرية رسمية ]</div>
        </div>
        <div style="text-align: center; width: 30%;">
          <div style="font-size: 11px; font-weight: bold; color: #475569;">رئيس لجنة السلامة FMS</div>
          <div style="font-size: 12px; font-weight: 900; color: #0f172a; margin-top: 4px;">د/ محمد السراجي</div>
          <div style="font-size: 9px; color: #64748b;">المدير العام لمستشفى آزال</div>
          <div style="margin-top: 8px; font-family: monospace; font-size: 10px; color: #059669;">[ معتمد CBAHI FMS.37 ]</div>
        </div>
      </div>
    </div>
  `;

  executeSmartPrint(html, {
    title: `شهادة فحص المياه FMS.37 - ${test.sample_code}`,
    subtitle: 'سجل سباهي الرسمي للفحوصات البكتيرية والكيميائية الدورية للمياه (FMS.37)',
    refNumber: test.sample_code,
    department: test.water_source_ar,
    inspectorName: test.sample_collector
  });
}

/**
 * 4. FMS.3 Safety Committee Meeting Minutes & Quarterly Tour Print Template
 */
export function printCbahiCommitteeReport(item: CbahiSafetyCommitteeItem) {
  const isTour = item.record_type === 'quarterly_tour';
  const headerTitle = isTour ? `تقرير جولة السلامة والمرافق الربع سنوية المشتركة (${item.quarter})` :
                              `محضر الاجتماع الدوري رقم (${item.meeting_number}) للجنة السلامة وإدارة المرافق`;

  const capRowsHtml = (item.cap_actions && item.cap_actions.length > 0)
    ? item.cap_actions.map((cap, idx) => `
      <tr style="background: ${idx % 2 === 0 ? '#ffffff' : '#f8fafc'};">
        <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-weight: bold; text-align: center;">${idx + 1}</td>
        <td style="padding: 6px 8px; border: 1px solid #cbd5e1; color: #b91c1c; font-weight: 600;">${cap.deficiency}</td>
        <td style="padding: 6px 8px; border: 1px solid #cbd5e1; color: #15803d; font-weight: 600;">${cap.corrective_action}</td>
        <td style="padding: 6px 8px; border: 1px solid #cbd5e1;">${cap.department} (${cap.responsible_person})</td>
        <td style="padding: 6px 8px; border: 1px solid #cbd5e1; text-align: center; font-family: monospace;">${cap.target_date}</td>
        <td style="padding: 6px 8px; border: 1px solid #cbd5e1; text-align: center; font-weight: bold; color: ${cap.status === 'completed' ? '#15803d' : '#b45309'};">
          ${cap.status === 'completed' ? 'مغلقة ومحققة ✓' : 'قيد المتابعة'}
        </td>
      </tr>
    `).join('')
    : `<tr><td colspan="6" style="padding: 10px; text-align: center; color: #64748b; border: 1px solid #cbd5e1;">لا توجد إجراءات تصحيحية مفتوحة - جميع بنود السلامة مطابقة بنسبة 100%</td></tr>`;

  const attendeesHtml = item.attendees_list.map(att => `<span style="background: #f1f5f9; border: 1px solid #cbd5e1; padding: 3px 8px; border-radius: 4px; font-size: 10px; margin: 2px; display: inline-block;">${att}</span>`).join(' ');
  const agendaHtml = item.agenda_topics.map((top, i) => `<li style="margin-bottom: 4px; font-size: 11px;">${top}</li>`).join('');
  const decisionsHtml = item.decisions_and_recommendations.map((dec, i) => `<li style="margin-bottom: 4px; font-size: 11px;"><strong>${dec}</strong></li>`).join('');

  const html = `
    <div style="font-family: inherit; direction: rtl; text-align: right;">
      <div style="background: #f8fafc; border: 2px solid #0f766e; border-radius: 8px; padding: 14px; margin-bottom: 16px; text-align: center;">
        <span style="font-size: 10px; font-weight: bold; color: #0f766e; letter-spacing: 1px; display: block;">سجل الامتثال لمعايير المركز السعودي لاعتماد المنشآت الصحية (CBAHI FMS.3)</span>
        <h2 style="margin: 4px 0; font-size: 17px; color: #0f172a; font-weight: 900;">${headerTitle}</h2>
        <span style="font-size: 11px; color: #475569; font-weight: 600;">تاريخ الانعقاد / الجولة: <strong>${item.date}</strong> | المكان: <strong>${item.location}</strong></span>
      </div>

      <!-- Meeting Details Grid -->
      <table style="width: 100%; border-collapse: collapse; margin-bottom: 14px; font-size: 11px;">
        <tbody>
          <tr style="background: #f8fafc;">
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1; font-weight: bold; width: 22%; color: #334155;">رئيس اللجنة:</td>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1; font-weight: bold; color: #0f172a;">${item.chairperson}</td>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1; font-weight: bold; width: 22%; color: #334155;">مقرر اللجنة:</td>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1; font-weight: bold; color: #0f766e;">${item.secretary}</td>
          </tr>
          <tr>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1; font-weight: bold; color: #334155;">منسق الجودة والاعتماد:</td>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1; font-weight: bold;">${item.quality_coordinator}</td>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1; font-weight: bold; color: #334155;">عدد الأعضاء الحاضرين:</td>
            <td style="padding: 6px 10px; border: 1px solid #cbd5e1;">${item.attendees_count} أعضاء (اكتمال النصاب القانوني)</td>
          </tr>
        </tbody>
      </table>

      <!-- Attendees -->
      <div style="margin-bottom: 14px; border: 1px solid #e2e8f0; border-radius: 6px; padding: 8px; background: #ffffff;">
        <strong style="font-size: 11px; color: #0f172a; display: block; margin-bottom: 4px;">الأعضاء الحاضرون والتوقيعات:</strong>
        <div>${attendeesHtml}</div>
      </div>

      <!-- Agenda & Decisions Grid -->
      <div style="display: flex; gap: 12px; margin-bottom: 14px;">
        <div style="flex: 1; border: 1px solid #cbd5e1; border-radius: 6px; padding: 10px; background: #ffffff;">
          <h4 style="margin: 0 0 6px 0; font-size: 12px; color: #0f766e; border-bottom: 1px solid #cbd5e1; padding-bottom: 4px;">جدول الأعمال والمحاور:</h4>
          <ul style="margin: 0; padding-right: 18px; color: #334155;">${agendaHtml}</ul>
        </div>
        <div style="flex: 1; border: 1px solid #cbd5e1; border-radius: 6px; padding: 10px; background: #ffffff;">
          <h4 style="margin: 0 0 6px 0; font-size: 12px; color: #1e3a8a; border-bottom: 1px solid #cbd5e1; padding-bottom: 4px;">القرارات والتوصيات المعتمدة:</h4>
          <ul style="margin: 0; padding-right: 18px; color: #1e293b;">${decisionsHtml}</ul>
        </div>
      </div>

      <!-- CAP Plan (Corrective Action Plan) -->
      <h4 style="margin: 0 0 6px 0; font-size: 13px; color: #b91c1c;">خطة العمل التصحيحية الفورية لمعالجة الملاحظات (Corrective Action Plan - CAP):</h4>
      <table style="width: 100%; border-collapse: collapse; margin-bottom: 16px; font-size: 11px;">
        <thead>
          <tr style="background: #b91c1c; color: #ffffff;">
            <th style="padding: 6px; border: 1px solid #b91c1c; width: 4%;">#</th>
            <th style="padding: 6px; border: 1px solid #b91c1c; width: 28%;">الملاحظة / المخالفة المرصودة</th>
            <th style="padding: 6px; border: 1px solid #b91c1c; width: 28%;">الإجراء التصحيحي الواجب تنفيذه</th>
            <th style="padding: 6px; border: 1px solid #b91c1c; width: 18%;">الجهة المسؤولة</th>
            <th style="padding: 6px; border: 1px solid #b91c1c; width: 11%;">تاريخ الإنجاز</th>
            <th style="padding: 6px; border: 1px solid #b91c1c; width: 11%;">حالة الإغلاق</th>
          </tr>
        </thead>
        <tbody>
          ${capRowsHtml}
        </tbody>
      </table>

      <!-- Signatures Footer -->
      <div style="margin-top: 24px; padding-top: 12px; border-top: 1px solid #cbd5e1; display: flex; justify-content: space-between;">
        <div style="text-align: center; width: 30%;">
          <div style="font-size: 11px; font-weight: bold; color: #475569;">مقرر لجنة السلامة</div>
          <div style="font-size: 12px; font-weight: 900; color: #0f766e; margin-top: 4px;">${item.secretary}</div>
          <div style="margin-top: 6px; font-family: monospace; font-size: 10px; color: #059669;">[ توقيع تحرير المحضر ]</div>
        </div>
        <div style="text-align: center; width: 30%;">
          <div style="font-size: 11px; font-weight: bold; color: #475569;">منسق الجودة والاعتماد</div>
          <div style="font-size: 12px; font-weight: 900; color: #0f172a; margin-top: 4px;">${item.quality_coordinator}</div>
          <div style="margin-top: 6px; font-family: monospace; font-size: 10px; color: #059669;">[ مراجعة المطابقة والجودة ]</div>
        </div>
        <div style="text-align: center; width: 30%;">
          <div style="font-size: 11px; font-weight: bold; color: #475569;">رئيس اللجنة / المدير العام</div>
          <div style="font-size: 12px; font-weight: 900; color: #0f172a; margin-top: 4px;">${item.chairperson}</div>
          <div style="margin-top: 6px; font-family: monospace; font-size: 10px; color: #059669;">[ اعتماد ومصادقة رسمية ]</div>
        </div>
      </div>
    </div>
  `;

  executeSmartPrint(html, {
    title: `${headerTitle} - ${item.id}`,
    subtitle: 'سجل سباهي الرسمي لاجتماعات وجولات لجنة السلامة وإدارة المرافق (FMS.3)',
    refNumber: item.id,
    department: 'لجنة السلامة وإدارة المرافق FMS',
    inspectorName: item.secretary
  });
}

/**
 * 5. Comprehensive FMS Audit Portfolio (المحفظة التوثيقية الشاملة لسباهي لجميع معايير FMS الـ 39)
 */
export function printComprehensiveCbahiPortfolio(
  standards: CbahiStandardItem[],
  drills: CbahiFireDrill[],
  generators: CbahiGeneratorTest[],
  water: CbahiWaterTest[],
  committee: CbahiSafetyCommitteeItem[]
) {
  const avgCompliance = Math.round(
    standards.reduce((acc, s) => acc + s.complianceRate, 0) / standards.length
  );
  const esrStandards = standards.filter(s => s.esr);
  const totalEsr = esrStandards.length;
  const esrCompliant = esrStandards.filter(s => s.complianceRate >= 90).length;

  const standardsRows = standards.map((std, idx) => `
    <tr style="background: ${idx % 2 === 0 ? '#ffffff' : '#f8fafc'};">
      <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-weight: bold; text-align: center; font-family: monospace; color: #0f766e;">${std.code}</td>
      <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-weight: bold; color: #0f172a;">
        ${std.titleAr}
        ${std.esr ? '<span style="background: #fee2e2; color: #b91c1c; font-size: 9px; padding: 1px 4px; border-radius: 3px; margin-right: 4px; font-weight: bold;">ESR معيار حرج</span>' : ''}
        <div style="font-size: 10px; color: #64748b; margin-top: 2px;">${std.titleEn}</div>
      </td>
      <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-size: 10px; color: #334155;">${std.category}</td>
      <td style="padding: 6px 8px; border: 1px solid #cbd5e1; text-align: center; font-weight: 900; color: ${std.complianceRate >= 95 ? '#15803d' : '#0369a1'};">
        ${std.complianceRate}%
      </td>
      <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-size: 10px; color: #475569;">
        ${std.requiredDocuments.slice(0, 2).join(' • ')}
      </td>
      <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-family: monospace; font-size: 10px; color: #0f766e; text-align: center;">
        ${std.evidenceRef}
      </td>
    </tr>
  `).join('');

  const html = `
    <div style="font-family: inherit; direction: rtl; text-align: right;">
      <!-- Title Card -->
      <div style="background: #0f766e; color: #ffffff; border-radius: 8px; padding: 16px; margin-bottom: 20px; text-align: center;">
        <span style="font-size: 11px; font-weight: bold; color: #99f6e4; letter-spacing: 1px; display: block;">المركز السعودي لاعتماد المنشآت الصحية (CBAHI - 3rd Edition)</span>
        <h1 style="margin: 6px 0; font-size: 22px; font-weight: 900;">المحفظة التوثيقية الشاملة لبرنامج إدارة المرافق والسلامة (FMS Audit Portfolio)</h1>
        <p style="margin: 0; font-size: 12px; color: #ccfbf1;">مستشفى آزال النموذجي • السجل الكامل لمعايير السلامة الـ 39 والأدلة الميدانية والسجلات المركزية</p>
      </div>

      <!-- High Level Stats Cards -->
      <div style="display: flex; gap: 10px; margin-bottom: 20px;">
        <div style="flex: 1; background: #f0fdf4; border: 1px solid #86efac; border-radius: 6px; padding: 10px; text-align: center;">
          <span style="font-size: 10px; color: #166534; font-weight: bold; display: block;">نسبة الجاهزية العامة</span>
          <strong style="font-size: 24px; color: #15803d;">${avgCompliance}%</strong>
          <span style="font-size: 10px; color: #166534; display: block;">مطابقة ممتازة (CBAHI Ready)</span>
        </div>
        <div style="flex: 1; background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 6px; padding: 10px; text-align: center;">
          <span style="font-size: 10px; color: #1e40af; font-weight: bold; display: block;">معايير السلامة الإجمالية</span>
          <strong style="font-size: 24px; color: #1d4ed8;">39</strong>
          <span style="font-size: 10px; color: #1e40af; display: block;">معياراً شاملاً لكافة المجالات</span>
        </div>
        <div style="flex: 1; background: #fef2f2; border: 1px solid #fecaca; border-radius: 6px; padding: 10px; text-align: center;">
          <span style="font-size: 10px; color: #991b1b; font-weight: bold; display: block;">معايير الأمان الحرجة (ESR)</span>
          <strong style="font-size: 24px; color: #b91c1c;">${esrCompliant} / ${totalEsr}</strong>
          <span style="font-size: 10px; color: #991b1b; display: block;">مطابقة حرجة 100%</span>
        </div>
        <div style="flex: 1; background: #faf5ff; border: 1px solid #e9d5ff; border-radius: 6px; padding: 10px; text-align: center;">
          <span style="font-size: 10px; color: #6b21a8; font-weight: bold; display: block;">السجلات المركزية المعتمدة</span>
          <strong style="font-size: 24px; color: #7e22ce;">4</strong>
          <span style="font-size: 10px; color: #6b21a8; display: block;">FMS.18, 31, 37, 3</span>
        </div>
      </div>

      <!-- Registers Summary Section -->
      <h3 style="margin: 0 0 8px 0; font-size: 14px; color: #0f172a; border-bottom: 2px solid #0f766e; padding-bottom: 4px;">
        أولاً: ملخص بوابات وسجلات سباهي المركزية الموثقة بالنظام:
      </h3>
      <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 11px;">
        <thead>
          <tr style="background: #334155; color: #ffffff;">
            <th style="padding: 6px 8px; border: 1px solid #334155;">السجل المركزي المعتمد</th>
            <th style="padding: 6px 8px; border: 1px solid #334155;">المعيار المرتبط</th>
            <th style="padding: 6px 8px; border: 1px solid #334155; text-align: center;">عدد العمليات الموثقة</th>
            <th style="padding: 6px 8px; border: 1px solid #334155;">آخر عملية تدقيق مسجلة</th>
            <th style="padding: 6px 8px; border: 1px solid #334155; text-align: center;">حالة الامتثال</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-weight: bold;">سجل فرضيات وتجارب الحريق والإخلاء</td>
            <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-family: monospace; font-weight: bold; color: #b91c1c;">FMS.18 (ESR)</td>
            <td style="padding: 6px 8px; border: 1px solid #cbd5e1; text-align: center; font-weight: bold;">${drills.length} فرضيات (3 ورديات)</td>
            <td style="padding: 6px 8px; border: 1px solid #cbd5e1;">${drills[0]?.drill_date || '2026-08-20'} (${drills[0]?.department || 'الطوارئ'})</td>
            <td style="padding: 6px 8px; border: 1px solid #cbd5e1; text-align: center; font-weight: bold; color: #15803d;">مطابق بنسبة 97% ✓</td>
          </tr>
          <tr style="background: #f8fafc;">
            <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-weight: bold;">سجل اختبارات المولدات والأحمال الكهربائية</td>
            <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-family: monospace; font-weight: bold; color: #0284c7;">FMS.31 (ESR)</td>
            <td style="padding: 6px 8px; border: 1px solid #cbd5e1; text-align: center; font-weight: bold;">${generators.length} اختبارات موثقة</td>
            <td style="padding: 6px 8px; border: 1px solid #cbd5e1;">${generators[0]?.test_date || '2026-09-14'} (زمن التحويل ${generators[0]?.auto_start_time_seconds || 7.2} ثانية)</td>
            <td style="padding: 6px 8px; border: 1px solid #cbd5e1; text-align: center; font-weight: bold; color: #15803d;">مطابق بنسبة 98% ✓</td>
          </tr>
          <tr>
            <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-weight: bold;">سجل الفحوصات البكتيرية والكيميائية للمياه</td>
            <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-family: monospace; font-weight: bold; color: #0d9488;">FMS.37 (ESR)</td>
            <td style="padding: 6px 8px; border: 1px solid #cbd5e1; text-align: center; font-weight: bold;">${water.length} عينات مفحوصة</td>
            <td style="padding: 6px 8px; border: 1px solid #cbd5e1;">${water[0]?.test_date || '2026-09-10'} (خلو تام من الميكروبات)</td>
            <td style="padding: 6px 8px; border: 1px solid #cbd5e1; text-align: center; font-weight: bold; color: #15803d;">مطابق بنسبة 99% ✓</td>
          </tr>
          <tr style="background: #f8fafc;">
            <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-weight: bold;">سجل اجتماعات وجولات لجنة السلامة مع خطة CAP</td>
            <td style="padding: 6px 8px; border: 1px solid #cbd5e1; font-family: monospace; font-weight: bold; color: #7e22ce;">FMS.3 (ESR)</td>
            <td style="padding: 6px 8px; border: 1px solid #cbd5e1; text-align: center; font-weight: bold;">${committee.length} محاضر معتمدة</td>
            <td style="padding: 6px 8px; border: 1px solid #cbd5e1;">${committee[0]?.date || '2026-09-08'} (إغلاق خطط CAP)</td>
            <td style="padding: 6px 8px; border: 1px solid #cbd5e1; text-align: center; font-weight: bold; color: #15803d;">مطابق بنسبة 96% ✓</td>
          </tr>
        </tbody>
      </table>

      <!-- Full 39 Standards Table -->
      <h3 style="margin: 0 0 8px 0; font-size: 14px; color: #0f172a; border-bottom: 2px solid #0f766e; padding-bottom: 4px;">
        ثانياً: جدول تدقيق معايير إدارة المرافق والسلامة الـ 39 ونسب الامتثال والأدلة المرجعية:
      </h3>
      <table style="width: 100%; border-collapse: collapse; margin-bottom: 24px; font-size: 10px;">
        <thead>
          <tr style="background: #0f766e; color: #ffffff;">
            <th style="padding: 6px; border: 1px solid #0f766e; width: 8%; text-align: center;">رمز المعيار</th>
            <th style="padding: 6px; border: 1px solid #0f766e; width: 34%;">عنوان المعيار الرسمي (CBAHI FMS)</th>
            <th style="padding: 6px; border: 1px solid #0f766e; width: 18%;">مجال السلامة</th>
            <th style="padding: 6px; border: 1px solid #0f766e; width: 8%; text-align: center;">الامتثال</th>
            <th style="padding: 6px; border: 1px solid #0f766e; width: 20%;">الوثائق والمتطلبات الميدانية</th>
            <th style="padding: 6px; border: 1px solid #0f766e; width: 12%; text-align: center;">مرجع الدليل</th>
          </tr>
        </thead>
        <tbody>
          ${standardsRows}
        </tbody>
      </table>

      <!-- Certification & Leadership Signatures -->
      <div style="background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 6px; padding: 14px; margin-top: 20px;">
        <h4 style="margin: 0 0 8px 0; font-size: 12px; color: #0f172a; text-align: center;">إقرار المصادقة على المحفظة التوثيقية لبرنامج FMS والجاهزية لزيارة مقيمي المركز السعودي CBAHI</h4>
        <p style="font-size: 11px; color: #475569; text-align: center; margin: 0 0 16px 0;">
          نشهد بأن كافة البيانات والسجلات المرفقة في هذه المحفظة تم تدقيقها ميدانياً ومطابقتها للمتطلبات الإلزامية ومعايير الاعتماد الوطنية.
        </p>
        <div style="display: flex; justify-content: space-between; border-top: 1px solid #cbd5e1; padding-top: 12px;">
          <div style="text-align: center; width: 30%;">
            <div style="font-size: 11px; font-weight: bold; color: #475569;">رئيس قسم السلامة FMS</div>
            <div style="font-size: 12px; font-weight: 900; color: #0f766e; margin-top: 4px;">م/ نجيب غازي</div>
            <div style="font-size: 9px; color: #64748b;">ضابط السلامة وإدارة المرافق</div>
            <div style="margin-top: 6px; font-family: monospace; font-size: 10px; color: #059669;">[ مصادقة وتوقيع ]</div>
          </div>
          <div style="text-align: center; width: 30%;">
            <div style="font-size: 11px; font-weight: bold; color: #475569;">منسق الجودة والاعتماد</div>
            <div style="font-size: 12px; font-weight: 900; color: #0f172a; margin-top: 4px;">د/ نبيل عصار</div>
            <div style="font-size: 9px; color: #64748b;">إدارة الجودة وسلامة المرضى</div>
            <div style="margin-top: 6px; font-family: monospace; font-size: 10px; color: #059669;">[ تم التدقيق والتحقق ]</div>
          </div>
          <div style="text-align: center; width: 30%;">
            <div style="font-size: 11px; font-weight: bold; color: #475569;">رئيس مجلس الإدارة / المدير العام</div>
            <div style="font-size: 12px; font-weight: 900; color: #0f172a; margin-top: 4px;">د/ محمد السراجي</div>
            <div style="font-size: 9px; color: #64748b;">المدير العام لمستشفى آزال</div>
            <div style="margin-top: 6px; font-family: monospace; font-size: 10px; color: #059669;">[ اعتماد نهائي CBAHI ]</div>
          </div>
        </div>
      </div>
    </div>
  `;

  executeSmartPrint(html, {
    title: 'المحفظة التوثيقية الشاملة لسباهي CBAHI FMS Audit Portfolio',
    subtitle: 'المحفظة التوثيقية الرسمية لبرنامج إدارة المرافق والسلامة (39 معياراً) • مستشفى آزال النموذجي',
    refNumber: 'PORTFOLIO-CBAHI-2026-FMS',
    department: 'إدارة السلامة وإدارة المرافق والجودة'
  });
}
