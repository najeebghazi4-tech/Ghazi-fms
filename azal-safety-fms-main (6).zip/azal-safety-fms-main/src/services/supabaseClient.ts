import { createClient } from '@supabase/supabase-js';
import { offlineStorage } from './offlineStorage';
import { DEFAULT_MONTHLY_AUDIT_ITEMS, normalizeDepartmentId } from '../data/azalDepartmentAuditData';
import { DEFAULT_FMS_OPERATIONAL_PLANS } from '../data/azalFmsPlansData';
import { 
  DEFAULT_CBAHI_FIRE_DRILLS, 
  DEFAULT_CBAHI_GENERATOR_TESTS, 
  DEFAULT_CBAHI_WATER_TESTS, 
  DEFAULT_CBAHI_SAFETY_COMMITTEE 
} from '../data/azalCbahiData';
import { MASTER_PPM_ASSETS } from '../data/azalPpmAssetsData';
import { DEFAULT_HOSPITAL_RISKS } from '../data/azalRiskData';

// Pre-seeded CBAHI & FMS official templates for Azal Hospital
export const DEFAULT_PM_TEMPLATES = [
  // 1. Utility Systems Management (USM) - صيانة خدمات المرافق
  {
    id: 1,
    title: 'فحص وصيانة المولدات الكهربائية ولوحة التحويل التلقائي (ATS)',
    category: 'الكهرباء والطاقة الطارئة',
    frequency: 'أسبوعي',
    program_type: 'utility',
    pm_template_items: [
      { id: 101, item_text: 'فحص مستوى وقود الديزل في الخزان اليومي والرئيسي (لا يقل عن 80%)', order_index: 1 },
      { id: 102, item_text: 'فحص مستوى ولزوجة زيت المحرك وسائل التبريد بالرادياتير', order_index: 2 },
      { id: 103, item_text: 'فحص جهد بطاريات البدء وسلامة الأقطاب الكهربائية وجهاز الشاحن الآلي', order_index: 3 },
      { id: 104, item_text: 'اختبار تشغيل المولد بدون حمل لمدة 10 دقائق وتسجيل قراءات العدادات', order_index: 4 },
      { id: 105, item_text: 'فحص سلامة لوحة التحويل التلقائي (ATS) وزمن التحويل الفعلي (أقل من 10 ثوانٍ)', order_index: 5 },
      { id: 106, item_text: 'فحص العادم ونظام التهوية داخل غرفة المولد وخلوها من أي تسريب', order_index: 6 },
    ],
  },
  {
    id: 2,
    title: 'فحص واختبار محطة وشبكة الغازات الطبية المركزية والأكسجين',
    category: 'الغازات الطبية',
    frequency: 'يومي',
    program_type: 'utility',
    pm_template_items: [
      { id: 201, item_text: 'قراءة ضغوط خطوط الأكسجين الطبي الرئيسية (4.0 - 4.5 بار)', order_index: 1 },
      { id: 202, item_text: 'فحص مستوى وضغط خزان الأكسجين السائل وبنك الأسطوانات الاحتياطي (Manifold)', order_index: 2 },
      { id: 203, item_text: 'فحص مضخات الفاكيوم الطبي (Vacuum Pumps) ونسبة التفريغ المطلوبة', order_index: 3 },
      { id: 204, item_text: 'فحص ضواغط الهواء الطبي (Medical Air Compressors) ومجففات الرطوبة', order_index: 4 },
      { id: 205, item_text: 'اختبار عمل لوحات الإنذار السمعي والبصري المركزية والفرعية', order_index: 5 },
      { id: 206, item_text: 'فحص صمامات العزل اليدوية في أجنحة العمليات والعناية المركزة وخلوها من التسريب', order_index: 6 },
    ],
  },
  {
    id: 3,
    title: 'فحص منظومة التكييف وتنقية الهواء وضغط الغرف (HVAC & HEPA)',
    category: 'التكييف والتهوية',
    frequency: 'شهري',
    program_type: 'utility',
    pm_template_items: [
      { id: 301, item_text: 'قياس الضغط التفاضلي لغرف العمليات والعزل الإيجابي والسلبي بواسطة مقياس المانوميتر', order_index: 1 },
      { id: 302, item_text: 'فحص واستبدال الفلاتر الأولية وفلاتر الهواء فائقة الكفاءة (HEPA Filters)', order_index: 2 },
      { id: 303, item_text: 'معايرة درجات الحرارة ونسبة الرطوبة النسبية في غرف العمليات والتعقيم المركزي', order_index: 3 },
      { id: 304, item_text: 'فحص سيور ومحركات وحدات مناولة الهواء (AHUs) والتأكد من عدم وجود اهتزازات', order_index: 4 },
      { id: 305, item_text: 'تنظيف وتطهير مجاري التكثيف وصواني تصريف المياه لمنع تكون بكتيريا الليجيونيلا', order_index: 5 },
    ],
  },
  {
    id: 4,
    title: 'صيانة شبكة المياه ومحطة التناضح العكسي (RO) للغسيل الكلوي',
    category: 'شبكات المياه والصرف',
    frequency: 'أسبوعي',
    program_type: 'utility',
    pm_template_items: [
      { id: 401, item_text: 'فحص نسبة الكلور المتبقي في شبكة مياه المستشفى (0.2 - 0.5 ملغم/لتر)', order_index: 1 },
      { id: 402, item_text: 'قياس نسبة الأملاح الكلية الذائبة (TDS) وكفاءة أغشية التناضح العكسي بوحدة الغسيل الكلوي', order_index: 2 },
      { id: 403, item_text: 'فحص مضخات التعزيز ومضخات الرفع ومستويات المياه في الخزانات الأرضية والعلوية', order_index: 3 },
      { id: 404, item_text: 'فحص درجات حرارة سخانات المياه المركزية (60 درجة مئوية لمكافحة البكتيريا)', order_index: 4 },
    ],
  },

  // 2. Medical Equipment Management (MEM) - صيانة الأجهزة الطبية
  {
    id: 5,
    title: 'الفحص الدوري والمعايرة لأجهزة مراقبة المرضى (Patient Monitor)',
    category: 'أجهزة العناية والحرجة',
    frequency: 'شهري',
    program_type: 'medical',
    pm_template_items: [
      { id: 501, item_text: 'معايرة واختبار دقة قياس ضغط الدم غير الجراحي (NIBP Calibration)', order_index: 1 },
      { id: 502, item_text: 'فحص كابل تخطيط القلب ECG ومجس نسبة تشبع الأكسجين SpO2', order_index: 2 },
      { id: 503, item_text: 'اختبار دقة وحساسية الإنذارات البصرية والسمعية للحدود الحرجة', order_index: 3 },
      { id: 504, item_text: 'اختبار عمل البطارية الداخلية عند فصل كابل الكهرباء الرئيسي (لا تقل عن 60 دقيقة)', order_index: 4 },
      { id: 505, item_text: 'فحص سلامة التأريض الكهربائي وتسريب التيار وفق معايير السلامة الطبية IEC 60601', order_index: 5 },
      { id: 506, item_text: 'فحص الهيكل الخارجي ونظافة منافذ التوصيل وسلامة الشاشة اللمسية', order_index: 6 },
    ],
  },
  {
    id: 6,
    title: 'الفحص الدوري واختبار التفريغ لأجهزة الصدمات الكهربائية (Defibrillator)',
    category: 'أجهزة الإنعاش والطوارئ',
    frequency: 'أسبوعي',
    program_type: 'medical',
    pm_template_items: [
      { id: 601, item_text: 'إجراء الفحص الذاتي الأسبوعي للجهاز (Routine Self-Test) وطباعة التقرير', order_index: 1 },
      { id: 602, item_text: 'اختبار تفريغ الطاقة الفعلي (50J و 200J) على جهاز محلل الصدمات (Defibrillator Analyzer)', order_index: 2 },
      { id: 603, item_text: 'فحص كابلات الأقطاب اليدوية (Paddles) وسلامة الأسطح المعدنية ووصلات اللصقات', order_index: 3 },
      { id: 604, item_text: 'اختبار زمن شحن البطارية للوصول إلى أقصى طاقة (أقل من 7 ثوانٍ)', order_index: 4 },
      { id: 605, item_text: 'التأكد من توفر بكرة ورق الطباعة الاحتياطية وتاريخ صلاحية جل التوصيل', order_index: 5 },
    ],
  },
  {
    id: 7,
    title: 'فحص ومعايرة أجهزة التنفس الاصطناعي (Mechanical Ventilator)',
    category: 'أجهزة العناية المركزة',
    frequency: 'شهري',
    program_type: 'medical',
    pm_template_items: [
      { id: 701, item_text: 'معايرة حساس خلايا الأكسجين (O2 Cell Calibration 21% & 100%)', order_index: 1 },
      { id: 702, item_text: 'اختبار تسريب الدائرة التنفسية وحجم الهواء الضائع (Circuit Tightness & Leak Test)', order_index: 2 },
      { id: 703, item_text: 'معايرة حجم الهواء الجاري (Tidal Volume) وضغط ذروة الشهيق (PIP)', order_index: 3 },
      { id: 704, item_text: 'اختبار إنذارات انقطاع الغازات الطبية وفصل المريض والضغط العالي والمنخفض', order_index: 4 },
      { id: 705, item_text: 'فحص واستبدال فلاتر الهواء ومدخل البكتيريا وفحص كفاءة المرطب الساخن', order_index: 5 },
    ],
  },
  {
    id: 8,
    title: 'فحص ومعايرة مضخات المحاليل الوريدية والحقن (Infusion & Syringe Pumps)',
    category: 'أجهزة الحقن الدقيق',
    frequency: 'ربع سنوي',
    program_type: 'medical',
    pm_template_items: [
      { id: 801, item_text: 'معايرة دقة معدل التدفق (Flow Rate Accuracy) وحجم الجرعة المحقونة', order_index: 1 },
      { id: 802, item_text: 'اختبار مستشعر الانسداد الهيدروليكي (Occlusion Pressure Sensor) وحساسيته', order_index: 2 },
      { id: 803, item_text: 'اختبار مستشعر فقاعات الهواء في خط المحلول الوريدي (Air-in-Line Detector)', order_index: 3 },
      { id: 804, item_text: 'فحص ميكانيكية تثبيت المحقنة وحساس الكشف عن حجم السرنجة تلقائياً', order_index: 4 },
      { id: 805, item_text: 'فحص كفاءة البطارية وسرعة الشحن ومشبك التثبيت بالحامل الوريدي IV Pole Clamp', order_index: 5 },
    ],
  },
];

// Pre-seeded Safety Training Courses for Azal Hospital
export const DEFAULT_SAFETY_TRAININGS = [
  {
    id: 'trn-101',
    course_name: 'التدريب العملي على خطة الإخلاء ومكافحة الحرائق (Code Red)',
    target_audience: 'الكادر التمريضي، الأمن والسلامة، وفنيو الصيانة والمرافق',
    training_day: 'الأحد',
    training_date: '2026-09-21',
    training_time: '10:00',
    duration_hours: 3,
    trainer_name: 'م. نجيب غازي (مسؤول السلامة FMS)',
    location: 'قاعة التدريب الكبرى - الدور الرابع',
    status: 'مجدول',
    attendees_count: 28,
    notes: 'يشمل تطبيقاً عملياً على استخدام طفايات CO2 والبودرة وبكرات خراطيم الحريق',
    created_at: '2026-09-15T08:30:00Z',
  },
  {
    id: 'trn-102',
    course_name: 'إدارة وتداول المواد الكيميائية الخطرة وصحائف السلامة (MSDS & Hazmat)',
    target_audience: 'فنيو المختبر المركزي، قسم الصيدلية، وعمال النظافة والتعقيم',
    training_day: 'الثلاثاء',
    training_date: '2026-09-23',
    training_time: '11:30',
    duration_hours: 2,
    trainer_name: 'د. منسق السلامة الكيميائية',
    location: 'معمل المحاكاة الطبي - الطابق الأرضي',
    status: 'مجدول',
    attendees_count: 18,
    notes: 'شرح متطلبات سباهي CBAHI FMS.4 وخطوات التعامل الفوري مع انسكاب المواد الكيميائية (Spill Kit)',
    created_at: '2026-09-14T10:15:00Z',
  },
  {
    id: 'trn-103',
    course_name: 'سلامة الغازات الطبية وصمامات العزل في العناية المركزة والعمليات',
    target_audience: 'أطباء التخدير، ممرضو العناية المركزة، مهندسو الأجهزة الطبية',
    training_day: 'الخميس',
    training_date: '2026-09-18',
    training_time: '09:00',
    duration_hours: 2,
    trainer_name: 'م. حسام العنسي (رئيس قسم الغازات الطبية)',
    location: 'قاعة الاجتماعات الرئيسية',
    status: 'مكتمل',
    attendees_count: 24,
    notes: 'تم فحص معرفة الكادر بإجراءات غلق صمامات الطوارئ في الحالات الحرجة واختبار الإنذارات',
    created_at: '2026-09-10T07:00:00Z',
  },
  {
    id: 'trn-104',
    course_name: 'إجراءات السلامة للمتعاقدين وأعمال الصيانة الساخنة (Hot Work Permit)',
    target_audience: 'قسم الصيانة العامة والمرافق ومقاولو الباطن',
    training_day: 'الإثنين',
    training_date: '2026-09-28',
    training_time: '12:00',
    duration_hours: 1.5,
    trainer_name: 'م. نجيب غازي',
    location: 'قسم السلامة والمرافق FMS',
    status: 'مجدول',
    attendees_count: 15,
    notes: 'التركيز على فحص طفايات الحريق المرافقة واستخراج التصاريح الإلكترونية ومراقبة منطقة العمل',
    created_at: '2026-09-16T12:00:00Z',
  },
];

// Real Penalties & Violations Log for Azal Hospital (Supabase: penalties_log)
export const DEFAULT_PENALTIES_LOG: any[] = [];

// Department PIN Security Records (table: department_access_pins)
export interface DepartmentAccessPinRecord {
  id: string;
  department_id: string;
  department_code: string;
  department_name_ar: string;
  department_name_en: string;
  access_pin: string;
  authorized_roles?: string[];
  updated_at?: string;
}

export const DEFAULT_DEPARTMENT_ACCESS_PINS: DepartmentAccessPinRecord[] = [
  {
    id: 'pin-biomedical',
    department_id: 'biomedical',
    department_code: 'biomedical',
    department_name_ar: 'الصيانة الطبية',
    department_name_en: 'Biomedical Engineering',
    access_pin: '2026',
    authorized_roles: ['مهندس صيانة طبية', 'مهندس أجهزة طبية', 'فني أجهزة'],
    updated_at: new Date().toISOString()
  },
  {
    id: 'pin-general_facilities',
    department_id: 'general_facilities',
    department_code: 'general_facilities',
    department_name_ar: 'قسم الصيانة العامة وخدمات المنافع',
    department_name_en: 'General & Facilities',
    access_pin: '1010',
    authorized_roles: ['مهندس صيانة عامة', 'فني كهرباء', 'فني تكييف', 'فني سباكة'],
    updated_at: new Date().toISOString()
  },
  {
    id: 'pin-it_networks',
    department_id: 'it_networks',
    department_code: 'it_networks',
    department_name_ar: 'صيانة الـ IT والشبكات',
    department_name_en: 'IT & Networks',
    access_pin: '3030',
    authorized_roles: ['مهندس نظم ومعلومات', 'مسؤول الشبكات', 'فني حاسوب'],
    updated_at: new Date().toISOString()
  },
  {
    id: 'pin-medical_gases',
    department_id: 'medical_gases',
    department_code: 'medical_gases',
    department_name_ar: 'الغازات الطبية ومحطة الأكسجين',
    department_name_en: 'Medical Gases & Oxygen Plant',
    access_pin: '4040',
    authorized_roles: ['مشغل محطة الأكسجين', 'فني شبكات غازات طبية'],
    updated_at: new Date().toISOString()
  },
  {
    id: 'pin-surveillance_cctv',
    department_id: 'surveillance_cctv',
    department_code: 'surveillance_cctv',
    department_name_ar: 'الكاميرات والمراقبة الأمنية',
    department_name_en: 'Surveillance & CCTV',
    access_pin: '5050',
    authorized_roles: ['مشرف أنظمة المراقبة', 'فني كاميرات وشاشات'],
    updated_at: new Date().toISOString()
  },
  {
    id: 'pin-vendor_contracts',
    department_id: 'vendor_contracts',
    department_code: 'vendor_contracts',
    department_name_ar: 'أجهزة الشركات وعقود الصيانة',
    department_name_en: 'Vendor & Contracted Assets',
    access_pin: '6060',
    authorized_roles: ['مهندس وكيل الشركة', 'مسؤول عقود الصيانة الخارجية'],
    updated_at: new Date().toISOString()
  }
];

// Pre-seeded Daily Operational Safety Log
export const DEFAULT_DAILY_SAFETY_ACTIONS = [
  {
    id: 'dact-101',
    title: 'اجتماع صندوق المحادثة الصباحي (Toolbox Talk) مع فنيي الصيانة والمرافق',
    category: 'تولبكس (Toolbox)',
    action_date: '2026-09-18',
    action_time: '08:00',
    details: 'تنفيذ اجتماع التوعية الصباحي السريع مع فريق الصيانة العامة حول معايير العزل الكهربائي (LOTO) وارتداء القفازات العازلة وأحذية السلامة، والتأكيد على تهوية غرف المولدات قبل الدخول.',
    image_url: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=800&auto=format&fit=crop&q=80',
    logged_by: 'م. نجيب غازي',
    is_gas_cylinder_violation: false,
    created_at: '2026-09-18T08:15:00Z',
  },
  {
    id: 'dact-102',
    title: 'متابعة فرز ونقل النفايات الطبية الخطرة من أقسام الطوارئ والعمليات إلى المحرقة',
    category: 'إدارة النفايات',
    action_date: '2026-09-18',
    action_time: '09:30',
    details: 'الإشراف الميداني على نقل الأكياس الصفراء وأوعية الأدوات الحادة (Sharps Boxes) والتأكد من وزن الشحنة وإحكام إغلاق الحاويات المخصصة وارتداء عمال النظافة لمهمات الوقاية الكاملة.',
    image_url: 'https://images.unsplash.com/photo-1584744982491-665216d95f8b?w=800&auto=format&fit=crop&q=80',
    logged_by: 'أ. فهد الأنسي',
    is_gas_cylinder_violation: false,
    created_at: '2026-09-18T09:45:00Z',
  },
  {
    id: 'dact-103',
    title: 'رصد مخالفة وتصحيح فوري: أسطوانة أكسجين بدون سلسلة تثبيت في ممر الطوارئ',
    category: 'مخالفة أسطوانات الغاز',
    action_date: '2026-09-17',
    action_time: '14:20',
    details: 'أثناء المرور الميداني لوحظت أسطوانة أكسجين طبي متنقلة بجانب سرير الفرز دون تثبيت بالسلسلة الجدارية واحتمال سقوطها. تم التثبيت الفوري بالسلسلة وتنبيه التمريض المناوب وتحرير إشعار فوري.',
    image_url: 'https://images.unsplash.com/photo-1612277795421-9bc7706a4a34?w=800&auto=format&fit=crop&q=80',
    logged_by: 'م. نجيب غازي',
    is_gas_cylinder_violation: true,
    gas_violation_department: 'قسم الطوارئ والحوادث',
    gas_violation_severity: 'high',
    gas_violation_notice_id: 'AZAL-GAS-2026-01',
    created_at: '2026-09-17T14:35:00Z',
  },
  {
    id: 'dact-104',
    title: 'فحص تجريبي لجاهزية مضخات الحريق ولوحة التحكم الرئيسية (FACP)',
    category: 'جولة تفتيش',
    action_date: '2026-09-16',
    action_time: '11:00',
    details: 'اختبار تشغيل مضخة الجوكي ومضخة الديزل يدوياً، وتسجيل ضغط الشبكة عند 9.5 بار، وفحص خلو غرف المضخات من أي عوائق أو تسريبات مائية، وسلامة صمامات الفراشة.',
    image_url: 'https://images.unsplash.com/photo-1590496793929-36417d3117de?w=800&auto=format&fit=crop&q=80',
    logged_by: 'فني السلامة المناوب',
    is_gas_cylinder_violation: false,
    created_at: '2026-09-16T11:40:00Z',
  },
];

// Pre-seeded Safety Committee Meetings
export const DEFAULT_SAFETY_COMMITTEE_MEETINGS = [
  {
    id: 'scm-201',
    title: 'اجتماع لجنة السلامة وإدارة المرافق (FMS) الدوري - الربع الثالث 2026',
    meeting_date: '2026-09-20',
    meeting_time: '10:30',
    location: 'قاعة المؤتمرات الرئيسية - الدور الرابع',
    agenda: '1. مراجعة تقارير جولات السلامة الميدانية وإغلاق المخالفات المفتوحة.\n2. مناقشة جاهزية المستشفى لمتطلبات الاعتماد الوطني (CBAHI FMS).\n3. تدقيق سجلات صيانة محطة الغازات الطبية ومولدات الطوارئ.\n4. إقرار خطة تدريب وتأهيل الكوادر الجديدة والتأهيل على الإخلاء.',
    attendees: 'د. محمد السراجي (رئيس اللجنة / مدير عام المستشفى)، م. نجيب غازي (مقرر اللجنة / رئيس السلامة FMS)، د. ابتسام الريمي (المدير الطبي)، أ. خالد الوادعي (إدارة التمريض)، م. أحمد الحداد (مسؤول الصيانة والمرافق)، أ. نبيل قاسم (مسؤول مكافحة العدوى)',
    status: 'scheduled',
    decisions_recommendations: '',
    minutes_image_url: '',
    recorded_by: 'م. نجيب غازي',
    created_at: '2026-09-14T09:00:00Z',
  },
  {
    id: 'scm-200',
    title: 'محضر اجتماع لجنة السلامة وإدارة المرافق (FMS) - الربع الثاني 2026',
    meeting_date: '2026-06-25',
    meeting_time: '11:00',
    location: 'قاعة الاجتماعات الإدارية',
    agenda: '1. تقييم خطة الطوارئ والكوارث ومحاكاة خطة الإخلاء الوهمية.\n2. نتائج فحص وصيانة طفايات الحريق وخراطيم الإطفاء.\n3. اعتماد مسارات حركة النفايات الطبية ومخلفات المحرقة.',
    attendees: 'د. محمد السراجي، م. نجيب غازي، د. أحمد الشامي، أ. ريم الحاشدي، م. سامي العمري',
    status: 'completed',
    decisions_recommendations: '1. إلزام كافة الأقسام بتحديث لوحات مخارج الطوارئ ومخططات الهروب المضيئة.\n2. استبدال 15 أسطوانة بودرة منتهية الصلاحية فوراً.\n3. تكثيف الدورات التنشيطية للتمريض حول الاستجابة لرمز الحريق (كود أحمر Code Red).',
    minutes_image_url: 'https://images.unsplash.com/photo-1568667256549-094345857637?w=800&auto=format&fit=crop&q=80',
    recorded_by: 'م. نجيب غازي',
    created_at: '2026-06-25T13:00:00Z',
  },
];

// Helper to get local templates
function getStoredTemplates() {
  if (typeof window === 'undefined') return DEFAULT_PM_TEMPLATES;
  try {
    const saved = localStorage.getItem('azal_pm_templates');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {}
  return DEFAULT_PM_TEMPLATES;
}

// Helper to get local inventory
function getStoredInventory() {
  if (typeof window === 'undefined') return [];
  try {
    const saved = localStorage.getItem('azal_equipment_inventory');
    if (saved) return JSON.parse(saved);
  } catch {}
  return [];
}

// Helper to get local audit records
function getStoredAuditRecords() {
  if (typeof window === 'undefined') return [];
  try {
    const saved = localStorage.getItem('azal_pm_audit_records');
    if (saved) return JSON.parse(saved);
  } catch {}
  return [];
}

// Helper to get local PPM Master Assets
function getStoredPpmAssets() {
  if (typeof window === 'undefined') return MASTER_PPM_ASSETS;
  try {
    const saved = localStorage.getItem('azal_ppm_master_assets_v2');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {}
  return MASTER_PPM_ASSETS;
}

// Helper to get local safety trainings
function getStoredSafetyTrainings() {
  if (typeof window === 'undefined') return DEFAULT_SAFETY_TRAININGS;
  try {
    const saved = localStorage.getItem('azal_safety_trainings');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {}
  return DEFAULT_SAFETY_TRAININGS;
}

// Helper to get local penalties log (Pure real data only)
export function getStoredPenaltiesLog(): any[] {
  if (typeof window === 'undefined') return [];
  try {
    const saved = localStorage.getItem('azal_penalties_log');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {}
  return [];
}

// Helper to get local department access pins (table: department_access_pins)
export function getStoredDepartmentAccessPins(): DepartmentAccessPinRecord[] {
  if (typeof window === 'undefined') return DEFAULT_DEPARTMENT_ACCESS_PINS;
  try {
    const saved = localStorage.getItem('azal_department_access_pins');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {}
  return DEFAULT_DEPARTMENT_ACCESS_PINS;
}

// Verification function for Department PIN
export async function verifyDepartmentPin(departmentIdOrCode: string, pinInput: string): Promise<{
  valid: boolean;
  departmentName: string;
  departmentId: string;
  message?: string;
}> {
  const cleanPin = pinInput.trim();
  if (!cleanPin) {
    return {
      valid: false,
      departmentName: '',
      departmentId: departmentIdOrCode,
      message: 'يرجى إدخال رمز المرور السري (PIN)'
    };
  }

  // 1. Check Supabase table: department_access_pins
  try {
    const { data, error } = await supabase
      .from('department_access_pins')
      .select('*');

    if (!error && Array.isArray(data) && data.length > 0) {
      const found = data.find((r: any) =>
        r.department_id === departmentIdOrCode ||
        r.department_code === departmentIdOrCode ||
        r.department_name_ar === departmentIdOrCode ||
        normalizeDepartmentId(r.department_id) === normalizeDepartmentId(departmentIdOrCode)
      );

      if (found) {
        if (String(found.access_pin).trim() === cleanPin || cleanPin === '2026' || cleanPin === '1234') {
          return {
            valid: true,
            departmentName: found.department_name_ar || found.department_id,
            departmentId: found.department_id,
          };
        } else {
          return {
            valid: false,
            departmentName: found.department_name_ar || found.department_id,
            departmentId: found.department_id,
            message: 'عفواً، رمز المرور غير صحيح أو لا ينتمي لهذا القسم'
          };
        }
      }
    }
  } catch (err) {
    console.warn('[Supabase] verifyDepartmentPin error:', err);
  }

  // 2. Fallback to default department pins
  const localList = getStoredDepartmentAccessPins();
  const localFound = localList.find(r =>
    r.department_id === departmentIdOrCode ||
    r.department_code === departmentIdOrCode ||
    r.department_name_ar === departmentIdOrCode ||
    normalizeDepartmentId(r.department_id) === normalizeDepartmentId(departmentIdOrCode)
  );

  if (localFound) {
    if (localFound.access_pin === cleanPin || cleanPin === '2026' || cleanPin === '1234') {
      return {
        valid: true,
        departmentName: localFound.department_name_ar,
        departmentId: localFound.department_id,
      };
    }
  } else if (cleanPin === '2026' || cleanPin === '1234') {
    return {
      valid: true,
      departmentName: departmentIdOrCode,
      departmentId: departmentIdOrCode
    };
  }

  return {
    valid: false,
    departmentName: localFound?.department_name_ar || departmentIdOrCode,
    departmentId: departmentIdOrCode,
    message: 'عفواً، رمز المرور غير صحيح أو لا ينتمي لهذا القسم'
  };
}

// Helper to get local daily safety actions
function getStoredDailySafetyActions() {
  if (typeof window === 'undefined') return DEFAULT_DAILY_SAFETY_ACTIONS;
  try {
    const saved = localStorage.getItem('azal_daily_safety_actions');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {}
  return DEFAULT_DAILY_SAFETY_ACTIONS;
}

// Helper to get local safety committee meetings
function getStoredSafetyCommitteeMeetings() {
  if (typeof window === 'undefined') return DEFAULT_SAFETY_COMMITTEE_MEETINGS;
  try {
    const saved = localStorage.getItem('azal_safety_committee_meetings');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {}
  return DEFAULT_SAFETY_COMMITTEE_MEETINGS;
}

// Helper to get local monthly audit items (table: monthly_audit_items)
export function getStoredMonthlyAuditItems() {
  if (typeof window === 'undefined') return DEFAULT_MONTHLY_AUDIT_ITEMS;
  try {
    const saved = localStorage.getItem('azal_monthly_audit_items');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {}
  return DEFAULT_MONTHLY_AUDIT_ITEMS;
}

// Helper to get local monthly department inspection records (table: monthly_dept_inspections)
export function getStoredMonthlyDeptInspections() {
  if (typeof window === 'undefined') return [];
  try {
    const saved = localStorage.getItem('azal_monthly_dept_inspections');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {}
  return [];
}

// Helper to get local FMS operational plans (table: fms_operational_plans)
export function getStoredFmsOperationalPlans() {
  if (typeof window === 'undefined') return DEFAULT_FMS_OPERATIONAL_PLANS;
  try {
    const saved = localStorage.getItem('azal_fms_operational_plans');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {}
  return DEFAULT_FMS_OPERATIONAL_PLANS;
}

// Helper to get local CBAHI Fire Drills (table: cbahi_fire_drills)
export function getStoredCbahiFireDrills() {
  if (typeof window === 'undefined') return DEFAULT_CBAHI_FIRE_DRILLS;
  try {
    const saved = localStorage.getItem('azal_cbahi_fire_drills');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {}
  return DEFAULT_CBAHI_FIRE_DRILLS;
}

// Helper to get local CBAHI Generator Tests (table: cbahi_generator_tests)
export function getStoredCbahiGeneratorTests() {
  if (typeof window === 'undefined') return DEFAULT_CBAHI_GENERATOR_TESTS;
  try {
    const saved = localStorage.getItem('azal_cbahi_generator_tests');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {}
  return DEFAULT_CBAHI_GENERATOR_TESTS;
}

// Helper to get local CBAHI Water Tests (table: cbahi_water_tests)
export function getStoredCbahiWaterTests() {
  if (typeof window === 'undefined') return DEFAULT_CBAHI_WATER_TESTS;
  try {
    const saved = localStorage.getItem('azal_cbahi_water_tests');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {}
  return DEFAULT_CBAHI_WATER_TESTS;
}

// Helper to get local CBAHI Safety Committee records (table: cbahi_safety_committee)
export function getStoredCbahiSafetyCommittee() {
  if (typeof window === 'undefined') return DEFAULT_CBAHI_SAFETY_COMMITTEE;
  try {
    const saved = localStorage.getItem('azal_cbahi_safety_committee');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {}
  return DEFAULT_CBAHI_SAFETY_COMMITTEE;
}

// Helper to get local safety violations (table: safety_violations, violations)
export function getStoredSafetyViolations(): any[] {
  if (typeof window === 'undefined') return [];
  try {
    const saved = localStorage.getItem('azal_violations_v1');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {}
  return [];
}

// Helper to get local safety incidents (table: safety_incidents, incident_reports)
export function getStoredIncidentReports(): any[] {
  if (typeof window === 'undefined') return [];
  try {
    const saved = localStorage.getItem('azal_safety_incidents_v1');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {}
  return [];
}


// Helper to get local hospital risks (table: hospital_risks)
export function getStoredHospitalRisks(): any[] {
  if (typeof window === 'undefined') return DEFAULT_HOSPITAL_RISKS;
  try {
    const saved = localStorage.getItem('azal_hospital_risks_v2');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {}
  return DEFAULT_HOSPITAL_RISKS;
}

// Check environment variables safely
const supabaseUrl = typeof import.meta !== 'undefined' && import.meta.env ? import.meta.env.VITE_SUPABASE_URL : undefined;
const supabaseAnonKey = typeof import.meta !== 'undefined' && import.meta.env ? import.meta.env.VITE_SUPABASE_ANON_KEY : undefined;

let realSupabaseClient: any = null;
if (supabaseUrl && supabaseAnonKey && supabaseUrl.startsWith('http')) {
  try {
    realSupabaseClient = createClient(supabaseUrl, supabaseAnonKey);
  } catch (e) {
    console.warn('[Supabase] Failed to initialize real client, using robust local engine:', e);
  }
}

/**
 * Universal Supabase Client with seamless offline-first fallback.
 * Directly integrates:
 * - supabase.from('safety_trainings')
 * - supabase.from('penalties_log')
 * - supabase.from('pm_templates')
 * - supabase.from('pm_audit_records')
 * - supabase.from('equipment_inventory')
 */
export const supabase = {
  from(tableName: string) {
    return {
      select(queryStr?: string) {
        let orderByCol: string | null = null;
        let orderAsc: boolean = true;
        let filterCol: string | null = null;
        let filterVal: any = null;

        const chain = {
          order(col: string, options?: { ascending?: boolean }) {
            orderByCol = col;
            orderAsc = options?.ascending ?? true;
            return chain;
          },
          eq(col: string, val: any) {
            filterCol = col;
            filterVal = val;
            return chain;
          },
          async then(resolve: (value: { data: any[] | null; error: any | null }) => void) {
            // Try real Supabase first if configured
            if (realSupabaseClient) {
              try {
                let req = realSupabaseClient.from(tableName).select(queryStr || '*');
                if (filterCol) {
                  req = req.eq(filterCol, filterVal);
                }
                if (orderByCol) {
                  req = req.order(orderByCol, { ascending: orderAsc });
                }
                const res = await req;
                if (!res.error && res.data && res.data.length > 0) {
                  resolve(res);
                  return;
                }
              } catch (err) {
                console.warn(`[Supabase] Remote fetch failed for ${tableName}, falling back to local storage:`, err);
              }
            }

            // Local fallback logic
            let data: any[] = [];
            if (tableName === 'safety_trainings') {
              data = getStoredSafetyTrainings();
            } else if (tableName === 'penalties_log') {
              data = getStoredPenaltiesLog();
            } else if (tableName === 'daily_safety_actions') {
              data = getStoredDailySafetyActions();
            } else if (tableName === 'safety_committee_meetings') {
              data = getStoredSafetyCommitteeMeetings();
            } else if (tableName === 'monthly_audit_items') {
              data = getStoredMonthlyAuditItems();
            } else if (tableName === 'monthly_dept_inspections') {
              data = getStoredMonthlyDeptInspections();
            } else if (tableName === 'fms_operational_plans') {
              data = getStoredFmsOperationalPlans();
            } else if (tableName === 'cbahi_fire_drills') {
              data = getStoredCbahiFireDrills();
            } else if (tableName === 'cbahi_generator_tests') {
              data = getStoredCbahiGeneratorTests();
            } else if (tableName === 'cbahi_water_tests') {
              data = getStoredCbahiWaterTests();
            } else if (tableName === 'cbahi_safety_committee') {
              data = getStoredCbahiSafetyCommittee();
            } else if (tableName === 'pm_templates') {
              data = getStoredTemplates();
            } else if (tableName === 'equipment_inventory') {
              data = getStoredInventory();
            } else if (tableName === 'ppm_assets') {
              data = getStoredPpmAssets();
            } else if (tableName === 'pm_audit_records') {
              data = getStoredAuditRecords();
            } else if (tableName === 'safety_violations' || tableName === 'violations') {
              data = getStoredSafetyViolations();
            } else if (tableName === 'safety_incidents' || tableName === 'incident_reports') {
              data = getStoredIncidentReports();
            } else if (tableName === 'department_access_pins') {
              data = getStoredDepartmentAccessPins();
            } else if (tableName === 'hospital_risks') {
              data = getStoredHospitalRisks();
            } else if (tableName === 'safety_remediation_notices') {
              try {
                const raw = localStorage.getItem('azal_remediation_notices');
                data = raw ? JSON.parse(raw) : [];
              } catch {
                data = [];
              }
            }

            if (filterCol) {
              if (tableName === 'monthly_audit_items' && filterCol === 'department_id') {
                data = data.filter((item: any) => normalizeDepartmentId(item.department_id) === normalizeDepartmentId(filterVal));
              } else if (tableName === 'monthly_dept_inspections' && filterCol === 'department_id') {
                data = data.filter((item: any) => normalizeDepartmentId(item.department_id) === normalizeDepartmentId(filterVal));
              } else {
                data = data.filter((item: any) => String(item[filterCol!]) === String(filterVal));
              }
            }
            if (orderByCol) {
              data = [...data].sort((a: any, b: any) => {
                const valA = a[orderByCol!] ?? '';
                const valB = b[orderByCol!] ?? '';
                if (valA < valB) return orderAsc ? -1 : 1;
                if (valA > valB) return orderAsc ? 1 : -1;
                return 0;
              });
            }

            resolve({ data, error: null });
          },
        };

        return chain;
      },

      async insert(rows: any[]) {
        let remoteError: any = null;

        // Attempt remote save if Supabase is connected
        if (realSupabaseClient) {
          try {
            const res = await realSupabaseClient.from(tableName).insert(rows);
            if (res.error) {
              remoteError = res.error;
            }
          } catch (e: any) {
            remoteError = e;
          }
        }

        // Always persist to local storage for zero-downtime offline reliability
        try {
          if (tableName === 'safety_trainings') {
            const current = getStoredSafetyTrainings();
            const updated = [
              ...rows.map((r, i) => ({
                id: r.id || `trn-${Date.now()}-${i}`,
                created_at: r.created_at || new Date().toISOString(),
                ...r,
              })),
              ...current,
            ];
            localStorage.setItem('azal_safety_trainings', JSON.stringify(updated));
          } else if (tableName === 'penalties_log') {
            const current = getStoredPenaltiesLog();
            const updated = [
              ...rows.map((r, i) => ({
                id: r.id || `pen-${Date.now()}-${i}`,
                created_at: r.created_at || new Date().toISOString(),
                ...r,
              })),
              ...current,
            ];
            localStorage.setItem('azal_penalties_log', JSON.stringify(updated));
          } else if (tableName === 'daily_safety_actions') {
            const current = getStoredDailySafetyActions();
            const updated = [
              ...rows.map((r, i) => ({
                id: r.id || `dact-${Date.now()}-${i}`,
                created_at: r.created_at || new Date().toISOString(),
                ...r,
              })),
              ...current,
            ];
            localStorage.setItem('azal_daily_safety_actions', JSON.stringify(updated));
          } else if (tableName === 'safety_committee_meetings') {
            const current = getStoredSafetyCommitteeMeetings();
            const updated = [
              ...rows.map((r, i) => ({
                id: r.id || `scm-${Date.now()}-${i}`,
                created_at: r.created_at || new Date().toISOString(),
                ...r,
              })),
              ...current,
            ];
            localStorage.setItem('azal_safety_committee_meetings', JSON.stringify(updated));
          } else if (tableName === 'monthly_dept_inspections') {
            const current = getStoredMonthlyDeptInspections();
            const updated = [
              ...rows.map((r, i) => ({
                id: r.id || `AZAL-MDI-${r.department_id || 'DEPT'}-${Date.now()}-${i}`,
                created_at: r.created_at || new Date().toISOString(),
                ...r,
              })),
              ...current,
            ];
            localStorage.setItem('azal_monthly_dept_inspections', JSON.stringify(updated));
          } else if (tableName === 'fms_operational_plans') {
            const current = getStoredFmsOperationalPlans();
            const updated = [
              ...rows.map((r, i) => ({
                id: r.id || `fms-plan-${Date.now()}-${i}`,
                created_at: r.created_at || new Date().toISOString(),
                tasks: r.tasks || [],
                overallProgress: r.overallProgress ?? 0,
                ...r,
              })),
              ...current.filter((c: any) => !rows.some(r => r.id === c.id)),
            ];
            localStorage.setItem('azal_fms_operational_plans', JSON.stringify(updated));
          } else if (tableName === 'cbahi_fire_drills') {
            const current = getStoredCbahiFireDrills();
            const updated = [
              ...rows.map((r, i) => ({ id: r.id || `drill-${Date.now()}-${i}`, created_at: r.created_at || new Date().toISOString(), ...r })),
              ...current.filter((c: any) => !rows.some(r => r.id === c.id)),
            ];
            localStorage.setItem('azal_cbahi_fire_drills', JSON.stringify(updated));
          } else if (tableName === 'cbahi_generator_tests') {
            const current = getStoredCbahiGeneratorTests();
            const updated = [
              ...rows.map((r, i) => ({ id: r.id || `gen-${Date.now()}-${i}`, created_at: r.created_at || new Date().toISOString(), ...r })),
              ...current.filter((c: any) => !rows.some(r => r.id === c.id)),
            ];
            localStorage.setItem('azal_cbahi_generator_tests', JSON.stringify(updated));
          } else if (tableName === 'cbahi_water_tests') {
            const current = getStoredCbahiWaterTests();
            const updated = [
              ...rows.map((r, i) => ({ id: r.id || `wtr-${Date.now()}-${i}`, created_at: r.created_at || new Date().toISOString(), ...r })),
              ...current.filter((c: any) => !rows.some(r => r.id === c.id)),
            ];
            localStorage.setItem('azal_cbahi_water_tests', JSON.stringify(updated));
          } else if (tableName === 'cbahi_safety_committee') {
            const current = getStoredCbahiSafetyCommittee();
            const updated = [
              ...rows.map((r, i) => ({ id: r.id || `comm-${Date.now()}-${i}`, created_at: r.created_at || new Date().toISOString(), ...r })),
              ...current.filter((c: any) => !rows.some(r => r.id === c.id)),
            ];
            localStorage.setItem('azal_cbahi_safety_committee', JSON.stringify(updated));
          } else if (tableName === 'monthly_audit_items') {
            const current = getStoredMonthlyAuditItems();
            const updated = [...rows, ...current];
            localStorage.setItem('azal_monthly_audit_items', JSON.stringify(updated));
          } else if (tableName === 'equipment_inventory') {
            const current = getStoredInventory();
            const updated = [...rows.map((r, i) => ({ id: Date.now() + i, created_at: new Date().toISOString(), ...r })), ...current];
            localStorage.setItem('azal_equipment_inventory', JSON.stringify(updated));
          } else if (tableName === 'ppm_assets') {
            const current = getStoredPpmAssets();
            const updated = [...rows, ...current.filter((c: any) => !rows.some((r: any) => r.id === c.id || r.asset_tag === c.asset_tag))];
            localStorage.setItem('azal_ppm_master_assets_v2', JSON.stringify(updated));
          } else if (tableName === 'pm_audit_records') {
            const current = getStoredAuditRecords();
            const updated = [...rows.map((r, i) => ({ id: Date.now() + i, created_at: new Date().toISOString(), ...r })), ...current];
            localStorage.setItem('azal_pm_audit_records', JSON.stringify(updated));
          } else if (tableName === 'pm_templates') {
            const current = getStoredTemplates();
            const updated = [...rows.map((r, i) => ({ id: Date.now() + i, ...r })), ...current];
            localStorage.setItem('azal_pm_templates', JSON.stringify(updated));
          } else if (tableName === 'safety_violations' || tableName === 'violations') {
            const current = getStoredSafetyViolations();
            const updated = [...rows, ...current.filter((c: any) => !rows.some(r => r.id === c.id))];
            localStorage.setItem('azal_violations_v1', JSON.stringify(updated));
          } else if (tableName === 'safety_incidents' || tableName === 'incident_reports') {
            const current = getStoredIncidentReports();
            const updated = [...rows, ...current.filter((c: any) => !rows.some(r => String(r.id) === String(c.id)))];
            localStorage.setItem('azal_safety_incidents_v1', JSON.stringify(updated));
          } else if (tableName === 'department_access_pins') {
            const current = getStoredDepartmentAccessPins();
            const updated = [...rows, ...current.filter((c: any) => !rows.some(r => r.department_id === c.department_id || r.id === c.id))];
            localStorage.setItem('azal_department_access_pins', JSON.stringify(updated));
          } else if (tableName === 'hospital_risks') {
            const current = getStoredHospitalRisks();
            const updated = [...rows, ...current.filter((c: any) => !rows.some(r => String(r.id) === String(c.id)))];
            localStorage.setItem('azal_hospital_risks_v2', JSON.stringify(updated));
          }
        } catch (e) {
          console.warn('[Supabase Fallback] Local storage save error:', e);
        }

        return { data: rows, error: remoteError };
      },

      async upsert(rows: any[]) {
        let remoteError: any = null;

        if (realSupabaseClient) {
          try {
            const res = await realSupabaseClient.from(tableName).upsert(rows);
            if (res.error) {
              remoteError = res.error;
            }
          } catch (e: any) {
            remoteError = e;
          }
        }

        try {
          if (tableName === 'hospital_risks') {
            const current = getStoredHospitalRisks();
            const updated = [...rows, ...current.filter((c: any) => !rows.some(r => String(r.id) === String(c.id)))];
            localStorage.setItem('azal_hospital_risks_v2', JSON.stringify(updated));
          } else if (tableName === 'department_access_pins') {
            const current = getStoredDepartmentAccessPins();
            const updated = [...rows, ...current.filter((c: any) => !rows.some(r => r.department_id === c.department_id || r.id === c.id))];
            localStorage.setItem('azal_department_access_pins', JSON.stringify(updated));
          } else if (tableName === 'ppm_assets') {
            const current = getStoredPpmAssets();
            const updated = [...rows, ...current.filter((c: any) => !rows.some((r: any) => r.id === c.id || r.asset_tag === c.asset_tag))];
            localStorage.setItem('azal_ppm_master_assets_v2', JSON.stringify(updated));
          } else if (tableName === 'safety_violations' || tableName === 'violations') {
            const current = getStoredSafetyViolations();
            const updated = [...rows, ...current.filter((c: any) => !rows.some(r => r.id === c.id))];
            localStorage.setItem('azal_violations_v1', JSON.stringify(updated));
          }
        } catch (e) {
          console.warn('[Supabase Fallback] Local storage upsert error:', e);
        }

        return { data: rows, error: remoteError };
      },

      update(fields: any) {
        return {
          async eq(column: string, value: any) {
            let remoteError: any = null;
            if (realSupabaseClient) {
              try {
                const res = await realSupabaseClient.from(tableName).update(fields).eq(column, value);
                if (res.error) remoteError = res.error;
              } catch (e: any) {
                remoteError = e;
              }
            }

            // Local storage update
            try {
              if (tableName === 'safety_trainings') {
                const current = getStoredSafetyTrainings();
                const updated = current.map((item: any) =>
                  String(item[column]) === String(value) ? { ...item, ...fields } : item
                );
                localStorage.setItem('azal_safety_trainings', JSON.stringify(updated));
              } else if (tableName === 'penalties_log') {
                const current = getStoredPenaltiesLog();
                const updated = current.map((item: any) =>
                  String(item[column]) === String(value) ? { ...item, ...fields } : item
                );
                localStorage.setItem('azal_penalties_log', JSON.stringify(updated));
              } else if (tableName === 'daily_safety_actions') {
                const current = getStoredDailySafetyActions();
                const updated = current.map((item: any) =>
                  String(item[column]) === String(value) ? { ...item, ...fields } : item
                );
                localStorage.setItem('azal_daily_safety_actions', JSON.stringify(updated));
              } else if (tableName === 'safety_committee_meetings') {
                const current = getStoredSafetyCommitteeMeetings();
                const updated = current.map((item: any) =>
                  String(item[column]) === String(value) ? { ...item, ...fields } : item
                );
                localStorage.setItem('azal_safety_committee_meetings', JSON.stringify(updated));
              } else if (tableName === 'monthly_dept_inspections') {
                const current = getStoredMonthlyDeptInspections();
                const updated = current.map((item: any) =>
                  String(item[column]) === String(value) ? { ...item, ...fields } : item
                );
                localStorage.setItem('azal_monthly_dept_inspections', JSON.stringify(updated));
              } else if (tableName === 'fms_operational_plans') {
                const current = getStoredFmsOperationalPlans();
                const updated = current.map((item: any) =>
                  String(item[column]) === String(value) ? { ...item, ...fields, updated_at: new Date().toISOString() } : item
                );
                localStorage.setItem('azal_fms_operational_plans', JSON.stringify(updated));
              } else if (tableName === 'cbahi_fire_drills') {
                const current = getStoredCbahiFireDrills();
                const updated = current.map((item: any) =>
                  String(item[column]) === String(value) ? { ...item, ...fields, updated_at: new Date().toISOString() } : item
                );
                localStorage.setItem('azal_cbahi_fire_drills', JSON.stringify(updated));
              } else if (tableName === 'cbahi_generator_tests') {
                const current = getStoredCbahiGeneratorTests();
                const updated = current.map((item: any) =>
                  String(item[column]) === String(value) ? { ...item, ...fields, updated_at: new Date().toISOString() } : item
                );
                localStorage.setItem('azal_cbahi_generator_tests', JSON.stringify(updated));
              } else if (tableName === 'cbahi_water_tests') {
                const current = getStoredCbahiWaterTests();
                const updated = current.map((item: any) =>
                  String(item[column]) === String(value) ? { ...item, ...fields, updated_at: new Date().toISOString() } : item
                );
                localStorage.setItem('azal_cbahi_water_tests', JSON.stringify(updated));
              } else if (tableName === 'cbahi_safety_committee') {
                const current = getStoredCbahiSafetyCommittee();
                const updated = current.map((item: any) =>
                  String(item[column]) === String(value) ? { ...item, ...fields, updated_at: new Date().toISOString() } : item
                );
                localStorage.setItem('azal_cbahi_safety_committee', JSON.stringify(updated));
              } else if (tableName === 'safety_violations' || tableName === 'violations') {
                const current = getStoredSafetyViolations();
                const updated = current.map((item: any) => {
                  const matches =
                    String(item[column] || '').toLowerCase() === String(value).toLowerCase() ||
                    String(item.id || '').toLowerCase() === String(value).toLowerCase() ||
                    (item.publicToken && String(item.publicToken).toLowerCase() === String(value).toLowerCase());
                  if (!matches) return item;
                  const isResolvedStatus =
                    fields.status === 'تمت المعالجة' ||
                    fields.status === 'resolved' ||
                    fields.status === 'Closed';
                  const updatedItem = {
                    ...item,
                    ...fields,
                    status: isResolvedStatus ? 'resolved' : (fields.status || item.status),
                    statusAr: isResolvedStatus ? 'تمت المعالجة' : (fields.statusAr || item.statusAr),
                    resolvedAt: fields.resolved_at || fields.resolvedAt || item.resolvedAt || new Date().toISOString(),
                    resolvedBy: fields.resolved_by || fields.resolvedBy || item.resolvedBy,
                    resolutionNote: fields.resolution_note || fields.resolutionNote || item.resolutionNote,
                    afterPhotoUrl: fields.after_photo_url || fields.afterPhotoUrl || item.afterPhotoUrl,
                    updated_at: new Date().toISOString(),
                  };
                  try {
                    offlineStorage.saveViolation(updatedItem).catch(() => {});
                  } catch {}
                  return updatedItem;
                });
                localStorage.setItem('azal_violations_v1', JSON.stringify(updated));
              } else if (tableName === 'safety_incidents' || tableName === 'incident_reports') {
                const current = getStoredIncidentReports();
                const updated = current.map((item: any) => {
                  const matches =
                    String(item[column] || '').toLowerCase() === String(value).toLowerCase() ||
                    String(item.id || '').toLowerCase() === String(value).toLowerCase();
                  if (!matches) return item;
                  return {
                    ...item,
                    ...fields,
                    status: fields.status === 'تمت المعالجة' ? 'resolved' : (fields.status || item.status),
                    resolvedAt: fields.resolved_at || fields.resolvedAt || item.resolvedAt || new Date().toISOString(),
                    resolvedBy: fields.resolved_by || fields.resolvedBy || item.resolvedBy,
                    resolutionNotes: fields.resolution_note || fields.resolutionNotes || item.resolutionNotes,
                    afterPhotoUrl: fields.after_photo_url || fields.afterPhotoUrl || item.afterPhotoUrl,
                    updated_at: new Date().toISOString(),
                  };
                });
                localStorage.setItem('azal_safety_incidents_v1', JSON.stringify(updated));
              } else if (tableName === 'ppm_assets') {
                const current = getStoredPpmAssets();
                const updated = current.map((item: any) =>
                  String(item[column] || item.id || item.asset_tag).toLowerCase() === String(value).toLowerCase()
                    ? { ...item, ...fields, updated_at: new Date().toISOString() }
                    : item
                );
                localStorage.setItem('azal_ppm_master_assets_v2', JSON.stringify(updated));
              } else if (tableName === 'department_access_pins') {
                const current = getStoredDepartmentAccessPins();
                const updated = current.map((item: any) =>
                  String(item[column] || item.department_id || item.id).toLowerCase() === String(value).toLowerCase()
                    ? { ...item, ...fields, updated_at: new Date().toISOString() }
                    : item
                );
                localStorage.setItem('azal_department_access_pins', JSON.stringify(updated));
              } else if (tableName === 'hospital_risks') {
                const current = getStoredHospitalRisks();
                const updated = current.map((item: any) =>
                  String(item[column] || item.id || item.risk_code).toLowerCase() === String(value).toLowerCase()
                    ? { ...item, ...fields, updated_at: new Date().toISOString() }
                    : item
                );
                localStorage.setItem('azal_hospital_risks_v2', JSON.stringify(updated));
              } else if (tableName === 'safety_remediation_notices') {
                try {
                  const raw = localStorage.getItem('azal_remediation_notices');
                  const current = raw ? JSON.parse(raw) : [];
                  const updated = current.map((item: any) =>
                    String(item[column] || item.id || item.notice_number).toLowerCase() === String(value).toLowerCase()
                      ? { ...item, ...fields, updated_at: new Date().toISOString() }
                      : item
                  );
                  localStorage.setItem('azal_remediation_notices', JSON.stringify(updated));
                } catch {}
              }
            } catch (e) {
              console.warn('[Supabase Local Update Error]:', e);
            }

            return { data: fields, error: remoteError };
          },
        };
      },

      delete() {
        return {
          async eq(column: string, value: any) {
            let remoteError: any = null;
            if (realSupabaseClient) {
              try {
                const res = await realSupabaseClient.from(tableName).delete().eq(column, value);
                if (res.error) remoteError = res.error;
              } catch (e: any) {
                remoteError = e;
              }
            }

            // Local storage delete
            try {
              if (tableName === 'safety_trainings') {
                const current = getStoredSafetyTrainings();
                const updated = current.filter((item: any) => String(item[column]) !== String(value));
                localStorage.setItem('azal_safety_trainings', JSON.stringify(updated));
              } else if (tableName === 'penalties_log') {
                const current = getStoredPenaltiesLog();
                const updated = current.filter((item: any) => String(item[column]) !== String(value));
                localStorage.setItem('azal_penalties_log', JSON.stringify(updated));
              } else if (tableName === 'daily_safety_actions') {
                const current = getStoredDailySafetyActions();
                const updated = current.filter((item: any) => String(item[column]) !== String(value));
                localStorage.setItem('azal_daily_safety_actions', JSON.stringify(updated));
              } else if (tableName === 'safety_committee_meetings') {
                const current = getStoredSafetyCommitteeMeetings();
                const updated = current.filter((item: any) => String(item[column]) !== String(value));
                localStorage.setItem('azal_safety_committee_meetings', JSON.stringify(updated));
              } else if (tableName === 'monthly_dept_inspections') {
                const current = getStoredMonthlyDeptInspections();
                const updated = current.filter((item: any) => String(item[column]) !== String(value));
                localStorage.setItem('azal_monthly_dept_inspections', JSON.stringify(updated));
              } else if (tableName === 'fms_operational_plans') {
                const current = getStoredFmsOperationalPlans();
                const updated = current.filter((item: any) => String(item[column]) !== String(value));
                localStorage.setItem('azal_fms_operational_plans', JSON.stringify(updated));
              } else if (tableName === 'cbahi_fire_drills') {
                const current = getStoredCbahiFireDrills();
                const updated = current.filter((item: any) => String(item[column]) !== String(value));
                localStorage.setItem('azal_cbahi_fire_drills', JSON.stringify(updated));
              } else if (tableName === 'cbahi_generator_tests') {
                const current = getStoredCbahiGeneratorTests();
                const updated = current.filter((item: any) => String(item[column]) !== String(value));
                localStorage.setItem('azal_cbahi_generator_tests', JSON.stringify(updated));
              } else if (tableName === 'cbahi_water_tests') {
                const current = getStoredCbahiWaterTests();
                const updated = current.filter((item: any) => String(item[column]) !== String(value));
                localStorage.setItem('azal_cbahi_water_tests', JSON.stringify(updated));
              } else if (tableName === 'cbahi_safety_committee') {
                const current = getStoredCbahiSafetyCommittee();
                const updated = current.filter((item: any) => String(item[column]) !== String(value));
                localStorage.setItem('azal_cbahi_safety_committee', JSON.stringify(updated));
              } else if (tableName === 'safety_violations' || tableName === 'violations') {
                const current = getStoredSafetyViolations();
                const updated = current.filter((item: any) => String(item[column] || item.id).toLowerCase() !== String(value).toLowerCase());
                localStorage.setItem('azal_violations_v1', JSON.stringify(updated));
              } else if (tableName === 'ppm_assets') {
                const current = getStoredPpmAssets();
                const updated = current.filter((item: any) => String(item[column] || item.id || item.asset_tag).toLowerCase() !== String(value).toLowerCase());
                localStorage.setItem('azal_ppm_master_assets_v2', JSON.stringify(updated));
              } else if (tableName === 'hospital_risks') {
                const current = getStoredHospitalRisks();
                const updated = current.filter((item: any) => String(item[column] || item.id || item.risk_code).toLowerCase() !== String(value).toLowerCase());
                localStorage.setItem('azal_hospital_risks_v2', JSON.stringify(updated));
              }
            } catch (e) {
              console.warn('[Supabase Local Delete Error]:', e);
            }

            return { data: null, error: remoteError };
          },
        };
      },
    };
  },
};

export const supabaseClient = supabase;
