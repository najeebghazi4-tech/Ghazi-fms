import { StaffUser, UserRole } from '../types';

/**
 * Session Security & Auto-Lock Inactivity Configuration
 * Standard: 10 minutes timeout (600,000 ms / 600 seconds)
 * Warning: 30 seconds before auto-lock triggers
 */
export const IDLE_TIMEOUT_MS = 10 * 60 * 1000; // 10 minutes = 600,000 ms
export const IDLE_WARNING_MS = 30 * 1000; // 30 seconds warning
export const DEFAULT_AUTO_LOCK_MINUTES = 10;

/**
 * User interaction events that immediately reset the 10-minute idle timer:
 * - Touch interactions on mobile / tablet screens (touchstart, pointerdown)
 * - Mouse movements and clicks (mousemove, click, mousedown)
 * - Page scrolling and wheel navigation (scroll, wheel)
 * - Keystrokes and typing (keydown)
 */
export const USER_ACTIVITY_EVENTS = [
  'touchstart',
  'pointerdown',
  'mousedown',
  'mousemove',
  'click',
  'scroll',
  'wheel',
  'keydown'
] as const;

const SESSION_KEY = 'azal_secure_session_token_v2';
const SECRET_SALT = 'AZAL_HOSPITAL_FMS_CBAHI_2026_RBAC';

interface SessionData {
  userId: string;
  userName: string;
  role: UserRole;
  badgeNumber: string;
  department: string;
  issuedAt: number;
  checksum: string;
}

function computeChecksum(user: StaffUser, timestamp: number): string {
  const payload = `${user.id}:${user.role}:${user.badgeNumber}:${timestamp}:${SECRET_SALT}`;
  let hash = 0;
  for (let i = 0; i < payload.length; i++) {
    hash = (Math.imul(31, hash) + payload.charCodeAt(i)) | 0;
  }
  return Math.abs(hash).toString(36);
}

/**
 * Saves a signed, obfuscated session token into sessionStorage.
 * Automatically clears when the tab/browser is closed.
 */
export function saveSecureSession(user: StaffUser): void {
  if (typeof window === 'undefined') return;
  try {
    const timestamp = Date.now();
    const sessionData: SessionData = {
      userId: user.id,
      userName: user.name,
      role: user.role,
      badgeNumber: user.badgeNumber,
      department: user.department,
      issuedAt: timestamp,
      checksum: computeChecksum(user, timestamp),
    };

    const jsonStr = JSON.stringify(sessionData);
    const encoded = btoa(unescape(encodeURIComponent(jsonStr)));
    sessionStorage.setItem(SESSION_KEY, encoded);
    sessionStorage.setItem('azal_auth_logged_in', 'true');
    sessionStorage.setItem('azal_user_role', user.role);
  } catch (err) {
    console.error('Failed to store secure session:', err);
  }
}

/**
 * Reads and verifies the active session token from sessionStorage.
 * Returns the matching StaffUser if valid; otherwise null and clears corrupted session.
 */
export function getSecureSession(staffList: StaffUser[]): StaffUser | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = sessionStorage.getItem(SESSION_KEY);
    if (!raw) return null;

    const decoded = decodeURIComponent(escape(atob(raw)));
    const session: SessionData = JSON.parse(decoded);

    // Validate against staff list
    const userMatch = staffList.find(
      (s) => s.id === session.userId && s.role === session.role
    );
    if (!userMatch) {
      clearSecureSession();
      return null;
    }

    const expectedChecksum = computeChecksum(userMatch, session.issuedAt);
    if (expectedChecksum !== session.checksum) {
      console.warn('Session checksum mismatch. Terminating session.');
      clearSecureSession();
      return null;
    }

    return userMatch;
  } catch {
    clearSecureSession();
    return null;
  }
}

/**
 * Clears the secure session from sessionStorage on explicit logout or lockout.
 */
export function clearSecureSession(): void {
  if (typeof window === 'undefined') return;
  try {
    sessionStorage.removeItem(SESSION_KEY);
    sessionStorage.removeItem('azal_auth_logged_in');
    sessionStorage.removeItem('azal_user_role');
    sessionStorage.removeItem('azal_gm_unlocked');
  } catch {}
}
