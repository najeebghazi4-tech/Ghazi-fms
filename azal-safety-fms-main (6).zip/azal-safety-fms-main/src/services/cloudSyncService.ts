import { 
  collection, 
  doc, 
  setDoc, 
  deleteDoc,
  getDocs,
  onSnapshot, 
  Unsubscribe 
} from 'firebase/firestore';
import { db, ensureFirebaseAuth } from './firebase';
import { 
  SafetyViolationNotice, 
  SafetyTourRecord, 
  FireExtinguisherItem, 
  SafetyIncidentReport, 
  ContractorPermitNotice, 
  IncineratorOperationNotice, 
  TrainingNominationNotice,
  PublicSafetyReport
} from '../types';
import { offlineStorage } from './offlineStorage';
import { supabase } from './supabaseClient';

export type SyncStatus = 'connected' | 'connecting' | 'offline' | 'error';

export interface HospitalNotificationItem {
  id: string;
  type: string;
  title: string;
  body: string;
  violationId?: string;
  incidentId?: string;
  department?: string;
  resolvedBy?: string;
  resolutionNote?: string;
  afterPhotoUrl?: string;
  timestamp: number;
  createdAt: string;
  read: boolean;
}

class CloudSyncService {
  private status: SyncStatus = 'connecting';
  private lastSyncedAt: number = Date.now();
  private unsubscribers: Unsubscribe[] = [];
  private statusListeners: Array<(status: SyncStatus, lastSynced: number) => void> = [];
  private isInitialized = false;

  public subscribeStatus(listener: (status: SyncStatus, lastSynced: number) => void) {
    this.statusListeners.push(listener);
    listener(this.status, this.lastSyncedAt);
    return () => {
      this.statusListeners = this.statusListeners.filter(l => l !== listener);
    };
  }

  private notifyStatus(newStatus: SyncStatus) {
    this.status = newStatus;
    this.lastSyncedAt = Date.now();
    this.statusListeners.forEach(fn => fn(this.status, this.lastSyncedAt));
  }

  public getStatus(): SyncStatus {
    return this.status;
  }

  public getLastSyncedAt(): number {
    return this.lastSyncedAt;
  }

  /**
   * Initializes real-time listeners for all hospital records across phones and 

   */
  public async initRealtimeSync(callbacks: {
    onViolationsUpdate?: (violations: SafetyViolationNotice[]) => void;
    onToursUpdate?: (tours: SafetyTourRecord[]) => void;
    onExtinguishersUpdate?: (extinguishers: FireExtinguisherItem[]) => void;
    onIncidentsUpdate?: (incidents: SafetyIncidentReport[]) => void;
    onPermitsUpdate?: (permits: ContractorPermitNotice[]) => void;
    onIncineratorUpdate?: (notices: IncineratorOperationNotice[]) => void;
    onTrainingNominationsUpdate?: (nominations: TrainingNominationNotice[]) => void;
    onNotificationsUpdate?: (notifications: HospitalNotificationItem[]) => void;
    onPublicReportsUpdate?: (reports: PublicSafetyReport[]) => void;
  }) {
    if (this.isInitialized) return;
    this.isInitialized = true;

    try {
      this.notifyStatus('connecting');
          this.fetchPublicReportsFromSupabase();

      // Attempt anonymous auth non-blockingly if permitted
      ensureFirebaseAuth().catch(() => null);

      // 1. Real-time Notifications Listener
      const notifCol = collection(db, 'hospital_notifications');
      const unsubNotif = onSnapshot(notifCol, (snap) => {
        const list: HospitalNotificationItem[] = [];
        snap.forEach((d) => {
          list.push(d.data() as HospitalNotificationItem);
        });
        list.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
        callbacks.onNotificationsUpdate?.(list);
        this.notifyStatus('connected');
      }, (err) => {
        console.warn('[CloudSync] notifications snapshot warning:', err);
      });
      this.unsubscribers.push(unsubNotif);

      // 2. Real-time Violations Listener
      const violationsCol = collection(db, 'violations');
      const unsubViolations = onSnapshot(violationsCol, (snap) => {
        const list: SafetyViolationNotice[] = [];
        snap.forEach((d) => {
          list.push(d.data() as SafetyViolationNotice);
        });
        list.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
        callbacks.onViolationsUpdate?.(list);
        this.notifyStatus('connected');
      }, () => {
        this.notifyStatus('offline');
      });
      this.unsubscribers.push(unsubViolations);

      // 3. Real-time Safety Tours Listener
      const toursCol = collection(db, 'safety_tours');
      const unsubTours = onSnapshot(toursCol, (snap) => {
        const list: SafetyTourRecord[] = [];
        snap.forEach((d) => {
          list.push(d.data() as SafetyTourRecord);
        });
        list.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
        callbacks.onToursUpdate?.(list);
        this.notifyStatus('connected');
      }, () => {
        this.notifyStatus('offline');
      });
      this.unsubscribers.push(unsubTours);

      // 4. Real-time Fire Extinguishers Listener
      const extCol = collection(db, 'fire_extinguishers');
      const unsubExt = onSnapshot(extCol, (snap) => {
        const list: FireExtinguisherItem[] = [];
        snap.forEach((d) => {
          list.push(d.data() as FireExtinguisherItem);
        });
        callbacks.onExtinguishersUpdate?.(list);
        this.notifyStatus('connected');
      }, () => {
        this.notifyStatus('offline');
      });
      this.unsubscribers.push(unsubExt);

      // 5. Real-time Incidents Listener
      const incidentsCol = collection(db, 'incidents');
      const unsubIncidents = onSnapshot(incidentsCol, (snap) => {
        const list: SafetyIncidentReport[] = [];
        snap.forEach((d) => {
          list.push(d.data() as SafetyIncidentReport);
        });
        list.sort((a, b) => new Date(b.reportedAt).getTime() - new Date(a.reportedAt).getTime());
        callbacks.onIncidentsUpdate?.(list);
        this.notifyStatus('connected');
      }, () => {
        this.notifyStatus('offline');
      });
      this.unsubscribers.push(unsubIncidents);

      // 6. Real-time Contractor Permits Listener
      const permitsCol = collection(db, 'contractor_permits');
      const unsubPermits = onSnapshot(permitsCol, (snap) => {
        const list: ContractorPermitNotice[] = [];
        snap.forEach((d) => {
          list.push(d.data() as ContractorPermitNotice);
        });
        list.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
        callbacks.onPermitsUpdate?.(list);
        this.notifyStatus('connected');
      }, () => {
        this.notifyStatus('offline');
      });
      this.unsubscribers.push(unsubPermits);

      // 7. Real-time Incinerator Batches Listener
      const incineratorCol = collection(db, 'incinerator_batches');
      const unsubIncinerator = onSnapshot(incineratorCol, (snap) => {
        const list: IncineratorOperationNotice[] = [];
        snap.forEach((d) => {
          list.push(d.data() as IncineratorOperationNotice);
        });
        list.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
        callbacks.onIncineratorUpdate?.(list);
        this.notifyStatus('connected');
      }, () => {
        this.notifyStatus('offline');
      });
      this.unsubscribers.push(unsubIncinerator);

      // 8. Real-time Training Nominations Listener
      const trainingCol = collection(db, 'training_nominations');
      const unsubTraining = onSnapshot(trainingCol, (snap) => {
        const list: TrainingNominationNotice[] = [];
        snap.forEach((d) => {
          list.push(d.data() as TrainingNominationNotice);
        });
        list.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
        callbacks.onTrainingNominationsUpdate?.(list);
        this.notifyStatus('connected');
      }, () => {
        this.notifyStatus('offline');
      });
      this.unsubscribers.push(unsubTraining);

      // 9. Real-time Public Reports Listener
      const publicReportsCol = collection(db, 'public_reports');
      const unsubPublicReports = onSnapshot(publicReportsCol, (snap) => {
        const list: PublicSafetyReport[] = [];
        snap.forEach((d) => {
          list.push(d.data() as PublicSafetyReport);
        });
        list.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
        callbacks.onPublicReportsUpdate?.(list);
        this.notifyStatus('connected');
      }, () => {
        // silent fallback
      });
      this.unsubscribers.push(unsubPublicReports);

    } catch {
      this.notifyStatus('offline');
    }
  }

  /**
   * Pushes a single record directly to Firestore cloud collection
   */
  public async pushRecord(collectionName: string, id: string, data: any): Promise<boolean> {
    try {
      await ensureFirebaseAuth().catch(() => null);
      const cleanId = String(id).trim().replace(/[^a-zA-Z0-9_\-\.]/g, '_') || `doc_${Date.now()}`;
      const docRef = doc(db, collectionName, cleanId);
      // Strip undefined keys cleanly for Firestore
      const cleanData = JSON.parse(JSON.stringify(data));
      await setDoc(docRef, cleanData, { merge: true });
      this.notifyStatus('connected');
      return true;
    } catch (err) {
      console.warn(`[CloudSync] pushRecord error for ${collectionName}/${id}:`, err);
      this.notifyStatus('offline');
      return false;
    }
  }

  /**
   * Deletes a single record directly from Firestore cloud collection
   */
  public async deleteRecord(collectionName: string, id: string): Promise<boolean> {
    try {
      await ensureFirebaseAuth().catch(() => null);
      const cleanId = String(id).trim().replace(/[^a-zA-Z0-9_\-\.]/g, '_') || `doc_${Date.now()}`;
      const docRef = doc(db, collectionName, cleanId);
      await deleteDoc(docRef);
      this.notifyStatus('connected');
      return true;
    } catch (err) {
      console.warn(`[CloudSync] deleteRecord error for ${collectionName}/${id}:`, err);
      this.notifyStatus('offline');
      return false;
    }
  }

  /**
   * Pushes a new hospital alert/notification
   */
  public async pushNotification(notif: HospitalNotificationItem): Promise<boolean> {
    return this.pushRecord('hospital_notifications', notif.id, notif);
  }

  /**
   * Pushes a public hazard report to cloud and offline storage
   */
    /**
   * Pushes a public hazard report to cloud and offline storage
   */
  public async syncPublicReport(report: PublicSafetyReport): Promise<boolean> {
    try {
      await offlineStorage.savePublicReport(report);
      if (supabase) {
        const { error } = await supabase.from('safety_reports').insert([{
          reporter_name: report.reporterName,
          reporter_phone: report.reporterPhone,
          department: report.department,
          location_detail: report.locationDetail,
          description: report.description,
          priority: report.priority,
          status: report.status || 'new',
          photo_url: report.photoUrl,
          created_at: new Date(report.timestamp).toISOString()
        }]);
        if (error) console.warn('[CloudSync] Supabase insert warning:', error);
      }
      return true;
    } catch (err) {
      console.warn('[CloudSync] syncPublicReport error:', err);
      return false;
    }
  }

  public async fetchPublicReportsFromSupabase(): Promise<void> {
    try {
      if (!supabase) return;
      const { data, error } = await supabase
        .from('safety_reports')
        .select('*')
        .order('created_at', { ascending: false });

      if (data && !error) {
        for (const rep of data) {
          const reportItem: PublicSafetyReport = {
            id: rep.id ? String(rep.id) : String(Date.now()),
            reporterName: rep.reporter_name || rep.reporterName || 'فاعل خير',
            reporterPhone: rep.reporter_phone || rep.reporterPhone || '',
            department: rep.department || '',
            locationDetail: rep.location_detail || rep.locationDetail || '',
            description: rep.description || '',
            priority: (rep.priority as any) || 'medium',
            status: (rep.status as any) || 'new',
            timestamp: rep.created_at ? new Date(rep.created_at).getTime() : Date.now(),
            photoUrl: rep.photo_url || rep.photoUrl || ''
          };
          await offlineStorage.savePublicReport(reportItem);
        }
      }
    } catch (err) {
      console.warn('[CloudSync] Error fetching reports from Supabase:', err);
    }
  }
}

export const cloudSync = new CloudSyncService();
