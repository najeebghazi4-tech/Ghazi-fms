import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Camera, 
  Scan, 
  QrCode, 
  AlertCircle, 
  CheckCircle2, 
  Upload, 
  Search, 
  Flame, 
  Zap,
  RefreshCw
} from 'lucide-react';
import { Html5Qrcode, Html5QrcodeSupportedFormats } from 'html5-qrcode';
import { FireExtinguisherItem } from '../types';
import { parseExtinguisherCode } from '../utils/fireExtinguisherQrUtils';
import { playScanBeep, triggerHapticFeedback } from '../utils/feedbackUtils';

interface FireExtinguisherQrScannerModalProps {
  extinguishers: FireExtinguisherItem[];
  onClose: () => void;
  onExtinguisherScanned: (extinguisher: FireExtinguisherItem) => void;
}

export const FireExtinguisherQrScannerModal: React.FC<FireExtinguisherQrScannerModalProps> = ({
  extinguishers,
  onClose,
  onExtinguisherScanned,
}) => {
  const [isScanning, setIsScanning] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [scannedResult, setScannedResult] = useState<FireExtinguisherItem | null>(null);
  const [unrecognizedCode, setUnrecognizedCode] = useState<string | null>(null);
  const [searchManual, setSearchManual] = useState('');
  const [showManualSelector, setShowManualSelector] = useState(false);

  const scannerRef = useRef<Html5Qrcode | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const hasHandledScanRef = useRef(false);

  // Initialize and start camera
  useEffect(() => {
    let isMounted = true;
    hasHandledScanRef.current = false;

    const startScanner = async () => {
      try {
        setCameraError(null);
        // Small delay to ensure the DOM node is rendered
        await new Promise((r) => setTimeout(r, 150));
        if (!isMounted) return;

        const readerElem = document.getElementById('fire-ext-qr-reader');
        if (!readerElem) return;

        const html5QrCode = new Html5Qrcode('fire-ext-qr-reader', {
          formatsToSupport: [
            Html5QrcodeSupportedFormats.QR_CODE,
            Html5QrcodeSupportedFormats.CODE_128,
            Html5QrcodeSupportedFormats.CODE_39,
            Html5QrcodeSupportedFormats.EAN_13,
          ],
          verbose: false,
        });

        scannerRef.current = html5QrCode;

        await html5QrCode.start(
          { facingMode: 'environment' },
          {
            fps: 15,
            qrbox: (viewfinderWidth, viewfinderHeight) => {
              const minEdge = Math.min(viewfinderWidth, viewfinderHeight);
              const edgeSize = Math.floor(minEdge * 0.72);
              return { width: edgeSize, height: edgeSize };
            },
            aspectRatio: 1.0,
          },
          (decodedText) => {
            if (hasHandledScanRef.current) return;
            handleSuccessfulDecode(decodedText);
          },
          () => {
            // Frame parse error (normal while searching for QR)
          }
        );

        if (isMounted) {
          setIsScanning(true);
        }
      } catch (err: any) {
        console.warn('Unable to start HTML5 camera QR scanner:', err);
        if (isMounted) {
          setIsScanning(false);
          setCameraError(
            err?.message?.includes('Permission') || err?.name === 'NotAllowedError'
              ? 'يرجى السماح بصلاحية الكاميرا في المتصفح لمسح كود الطفايات.'
              : 'تعذر تشغيل كاميرا الهاتف مباشرة. يمكنك رفع صورة الكود أو الاختيار السريع أدناه.'
          );
        }
      }
    };

    startScanner();

    return () => {
      isMounted = false;
      if (scannerRef.current && scannerRef.current.isScanning) {
        scannerRef.current
          .stop()
          .then(() => scannerRef.current?.clear())
          .catch(() => {});
      }
    };
  }, []);

  const handleSuccessfulDecode = (decodedText: string) => {
    hasHandledScanRef.current = true;
    playScanBeep();
    triggerHapticFeedback([60, 40, 90]);

    const matched = parseExtinguisherCode(decodedText, extinguishers);

    if (matched) {
      setScannedResult(matched);
      setUnrecognizedCode(null);

      // Stop scanner before transitioning
      if (scannerRef.current && scannerRef.current.isScanning) {
        scannerRef.current
          .stop()
          .then(() => scannerRef.current?.clear())
          .catch(() => {});
      }

      // Short delay for visual confirmation feedback
      setTimeout(() => {
        onExtinguisherScanned(matched);
        onClose();
      }, 700);
    } else {
      setUnrecognizedCode(decodedText);
      hasHandledScanRef.current = false;
    }
  };

  const handleImageFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setCameraError(null);
      setUnrecognizedCode(null);
      let html5QrCode = scannerRef.current;
      if (!html5QrCode) {
        html5QrCode = new Html5Qrcode('fire-ext-qr-reader');
        scannerRef.current = html5QrCode;
      }

      const decodedText = await html5QrCode.scanFile(file, true);
      handleSuccessfulDecode(decodedText);
    } catch (err) {
      setUnrecognizedCode('تعذر قراءة رمز QR من الصورة المرفوعة. يرجى تجربة صورة أوضح أو تحديد الطفاية يدوياً.');
    }
  };

  const handleSelectExtinguisherManually = (item: FireExtinguisherItem) => {
    playScanBeep();
    triggerHapticFeedback([40, 20, 60]);
    if (scannerRef.current && scannerRef.current.isScanning) {
      scannerRef.current
        .stop()
        .then(() => scannerRef.current?.clear())
        .catch(() => {});
    }
    onExtinguisherScanned(item);
    onClose();
  };

  const filteredManualList = extinguishers.filter(
    (item) =>
      item.serialNumber.toLowerCase().includes(searchManual.toLowerCase()) ||
      item.location.toLowerCase().includes(searchManual.toLowerCase()) ||
      (item.typeAr && item.typeAr.toLowerCase().includes(searchManual.toLowerCase()))
  );

  return (
    <div
      id="fire-extinguisher-qr-scanner-modal"
      className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 text-right animate-fade-in"
      dir="rtl"
    >
      <div className="bg-slate-900 border border-red-700/60 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-slate-950 px-4 py-3.5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-red-950/90 border border-red-700 text-red-400 shadow-md">
              <Camera className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-slate-100">
                  ماسح كود طفايات الحريق (QR Scanner)
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-red-950 text-red-300 border border-red-800">
                  CBAHI FMS.7
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                وجّه الكاميرا نحو ملصق QR على الطفاية للتعرف عليها فوراً وفتح نموذج الفحص
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body Container */}
        <div className="p-4 space-y-3.5 overflow-y-auto">
          {/* Camera Viewport */}
          <div className="relative w-full aspect-square max-h-72 sm:max-h-80 mx-auto bg-black rounded-2xl border-2 border-red-600/50 overflow-hidden flex items-center justify-center shadow-inner">
            {/* HTML5 QR Container (Target element) */}
            <div
              id="fire-ext-qr-reader"
              className="w-full h-full object-cover flex items-center justify-center"
            />

            {/* Overlaid Animated Scanner HUD */}
            <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
              {/* Corner Reticle Brackets */}
              <div className="relative w-48 h-48 sm:w-56 sm:h-56">
                <div className="absolute top-0 left-0 w-7 h-7 border-t-4 border-l-4 border-red-500 rounded-tl-xl" />
                <div className="absolute top-0 right-0 w-7 h-7 border-t-4 border-r-4 border-red-500 rounded-tr-xl" />
                <div className="absolute bottom-0 left-0 w-7 h-7 border-b-4 border-l-4 border-red-500 rounded-bl-xl" />
                <div className="absolute bottom-0 right-0 w-7 h-7 border-b-4 border-r-4 border-red-500 rounded-br-xl" />

                {/* Laser Scanning Bar */}
                <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 h-0.5 bg-gradient-to-r from-transparent via-red-500 to-transparent shadow-[0_0_12px_#ef4444] animate-pulse" />
              </div>

              {/* Status Hint */}
              <div className="absolute bottom-3 bg-black/75 px-3 py-1 rounded-full border border-red-900/60 text-[10px] text-red-200 font-medium">
                {isScanning ? '⚡ الماسح نشط - قرّب الكود من الإطار' : 'جاري تشغيل الكاميرا...'}
              </div>
            </div>

            {/* Success Overlay on Match */}
            {scannedResult && (
              <div className="absolute inset-0 bg-emerald-950/95 flex flex-col items-center justify-center text-emerald-300 z-30 animate-fade-in p-4 text-center">
                <div className="p-3 rounded-2xl bg-emerald-900/80 border border-emerald-500 mb-2">
                  <CheckCircle2 className="w-12 h-12 text-emerald-400 animate-bounce" />
                </div>
                <h4 className="text-base font-bold text-emerald-200">
                  تم التعرف على الطفاية بنجاح!
                </h4>
                <div className="mt-1 font-mono text-sm font-bold text-emerald-100 bg-emerald-900/50 px-3 py-1 rounded-lg border border-emerald-700">
                  {scannedResult.serialNumber}
                </div>
                <p className="text-xs text-emerald-300/80 mt-1 max-w-xs truncate">
                  {scannedResult.location}
                </p>
                <span className="text-[10px] text-emerald-400/90 mt-2">
                  جاري فتح استمارة الفحص الشهري...
                </span>
              </div>
            )}
          </div>

          {/* Warning: Unrecognized Code */}
          {unrecognizedCode && (
            <div className="p-3 rounded-2xl bg-amber-950/60 border border-amber-800/80 text-amber-200 text-xs flex items-start gap-2.5">
              <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div className="flex-1">
                <span className="font-bold block text-amber-300">
                  الكود المقروء غير مسجل في منظومة الطفايات:
                </span>
                <code className="text-[11px] font-mono bg-black/40 px-2 py-0.5 rounded text-amber-100 mt-1 inline-block">
                  {unrecognizedCode}
                </code>
                <p className="text-[11px] text-amber-300/80 mt-1">
                  تأكد من مسح ملصق QR الرسمي المعتمد لطفاية الحريق بمستشفى آزال، أو حدد الطفاية من القائمة أدناه.
                </p>
              </div>
            </div>
          )}

          {/* Camera Error / Permission Banner */}
          {cameraError && (
            <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 text-slate-300 text-xs space-y-2">
              <div className="flex items-center gap-2 text-amber-400 font-bold">
                <AlertCircle className="w-4 h-4" />
                <span>تنبيه تشغيل الكاميرا</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                {cameraError}
              </p>
            </div>
          )}

          {/* Actions Row: Upload Photo or Quick Manual Select */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="px-3 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold flex items-center justify-center gap-1.5 transition"
            >
              <Upload className="w-4 h-4 text-teal-400" />
              <span>مسح من صورة</span>
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleImageFileUpload}
            />

            <button
              type="button"
              onClick={() => setShowManualSelector(!showManualSelector)}
              className="px-3 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold flex items-center justify-center gap-1.5 transition"
            >
              <Search className="w-4 h-4 text-amber-400" />
              <span>{showManualSelector ? 'إخفاء القائمة' : 'تحديد يدوي سريع'}</span>
            </button>
          </div>

          {/* Manual Selection Dropdown / Drawer for all 28 extinguishers */}
          {showManualSelector && (
            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-3 space-y-2 animate-fade-in">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                  <Flame className="w-4 h-4 text-red-400" />
                  قائمة طفايات الحريق الـ ({extinguishers.length})
                </span>
                <span className="text-[10px] text-slate-400">انقر للفتح الفوري</span>
              </div>

              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-500 absolute right-2.5 top-2.5" />
                <input
                  type="text"
                  placeholder="بحث برقم الطفاية (EXT-01) أو القسم..."
                  value={searchManual}
                  onChange={(e) => setSearchManual(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl pr-8 pl-3 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-red-600"
                />
              </div>

              <div className="max-h-48 overflow-y-auto divide-y divide-slate-850 space-y-1 pr-1">
                {filteredManualList.length === 0 ? (
                  <p className="text-center py-4 text-slate-500 text-xs">لا توجد طفاية مطابقة للبحث</p>
                ) : (
                  filteredManualList.map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => handleSelectExtinguisherManually(item)}
                      className="w-full text-right p-2 rounded-xl hover:bg-slate-900 flex items-center justify-between text-xs transition group"
                    >
                      <div className="flex items-center gap-2 overflow-hidden">
                        <span className="font-mono font-bold text-teal-400 text-[11px] shrink-0 bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800 group-hover:border-teal-500">
                          {item.serialNumber}
                        </span>
                        <div className="overflow-hidden">
                          <span className="text-slate-200 block truncate font-medium text-[11px]">
                            {item.location}
                          </span>
                          <span className="text-[10px] text-slate-400 block truncate">
                            {item.typeAr} • {item.weight || item.capacity || '6 كجم'}
                          </span>
                        </div>
                      </div>
                      <span className="text-[10px] text-red-400 group-hover:translate-x-[-2px] transition font-bold shrink-0 mr-2">
                        فحص ⬅
                      </span>
                    </button>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-950 px-4 py-3 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
          <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
            <Zap className="w-3.5 h-3.5" />
            <span>تعرف فوري وسريع بنقرة واحدة</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold transition"
          >
            إلغاء
          </button>
        </div>
      </div>
    </div>
  );
};
