import React, { useState, useEffect } from 'react';
import { ShieldCheck, Eye, EyeOff, Lock, Wifi, Battery, Radio, RefreshCw, CloudCheck, CloudUpload } from 'lucide-react';
import { StaffUser } from '../types';
import { offlineStorage } from '../services/offlineStorage';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';

interface AndroidStatusBarProps {
  currentUser: StaffUser | null;
  privacyMode: boolean;
  onTogglePrivacy: () => void;
  onLock: () => void;
  isOnline: boolean;
}

export const AndroidStatusBar: React.FC<AndroidStatusBarProps> = ({
  currentUser,
  privacyMode,
  onTogglePrivacy,
  onLock,
  isOnline,
}) => {
  const [timeStr, setTimeStr] = useState('');
  const [batteryLevel, setBatteryLevel] = useState(94);
  const [pendingCount, setPendingCount] = useState(0);
  const [isSyncing, setIsSyncing] = useState(false);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString('ar-EG', {
          hour: '2-digit',
          minute: '2-digit',
          hour12: true,
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    let mounted = true;
    const checkPending = async () => {
      try {
        const count = await offlineStorage.getPendingSyncCount();
        if (mounted) setPendingCount(count);
      } catch {}
    };

    checkPending();
    const unsubscribe = offlineStorage.subscribe(() => {
      checkPending();
    });

    return () => {
      mounted = false;
      unsubscribe();
    };
  }, []);

  const handleManualSync = async () => {
    if (isSyncing) return;
    setIsSyncing(true);
    try {
      await offlineStorage.forceSyncAllPendingRecords();
      triggerSuccessFeedback();
      const count = await offlineStorage.getPendingSyncCount();
      setPendingCount(count);
    } catch {} finally {
      setIsSyncing(false);
    }
  };

  return (
    <div id="android-status-bar" className="w-full bg-slate-950/95 border-b border-slate-800/80 px-3 py-1.5 text-xs text-slate-300 flex items-center justify-between select-none z-30 sticky top-0 backdrop-blur-md">
      {/* Right side in RTL: System Clock and Hospital Security Badge */}
      <div className="flex items-center gap-2">
        <span className="font-semibold tracking-wider font-mono text-slate-100 text-xs">
          {timeStr || '12:00'}
        </span>
        <div className="flex items-center gap-1 bg-teal-950/80 text-teal-300 border border-teal-800/60 px-2 py-0.5 rounded-full text-[11px] font-medium">
          <ShieldCheck className="w-3 h-3 text-teal-400" />
          <span className="hidden sm:inline">نظام آمن مشفر</span>
          <span className="sm:hidden">آمن</span>
        </div>

        {/* Real-time Cloud Sync Engine Indicator */}
        <button
          type="button"
          onClick={handleManualSync}
          disabled={isSyncing}
          title={
            isSyncing 
              ? 'جارٍ رفع السجلات إلى السحابة...' 
              : pendingCount > 0 
                ? `يوجد ${pendingCount} سجل قيد المزامنة - انقر للمزامنة الفورية الآن`
                : 'كافة البيانات متزامنة سحابياً بنجاح (Synced)'
          }
          className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold transition-all ${
            isSyncing
              ? 'bg-teal-900/60 text-teal-300 border border-teal-600 animate-pulse'
              : pendingCount > 0
                ? 'bg-amber-950/80 text-amber-300 border border-amber-600 hover:bg-amber-900 cursor-pointer animate-bounce'
                : 'bg-emerald-950/70 text-emerald-300 border border-emerald-800/60 hover:bg-emerald-900/50'
          }`}
        >
          {isSyncing ? (
            <>
              <RefreshCw className="w-3 h-3 text-teal-400 animate-spin" />
              <span className="hidden sm:inline">جارٍ الرفع...</span>
            </>
          ) : pendingCount > 0 ? (
            <>
              <CloudUpload className="w-3 h-3 text-amber-400" />
              <span>معلق ({pendingCount}) • مزامنة الآن</span>
            </>
          ) : (
            <>
              <CloudCheck className="w-3 h-3 text-emerald-400" />
              <span className="hidden sm:inline">متزامن سحابياً</span>
              <span className="sm:hidden">متزامن</span>
            </>
          )}
        </button>
      </div>

      {/* Center: Current active user profile quick info */}
      {currentUser && (
        <div className="hidden md:flex items-center gap-1.5 text-[11px] bg-slate-900 px-2.5 py-0.5 rounded-full border border-slate-800">
          <div className={`w-2 h-2 rounded-full ${currentUser.avatarColor}`} />
          <span className="text-slate-200 font-medium truncate max-w-[150px]">{currentUser.name}</span>
          <span className="text-slate-400 text-[10px]">({currentUser.badgeNumber})</span>
        </div>
      )}

      {/* Left side in RTL: Privacy toggle, lock action, Wi-Fi, battery */}
      <div className="flex items-center gap-2">
        {/* Privacy masking toggle */}
        <button
          id="btn-toggle-privacy-mode"
          onClick={onTogglePrivacy}
          title={privacyMode ? 'إلغاء حظر الأسماء' : 'تفعيل قناع خصوصية المرضى (HIPAA)'}
          className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] transition-all font-medium ${
            privacyMode
              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse'
              : 'bg-slate-900 text-slate-300 hover:text-white border border-slate-800'
          }`}
        >
          {privacyMode ? <EyeOff className="w-3 h-3 text-amber-400" /> : <Eye className="w-3 h-3" />}
          <span className="hidden sm:inline">{privacyMode ? 'الخصوصية مفعّلة' : 'حماية الخصوصية'}</span>
        </button>

        {/* Lock Screen Button */}
        <button
          id="btn-instant-lock"
          onClick={onLock}
          title="قفل الشاشة فوراً لحماية السجلات"
          className="flex items-center gap-1 bg-rose-950/60 hover:bg-rose-900/70 text-rose-300 border border-rose-800/50 px-2 py-0.5 rounded-full text-[11px] transition-colors"
        >
          <Lock className="w-3 h-3 text-rose-400" />
          <span className="hidden sm:inline">قفل</span>
        </button>

        {/* Network & Battery icons typical of Android OS */}
        <div className="flex items-center gap-1 text-slate-400">
          {isOnline ? (
            <span title="متصل بالشبكة الطبية"><Wifi className="w-3.5 h-3.5 text-emerald-400" /></span>
          ) : (
            <span title="الوضع غير المتصل (PWA Offline)"><Radio className="w-3.5 h-3.5 text-amber-400 animate-pulse" /></span>
          )}
          <div className="flex items-center gap-0.5 font-mono text-[10px] text-slate-300">
            <span>{batteryLevel}%</span>
            <Battery className="w-3.5 h-3.5 text-slate-300" />
          </div>
        </div>
      </div>
    </div>
  );
};
