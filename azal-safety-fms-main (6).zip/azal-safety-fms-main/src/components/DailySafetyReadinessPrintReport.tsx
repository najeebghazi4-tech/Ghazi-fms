import React, { useState, useEffect, useMemo } from 'react';
import {
  Printer,
  ShieldCheck,
  Flame,
  AlertTriangle,
  Building2,
  Calendar,
  CheckCircle2,
  Clock,
  MapPin,
  Check,
  ArrowRight,
  TrendingUp,
  FileText,
  BadgeAlert,
  Edit3,
  Trash2,
  Plus,
  X,
  Send,
  Layers,
  Sparkles,
} from 'lucide-react';
import { AzalLogo } from './AzalLogo';
import { AZAL_HOSPITAL_PATROL_CHECKPOINTS } from '../data/azalHospitalSafetyRegistry';
import { SafetyViolationNotice, StaffUser } from '../types';
import { printExistingElementById } from '../utils/printUtils';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';

export interface ManualRecommendation {
  id: string;
  text: string;
  targetDepartment: string;
  priority?: 'عاجل' | 'هام' | 'روتيني';
  createdAt?: string;
}

const STORAGE_KEY_RECOMMENDATIONS = 'azal_manual_safety_recommendations_v2';

const DEFAULT_RECOMMENDATIONS: ManualRecommendation[] = [
  {
    id: 'rec-1',
    text: 'إلزام الأقسام ذات الإشعارات المعلقة (خصوصاً قسم الخدمات المساندة والنظافة) بفتح ممرات الطوارئ فوراً تحت طائلة المساءلة الإدارية.',
    targetDepartment: 'قسم الخدمات المساندة والنظافة',
    priority: 'عاجل',
  },
  {
    id: 'rec-2',
    text: 'التوجيه العاجل لقسم الصيانة العامة بإصلاح قفل لوحة الكهرباء DB-G04 وتأمين الأسلاك المكشوفة قبل انقضاء مهلة الـ 48 ساعة.',
    targetDepartment: 'قسم الصيانة العامة',
    priority: 'عاجل',
  },
  {
    id: 'rec-3',
    text: 'اعتماد أمر شراء وتعبئة طفايات الحريق في المطبخ والقبو (رغوة كيميائية 9 لتر) لضمان الوصول إلى نسبة جاهزية 100%.',
    targetDepartment: 'إدارة المشتريات والمستودعات',
    priority: 'هام',
  },
  {
    id: 'rec-4',
    text: 'استمرار الجولات التفتيشية الليلية المفاجئة للتأكد من انضباط مخارج الطوارئ وعدم تكديس العهد أو الأسرة الطبية في الممرات.',
    targetDepartment: 'إدارة الأمن والسلامة FMS',
    priority: 'هام',
  },
  {
    id: 'rec-5',
    text: 'إلزام مشرفي الورديات بالتبليغ الفوري عن أي عطل في شبكة إنذار الحريق أو محابس شبكة الغازات الطبية.',
    targetDepartment: 'جميع الأقسام ورؤساء الورديات',
    priority: 'روتيني',
  },
];

const SUGGESTED_DEPARTMENTS = [
  'قسم الخدمات المساندة والنظافة',
  'قسم الصيانة العامة',
  'إدارة المشتريات والمستودعات',
  'إدارة التمريض',
  'إدارة العمليات والعناية المركزة',
  'قسم الطوارئ والإسعاف',
  'المطبخ المركزي والإعاشة',
  'إدارة الأمن والسلامة FMS',
  'جميع الأقسام الطبية والمساندة',
];

interface DailySafetyReadinessPrintReportProps {
  currentUser?: StaffUser;
  violations?: SafetyViolationNotice[];
  onBack?: () => void;
}

export const DailySafetyReadinessPrintReport: React.FC<DailySafetyReadinessPrintReportProps> = ({
  currentUser,
  violations = [],
  onBack,
}) => {
  // Toggle Report View Mode: Default to Full Comprehensive Report
  const [reportMode, setReportMode] = useState<'summary' | 'detailed'>('detailed');

  // Load and manage recommendations manually (Zero automated alterations)
  const [recommendations, setRecommendations] = useState<ManualRecommendation[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_RECOMMENDATIONS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {
      // fallback
    }
    return DEFAULT_RECOMMENDATIONS;
  });

  // Save manual recommendations whenever updated
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_RECOMMENDATIONS, JSON.stringify(recommendations));
    } catch {
      // ignore
    }
  }, [recommendations]);

  // Edit State
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState('');
  const [editDepartment, setEditDepartment] = useState('');
  const [editPriority, setEditPriority] = useState<'عاجل' | 'هام' | 'روتيني'>('عاجل');

  // Add New State
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [newText, setNewText] = useState('');
  const [newDepartment, setNewDepartment] = useState('قسم الصيانة العامة');
  const [newPriority, setNewPriority] = useState<'عاجل' | 'هام' | 'روتيني'>('عاجل');

  // Violations list
  const allViolations: SafetyViolationNotice[] = useMemo(() => {
    if (violations && violations.length > 0) return violations;
    try {
      const saved = localStorage.getItem('azal_safety_violations_v1');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // fallback
    }
    return [];
  }, [violations]);

  // Census & Readiness metrics matching approved figures
  const totalExtinguishers = 45;
  const operationalExtinguishers = 43;
  const maintenanceExtinguishers = 2;
  const extinguisherReadinessRate = 96; // 96%

  // Resolution Statements (إفادات المعالجة: 0% معالجة)
  const resolvedCount = allViolations.filter((v) => v.status === 'resolved').length;
  const totalVioCount = allViolations.length || 7;
  const resolutionPercentage = Math.round((resolvedCount / totalVioCount) * 100); // 0%
  const pendingCount = totalVioCount - resolvedCount;

  // 10 Inspection Routes / Checkpoints
  const patrolCheckpoints = AZAL_HOSPITAL_PATROL_CHECKPOINTS.slice(0, 10);

  // Handlers for Manual Recommendations
  const handleStartEdit = (rec: ManualRecommendation) => {
    setEditingId(rec.id);
    setEditText(rec.text);
    setEditDepartment(rec.targetDepartment);
    setEditPriority(rec.priority || 'عاجل');
    setIsAddingNew(false);
  };

  const handleSaveEdit = () => {
    if (!editText.trim()) return;
    setRecommendations((prev) =>
      prev.map((r) =>
        r.id === editingId
          ? {
              ...r,
              text: editText.trim(),
              targetDepartment: editDepartment.trim() || 'إدارة المستشفى',
              priority: editPriority,
            }
          : r
      )
    );
    setEditingId(null);
    setEditText('');
    triggerSuccessFeedback();
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setEditText('');
  };

  const handleDelete = (id: string) => {
    if (window.confirm('هل أنت متأكد من حذف هذه التوصية الإدارية؟')) {
      setRecommendations((prev) => prev.filter((r) => r.id !== id));
      triggerSuccessFeedback();
    }
  };

  const handleSaveNew = () => {
    if (!newText.trim()) return;
    const newRec: ManualRecommendation = {
      id: `rec-manual-${Date.now()}`,
      text: newText.trim(),
      targetDepartment: newDepartment.trim() || 'إدارة المستشفى',
      priority: newPriority,
      createdAt: new Date().toISOString(),
    };
    setRecommendations((prev) => [...prev, newRec]);
    setNewText('');
    setIsAddingNew(false);
    triggerSuccessFeedback();
  };

  const handlePrint = () => {
    triggerSuccessFeedback();
    try {
      window.print();
    } catch {
      const sheetId = reportMode === 'summary' ? 'executive-summary-single-sheet' : 'daily-readiness-report-sheet';
      const title =
        reportMode === 'summary'
          ? 'موجز مؤشرات السلامة والجاهزية التنفيذي (A4 صفحة واحدة) - مستشفى آزال النموذجي'
          : 'التقرير اليومي الشامل للسلامة والجاهزية - مستشفى آزال النموذجي';

      printExistingElementById(sheetId, {
        title,
        subtitle: 'إدارة الأمن والسلامة وإدارة المرافق FMS • نسخة الإدارة العامة',
        refNumber: `AZAL-REP-${new Date().getFullYear()}-${reportMode === 'summary' ? 'EX-01' : 'DLY-01'}`,
      });
    }
  };

  const handleBackToSystem = () => {
    if (onBack) {
      onBack();
    } else {
      window.location.hash = '';
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 font-sans p-2 sm:p-6 flex flex-col items-center select-text">
      <style>{`
        @media print {
          /* إجبار الطابعة على إظهار كافة الخلفيات الملونة والحدود بدقة */
          *, *::before, *::after {
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
            color-adjust: exact !important;
          }

          /* إخفاء شريط التنقل العلوي الأسود وأزرار العمليات فقط */
          .top-navbar,
          header.fixed,
          nav,
          button,
          .btn,
          .no-print {
            display: none !important;
          }

          /* إظهار كافة الأقسام والجداول دون إخفاء أي حاوية */
          body, main, .report-container, table, tr, td, th, .card, .section {
            display: block !important;
            visibility: visible !important;
            height: auto !important;
            overflow: visible !important;
          }

          table {
            display: table !important;
            width: 100% !important;
          }

          tr {
            display: table-row !important;
            page-break-inside: avoid !important;
            break-inside: avoid !important;
          }

          td, th {
            display: table-cell !important;
          }

          /* هوامش قياسية للطباعة */
          @page {
            size: A4 portrait;
            margin: 10mm 8mm;
          }

          /* منع قطع البطاقات والتوصيات في منتصف الورقة */
          .recommendation-item, .kpi-card, .signature-box {
            page-break-inside: avoid !important;
            break-inside: avoid !important;
          }

          /* تثبيت ترويسة الجداول الملونة */
          thead {
            display: table-header-group !important;
          }
        }
      `}</style>

      {/* Floating Sticky Top Action Bar (Disappears on Print) */}
      <div className="no-print top-navbar sticky top-3 z-50 w-full max-w-5xl mb-4 bg-slate-950/95 backdrop-blur-md border border-teal-800/80 rounded-2xl p-3 sm:p-4 flex flex-wrap items-center justify-between gap-3 text-slate-100 shadow-2xl">
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          {/* View Mode Switcher */}
          <div className="flex items-center bg-slate-900 border border-slate-700/80 p-1 rounded-xl shadow-inner">
            <button
              type="button"
              id="btn-switch-summary"
              onClick={() => setReportMode('summary')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                reportMode === 'summary'
                  ? 'bg-gradient-to-r from-teal-600 to-emerald-600 text-white shadow-md'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <span>📊 مؤشرات رقمية موجزة (صفحة A4 واحدة)</span>
              <span className="text-[10px] bg-teal-950/80 text-teal-200 border border-teal-500/40 px-1.5 py-0.2 rounded-full font-mono font-normal">
                الافتراضي
              </span>
            </button>
            <button
              type="button"
              id="btn-switch-detailed"
              onClick={() => setReportMode('detailed')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                reportMode === 'detailed'
                  ? 'bg-gradient-to-r from-teal-600 to-emerald-600 text-white shadow-md'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>📑 تقرير تفصيلي كامل</span>
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Main Print Button */}
          <button
            type="button"
            id="btn-print-report"
            onClick={handlePrint}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-teal-950 transition active:scale-95"
            title="طباعة التقرير أو حفظه بصيغة PDF بجودة A4"
          >
            <Printer className="w-4 h-4" />
            <span>🖨️ طباعة التقرير / حفظ PDF</span>
          </button>

          {/* Return to Dashboard */}
          <button
            type="button"
            id="btn-back-dashboard"
            onClick={handleBackToSystem}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 transition active:scale-95 flex items-center gap-1"
          >
            <ArrowRight className="w-3.5 h-3.5" />
            <span>العودة للنظام الرئيسي</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* MODE 1: EXECUTIVE SUMMARY (A4 SINGLE-PAGE FOR GENERAL MANAGER)           */}
      {/* ========================================================================= */}
      {reportMode === 'summary' && (
        <div
          id="executive-summary-single-sheet"
          className="report-container executive-summary-wrapper summary-a4-sheet w-full max-w-5xl bg-white text-slate-900 border border-slate-300 rounded-3xl p-5 sm:p-7 space-y-4 shadow-2xl transition"
        >
          {/* 1. Compact Official Institutional Letterhead (Azal Hospital - FMS) */}
          <div className="border-b-2 border-slate-800 pb-3 flex items-center justify-between gap-4">
            {/* Right: Hospital & FMS Details */}
            <div className="flex items-center gap-3">
              <AzalLogo variant="horizontal" size="md" transparent={true} />
              <div>
                <span className="text-[10px] font-bold text-slate-500 block">الجمهورية اليمنية • صنعاء</span>
                <span className="text-xs font-bold text-teal-800 block leading-tight">
                  إدارة الأمن والسلامة وإدارة المرافق (FMS) • معتمد CBAHI
                </span>
                <span className="text-[10px] text-slate-600 font-bold block">
                  رئيس قسم السلامة وإدارة المرافق FMS: م/ نجيب قاسم غازي
                </span>
              </div>
            </div>

            {/* Middle: Badge */}
            <div className="text-center hidden sm:block">
              <div className="inline-block bg-teal-50 border border-teal-600 px-3 py-1 rounded-xl">
                <span className="text-xs font-black text-teal-900 block">
                  موجز المؤشرات التنفيذية للسلامة والجاهزية
                </span>
                <span className="text-[10px] font-bold text-teal-700 block">
                  صفحة A4 واحدة للمدير العام • نسخة معتمدة
                </span>
              </div>
            </div>

            {/* Left: Administrative Metadata */}
            <div className="text-left font-mono text-[10px] text-slate-700 space-y-0.5 bg-slate-50 p-2 rounded-xl border border-slate-300">
              <div><strong>رقم المرجع:</strong> AZAL-REP-{new Date().getFullYear()}-DLY-EX01</div>
              <div><strong>تاريخ التقرير:</strong> {new Date().toLocaleDateString('ar-EG', { dateStyle: 'medium' })}</div>
              <div><strong>درجة السرية:</strong> <span className="text-amber-700 font-bold">مباشر للمدير العام</span></div>
              <div className="text-emerald-700 font-bold">الحالة: معتمد ومزامَن إلكترونياً ⚡</div>
            </div>
          </div>

          {/* 2. Three Main Statistical KPI Cards (بطاقات المؤشرات الإحصائية) */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5 text-teal-700" />
                <span>أولاً: بطاقات المؤشرات الإحصائية الرئيسية للسلامة (Executive KPIs)</span>
              </h2>
              <span className="text-[10px] text-slate-500 font-mono">
                تحديث ميداني فوري • نسبة الدقة 100%
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 print-card-grid">
              {/* Card 1: Completed Tours & Routes */}
              <div className="kpi-card bg-slate-50 border-2 border-blue-200 p-3 rounded-2xl print-card space-y-1">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-blue-900 font-bold text-xs">
                    <MapPin className="w-4 h-4 text-blue-600" />
                    <span>الجولات والمسارات التفتيشية</span>
                  </div>
                  <span className="text-[10px] font-bold bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full font-mono">
                    10 مسارات
                  </span>
                </div>
                <div className="text-2xl font-black font-mono text-blue-950">
                  10 <span className="text-xs font-sans text-slate-600 font-normal">مسارات منجزة</span>
                </div>
                <div className="text-[11px] font-bold text-blue-800 bg-blue-100/60 p-1 rounded-lg border border-blue-200">
                  تغطية شاملة 100% لكافة الأقسام والمرافق
                </div>
                <p className="text-[10px] text-slate-600 leading-tight">
                  شملت الطوارئ، العمليات، العناية، الأشعة، المطبخ، ومحطة الغازات والمولدات.
                </p>
              </div>

              {/* Card 2: Fire Extinguishers Network Readiness */}
              <div className="kpi-card bg-slate-50 border-2 border-emerald-200 p-3 rounded-2xl print-card space-y-1">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-emerald-900 font-bold text-xs">
                    <Flame className="w-4 h-4 text-rose-600" />
                    <span>جاهزية شبكة مطافئ الحريق</span>
                  </div>
                  <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-mono">
                    {extinguisherReadinessRate}% جاهزية
                  </span>
                </div>
                <div className="text-2xl font-black font-mono text-emerald-900">
                  {operationalExtinguishers} / {totalExtinguishers}{' '}
                  <span className="text-xs font-sans text-slate-600 font-normal">أسطوانة وعربة</span>
                </div>
                <div className="grid grid-cols-2 gap-1 text-[10px] font-bold">
                  <span className="bg-emerald-100 text-emerald-900 p-1 rounded border border-emerald-200 text-center">
                    ✓ {operationalExtinguishers} صالحة للعمل
                  </span>
                  <span className="bg-amber-100 text-amber-900 p-1 rounded border border-amber-200 text-center">
                    ⚠️ {maintenanceExtinguishers} بحاجة تعبئة
                  </span>
                </div>
                <p className="text-[10px] text-slate-600 leading-tight">
                  تم التدقيق على ضغوط البودرة وCO2، ورصد أسطوانتي رغوة تحتاجان إعادة تعبئة.
                </p>
              </div>

              {/* Card 3: Daily Notices & Violations Status */}
              <div className="kpi-card bg-slate-50 border-2 border-rose-200 p-3 rounded-2xl print-card space-y-1">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-rose-900 font-bold text-xs">
                    <AlertTriangle className="w-4 h-4 text-rose-600" />
                    <span>بلاغات ومخالفات اليوم</span>
                  </div>
                  <span className="text-[10px] font-bold bg-rose-100 text-rose-800 px-2 py-0.5 rounded-full font-mono">
                    {resolutionPercentage}% معالجة
                  </span>
                </div>
                <div className="text-2xl font-black font-mono text-rose-900">
                  {totalVioCount} <span className="text-xs font-sans text-slate-600 font-normal">إشعارات مرصودة</span>
                </div>
                <div className="grid grid-cols-2 gap-1 text-[10px] font-bold">
                  <span className="bg-rose-50 text-rose-800 p-1 rounded border border-rose-200 text-center">
                    {pendingCount} قيد المتابعة والمهلة
                  </span>
                  <span className="bg-slate-100 text-slate-700 p-1 rounded border border-slate-300 text-center">
                    {resolvedCount} إفادات معتمدة
                  </span>
                </div>
                <p className="text-[10px] text-slate-600 leading-tight">
                  المخالفات معلقة بانتظار إفادات الصيانة والخدمات المساندة ضمن مهلة 48 ساعة.
                </p>
              </div>
            </div>
          </div>

          {/* 3. Manual Recommendations & Administrative Decisions for GM */}
          <div className="recommendation-box border-2 border-teal-700/80 bg-teal-50/30 rounded-2xl p-3.5 sm:p-4 space-y-2.5 print-card">
            <div className="flex items-center justify-between border-b border-teal-200 pb-2">
              <div>
                <h3 className="text-xs font-black text-teal-950 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-teal-700" />
                  <span>ثانياً: التوصيات والقرارات الإدارية المرفوعة للمدير العام</span>
                </h3>
                <span className="text-[10px] text-teal-800 font-semibold block mt-0.5">
                  تخضع للتحكم والإدارة اليدوية البحتة من قِبل رئيس قسم السلامة (بدون أي اقتراح آلي)
                </span>
              </div>
              <div className="no-print">
                {!isAddingNew && (
                  <button
                    type="button"
                    onClick={() => {
                      setIsAddingNew(true);
                      setEditingId(null);
                    }}
                    className="btn-action no-print px-2.5 py-1 bg-teal-700 hover:bg-teal-800 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-sm transition active:scale-95"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>إضافة توصية جديدة</span>
                  </button>
                )}
              </div>
            </div>

            {/* Recommendations List */}
            <ol className="space-y-1.5 text-xs text-slate-800 leading-relaxed pr-0.5">
              {recommendations.map((rec, idx) => (
                <li
                  key={rec.id}
                  className="recommendation-item card bg-white p-2.5 rounded-xl border border-teal-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                >
                  <div className="flex items-start gap-2 flex-1">
                    <span className="w-5 h-5 rounded-md bg-teal-800 text-white font-mono font-black text-[11px] flex items-center justify-center shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <div className="space-y-1 flex-1">
                      <p className="font-bold text-slate-900 text-xs sm:text-[13px] leading-snug">
                        {rec.text}
                      </p>
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="text-[10px] font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md border border-slate-300">
                          الجهة المعنية: <strong className="text-teal-900">{rec.targetDepartment}</strong>
                        </span>
                        {rec.priority && (
                          <span
                            className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                              rec.priority === 'عاجل'
                                ? 'bg-rose-100 text-rose-800 border border-rose-300'
                                : rec.priority === 'هام'
                                ? 'bg-amber-100 text-amber-800 border border-amber-300'
                                : 'bg-slate-100 text-slate-700 border border-slate-300'
                            }`}
                          >
                            {rec.priority}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Manual Administrative Control Actions (Hidden on Print) */}
                  <div className="no-print flex items-center gap-1 shrink-0 self-end sm:self-center border-t sm:border-t-0 pt-1 sm:pt-0 border-slate-100">
                    <button
                      type="button"
                      onClick={() => handleStartEdit(rec)}
                      className="btn-action no-print px-2 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-bold flex items-center gap-1 border border-slate-300 transition"
                      title="تعديل نص التوصية والجهة المعنية"
                    >
                      <Edit3 className="w-3 h-3 text-teal-600" />
                      <span>تعديل</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDelete(rec.id)}
                      className="btn-action no-print px-2 py-1 rounded bg-rose-50 hover:bg-rose-100 text-rose-700 text-[11px] font-bold flex items-center gap-1 border border-rose-200 transition"
                      title="حذف هذه التوصية"
                    >
                      <Trash2 className="w-3 h-3 text-rose-600" />
                      <span>حذف</span>
                    </button>
                  </div>
                </li>
              ))}
            </ol>

            {/* Inline Editor for an existing recommendation (Hidden on Print) */}
            {editingId && (
              <div className="no-print bg-amber-50 border-2 border-amber-400 p-3 rounded-xl space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-amber-900 border-b border-amber-200 pb-1">
                  <span>✏️ تعديل التوصية الإدارية يدوياً:</span>
                  <button type="button" onClick={handleCancelEdit} className="text-slate-500 hover:text-slate-800">
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <textarea
                  value={editText}
                  onChange={(e) => setEditText(e.target.value)}
                  rows={2}
                  className="w-full p-2 text-xs bg-white text-slate-900 border border-amber-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                  placeholder="اكتب نص التوصية الإدارية بدقة..."
                />
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-0.5">الجهة المعنية / القسم المكلف:</label>
                    <input
                      type="text"
                      value={editDepartment}
                      onChange={(e) => setEditDepartment(e.target.value)}
                      className="w-full p-1.5 text-xs bg-white text-slate-900 border border-slate-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-0.5">درجة الأولوية:</label>
                    <select
                      value={editPriority}
                      onChange={(e) => setEditPriority(e.target.value as any)}
                      className="w-full p-1.5 text-xs bg-white text-slate-900 border border-slate-300 rounded-lg"
                    >
                      <option value="عاجل">عاجل</option>
                      <option value="هام">هام</option>
                      <option value="روتيني">روتيني</option>
                    </select>
                  </div>
                </div>
                <div className="flex items-center justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={handleCancelEdit}
                    className="px-3 py-1 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold rounded-lg transition"
                  >
                    إلغاء
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveEdit}
                    className="px-4 py-1 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-lg transition shadow-sm"
                  >
                    حفظ التعديلات
                  </button>
                </div>
              </div>
            )}

            {/* Inline Form to Add a New Manual Recommendation (Hidden on Print) */}
            {isAddingNew && (
              <div className="no-print bg-teal-50 border-2 border-teal-500 p-3 rounded-xl space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-teal-900 border-b border-teal-200 pb-1">
                  <span>➕ إضافة توصية إدارية جديدة (إدخال يدوي):</span>
                  <button type="button" onClick={() => setIsAddingNew(false)} className="text-slate-500 hover:text-slate-800">
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <textarea
                  value={newText}
                  onChange={(e) => setNewText(e.target.value)}
                  rows={2}
                  className="w-full p-2 text-xs bg-white text-slate-900 border border-teal-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
                  placeholder="اكتب التوجيه أو القرار الإداري المطلوب من الإدارة العامة بدقة..."
                />
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-0.5">الجهة المعنية / القسم المكلف:</label>
                    <input
                      type="text"
                      value={newDepartment}
                      onChange={(e) => setNewDepartment(e.target.value)}
                      className="w-full p-1.5 text-xs bg-white text-slate-900 border border-slate-300 rounded-lg"
                      placeholder="مثال: قسم الصيانة العامة"
                    />
                    <div className="flex flex-wrap gap-1 mt-1">
                      {SUGGESTED_DEPARTMENTS.slice(0, 4).map((d) => (
                        <button
                          key={d}
                          type="button"
                          onClick={() => setNewDepartment(d)}
                          className="text-[9px] bg-white hover:bg-teal-100 text-teal-800 px-1.5 py-0.5 rounded border border-teal-200 transition"
                        >
                          {d}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-0.5">درجة الأولوية:</label>
                    <select
                      value={newPriority}
                      onChange={(e) => setNewPriority(e.target.value as any)}
                      className="w-full p-1.5 text-xs bg-white text-slate-900 border border-slate-300 rounded-lg"
                    >
                      <option value="عاجل">عاجل</option>
                      <option value="هام">هام</option>
                      <option value="روتيني">روتيني</option>
                    </select>
                  </div>
                </div>
                <div className="flex items-center justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setIsAddingNew(false)}
                    className="px-3 py-1 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold rounded-lg transition"
                  >
                    إلغاء
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveNew}
                    className="px-4 py-1 bg-teal-700 hover:bg-teal-800 text-white text-xs font-bold rounded-lg transition shadow-sm"
                  >
                    اعتماد وإضافة التوصية
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* 4. Official Authorization & Stamps (A4 Bottom Anchor) */}
          <div className="pt-3 border-t-2 border-slate-800">
            <div className="grid grid-cols-2 gap-4 text-center text-xs print-signature-grid">
              {/* Left Column: Head of Safety & FMS */}
              <div className="signature-box p-3 border-2 border-teal-700 rounded-2xl bg-teal-50/40 print-card space-y-1.5">
                <span className="text-[10px] font-bold text-teal-800 block">
                  رئيس قسم السلامة وإدارة المرافق (FMS)
                </span>
                <div className="font-black text-teal-950 text-sm">
                  م/ نجيب قاسم غازي
                </div>
                <div className="h-8 border-b border-dashed border-teal-700 flex items-end justify-center pb-0.5">
                  <span className="text-[10px] text-teal-800 font-bold font-mono">مُعتمد ومصادق عليه إلكترونياً ✓</span>
                </div>
                <span className="text-[9px] text-slate-500 block font-mono">
                  إدارة الأمن والسلامة • مستشفى آزال النموذجي
                </span>
              </div>

              {/* Right Column: General Manager Approval & Hospital Stamp */}
              <div className="signature-box p-3 border border-slate-300 rounded-2xl bg-slate-50 print-card space-y-1.5">
                <span className="text-[10px] font-bold text-slate-600 block">
                  المدير العام للمستشفى
                </span>
                <div className="font-black text-slate-900 text-sm">
                  د/ محمد السراجي
                </div>
                <div className="w-28 h-10 mx-auto border-2 border-dashed border-teal-700 rounded-full flex flex-col items-center justify-center text-[8px] text-teal-900 font-bold bg-white shadow-inner my-0.5">
                  <span>مستشفى آزال النموذجي</span>
                  <span className="text-[7px] text-slate-500">الختم الرسمي للإدارة العامة</span>
                </div>
                <span className="text-[9px] text-slate-600 font-bold block">
                  الاعتماد النهائي والتوجيه الإداري
                </span>
              </div>
            </div>

            <div className="mt-2.5 pt-1.5 border-t border-slate-200 text-center text-[9px] text-slate-500 font-mono">
              نظام مستشفى آزال النموذجي لإدارة السلامة FMS • وثيقة رسمية صادرة برقم مرجعي معتمد • صفحة A4 واحدة • صنعاء، الجمهورية اليمنية
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODE 2: DETAILED MULTI-SECTION REPORT                                     */}
      {/* ========================================================================= */}
      {reportMode === 'detailed' && (
        <div
          id="daily-readiness-report-sheet"
          className="report-container w-full max-w-5xl bg-white text-slate-900 border border-slate-300 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl transition"
        >
          {/* 1. Official Institutional Letterhead */}
          <div className="border-b-2 border-slate-800 pb-4 space-y-3">
            <div className="flex items-center justify-between gap-4">
              {/* Right: Hospital & FMS Details */}
              <div className="flex items-center gap-3">
                <AzalLogo variant="horizontal" size="lg" transparent={true} />
                <div>
                  <span className="text-[11px] font-bold text-slate-500 block">الجمهورية اليمنية • صنعاء</span>
                  <span className="text-xs font-bold text-teal-800 block">
                    إدارة الأمن والسلامة وإدارة المرافق (FMS) • معتمد CBAHI
                  </span>
                  <span className="text-[11px] text-slate-600 font-semibold block">
                    رئيس قسم السلامة وإدارة المرافق FMS: م/ نجيب قاسم غازي
                  </span>
                </div>
              </div>

              {/* Left: Administrative Filing Metadata */}
              <div className="text-left font-mono text-[11px] text-slate-700 space-y-1 bg-slate-100 p-3 rounded-xl border border-slate-300">
                <div><strong>رقم المرجع:</strong> AZAL-REP-{new Date().getFullYear()}-DLY-01</div>
                <div><strong>تاريخ التقرير:</strong> {new Date().toLocaleDateString('ar-EG', { dateStyle: 'full' })}</div>
                <div><strong>درجة السرية:</strong> <span className="text-amber-700 font-bold">تقرير تفصيلي شامل للمدير العام</span></div>
                <div className="text-emerald-700 font-bold">الحالة: معتمد ومزامَن إلكترونياً ⚡</div>
              </div>
            </div>
          </div>

          {/* 2. Executive Report Heading Banner */}
          <div className="bg-slate-50 border-2 border-teal-700 rounded-2xl p-4 sm:p-5 space-y-3 print-card">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-300 pb-2.5">
              <div>
                <h2 className="text-base sm:text-lg font-black text-slate-900 tracking-tight">
                  التقرير اليومي الشامل للسلامة الميدانية وحصر الجاهزية (Daily Safety & Readiness Report)
                </h2>
                <div className="text-xs font-bold text-teal-800 mt-0.5">
                  مستشفى آزال النموذجي • الإدارة العامة • تقرير المتابعة الميدانية اليومية
                </div>
              </div>
              <div className="text-xs font-mono font-bold text-teal-900 bg-teal-100 px-3 py-1 rounded-xl border border-teal-300">
                اليوم: {new Date().toLocaleDateString('ar-EG', { weekday: 'long' })}
              </div>
            </div>

            <div className="bg-white border-r-4 border-teal-600 p-3 rounded-xl">
              <span className="font-black text-teal-800 text-xs sm:text-sm">الموضوع: </span>
              <span className="text-xs sm:text-sm font-bold text-slate-900">
                تقرير المتابعة الميدانية اليومية، حصر شبكة الإطفاء، جاهزية مسارات التفتيش الـ 10، ومتابعة إفادات المعالجة
              </span>
            </div>

            <p className="text-slate-700 text-xs sm:text-[13px] leading-relaxed text-justify">
              نرفع لسيادتكم التقرير الرقابي والميداني اليومي لإدارة الأمن والسلامة وإدارة المرافق (FMS) المتضمن خلاصة جولات التفتيش الرقابية عبر (10 مسارات رقابية)، ومستوى جاهزية شبكة الإطفاء البالغ عددها (45 أسطوانة وعربة) بنسبة جاهزية (96%)، ومتابعة إفادات المعالجة الميدانية للمخالفات، مصحوبة بالتوصيات الميدانية الخمس العاجلة لاتخاذ التوجيهات اللازمة.
            </p>
          </div>

          {/* 3. Executive KPI Dashboard - 4 Top Pillars */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 print-card-grid">
            {/* Pillar 1 */}
            <div className="bg-slate-50 border border-slate-300 p-3.5 rounded-2xl text-center space-y-1 print-card">
              <div className="flex items-center justify-center gap-1.5 text-slate-600 text-xs font-bold">
                <Flame className="w-4 h-4 text-rose-600" />
                <span>شبكة الإطفاء</span>
              </div>
              <div className="text-2xl font-black font-mono text-slate-900">
                {totalExtinguishers} <span className="text-xs font-sans text-slate-500 font-normal">أسطوانة/عربة</span>
              </div>
              <div className="text-[11px] font-bold text-emerald-700 bg-emerald-50 py-0.5 px-2 rounded-lg border border-emerald-200">
                {operationalExtinguishers} صالحة ({extinguisherReadinessRate}% جاهزية)
              </div>
              <span className="text-[10px] text-amber-700 block">
                {maintenanceExtinguishers} بحاجة صيانة وتعبئة
              </span>
            </div>

            {/* Pillar 2 */}
            <div className="bg-slate-50 border border-slate-300 p-3.5 rounded-2xl text-center space-y-1 print-card">
              <div className="flex items-center justify-center gap-1.5 text-slate-600 text-xs font-bold">
                <MapPin className="w-4 h-4 text-blue-600" />
                <span>مسارات التفتيش</span>
              </div>
              <div className="text-2xl font-black font-mono text-blue-900">
                10 <span className="text-xs font-sans text-slate-500 font-normal">مسارات رقابية</span>
              </div>
              <div className="text-[11px] font-bold text-blue-700 bg-blue-50 py-0.5 px-2 rounded-lg border border-blue-200">
                تفتيش شامل لجميع الأقسام
              </div>
              <span className="text-[10px] text-slate-500 block">
                جولات تفتيش دورية معتمدة
              </span>
            </div>

            {/* Pillar 3 */}
            <div className="bg-slate-50 border border-slate-300 p-3.5 rounded-2xl text-center space-y-1 print-card">
              <div className="flex items-center justify-center gap-1.5 text-slate-600 text-xs font-bold">
                <Clock className="w-4 h-4 text-amber-600" />
                <span>إفادات المعالجة</span>
              </div>
              <div className="text-2xl font-black font-mono text-rose-700">
                0% <span className="text-xs font-sans text-slate-500 font-normal">معالجة</span>
              </div>
              <div className="text-[11px] font-bold text-rose-700 bg-rose-50 py-0.5 px-2 rounded-lg border border-rose-200">
                قيد المتابعة والمهلة
              </div>
              <span className="text-[10px] text-slate-500 block">
                لم تُستكمل إفادات الأقسام
              </span>
            </div>

            {/* Pillar 4 */}
            <div className="bg-slate-50 border border-slate-300 p-3.5 rounded-2xl text-center space-y-1 print-card">
              <div className="flex items-center justify-center gap-1.5 text-slate-600 text-xs font-bold">
                <ShieldCheck className="w-4 h-4 text-teal-700" />
                <span>إشراف السلامة FMS</span>
              </div>
              <div className="text-sm font-black text-slate-900 leading-tight pt-1">
                م/ نجيب قاسم غازي
              </div>
              <div className="text-[11px] font-bold text-teal-800 bg-teal-50 py-0.5 px-2 rounded-lg border border-teal-200">
                رئيس قسم الأمن والسلامة
              </div>
              <span className="text-[10px] text-slate-500 block">
                معايير CBAHI FMS المعتمدة
              </span>
            </div>
          </div>

          {/* 4. Inspection Routes Registry (10 Checkpoints) */}
          <div className="section space-y-3">
            <div className="flex items-center justify-between border-b border-slate-300 pb-2">
              <h3 className="text-xs font-bold text-slate-800 flex items-center gap-2">
                <MapPin className="w-4 h-4 text-teal-700" />
                <span>أولاً: مسارات وجولات التفتيش الرقابية المعتمدة (10 مسارات رقابية)</span>
              </h3>
              <span className="text-[11px] font-mono text-slate-500">
                10 مسارات ميدانية معتمدة بمستشفى آزال
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs border border-slate-300 print-table">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-300">
                    <th className="py-2.5 px-3 w-10 text-center">#</th>
                    <th className="py-2.5 px-3">القسم / المرفق</th>
                    <th className="py-2.5 px-3">نطاق المسار الرقابي وموقع الفحص</th>
                    <th className="py-2.5 px-3">مهام التفتيش اليومية</th>
                    <th className="py-2.5 px-3">المفتش المسؤول</th>
                    <th className="py-2.5 px-3 text-center">حالة الجاهزية</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {patrolCheckpoints.map((chk, idx) => (
                    <tr key={chk.id} className="hover:bg-slate-50 transition">
                      <td className="py-2 px-3 text-center font-mono text-slate-500 text-[11px] font-bold">
                        {idx + 1}
                      </td>
                      <td className="py-2 px-3 font-bold text-slate-900">
                        {chk.department}
                      </td>
                      <td className="py-2 px-3 text-slate-700 text-[11px]">
                        {chk.checkpointName}
                        <span className="block text-[10px] text-slate-500">{chk.floor} - {chk.zone}</span>
                      </td>
                      <td className="py-2 px-3 text-[11px] text-slate-600">
                        {chk.tasks.join(' • ')}
                      </td>
                      <td className="py-2 px-3 text-slate-700 text-[11px] font-medium">
                        {chk.inspectorName}
                      </td>
                      <td className="py-2 px-3 text-center">
                        <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          chk.status === 'attention_required'
                            ? 'bg-amber-100 text-amber-900 border border-amber-300'
                            : 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                        }`}>
                          {chk.statusAr}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* 5. Fire Extinguishers Network Census Details */}
          <div className="section bg-slate-50 border border-slate-300 rounded-2xl p-4 space-y-3 print-card">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <h3 className="text-xs font-bold text-slate-800 flex items-center gap-2">
                <Flame className="w-4 h-4 text-rose-600" />
                <span>ثانياً: الحصر الفني لمنظومة أسطوانات وعربات الإطفاء (45 أسطوانة وعربة)</span>
              </h3>
              <span className="text-[11px] font-mono font-bold text-emerald-800">
                نسبة الجاهزية الإجمالية: 96% (43 صالحة - 2 صيانة)
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-center text-xs">
              <div className="p-2 bg-white rounded-xl border border-slate-200">
                <span className="text-[10px] text-slate-500 block">بودرة جافة ABC</span>
                <strong className="text-base text-slate-900 font-mono">24</strong>
                <span className="text-[9px] text-emerald-700 block">صالحة وسليمة ✓</span>
              </div>
              <div className="p-2 bg-white rounded-xl border border-slate-200">
                <span className="text-[10px] text-slate-500 block">ثاني أكسيد الكربون CO2</span>
                <strong className="text-base text-slate-900 font-mono">13</strong>
                <span className="text-[9px] text-emerald-700 block">جاهزة للكهرباء والأجهزة ✓</span>
              </div>
              <div className="p-2 bg-white rounded-xl border border-slate-200">
                <span className="text-[10px] text-slate-500 block">رغوة AFFF مائية</span>
                <strong className="text-base text-slate-900 font-mono">4</strong>
                <span className="text-[9px] text-amber-700 block">2 جاهزة / 2 إعادة تعبئة ⚠️</span>
              </div>
              <div className="p-2 bg-white rounded-xl border border-slate-200">
                <span className="text-[10px] text-slate-500 block">ماء تحت الضغط Water</span>
                <strong className="text-base text-slate-900 font-mono">2</strong>
                <span className="text-[9px] text-emerald-700 block">صالحة للنفايات والخشب ✓</span>
              </div>
              <div className="p-2 bg-white rounded-xl border border-slate-200">
                <span className="text-[10px] text-slate-500 block">كيماوي رطب K للمطبخ</span>
                <strong className="text-base text-slate-900 font-mono">2</strong>
                <span className="text-[9px] text-emerald-700 block">جاهزة لزيوت الطهي ✓</span>
              </div>
            </div>
          </div>

          {/* 6. Manual Recommendations Section */}
          <div className="section border-2 border-teal-700/80 bg-teal-50/40 rounded-2xl p-4 sm:p-5 space-y-3 print-card">
            <div className="flex items-center justify-between border-b border-teal-200 pb-2">
              <div>
                <h3 className="text-xs font-bold text-teal-950 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-teal-700" />
                  <span>ثالثاً: التوصيات والقرارات الإدارية المرفوعة للمدير العام (إدارة وتحكم يدوي)</span>
                </h3>
                <span className="text-[10px] text-teal-800">خاضعة للتعديل والحذف والإضافة اليدوية الصرفة من قِبل إدارة السلامة</span>
              </div>
              <div className="no-print">
                {!isAddingNew && (
                  <button
                    type="button"
                    onClick={() => {
                      setIsAddingNew(true);
                      setEditingId(null);
                    }}
                    className="px-2.5 py-1 bg-teal-700 hover:bg-teal-800 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-sm transition active:scale-95"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>إضافة توصية جديدة</span>
                  </button>
                )}
              </div>
            </div>

            <ol className="space-y-2 text-xs text-slate-800 leading-relaxed pr-1">
              {recommendations.map((rec, idx) => (
                <li
                  key={rec.id}
                  className="recommendation-item card flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 bg-white p-3 rounded-xl border border-teal-200 shadow-sm"
                >
                  <div className="flex items-start gap-2.5 flex-1">
                    <span className="w-6 h-6 rounded-lg bg-teal-800 text-white font-mono font-black text-xs flex items-center justify-center shrink-0">
                      {idx + 1}
                    </span>
                    <div className="space-y-1">
                      <span className="font-semibold text-slate-900 block leading-snug">{rec.text}</span>
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="text-[10px] font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded border border-slate-300">
                          الجهة المعنية: <strong className="text-teal-900">{rec.targetDepartment}</strong>
                        </span>
                        {rec.priority && (
                          <span
                            className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                              rec.priority === 'عاجل'
                                ? 'bg-rose-100 text-rose-800 border border-rose-300'
                                : rec.priority === 'هام'
                                ? 'bg-amber-100 text-amber-800 border border-amber-300'
                                : 'bg-slate-100 text-slate-700 border border-slate-300'
                            }`}
                          >
                            {rec.priority}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Manual Controls */}
                  <div className="no-print flex items-center gap-1 shrink-0 self-end sm:self-center">
                    <button
                      type="button"
                      onClick={() => handleStartEdit(rec)}
                      className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1 border border-slate-300 transition"
                    >
                      <Edit3 className="w-3 h-3 text-teal-600" />
                      <span>تعديل</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDelete(rec.id)}
                      className="px-2.5 py-1 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold flex items-center gap-1 border border-rose-200 transition"
                    >
                      <Trash2 className="w-3 h-3 text-rose-600" />
                      <span>حذف</span>
                    </button>
                  </div>
                </li>
              ))}
            </ol>

            {/* Inline Editor for an existing recommendation (Hidden on Print) */}
            {editingId && (
              <div className="no-print bg-amber-50 border-2 border-amber-400 p-3 rounded-xl space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-amber-900 border-b border-amber-200 pb-1">
                  <span>✏️ تعديل التوصية الإدارية يدوياً:</span>
                  <button type="button" onClick={handleCancelEdit} className="text-slate-500 hover:text-slate-800">
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <textarea
                  value={editText}
                  onChange={(e) => setEditText(e.target.value)}
                  rows={2}
                  className="w-full p-2 text-xs bg-white text-slate-900 border border-amber-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500"
                  placeholder="اكتب نص التوصية الإدارية بدقة..."
                />
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-0.5">الجهة المعنية / القسم المكلف:</label>
                    <input
                      type="text"
                      value={editDepartment}
                      onChange={(e) => setEditDepartment(e.target.value)}
                      className="w-full p-1.5 text-xs bg-white text-slate-900 border border-slate-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-0.5">درجة الأولوية:</label>
                    <select
                      value={editPriority}
                      onChange={(e) => setEditPriority(e.target.value as any)}
                      className="w-full p-1.5 text-xs bg-white text-slate-900 border border-slate-300 rounded-lg"
                    >
                      <option value="عاجل">عاجل</option>
                      <option value="هام">هام</option>
                      <option value="روتيني">روتيني</option>
                    </select>
                  </div>
                </div>
                <div className="flex items-center justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={handleCancelEdit}
                    className="px-3 py-1 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold rounded-lg transition"
                  >
                    إلغاء
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveEdit}
                    className="px-4 py-1 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-lg transition shadow-sm"
                  >
                    حفظ التعديلات
                  </button>
                </div>
              </div>
            )}

            {/* Inline Form to Add a New Manual Recommendation (Hidden on Print) */}
            {isAddingNew && (
              <div className="no-print bg-teal-50 border-2 border-teal-500 p-3 rounded-xl space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-teal-900 border-b border-teal-200 pb-1">
                  <span>➕ إضافة توصية إدارية جديدة (إدخال يدوي):</span>
                  <button type="button" onClick={() => setIsAddingNew(false)} className="text-slate-500 hover:text-slate-800">
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <textarea
                  value={newText}
                  onChange={(e) => setNewText(e.target.value)}
                  rows={2}
                  className="w-full p-2 text-xs bg-white text-slate-900 border border-teal-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
                  placeholder="اكتب التوجيه أو القرار الإداري المطلوب من الإدارة العامة بدقة..."
                />
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-0.5">الجهة المعنية / القسم المكلف:</label>
                    <input
                      type="text"
                      value={newDepartment}
                      onChange={(e) => setNewDepartment(e.target.value)}
                      className="w-full p-1.5 text-xs bg-white text-slate-900 border border-slate-300 rounded-lg"
                      placeholder="مثال: قسم الصيانة العامة"
                    />
                    <div className="flex flex-wrap gap-1 mt-1">
                      {SUGGESTED_DEPARTMENTS.slice(0, 4).map((d) => (
                        <button
                          key={d}
                          type="button"
                          onClick={() => setNewDepartment(d)}
                          className="text-[9px] bg-white hover:bg-teal-100 text-teal-800 px-1.5 py-0.5 rounded border border-teal-200 transition"
                        >
                          {d}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-0.5">درجة الأولوية:</label>
                    <select
                      value={newPriority}
                      onChange={(e) => setNewPriority(e.target.value as any)}
                      className="w-full p-1.5 text-xs bg-white text-slate-900 border border-slate-300 rounded-lg"
                    >
                      <option value="عاجل">عاجل</option>
                      <option value="هام">هام</option>
                      <option value="روتيني">روتيني</option>
                    </select>
                  </div>
                </div>
                <div className="flex items-center justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setIsAddingNew(false)}
                    className="px-3 py-1 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold rounded-lg transition"
                  >
                    إلغاء
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveNew}
                    className="px-4 py-1 bg-teal-700 hover:bg-teal-800 text-white text-xs font-bold rounded-lg transition shadow-sm"
                  >
                    اعتماد وإضافة التوصية
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* 7. Outstanding Observations Table */}
          <div className="section space-y-3">
            <div className="flex items-center justify-between border-b border-slate-300 pb-2">
              <h3 className="text-xs font-bold text-slate-800 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-600" />
                <span>رابعاً: موقف المخالفات الميدانية وإفادات الأقسام (إفادات المعالجة: 0% معالجة)</span>
              </h3>
              <span className="text-[11px] font-mono text-rose-700 font-bold">
                جميع المخالفات قيد المتابعة ولم يتم تسليم إفادات معتمدة
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs border border-slate-300 print-table">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-300">
                    <th className="py-2.5 px-3">رقم الإشعار</th>
                    <th className="py-2.5 px-3">القسم المعني</th>
                    <th className="py-2.5 px-3">وصف المخالفة الميدانية</th>
                    <th className="py-2.5 px-3">مستوى الخطورة</th>
                    <th className="py-2.5 px-3">المهلة المحددة</th>
                    <th className="py-2.5 px-3 text-center">موقف إفادة المعالجة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {allViolations.slice(0, 5).map((vio) => (
                    <tr key={vio.id} className="hover:bg-slate-50 transition">
                      <td className="py-2 px-3 font-mono font-bold text-slate-900 text-[11px]">
                        {vio.id}
                      </td>
                      <td className="py-2 px-3 font-semibold text-slate-800">
                        {vio.department}
                      </td>
                      <td className="py-2 px-3 text-slate-700 text-[11px] max-w-xs">
                        {vio.description}
                      </td>
                      <td className="py-2 px-3">
                        <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          vio.severity === 'high' || vio.severity === 'critical'
                            ? 'bg-rose-100 text-rose-800 border border-rose-300'
                            : 'bg-amber-100 text-amber-800 border border-amber-300'
                        }`}>
                          {vio.severity === 'high' || vio.severity === 'critical' ? 'عالية الخطورة' : 'متوسطة الخطورة'}
                        </span>
                      </td>
                      <td className="py-2 px-3 font-mono text-[11px] text-slate-600">
                        {vio.deadlineHours ? `${vio.deadlineHours} ساعة` : '48 ساعة'}
                      </td>
                      <td className="py-2 px-3 text-center">
                        <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200">
                          معلقة (0% معالجة)
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* 8. Three-Party Official Approvals & Stamp Section */}
          <div className="section pt-4 border-t-2 border-slate-800 mt-6">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-center text-xs">
              {/* 1. Field Inspector */}
              <div className="signature-box p-3 border border-slate-300 rounded-xl space-y-3 bg-slate-50 print-card">
                <span className="text-[11px] font-bold text-slate-500 block">المفتش والضابط الميداني</span>
                <div className="font-bold text-slate-900 text-xs">
                  م/ نجيب قاسم غازي
                </div>
                <div className="h-10 border-b border-dashed border-slate-400 flex items-end justify-center pb-1">
                  <span className="text-[10px] text-slate-400 font-mono">التوقيع الإلكتروني المعتمد ✓</span>
                </div>
                <span className="text-[10px] text-slate-500 block">مفتش السلامة الميداني</span>
              </div>

              {/* 2. Head of Safety & FMS */}
              <div className="signature-box p-3 border-2 border-teal-700 rounded-xl space-y-3 bg-teal-50/40 print-card">
                <span className="text-[11px] font-bold text-teal-800 block">رئيس قسم الأمن والسلامة وإدارة المرافق (FMS)</span>
                <div className="font-black text-teal-950 text-sm">
                  م/ نجيب قاسم غازي
                </div>
                <div className="h-10 border-b border-dashed border-teal-700 flex items-end justify-center pb-1">
                  <span className="text-[10px] text-teal-800 font-bold font-mono">مُعتمد ومصادق عليه إلكترونياً ✓</span>
                </div>
                <span className="text-[10px] text-teal-800 font-bold block">إدارة الأمن والسلامة FMS</span>
              </div>

              {/* 3. General Manager with Hospital Stamp */}
              <div className="signature-box p-3 border border-slate-300 rounded-xl space-y-2 bg-slate-50 print-card">
                <span className="text-[11px] font-bold text-slate-500 block">المدير العام للمستشفى</span>
                <div className="font-bold text-slate-900 text-xs">
                  د/ محمد السراجي
                </div>
                <div className="w-24 h-14 mx-auto border-2 border-dashed border-teal-600 rounded-full flex flex-col items-center justify-center text-[9px] text-teal-800 font-bold bg-white shadow-inner my-1">
                  <span>مستشفى آزال النموذجي</span>
                  <span className="text-[8px] text-slate-600">الختم الرسمي للمستشفى</span>
                </div>
                <span className="text-[10px] text-slate-500 block">الاعتماد النهائي والتوجيه</span>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-200 text-center text-[10px] text-slate-500 font-mono">
              نظام مستشفى آزال النموذجي لإدارة السلامة FMS • وثيقة رسمية صادرة برقم مرجعي معتمد • صنعاء، الجمهورية اليمنية
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DailySafetyReadinessPrintReport;
