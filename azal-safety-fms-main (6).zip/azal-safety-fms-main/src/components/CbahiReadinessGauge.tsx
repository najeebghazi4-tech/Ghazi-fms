import React from 'react';
import { Award, ShieldCheck, AlertTriangle, FileText, CheckCircle2 } from 'lucide-react';
import { CbahiStandardItem } from '../types';

interface CbahiReadinessGaugeProps {
  standards: CbahiStandardItem[];
  onOpenPortfolioPrint: () => void;
  onSelectStandardCategory?: (category: string) => void;
}

export const CbahiReadinessGauge: React.FC<CbahiReadinessGaugeProps> = ({
  standards,
  onOpenPortfolioPrint,
  onSelectStandardCategory,
}) => {
  const total = standards.length;
  const avgCompliance = total > 0
    ? Math.round(standards.reduce((sum, s) => sum + s.complianceRate, 0) / total)
    : 95;

  const esrStandards = standards.filter(s => s.esr);
  const totalEsr = esrStandards.length;
  const esrCompliant = esrStandards.filter(s => s.complianceRate >= 90).length;
  const fullyCompliantCount = standards.filter(s => s.complianceRate >= 95).length;
  const partiallyCompliantCount = standards.filter(s => s.complianceRate < 95 && s.complianceRate >= 80).length;

  // Group by category
  const categories = Array.from(new Set(standards.map(s => s.category)));
  const categoryStats = categories.map(cat => {
    const catStds = standards.filter(s => s.category === cat);
    const catAvg = Math.round(catStds.reduce((sum, s) => sum + s.complianceRate, 0) / catStds.length);
    return { name: cat, count: catStds.length, avg: catAvg };
  });

  // Calculate SVG Circle values
  const radius = 64;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (avgCompliance / 100) * circumference;

  return (
    <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-teal-950 text-white rounded-2xl p-4 sm:p-6 shadow-xl border border-teal-800/40 relative overflow-hidden">
      {/* Subtle background glow */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-60 h-60 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

      <div className="relative z-10">
        {/* Header Bar */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-4 border-b border-slate-700/60">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-teal-500/20 border border-teal-400/40 flex items-center justify-center text-teal-300 shadow-inner">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-teal-400 uppercase tracking-wider">CBAHI 3rd Edition</span>
                <span className="bg-emerald-500/20 text-emerald-300 text-[11px] px-2 py-0.5 rounded-full font-semibold border border-emerald-500/30">
                  جاهزية الاعتماد الوطني
                </span>
              </div>
              <h2 className="text-lg sm:text-xl font-black text-white mt-0.5">
                مؤشر الامتثال والجاهزية لمعايير سباهي (39 معيار FMS)
              </h2>
            </div>
          </div>

          <button
            onClick={onOpenPortfolioPrint}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-gradient-to-r from-teal-500 to-emerald-600 hover:from-teal-600 hover:to-emerald-700 text-white px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm shadow-lg shadow-teal-900/40 hover:shadow-teal-900/60 transition-all cursor-pointer"
          >
            <FileText className="w-4 h-4" />
            <span>طباعة وتصدير المحفظة التوثيقية الشاملة PDF</span>
          </button>
        </div>

        {/* Main Gauge and Metrics */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center mt-5">
          {/* Radial Circular Gauge */}
          <div className="lg:col-span-4 flex flex-col items-center justify-center p-3 bg-slate-800/40 rounded-xl border border-slate-700/50">
            <div className="relative flex items-center justify-center">
              <svg className="w-40 h-40 transform -rotate-90" viewBox="0 0 160 160">
                {/* Background Track */}
                <circle
                  cx="80"
                  cy="80"
                  r={radius}
                  stroke="#334155"
                  strokeWidth="14"
                  fill="transparent"
                />
                {/* Animated Progress Track */}
                <circle
                  cx="80"
                  cy="80"
                  r={radius}
                  stroke="url(#cbahiGaugeGradient)"
                  strokeWidth="14"
                  fill="transparent"
                  strokeDasharray={circumference}
                  strokeDashoffset={strokeDashoffset}
                  strokeLinecap="round"
                  className="transition-all duration-1000 ease-out"
                />
                <defs>
                  <linearGradient id="cbahiGaugeGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#14b8a6" />
                    <stop offset="50%" stopColor="#10b981" />
                    <stop offset="100%" stopColor="#059669" />
                  </linearGradient>
                </defs>
              </svg>

              <div className="absolute text-center">
                <span className="text-3xl sm:text-4xl font-black tracking-tight text-white block">
                  {avgCompliance}%
                </span>
                <span className="text-[11px] font-bold text-emerald-400 block -mt-1">
                  امتثال كلي ممتاز
                </span>
              </div>
            </div>

            <div className="mt-3 text-center">
              <p className="text-xs text-slate-300 font-medium">
                تم استيفاء <strong className="text-teal-300">{fullyCompliantCount}</strong> من أصل <strong className="text-teal-300">{total}</strong> معياراً بنسبة تفوق 95%
              </p>
            </div>
          </div>

          {/* Core Stat Cards */}
          <div className="lg:col-span-8 grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div className="bg-slate-800/60 border border-slate-700/80 rounded-xl p-3.5 hover:border-teal-500/40 transition-colors">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400 font-medium">إجمالي المعايير</span>
                <span className="text-teal-400 text-xs font-bold">FMS</span>
              </div>
              <div className="mt-2 flex items-baseline gap-2">
                <span className="text-2xl font-black text-white">{total}</span>
                <span className="text-xs text-slate-400">معياراً معتمداً</span>
              </div>
              <div className="mt-2 text-[11px] text-teal-400 font-medium flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>شاملة لكافة الأقسام</span>
              </div>
            </div>

            <div className="bg-slate-800/60 border border-rose-800/40 rounded-xl p-3.5 hover:border-rose-500/50 transition-colors">
              <div className="flex items-center justify-between">
                <span className="text-xs text-rose-300 font-medium">معايير الأمان الحرجة</span>
                <span className="bg-rose-500/20 text-rose-300 text-[10px] font-bold px-1.5 py-0.5 rounded">ESR</span>
              </div>
              <div className="mt-2 flex items-baseline gap-2">
                <span className="text-2xl font-black text-rose-400">{esrCompliant}/{totalEsr}</span>
                <span className="text-xs text-slate-400">مطابقة تامة</span>
              </div>
              <div className="mt-2 text-[11px] text-rose-300 font-medium flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>صفر انحراف حرج</span>
              </div>
            </div>

            <div className="bg-slate-800/60 border border-slate-700/80 rounded-xl p-3.5 hover:border-emerald-500/40 transition-colors">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400 font-medium">السجلات المركزية</span>
                <span className="text-emerald-400 text-xs font-bold">4 بوابات</span>
              </div>
              <div className="mt-2 flex items-baseline gap-2">
                <span className="text-2xl font-black text-emerald-400">100%</span>
                <span className="text-xs text-slate-400">ربط رقمي</span>
              </div>
              <div className="mt-2 text-[11px] text-emerald-300 font-medium flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>تحديث فوري ومستمر</span>
              </div>
            </div>

            <div className="bg-slate-800/60 border border-slate-700/80 rounded-xl p-3.5 col-span-2 sm:col-span-3">
              <span className="text-xs text-slate-300 font-bold block mb-2">
                نسب الامتثال حسب مجالات السلامة الثمانية (Safety Programs):
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {categoryStats.map(cat => (
                  <button
                    key={cat.name}
                    onClick={() => onSelectStandardCategory && onSelectStandardCategory(cat.name)}
                    className="p-2 rounded-lg bg-slate-900/60 border border-slate-700/60 hover:border-teal-500/60 text-right transition-all cursor-pointer"
                  >
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-slate-300 font-semibold truncate max-w-[110px]" title={cat.name}>{cat.name}</span>
                      <span className={`font-black ${cat.avg >= 95 ? 'text-emerald-400' : 'text-teal-400'}`}>{cat.avg}%</span>
                    </div>
                    <div className="w-full bg-slate-700/50 h-1.5 rounded-full mt-1.5 overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          cat.avg >= 95 ? 'bg-emerald-500' : 'bg-teal-500'
                        }`}
                        style={{ width: `${cat.avg}%` }}
                      />
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
