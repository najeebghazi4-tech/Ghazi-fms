import React, { useState } from 'react';
import { X, UserPlus, ShieldAlert, Heart, Activity, AlertCircle } from 'lucide-react';
import { ISBARData } from '../types';

interface AddPatientModalProps {
  onClose: () => void;
  onAddPatient: (newPatient: ISBARData) => void;
}

export const AddPatientModal: React.FC<AddPatientModalProps> = ({
  onClose,
  onAddPatient,
}) => {
  const [fullName, setFullName] = useState('');
  const [mrn, setMrn] = useState(`MRN-${Math.floor(10000 + Math.random() * 90000)}`);
  const [bedNumber, setBedNumber] = useState('ICU-Bed-08');
  const [department, setDepartment] = useState('العناية المركزة');
  const [age, setAge] = useState(45);
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [attendingPhysician, setAttendingPhysician] = useState('د. غازي نجيب');
  const [primaryDiagnosis, setPrimaryDiagnosis] = useState('');
  const [acuity, setAcuity] = useState<'critical' | 'guard' | 'stable'>('guard');
  const [allergiesText, setAllergiesText] = useState('لا توجد حساسيات معروفة (NKDA)');
  const [bpSystolic, setBpSystolic] = useState(120);
  const [bpDiastolic, setBpDiastolic] = useState(80);
  const [heartRate, setHeartRate] = useState(78);
  const [oxygenSat, setOxygenSat] = useState(98);
  const [temperature, setTemperature] = useState(37.0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim() || !primaryDiagnosis.trim()) return;

    const allergies = allergiesText
      .split('،')
      .map((s) => s.trim())
      .filter(Boolean);

    const newPatient: ISBARData = {
      patientId: `pat-${Date.now()}`,
      fullName: fullName.trim(),
      fullNameEn: fullName.trim(),
      mrn: mrn.trim(),
      nationalId: `1${Math.floor(100000000 + Math.random() * 900000000)}`,
      bedNumber: bedNumber.trim(),
      department,
      age,
      gender,
      attendingPhysician,
      admissionDate: new Date().toISOString().split('T')[0],
      primaryDiagnosis: primaryDiagnosis.trim(),
      primaryDiagnosisEn: primaryDiagnosis.trim(),
      acuity,
      codeStatus: 'full_code',
      isolation: 'none',
      fallRiskScore: 'moderate',
      currentConditionSummary: 'مريض جديد تم تنويمه بالقسم حديثاً، تم أخذ العلامات الأولية وفحص سلامة التنويم.',
      allergies,
      medicalHistory: ['قيد التوثيق السريري'],
      surgicalHistory: ['لا يوجد'],
      currentDiet: 'حمية عادية خفيفة',
      vitals: {
        recordedAt: 'الآن (تنويم جديد)',
        bpSystolic,
        bpDiastolic,
        heartRate,
        respRate: 18,
        oxygenSat,
        temperature,
        painScore: 2,
        gcs: 15,
        bloodSugar: 110,
      },
      invasiveLines: [
        {
          id: `line-${Date.now()}`,
          type: 'IV Cannula',
          typeAr: 'كانيولا وريدية طرفية 20G',
          location: 'الساعد الأيمن',
          insertedDate: new Date().toISOString().split('T')[0],
          status: 'clean',
        },
      ],
      neurologicalStatus: 'alert',
      respiratorySupport: 'room_air',
      intakeOutputBalance: 'بدء التسجيل مع الوردية',
      pendingTasks: [
        {
          id: `task-${Date.now()}-1`,
          text: 'إكمال ملف التقييم التمريضي الأولي وسحب تحاليل الدخول CBC & Chemistry',
          urgency: 'high',
          category: 'lab',
          isCompleted: false,
        },
      ],
      criticalAlertNotes: 'مريض جديد: التحقق من سوار المعصم ومطابقة الأدوية المنزلية.',
      dischargePlan: 'تنويم عادي قيد التقييم اليومي.',
    };

    onAddPatient(newPatient);
    onClose();
  };

  return (
    <div id="add-patient-modal" className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 text-right">
      <div className="bg-slate-900 border border-teal-600/70 rounded-2xl w-full max-w-xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-teal-950 border border-teal-800 text-teal-400">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100">إدخال وتنويم مريض جديد في الجناح</h3>
              <p className="text-[11px] text-slate-400">إنشاء سجل ISBAR سريري أولي وتخصيص السرير</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-100"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 space-y-3 overflow-y-auto text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-slate-300 block mb-1 font-semibold">اسم المريض الرباعي:</label>
              <input
                type="text"
                required
                placeholder="مثال: خالد بن سلطان المطيري"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-slate-100 placeholder-slate-500"
              />
            </div>

            <div>
              <label className="text-slate-300 block mb-1 font-semibold">رقم الملف الطبي (MRN):</label>
              <input
                type="text"
                required
                value={mrn}
                onChange={(e) => setMrn(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-slate-100 font-mono"
              />
            </div>

            <div>
              <label className="text-slate-300 block mb-1 font-semibold">رقم السرير / الغرفة:</label>
              <input
                type="text"
                required
                placeholder="مثال: Bed-06"
                value={bedNumber}
                onChange={(e) => setBedNumber(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-slate-100 font-mono"
              />
            </div>

            <div>
              <label className="text-slate-300 block mb-1 font-semibold">القسم:</label>
              <select
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-slate-100"
              >
                <option value="العناية المركزة">العناية المركزة (ICU)</option>
                <option value="قسم الجراحة العامة">قسم الجراحة العامة</option>
                <option value="قسم الباطنية">قسم الباطنية</option>
                <option value="قسم الطوارئ والإسعاف">قسم الطوارئ والإسعاف</option>
                <option value="قسم القلب">قسم القلب (CCU)</option>
              </select>
            </div>

            <div>
              <label className="text-slate-300 block mb-1 font-semibold">العمر والجنس:</label>
              <div className="flex gap-2">
                <input
                  type="number"
                  min="1"
                  max="120"
                  value={age}
                  onChange={(e) => setAge(Number(e.target.value))}
                  className="w-20 bg-slate-950 border border-slate-700 rounded-lg p-2 text-center text-slate-100"
                />
                <select
                  value={gender}
                  onChange={(e) => setGender(e.target.value as any)}
                  className="flex-1 bg-slate-950 border border-slate-700 rounded-lg p-2 text-slate-100"
                >
                  <option value="male">ذكر</option>
                  <option value="female">أنثى</option>
                </select>
              </div>
            </div>

            <div>
              <label className="text-slate-300 block mb-1 font-semibold">الطبيب الاستشاري المسؤول:</label>
              <input
                type="text"
                value={attendingPhysician}
                onChange={(e) => setAttendingPhysician(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-slate-100"
              />
            </div>
          </div>

          <div>
            <label className="text-slate-300 block mb-1 font-semibold">التشخيص الطبي الأولي للدخول:</label>
            <textarea
              rows={2}
              required
              placeholder="مثال: التهاب حاد في الزائدة الدودية مع ارتفاع في كريات الدم البيضاء..."
              value={primaryDiagnosis}
              onChange={(e) => setPrimaryDiagnosis(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-slate-100 placeholder-slate-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-slate-300 block mb-1 font-semibold">مستوى الخطورة السريرية (Acuity):</label>
              <select
                value={acuity}
                onChange={(e) => setAcuity(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-slate-100 font-bold"
              >
                <option value="critical">أحمر (حرج - Acuity 1)</option>
                <option value="guard">برتقالي (مراقبة - Acuity 2)</option>
                <option value="stable">أخضر (مستقر - Acuity 3)</option>
              </select>
            </div>

            <div>
              <label className="text-slate-300 block mb-1 font-semibold">الحساسيات (افصل بفاصلة عربية ،):</label>
              <input
                type="text"
                value={allergiesText}
                onChange={(e) => setAllergiesText(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-slate-100"
              />
            </div>
          </div>

          {/* Initial Vitals Row */}
          <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800 space-y-2">
            <span className="font-bold text-teal-400 block">العلامات الحيوية الأولية عند الدخول:</span>
            <div className="grid grid-cols-4 gap-2 text-center">
              <div>
                <label className="text-[10px] text-slate-400 block">BP (SYS/DIA)</label>
                <div className="flex gap-1 font-mono">
                  <input
                    type="number"
                    value={bpSystolic}
                    onChange={(e) => setBpSystolic(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-1 text-center text-xs"
                  />
                  <input
                    type="number"
                    value={bpDiastolic}
                    onChange={(e) => setBpDiastolic(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-1 text-center text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] text-slate-400 block">HR (نبض)</label>
                <input
                  type="number"
                  value={heartRate}
                  onChange={(e) => setHeartRate(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded p-1 text-center text-xs font-mono"
                />
              </div>

              <div>
                <label className="text-[10px] text-slate-400 block">SpO2 %</label>
                <input
                  type="number"
                  value={oxygenSat}
                  onChange={(e) => setOxygenSat(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded p-1 text-center text-xs font-mono"
                />
              </div>

              <div>
                <label className="text-[10px] text-slate-400 block">Temp °C</label>
                <input
                  type="number"
                  step="0.1"
                  value={temperature}
                  onChange={(e) => setTemperature(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded p-1 text-center text-xs font-mono"
                />
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-slate-400 hover:text-slate-200 bg-slate-800 font-medium"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold shadow-lg shadow-teal-950"
            >
              حفظ وتنويم المريض
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
