import React, { useState, useEffect } from 'react';
import { 
  Lock, 
  Fingerprint, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  ShieldAlert, 
  ArrowLeft, 
  Building2, 
  Flame, 
  FlaskConical, 
  FileCheck,
  Wrench
} from 'lucide-react';
import { StaffUser } from '../types';
import { AzalLogo } from './AzalLogo';

interface LockScreenProps {
  staffList?: StaffUser[];
  currentUser?: StaffUser;
  onUnlock: (user: StaffUser) => void;
  onEmergencyAccess?: (reason: string) => void;
  onNavigateToExecutive?: () => void;
  onOpenPublicPortal?: (portal: string) => void;
}

export const LockScreen: React.FC<LockScreenProps> = ({
  currentUser,
  staffList,
  onUnlock,
  onEmergencyAccess,
  onNavigateToExecutive,
  onOpenPublicPortal,
}) => {
  const [pin, setPin] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [showEmergencyModal, setShowEmergencyModal] = useState(false);
  const [emergencyReason, setEmergencyReason] = useState('');
  const [failedAttempts, setFailedAttempts] = useState<number>(() => {
    try {
      return Number(sessionStorage.getItem('azal_failed_attempts') || '0');
    } catch {
      return 0;
    }
  });
  const [cooldownSeconds, setCooldownSeconds] = useState<number>(() => {
    try {
      const until = Number(sessionStorage.getItem('azal_lockout_until') || '0');
      const remaining = Math.ceil((until - Date.now()) / 1000);
      return remaining > 0 ? remaining : 0;
    } catch {
      return 0;
    }
  });

  // Countdown timer for brute-force prevention (Locks for 60 seconds after 5 failed attempts)
  useEffect(() => {
    if (cooldownSeconds <= 0) {
      try {
        sessionStorage.removeItem('azal_lockout_until');
      } catch {}
      return;
    }
    const timer = setInterval(() => {
      setCooldownSeconds((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setFailedAttempts(0);
          try {
            sessionStorage.removeItem('azal_failed_attempts');
            sessionStorage.removeItem('azal_lockout_until');
          } catch {}
          setErrorMsg('');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [cooldownSeconds]);

  const handleDigit = (digit: string) => {
    if (cooldownSeconds > 0) return;
    if (pin.length < 4) {
      const newPin = pin + digit;
      setPin(newPin);
      setErrorMsg('');
      if (newPin.length === 4) {
        verifyPin(newPin);
      }
    }
  };

  const handleBackspace = () => {
    if (cooldownSeconds > 0) return;
    setPin((prev) => prev.slice(0, -1));
    setErrorMsg('');
  };

  const handleClear = () => {
    if (cooldownSeconds > 0) return;
    setPin('');
    setErrorMsg('');
  };

  const verifyPin = (pinToTest: string) => {
    if (cooldownSeconds > 0) return;

    // 1. PIN 1234: دخول الإدارة العامة (المدير العام د/ محمد السراجي)
    if (pinToTest === '1234') {
      setErrorMsg('');
      setFailedAttempts(0);
      try {
        sessionStorage.removeItem('azal_failed_attempts');
        sessionStorage.removeItem('azal_lockout_until');
      } catch {}
      const gmUser: StaffUser = {
        id: 'DIR-01',
        name: 'د/ محمد السراجي',
        nameEn: 'Dr. Mohammed Al-Saraji',
        role: 'general_director',
        roleTitleAr: 'مدير عام المستشفى',
        badgeNumber: 'AZAL-GM-01',
        department: 'الإدارة العامة',
        pin: '1234',
        avatarColor: 'bg-emerald-700',
      };
      onUnlock(gmUser);
      return;
    }

    // 2. PIN 7777: دخول رئيس السلامة والمرافق (م/ نجيب قاسم غازي)
    if (pinToTest === '7777') {
      setErrorMsg('');
      setFailedAttempts(0);
      try {
        sessionStorage.removeItem('azal_failed_attempts');
        sessionStorage.removeItem('azal_lockout_until');
      } catch {}
      const safetyHeadUser: StaffUser = {
        id: 'SAFETY-01',
        name: 'م/ نجيب قاسم غازي',
        nameEn: 'Eng. Najib Qasem Ghazi',
        role: 'safety_head',
        roleTitleAr: 'رئيس قسم السلامة وإدارة المرافق (FMS)',
        badgeNumber: 'AZAL-FMS-01',
        department: 'إدارة الأمن والسلامة والصحة المهنية',
        pin: '7777',
        avatarColor: 'bg-teal-600',
      };
      onUnlock(safetyHeadUser);
      return;
    }

    // 3. PIN 1122: دخول فني صيانة المرافق والخدمات (USM)
    if (pinToTest === '1122') {
      setErrorMsg('');
      setFailedAttempts(0);
      try {
        sessionStorage.removeItem('azal_failed_attempts');
        sessionStorage.removeItem('azal_lockout_until');
      } catch {}
      const usmTechUser: StaffUser = {
        id: 'USM-01',
        name: 'فني صيانة المرافق والخدمات',
        nameEn: 'USM Utility Technician',
        role: 'usm_tech',
        roleTitleAr: 'فني صيانة المرافق والخدمات (USM)',
        badgeNumber: 'AZAL-USM-01',
        department: 'قسم صيانة المرافق العامة والتشغيل (USM)',
        pin: '1122',
        avatarColor: 'bg-amber-700',
      };
      onUnlock(usmTechUser);
      return;
    }

    // 4. PIN 3344: دخول مهندس الأجهزة الطبية (MEM)
    if (pinToTest === '3344') {
      setErrorMsg('');
      setFailedAttempts(0);
      try {
        sessionStorage.removeItem('azal_failed_attempts');
        sessionStorage.removeItem('azal_lockout_until');
      } catch {}
      const memEngineerUser: StaffUser = {
        id: 'MEM-01',
        name: 'مهندس الأجهزة والمعدات الطبية',
        nameEn: 'MEM Biomedical Engineer',
        role: 'mem_engineer',
        roleTitleAr: 'مهندس الأجهزة الطبية (MEM)',
        badgeNumber: 'AZAL-MEM-01',
        department: 'قسم الهندسة الطبية الحيوية والأجهزة (MEM)',
        pin: '3344',
        avatarColor: 'bg-blue-700',
      };
      onUnlock(memEngineerUser);
      return;
    }

    // 5. PIN 5678: د/ علي الظبيبي (منسق الجودة والاعتماد CBAHI)
    if (pinToTest === '5678') {
      setErrorMsg('');
      setFailedAttempts(0);
      try {
        sessionStorage.removeItem('azal_failed_attempts');
        sessionStorage.removeItem('azal_lockout_until');
      } catch {}
      const qualityCoordinatorUser: StaffUser = {
        id: 'QA-01',
        name: 'د/ علي الظبيبي',
        nameEn: 'Dr. Ali Al-Dhabibi',
        role: 'quality_head',
        roleTitleAr: 'منسق الجودة والاعتماد (CBAHI)',
        badgeNumber: 'AZAL-QA-01',
        department: 'إدارة الجودة وتطوير الأداء',
        pin: '5678',
        avatarColor: 'bg-sky-700',
      };
      onUnlock(qualityCoordinatorUser);
      return;
    }

    // 6. PIN 8888: بوابة المتابعة الرقابية للإدارة العامة (د/ محمد السراجي)
    if (pinToTest === '8888') {
      setErrorMsg('');
      setFailedAttempts(0);
      try {
        sessionStorage.removeItem('azal_failed_attempts');
        sessionStorage.removeItem('azal_lockout_until');
      } catch {}
      const gmUser: StaffUser = {
        id: 'GM-01',
        name: 'د/ محمد السراجي',
        nameEn: 'Dr. Mohammed Al-Saraji',
        role: 'general_director',
        roleTitleAr: 'مدير عام المستشفى',
        badgeNumber: 'AZAL-GM-01',
        department: 'الإدارة العامة',
        pin: '8888',
        avatarColor: 'bg-amber-600',
      };
      if (typeof window !== 'undefined') {
        sessionStorage.setItem('azal_gm_unlocked', 'true');
        window.location.hash = 'executive';
      }
      if (onNavigateToExecutive) {
        onNavigateToExecutive();
      } else {
        onUnlock(gmUser);
      }
      return;
    }

    // 7. Match current user or staff list PIN
    const matchedStaff = staffList?.find((u) => u.pin === pinToTest);
    if (matchedStaff) {
      setErrorMsg('');
      setFailedAttempts(0);
      try {
        sessionStorage.removeItem('azal_failed_attempts');
        sessionStorage.removeItem('azal_lockout_until');
      } catch {}
      onUnlock(matchedStaff);
      return;
    }

    if (currentUser && currentUser.pin === pinToTest) {
      setErrorMsg('');
      setFailedAttempts(0);
      try {
        sessionStorage.removeItem('azal_failed_attempts');
        sessionStorage.removeItem('azal_lockout_until');
      } catch {}
      onUnlock(currentUser);
      return;
    }

    // Wrong PIN Handling & Brute-Force lockout after 5 failed attempts
    const nextAttempts = failedAttempts + 1;
    setFailedAttempts(nextAttempts);
    try {
      sessionStorage.setItem('azal_failed_attempts', nextAttempts.toString());
    } catch {}

    if (typeof window !== 'undefined' && window.navigator && window.navigator.vibrate) {
      try {
        window.navigator.vibrate([100, 50, 100]);
      } catch {}
    }

    if (nextAttempts >= 5) {
      const lockUntil = Date.now() + 60000;
      try {
        sessionStorage.setItem('azal_lockout_until', lockUntil.toString());
      } catch {}
      setCooldownSeconds(60);
      setErrorMsg('تم إيقاف لوحة الإدخال مؤقتاً لمدة دقيقة (60 ثانية) لحماية النظام بعد 5 محاولات إدخال غير صحيحة.');
      setPin('');
    } else {
      setErrorMsg(`الرمز السري غير صحيح. المحاولة (${nextAttempts} من 5)`);
      setTimeout(() => setPin(''), 500);
    }
  };

  const handleEmergencySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emergencyReason.trim()) return;
    if (onEmergencyAccess) {
      onEmergencyAccess(emergencyReason);
    } else {
      const fallbackUser: StaffUser = currentUser || {
        id: 'SAFETY-01',
        name: 'م/ نجيب غازي',
        nameEn: 'Eng. Najib Ghazi',
        role: 'safety_head',
        roleTitleAr: 'رئيس قسم السلامة وإدارة المرافق (FMS)',
        badgeNumber: 'AZAL-FMS-01',
        department: 'إدارة الأمن والسلامة والصحة المهنية',
        pin: '7777',
        avatarColor: 'bg-teal-600',
      };
      onUnlock(fallbackUser);
    }
    setShowEmergencyModal(false);
  };

  const navigateToPublic = (portalHash: string) => {
    if (typeof window !== 'undefined') {
      window.location.hash = portalHash;
    }
    if (onOpenPublicPortal) {
      onOpenPublicPortal(portalHash.replace('#', ''));
    }
  };

  return (
    <div id="clinical-lock-screen" className="fixed inset-0 z-50 bg-slate-950/98 backdrop-blur-2xl flex flex-col justify-between p-4 sm:p-6 overflow-y-auto" dir="rtl">
      {/* Top Header with Azal Model Hospital Emblem */}
      <div className="w-full max-w-sm mx-auto text-center pt-2 flex flex-col items-center">
        <div className="mb-2.5">
          <AzalLogo variant="horizontal" size="lg" />
        </div>
        <div className="inline-flex items-center gap-2 bg-emerald-950/90 border border-emerald-800/80 text-emerald-300 px-3.5 py-1 rounded-full text-xs font-semibold mb-1 shadow-inner">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>مستشفى آزال • الرعاية الكاملة • إدارة السلامة FMS</span>
        </div>
        <h1 className="text-base font-bold text-slate-100 flex items-center justify-center gap-2">
          <Lock className="w-4 h-4 text-teal-400" />
          <span>بوابة المصادقة والدخول الإداري المحمي</span>
        </h1>
        <p className="text-[11px] text-slate-400 mt-0.5">
          يرجى إدخال رمز المرور السري المصرح لفتح لوحة التحكم
        </p>
      </div>

      {/* Center: PIN Keypad */}
      <div className="w-full max-w-xs mx-auto flex flex-col items-center my-auto py-2">
        {/* Cooldown Timer Banner */}
        {cooldownSeconds > 0 && (
          <div className="w-full p-2.5 bg-rose-950/80 border border-rose-700 rounded-xl text-center mb-2 animate-pulse">
            <span className="text-xs font-bold text-rose-300 block">
              ⚠️ لوحة الإدخال مجمدة مؤقتاً
            </span>
            <span className="text-[11px] text-rose-200 mt-0.5 block font-mono font-bold">
              يرجى الانتظار: {cooldownSeconds} ثانية
            </span>
          </div>
        )}

        {/* PIN 4-Dots Display */}
        <div className="flex items-center justify-center gap-4 my-2">
          {[0, 1, 2, 3].map((index) => {
            const isFilled = pin.length > index;
            return (
              <div
                key={index}
                className={`w-4 h-4 rounded-full transition-all duration-200 ${
                  isFilled
                    ? 'bg-teal-400 scale-110 shadow-lg shadow-teal-500/50'
                    : 'border-2 border-slate-700 bg-slate-900'
                }`}
              />
            );
          })}
        </div>

        {errorMsg && cooldownSeconds === 0 && (
          <div className="text-xs text-rose-400 font-medium mb-2 animate-shake text-center">
            {errorMsg}
          </div>
        )}

        {/* PIN Keypad */}
        <div className="grid grid-cols-3 gap-2.5 w-full max-w-[250px] my-1">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
            <button
              key={digit}
              type="button"
              disabled={cooldownSeconds > 0}
              onClick={() => handleDigit(digit)}
              className={`h-12 rounded-xl border text-xl font-mono font-bold flex items-center justify-center transition-all shadow-sm active:scale-95 cursor-pointer ${
                cooldownSeconds > 0
                  ? 'bg-slate-900/40 text-slate-600 border-slate-850 cursor-not-allowed'
                  : 'bg-slate-900 hover:bg-slate-800 active:bg-teal-950 active:text-teal-300 border-slate-800 text-slate-100'
              }`}
            >
              {digit}
            </button>
          ))}
          <button
            type="button"
            disabled={cooldownSeconds > 0}
            onClick={handleClear}
            className="h-12 rounded-xl bg-slate-900/40 hover:bg-slate-800/70 border border-slate-800/60 text-xs font-semibold text-slate-400 flex items-center justify-center transition-all cursor-pointer"
          >
            مسح
          </button>
          <button
            type="button"
            disabled={cooldownSeconds > 0}
            onClick={() => handleDigit('0')}
            className={`h-12 rounded-xl border text-xl font-mono font-bold flex items-center justify-center transition-all shadow-sm active:scale-95 cursor-pointer ${
              cooldownSeconds > 0
                ? 'bg-slate-900/40 text-slate-600 border-slate-850 cursor-not-allowed'
                : 'bg-slate-900 hover:bg-slate-800 active:bg-teal-950 active:text-teal-300 border-slate-800 text-slate-100'
            }`}
          >
            0
          </button>
          <button
            type="button"
            disabled={cooldownSeconds > 0}
            onClick={handleBackspace}
            className="h-12 rounded-xl bg-slate-900/40 hover:bg-slate-800/70 border border-slate-800/60 text-xs font-semibold text-slate-400 flex items-center justify-center transition-all cursor-pointer"
          >
            حذف ⌫
          </button>
        </div>
      </div>

      {/* Bottom Section: Public Unlocked Portals Links */}
      <div className="w-full max-w-sm mx-auto text-center pt-2 border-t border-slate-800 space-y-2">
        <div className="text-[11px] font-bold text-slate-400">
          البوابات العامة المفتوحة (المرجع الحصري):
        </div>

        <div className="grid grid-cols-2 gap-2 text-right">
          <button
            type="button"
            onClick={() => navigateToPublic('#services')}
            className="p-2.5 rounded-xl bg-gradient-to-r from-teal-950/80 to-slate-900 hover:from-teal-900/80 hover:to-slate-850 border border-teal-600/60 hover:border-teal-400 text-teal-300 text-xs font-bold flex items-center justify-center gap-2 transition cursor-pointer shadow-md col-span-2"
          >
            <Building2 className="w-4 h-4 text-teal-400 shrink-0" />
            <span>بوابة الخدمات والتصاريح الموحدة (#services)</span>
          </button>

          <button
            type="button"
            onClick={() => navigateToPublic('#report')}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-rose-500/50 text-slate-300 text-[11px] font-bold flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <ShieldAlert className="w-3.5 h-3.5 text-rose-400 shrink-0" />
            <span className="truncate">تقديم بلاغ خطر عاجل</span>
          </button>

          <button
            type="button"
            onClick={() => navigateToPublic('#director')}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-amber-500/50 text-amber-300/90 text-[11px] font-bold flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="truncate">بوابة الإدارة العامة</span>
          </button>
          <button
            type="button"
            onClick={() => navigateToPublic('#guidelines')}
            className="p-2 rounded-xl bg-gradient-to-r from-amber-950/70 via-slate-900 to-slate-900 hover:from-amber-900/80 hover:to-slate-800 border border-amber-600/50 hover:border-amber-400 text-amber-300 text-[11px] font-bold flex items-center justify-center gap-1.5 transition cursor-pointer col-span-2 shadow-sm"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0 animate-pulse" />
            <span>إرشادات وتحذيرات السلامة العامة والطوارئ (#guidelines) ⚠️</span>
          </button>
        </div>

        {/* Emergency Code Blue Button */}
        <div className="pt-1">
          <button
            id="btn-open-emergency-access"
            type="button"
            onClick={() => setShowEmergencyModal(true)}
            className="text-[11px] text-rose-400 hover:text-rose-300 flex items-center justify-center gap-1 mx-auto font-semibold cursor-pointer"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-rose-500" />
            <span>دخول طوارئ إسعافي (Code Blue Override)</span>
          </button>
        </div>
      </div>

      {/* Emergency Code Blue Modal */}
      {showEmergencyModal && (
        <div className="fixed inset-0 z-60 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-rose-600/60 rounded-2xl p-5 max-w-md w-full shadow-2xl text-right">
            <div className="flex items-center gap-2 text-rose-400 mb-2 font-bold text-base">
              <AlertTriangle className="w-5 h-5 text-rose-500" />
              <span>تفعيل بروتوكول الدخول الإسعافي الطارئ</span>
            </div>
            <p className="text-xs text-slate-300 mb-3 leading-relaxed">
              وفقاً للوائح سلامة المرضى، يسمح بالدخول المباشر بدون رمز سري في حالات الإنعاش أو النداء الأزرق (Code Blue)، ويتم توثيق سبب الدخول ورقم الجهاز فوراً في سجل التحقيق الجنائي الطبي.
            </p>
            <form onSubmit={handleEmergencySubmit}>
              <label className="text-xs font-semibold text-slate-200 block mb-1">
                سبب الدخول الطارئ (إلزامي للتوثيق):
              </label>
              <textarea
                value={emergencyReason}
                onChange={(e) => setEmergencyReason(e.target.value)}
                placeholder="مثال: استدعاء طارئ لفريق الإنعاش وحالة حرجة"
                rows={3}
                required
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-rose-500 mb-4"
              />
              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowEmergencyModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-slate-200 bg-slate-800 cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white shadow-lg shadow-rose-950 cursor-pointer"
                >
                  تأكيد الدخول وتوثيق الحالة
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export const SecurityLockScreen = LockScreen;
export default LockScreen;
