import React, { useState } from 'react';
import { 
  Smartphone, 
  Download, 
  X, 
  Monitor, 
  CheckCircle2, 
  Share2, 
  PlusSquare, 
  HelpCircle,
  ShieldCheck,
  Copy,
  Check,
  QrCode,
  MessageSquare,
  ExternalLink
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { 
  cleanYemeniPhoneNumber, 
  getNativeSMSUri, 
  openNativeSMSDirect,
  getPublicAppBaseUrl 
} from '../utils/phoneUtils';

interface PWAInstallBannerProps {
  externalModalOpen?: boolean;
  onCloseExternalModal?: () => void;
}

export const PWAInstallBanner: React.FC<PWAInstallBannerProps> = ({
  externalModalOpen = false,
  onCloseExternalModal,
}) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [dismissed, setDismissed] = useState(false);
  const [internalShowGuideModal, setInternalShowGuideModal] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [smsPhone, setSmsPhone] = useState('');
  const [activePlatformTab, setActivePlatformTab] = useState<'android' | 'ios' | 'desktop'>(
    isIOS ? 'ios' : isAndroid ? 'android' : 'desktop'
  );

  const showGuideModal = externalModalOpen || internalShowGuideModal;
  const handleCloseModal = () => {
    setInternalShowGuideModal(false);
    if (onCloseExternalModal) {
      onCloseExternalModal();
    }
  };

  const getAppUrl = () => {
    return getPublicAppBaseUrl();
  };

  const appUrl = getAppUrl();

  const handleCopyLink = async () => {
    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(appUrl);
        setCopiedLink(true);
        setTimeout(() => setCopiedLink(false), 2500);
      }
    } catch {
      // Fallback if clipboard API blocked
    }
  };

  const handleSendAppUrlViaSMS = () => {
    const cleaned = cleanYemeniPhoneNumber(smsPhone || '967XXXXXXXXX');
    const msg = `مستشفى آزال النموذجي - إدارة الأمن والسلامة: رابط تثبيت التطبيق على هاتفك للعمل دون اتصال:\n${appUrl}`;
    openNativeSMSDirect(cleaned, msg);
  };

  const handleInstallClick = async () => {
    if (isInstallable) {
      const outcome = await install();
      if (!outcome) {
        setInternalShowGuideModal(true);
      }
    } else {
      setInternalShowGuideModal(true);
    }
  };

  return (
    <>
      {/* Persistent Ribbon Banner (if not dismissed) */}
      {!dismissed && (
        <div 
          id="pwa-install-banner" 
          className="bg-gradient-to-r from-teal-950 via-slate-900 to-slate-950 border-b border-teal-800/60 px-3 sm:px-4 py-2 text-xs flex items-center justify-between text-right text-slate-200 shadow-md select-none"
        >
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-xl bg-teal-600 text-white shadow-sm shrink-0">
              {isIOS || isAndroid ? <Smartphone className="w-4 h-4" /> : <Monitor className="w-4 h-4" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-teal-300 block">
                  {isInstalled ? 'نظام مستشفى آزال مُثبت كـ تطبيق' : 'تثبيت نظام مستشفى آزال على هاتفك (PWA)'}
                </span>
                {isInstalled ? (
                  <span className="inline-flex items-center gap-1 text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded-full font-bold">
                    <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                    <span>مُثبت ونشط</span>
                  </span>
                ) : (
                  <span className="text-[10px] bg-teal-900/80 text-teal-200 border border-teal-700 px-1.5 py-0.5 rounded font-bold hidden sm:inline-block">
                    أندرويد وآيفون
                  </span>
                )}
              </div>
              <span className="text-[11px] text-slate-400">
                يعمل دون إنترنت • شاشة كاملة • استجابة فورية بدون شريط المتصفح
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              id="pwa-install-action-btn"
              onClick={handleInstallClick}
              className="flex items-center gap-1.5 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-bold px-3.5 py-1.5 rounded-xl shadow-lg shadow-teal-950 transition active:scale-95 text-xs"
            >
              <Download className="w-3.5 h-3.5 animate-bounce" />
              <span>📲 تثبيت التطبيق على الهاتف</span>
            </button>

            <button
              type="button"
              onClick={() => setDismissed(true)}
              className="p-1 text-slate-400 hover:text-slate-200 rounded-lg hover:bg-slate-800 transition"
              title="إخفاء الشريط"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Comprehensive Mobile Installation Guide Modal */}
      {showGuideModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-3 sm:p-4 animate-in fade-in overflow-y-auto text-right">
          <div className="bg-slate-900 border border-teal-700/60 rounded-3xl max-w-lg w-full p-5 space-y-4 shadow-2xl my-auto max-h-[94vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-2xl bg-teal-600 text-white shadow-md shadow-teal-950">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-100">
                    تثبيت منظومة أمان مستشفى آزال النموذجي على هاتفك
                  </h4>
                  <p className="text-[11px] text-teal-300">
                    يعمل كتطبيق أصيل (Native PWA) دون إنترنت مع كامل الصلاحيات
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={handleCloseModal}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-200 bg-slate-800/80 hover:bg-slate-700 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* If the device already supports direct in-app install prompt */}
            {isInstallable && (
              <div className="bg-gradient-to-r from-emerald-950 to-teal-950 border border-emerald-700 p-3.5 rounded-2xl flex items-center justify-between gap-3">
                <div className="space-y-0.5">
                  <p className="font-bold text-emerald-300 text-xs">متصفحك جاهز للتثبيت الفوري الآن!</p>
                  <p className="text-[11px] text-slate-300">اضغط للتحميل المباشر إلى الشاشة الرئيسية بضغطة واحدة</p>
                </div>
                <button
                  type="button"
                  onClick={async () => {
                    await install();
                    handleCloseModal();
                  }}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-emerald-950 flex items-center gap-1.5 shrink-0 active:scale-95 transition"
                >
                  <Download className="w-4 h-4" />
                  <span>تثبيت الآن</span>
                </button>
              </div>
            )}

            {/* Quick Access QR Code & Link Sharing Section */}
            <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 space-y-3">
              <div className="flex flex-col sm:flex-row items-center gap-4">
                {/* QR Code Container */}
                <div className="bg-white p-2.5 rounded-2xl shrink-0 shadow-md flex flex-col items-center">
                  <img
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=140x140&margin=4&data=${encodeURIComponent(appUrl)}`}
                    alt="QR Code لمسح وتثبيت التطبيق على الهاتف"
                    className="w-28 h-28 object-contain"
                    onError={(e) => {
                      // Fallback SVG if offline
                      e.currentTarget.style.display = 'none';
                    }}
                  />
                  <span className="text-[9px] font-bold text-slate-800 mt-1">امسح بكاميرا الهاتف</span>
                </div>

                <div className="flex-1 space-y-2 text-xs w-full">
                  <p className="font-bold text-slate-200">افتح التطبيق على هاتفك عبر:</p>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    وجه كاميرا هاتفك نحو الرمز المربع (QR Code) على اليسار لفتح الرابط فوراً، أو انسخ الرابط وافتحه في متصفح الهاتف:
                  </p>

                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      readOnly
                      value={appUrl}
                      dir="ltr"
                      className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 text-[11px] font-mono text-slate-300 truncate"
                    />
                    <button
                      type="button"
                      onClick={handleCopyLink}
                      className="px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs flex items-center gap-1.5 shrink-0 transition"
                    >
                      {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedLink ? 'تم النسخ' : 'نسخ'}</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Send link directly to phone via SMS */}
              <div className="pt-2 border-t border-slate-800/80 flex flex-col sm:flex-row items-center gap-2 text-xs">
                <span className="text-slate-400 shrink-0 text-[11px] flex items-center gap-1">
                  <MessageSquare className="w-3.5 h-3.5 text-blue-400" />
                  <span>إرسال الرابط إلى هاتفي عبر SMS:</span>
                </span>
                <div className="flex items-center gap-1.5 w-full sm:w-auto flex-1">
                  <input
                    type="tel"
                    dir="ltr"
                    placeholder="7XXXXXXXX"
                    value={smsPhone}
                    onChange={(e) => setSmsPhone(e.target.value)}
                    className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-slate-200 font-mono"
                  />
                  <button
                    type="button"
                    onClick={handleSendAppUrlViaSMS}
                    className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shrink-0 flex items-center gap-1 transition"
                  >
                    <span>إرسال SMS</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Platform Selector Tabs */}
            <div className="grid grid-cols-3 gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
              <button
                type="button"
                onClick={() => setActivePlatformTab('android')}
                className={`py-2 rounded-lg font-bold transition flex items-center justify-center gap-1.5 ${
                  activePlatformTab === 'android'
                    ? 'bg-teal-600 text-white shadow'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Smartphone className="w-4 h-4" />
                <span>أندرويد (Android)</span>
              </button>
              <button
                type="button"
                onClick={() => setActivePlatformTab('ios')}
                className={`py-2 rounded-lg font-bold transition flex items-center justify-center gap-1.5 ${
                  activePlatformTab === 'ios'
                    ? 'bg-teal-600 text-white shadow'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Smartphone className="w-4 h-4" />
                <span>آيفون (iOS Safari)</span>
              </button>
              <button
                type="button"
                onClick={() => setActivePlatformTab('desktop')}
                className={`py-2 rounded-lg font-bold transition flex items-center justify-center gap-1.5 ${
                  activePlatformTab === 'desktop'
                    ? 'bg-teal-600 text-white shadow'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Monitor className="w-4 h-4" />
                <span>الكمبيوتر</span>
              </button>
            </div>

            {/* Platform Specific Steps */}
            <div className="bg-slate-950/70 border border-slate-800/80 rounded-2xl p-4 space-y-2.5 text-xs text-slate-300 leading-relaxed">
              {activePlatformTab === 'android' && (
                <div className="space-y-2.5">
                  <div className="flex items-center gap-2 font-bold text-teal-300">
                    <span className="w-2 h-2 rounded-full bg-teal-400"></span>
                    <span>خطوات التثبيت على هواتف وأجهزة أندرويد (Google Chrome):</span>
                  </div>
                  <ol className="list-decimal list-inside space-y-2 text-slate-300 pr-1 text-[11px]">
                    <li>افتح الرابط في متصفح <strong>Google Chrome</strong> على هاتفك.</li>
                    <li>
                      ستلاحظ ظهور شريط أو زر <strong>[ 📲 تثبيت التطبيق على الجهاز ]</strong> بأعلى الشاشة، اضغط عليه مباشرة.
                    </li>
                    <li>
                      أو اضغط على قائمة خيارات Chrome (الثلاث نقاط الرأسية <strong className="font-mono text-teal-300">⋮</strong> بأعلى يسار/يمين الشاشة).
                    </li>
                    <li>
                      اختر <strong>«تثبيت التطبيق» (Install App)</strong> أو <strong>«إضافة إلى الشاشة الرئيسية» (Add to Home screen)</strong>.
                    </li>
                    <li>
                      اضغط على <strong>«تثبيت» (Install)</strong> لتأكيد العملية.
                    </li>
                  </ol>
                  <div className="bg-teal-950/50 border border-teal-800/60 p-2.5 rounded-xl text-[10px] text-teal-300 mt-2">
                    ✓ ستظهر أيقونة مستشفى آزال الرسمية على شاشة هاتفك الرئيسية، وسيعمل التطبيق بملء الشاشة وبدون متصفح حتى بدون اتصال إنترنت.
                  </div>
                </div>
              )}

              {activePlatformTab === 'ios' && (
                <div className="space-y-2.5">
                  <div className="flex items-center gap-2 font-bold text-teal-300">
                    <span className="w-2 h-2 rounded-full bg-teal-400"></span>
                    <span>خطوات التثبيت على هواتف iPhone و iPad (متصفح Safari):</span>
                  </div>
                  <ol className="list-decimal list-inside space-y-2 text-slate-300 pr-1 text-[11px]">
                    <li>
                      افتح الرابط حصراً في متصفح <strong>Safari</strong> الأساسي بالآيفون.
                    </li>
                    <li className="flex items-center gap-1.5">
                      <span>اضغط على زر المشاركة</span>
                      <Share2 className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                      <span>(الأيقونة المربعة وبها سهم للأعلى في أسفل الشاشة).</span>
                    </li>
                    <li className="flex items-center gap-1.5">
                      <span>مرر القائمة لأسفل واختر</span>
                      <PlusSquare className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                      <strong className="text-teal-200">«إضافة إلى الشاشة الرئيسية» (Add to Home Screen)</strong>.
                    </li>
                    <li>
                      اضغط على <strong>«إضافة» (Add)</strong> في الزاوية العلوية.
                    </li>
                  </ol>
                  <div className="bg-teal-950/50 border border-teal-800/60 p-2.5 rounded-xl text-[10px] text-teal-300 mt-2">
                    ✓ يتم تثبيت التطبيق فوراً كبرنامج مستقل على شاشة الآيفون مع دعم وضع العمل دون اتصال.
                  </div>
                </div>
              )}

              {activePlatformTab === 'desktop' && (
                <div className="space-y-2.5">
                  <div className="flex items-center gap-2 font-bold text-teal-300">
                    <span className="w-2 h-2 rounded-full bg-teal-400"></span>
                    <span>طريقة التثبيت على جهاز الكمبيوتر (Chrome / Edge):</span>
                  </div>
                  <ol className="list-decimal list-inside space-y-2 text-slate-300 pr-1 text-[11px]">
                    <li>ستجد أيقونة تثبيت صغيرة <strong className="text-teal-400 font-mono">⊕</strong> أو شاشة كمبيوتر صغيرة في شريط العنوان (URL bar) بأعلى المتصفح.</li>
                    <li>اضغط عليها ثم اضغط <strong>«تثبيت» (Install)</strong>.</li>
                    <li>سيتم فتح المنظومة في نافذة مستقلة وخفيفة مع أيقونة على سطح المكتب وقائمة البرامج.</li>
                  </ol>
                </div>
              )}
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-[11px] text-slate-400">
              <span className="flex items-center gap-1.5 text-emerald-400 font-semibold">
                <ShieldCheck className="w-4 h-4" />
                <span>بياناتك ومحاضرك مشفرة ومحفوظة محلياً بأمان تام</span>
              </span>
              <button
                type="button"
                onClick={handleCloseModal}
                className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition"
              >
                فهمت ذلك ✓
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
