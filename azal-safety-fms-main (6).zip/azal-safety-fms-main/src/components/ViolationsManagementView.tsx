import React, { useState } from 'react';
import { 
  AlertTriangle, 
  Send, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Search, 
  Filter, 
  User, 
  Phone, 
  ExternalLink, 
  Share2, 
  ShieldAlert, 
  FileText, 
  Eye, 
  Camera, 
  Calendar,
  X,
  Plus,
  MessageSquare,
  Smartphone,
  AlertOctagon,
  Trash2,
  Building2,
  Table,
  LayoutGrid,
  BellRing,
  Mail,
  Check,
  Printer,
  Copy
} from 'lucide-react';
import { CompletedActionResponseModal, CompletedAction } from './CompletedActionResponseModal';
import { SafetyViolationNotice, StaffUser, ViolationStatus } from '../types';
import { VoiceDictationButton } from './VoiceDictationButton';
import { 
  cleanYemeniPhoneNumber, 
  pickContactPhoneNumber, 
  generateOfficialViolationWhatsAppText, 
  generateEscalationWarningWhatsAppText, 
  openWhatsAppDirect,
  generateOfficialViolationSMSText,
  generateEscalationWarningSMSText,
  openNativeSMSDirect,
  getNativeSMSUri,
  getPublicResolveUrl,
  getPublicAppBaseUrl,
  formatOverdueDurationAr
} from '../utils/phoneUtils';
import { analyzeViolationDeadline, POPULAR_DEPARTMENTS } from '../utils/violationUtils';
import { ExecutiveDepartmentAuditReportModal } from './ExecutiveDepartmentAuditReportModal';

interface ViolationsManagementViewProps {
  violations: SafetyViolationNotice[];
  currentUser: StaffUser;
  onUpdateViolation: (updated: SafetyViolationNotice) => void;
  onDeleteViolation?: (id: string) => void;
  onLogAudit: (action: string, actionAr: string, details: string) => void;
  onOpenIncomingReportsModal?: () => void;
  onOpenResolvePortal?: (violationId: string) => void;
}

export const ViolationsManagementView: React.FC<ViolationsManagementViewProps> = ({
  violations,
  currentUser,
  onUpdateViolation,
  onDeleteViolation,
  onLogAudit,
  onOpenIncomingReportsModal,
  onOpenResolvePortal,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');
  const [showExecutiveReportModal, setShowExecutiveReportModal] = useState(false);
  
  // Follow-up Alert Success Modal
  const [followUpSuccessModal, setFollowUpSuccessModal] = useState<{
    violation: SafetyViolationNotice;
    newCount: number;
    sentAt: string;
  } | null>(null);

  // Dispatch Modal
  const [selectedViolationForSend, setSelectedViolationForSend] = useState<SafetyViolationNotice | null>(null);
  const [dispatchChannel, setDispatchChannel] = useState<'sms' | 'whatsapp'>('sms');
  const [recipientPhoneInput, setRecipientPhoneInput] = useState('');
  const [requiredActionInput, setRequiredActionInput] = useState('');
  const [isEscalationMode, setIsEscalationMode] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState<SafetyViolationNotice | null>(null);
  const [deleteConfirmViolation, setDeleteConfirmViolation] = useState<SafetyViolationNotice | null>(null);

  // Completed Action Response Modal (Strictly isolated via closureModalNotice)
  const [closureModalNotice, setClosureModalNotice] = useState<CompletedAction | null>(null);

  const getBaseResolveUrl = (violation: SafetyViolationNotice) => {
    // Generate static public accessible route without authentication requirements
    return getPublicResolveUrl(violation);
  };

  const openSendModal = (
    violation: SafetyViolationNotice, 
    escalation = false, 
    channel: 'sms' | 'whatsapp' = 'sms'
  ) => {
    setSelectedViolationForSend(violation);
    setIsEscalationMode(escalation);
    setDispatchChannel(channel);
    setRecipientPhoneInput(violation.recipientPhone || '967');
    const party = violation.assignedToCustom || violation.assignedTo;
    setRequiredActionInput(
      violation.requiredAction || 
      (party && party !== 'غير محدد'
        ? `معالجة وتصحيح الوضع فوراً من قِبل ${party} وإرفاق صورة الإنجاز`
        : 'معالجة وتصحيح وضع المخالفة فوراً وتأمين الموقع ورفع إفادة الإنجاز')
    );
  };

  const handlePickContact = async () => {
    const contact = await pickContactPhoneNumber();
    if (contact && contact.phone) {
      setRecipientPhoneInput(contact.phone);
    }
  };

  const handleSendViaSMS = () => {
    if (!selectedViolationForSend) return;

    const cleaned = cleanYemeniPhoneNumber(recipientPhoneInput);
    if (!cleaned || cleaned.length < 9) {
      alert('يرجى إدخال أو سحب رقم هاتف يمني صحيح (مثال: 771234567)');
      return;
    }

    const violationWithAction = {
      ...selectedViolationForSend,
      requiredAction: requiredActionInput || selectedViolationForSend.requiredAction
    };

    const resolveUrl = getBaseResolveUrl(violationWithAction);
    const text = isEscalationMode
      ? generateEscalationWarningSMSText(violationWithAction, resolveUrl)
      : generateOfficialViolationSMSText(violationWithAction, resolveUrl);

    // Document actual dispatch timestamp
    const nowTimestamp = new Date().toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' });

    const updatedViolation: SafetyViolationNotice = {
      ...violationWithAction,
      recipientPhone: cleaned,
      firstSentAt: selectedViolationForSend.firstSentAt || nowTimestamp,
      secondSentAt: isEscalationMode ? nowTimestamp : selectedViolationForSend.secondSentAt,
      synced: false,
    };

    onUpdateViolation(updatedViolation);

    onLogAudit(
      isEscalationMode ? 'VIOLATION_ESCALATION_SMS_SENT' : 'VIOLATION_DISPATCHED_SMS',
      isEscalationMode ? 'إرسال إنذار ثانٍ عبر رسالة SMS (الشريحة)' : 'إرسال إشعار مخالفة عبر رسالة SMS (شريحة الهاتف)',
      `تم توجيه رسالة SMS المباشرة برقم الإشعار ${selectedViolationForSend.id} للرقم ${cleaned} في: ${nowTimestamp}.`
    );

    // Open Native SMS App with sms:967XXXXXXXXX?body=... (or sms:967XXXXXXXXX;?body= for iOS)
    openNativeSMSDirect(cleaned, text);
    setSelectedViolationForSend(null);
  };

  const handleSendViaWhatsApp = () => {
    if (!selectedViolationForSend) return;

    const cleaned = cleanYemeniPhoneNumber(recipientPhoneInput);
    if (!cleaned || cleaned.length < 9) {
      alert('يرجى إدخال أو سحب رقم هاتف يمني صحيح (مثال: 771234567)');
      return;
    }

    const violationWithAction = {
      ...selectedViolationForSend,
      requiredAction: requiredActionInput || selectedViolationForSend.requiredAction
    };

    const resolveUrl = getBaseResolveUrl(violationWithAction);
    const text = isEscalationMode
      ? generateEscalationWarningWhatsAppText(violationWithAction, resolveUrl)
      : generateOfficialViolationWhatsAppText(violationWithAction, resolveUrl);

    // Document actual dispatch timestamp
    const nowTimestamp = new Date().toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' });

    const updatedViolation: SafetyViolationNotice = {
      ...violationWithAction,
      recipientPhone: cleaned,
      firstSentAt: selectedViolationForSend.firstSentAt || nowTimestamp,
      secondSentAt: isEscalationMode ? nowTimestamp : selectedViolationForSend.secondSentAt,
      synced: false,
    };

    onUpdateViolation(updatedViolation);

    onLogAudit(
      isEscalationMode ? 'VIOLATION_ESCALATION_SENT' : 'VIOLATION_DISPATCHED_WHATSAPP',
      isEscalationMode ? 'إرسال إنذار ثانٍ (تصعيد للإدارة العليا)' : 'إرسال إشعار مخالفة عبر الواتساب',
      `تم إرسال الإشعار رقم ${selectedViolationForSend.id} للرقم ${cleaned} في: ${nowTimestamp}.`
    );

    // Open WhatsApp via direct intent / scheme
    openWhatsAppDirect(cleaned, text);
    setSelectedViolationForSend(null);
  };

  const handleSendFollowUpNotice = (violation: SafetyViolationNotice) => {
    const newCount = (violation.followUpCount || 0) + 1;
    const nowTimestamp = new Date().toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' });
    const analysis = analyzeViolationDeadline(violation);

    const newFollowUpItem = {
      id: `FOL-${Date.now()}`,
      sentAt: nowTimestamp,
      sentBy: currentUser.name || 'مسؤول الأمن والسلامة',
      channel: 'system_alert',
      count: newCount,
      notes: `إشعار متابعة رقم (${newCount}) لتجاوز مهلة الإنجاز (${analysis.overdueDaysText || 'متأخر'})`
    };

    const updatedViolation: SafetyViolationNotice = {
      ...violation,
      followUpCount: newCount,
      lastFollowUpAt: nowTimestamp,
      followUpHistory: [...(violation.followUpHistory || []), newFollowUpItem],
      status: violation.status === 'resolved' ? 'resolved' : 'overdue',
      synced: false
    };

    onUpdateViolation(updatedViolation);

    onLogAudit(
      'VIOLATION_FOLLOWUP_DISPATCHED',
      'إرسال إشعار متابعة وزيادة عداد الإنذارات',
      `تم توثيق إرسال إشعار المتابعة رقم (${newCount}) للمخالفة (${violation.id}) بقسم (${violation.department}) - المهلة متأخرة بمقدار (${analysis.overdueDaysText || 'منتهية'}). التاريخ: ${nowTimestamp}.`
    );

    setFollowUpSuccessModal({
      violation: updatedViolation,
      newCount,
      sentAt: nowTimestamp
    });
  };

  // Department dropdown options
  const departmentOptions = [
    { id: 'all', label: 'عرض كافة الأقسام (الكل)', icon: '🏢' },
    { id: 'الطوارئ', label: 'قسم الطوارئ والإسعاف', icon: '🚨' },
    { id: 'الصيانة العامة', label: 'قسم الصيانة العامة والهندسية', icon: '🔧' },
    { id: 'الأجهزة الطبية', label: 'قسم الأجهزة الطبية والهندسة الطبية', icon: '🩺' },
    { id: 'العمليات', label: 'العمليات الجراحية الكبرى', icon: '🔪' },
    { id: 'المغسلة', label: 'المغسلة المركزية ومستودع البياضات', icon: '🧺' },
    { id: 'الأشعة', label: 'قسم الأشعة التشخيصية', icon: '🩻' },
  ];
  
  // Dynamically include other departments from active violations
  const existingDepts = Array.from(new Set(violations.map((v) => v.department).filter(Boolean)));
  existingDepts.forEach((d) => {
    if (!departmentOptions.some((opt) => opt.id !== 'all' && d.toLowerCase().includes(opt.id.toLowerCase()))) {
      departmentOptions.push({ id: d, label: d, icon: '🏥' });
    }
  });

  const isViolationResolved = (v: SafetyViolationNotice) => {
    return (
      v.status === 'resolved' ||
      v.status === 'responded' ||
      v.status === 'تمت المعالجة' ||
      (v as any).status === 'Closed' ||
      Boolean(v.resolvedAt && v.resolutionNote)
    );
  };

  const filteredViolations = violations.filter((v) => {
    const party = (v.assignedToCustom || v.assignedTo || '').toLowerCase();
    const matchesSearch =
      v.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      v.department.toLowerCase().includes(searchTerm.toLowerCase()) ||
      v.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (v.resolutionNote && v.resolutionNote.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (v.resolvedBy && v.resolvedBy.toLowerCase().includes(searchTerm.toLowerCase())) ||
      party.includes(searchTerm.toLowerCase());

    const analysis = analyzeViolationDeadline(v);
    const isResolved = isViolationResolved(v);
    const isOverdue = !isResolved && analysis.isOverdue;
    const isPending = !isResolved && !isOverdue;

    let matchesStatus = true;
    if (statusFilter === 'pending') matchesStatus = isPending;
    else if (statusFilter === 'overdue') matchesStatus = isOverdue;
    else if (statusFilter === 'resolved') matchesStatus = isResolved;

    const matchesSeverity = severityFilter === 'all' || v.severity === severityFilter;

    const matchesDepartment =
      departmentFilter === 'all' ||
      v.department.toLowerCase().includes(departmentFilter.toLowerCase());

    return matchesSearch && matchesStatus && matchesSeverity && matchesDepartment;
  });

  const overdueViolationsList = violations.filter((v) => !isViolationResolved(v) && analyzeViolationDeadline(v).isOverdue);
  const resolvedCount = violations.filter((v) => isViolationResolved(v)).length;
  const pendingCount = violations.filter((v) => {
    const isResolved = isViolationResolved(v);
    const isOverdue = analyzeViolationDeadline(v).isOverdue;
    return !isResolved && !isOverdue;
  }).length;

  const overdueCount = overdueViolationsList.length;

  return (
    <div id="violations-management-view" className="space-y-4 text-right">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-amber-950/60 via-slate-900 to-slate-900 border border-amber-800/60 rounded-2xl p-4 shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-amber-950/90 border border-amber-700 text-amber-400">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-slate-100">
                منظومة إشعارات المخالفات والإنذار والمتابعة
              </h3>
              <span className="text-[10px] bg-amber-950 text-amber-300 border border-amber-800 px-2 py-0.5 rounded font-bold">
                WhatsApp & Escalation
              </span>
            </div>
            <p className="text-xs text-slate-400">
              إرسال الإشعارات عبر واتساب بروابط إفادة مباشرة وتتبع المهلة والتصعيد للإدارة العليا
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto text-xs">
          {onOpenIncomingReportsModal && (
            <button
              type="button"
              onClick={onOpenIncomingReportsModal}
              className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-800 to-teal-800 hover:from-emerald-700 hover:to-teal-700 text-white font-bold flex items-center gap-1.5 shadow-md shadow-emerald-950 transition active:scale-95"
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span>مركز إفادة بنك الدم والبلاغات الواردة</span>
            </button>
          )}
          <div className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300">
            <span>إجمالي الإشعارات: </span>
            <strong className="text-amber-400 font-mono">{violations.length}</strong>
          </div>
        </div>
      </div>

      {/* Prominent Red Warning Card: Overdue Violations Alert */}
      {overdueCount > 0 && (
        <div className="bg-gradient-to-r from-rose-950 via-red-950 to-slate-900 border-2 border-rose-600 rounded-2xl p-4 sm:p-5 shadow-2xl shadow-rose-950/80 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-rose-800/80 pb-3">
            <div className="flex items-center gap-3">
              <span className="p-2.5 rounded-xl bg-rose-900 text-rose-100 border border-rose-500 shadow-md flex items-center justify-center animate-pulse">
                <AlertOctagon className="w-6 h-6 text-rose-200" />
              </span>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="text-base font-black text-white">
                    ⚠️ مخالفات متجاوزة للمهلة المحددة
                  </h4>
                  <span className="px-2.5 py-0.5 rounded-full bg-rose-600 text-white font-mono font-black text-xs shadow animate-bounce">
                    {overdueCount} متأخرة
                  </span>
                </div>
                <p className="text-xs text-rose-200 mt-1 leading-relaxed">
                  تنبيه إداري: انتهت مهلة المعالجة المقررة لهذه المخالفات دون تسجيل إفادة إنجاز معتمدة حتى الآن، وتستوجب توجيه إنذار ثانٍ وتصعيد للإدارة العليا.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 self-start sm:self-auto">
              <button
                type="button"
                onClick={() => setStatusFilter(statusFilter === 'overdue' ? 'all' : 'overdue')}
                className="px-3.5 py-2 rounded-xl bg-rose-700 hover:bg-rose-600 text-white text-xs font-bold transition shadow-lg shadow-rose-950 flex items-center gap-1.5"
              >
                <Filter className="w-3.5 h-3.5" />
                <span>{statusFilter === 'overdue' ? 'عرض كافة الحالات' : `تصفية المتجاوزة فقط (${overdueCount})`}</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 pt-1">
            {overdueViolationsList.map((ov) => (
              <div
                key={ov.id}
                onClick={() => {
                  setStatusFilter('overdue');
                  setSearchTerm(ov.id);
                }}
                className="p-2.5 rounded-xl bg-slate-950/80 border border-rose-800 hover:border-rose-500 cursor-pointer transition flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-rose-400">{ov.id}</span>
                  <span className="text-slate-300 font-semibold">{ov.department}</span>
                </div>
                {ov.deadlineAt && (
                  <span className="text-[11px] text-rose-300 font-mono">
                    تأخير: {formatOverdueDurationAr(ov.deadlineAt)}
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Prominent Blood Bank Response Card (Direct Answer to User Request) */}
      {(() => {
        const bloodBankVio = violations.find(
          (v) => v.id === 'AZAL-VIO-2026-004' || v.department.includes('بنك الدم') || (v.resolutionNote && v.resolutionNote.includes('بنك الدم'))
        );
        if (!bloodBankVio || !bloodBankVio.resolutionNote) return null;

        return (
          <div className="bg-gradient-to-r from-rose-950/40 via-slate-900 to-emerald-950/40 border-2 border-emerald-500/70 rounded-2xl p-4 shadow-xl space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-lg bg-rose-950 text-rose-300 border border-rose-800 font-mono text-xs font-black">
                  🩸 {bloodBankVio.id}
                </span>
                <span className="text-xs font-bold text-white">
                  رسالة وإفادة الرد المعتمدة من {bloodBankVio.department}
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold">
                  🟢 تم الرد بالرابط
                </span>
              </div>
              <span className="text-[11px] text-slate-400 font-mono">
                وقت الرد: {bloodBankVio.resolvedAt || '09:42 ص'} • المعتمد: <strong className="text-teal-300">{bloodBankVio.resolvedBy}</strong>
              </span>
            </div>

            <div className="bg-slate-950/90 p-3 rounded-xl border border-emerald-900/60 text-xs text-slate-200 space-y-1">
              <span className="text-emerald-400 font-bold block text-[11px]">
                نص الرسالة التي رد بها بالرابط من بنك الدم:
              </span>
              <p className="leading-relaxed font-medium">"{bloodBankVio.resolutionNote}"</p>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
              <span className="text-[11px] text-slate-400">
                الموقع: {bloodBankVio.locationDetail}
              </span>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    setClosureModalNotice({
                      id: bloodBankVio.id,
                      notice_number: bloodBankVio.id,
                      department_name: bloodBankVio.department,
                      hazard_description: bloodBankVio.description,
                      action_taken: bloodBankVio.resolutionNote || 'تمت المعالجة والإنجاز بنجاح',
                      completed_by: bloodBankVio.resolvedBy || 'مسؤول بنك الدم',
                      completed_at: bloodBankVio.resolvedAt || 'اليوم',
                      status: bloodBankVio.status
                    });
                  }}
                  className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 transition shadow-sm cursor-pointer"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>الرد على الإفادة واعتمادها</span>
                </button>

                <button
                  type="button"
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    if (onOpenResolvePortal) {
                      onOpenResolvePortal(bloodBankVio.id);
                    } else {
                      window.location.hash = `#resolve?id=${bloodBankVio.id}`;
                    }
                  }}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 text-xs font-bold flex items-center gap-1.5 transition shadow-sm cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>صفحة الإفادة بالرابط</span>
                </button>

                {onOpenIncomingReportsModal && (
                  <button
                    type="button"
                    onClick={onOpenIncomingReportsModal}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition"
                  >
                    عرض كافة البلاغات والإفادات
                  </button>
                )}
              </div>
            </div>
          </div>
        );
      })()}

      {/* Traffic Light Quick Stats & Tab Filter Bar */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
        <button
          type="button"
          onClick={() => setStatusFilter(statusFilter === 'pending' ? 'all' : 'pending')}
          className={`p-3 border rounded-xl text-right transition cursor-pointer ${
            statusFilter === 'pending'
              ? 'bg-amber-950/80 border-amber-500 shadow-lg ring-2 ring-amber-500/40'
              : 'bg-slate-900 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] text-amber-300 block font-bold">🟡 المهام المفتوحة (النشطة)</span>
            <span className="text-[10px] text-slate-400 font-mono">ضمن المهلة</span>
          </div>
          <span className="text-xl font-black text-amber-400 font-mono mt-1 block">{pendingCount}</span>
        </button>

        <button
          type="button"
          onClick={() => setStatusFilter(statusFilter === 'overdue' ? 'all' : 'overdue')}
          className={`p-3 border rounded-xl text-right transition cursor-pointer ${
            statusFilter === 'overdue'
              ? 'bg-rose-950/90 border-rose-500 shadow-lg ring-2 ring-rose-500/40'
              : 'bg-rose-950/30 border-rose-900/60 hover:border-rose-700'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] text-rose-300 block font-bold">🔴 متجاوزة للمهلة (Overdue)</span>
            <span className="text-[10px] text-rose-400 font-mono animate-pulse">تستوجب إنذار</span>
          </div>
          <span className="text-xl font-black text-rose-400 font-mono mt-1 block">{overdueCount}</span>
        </button>

        <button
          type="button"
          onClick={() => setStatusFilter(statusFilter === 'resolved' ? 'all' : 'resolved')}
          className={`p-3 border rounded-xl text-right transition cursor-pointer ${
            statusFilter === 'resolved'
              ? 'bg-emerald-950/90 border-emerald-500 shadow-lg ring-2 ring-emerald-500/40'
              : 'bg-emerald-950/30 border-emerald-900/60 hover:border-emerald-700'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] text-emerald-300 block font-bold">🟢 الإشعارات المنجزة</span>
            <span className="text-[10px] text-emerald-400 font-mono">تمت المعالجة</span>
          </div>
          <span className="text-xl font-black text-emerald-400 font-mono mt-1 block">{resolvedCount}</span>
        </button>

        <button
          type="button"
          onClick={() => setStatusFilter('all')}
          className={`p-3 border rounded-xl text-right transition cursor-pointer ${
            statusFilter === 'all'
              ? 'bg-slate-800 border-teal-500 shadow-lg ring-2 ring-teal-500/40'
              : 'bg-slate-900 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] text-slate-300 block font-bold">📋 كافة الإشعارات المسجلة</span>
            <span className="text-[10px] text-teal-400 font-mono">الكل</span>
          </div>
          <span className="text-xl font-black text-teal-400 font-mono mt-1 block">{violations.length}</span>
        </button>
      </div>

      {/* Department Filter & Search Bar */}
      <div className="space-y-2">
        {/* Top Row: Department Filter Dropdown, Search, Status, Severity, and Table/Cards toggle */}
        <div className="flex flex-col lg:flex-row gap-2 text-xs">
          {/* 1. Department Filter Dropdown (Required by user) */}
          <div className="flex items-center gap-2 bg-slate-900 border border-slate-700/80 rounded-xl px-3 py-2 text-xs lg:w-72 shrink-0">
            <Building2 className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="text-slate-300 font-bold whitespace-nowrap">القسم:</span>
            <select
              id="violations-department-filter"
              value={departmentFilter}
              onChange={(e) => setDepartmentFilter(e.target.value)}
              className="bg-transparent text-slate-100 font-bold text-xs focus:outline-none cursor-pointer w-full"
            >
              <option value="all" className="bg-slate-900 text-slate-100 font-bold">
                [عرض كافة الأقسام]
              </option>
              <option value="الطوارئ" className="bg-slate-900 text-slate-100">
                🚨 قسم الطوارئ والإسعاف
              </option>
              <option value="الصيانة العامة" className="bg-slate-900 text-slate-100">
                🔧 قسم الصيانة العامة والهندسية
              </option>
              <option value="الأجهزة الطبية" className="bg-slate-900 text-slate-100">
                🩺 قسم الأجهزة الطبية والهندسة
              </option>
              <option value="العمليات" className="bg-slate-900 text-slate-100">
                🔪 العمليات الجراحية الكبرى
              </option>
              <option value="المغسلة" className="bg-slate-900 text-slate-100">
                🧺 المغسلة المركزية ومستودع البياضات
              </option>
              <option value="الأشعة" className="bg-slate-900 text-slate-100">
                🩻 قسم الأشعة التشخيصية
              </option>
              {departmentOptions
                .filter(
                  (opt) =>
                    opt.id !== 'all' &&
                    !['الطوارئ', 'الصيانة العامة', 'الأجهزة الطبية', 'العمليات', 'المغسلة', 'الأشعة'].includes(
                      opt.id
                    )
                )
                .map((opt) => (
                  <option key={opt.id} value={opt.id} className="bg-slate-900 text-slate-100">
                    {opt.label}
                  </option>
                ))}
            </select>
          </div>

          {/* Quick Action: Generate Department Audit Report for General Director */}
          <button
            type="button"
            id="btn-issue-executive-audit-report"
            onClick={() => setShowExecutiveReportModal(true)}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-600 via-amber-700 to-slate-900 hover:from-amber-500 hover:to-slate-800 text-white font-black text-xs flex items-center justify-center gap-1.5 shadow-md shadow-amber-950/60 border border-amber-500/40 transition active:scale-95 shrink-0 whitespace-nowrap"
            title="إصدار التقرير الرقابي التنفيذي للقسم المحدد لرفعه للمدير العام للمحاسبة الإدارية"
          >
            <FileText className="w-4 h-4 text-amber-300" />
            <span>📄 إصدار التقرير الرقابي للقسم المحدد</span>
          </button>

          {/* Search Input */}
          <div className="relative flex-1 flex items-center">
            <Search className="w-4 h-4 text-slate-500 absolute right-3 top-2.5 pointer-events-none" />
            <input
              type="text"
              placeholder="بحث برقم الإشعار، القسم، الجهة المكلفة، الوصف..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl pr-9 pl-11 py-2 text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-500 text-xs"
            />
            <div className="absolute left-1.5 top-1.5">
              <VoiceDictationButton
                value={searchTerm}
                onChange={setSearchTerm}
                title="بحث صوتي في المخالفات"
              />
            </div>
          </div>

          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 text-xs focus:outline-none font-bold cursor-pointer"
          >
            <option value="all">كافة الحالات ({violations.length})</option>
            <option value="pending">🟡 المهام المفتوحة النشطة ({pendingCount})</option>
            <option value="overdue">🔴 متأخرة وتجاوزت المهلة ({overdueCount})</option>
            <option value="resolved">🟢 تمت المعالجة ({resolvedCount})</option>
          </select>

          {/* Severity Filter */}
          <select
            value={severityFilter}
            onChange={(e) => setSeverityFilter(e.target.value)}
            className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 text-xs focus:outline-none"
          >
            <option value="all">كافة مستويات الخطورة</option>
            <option value="critical">حرج جداً</option>
            <option value="high">مرتفع</option>
            <option value="medium">متوسط</option>
            <option value="low">منخفض</option>
          </select>

          {/* View Mode Toggle: Table / Cards */}
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 shrink-0">
            <button
              type="button"
              onClick={() => setViewMode('table')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition ${
                viewMode === 'table'
                  ? 'bg-amber-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="عرض جدول المخالفات والملاحظات"
            >
              <Table className="w-3.5 h-3.5" />
              <span>جدول منظم</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('cards')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition ${
                viewMode === 'cards'
                  ? 'bg-amber-600 text-white shadow'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="عرض البطاقات التفصيلية"
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>بطاقات</span>
            </button>
          </div>
        </div>

        {/* Quick Department Buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px] scrollbar-thin">
          <span className="text-slate-400 font-bold shrink-0 ml-1">تصفية سريعة:</span>
          {[
            { id: 'all', label: 'كافة الأقسام', icon: '🏢' },
            { id: 'الطوارئ', label: 'الطوارئ', icon: '🚨' },
            { id: 'الصيانة العامة', label: 'الصيانة العامة', icon: '🔧' },
            { id: 'الأجهزة الطبية', label: 'الأجهزة الطبية', icon: '🩺' },
            { id: 'العمليات', label: 'العمليات', icon: '🔪' },
            { id: 'المغسلة', label: 'المغسلة', icon: '🧺' },
            { id: 'الأشعة', label: 'الأشعة', icon: '🩻' },
          ].map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setDepartmentFilter(item.id)}
              className={`px-2.5 py-1 rounded-lg font-bold flex items-center gap-1 transition shrink-0 ${
                departmentFilter === item.id
                  ? 'bg-amber-600 text-white shadow-sm'
                  : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800'
              }`}
            >
              <span>{item.icon}</span>
              <span>{item.label}</span>
            </button>
          ))}
          {departmentFilter !== 'all' && (
            <button
              type="button"
              onClick={() => setDepartmentFilter('all')}
              className="text-[10px] text-amber-400 hover:underline shrink-0 mr-1"
            >
              (إلغاء التصفية)
            </button>
          )}
        </div>
      </div>

      {/* Main Content Area: Table View or Cards View */}
      {filteredViolations.length === 0 ? (
        <div className="p-8 text-center bg-slate-900/60 border border-slate-800 rounded-2xl text-slate-500 text-xs">
          لا توجد مخالفات مسجلة تطابق عوامل التصفية الحالية.
        </div>
      ) : viewMode === 'table' ? (
        /* TABLE VIEW (جدول المخالفات والملاحظات) */
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-950/90 border-b border-slate-800 text-slate-300 font-bold">
                <tr>
                  <th className="p-3 whitespace-nowrap">رقم الإشعار</th>
                  <th className="p-3 whitespace-nowrap">القسم والموقع</th>
                  <th className="p-3">وصف الملاحظة والخطورة</th>
                  <th className="p-3 whitespace-nowrap">المكلف بالمعالجة</th>
                  <th className="p-3 whitespace-nowrap">تاريخ الاستحقاق (Deadline)</th>
                  <th className="p-3 whitespace-nowrap">مؤشر المهلة وحالة التأخير</th>
                  <th className="p-3 whitespace-nowrap">عداد المتابعات</th>
                  <th className="p-3 whitespace-nowrap text-center">إجراءات المتابعة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredViolations.map((v) => {
                  const overdueInfo = analyzeViolationDeadline(v);
                  const isResolved = isViolationResolved(v);
                  const isOverdue = !isResolved && overdueInfo.isOverdue;
                  const party = v.assignedToCustom || v.assignedTo;

                  return (
                    <tr
                      key={v.id}
                      onClick={(e) => {
                        const target = e.target as HTMLElement;
                        if (target.closest('button') || target.closest('a') || target.closest('select') || target.closest('input')) {
                          return;
                        }
                        setShowDetailModal(v);
                      }}
                      className={`hover:bg-slate-800/60 cursor-pointer transition ${
                        isOverdue
                          ? 'bg-rose-950/20'
                          : isResolved
                          ? 'bg-emerald-950/15'
                          : 'bg-slate-900/50'
                      }`}
                      title="اضغط لاستعراض تفاصيل الإشعار وإفادة المعالجة المرفقة"
                    >
                      {/* Notice ID */}
                      <td className="p-3 font-mono font-bold text-amber-400 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <span>{v.id}</span>
                          {isResolved && (
                            <span className="w-2 h-2 rounded-full bg-emerald-400" title="تمت المعالجة" />
                          )}
                        </div>
                      </td>

                      {/* Department & Location */}
                      <td className="p-3">
                        <span className="font-bold text-slate-100 block whitespace-nowrap">
                          {v.department}
                        </span>
                        <span className="text-[11px] text-slate-400 block max-w-xs truncate">
                          📍 {v.locationDetail}
                        </span>
                      </td>

                      {/* Description & Severity */}
                      <td className="p-3 min-w-[200px] max-w-xs">
                        <p className="text-slate-200 line-clamp-2 leading-relaxed font-medium">
                          {v.description}
                        </p>
                        <span
                          className={`inline-block mt-1 text-[10px] px-2 py-0.5 rounded border font-bold ${
                            v.severity === 'critical'
                              ? 'bg-rose-950 text-rose-300 border-rose-800'
                              : v.severity === 'high'
                              ? 'bg-orange-950 text-orange-300 border-orange-800'
                              : 'bg-slate-800 text-slate-300 border-slate-700'
                          }`}
                        >
                          {v.severity === 'critical' ? 'حرج جداً' : v.severity === 'high' ? 'مرتفع' : 'متوسط'}
                        </span>
                      </td>

                      {/* Assignee */}
                      <td className="p-3 whitespace-nowrap">
                        <span className="text-amber-300 font-bold block">{party}</span>
                        {v.recipientPhone && (
                          <span className="text-[10px] text-slate-400 font-mono block" dir="ltr">
                            📞 {v.recipientPhone}
                          </span>
                        )}
                      </td>

                      {/* Deadline Date */}
                      <td className="p-3 whitespace-nowrap">
                        <span className="text-slate-200 font-mono font-bold block">{v.deadlineAt}</span>
                        <span className="text-[10px] text-slate-400">
                          المهلة المحددة: {v.deadlineHours || 24} ساعة
                        </span>
                      </td>

                      {/* Smart Deadline & Overdue Indicator (Requirement 2) */}
                      <td className="p-3 whitespace-nowrap">
                        {isResolved ? (
                          <div className="space-y-1">
                            <span className="inline-flex items-center gap-1.5 text-[11px] font-black px-2.5 py-1 rounded-full bg-emerald-950 text-emerald-300 border-2 border-emerald-500 shadow-md shadow-emerald-950/60">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                              <span>🟢 تمت المعالجة</span>
                            </span>
                            {v.resolvedAt && (
                              <div className="text-[10px] text-emerald-400/90 font-mono pr-1">
                                🕒 {v.resolvedAt}
                              </div>
                            )}
                            {v.resolvedBy && (
                              <div className="text-[10px] text-slate-300 pr-1 truncate max-w-[140px]">
                                👤 {v.resolvedBy}
                              </div>
                            )}
                          </div>
                        ) : isOverdue ? (
                          <div className="space-y-1">
                            {/* RED BLINKING INDICATOR */}
                            <span className="inline-flex items-center gap-1.5 text-[11px] font-black px-2.5 py-1 rounded-full bg-rose-950 text-rose-200 border-2 border-rose-600 animate-pulse shadow-md shadow-rose-950">
                              <AlertOctagon className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                              <span>⚠️ منتهية المهلة - متأخر عن التنفيذ</span>
                            </span>
                            {/* Overdue Days count */}
                            <div className="flex items-center gap-1 text-[11px] text-rose-300 font-bold font-mono pr-1">
                              <span>⏳ التأخير:</span>
                              <span className="px-1.5 py-0.5 rounded bg-rose-900 border border-rose-600 text-white font-black text-xs">
                                {overdueInfo.overdueDays} يوم
                              </span>
                              <span className="text-[10px] text-rose-300/90 font-sans">
                                ({overdueInfo.overdueDaysText})
                              </span>
                            </div>
                          </div>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-full bg-amber-950 text-amber-300 border border-amber-800">
                            <Clock className="w-3.5 h-3.5 text-amber-400" />
                            <span>🟡 قيد المتابعة ضمن المهلة</span>
                          </span>
                        )}
                      </td>

                      {/* Follow-up Counter Display (Requirement 3) */}
                      <td className="p-3 whitespace-nowrap">
                        <div className="space-y-1">
                          <span
                            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg font-mono font-bold text-xs ${
                              (v.followUpCount || 0) > 0
                                ? 'bg-amber-950 text-amber-300 border border-amber-600 shadow-sm'
                                : 'bg-slate-800 text-slate-400 border border-slate-700'
                            }`}
                          >
                            <BellRing className="w-3.5 h-3.5 text-amber-400" />
                            <span>عدد مرات المتابعة: {v.followUpCount || 0}</span>
                          </span>
                          {v.lastFollowUpAt && (
                            <span className="block text-[10px] text-slate-400">
                              آخر متابعة: <strong className="text-slate-300 font-mono">{v.lastFollowUpAt}</strong>
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Actions: Follow-up Button & Dispatch */}
                      <td className="p-3 whitespace-nowrap text-center">
                        <div className="flex flex-col gap-1.5 items-center justify-center">
                          {/* View Statement / Details Button */}
                          <button
                            type="button"
                            onClick={() => setShowDetailModal(v)}
                            className={`w-full px-2.5 py-1.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition active:scale-95 ${
                              isResolved
                                ? 'bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border-emerald-600 shadow-sm'
                                : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
                            }`}
                            title={isResolved ? 'استعراض إفادة المعالجة وتاريخ الإغلاق' : 'استعراض تفاصيل الإشعار'}
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>{isResolved ? 'استعراض الإفادة ✅' : 'تفاصيل الإشعار'}</span>
                          </button>

                          {/* FOLLOW-UP BUTTON (Requirement 3) */}
                          <button
                            type="button"
                            onClick={() => handleSendFollowUpNotice(v)}
                            className="w-full px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-600 via-rose-600 to-red-600 hover:from-amber-500 hover:to-red-500 text-white text-xs font-black shadow-md shadow-rose-950 flex items-center justify-center gap-1.5 transition active:scale-95 whitespace-nowrap"
                            title="إرسال إشعار متابعة وزيادة عداد الإنذارات آلياً في قاعدة البيانات"
                          >
                            <Mail className="w-3.5 h-3.5 text-amber-200" />
                            <span>📩 إرسال إشعار متابعة</span>
                            {(v.followUpCount || 0) > 0 && (
                              <span className="px-1.5 py-0.2 rounded-full bg-slate-950 text-amber-300 font-mono text-[10px] font-bold border border-amber-500">
                                +{v.followUpCount}
                              </span>
                            )}
                          </button>

                          {/* Secondary Fast Dispatch Buttons */}
                          <div className="flex items-center gap-1 w-full justify-center">
                            <button
                              type="button"
                              onClick={() => openSendModal(v, isOverdue, 'whatsapp')}
                              className="px-2 py-1 rounded-lg bg-emerald-700/80 hover:bg-emerald-600 text-white text-[10px] font-bold flex items-center gap-1 transition"
                              title="إرسال عبر تطبيق الواتساب"
                            >
                              <Send className="w-3 h-3" />
                              <span>واتساب</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => openSendModal(v, isOverdue, 'sms')}
                              className="px-2 py-1 rounded-lg bg-blue-700/80 hover:bg-blue-600 text-white text-[10px] font-bold flex items-center gap-1 transition"
                              title="إرسال SMS من شريحة الهاتف"
                            >
                              <MessageSquare className="w-3 h-3" />
                              <span>SMS</span>
                            </button>

                            <a
                              href={getBaseResolveUrl(v)}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="p-1 px-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-teal-300 text-[10px] font-bold flex items-center transition"
                              title="فتح رابط إفادة الإنجاز"
                            >
                              <ExternalLink className="w-3 h-3" />
                            </a>

                            <button
                              type="button"
                              onClick={() => setDeleteConfirmViolation(v)}
                              className="p-1 px-1.5 rounded-lg bg-slate-800 hover:bg-rose-950 text-rose-400 hover:text-rose-300 border border-slate-700/60 text-[10px] font-bold transition"
                              title="حذف إشعار المخالفة"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* CARDS VIEW (عرض البطاقات التفصيلية) */
        <div className="space-y-3">
          {filteredViolations.map((v) => {
            const overdueInfo = analyzeViolationDeadline(v);
            const isResolved = isViolationResolved(v);
            const isOverdue = !isResolved && overdueInfo.isOverdue;
            const party = v.assignedToCustom || v.assignedTo;

            return (
              <div
                key={v.id}
                onClick={(e) => {
                  const target = e.target as HTMLElement;
                  if (target.closest('button') || target.closest('a') || target.closest('select') || target.closest('input')) {
                    return;
                  }
                  setShowDetailModal(v);
                }}
                className={`bg-slate-900 border rounded-2xl p-4 transition shadow-md relative overflow-hidden cursor-pointer hover:border-slate-700 ${
                  isOverdue
                    ? 'border-rose-700/80 bg-rose-950/10'
                    : isResolved
                    ? 'border-emerald-700/60 bg-emerald-950/10'
                    : 'border-slate-800'
                }`}
                title="اضغط لاستعراض تفاصيل الإشعار وإفادة المعالجة المرفقة"
              >
                {/* Traffic Light side accent */}
                <div
                  className={`absolute top-0 right-0 bottom-0 w-1.5 ${
                    isOverdue ? 'bg-rose-500' : isResolved ? 'bg-emerald-500' : 'bg-amber-500'
                  }`}
                />

                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 pr-2">
                  <div className="space-y-1.5 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono font-bold text-amber-400 text-xs">{v.id}</span>
                      <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[11px] font-bold">
                        {v.department}
                      </span>

                      {/* Smart Status Badge */}
                      {isResolved && (
                        <span className="inline-flex items-center gap-1.5 text-[11px] font-black px-2.5 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border-2 border-emerald-500 shadow-sm shadow-emerald-950/60">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          <span>🟢 تمت المعالجة</span>
                        </span>
                      )}
                      {isOverdue && (
                        <span className="inline-flex items-center gap-1 text-[10px] font-black px-2.5 py-0.5 rounded-full bg-rose-950 text-rose-200 border-2 border-rose-600 animate-pulse shadow-md shadow-rose-950">
                          <AlertOctagon className="w-3 h-3 text-rose-400" />
                          <span>⚠️ منتهية المهلة - متأخر عن التنفيذ</span>
                          <span className="px-1.5 py-0.2 rounded bg-rose-900 text-white font-mono text-[10px]">
                            ({overdueInfo.overdueDaysText})
                          </span>
                        </span>
                      )}
                      {!isResolved && !isOverdue && (
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-950 text-amber-300 border border-amber-800">
                          <Clock className="w-3 h-3 text-amber-400" />
                          <span>🟡 قيد المتابعة</span>
                        </span>
                      )}

                      {/* Follow-up counter chip */}
                      <span
                        className={`inline-flex items-center gap-1 text-[10px] font-mono font-bold px-2 py-0.5 rounded-lg border ${
                          (v.followUpCount || 0) > 0
                            ? 'bg-amber-950 text-amber-300 border-amber-700'
                            : 'bg-slate-800 text-slate-400 border-slate-700'
                        }`}
                      >
                        <BellRing className="w-3 h-3 text-amber-400" />
                        <span>عدد مرات المتابعة: {v.followUpCount || 0}</span>
                      </span>

                      <span
                        className={`text-[10px] px-2 py-0.5 rounded border ${
                          v.severity === 'critical'
                            ? 'bg-rose-950 text-rose-400 border-rose-800'
                            : v.severity === 'high'
                            ? 'bg-orange-950 text-orange-400 border-orange-800'
                            : 'bg-slate-800 text-slate-400 border-slate-700'
                        }`}
                      >
                        خطورة: {v.severity === 'critical' ? 'حرج جداً' : v.severity === 'high' ? 'مرتفع' : 'متوسط'}
                      </span>
                    </div>

                    <p className="text-xs text-slate-200 font-semibold leading-relaxed">
                      {v.description}
                    </p>

                    <div className="flex flex-wrap items-center gap-y-1 gap-x-4 text-[11px] text-slate-400">
                      <span>📍 الموقع: <strong className="text-slate-200">{v.locationDetail}</strong></span>
                      <span>👷‍♂️ المكلف: <strong className="text-amber-300">{party}</strong></span>
                      <span>⏰ تاريخ الاستحقاق: <strong className="text-slate-200 font-mono">{v.deadlineAt}</strong></span>
                    </div>

                    {/* Bold Overdue Alert Notice with Days count */}
                    {isOverdue && !isResolved && (
                      <div className="p-2.5 rounded-xl bg-rose-950/90 border-2 border-rose-600 text-rose-100 text-xs font-bold leading-relaxed mt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping shrink-0" />
                          <span>⚠️ تنبيه الإهمال: انتهت المهلة المحددة دون إغلاق الملاحظة أو تقديم إفادة معالجة</span>
                        </div>
                        <span className="px-2.5 py-1 rounded-lg bg-rose-900 border border-rose-600 text-white font-mono text-[11px] font-black shrink-0">
                          ⏳ مدة التأخير: {overdueInfo.overdueDays} يوم ({overdueInfo.overdueDaysText})
                        </span>
                      </div>
                    )}

                    {/* Resolution details if available */}
                    {isResolved && v.resolutionNote && (
                      <div className="p-2.5 rounded-xl bg-emerald-950/60 border border-emerald-800/80 text-emerald-200 text-xs mt-2">
                        <span className="font-bold block mb-0.5">✅ إفادة الإنجاز المسجلة:</span>
                        <span>{v.resolutionNote}</span>
                        {v.resolvedBy && (
                          <span className="block text-[10px] text-emerald-400 mt-1">
                            بواسطة: {v.resolvedBy} • {v.resolvedAt}
                          </span>
                        )}
                      </div>
                    )}

                    {/* Dispatch & Follow-up Timestamps */}
                    <div className="flex flex-wrap items-center gap-3 text-[10px] text-slate-500 pt-1">
                      {v.firstSentAt && (
                        <span>تاريخ الإرسال الأول: <strong className="text-slate-400 font-mono">{v.firstSentAt}</strong></span>
                      )}
                      {v.lastFollowUpAt && (
                        <span className="text-amber-400">
                          آخر إشعار متابعة: <strong className="font-mono">{v.lastFollowUpAt}</strong>
                        </span>
                      )}
                      {v.secondSentAt && (
                        <span className="text-rose-400">تاريخ الإنذار الثاني: <strong className="font-mono">{v.secondSentAt}</strong></span>
                      )}
                    </div>
                  </div>

                  {/* Actions Column */}
                  <div className="flex flex-col sm:items-end gap-2 shrink-0">
                    {/* View Statement & Details Button */}
                    <button
                      type="button"
                      onClick={() => setShowDetailModal(v)}
                      className={`w-full sm:w-auto px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition active:scale-95 ${
                        isResolved
                          ? 'bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border-emerald-600 shadow-sm'
                          : 'bg-slate-800 hover:bg-slate-700 text-teal-300 border-slate-700'
                      }`}
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>{isResolved ? 'استعراض الإفادة المرفقة وتاريخ الإغلاق ✅' : 'استعراض تفاصيل الإشعار'}</span>
                    </button>

                    {/* FOLLOW UP BUTTON (Requirement 3) */}
                    <button
                      type="button"
                      onClick={() => handleSendFollowUpNotice(v)}
                      className="w-full sm:w-auto px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-600 via-rose-600 to-red-600 hover:from-amber-500 hover:to-red-500 text-white text-xs font-black shadow-md shadow-rose-950 flex items-center justify-center gap-1.5 transition active:scale-95"
                      title="إرسال إشعار متابعة وزيادة عداد الإنذارات آلياً في قاعدة البيانات"
                    >
                      <Mail className="w-3.5 h-3.5 text-amber-200" />
                      <span>📩 إرسال إشعار متابعة</span>
                      {(v.followUpCount || 0) > 0 && (
                        <span className="px-1.5 py-0.2 rounded-full bg-slate-950 text-amber-300 font-mono text-[10px] font-bold border border-amber-500">
                          +{v.followUpCount}
                        </span>
                      )}
                    </button>

                    <div className="flex flex-wrap sm:flex-col lg:flex-row items-center gap-1.5 w-full sm:w-auto">
                      {/* Send Native SMS Button */}
                      <button
                        type="button"
                        onClick={() => openSendModal(v, false, 'sms')}
                        className="flex-1 sm:flex-initial px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md shadow-blue-950/50 flex items-center justify-center gap-1.5 transition active:scale-95"
                        title="إرسال إشعار المخالفة عبر رسالة SMS من شريحة الهاتف مباشرة (Native SMS)"
                      >
                        <MessageSquare className="w-3.5 h-3.5 text-blue-200" />
                        <span>إرسال SMS</span>
                      </button>

                      {/* Send WhatsApp Notice Button */}
                      <button
                        type="button"
                        onClick={() => openSendModal(v, false, 'whatsapp')}
                        className="flex-1 sm:flex-initial px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md shadow-emerald-950/50 flex items-center justify-center gap-1.5 transition active:scale-95"
                        title="إرسال إشعار المخالفة عبر واتساب مباشرة"
                      >
                        <Send className="w-3.5 h-3.5 text-emerald-200" />
                        <span>{v.firstSentAt ? 'إعادة بالواتساب' : 'إرسال واتساب'}</span>
                      </button>
                    </div>

                    {/* ESCALATION BUTTON: Second Warning if Overdue */}
                    {isOverdue && !isResolved && (
                      <div className="flex items-center gap-1.5 w-full sm:w-auto">
                        <button
                          type="button"
                          onClick={() => openSendModal(v, true, 'sms')}
                          className="flex-1 sm:flex-initial px-2.5 py-1.5 rounded-xl bg-rose-700 hover:bg-rose-600 text-white text-[11px] font-black shadow flex items-center justify-center gap-1 transition"
                          title="إرسال إنذار ثانٍ مشدد عبر رسالة SMS من شريحة الهاتف"
                        >
                          <MessageSquare className="w-3 h-3 text-rose-200" />
                          <span>إنذار SMS</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => openSendModal(v, true, 'whatsapp')}
                          className="flex-1 sm:flex-initial px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-rose-700 to-red-600 hover:from-rose-600 hover:to-red-500 text-white text-[11px] font-black shadow-lg shadow-rose-950 flex items-center justify-center gap-1 transition animate-bounce"
                          title="إرسال إنذار ثانٍ مشدد وتصعيد للإدارة العليا عبر واتساب"
                        >
                          <ShieldAlert className="w-3.5 h-3.5" />
                          <span>🚨 تصعيد واتساب</span>
                        </button>
                      </div>
                    )}

                    {/* Direct link preview & Delete action */}
                    <div className="flex items-center gap-2 self-center sm:self-end pt-1">
                      <a
                        href={getBaseResolveUrl(v)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[11px] text-teal-400 hover:text-teal-300 flex items-center gap-1 transition"
                      >
                        <ExternalLink className="w-3 h-3" />
                        <span>رابط إفادة الإنجاز</span>
                      </a>

                      <button
                        type="button"
                        onClick={() => setDeleteConfirmViolation(v)}
                        className="p-1 px-2 rounded-lg bg-slate-800 hover:bg-rose-950 text-rose-400 hover:text-rose-300 border border-slate-700/60 text-[11px] font-bold transition flex items-center gap-1"
                        title="حذف إشعار المخالفة من السجل الرسمي"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>حذف</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* SMS & WhatsApp Dispatch / Escalation Modal */}
      {selectedViolationForSend && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-3 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl my-auto animate-in fade-in zoom-in-95 duration-200">
            <div className={`p-4 border-b flex items-center justify-between ${
              isEscalationMode 
                ? 'bg-gradient-to-r from-rose-950 via-slate-900 to-slate-900 border-rose-800' 
                : dispatchChannel === 'sms'
                ? 'bg-gradient-to-r from-blue-950 via-slate-900 to-slate-900 border-blue-800'
                : 'bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-900 border-emerald-800'
            }`}>
              <div className="flex items-center gap-2.5">
                <div className={`p-2 rounded-xl text-white ${
                  isEscalationMode 
                    ? 'bg-rose-700' 
                    : dispatchChannel === 'sms'
                    ? 'bg-blue-600'
                    : 'bg-emerald-600'
                }`}>
                  {isEscalationMode ? (
                    <ShieldAlert className="w-5 h-5" />
                  ) : dispatchChannel === 'sms' ? (
                    <MessageSquare className="w-5 h-5" />
                  ) : (
                    <Send className="w-5 h-5" />
                  )}
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-100">
                    {isEscalationMode 
                      ? 'إرسال إنذار ثانٍ وتصعيد للإدارة العليا' 
                      : dispatchChannel === 'sms' 
                      ? 'إرسال إشعار SMS عبر شريحة الهاتف (Native Device SMS)' 
                      : 'إرسال إشعار مخالفة وتصحيح سلامة عبر واتساب'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    مستشفى آزال النموذجي • إدارة الأمن والسلامة
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedViolationForSend(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 space-y-3.5 text-xs text-right">
              {/* Channel Selector Tabs */}
              <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 gap-1">
                <button
                  type="button"
                  onClick={() => setDispatchChannel('sms')}
                  className={`flex-1 py-2 rounded-lg font-bold text-xs flex items-center justify-center gap-1.5 transition ${
                    dispatchChannel === 'sms'
                      ? 'bg-blue-600 text-white shadow'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>رسالة SMS (شريحة الهاتف)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setDispatchChannel('whatsapp')}
                  className={`flex-1 py-2 rounded-lg font-bold text-xs flex items-center justify-center gap-1.5 transition ${
                    dispatchChannel === 'whatsapp'
                      ? 'bg-emerald-600 text-white shadow'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Send className="w-4 h-4" />
                  <span>تطبيق الواتساب (WhatsApp)</span>
                </button>
              </div>

              {/* Phone input & Contact Picker Button */}
              <div>
                <label className="block text-slate-200 font-bold mb-1">
                  رقم هاتف المستلم / الجهة المكلفة (مفتاح اليمن +967):
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="tel"
                    dir="ltr"
                    value={recipientPhoneInput}
                    onChange={(e) => setRecipientPhoneInput(e.target.value)}
                    placeholder="9677XXXXXXXX"
                    className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 font-mono text-sm focus:outline-none focus:border-blue-500"
                  />
                  <button
                    type="button"
                    onClick={handlePickContact}
                    className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 font-bold border border-slate-700 flex items-center gap-1.5 transition shrink-0"
                    title="سحب الرقم تلقائياً من دفتر جهات اتصال الهاتف"
                  >
                    <User className="w-4 h-4" />
                    <span>جهات الاتصال</span>
                  </button>
                </div>
                <span className="text-[10px] text-slate-500 mt-1 block">
                  {dispatchChannel === 'sms'
                    ? 'يتم تنظيف الرقم آلياً وإضافة كود اليمن (967) ليتم استدعاؤه فوراً في خانة المستلم ببروتوكول SMS.'
                    : 'سيتم تنظيف الرقم تلقائياً وإضافة كود اليمن (967) لضمان توجيه الرسالة عبر تطبيق واتساب الأساسي.'}
                </span>
              </div>

              {/* Required Action Input */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-slate-200 font-bold">
                    الإجراء المطلوب (يتم تضمينه تلقائياً في نص الرسالة):
                  </label>
                  <VoiceDictationButton
                    value={requiredActionInput}
                    onChange={setRequiredActionInput}
                    title="إملاء صوتي للإجراء المطلوب"
                  />
                </div>
                <input
                  type="text"
                  value={requiredActionInput}
                  onChange={(e) => setRequiredActionInput(e.target.value)}
                  placeholder="معالجة وتصحيح وضع المخالفة فوراً وتأمين الموقع وإرفاق صورة الإنجاز..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 text-xs focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Message Preview */}
              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  نص الرسالة المجهز تلقائياً (WhatsApp & SMS):
                </label>
                <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 space-y-1 font-mono text-[11px] text-slate-200 whitespace-pre-wrap leading-relaxed max-h-48 overflow-y-auto">
                  {(() => {
                    const previewViolation = {
                      ...selectedViolationForSend,
                      requiredAction: requiredActionInput || selectedViolationForSend.requiredAction
                    };
                    const resolveUrl = getBaseResolveUrl(previewViolation);

                    return dispatchChannel === 'sms' ? (
                      isEscalationMode
                        ? generateEscalationWarningSMSText(previewViolation, resolveUrl)
                        : generateOfficialViolationSMSText(previewViolation, resolveUrl)
                    ) : (
                      isEscalationMode
                        ? generateEscalationWarningWhatsAppText(previewViolation, resolveUrl)
                        : generateOfficialViolationWhatsAppText(previewViolation, resolveUrl)
                    );
                  })()}
                </div>
              </div>

              {/* Protocol / Information Box */}
              {dispatchChannel === 'sms' ? (
                <div className="bg-blue-950/40 border border-blue-800/60 rounded-xl p-2.5 text-[11px] text-blue-200 flex items-start gap-2">
                  <Smartphone className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                  <div className="space-y-1 w-full">
                    <p className="font-bold">بروتوكول الإرسال المباشر من شريحة الهاتف (Native Device SMS):</p>
                    <div className="bg-slate-950/80 p-1.5 rounded text-[10px] text-blue-300 font-mono dir-ltr text-right break-all">
                      {getNativeSMSUri(
                        recipientPhoneInput || '967XXXXXXXXX',
                        isEscalationMode
                          ? generateEscalationWarningSMSText(selectedViolationForSend, getBaseResolveUrl(selectedViolationForSend))
                          : generateOfficialViolationSMSText(selectedViolationForSend, getBaseResolveUrl(selectedViolationForSend))
                      )}
                    </div>
                    <p className="text-[10px] text-blue-300/85">
                      ⚡ بمجرد الضغط، يفتح تطبيق الرسائل النصية الأساسي في هاتفك معبأً بالرقم والنص، لتضغط فقط على زر الإرسال عبر الشريحة.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="bg-emerald-950/30 border border-emerald-900/60 rounded-xl p-2.5 text-[11px] text-emerald-200">
                  ⚡ بمجرد الضغط على زر الإرسال، سيتم توثيق وقت وتاريخ الإرسال الفعلي آلياً (Timestamp) وفتح تطبيق واتساب الأساسي.
                </div>
              )}

              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-800/80">
                <button
                  type="button"
                  onClick={() => setSelectedViolationForSend(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold transition"
                >
                  إلغاء
                </button>
                {dispatchChannel === 'sms' ? (
                  <button
                    type="button"
                    onClick={handleSendViaSMS}
                    className={`px-5 py-2 rounded-xl text-white font-bold flex items-center gap-2 shadow-lg transition active:scale-95 ${
                      isEscalationMode 
                        ? 'bg-rose-600 hover:bg-rose-500 shadow-rose-950' 
                        : 'bg-blue-600 hover:bg-blue-500 shadow-blue-950'
                    }`}
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>
                      {isEscalationMode ? 'إرسال إنذار SMS عبر الشريحة' : 'إرسال SMS عبر شريحة الهاتف'}
                    </span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={handleSendViaWhatsApp}
                    className={`px-5 py-2 rounded-xl text-white font-bold flex items-center gap-2 shadow-lg transition active:scale-95 ${
                      isEscalationMode 
                        ? 'bg-rose-600 hover:bg-rose-500 shadow-rose-950' 
                        : 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-950'
                    }`}
                  >
                    <Send className="w-4 h-4" />
                    <span>
                      {isEscalationMode ? 'إرسال الإنذار الثاني فوراً' : 'إرسال عبر تطبيق واتساب'}
                    </span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
      {/* Delete Confirmation Modal */}
      {deleteConfirmViolation && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-3">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-5 text-right space-y-4 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 text-rose-400">
              <div className="p-2.5 rounded-xl bg-rose-950/80 border border-rose-800">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-100">تأكيد حذف إشعار المخالفة</h3>
                <span className="text-[11px] text-slate-400 font-mono">{deleteConfirmViolation.id} • {deleteConfirmViolation.department}</span>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              هل أنت متأكد من حذف هذا البند من السجل الرسمي؟
              <span className="block text-rose-300 font-semibold mt-1">
                ⚠️ تنبيه: سيتم حذف هذا السجل نهائياً وتحديث إجمالي العدادات ومؤشرات الامتثال فوراً.
              </span>
            </p>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setDeleteConfirmViolation(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition"
              >
                إلغاء التراجع
              </button>
              <button
                type="button"
                onClick={() => {
                  if (onDeleteViolation) {
                    onDeleteViolation(deleteConfirmViolation.id);
                  }
                  onLogAudit(
                    'VIOLATION_DELETED',
                    'حذف إشعار مخالفة سلامة',
                    `تم حذف إشعار المخالفة (${deleteConfirmViolation.id}) الخاص بقسم ${deleteConfirmViolation.department} بواسطة ${currentUser.name}.`
                  );
                  setDeleteConfirmViolation(null);
                }}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-lg shadow-rose-950"
              >
                <Trash2 className="w-4 h-4" />
                <span>تأكيد الحذف النهائي</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Follow-up Success Confirmation Dialog */}
      {followUpSuccessModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-3">
          <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-md p-5 text-right space-y-4 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 text-amber-400">
              <div className="p-3 rounded-2xl bg-amber-950/80 border border-amber-600/80 shadow-md">
                <BellRing className="w-6 h-6 text-amber-400 animate-bounce" />
              </div>
              <div>
                <h3 className="text-sm font-black text-slate-100">تم تسجيل وتوثيق إشعار المتابعة بنجاح</h3>
                <span className="text-[11px] text-amber-400 font-mono font-bold">
                  {followUpSuccessModal.violation.id} • {followUpSuccessModal.violation.department}
                </span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2 text-xs">
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                <span className="text-slate-400">عداد المتابعات والإنذارات:</span>
                <span className="px-2.5 py-0.5 rounded-full bg-amber-950 text-amber-300 font-mono font-black border border-amber-600">
                  إشعار رقم #{followUpSuccessModal.newCount}
                </span>
              </div>
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                <span className="text-slate-400">وقت وتاريخ التوثيق:</span>
                <span className="text-slate-200 font-mono font-bold">
                  {followUpSuccessModal.sentAt}
                </span>
              </div>
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                <span className="text-slate-400">حالة المهلة المحددة:</span>
                <span className="text-rose-400 font-bold">
                  {analyzeViolationDeadline(followUpSuccessModal.violation).overdueDaysText || 'متأخرة'}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">المكلف بالمعالجة:</span>
                <span className="text-amber-300 font-bold">
                  {followUpSuccessModal.violation.assignedToCustom || followUpSuccessModal.violation.assignedTo}
                </span>
              </div>
            </div>

            <p className="text-[11px] text-slate-300 leading-relaxed bg-amber-950/20 p-2.5 rounded-xl border border-amber-900/40">
              ⚡ تم تحديث عداد المتابعات وتوثيقه في سجل التدقيق الرسمي وسجل المتابعة التاريخي بنجاح. يمكنك إرسال التنبيه الآن للمكلف عبر الواتساب أو SMS إن رغبت.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setFollowUpSuccessModal(null)}
                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition"
              >
                إغلاق واكتفاء بالتوثيق
              </button>
              <button
                type="button"
                onClick={() => {
                  const targetVio = followUpSuccessModal.violation;
                  setFollowUpSuccessModal(null);
                  openSendModal(targetVio, true, 'whatsapp');
                }}
                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-950"
              >
                <Send className="w-3.5 h-3.5" />
                <span>إرسال تنبيه بالواتساب</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Executive Department Audit Report Modal for General Director */}
      {showExecutiveReportModal && (
        <ExecutiveDepartmentAuditReportModal
          selectedDepartment={departmentFilter}
          violations={violations}
          currentUser={currentUser}
          onClose={() => setShowExecutiveReportModal(false)}
          onLogAudit={(action, title, details) => onLogAudit(action, title, details)}
          allDepartments={departmentOptions}
        />
      )}

      {/* Detailed Violation & Attached Affidavit Statement Modal (إفادة المعالجة وتفاصيل الإشعار) */}
      {showDetailModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700/80 rounded-3xl w-full max-w-2xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden text-right">
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between gap-3 bg-slate-950/60">
              <div className="flex items-center gap-3">
                <div
                  className={`p-3 rounded-2xl border ${
                    isViolationResolved(showDetailModal)
                      ? 'bg-emerald-950/80 border-emerald-500/80 text-emerald-400'
                      : analyzeViolationDeadline(showDetailModal).isOverdue
                      ? 'bg-rose-950/80 border-rose-500/80 text-rose-400'
                      : 'bg-amber-950/80 border-amber-500/80 text-amber-400'
                  }`}
                >
                  {isViolationResolved(showDetailModal) ? (
                    <CheckCircle2 className="w-6 h-6" />
                  ) : analyzeViolationDeadline(showDetailModal).isOverdue ? (
                    <AlertOctagon className="w-6 h-6" />
                  ) : (
                    <Clock className="w-6 h-6" />
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-black text-slate-100">
                      {isViolationResolved(showDetailModal)
                        ? 'إفادة المعالجة وسجل إنجاز المخالفة'
                        : 'تفاصيل إشعار المخالفة والسلامة'}
                    </h3>
                    <span className="px-2 py-0.5 rounded-full font-mono font-bold text-xs bg-slate-800 text-amber-400 border border-slate-700">
                      {showDetailModal.id}
                    </span>
                  </div>
                  <span className="text-xs text-slate-400">
                    {showDetailModal.department} • {showDetailModal.locationDetail}
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowDetailModal(null)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-100 transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Scrollable Body */}
            <div className="p-4 sm:p-6 overflow-y-auto space-y-4 flex-1 text-xs">
              {/* Status Banner */}
              {isViolationResolved(showDetailModal) ? (
                <div className="p-3.5 rounded-2xl bg-emerald-950/50 border-2 border-emerald-500/70 text-emerald-100 flex items-center justify-between gap-3 shadow-md">
                  <div className="flex items-center gap-2.5">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                    <div>
                      <span className="font-black text-sm block text-emerald-300">
                        🟢 تمت المعالجة والإنجاز بنجاح (Resolved & Closed)
                      </span>
                      <span className="text-[11px] text-emerald-400/90 block mt-0.5">
                        تم تقديم إفادة المعالجة المعتمدة ونقل الإشعار إلى قائمة الإشعارات المنجزة.
                      </span>
                    </div>
                  </div>
                  {showDetailModal.resolvedAt && (
                    <span className="px-3 py-1 rounded-xl bg-emerald-900 border border-emerald-600 text-emerald-200 font-mono text-[11px] font-bold shrink-0">
                      {showDetailModal.resolvedAt}
                    </span>
                  )}
                </div>
              ) : analyzeViolationDeadline(showDetailModal).isOverdue ? (
                <div className="p-3.5 rounded-2xl bg-rose-950/70 border-2 border-rose-600 text-rose-100 flex items-center justify-between gap-3 shadow-md animate-pulse">
                  <div className="flex items-center gap-2.5">
                    <AlertOctagon className="w-5 h-5 text-rose-400 shrink-0" />
                    <div>
                      <span className="font-black text-sm block text-rose-200">
                        🔴 متجاوزة للمهلة المحددة (Overdue)
                      </span>
                      <span className="text-[11px] text-rose-300 block mt-0.5">
                        انتهت المهلة المحددة دون تسجيل إفادة إنجاز حتى الآن.
                      </span>
                    </div>
                  </div>
                  <span className="px-3 py-1 rounded-xl bg-rose-900 border border-rose-500 text-white font-mono text-[11px] font-black shrink-0">
                    تأخير: {analyzeViolationDeadline(showDetailModal).overdueDays} يوم
                  </span>
                </div>
              ) : (
                <div className="p-3.5 rounded-2xl bg-amber-950/50 border border-amber-600/70 text-amber-100 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <Clock className="w-5 h-5 text-amber-400 shrink-0" />
                    <div>
                      <span className="font-bold text-sm block text-amber-300">
                        🟡 قيد المتابعة النشطة ضمن المهلة
                      </span>
                      <span className="text-[11px] text-amber-400/90 block mt-0.5">
                        الإشعار مفتوح وبانتظار رفع إفادة المعالجة من القسم المكلف.
                      </span>
                    </div>
                  </div>
                  <span className="px-3 py-1 rounded-xl bg-amber-900 border border-amber-600 text-amber-200 font-mono text-[11px] font-bold shrink-0">
                    الاستحقاق: {showDetailModal.deadlineAt}
                  </span>
                </div>
              )}

              {/* Resolution Statement Section (إفادة المعالجة المرفقة) */}
              {isViolationResolved(showDetailModal) || showDetailModal.resolutionNote || showDetailModal.resolvedAt ? (
                <div className="bg-emerald-950/30 border-2 border-emerald-500/80 rounded-2xl p-4 sm:p-5 space-y-3.5 shadow-lg">
                  <div className="flex items-center justify-between border-b border-emerald-800/80 pb-3">
                    <div className="flex items-center gap-2 text-emerald-300 font-black text-sm">
                      <FileText className="w-5 h-5 text-emerald-400" />
                      <span>نص إفادة المعالجة والإنجاز المرفقة:</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        const noteText = showDetailModal.resolutionNote || 'تمت المعالجة والإنجاز بنجاح.';
                        navigator.clipboard?.writeText(noteText);
                        alert('تم نسخ نص إفادة المعالجة للحافظة بنجاح.');
                      }}
                      className="px-2.5 py-1 rounded-lg bg-emerald-900 hover:bg-emerald-800 text-emerald-200 text-[11px] font-bold flex items-center gap-1 transition cursor-pointer"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      <span>نسخ النص</span>
                    </button>
                  </div>

                  {/* Statement Body Text */}
                  <div className="p-3.5 rounded-xl bg-slate-950 border border-emerald-700/60 text-emerald-100 text-sm leading-relaxed whitespace-pre-wrap font-medium select-text">
                    {showDetailModal.resolutionNote || 'تمت معالجة وتصحيح وضع المخالفة بالكامل وفق معايير واشتراطات السلامة وإدارة المرافق (FMS/CBAHI).'}
                  </div>

                  {/* Statement Meta Info: Date & Executor */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1">
                    <div className="p-2.5 rounded-xl bg-slate-900/90 border border-emerald-800/60 flex items-center justify-between">
                      <span className="text-slate-400">تاريخ ووقت الإنجاز الفعلي:</span>
                      <strong className="text-emerald-300 font-mono font-bold">
                        {showDetailModal.resolvedAt || 'موثق بالنظام'}
                      </strong>
                    </div>
                    <div className="p-2.5 rounded-xl bg-slate-900/90 border border-emerald-800/60 flex items-center justify-between">
                      <span className="text-slate-400">منفذ المعالجة / مقدم الإفادة:</span>
                      <strong className="text-emerald-300 font-bold">
                        {showDetailModal.resolvedBy || 'المسؤول المناوب'}
                      </strong>
                    </div>
                  </div>

                  {/* Resolution Proof Photos (صورة قبل وصورة بعد الإنجاز) */}
                  <div className="space-y-2 pt-2 border-t border-emerald-800/80">
                    <span className="text-xs font-bold text-slate-300 block">
                      📷 صور التوثيق والمقارنة (قبل وبعد المعالجة):
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {/* Before Photo */}
                      <div className="space-y-1">
                        <span className="text-[11px] text-slate-400 block font-semibold">
                          صورة المخالفة الأصلية (قبل المعالجة):
                        </span>
                        {(showDetailModal as any).photoUrl || showDetailModal.beforePhotoUrl ? (
                          <img
                            src={(showDetailModal as any).photoUrl || showDetailModal.beforePhotoUrl}
                            alt="صورة المخالفة قبل المعالجة"
                            className="w-full h-44 object-cover rounded-xl border border-slate-700"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <div className="w-full h-44 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center text-slate-500 text-xs">
                            لا توجد صورة أولية مرفقة
                          </div>
                        )}
                      </div>

                      {/* After Photo */}
                      <div className="space-y-1">
                        <span className="text-[11px] text-emerald-400 block font-bold flex items-center gap-1">
                          <Check className="w-3.5 h-3.5" />
                          <span>صورة إثبات الإنجاز المرفقة مع الإفادة (بعد المعالجة):</span>
                        </span>
                        {showDetailModal.afterPhotoUrl ? (
                          <img
                            src={showDetailModal.afterPhotoUrl}
                            alt="صورة إثبات الإنجاز بعد المعالجة"
                            className="w-full h-44 object-cover rounded-xl border-2 border-emerald-500 shadow-md"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <div className="w-full h-44 rounded-xl bg-slate-950 border border-dashed border-emerald-800 flex flex-col items-center justify-center text-emerald-400/80 text-xs p-3 text-center">
                            <span>تم توثيق الإفادة كتابياً بنجاح دون إرفاق صورة فوتوغرافية</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-4 rounded-2xl bg-slate-950 border border-amber-900/50 space-y-2 text-center">
                  <span className="text-amber-400 font-bold block text-sm">
                    لم تُسجل إفادة معالجة لهذا الإشعار بعد
                  </span>
                  <p className="text-slate-400 text-xs leading-relaxed max-w-md mx-auto">
                    يمكنك إرسال تنبيه مباشر للمكلف عبر الواتساب لإرفاق الإفادة، أو فتح بوابة تسجيل الإفادة الآن لتسجيلها يدوياً.
                  </p>
                  <div className="pt-2 flex items-center justify-center gap-2">
                    <a
                      href={getBaseResolveUrl(showDetailModal)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3.5 py-1.5 rounded-xl bg-teal-700 hover:bg-teal-600 text-white font-bold text-xs flex items-center gap-1.5 transition"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>فتح نموذج تسجيل الإفادة</span>
                    </a>
                  </div>
                </div>
              )}

              {/* General Violation Details Grid */}
              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3">
                <h4 className="text-xs font-bold text-slate-300 border-b border-slate-800 pb-2">
                  بيانات المخالفة والمكلف بالمعالجة:
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                  <div>
                    <span className="text-slate-400 block text-[11px]">وصف الملاحظة / المخالفة:</span>
                    <p className="text-slate-200 font-medium mt-0.5 leading-relaxed bg-slate-900 p-2 rounded-lg border border-slate-800">
                      {showDetailModal.description}
                    </p>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[11px]">الإجراء التصحيحي المطلوب:</span>
                    <p className="text-amber-300 font-medium mt-0.5 leading-relaxed bg-slate-900 p-2 rounded-lg border border-slate-800">
                      {showDetailModal.requiredAction || 'معالجة وتصحيح وضع المخالفة فوراً وتأمين الموقع ورفع إفادة الإنجاز'}
                    </p>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[11px]">المكلف بالمعالجة:</span>
                    <span className="text-slate-200 font-bold block mt-0.5">
                      {showDetailModal.assignedToCustom || showDetailModal.assignedTo}
                      {showDetailModal.recipientPhone && ` (📞 ${showDetailModal.recipientPhone})`}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[11px]">المهلة وتاريخ الاستحقاق:</span>
                    <span className="text-slate-200 font-mono font-bold block mt-0.5">
                      {showDetailModal.deadlineAt} ({showDetailModal.deadlineHours || 24} ساعة)
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Footer Actions */}
            <div className="p-4 border-t border-slate-800 bg-slate-950/60 flex flex-wrap items-center justify-between gap-2">
              <div className="flex flex-wrap items-center gap-2">
                {(isViolationResolved(showDetailModal) || showDetailModal.resolutionNote || showDetailModal.resolvedAt) && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      setClosureModalNotice({
                        id: showDetailModal.id,
                        notice_number: showDetailModal.id,
                        department_name: showDetailModal.department,
                        hazard_description: showDetailModal.description,
                        action_taken: showDetailModal.resolutionNote || 'تمت المعالجة والإنجاز بنجاح',
                        completed_by: showDetailModal.resolvedBy || showDetailModal.assignedToCustom || showDetailModal.assignedTo || 'المسؤول الميداني',
                        completed_at: showDetailModal.resolvedAt || showDetailModal.createdAt,
                        status: isViolationResolved(showDetailModal) ? 'مغلق ومعتمد نهائياً' : 'قيد المراجعة'
                      });
                    }}
                    className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-md cursor-pointer"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>الرد على الإفادة واعتمادها</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => {
                    const printUrl = getBaseResolveUrl(showDetailModal);
                    window.open(printUrl, '_blank');
                  }}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-4 h-4 text-teal-400" />
                  <span>طباعة بطاقة الإشعار والإفادة</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const text = `*إفادة إنجاز مخالفة سلامة - مستشفى آزال النموذجي*\n` +
                      `رقم الإشعار: ${showDetailModal.id}\n` +
                      `القسم: ${showDetailModal.department}\n` +
                      `الحالة: ${isViolationResolved(showDetailModal) ? 'تمت المعالجة والإغلاق' : 'قيد المتابعة'}\n` +
                      (showDetailModal.resolutionNote ? `نص الإفادة: ${showDetailModal.resolutionNote}\n` : '') +
                      (showDetailModal.resolvedAt ? `تاريخ الإنجاز: ${showDetailModal.resolvedAt}\n` : '') +
                      (showDetailModal.resolvedBy ? `منفذ المعالجة: ${showDetailModal.resolvedBy}\n` : '');
                    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`, '_blank');
                  }}
                  className="px-3.5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-md shadow-emerald-950 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>مشاركة الإفادة بالواتساب</span>
                </button>
              </div>

              <button
                type="button"
                onClick={() => setShowDetailModal(null)}
                className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition cursor-pointer"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CompletedActionResponseModal (Strictly isolated via closureModalNotice) */}
      {closureModalNotice && (
        <CompletedActionResponseModal
          isOpen={Boolean(closureModalNotice)}
          action={closureModalNotice}
          onClose={() => {
            setClosureModalNotice(null);
          }}
          onSuccess={() => {
            if (closureModalNotice) {
              const targetVio = violations.find(v => v.id === closureModalNotice.id);
              if (targetVio) {
                onUpdateViolation({
                  ...targetVio,
                  status: 'resolved',
                  resolutionNote: closureModalNotice.action_taken || targetVio.resolutionNote,
                  resolvedAt: targetVio.resolvedAt || new Date().toISOString()
                });
                onLogAudit('UPDATE', 'اعتماد إفادة إنجاز', `تم اعتماد وإغلاق إفادة المخالفة ${targetVio.id} بواسطة م/ نجيب غازي`);
              }
            }
            setClosureModalNotice(null);
          }}
        />
      )}
    </div>
  );
};
