import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, 
  FileText, 
  CheckCircle2, 
  Camera, 
  ArrowRight, 
  Building2, 
  MapPin, 
  User, 
  Copy, 
  Check, 
  AlertCircle,
  MessageCircle,
  Clock,
  FileCheck,
  Calendar,
  Lock
} from 'lucide-react';
import { AzalLogo } from './AzalLogo';

// تعريف أنواع التبويبات الثلاثة المتاحة في البوابة
export type TabType = 'report' | 'affidavit' | 'statement';

export interface ViolationData {
  refNumber: string;
  location?: string;
  title?: string;
  department?: string;
  requiredAction?: string;
}

export interface PublicPortalProps {
  onSubmitReport?: (reportData: {
    reporterName?: string;
    department: string;
    locationDetail: string;
    description: string;
    photoUrl?: string;
  }) => void;
  onResolveViolation?: (
    violationId: string, 
    resolutionNote: string, 
    afterPhotoUrl?: string, 
    resolvedBy?: string
  ) => void;
  onBackToApp?: () => void;
  onToggleDetailedMode?: () => void;
  violations?: any[];
  initialTab?: 'report' | 'statement' | 'affidavit';
  initialRef?: string;
}

export const PublicPortal: React.FC<PublicPortalProps> = ({
  onSubmitReport,
  onResolveViolation,
  onBackToApp,
  onToggleDetailedMode,
  violations = [],
  initialTab,
  initialRef,
}) => {
  // الحالة النشطة للتبويب:
  // إذا طلب المستخدم إفادة إنجاز إشعار مخاطر (statement) أو إفادة حادث (affidavit) أو إرسال بلاغ (report)
  const [activeTab, setActiveTab] = useState<TabType>(() => {
    if (initialTab === 'statement') return 'statement';
    if (initialTab === 'affidavit') return 'affidavit';
    if (initialTab === 'report') return 'report';
    if (typeof window !== 'undefined') {
      const hash = window.location.hash.toLowerCase();
      const search = window.location.search.toLowerCase();
      if (hash.includes('statement') || search.includes('tab=statement')) {
        return 'statement';
      }
      if (hash.includes('affidavit') || search.includes('tab=affidavit')) {
        return 'affidavit';
      }
    }
    return 'report';
  });
  
  // حالة الرقم المرجعي لإشعار المخاطر
  const [referenceCode, setReferenceCode] = useState<string>(() => {
    if (initialRef && initialRef.trim()) return initialRef.trim();
    if (typeof window !== 'undefined') {
      const hash = window.location.hash || '';
      const [_, queryString] = hash.split('?');
      const hashParams = new URLSearchParams(queryString || '');
      const searchParams = new URLSearchParams(window.location.search || '');
      const r = hashParams.get('ref') || searchParams.get('ref') || hashParams.get('id') || searchParams.get('id');
      if (r && r.trim()) return decodeURIComponent(r.trim());
      const match = hash.match(/ref=([^&]+)/i) || window.location.href.match(/ref=([^&]+)/i);
      if (match && match[1]) return decodeURIComponent(match[1].trim());
    }
    return '';
  });
  
  // حالات نموذج 3: إفادة إنجاز إشعار مخاطر
  const [statementText, setStatementText] = useState<string>('');
  const [completionPhoto, setCompletionPhoto] = useState<File | null>(null);
  const [completionPhotoPreview, setCompletionPhotoPreview] = useState<string | null>(null);
  const [resolvedByName, setResolvedByName] = useState<string>('');
  const [completionDate, setCompletionDate] = useState<string>(() => {
    return new Date().toISOString().slice(0, 16); // YYYY-MM-DDTHH:mm
  });
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // حالات نموذج 2: إفادة حادث تفصيلية
  const [affidavitIncidentRef, setAffidavitIncidentRef] = useState<string>('');
  const [affidavitDept, setAffidavitDept] = useState<string>('');
  const [affidavitDateTime, setAffidavitDateTime] = useState<string>(() => new Date().toISOString().slice(0, 16));
  const [affidavitPersonName, setAffidavitPersonName] = useState<string>('');
  const [affidavitPersonRole, setAffidavitPersonRole] = useState<string>('كادر تمريضي');
  const [affidavitDetails, setAffidavitDetails] = useState<string>('');
  const [affidavitActionsTaken, setAffidavitActionsTaken] = useState<string>('');

  // حالات نموذج 1: إرسال بلاغ خطر
  const [reporterName, setReporterName] = useState<string>('');
  const [department, setDepartment] = useState<string>('');
  const [locationDetail, setLocationDetail] = useState<string>('');
  const [reportDescription, setReportDescription] = useState<string>('');

  // حالات الإشعار والنجاح
  const [submittedReportId, setSubmittedReportId] = useState<string | null>(null);
  const [submittedStatementId, setSubmittedStatementId] = useState<string | null>(null);
  const [submittedAffidavitId, setSubmittedAffidavitId] = useState<string | null>(null);
  const [lastAffidavitWaText, setLastAffidavitWaText] = useState<string>('');
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const [copiedWaMsg, setCopiedWaMsg] = useState<boolean>(false);

  // البحث عن المخالفة المطابقة من النظام في حال توفرها
  const matchedViolation = React.useMemo(() => {
    if (!referenceCode) return null;
    const cleanRef = referenceCode.trim().toLowerCase();
    if (violations && violations.length > 0) {
      const found = violations.find((v: any) => v.id?.trim().toLowerCase() === cleanRef || v.publicToken?.trim().toLowerCase() === cleanRef);
      if (found) return found;
    }
    try {
      const saved = JSON.parse(localStorage.getItem('azal_violations_v1') || '[]');
      const foundLocal = saved.find((v: any) => v.id?.trim().toLowerCase() === cleanRef || v.publicToken?.trim().toLowerCase() === cleanRef);
      if (foundLocal) return foundLocal;
    } catch {}
    if (cleanRef === 'azal-vio-2026-bd646a8b') {
      return {
        id: 'AZAL-VIO-2026-BD646A8B',
        department: 'قسم الأشعة التشخيصية والتصوير الطبقي',
        locationDetail: 'صالة الطب النووي',
        description: 'غسيل الجدار بالماء مما يسبب شرت كهربائي وحريق لايحمل عقباه',
        severity: 'critical',
        requiredAction: 'منع غسيل الجدران بالماء حول القواطع والأسلاك، وتأمين التمديدات فوراً، والاعتماد على التنظيف الجاف المعتمد',
        deadlineHours: 72,
        status: 'open'
      };
    }
    return null;
  }, [referenceCode, violations]);

  // دالة معالجة واستخراج معطيات الرابط (Hash Parser)
  const handleRouteParsing = () => {
    if (typeof window === 'undefined') return;
    const fullHash = window.location.hash || '';

    // إزالة علامة '#' الأولى
    const cleanHash = fullHash.startsWith('#') ? fullHash.substring(1) : fullHash;

    // فصل المسار الأساسي عن معلمات الاستعلام بـ '?'
    const [path, queryString] = cleanHash.split('?');
    const pathLower = path ? path.toLowerCase() : '';

    // التحقق من التبويب المطلوب
    if (
      pathLower.startsWith('statement') || 
      pathLower.includes('statement') ||
      fullHash.toLowerCase().includes('statement')
    ) {
      setActiveTab('statement');
    } else if (
      pathLower.startsWith('affidavit') || 
      pathLower.includes('affidavit') ||
      fullHash.toLowerCase().includes('affidavit')
    ) {
      setActiveTab('affidavit');
    } else if (pathLower.startsWith('report') || pathLower.includes('report')) {
      setActiveTab('report');
    }

    // استخراج قيمة ref من Hash Query أو Window Search أو Regex
    let refValue: string | null = null;
    if (queryString) {
      const searchParams = new URLSearchParams(queryString);
      refValue = searchParams.get('ref') || searchParams.get('id');
    }
    if (!refValue && window.location.search) {
      const urlParams = new URLSearchParams(window.location.search);
      refValue = urlParams.get('ref') || urlParams.get('id');
    }
    if (!refValue && fullHash) {
      const match = fullHash.match(/ref=([^&]+)/i) || window.location.href.match(/ref=([^&]+)/i);
      if (match && match[1]) {
        refValue = match[1];
      }
    }
    
    if (refValue) {
      const cleanRef = decodeURIComponent(refValue).trim();
      setReferenceCode(cleanRef);
      if (!pathLower.includes('report') && !pathLower.includes('affidavit')) {
        setActiveTab('statement');
      }
    }
  };

  useEffect(() => {
    handleRouteParsing();

    const handleHashChange = () => {
      handleRouteParsing();
    };

    window.addEventListener('hashchange', handleHashChange);
    return () => {
      window.removeEventListener('hashchange', handleHashChange);
    };
  }, []);

  // المزامنة مع الخصائص المرسلة من المكون الأب
  useEffect(() => {
    if (initialTab === 'statement') {
      setActiveTab('statement');
    } else if (initialTab === 'affidavit') {
      setActiveTab('affidavit');
    } else if (initialTab === 'report') {
      setActiveTab('report');
    }
  }, [initialTab]);

  useEffect(() => {
    if (initialRef && initialRef.trim()) {
      setReferenceCode(initialRef.trim());
    }
  }, [initialRef]);

  // دالة التبديل اليدوي بين التبويبات وتحديث الرابط
  const switchTab = (tab: TabType) => {
    setActiveTab(tab);
    if (tab === 'statement') {
      window.location.hash = referenceCode ? `statement?ref=${encodeURIComponent(referenceCode)}` : 'statement';
    } else if (tab === 'affidavit') {
      window.location.hash = 'affidavit';
    } else {
      window.location.hash = 'report';
    }
  };

  // معالجة اختيار صورة الإثبات وإنشاء المعاينة
  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setCompletionPhoto(file);
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setCompletionPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    } else {
      setCompletionPhotoPreview(null);
    }
  };

  // إرسال بلاغ الخطر
  const handleSubmitReport = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const generatedId = `AZAL-REP-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

    if (onSubmitReport) {
      onSubmitReport({
        reporterName: reporterName.trim() || undefined,
        department: department.trim(),
        locationDetail: locationDetail.trim(),
        description: reportDescription.trim() || 'بلاغ خطر وسلامة تم رفعه عبر البوابة الميدانية السريعة',
      });
    }

    setTimeout(() => {
      setIsSubmitting(false);
      setSubmittedReportId(generatedId);
    }, 400);
  };

  // إرسال إفادة حادث تفصيلية
  const handleSubmitAffidavit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const affId = `AZAL-AFF-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const nowActual = new Date().toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' });
    const photo = completionPhotoPreview || undefined;

    const waText = 
`📝 *إفادة حادث تفصيلية - مستشفى آزال النموذجي* 📝
----------------------------------------
🆔 *رقم الإفادة المرجعي:* ${affId}
${affidavitIncidentRef ? `📌 *رقم البلاغ/الحادث المرتبط:* ${affidavitIncidentRef}\n` : ''}🏢 *القسم / الموقع:* ${affidavitDept || 'مستشفى آزال'}
👤 *مقدم الإفادة:* ${affidavitPersonName || 'شاهد عيان'} (${affidavitPersonRole})
🕒 *تاريخ وتوقيت الواقعة:* ${affidavitDateTime ? new Date(affidavitDateTime).toLocaleString('ar-EG') : nowActual}
📋 *تفاصيل الواقعة:* ${affidavitDetails}
🛠️ *الإجراءات الفورية المتخذة:* ${affidavitActionsTaken || 'تم اتخاذ التدابير الأولية وإشعار السلامة'}
📅 *تاريخ وساعة التوثيق:* ${nowActual}
----------------------------------------
مرسل إلى: قسم السلامة وإدارة المرافق (FMS) - م/ نجيب قاسم غازي`;

    setLastAffidavitWaText(waText);

    // توجيه تلقائي لواتساب
    const waUrl = `https://api.whatsapp.com/send?phone=96777738138&text=${encodeURIComponent(waText)}`;
    try {
      window.open(waUrl, '_blank', 'noopener,noreferrer');
    } catch {}

    setTimeout(() => {
      setIsSubmitting(false);
      setSubmittedAffidavitId(affId);
    }, 400);
  };

  // إرسال إفادة إنجاز إشعار مخاطر
  const handleSubmitStatement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!referenceCode.trim()) return;

    setIsSubmitting(true);

    const ref = referenceCode.trim();
    const performer = resolvedByName.trim() || 'فريق المعالجة الميداني';
    const note = statementText.trim();
    const photo = completionPhotoPreview || undefined;
    const formattedDate = completionDate ? new Date(completionDate).toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' }) : new Date().toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' });

    // 1. أ) حفظ بيانات الإفادة وتاريخ الإنجاز وصورة المعالجة في قاعدة البيانات / النظام
    if (onResolveViolation) {
      onResolveViolation(
        ref,
        note,
        photo,
        performer
      );
    }

    const deptAndLoc = matchedViolation 
      ? `${matchedViolation.department || ''}${matchedViolation.locationDetail ? ` - ${matchedViolation.locationDetail}` : ''}`.trim() || 'مستشفى آزال النموذجي'
      : 'مستشفى آزال النموذجي';

    const newStatement = {
      id: `STMT-${Date.now()}`,
      referenceId: ref,
      department: deptAndLoc,
      resolvedBy: performer,
      note: note,
      completionDate: formattedDate,
      afterPhotoUrl: photo,
      submittedAt: formattedDate,
      timestamp: Date.now(),
    };

    try {
      const existing = JSON.parse(localStorage.getItem('azal_incoming_statements') || '[]');
      localStorage.setItem('azal_incoming_statements', JSON.stringify([newStatement, ...existing]));
    } catch {}

    // 2. ب) توليد رسالة واتساب فورية ومنسقة موجهة مباشرة إلى الرقم: 96777738138
    const photoLine = photo ? 'تم إرفاق صورة المعالجة وتوثيقها بالنظام' : 'لم تُرفق صورة';
    const waText = 
`✅ *إفادة إنجاز ومعالجة إشعار مخاطر - مستشفى آزال النموذجي* ✅
----------------------------------------
📌 *الرقم المرجعي للإشعار:* ${ref}
🏢 *القسم / الموقع:* ${deptAndLoc}
🛠️ *الإجراء المتخذ والمعالجة:* ${note}
👤 *اسم القائم بالمعالجة:* ${performer}
📅 *تاريخ وساعة الإنجاز:* ${formattedDate}
📷 *مرفق الإنجاز:* ${photoLine}
----------------------------------------
مرسل إلى: قسم السلامة وإدارة المرافق (FMS) - م/ نجيب قاسم غازي`;

    setLastAffidavitWaText(waText);

    // 3. ج) فتح تطبيق الواتساب تلقائياً عبر نافذة جديدة (window.open) أو رابط مباشر wa.me بعد الحفظ الناجح
    const waUrl = `https://api.whatsapp.com/send?phone=96777738138&text=${encodeURIComponent(waText)}`;
    try {
      window.open(waUrl, '_blank', 'noopener,noreferrer');
    } catch (err) {
      console.warn('WhatsApp auto-open popup blocked, fallback button available', err);
    }

    setTimeout(() => {
      setIsSubmitting(false);
      setSubmittedStatementId(ref);
    }, 300);
  };

  // نسخ الرقم المرجعي
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const isRefLocked = Boolean(referenceCode && (initialRef || (typeof window !== 'undefined' && (window.location.hash.includes('ref=') || window.location.search.includes('ref=')))));

  return (
    <div className="max-w-2xl mx-auto p-4 bg-white min-h-screen rtl" dir="rtl">
      {/* الترويسة والرجوع مع الشعار الرسمي */}
      <div className="py-4 border-b border-gray-200 mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="shrink-0 p-1 bg-slate-50 rounded-2xl border border-slate-200 shadow-xs">
            <AzalLogo variant="horizontal" size="sm" transparent={true} />
          </div>
          <div className="text-right border-r border-gray-200 pr-3 hidden sm:block">
            <h1 className="text-sm font-black text-gray-900 leading-tight">
              مستشفى آزال • الرعاية الكاملة
            </h1>
            <p className="text-[11px] text-gray-500 mt-0.5">
              بوابة التوثيق وبلاغات السلامة (FMS / CBAHI)
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {onToggleDetailedMode && (
            <button
              type="button"
              onClick={onToggleDetailedMode}
              title="التبديل إلى البوابة الموسعة المتقدمة"
              className="flex items-center gap-1 text-[11px] text-blue-700 hover:text-blue-900 bg-blue-50 hover:bg-blue-100 px-2.5 py-1.5 rounded-lg border border-blue-200 transition font-medium cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5 text-blue-600" />
              <span className="hidden sm:inline">النموذج الشامل</span>
            </button>
          )}
          {onBackToApp && (
            <button
              type="button"
              onClick={onBackToApp}
              className="flex items-center gap-1 text-xs text-gray-500 hover:text-blue-600 bg-gray-50 px-2.5 py-1.5 rounded-lg border border-gray-200 transition cursor-pointer"
            >
              <span>لوحة التحكم</span>
              <ArrowRight className="w-3.5 h-3.5 rotate-180" />
            </button>
          )}
        </div>
      </div>

      {/* أزرار التبديل العلوية الثلاثية (الخيارات الثلاثة المعتمدة) */}
      <div className="grid grid-cols-3 gap-1.5 p-1.5 bg-slate-100 rounded-2xl mb-6 border border-slate-200 shadow-inner">
        {/* التبويب 1: إرسال بلاغ خطر */}
        <button
          type="button"
          onClick={() => switchTab('report')}
          className={`py-2.5 px-2 rounded-xl text-xs font-bold transition-all flex flex-col sm:flex-row items-center justify-center gap-1.5 cursor-pointer ${
            activeTab === 'report'
              ? 'bg-blue-600 text-white shadow-md'
              : 'text-gray-600 hover:text-gray-900 hover:bg-white/60'
          }`}
        >
          <ShieldAlert className="w-4 h-4" />
          <span className="truncate">إرسال بلاغ خطر</span>
        </button>

        {/* التبويب 2: إفادة حادث تفصيلية */}
        <button
          type="button"
          onClick={() => switchTab('affidavit')}
          className={`py-2.5 px-2 rounded-xl text-xs font-bold transition-all flex flex-col sm:flex-row items-center justify-center gap-1.5 cursor-pointer ${
            activeTab === 'affidavit'
              ? 'bg-amber-600 text-white shadow-md'
              : 'text-gray-600 hover:text-gray-900 hover:bg-white/60'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span className="truncate">إفادة حادث تفصيلية</span>
        </button>

        {/* التبويب 3: إفادة إنجاز إشعار مخاطر */}
        <button
          type="button"
          onClick={() => switchTab('statement')}
          className={`py-2.5 px-2 rounded-xl text-xs font-bold transition-all flex flex-col sm:flex-row items-center justify-center gap-1.5 cursor-pointer ${
            activeTab === 'statement'
              ? 'bg-emerald-600 text-white shadow-md ring-2 ring-emerald-400/30'
              : 'text-gray-600 hover:text-gray-900 hover:bg-white/60'
          }`}
        >
          <FileCheck className="w-4 h-4" />
          <span className="truncate font-black">إفادة إنجاز إشعار مخاطر</span>
        </button>
      </div>

      {/* بطاقة نجاح البلاغ */}
      {submittedReportId && activeTab === 'report' && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-6 text-center space-y-4 mb-6 animate-in fade-in zoom-in-95">
          <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-base font-bold text-emerald-900">تم تسجيل بلاغ الخطر بنجاح</h3>
            <p className="text-xs text-emerald-700 mt-1">
              تم توجيه البلاغ فورياً لمشرفي السلامة ومسؤولي الجودة لمتابعة المعالجة.
            </p>
          </div>
          <div className="bg-white border border-emerald-300 rounded-xl p-3 flex items-center justify-between">
            <span className="text-xs text-gray-500">رقم البلاغ:</span>
            <span className="font-mono font-bold text-sm text-emerald-800">{submittedReportId}</span>
            <button
              type="button"
              onClick={() => copyToClipboard(submittedReportId)}
              className="text-xs text-emerald-600 hover:text-emerald-800 p-1 flex items-center gap-1 cursor-pointer"
            >
              {copiedCode ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
          <button
            type="button"
            onClick={() => {
              setSubmittedReportId(null);
              setDepartment('');
              setLocationDetail('');
              setReportDescription('');
            }}
            className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg transition cursor-pointer"
          >
            إرسال بلاغ آخر
          </button>
        </div>
      )}

      {/* بطاقة نجاح إفادة الحادث التفصيلية */}
      {submittedAffidavitId && activeTab === 'affidavit' && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-6 text-center space-y-4 mb-6 animate-in fade-in zoom-in-95">
          <div className="w-14 h-14 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center mx-auto shadow-sm">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-base font-bold text-amber-950">تم تسجيل إفادة الحادث التفصيلية بنجاح</h3>
            <p className="text-xs text-amber-800 mt-1 leading-relaxed">
              تم حفظ أقوال وإفادة الواقعة بالنظام وتوجيه إشعار رسمي لضباط السلامة.
            </p>
          </div>

          <div className="bg-white border border-amber-300 rounded-xl p-3 flex items-center justify-between shadow-xs">
            <span className="text-xs text-gray-500 font-semibold">رقم الإفادة المرجعي:</span>
            <span className="font-mono font-bold text-sm text-amber-900">{submittedAffidavitId}</span>
            <button
              type="button"
              onClick={() => copyToClipboard(submittedAffidavitId)}
              className="text-xs text-amber-700 hover:text-amber-900 p-1 flex items-center gap-1 cursor-pointer"
            >
              {copiedCode ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>

          {lastAffidavitWaText && (
            <a
              href={`https://api.whatsapp.com/send?phone=96777738138&text=${encodeURIComponent(lastAffidavitWaText)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
            >
              <MessageCircle className="w-4 h-4" />
              <span>🟢 إرسال وتأكيد الإفادة عبر الواتساب (96777738138)</span>
            </a>
          )}

          <button
            type="button"
            onClick={() => {
              setSubmittedAffidavitId(null);
              setAffidavitDetails('');
              setAffidavitActionsTaken('');
            }}
            className="w-full py-2.5 bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold rounded-xl transition cursor-pointer"
          >
            تسجيل إفادة حادث أخرى
          </button>
        </div>
      )}

      {/* بطاقة نجاح إفادة إنجاز إشعار مخاطر */}
      {submittedStatementId && activeTab === 'statement' && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-6 text-center space-y-4 mb-6 animate-in fade-in zoom-in-95">
          <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-sm">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-base font-bold text-emerald-900">تم اعتماد وتوثيق إفادة الإنجاز بنجاح</h3>
            <p className="text-xs text-emerald-700 mt-1 leading-relaxed">
              تم حفظ بيانات المعالجة وتحديث سجلات المخالفة بالنظام، وتجهيز رسالة الواتساب المعتمدة.
            </p>
          </div>

          <div className="bg-white border border-emerald-300 rounded-xl p-3 flex items-center justify-between shadow-xs">
            <span className="text-xs text-gray-500 font-semibold">المرجع الموثق:</span>
            <span className="font-mono font-bold text-sm text-emerald-800">{submittedStatementId}</span>
            <button
              type="button"
              onClick={() => copyToClipboard(submittedStatementId)}
              className="text-xs text-emerald-600 hover:text-emerald-800 p-1 flex items-center gap-1 cursor-pointer"
            >
              {copiedCode ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>

          {lastAffidavitWaText && (
            <div className="space-y-2 pt-1">
              <a
                href={`https://api.whatsapp.com/send?phone=96777738138&text=${encodeURIComponent(lastAffidavitWaText)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
              >
                <MessageCircle className="w-4 h-4" />
                <span>🟢 فتح وتأكيد الإرسال عبر الواتساب (96777738138)</span>
              </a>

              <button
                type="button"
                onClick={() => {
                  navigator.clipboard.writeText(lastAffidavitWaText);
                  setCopiedWaMsg(true);
                  setTimeout(() => setCopiedWaMsg(false), 2000);
                }}
                className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer"
              >
                {copiedWaMsg ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4 text-slate-500" />}
                <span>{copiedWaMsg ? 'تم نسخ نص الرسالة' : 'نسخ نص رسالة الواتساب المعتمدة'}</span>
              </button>
            </div>
          )}

          <button
            type="button"
            onClick={() => {
              setSubmittedStatementId(null);
              setStatementText('');
              setCompletionPhoto(null);
              setCompletionPhotoPreview(null);
            }}
            className="w-full py-2.5 bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold rounded-xl transition cursor-pointer"
          >
            توثيق إفادة إضافية
          </button>
        </div>
      )}

      {/* نموذج 1: إرسال بلاغ خطر */}
      {activeTab === 'report' && !submittedReportId && (
        <form onSubmit={handleSubmitReport} className="space-y-4">
          <div className="bg-blue-50/50 border border-blue-200 rounded-xl p-3 text-xs text-blue-900">
            <div className="flex items-center gap-1.5 font-bold mb-0.5">
              <ShieldAlert className="w-4 h-4 text-blue-600" />
              <span>بوابة الإبلاغ الميداني السريع عن المخاطر وحوادث السلامة</span>
            </div>
            <p className="text-gray-600 text-[11px]">
              يرجى تعبئة الحقول التالية لمساعدة فريق السلامة على الاستجابة الفورية.
            </p>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">
              اسم المبلّغ (اختياري)
            </label>
            <div className="relative">
              <input
                type="text"
                value={reporterName}
                onChange={(e) => setReporterName(e.target.value)}
                placeholder="اتركه فارغاً إن أردت السرية"
                className="w-full p-2.5 pr-9 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              />
              <User className="w-4 h-4 text-gray-400 absolute right-3 top-3.5" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">
              القسم / الإدارة <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <input
                type="text"
                required
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                placeholder="مثال: العمليات، الطوارئ، العناية المركزة..."
                className="w-full p-2.5 pr-9 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              />
              <Building2 className="w-4 h-4 text-gray-400 absolute right-3 top-3.5" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">
              الموقع الدقيق داخل المستشفى <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <input
                type="text"
                required
                value={locationDetail}
                onChange={(e) => setLocationDetail(e.target.value)}
                placeholder="مثال: الدور الأول ممر المختبر، غرفة 104"
                className="w-full p-2.5 pr-9 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              />
              <MapPin className="w-4 h-4 text-gray-400 absolute right-3 top-3.5" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">
              وصف الخطر أو الملاحظة (اختياري)
            </label>
            <textarea
              rows={3}
              value={reportDescription}
              onChange={(e) => setReportDescription(e.target.value)}
              placeholder="اكتب تفاصيل الخطر أو المشكلة إن وجدت..."
              className="w-full p-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold text-sm shadow transition-colors disabled:opacity-50 cursor-pointer"
          >
            {isSubmitting ? 'جاري الإرسال...' : 'إرسال البلاغ فوراً'}
          </button>
        </form>
      )}

      {/* نموذج 2: إفادة حادث تفصيلية */}
      {activeTab === 'affidavit' && !submittedAffidavitId && (
        <form onSubmit={handleSubmitAffidavit} className="space-y-4">
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-xs text-amber-950">
            <div className="flex items-center gap-1.5 font-bold mb-0.5">
              <FileText className="w-4 h-4 text-amber-700" />
              <span>نموذج إفادة حادث تفصيلية (أقوال وشهادات الوقائع)</span>
            </div>
            <p className="text-amber-800 text-[11px]">
              يستخدم هذا النموذج لتدوين وتوثيق الإفادات الرسمية الخاصة بحوادث السلامة والأمن بالمستشفى.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">
                رقم البلاغ / الحادث المرتبط (اختياري)
              </label>
              <input
                type="text"
                value={affidavitIncidentRef}
                onChange={(e) => setAffidavitIncidentRef(e.target.value)}
                placeholder="AZAL-INC-..."
                className="w-full p-2.5 border border-gray-300 rounded-lg text-sm font-mono focus:ring-2 focus:ring-amber-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">
                القسم / الموقع المعني <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                required
                value={affidavitDept}
                onChange={(e) => setAffidavitDept(e.target.value)}
                placeholder="مثال: الطوارئ، التغذية، العناية..."
                className="w-full p-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-amber-500 outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">
                اسم مقدم الإفادة <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                required
                value={affidavitPersonName}
                onChange={(e) => setAffidavitPersonName(e.target.value)}
                placeholder="الاسم الثلاثي أو الوظيفي"
                className="w-full p-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-amber-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">
                الصفة الوظيفية
              </label>
              <select
                value={affidavitPersonRole}
                onChange={(e) => setAffidavitPersonRole(e.target.value)}
                className="w-full p-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-amber-500 outline-none bg-white"
              >
                <option value="كادر تمريضي">كادر تمريضي</option>
                <option value="طبيب">طبيب / أخصائي</option>
                <option value="فني / تقني">فني / تقني</option>
                <option value="ضابط أمن وسلامة">ضابط أمن وسلامة</option>
                <option value="إداري / استقبال">إداري / استقبال</option>
                <option value="شاهد عيان / مرافق">شاهد عيان / مرافق</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">
                تاريخ وتوقيت الواقعة
              </label>
              <input
                type="datetime-local"
                value={affidavitDateTime}
                onChange={(e) => setAffidavitDateTime(e.target.value)}
                className="w-full p-2.5 border border-gray-300 rounded-lg text-xs focus:ring-2 focus:ring-amber-500 outline-none bg-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">
              نص الإفادة وشرح مجريات الواقعة بالتفصيل <span className="text-red-500">*</span>
            </label>
            <textarea
              rows={4}
              required
              value={affidavitDetails}
              onChange={(e) => setAffidavitDetails(e.target.value)}
              placeholder="اكتب بالتفصيل ما شاهدته أو ما وقع، مع ذكر الأسباب المباشرة إن وُجدت..."
              className="w-full p-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-amber-500 outline-none"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">
              الإجراءات الفورية المتخذة وقت الحادث
            </label>
            <input
              type="text"
              value={affidavitActionsTaken}
              onChange={(e) => setAffidavitActionsTaken(e.target.value)}
              placeholder="مثال: تم إخلاء المنطقة، استخدام طفاية الحريق، إبلاغ الصيانة..."
              className="w-full p-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-amber-500 outline-none"
            />
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3.5 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-700 hover:to-amber-800 text-white rounded-xl font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <FileText className="w-4 h-4" />
            <span>{isSubmitting ? 'جاري الاعتماد...' : 'اعتماد وتوثيق إفادة الحادث'}</span>
          </button>
        </form>
      )}

      {/* نموذج 3: إفادة إنجاز إشعار مخاطر */}
      {activeTab === 'statement' && !submittedStatementId && (
        <form onSubmit={handleSubmitStatement} className="space-y-4">
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 text-xs text-emerald-950">
            <div className="flex items-center gap-1.5 font-bold mb-0.5">
              <FileCheck className="w-4 h-4 text-emerald-600" />
              <span>نموذج إفادة إنجاز ومعالجة إشعار مخاطر (الجهة المنفذة)</span>
            </div>
            <p className="text-emerald-800 text-[11px]">
              يستخدم هذا النموذج لتسجيل وتوثيق المعالجة الفعلية للملاحظات الميدانية وإرفاق صور الإثبات فورياً.
            </p>
          </div>

          {/* بطاقة معلومات المخالفة المسجلة إذا تم العثور عليها بالرقم المرجعي */}
          {matchedViolation && (
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-3.5 text-xs text-blue-900 space-y-1.5">
              <div className="flex items-center justify-between font-bold">
                <span className="flex items-center gap-1">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>إشعار مطابق بالنظام</span>
                </span>
                <span className="font-mono bg-blue-100 px-2 py-0.5 rounded text-blue-800">
                  {matchedViolation.id}
                </span>
              </div>
              <div><span className="font-semibold text-blue-700">القسم:</span> {matchedViolation.department}</div>
              {matchedViolation.locationDetail && (
                <div><span className="font-semibold text-blue-700">الموقع:</span> {matchedViolation.locationDetail}</div>
              )}
              <div><span className="font-semibold text-blue-700">الملاحظة:</span> {matchedViolation.description}</div>
              {matchedViolation.requiredAction && (
                <div className="bg-white/80 p-2 rounded border border-blue-200 text-amber-900 mt-1">
                  <span className="font-bold text-amber-700">الإجراء المطلوب: </span>
                  {matchedViolation.requiredAction}
                </div>
              )}
            </div>
          )}

          {/* حقل الرقم المرجعي للإشعار (مقفول إذا تم تمريره في الرابط) */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1 flex items-center justify-between">
              <span className="flex items-center gap-1">
                <span>الرقم المرجعي للإشعار / البلاغ</span>
                <span className="text-red-500">*</span>
              </span>
              {isRefLocked && (
                <span className="text-[11px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded flex items-center gap-1">
                  <Lock className="w-3 h-3" />
                  <span>تم التثبيت التلقائي من الرابط ومقفل</span>
                </span>
              )}
            </label>
            <input
              type="text"
              value={referenceCode}
              onChange={(e) => setReferenceCode(e.target.value)}
              placeholder="AZAL-VIO-2026-..."
              required
              readOnly={isRefLocked}
              className={`w-full p-2.5 border border-emerald-300 rounded-lg text-sm font-mono font-bold outline-none ${
                isRefLocked
                  ? 'bg-emerald-50/70 text-emerald-950 cursor-not-allowed select-all'
                  : 'bg-white text-gray-900 focus:ring-2 focus:ring-emerald-500'
              }`}
            />
            <p className="text-xs text-gray-500 mt-1">
              {isRefLocked 
                ? 'تم استخراج وتثبيت كود الإشعار تلقائياً من واقع الباركود / الرابط.' 
                : 'أدخل كود الإشعار المسجل في الإشعار الميداني (مثال: AZAL-VIO-2026-BD646A8B).'}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* اسم القائم بالمعالجة */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">
                اسم القائم بالمعالجة / المنفّذ <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={resolvedByName}
                  onChange={(e) => setResolvedByName(e.target.value)}
                  placeholder="اسم المهندس / الفني أو رئيس القسم"
                  className="w-full p-2.5 pr-9 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500 outline-none"
                />
                <User className="w-4 h-4 text-gray-400 absolute right-3 top-3.5" />
              </div>
            </div>

            {/* تاريخ ووقت الإنجاز */}
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">
                تاريخ وتوقيت الإنجاز <span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="datetime-local"
                  required
                  value={completionDate}
                  onChange={(e) => setCompletionDate(e.target.value)}
                  className="w-full p-2.5 pr-9 border border-gray-300 rounded-lg text-xs focus:ring-2 focus:ring-emerald-500 outline-none bg-white font-mono"
                />
                <Calendar className="w-4 h-4 text-gray-400 absolute right-3 top-3.5" />
              </div>
            </div>
          </div>

          {/* تفاصيل الإجراء المتخذ والمعالجة */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">
              الإجراء التصحيحي والمعالجة المتخذة <span className="text-red-500">*</span>
            </label>
            <textarea
              rows={4}
              required
              value={statementText}
              onChange={(e) => setStatementText(e.target.value)}
              placeholder="وضح بالتفصيل الخطوات والإجراءات الفنية التي تم تنفيذها لتصحيح الخلل المطلوب وإغلاق الملاحظة..."
              className="w-full p-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500 outline-none leading-relaxed"
            />
          </div>

          {/* إرفاق صورة المعالجة */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1">
              صورة الإثبات بعد المعالجة والإغلاق (موصى بها)
            </label>
            <input
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handlePhotoChange}
              className="w-full text-xs text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-emerald-50 file:text-emerald-700 hover:file:bg-emerald-100 cursor-pointer"
            />
            {completionPhotoPreview && (
              <div className="mt-2.5 border border-emerald-200 rounded-xl p-2.5 bg-emerald-50/50 flex items-center gap-3">
                <img
                  src={completionPhotoPreview}
                  alt="معاينة صورة المعالجة"
                  className="w-16 h-16 object-cover rounded-lg border border-emerald-300 shadow-xs"
                />
                <div className="text-xs text-emerald-900">
                  <p className="font-bold">تم تجهيز صورة المعالجة والإغلاق</p>
                  <p className="text-emerald-700">سيتم توثيقها كإثبات رسمي مع الإفادة في سجلات المستشفى</p>
                </div>
              </div>
            )}
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 active:scale-[0.99]"
          >
            <CheckCircle2 className="w-5 h-5" />
            <span>{isSubmitting ? 'جاري الحفظ وتوجيه الواتساب...' : 'إرسال إفادة المعالجة (وحفظ الإنجاز)'}</span>
          </button>
        </form>
      )}
    </div>
  );
};
