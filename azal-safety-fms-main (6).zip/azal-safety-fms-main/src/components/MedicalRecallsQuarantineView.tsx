import React, { useState, useEffect } from 'react';
import { 
  AlertOctagon, 
  ShieldAlert, 
  Plus, 
  Printer, 
  Search, 
  Filter, 
  CheckCircle2, 
  AlertTriangle, 
  X, 
  Check, 
  Building2, 
  Cpu, 
  FileText, 
  RefreshCw, 
  Lock, 
  QrCode, 
  Tag,
  ArrowRight,
  ExternalLink,
  ShieldCheck
} from 'lucide-react';
import { collection, addDoc, getDocs, query, orderBy, limit, updateDoc, doc } from 'firebase/firestore';
import { db } from '../services/firebase';
import { MedicalRecallNotice } from '../types';
import { INITIAL_MEDICAL_RECALLS } from '../data/azalMedicalRecallsData';
import { executeSmartPrint } from '../utils/printUtils';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';

interface MedicalRecallsQuarantineViewProps {
  onLogAudit?: (action: string, actionAr: string, details: string) => void;
  technicianName?: string;
}

export const MedicalRecallsQuarantineView: React.FC<MedicalRecallsQuarantineViewProps> = ({
  onLogAudit,
  technicianName = 'م/ عمار اليافعي'
}) => {
  const [recalls, setRecalls] = useState<MedicalRecallNotice[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [hazardFilter, setHazardFilter] = useState<string>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedRecall, setSelectedRecall] = useState<MedicalRecallNotice | null>(null);

  // New Recall Form State
  const [source, setSource] = useState('تعميم الهيئة العليا للأدوية والمستلزمات الطبية');
  const [deviceName, setDeviceName] = useState('');
  const [modelNumber, setModelNumber] = useState('');
  const [manufacturer, setManufacturer] = useState('');
  const [serialNumber, setSerialNumber] = useState('');
  const [lotBatchNumber, setLotBatchNumber] = useState('');
  const [assetTag, setAssetTag] = useState('');
  const [department, setDepartment] = useState('قسم العناية المركزة (ICU)');
  const [hazardClass, setHazardClass] = useState<'class_1' | 'class_2' | 'class_3' | 'smda_clinical_incident'>('class_1');
  const [defectDescription, setDefectDescription] = useState('');
  const [actionTaken, setActionTaken] = useState('سحب فوري للجهاز من القسم، فصل مصدر الطاقة، تثبيت ملصق العزل الأحمر، والإيداع بمستودع التحريز الطبي.');
  const [quarantinedLocation, setQuarantinedLocation] = useState('مستودع التحريز الطبي المحكم (الهندسة الطبية)');
  const [quarantinedBy, setQuarantinedBy] = useState(technicianName);
  const [notes, setNotes] = useState('');

  useEffect(() => {
    loadRecalls();
  }, []);

  const loadRecalls = async () => {
    setLoading(true);
    try {
      let cached: MedicalRecallNotice[] = [];
      try {
        const local = localStorage.getItem('azal_medical_recalls_v1');
        if (local) cached = JSON.parse(local);
      } catch (e) {
        console.warn('Failed reading recalls from localStorage', e);
      }

      // Fetch from Firestore
      try {
        const q = query(collection(db, 'medical_recalls'), orderBy('createdAt', 'desc'), limit(50));
        const snap = await getDocs(q);
        if (!snap.empty) {
          const remoteRecalls: MedicalRecallNotice[] = snap.docs.map(d => ({
            id: d.id,
            ...(d.data() as Omit<MedicalRecallNotice, 'id'>)
          }));
          setRecalls(remoteRecalls);
          localStorage.setItem('azal_medical_recalls_v1', JSON.stringify(remoteRecalls));
          setLoading(false);
          return;
        }
      } catch (err) {
        console.warn('[Firestore] Fetching medical_recalls failed, using fallback:', err);
      }

      if (cached && cached.length > 0) {
        setRecalls(cached);
      } else {
        setRecalls(INITIAL_MEDICAL_RECALLS);
        localStorage.setItem('azal_medical_recalls_v1', JSON.stringify(INITIAL_MEDICAL_RECALLS));
      }
    } finally {
      setLoading(false);
    }
  };

  const handleCreateRecall = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!deviceName.trim() || !assetTag.trim() || !serialNumber.trim()) return;

    const count = recalls.length + 1;
    const currentYear = new Date().getFullYear();
    const newRecallId = `SMDA-AZAL-${currentYear}-${String(count).padStart(3, '0')}`;

    const newRecord: MedicalRecallNotice = {
      id: newRecallId,
      source: source.trim(),
      deviceName: deviceName.trim(),
      modelNumber: modelNumber.trim() || 'N/A',
      manufacturer: manufacturer.trim() || 'N/A',
      serialNumber: serialNumber.trim(),
      lotBatchNumber: lotBatchNumber.trim() || 'N/A',
      assetTag: assetTag.trim(),
      department: department.trim(),
      hazardClass,
      defectDescription: defectDescription.trim(),
      actionTaken: actionTaken.trim(),
      quarantinedLocation: quarantinedLocation.trim(),
      quarantinedBy: quarantinedBy.trim(),
      quarantineDate: new Date().toISOString().split('T')[0],
      status: 'quarantined',
      stickerPrinted: false,
      notes: notes.trim(),
      createdAt: Date.now(),
      synced: true
    };

    const updated = [newRecord, ...recalls];
    setRecalls(updated);
    try {
      localStorage.setItem('azal_medical_recalls_v1', JSON.stringify(updated));
    } catch (e) {
      console.warn('Failed saving recall to localStorage', e);
    }

    try {
      await addDoc(collection(db, 'medical_recalls'), newRecord);
    } catch (err) {
      console.warn('[Firestore] Writing medical recall error:', err);
    }

    triggerSuccessFeedback();
    if (onLogAudit) {
      onLogAudit(
        'MEDICAL_RECALL_QUARANTINED',
        'تحريز جهاز طبي معيب وعزل SMDA',
        `تم تحريز الجهاز (${newRecord.deviceName}) كود أصل (${newRecord.assetTag}) تصنيف (${newRecord.hazardClass}) بمستودع التحريز.`
      );
    }

    setShowAddModal(false);
    // Reset Form
    setDeviceName('');
    setModelNumber('');
    setManufacturer('');
    setSerialNumber('');
    setLotBatchNumber('');
    setAssetTag('');
    setDefectDescription('');
    setNotes('');

    // Automatically prompt to print red quarantine tag
    handlePrintRedQuarantineSticker(newRecord);
  };

  const handleUpdateStatus = async (recallId: string, newStatus: MedicalRecallNotice['status']) => {
    const updated = recalls.map(r => r.id === recallId ? { ...r, status: newStatus } : r);
    setRecalls(updated);
    try {
      localStorage.setItem('azal_medical_recalls_v1', JSON.stringify(updated));
    } catch (e) {
      console.warn(e);
    }

    try {
      const q = query(collection(db, 'medical_recalls'));
      const snap = await getDocs(q);
      const docMatch = snap.docs.find(d => d.id === recallId || d.data().id === recallId);
      if (docMatch) {
        await updateDoc(doc(db, 'medical_recalls', docMatch.id), { status: newStatus });
      }
    } catch (err) {
      console.warn('[Firestore] Updating recall status warning:', err);
    }

    triggerSuccessFeedback();
    if (onLogAudit) {
      onLogAudit(
        'RECALL_STATUS_UPDATED',
        'تحديث حالة جهاز محرز / استدعاء طبي',
        `تم تحديث حالة السجل (${recallId}) إلى: ${newStatus}`
      );
    }
  };

  // Official Red Hazard / Quarantine Label Printing (Crucial CBAHI MEM Requirement)
  const handlePrintRedQuarantineSticker = (item: MedicalRecallNotice) => {
    const hazardTitle = item.hazardClass === 'class_1' ? 'CLASS I HAZARD (خطر حرج يهدد الحياة)' :
      item.hazardClass === 'class_2' ? 'CLASS II HAZARD (خطر متوسط / مؤقت)' :
      item.hazardClass === 'class_3' ? 'CLASS III HAZARD (خلل تصنيعي)' : 'SMDA CLINICAL INCIDENT (تحريز إثر حادث سريري)';

    const bodyHtml = `
      <div style="direction:rtl; font-family:sans-serif; border: 8px solid #b91c1c; border-radius: 16px; padding: 24px; background: #fff; max-width: 700px; margin: 0 auto; box-shadow: 0 4px 12px rgba(0,0,0,0.15);">
        
        <!-- Danger Top Banner -->
        <div style="background: #b91c1c; color: #fff; text-align: center; padding: 14px 10px; border-radius: 8px; margin-bottom: 20px;">
          <h1 style="margin: 0; font-size: 26px; font-weight: 900; letter-spacing: 1px;">
            ⚠️ خــطـر - مـعـدة طـبـيـة مـعـزولـة ومـحـرزة
          </h1>
          <h2 style="margin: 4px 0 0; font-size: 16px; font-weight: bold; letter-spacing: 0.5px;">
            EQUIPMENT OUT OF SERVICE / QUARANTINED UNDER SMDA
          </h2>
          <div style="font-size: 13px; font-weight: bold; margin-top: 6px; background: #7f1d1d; display: inline-block; padding: 4px 16px; border-radius: 20px;">
            يُحظر تشغيل أو توصيل أو نقل هذا الجهاز بتاتاً تحت طائلة المسؤولية القانونية
          </div>
        </div>

        <!-- Meta Grid -->
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-bottom: 16px; font-size: 13px;">
          <div style="border: 2px solid #ef4444; border-radius: 8px; padding: 10px; background: #fef2f2;">
            <div style="font-weight: bold; color: #991b1b; font-size: 11px;">رقم إشعار التحريز الرسمي:</div>
            <div style="font-family: monospace; font-size: 18px; font-weight: 900; color: #b91c1c;">${item.id}</div>
          </div>
          <div style="border: 2px solid #ef4444; border-radius: 8px; padding: 10px; background: #fef2f2;">
            <div style="font-weight: bold; color: #991b1b; font-size: 11px;">مستوى خطورة الاستدعاء:</div>
            <div style="font-weight: 900; color: #b91c1c; font-size: 14px;">${hazardTitle}</div>
          </div>
        </div>

        <!-- Device Info Table -->
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 16px; font-size: 13px;">
          <tbody>
            <tr style="border-bottom: 1px solid #fca5a5;">
              <td style="padding: 8px; font-weight: bold; width: 30%; color: #374151; background: #f9fafb;">اسم الجهاز الطبي:</td>
              <td style="padding: 8px; font-weight: 900; font-size: 15px; color: #111827;">${item.deviceName}</td>
            </tr>
            <tr style="border-bottom: 1px solid #fca5a5;">
              <td style="padding: 8px; font-weight: bold; color: #374151; background: #f9fafb;">رقم الأصل الطبي بالمستشفى:</td>
              <td style="padding: 8px; font-family: monospace; font-weight: bold; font-size: 16px; color: #b91c1c;">${item.assetTag}</td>
            </tr>
            <tr style="border-bottom: 1px solid #fca5a5;">
              <td style="padding: 8px; font-weight: bold; color: #374151; background: #f9fafb;">الرقم التسلسلي (S/N) والطراز:</td>
              <td style="padding: 8px; font-family: monospace; font-weight: bold;">${item.serialNumber} | الموديل: ${item.modelNumber}</td>
            </tr>
            <tr style="border-bottom: 1px solid #fca5a5;">
              <td style="padding: 8px; font-weight: bold; color: #374151; background: #f9fafb;">الشركة الصانعة / المنشأ:</td>
              <td style="padding: 8px;">${item.manufacturer} (تشغيلة: ${item.lotBatchNumber || 'N/A'})</td>
            </tr>
            <tr style="border-bottom: 1px solid #fca5a5;">
              <td style="padding: 8px; font-weight: bold; color: #374151; background: #f9fafb;">القسم المسحوب منه الجهاز:</td>
              <td style="padding: 8px; font-weight: bold; color: #b91c1c;">${item.department}</td>
            </tr>
            <tr style="border-bottom: 1px solid #fca5a5;">
              <td style="padding: 8px; font-weight: bold; color: #374151; background: #f9fafb;">تاريخ التحريز وسحب الجهاز:</td>
              <td style="padding: 8px; font-weight: bold;">${item.quarantineDate}</td>
            </tr>
            <tr style="border-bottom: 1px solid #fca5a5;">
              <td style="padding: 8px; font-weight: bold; color: #374151; background: #f9fafb;">مصدر التعميم / البلاغ:</td>
              <td style="padding: 8px; font-size: 12px; color: #4b5563;">${item.source}</td>
            </tr>
            <tr style="border-bottom: 1px solid #fca5a5;">
              <td style="padding: 8px; font-weight: bold; color: #374151; background: #f9fafb;">سبب الاستدعاء / العطل المرصود:</td>
              <td style="padding: 8px; font-weight: bold; color: #b91c1c; font-size: 12px;">${item.defectDescription}</td>
            </tr>
            <tr style="border-bottom: 1px solid #fca5a5;">
              <td style="padding: 8px; font-weight: bold; color: #374151; background: #f9fafb;">مستودع التحريز والاحتجاز:</td>
              <td style="padding: 8px; font-weight: bold;">${item.quarantinedLocation}</td>
            </tr>
          </tbody>
        </table>

        <!-- Signatures & Authority Verification -->
        <div style="margin-top: 24px; padding-top: 16px; border-top: 2px dashed #b91c1c; display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; text-align: center; font-size: 12px;">
          <div>
            <div style="font-weight: bold; color: #374151;">المهندس الطبي المحرِّز:</div>
            <div style="margin-top: 8px; font-weight: bold; color: #111827;">${item.quarantinedBy}</div>
            <div style="margin-top: 18px; border-bottom: 1px dotted #9ca3af; width: 80%; margin-left: auto; margin-right: auto;"></div>
            <div style="font-size: 10px; color: #6b7280; margin-top: 4px;">التوقيع والتاريخ</div>
          </div>
          <div>
            <div style="font-weight: bold; color: #374151;">رئيس قسم السلامة FMS:</div>
            <div style="margin-top: 8px; font-weight: bold; color: #111827;">م/ نجيب قاسم غازي</div>
            <div style="margin-top: 18px; border-bottom: 1px dotted #9ca3af; width: 80%; margin-left: auto; margin-right: auto;"></div>
            <div style="font-size: 10px; color: #6b7280; margin-top: 4px;">الاعتماد والتوقيع</div>
          </div>
          <div>
            <div style="font-weight: bold; color: #374151;">ختم التحريز الرسمي:</div>
            <div style="margin-top: 10px; display: inline-block; width: 70px; height: 70px; border: 2px solid #b91c1c; border-radius: 50%; line-height: 22px; font-size: 10px; font-weight: bold; color: #b91c1c; padding-top: 10px; box-sizing: border-box;">
              معزول رسمياً<br>QUARANTINE<br>آزال
            </div>
          </div>
        </div>

        <div style="margin-top: 18px; text-align: center; font-size: 11px; color: #6b7280;">
          مستشفى آزال النموذجي • إدارة الهندسة الطبية MEM وقسم السلامة FMS • نظام التحريز المعتمد لسباهي (SMDA Protocol)
        </div>
      </div>
    `;

    executeSmartPrint(bodyHtml, {
      title: `ملصق عزل أحمر رسمي - ${item.assetTag} - ${item.deviceName}`,
      subtitle: 'مستشفى آزال النموذجي • الهندسة الطبية • إشعار تحريز معتمد',
      refNumber: item.id
    });
  };

  const filteredRecalls = recalls.filter((item) => {
    const matchesSearch = 
      item.deviceName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.assetTag.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.serialNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.department.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.id.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'all' || item.status === statusFilter;
    const matchesHazard = hazardFilter === 'all' || item.hazardClass === hazardFilter;
    return matchesSearch && matchesStatus && matchesHazard;
  });

  const activeQuarantineCount = recalls.filter(r => r.status === 'quarantined' || r.status === 'under_investigation').length;

  return (
    <div className="space-y-6 text-slate-100" dir="rtl">
      
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-rose-950/80 via-slate-900 to-slate-900 border border-rose-800/60 rounded-2xl p-5 shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-rose-950 text-rose-400 border border-rose-700 flex items-center justify-center font-bold shadow-lg shrink-0">
            <AlertOctagon className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-rose-950 text-rose-300 border border-rose-800 text-[11px] font-bold">
                CBAHI MEM.6 & SMDA Protocol
              </span>
              <span className="text-xs text-rose-300/80 font-mono">#pm #recalls</span>
            </div>
            <h3 className="text-base sm:text-lg font-black text-slate-100 mt-0.5">
              وحدة تحريز الأجهزة الطبية واستدعاء المنتجات (Medical Recalls & Quarantine)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              تسجيل تعميمات سحب الأجهزة المعيبة، بلاغات التحريز الفوري، وطباعة ملصق العزل الأحمر الرسمي
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-black text-xs flex items-center gap-1.5 transition cursor-pointer shadow-lg shadow-rose-950 active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>تسجيل استدعاء / تحريز جهاز جديد</span>
          </button>
        </div>
      </div>

      {/* Stats Overview Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col justify-between space-y-1">
          <span className="text-xs text-slate-400 font-bold">إجمالي بلاغات الاستدعاء</span>
          <span className="text-2xl font-black text-slate-100">{recalls.length}</span>
        </div>
        <div className="p-4 rounded-2xl bg-rose-950/40 border border-rose-900/60 flex flex-col justify-between space-y-1">
          <span className="text-xs text-rose-300 font-bold">أجهزة معزولة ومحرزة حالياً</span>
          <span className="text-2xl font-black text-rose-400">{activeQuarantineCount}</span>
        </div>
        <div className="p-4 rounded-2xl bg-amber-950/40 border border-amber-900/60 flex flex-col justify-between space-y-1">
          <span className="text-xs text-amber-300 font-bold">قيد الفحص والتنسيق مع الوكيل</span>
          <span className="text-2xl font-black text-amber-400">{recalls.filter(r => r.status === 'under_investigation' || r.status === 'vendor_servicing').length}</span>
        </div>
        <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-900/60 flex flex-col justify-between space-y-1">
          <span className="text-xs text-emerald-300 font-bold">تمت المعالجة ورفع التحريز</span>
          <span className="text-2xl font-black text-emerald-400">{recalls.filter(r => r.status === 'repaired_cleared').length}</span>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex flex-col md:flex-row items-center justify-between gap-3 shadow-inner">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 absolute right-3 top-3 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="بحث باسم الجهاز، رقم الأصل، السيريال، أو القسم..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-9 pl-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-rose-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-rose-500"
          >
            <option value="all">كافة الحالات</option>
            <option value="quarantined">محرز ومعزول بالمستودع</option>
            <option value="under_investigation">قيد الفحص والتحقيق</option>
            <option value="vendor_servicing">لدى الوكيل / المورد</option>
            <option value="repaired_cleared">تم الإصلاح ورفع التحريز</option>
          </select>

          <select
            value={hazardFilter}
            onChange={(e) => setHazardFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-rose-500"
          >
            <option value="all">كافة مستويات الخطر</option>
            <option value="class_1">Class I - خطر حرج</option>
            <option value="class_2">Class II - خطر متوسط</option>
            <option value="class_3">Class III - ملاحظات تصنيعية</option>
            <option value="smda_clinical_incident">تحريز لحادث سريري SMDA</option>
          </select>

          <button
            type="button"
            onClick={loadRecalls}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
            title="تحديث البيانات"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Recalls List */}
      <div className="space-y-3">
        {loading ? (
          <div className="p-8 text-center text-slate-400 text-xs">جاري تحميل سجلات الاستدعاء والتحريز...</div>
        ) : filteredRecalls.length === 0 ? (
          <div className="p-8 text-center bg-slate-900/60 border border-slate-800 rounded-2xl text-slate-400 text-xs">
            لا توجد أجهزة مطابقة للبحث أو معزولة حالياً.
          </div>
        ) : (
          filteredRecalls.map((item) => {
            const isQuarantined = item.status === 'quarantined' || item.status === 'under_investigation';
            const hazardBadge = item.hazardClass === 'class_1' ? 'Class I (خطر حرج يهدد الحياة)' :
              item.hazardClass === 'class_2' ? 'Class II (خطر متوسط)' :
              item.hazardClass === 'class_3' ? 'Class III (تصنيعي)' : 'حادث سريري SMDA';

            return (
              <div
                key={item.id}
                className={`p-5 rounded-2xl border transition-all duration-150 space-y-4 shadow-lg ${
                  isQuarantined 
                    ? 'bg-gradient-to-r from-rose-950/40 via-slate-900 to-slate-900 border-rose-800/80 hover:border-rose-600'
                    : 'bg-slate-900/90 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold shrink-0 ${
                      isQuarantined ? 'bg-rose-950 text-rose-400 border border-rose-700' : 'bg-slate-800 text-slate-400'
                    }`}>
                      <Lock className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-rose-400 bg-slate-950 px-2.5 py-0.5 rounded border border-rose-900/50">
                          {item.id}
                        </span>
                        <span className={`text-[11px] font-bold px-2 py-0.5 rounded ${
                          item.hazardClass === 'class_1' || item.hazardClass === 'smda_clinical_incident'
                            ? 'bg-rose-950 text-rose-300 border border-rose-700'
                            : 'bg-amber-950 text-amber-300 border border-amber-700'
                        }`}>
                          {hazardBadge}
                        </span>
                      </div>
                      <h4 className="text-sm font-black text-slate-100 mt-1">
                        {item.deviceName}
                      </h4>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handlePrintRedQuarantineSticker(item)}
                      className="px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-black text-xs flex items-center gap-1.5 transition cursor-pointer shadow-md active:scale-95"
                      title="طباعة ملصق العزل الأحمر الرسمي لتثبيته على الجهاز المعيب"
                    >
                      <Tag className="w-3.5 h-3.5" />
                      <span>طباعة ملصق العزل الأحمر</span>
                    </button>
                  </div>
                </div>

                {/* Device Details Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80 space-y-0.5">
                    <span className="text-[11px] text-slate-400">رقم الأصل الطبي:</span>
                    <div className="font-mono font-bold text-slate-200">{item.assetTag}</div>
                  </div>
                  <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80 space-y-0.5">
                    <span className="text-[11px] text-slate-400">الرقم التسلسلي والموديل:</span>
                    <div className="font-mono text-slate-300 text-[11px] truncate" title={item.serialNumber}>
                      {item.serialNumber} ({item.modelNumber})
                    </div>
                  </div>
                  <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80 space-y-0.5">
                    <span className="text-[11px] text-slate-400">القسم المسحوب منه:</span>
                    <div className="font-bold text-slate-200">{item.department}</div>
                  </div>
                  <div className="bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80 space-y-0.5">
                    <span className="text-[11px] text-slate-400">موقع التحريز والعزل:</span>
                    <div className="font-bold text-rose-300 truncate" title={item.quarantinedLocation}>
                      {item.quarantinedLocation}
                    </div>
                  </div>
                </div>

                {/* Reason & Defect */}
                <div className="text-xs bg-slate-950/80 p-3 rounded-xl border border-slate-800 space-y-1">
                  <div className="flex items-center justify-between text-[11px] text-slate-400 font-bold">
                    <span>سبب الاستدعاء والخلل المرصود:</span>
                    <span>تاريخ التحريز: {item.quarantineDate}</span>
                  </div>
                  <p className="text-slate-300 leading-relaxed font-medium">
                    {item.defectDescription}
                  </p>
                  <div className="pt-2 border-t border-slate-800/60 text-[11px] text-teal-400 font-medium">
                    الإجراء المتخذ: {item.actionTaken}
                  </div>
                </div>

                {/* Status Update Quick Bar */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 text-xs border-t border-slate-800/60">
                  <div className="flex items-center gap-2 text-slate-400">
                    <span>المسؤول: <strong>{item.quarantinedBy}</strong></span>
                    <span>• المصدر: <em>{item.source}</em></span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-slate-400 text-[11px]">تحديث الحالة:</span>
                    <select
                      value={item.status}
                      onChange={(e) => handleUpdateStatus(item.id, e.target.value as any)}
                      className="bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-slate-200 focus:outline-none focus:border-rose-500 font-bold"
                    >
                      <option value="quarantined">محرز ومعزول بالمستودع 🔒</option>
                      <option value="under_investigation">قيد الفحص والتحقيق 🔍</option>
                      <option value="vendor_servicing">أُرسل للوكيل / المورد 🚚</option>
                      <option value="repaired_cleared">تم الإصلاح ورفع التحريز ✔</option>
                    </select>
                  </div>
                </div>

              </div>
            );
          })
        )}
      </div>

      {/* Add New Medical Recall / Quarantine Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto" dir="rtl">
          <div className="bg-slate-900 border border-rose-800/70 rounded-3xl max-w-2xl w-full p-6 space-y-5 shadow-2xl animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-rose-950 text-rose-400 border border-rose-700 flex items-center justify-center font-bold">
                  <AlertOctagon className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-100">
                    تسجيل استدعاء وتحريز جهاز طبي (SMDA Quarantine Protocol)
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    عزل الجهاز المعيب عن المرضى وإيداعه قفص التحريز وطباعة ملصق العزل الأحمر
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateRecall} className="space-y-4">
              
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300">مصدر الاستدعاء أو البلاغ:</label>
                <input
                  type="text"
                  value={source}
                  onChange={(e) => setSource(e.target.value)}
                  placeholder="تعميم الهيئة العليا للأدوية / وزارة الصحة / بلاغ حادث سريري داخلي..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-rose-500"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">اسم الجهاز الطبي:</label>
                  <input
                    type="text"
                    value={deviceName}
                    onChange={(e) => setDeviceName(e.target.value)}
                    placeholder="مثال: مضخة تسريب وريدي ذكية، جهاز تنفس..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-rose-500"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">رقم الأصل الطبي بالمستشفى:</label>
                  <input
                    type="text"
                    value={assetTag}
                    onChange={(e) => setAssetTag(e.target.value)}
                    placeholder="مثال: AZAL-MED-055"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 font-mono focus:outline-none focus:border-rose-500"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">الرقم التسلسلي (S/N):</label>
                  <input
                    type="text"
                    value={serialNumber}
                    onChange={(e) => setSerialNumber(e.target.value)}
                    placeholder="SN-12345678"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 font-mono focus:outline-none focus:border-rose-500"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">الموديل / الطراز:</label>
                  <input
                    type="text"
                    value={modelNumber}
                    onChange={(e) => setModelNumber(e.target.value)}
                    placeholder="Model Plus v2"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-rose-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">الشركة المصنعة:</label>
                  <input
                    type="text"
                    value={manufacturer}
                    onChange={(e) => setManufacturer(e.target.value)}
                    placeholder="Philips, BD, GE..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-rose-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">القسم المتواجد به الجهاز حالياً:</label>
                  <input
                    type="text"
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-rose-500"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">مستوى تصنيف خطورة الاستدعاء:</label>
                  <select
                    value={hazardClass}
                    onChange={(e) => setHazardClass(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-rose-500 font-bold"
                  >
                    <option value="class_1">Class I - خطر حرج يهدد الحياة (استدعاء وتحريز فوري)</option>
                    <option value="class_2">Class II - خطر متوسط أو مؤقت</option>
                    <option value="class_3">Class III - ملاحظات تصنيعية غير حرجة</option>
                    <option value="smda_clinical_incident">SMDA Incident - تحريز طارئ إثر عطل سريري</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300">وصف الخلل الفني أو سبب الاستدعاء:</label>
                <textarea
                  value={defectDescription}
                  onChange={(e) => setDefectDescription(e.target.value)}
                  rows={2}
                  placeholder="وصف تفصيلي للخلل الكهربائي أو البرمجي أو الميكانيكي..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-rose-500"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">موقع التحريز والعزل المعتمد:</label>
                  <input
                    type="text"
                    value={quarantinedLocation}
                    onChange={(e) => setQuarantinedLocation(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-rose-500"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">المهندس الطبي المسؤول عن التحريز:</label>
                  <input
                    type="text"
                    value={quarantinedBy}
                    onChange={(e) => setQuarantinedBy(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-rose-500"
                    required
                  />
                </div>
              </div>

              <div className="pt-3 flex items-center justify-between border-t border-slate-800">
                <div className="text-[11px] text-slate-400">
                  * سيتم فتح ملصق العزل الأحمر للطباعة فور الاعتماد
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-black text-xs flex items-center gap-1.5 shadow-lg shadow-rose-950"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>اعتماد التحريز وإصدار الملصق</span>
                  </button>
                </div>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
