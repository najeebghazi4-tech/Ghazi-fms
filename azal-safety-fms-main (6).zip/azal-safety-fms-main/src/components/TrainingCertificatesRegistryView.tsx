import React, { useState, useMemo, useEffect } from 'react';
import {
  Award,
  Plus,
  Search,
  Filter,
  Printer,
  Trash2,
  Calendar,
  Building2,
  CheckCircle2,
  Clock,
  Sparkles,
  ShieldCheck,
  User,
  ExternalLink,
  BookOpen,
  QrCode,
  FileCheck,
} from 'lucide-react';
import { TrainingCertificateRecord, SafetyTraining, StaffUser } from '../types';
import {
  loadStoredCertificates,
  saveStoredCertificates,
  generateNextCertificateSerial,
} from '../data/trainingCertificatesData';
import { TrainingCertificatePrintModal } from './TrainingCertificatePrintModal';
import { AddCertificateModal } from './AddCertificateModal';

interface TrainingCertificatesRegistryViewProps {
  trainingsList?: SafetyTraining[];
  currentUser?: StaffUser;
  onLogAudit?: (action: string, actionAr: string, details: string) => void;
  onOpenAddCertificateExternal?: boolean;
}

export const TrainingCertificatesRegistryView: React.FC<TrainingCertificatesRegistryViewProps> = ({
  trainingsList = [],
  currentUser,
  onLogAudit,
}) => {
  const [certificates, setCertificates] = useState<TrainingCertificateRecord[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState('ALL');
  const [showAddModal, setShowAddModal] = useState(false);
  const [activePrintCert, setActivePrintCert] = useState<TrainingCertificateRecord | null>(null);
  const [deleteConfirmCert, setDeleteConfirmCert] = useState<TrainingCertificateRecord | null>(null);
  const [notification, setNotification] = useState<{ type: 'success' | 'info'; message: string } | null>(null);

  // Load stored certificates on mount
  useEffect(() => {
    const loaded = loadStoredCertificates();
    setCertificates(loaded);
  }, []);

  const showNotification = (type: 'success' | 'info', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 3500);
  };

  // Distinct departments from existing certificates
  const distinctDepartments = useMemo(() => {
    const set = new Set<string>();
    certificates.forEach((c) => {
      if (c.department) set.add(c.department);
    });
    return Array.from(set);
  }, [certificates]);

  // Filtered certificates based on search and department
  const filteredCertificates = useMemo(() => {
    return certificates.filter((cert) => {
      const matchDept = selectedDepartment === 'ALL' || cert.department === selectedDepartment;
      const term = searchTerm.trim().toLowerCase();
      const matchSearch =
        !term ||
        cert.trainee_name.toLowerCase().includes(term) ||
        cert.course_name.toLowerCase().includes(term) ||
        cert.certificate_serial.toLowerCase().includes(term) ||
        (cert.department && cert.department.toLowerCase().includes(term)) ||
        (cert.job_title && cert.job_title.toLowerCase().includes(term));

      return matchDept && matchSearch;
    });
  }, [certificates, selectedDepartment, searchTerm]);

  // Handle Save New Certificate
  const handleSaveCertificate = (newCert: TrainingCertificateRecord) => {
    const updated = [newCert, ...certificates];
    setCertificates(updated);
    saveStoredCertificates(updated);
    setShowAddModal(false);

    showNotification('success', `تم إصدار الشهادة بنجاح برقم: ${newCert.certificate_serial}`);

    if (onLogAudit) {
      onLogAudit(
        'CREATE_TRAINING_CERTIFICATE',
        'إصدار شهادة تدريبية جديدة',
        `تم إصدار شهادة تدريبية للمتدرب (${newCert.trainee_name}) بالرقم التسلسلي (${newCert.certificate_serial}) لقسم (${newCert.department}).`
      );
    }

    // Automatically prompt printable view
    setActivePrintCert(newCert);
  };

  // Handle Delete Certificate
  const handleDeleteCertificate = (cert: TrainingCertificateRecord) => {
    const updated = certificates.filter((c) => c.id !== cert.id);
    setCertificates(updated);
    saveStoredCertificates(updated);
    setDeleteConfirmCert(null);

    showNotification('info', `تم حذف الشهادة (${cert.certificate_serial}) من السجل.`);

    if (onLogAudit) {
      onLogAudit(
        'DELETE_TRAINING_CERTIFICATE',
        'حذف شهادة تدريبية',
        `تم حذف شهادة المتدرب (${cert.trainee_name}) برقم (${cert.certificate_serial}).`
      );
    }
  };

  // Total Hours Calculated
  const totalTrainingHours = useMemo(() => {
    return certificates.reduce((acc, c) => acc + (c.duration_hours || 0), 0);
  }, [certificates]);

  return (
    <div className="space-y-4 text-xs animate-in fade-in duration-200">
      {/* Toast Notification */}
      {notification && (
        <div
          className={`fixed top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-2xl shadow-2xl text-xs font-bold border flex items-center gap-2 transition-all ${
            notification.type === 'success'
              ? 'bg-emerald-950/95 text-emerald-200 border-emerald-500'
              : 'bg-blue-950/95 text-blue-200 border-blue-500'
          }`}
        >
          <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
          <span>{notification.message}</span>
        </div>
      )}

      {/* KPI Stats Summary */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3">
        {/* Total Certificates */}
        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-2xl flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center shrink-0">
            <Award className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 block font-medium">الشهادات المعتمدة</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl font-black text-amber-400">{certificates.length}</span>
              <span className="text-[10px] text-slate-400">شهادة رسمية</span>
            </div>
          </div>
        </div>

        {/* Distinct Departments */}
        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-2xl flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 text-blue-400 flex items-center justify-center shrink-0">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 block font-medium">الأقسام المشمولة</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl font-black text-blue-400">{distinctDepartments.length}</span>
              <span className="text-[10px] text-slate-400">قسم ومرفق</span>
            </div>
          </div>
        </div>

        {/* Total Training Hours */}
        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-2xl flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center shrink-0">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 block font-medium">إجمالي ساعات التدريب</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl font-black text-emerald-400">{totalTrainingHours}</span>
              <span className="text-[10px] text-slate-400">ساعة تدريبية</span>
            </div>
          </div>
        </div>

        {/* Verification System */}
        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-2xl flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/30 text-purple-400 flex items-center justify-center shrink-0">
            <QrCode className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 block font-medium">نظام التحقق الذكي</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xs font-mono font-black text-purple-300">AZAL-FMS-CERT</span>
            </div>
            <span className="text-[9px] text-emerald-400 font-bold block mt-0.5">بار كود رقمي معتمد ✓</span>
          </div>
        </div>
      </div>

      {/* Filter and Actions Bar */}
      <div className="bg-slate-900/90 border border-slate-800 p-3.5 rounded-2xl flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Search Field */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-500 absolute right-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="بحث باسم المتدرب، القسم، اسم الدورة، أو الرقم التسلسلي للشهادة..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-9 pl-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition"
          />
          {searchTerm && (
            <button
              type="button"
              onClick={() => setSearchTerm('')}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
            >
              ✕
            </button>
          )}
        </div>

        {/* Department Filter Dropdown */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 shrink-0">
            <Filter className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="text-slate-400 text-[11px] shrink-0">فلترة القسم:</span>
            <select
              value={selectedDepartment}
              onChange={(e) => setSelectedDepartment(e.target.value)}
              className="bg-transparent text-slate-200 text-xs font-bold focus:outline-none cursor-pointer pr-1"
            >
              <option value="ALL" className="bg-slate-900 text-white">
                [ عرض كافة الأقسام ]
              </option>
              {distinctDepartments.map((dept) => (
                <option key={dept} value={dept} className="bg-slate-900 text-white">
                  {dept}
                </option>
              ))}
            </select>
          </div>

          {/* Add Certificate Button */}
          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-amber-950 transition active:scale-95 shrink-0"
            title="تسجيل متدرب جديد وإصدار شهادة رسمية"
          >
            <Plus className="w-4 h-4" />
            <span>إصدار شهادة جديدة</span>
          </button>
        </div>
      </div>

      {/* Main Interactive Training Registry Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl overflow-hidden shadow-xl">
        <div className="p-3.5 bg-slate-950/60 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileCheck className="w-4 h-4 text-amber-400" />
            <span className="font-bold text-slate-200 text-xs">
              سجل المتدربين المجتازين للدورات والشهادات الصادرة (CBAHI FMS.1)
            </span>
            <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded-full font-mono font-bold">
              {filteredCertificates.length} متدرب
            </span>
          </div>

          <div className="text-[11px] text-slate-400 hidden sm:block">
            معتمد بموجب توقيع رئيس السلامة (م/ نجيب غازي) والمدير العام
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 text-[11px] select-none">
                <th className="py-3 px-3 text-center w-12">#</th>
                <th className="py-3 px-3">اسم المتدرب</th>
                <th className="py-3 px-3">القسم / الإدارة</th>
                <th className="py-3 px-3">اسم الدورة التدريبية</th>
                <th className="py-3 px-3">تاريخ الانعقاد</th>
                <th className="py-3 px-3">الرقم التسلسلي للشهادة</th>
                <th className="py-3 px-3 text-center">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredCertificates.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-12 text-slate-500">
                    <Award className="w-8 h-8 mx-auto mb-2 opacity-30" />
                    <p className="font-bold text-sm">لا توجد شهادات متدربين مسجلة تطابق البحث</p>
                    <p className="text-[11px] mt-1">
                      يمكنك إصدار شهادة تدريبية جديدة بالنقر على "إصدار شهادة جديدة"
                    </p>
                  </td>
                </tr>
              ) : (
                filteredCertificates.map((cert, idx) => (
                  <tr key={cert.id} className="hover:bg-slate-800/40 transition-colors group">
                    {/* Index */}
                    <td className="py-3 px-3 text-center text-slate-500 font-mono text-[11px]">
                      {idx + 1}
                    </td>

                    {/* Trainee Name */}
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/30 flex items-center justify-center shrink-0">
                          <User className="w-3.5 h-3.5" />
                        </div>
                        <div>
                          <span className="font-bold text-white text-xs block leading-snug">
                            {cert.trainee_name}
                          </span>
                          {cert.job_title && (
                            <span className="text-[10px] text-slate-400 block">{cert.job_title}</span>
                          )}
                        </div>
                      </div>
                    </td>

                    {/* Department */}
                    <td className="py-3 px-3">
                      <span className="inline-block bg-slate-950 border border-slate-800 text-blue-300 text-[11px] px-2.5 py-1 rounded-xl font-medium">
                        {cert.department}
                      </span>
                    </td>

                    {/* Course Name */}
                    <td className="py-3 px-3">
                      <div className="text-slate-200 font-medium text-xs max-w-xs leading-snug">
                        {cert.course_name}
                      </div>
                      <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-1">
                        <span className="text-emerald-400 font-bold bg-emerald-950/40 px-1.5 py-0.5 rounded border border-emerald-800/50">
                          {cert.duration_hours} ساعات تدريبية
                        </span>
                        {cert.grade_or_evaluation && (
                          <span className="text-amber-400 font-medium">
                            • {cert.grade_or_evaluation}
                          </span>
                        )}
                      </div>
                    </td>

                    {/* Training Date */}
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-1.5 text-slate-200 font-medium">
                        <Calendar className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                        <span className="font-mono text-xs">{cert.training_date}</span>
                      </div>
                      <span className="text-[10px] text-slate-500 block mt-0.5">
                        المدرب: {cert.trainer_name}
                      </span>
                    </td>

                    {/* Certificate Serial Number */}
                    <td className="py-3 px-3">
                      <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-slate-950 border border-amber-600/40 text-amber-300 font-mono font-bold text-xs shadow-sm">
                        <ShieldCheck className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        <span>{cert.certificate_serial}</span>
                      </div>
                    </td>

                    {/* Actions: Print Certificate */}
                    <td className="py-3 px-3 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        {/* Print Certificate Button */}
                        <button
                          type="button"
                          onClick={() => setActivePrintCert(cert)}
                          className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-amber-950/60 transition active:scale-95"
                          title="معاينة وطباعة الشهادة الرسمية بتنسيق A4 أفقي"
                        >
                          <Printer className="w-3.5 h-3.5 text-amber-100" />
                          <span>طباعة الشهادة</span>
                        </button>

                        {/* Delete Button */}
                        <button
                          type="button"
                          onClick={() => setDeleteConfirmCert(cert)}
                          className="p-1.5 rounded-xl text-slate-500 hover:text-rose-400 hover:bg-rose-950/30 transition"
                          title="حذف الشهادة من السجل"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Certificate Modal */}
      {showAddModal && (
        <AddCertificateModal
          existingCertificates={certificates}
          trainingsList={trainingsList}
          onSave={handleSaveCertificate}
          onClose={() => setShowAddModal(false)}
        />
      )}

      {/* Printable Certificate Modal */}
      {activePrintCert && (
        <TrainingCertificatePrintModal
          certificate={activePrintCert}
          onClose={() => setActivePrintCert(null)}
          onLogAudit={onLogAudit}
        />
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmCert && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-3">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-5 text-right space-y-4 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 text-rose-400">
              <div className="p-2.5 rounded-xl bg-rose-950/80 border border-rose-800">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-100">تأكيد حذف شهادة المتدرب</h3>
                <span className="text-[11px] text-slate-400 font-mono">
                  {deleteConfirmCert.certificate_serial} - {deleteConfirmCert.trainee_name}
                </span>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              هل أنت متأكد من حذف هذه الشهادة من سجل التدريب المعتمد؟ لن يتمكن المتدرب من إثبات
              اجتياز الدورة بعد الحذف.
            </p>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setDeleteConfirmCert(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={() => handleDeleteCertificate(deleteConfirmCert)}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-lg shadow-rose-950"
              >
                <Trash2 className="w-4 h-4" />
                <span>تأكيد الحذف</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
