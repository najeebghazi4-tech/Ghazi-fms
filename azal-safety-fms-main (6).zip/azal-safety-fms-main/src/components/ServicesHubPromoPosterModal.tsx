import React, { useState, useEffect, useRef } from 'react';
import QRCode from 'qrcode';
import {
  Printer,
  Download,
  Copy,
  Check,
  ExternalLink,
  X,
  ShieldCheck,
  AlertTriangle,
  Wrench,
  GraduationCap,
  CheckCircle2,
  QrCode,
  Smartphone,
  Sparkles,
  Share2,
  Building2,
  Award,
  Maximize2
} from 'lucide-react';
import { AzalLogo } from './AzalLogo';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';

interface ServicesHubPromoPosterModalProps {
  isOpen: boolean;
  onClose: () => void;
  customUrl?: string;
}

const DEFAULT_PORTAL_URL = 'https://azal-safety.netlify.app/#services';

export const ServicesHubPromoPosterModal: React.FC<ServicesHubPromoPosterModalProps> = ({
  isOpen,
  onClose,
  customUrl,
}) => {
  const targetUrl = customUrl || DEFAULT_PORTAL_URL;
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const posterRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Generate high-resolution QR code on load
  useEffect(() => {
    let isMounted = true;
    async function generateQr() {
      try {
        const url = await QRCode.toDataURL(targetUrl, {
          errorCorrectionLevel: 'H',
          margin: 1,
          width: 480,
          color: {
            dark: '#071426',
            light: '#FFFFFF',
          },
        });
        if (isMounted) {
          setQrDataUrl(url);
        }
      } catch (err) {
        console.error('Error generating QR for poster:', err);
      }
    }
    generateQr();
    return () => {
      isMounted = false;
    };
  }, [targetUrl]);

  // Handle Copy Link
  const handleCopyLink = async () => {
    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(targetUrl);
      } else {
        const el = document.createElement('textarea');
        el.value = targetUrl;
        document.body.appendChild(el);
        el.select();
        document.execCommand('copy');
        document.body.removeChild(el);
      }
      triggerSuccessFeedback();
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch (e) {
      console.error('Failed to copy', e);
    }
  };

  // Handle Print A4
  const handlePrintPoster = () => {
    triggerSuccessFeedback();
    window.print();
  };

  // Handle High-Res PNG Image Generation via HTML5 Canvas
  const handleDownloadImage = async () => {
    setIsGeneratingImage(true);
    triggerSuccessFeedback();

    try {
      const canvas = document.createElement('canvas');
      // High-res A4 proportions: 1414 x 2000
      const width = 1414;
      const height = 2000;
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');

      if (!ctx) {
        throw new Error('Canvas 2D context not available');
      }

      // 1. Background gradient (Deep Navy to Slate Navy)
      const bgGrad = ctx.createLinearGradient(0, 0, width, height);
      bgGrad.addColorStop(0, '#071324');
      bgGrad.addColorStop(0.5, '#0B1E38');
      bgGrad.addColorStop(1, '#081729');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, width, height);

      // 2. Subtle radial glow behind center
      const glowGrad = ctx.createRadialGradient(width / 2, 700, 50, width / 2, 700, 600);
      glowGrad.addColorStop(0, 'rgba(30, 78, 140, 0.35)');
      glowGrad.addColorStop(1, 'rgba(7, 19, 36, 0)');
      ctx.fillStyle = glowGrad;
      ctx.fillRect(0, 0, width, height);

      // 3. Ornate Double Gold Outer Border
      ctx.strokeStyle = '#D4AF37';
      ctx.lineWidth = 6;
      ctx.strokeRect(36, 36, width - 72, height - 72);

      ctx.strokeStyle = 'rgba(212, 175, 55, 0.4)';
      ctx.lineWidth = 2;
      ctx.strokeRect(48, 48, width - 96, height - 96);

      // Corner geometric ornaments
      const cornerSize = 40;
      const corners = [
        [36, 36],
        [width - 36, 36],
        [36, height - 36],
        [width - 36, height - 36],
      ];
      ctx.fillStyle = '#F59E0B';
      corners.forEach(([cx, cy]) => {
        ctx.beginPath();
        ctx.arc(cx, cy, 8, 0, Math.PI * 2);
        ctx.fill();
      });

      // 4. Header Section
      // Hospital Arabic Title
      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 40px "Segoe UI", Tahoma, Arial, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('مستشفى آزال النموذجي - صنعاء', width / 2, 120);

      ctx.fillStyle = '#94A3B8';
      ctx.font = 'bold 20px "Segoe UI", Tahoma, Arial, sans-serif';
      ctx.fillText('AZAL MODEL HOSPITAL • SANAA, YEMEN', width / 2, 155);

      // Department & FMS Pill
      ctx.fillStyle = 'rgba(212, 175, 55, 0.15)';
      ctx.strokeStyle = '#D4AF37';
      ctx.lineWidth = 2;
      roundRect(ctx, width / 2 - 340, 180, 680, 48, 24, true, true);

      ctx.fillStyle = '#FDE047';
      ctx.font = 'bold 22px "Segoe UI", Tahoma, Arial, sans-serif';
      ctx.fillText('إدارة الأمن والسلامة المهنية وإدارة المرافق (FMS) • معتمد سباهي CBAHI', width / 2, 212);

      // 5. Main Attractive Headline
      ctx.fillStyle = '#FFFFFF';
      ctx.font = '900 54px "Segoe UI", Tahoma, Arial, sans-serif';
      ctx.fillText('بوابة الخدمات والتصاريح الموحدة لسلامة المنشأة', width / 2, 305);

      ctx.fillStyle = '#CBD5E1';
      ctx.font = 'bold 23px "Segoe UI", Tahoma, Arial, sans-serif';
      ctx.fillText('المنظومة الرقمية الشاملة للبلاغات الفورية وتصاريح المقاولين والتدريب الميداني', width / 2, 348);

      // 6. Central Card (White with Gold border) for QR Code
      const cardX = width / 2 - 360;
      const cardY = 390;
      const cardW = 720;
      const cardH = 750;

      // Card background
      ctx.fillStyle = '#FFFFFF';
      ctx.shadowColor = 'rgba(0, 0, 0, 0.4)';
      ctx.shadowBlur = 30;
      ctx.shadowOffsetY = 15;
      roundRect(ctx, cardX, cardY, cardW, cardH, 32, true, false);
      ctx.shadowColor = 'transparent';

      // Card gold border
      ctx.strokeStyle = '#D4AF37';
      ctx.lineWidth = 6;
      roundRect(ctx, cardX, cardY, cardW, cardH, 32, false, true);

      // Inner card top badge
      ctx.fillStyle = '#0F172A';
      ctx.font = 'bold 26px "Segoe UI", Tahoma, Arial, sans-serif';
      ctx.fillText('الرمز الرقمي المعتمد للوصول المباشر', width / 2, cardY + 55);

      // Draw QR Code Image
      if (qrDataUrl) {
        const qrImg = new Image();
        qrImg.crossOrigin = 'anonymous';
        qrImg.src = qrDataUrl;
        await new Promise((resolve) => {
          qrImg.onload = resolve;
          qrImg.onerror = resolve;
        });
        const qrSize = 360;
        ctx.drawImage(qrImg, width / 2 - qrSize / 2, cardY + 80, qrSize, qrSize);
      }

      // Guidance Box inside card (Navy blue box)
      const guideBoxY = cardY + 465;
      ctx.fillStyle = '#0F172A';
      roundRect(ctx, cardX + 40, guideBoxY, cardW - 80, 110, 18, true, false);

      ctx.fillStyle = '#FDE047';
      ctx.font = 'bold 24px "Segoe UI", Tahoma, Arial, sans-serif';
      ctx.fillText('📱 امسح الكود بكاميرا هاتفك لبدء الخدمة فوراً', width / 2, guideBoxY + 45);

      ctx.fillStyle = '#E2E8F0';
      ctx.font = 'normal 18px "Segoe UI", Tahoma, Arial, sans-serif';
      ctx.fillText('يعمل تلقائياً مع جميع كاميرات الهواتف الذكية دون الحاجة لتطبيقات إضافية', width / 2, guideBoxY + 82);

      // Target URL Pill
      const urlBoxY = cardY + 600;
      ctx.fillStyle = '#F1F5F9';
      ctx.strokeStyle = '#CBD5E1';
      ctx.lineWidth = 2;
      roundRect(ctx, cardX + 40, urlBoxY, cardW - 80, 58, 14, true, true);

      ctx.fillStyle = '#0369A1';
      ctx.font = 'bold 21px "Consolas", monospace, sans-serif';
      ctx.fillText(targetUrl, width / 2, urlBoxY + 37);

      ctx.fillStyle = '#64748B';
      ctx.font = 'bold 15px "Segoe UI", Tahoma, Arial, sans-serif';
      ctx.fillText('الرابط المعتمد للمشاركة المباشرة عبر المتصفح', width / 2, cardY + 700);

      // 7. Four Services Badges (2x2 Grid)
      const gridY = 1175;
      const boxW = 590;
      const boxH = 150;
      const col1X = width / 2 + 20; // right side in RTL
      const col2X = width / 2 - boxW - 20; // left side in RTL

      const servicesData = [
        {
          title: 'بلاغات المخاطر ⚠️',
          enTitle: 'Incident & Hazard Reporting',
          desc: 'إبلاغ فوري ومباشر عن أي مخاطر أو تسريبات أو ملاحظات سلامة لضمان أمان المرضى والمنشأة.',
          x: col1X,
          y: gridY,
          color: '#F59E0B',
          bgBorder: '#D97706',
        },
        {
          title: 'تصاريح المقاولين 🛠️',
          enTitle: 'Contractor Work Permits',
          desc: 'تقديم طلبات تصاريح العمل (الساخن، المرتفع، الإنشائي) والتحقق الميداني الفوري من السريان.',
          x: col2X,
          y: gridY,
          color: '#38BDF8',
          bgBorder: '#0284C7',
        },
        {
          title: 'التدريب والتأهيل 🎓',
          enTitle: 'Staff Training & Orientation',
          desc: 'توجيه الموظفين الجدد وحجز دورات السلامة ومكافحة الحريق وترشيح كوادر الأقسام الميدانية.',
          x: col1X,
          y: gridY + 175,
          color: '#A855F7',
          bgBorder: '#9333EA',
        },
        {
          title: 'إفادات الإنجاز ✅',
          enTitle: 'Clearances & Daily Logs',
          desc: 'إشعارات تشغيل المحرقة الطبية وتوثيق إنجاز الملاحظات المرفوعة وإصدار إفادات السلامة.',
          x: col2X,
          y: gridY + 175,
          color: '#34D399',
          bgBorder: '#059669',
        },
      ];

      servicesData.forEach((s) => {
        // Box background
        ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
        roundRect(ctx, s.x, s.y, boxW, boxH, 20, true, false);

        // Gold / colored border
        ctx.strokeStyle = s.bgBorder;
        ctx.lineWidth = 2.5;
        roundRect(ctx, s.x, s.y, boxW, boxH, 20, false, true);

        // Title
        ctx.fillStyle = s.color;
        ctx.font = 'bold 26px "Segoe UI", Tahoma, Arial, sans-serif';
        ctx.textAlign = 'right';
        ctx.fillText(s.title, s.x + boxW - 30, s.y + 44);

        // English Subtitle
        ctx.fillStyle = '#94A3B8';
        ctx.font = 'bold 15px "Segoe UI", Tahoma, Arial, sans-serif';
        ctx.fillText(s.enTitle, s.x + boxW - 30, s.y + 72);

        // Description
        ctx.fillStyle = '#E2E8F0';
        ctx.font = 'normal 17px "Segoe UI", Tahoma, Arial, sans-serif';
        wrapText(ctx, s.desc, s.x + boxW - 30, s.y + 104, boxW - 60, 26);
      });

      // 8. Footer Section (Signature, Stamp & Official Accreditation)
      const footerY = 1580;

      // Divider Line
      ctx.strokeStyle = 'rgba(212, 175, 55, 0.4)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(80, footerY);
      ctx.lineTo(width - 80, footerY);
      ctx.stroke();

      // Footer Info Box
      const sigBoxW = 420;
      const sigBoxH = 180;
      const sigBoxX = width / 2 - sigBoxW / 2;
      const sigBoxY = footerY + 30;

      ctx.fillStyle = 'rgba(212, 175, 55, 0.08)';
      ctx.strokeStyle = '#D4AF37';
      ctx.lineWidth = 2;
      roundRect(ctx, sigBoxX, sigBoxY, sigBoxW, sigBoxH, 20, true, true);

      ctx.fillStyle = '#FDE047';
      ctx.font = 'bold 18px "Segoe UI", Tahoma, Arial, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('التوقيع والاعتماد الرسمي للسلامة', width / 2, sigBoxY + 35);

      ctx.fillStyle = '#FFFFFF';
      ctx.font = '900 24px "Segoe UI", Tahoma, Arial, sans-serif';
      ctx.fillText('م/ نجيب قاسم غازي', width / 2, sigBoxY + 75);

      ctx.fillStyle = '#CBD5E1';
      ctx.font = 'bold 17px "Segoe UI", Tahoma, Arial, sans-serif';
      ctx.fillText('رئيس قسم الأمن والسلامة وإدارة المرافق (FMS)', width / 2, sigBoxY + 110);

      ctx.fillStyle = '#34D399';
      ctx.font = 'bold 16px "Segoe UI", Tahoma, Arial, sans-serif';
      ctx.fillText('✓ الاعتماد الرقمي المعتمد • مستشفى آزال النموذجي', width / 2, sigBoxY + 145);

      // Bottom Disclaimer & Standards
      ctx.fillStyle = '#94A3B8';
      ctx.font = 'normal 16px "Segoe UI", Tahoma, Arial, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(
        'وثيقة وبوستر إعلاني رسمي معتمد • نظام إدارة السلامة FMS • متوافق مع معايير سباهي CBAHI • المرجع: AZAL-PUB-POSTER-2026',
        width / 2,
        height - 65
      );

      // Download the generated high-res canvas as PNG
      const dataUrl = canvas.toDataURL('image/png', 1.0);
      const link = document.createElement('a');
      link.download = `بوستر_إعلان_بوابة_الخدمات_الموحدة_مستشفى_آزال_${Date.now()}.png`;
      link.href = dataUrl;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      console.error('Error generating poster image:', err);
      alert('حدث خطأ أثناء توليد الصورة، يرجى المحاولة مرة أخرى أو استخدام زر الطباعة.');
    } finally {
      setIsGeneratingImage(false);
    }
  };

  // Canvas text wrapping helper
  function wrapText(
    ctx: CanvasRenderingContext2D,
    text: string,
    x: number,
    y: number,
    maxWidth: number,
    lineHeight: number
  ) {
    const words = text.split(' ');
    let line = '';
    let currentY = y;

    for (let n = 0; n < words.length; n++) {
      const testLine = line + words[n] + ' ';
      const metrics = ctx.measureText(testLine);
      const testWidth = metrics.width;
      if (testWidth > maxWidth && n > 0) {
        ctx.fillText(line, x, currentY);
        line = words[n] + ' ';
        currentY += lineHeight;
      } else {
        line = testLine;
      }
    }
    ctx.fillText(line, x, currentY);
  }

  // Canvas rounded rectangle helper
  function roundRect(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    w: number,
    h: number,
    r: number,
    fill: boolean,
    stroke: boolean
  ) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
    if (fill) ctx.fill();
    if (stroke) ctx.stroke();
  }

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md overflow-y-auto flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-200">
      {/* Hidden print stylesheet for A4 portrait full-color */}
      <style>{`
        @media print {
          body * {
            visibility: hidden !important;
          }
          #services-promo-poster-printable, #services-promo-poster-printable * {
            visibility: visible !important;
          }
          #services-promo-poster-printable {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
            max-width: 100% !important;
            margin: 0 !important;
            padding: 16mm 12mm !important;
            box-shadow: none !important;
            border-radius: 0 !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          @page {
            size: A4 portrait;
            margin: 0;
          }
          .no-print-poster {
            display: none !important;
          }
        }
      `}</style>

      <div className="bg-slate-900 border border-amber-500/40 rounded-3xl max-w-4xl w-full my-auto shadow-2xl overflow-hidden flex flex-col max-h-[96vh]">
        {/* Top Action & Control Header Bar (no-print) */}
        <div className="no-print-poster bg-slate-950/95 border-b border-amber-500/30 p-3 sm:p-4 flex flex-wrap items-center justify-between gap-3 sticky top-0 z-20 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-yellow-600 text-slate-950 flex items-center justify-center font-black shadow-md shadow-amber-950">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-black text-white">
                  بوستر إعلان بوابة الخدمات والتصاريح الموحدة (A4 Portrait)
                </h3>
                <span className="text-[10px] bg-amber-950/80 text-amber-300 border border-amber-500/50 px-2 py-0.5 rounded-full font-bold">
                  هوية كحلية وذهبية فاخرة
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                جاهز للطباعة والتعليق في لوحات إعلانات الأقسام ومشاركته كصورة فائقة الدقة في مجموعات العمل
              </p>
            </div>
          </div>

          {/* Action Buttons Suite */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* 1. Download PNG Image Button */}
            <button
              type="button"
              onClick={handleDownloadImage}
              disabled={isGeneratingImage}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 via-amber-600 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 font-black text-xs shadow-lg shadow-amber-950 flex items-center gap-1.5 transition active:scale-95 cursor-pointer disabled:opacity-50"
              title="تحميل البوستر كصورة PNG عالية الدقة للمشاركة على واتساب ومجموعات الأقسام"
            >
              <Download className="w-4 h-4 text-slate-950" />
              <span>{isGeneratingImage ? 'جاري إنشاء الصورة...' : '📥 تحميل البوستر كصورة (PNG)'}</span>
            </button>

            {/* 2. Direct Print / Save as PDF */}
            <button
              type="button"
              onClick={handlePrintPoster}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-bold text-xs shadow-md shadow-teal-950 flex items-center gap-1.5 transition active:scale-95 cursor-pointer"
              title="طباعة البوستر مباشرة بمقاس A4 أو حفظه كملف PDF"
            >
              <Printer className="w-4 h-4 text-white" />
              <span>🖨️ طباعة / PDF</span>
            </button>

            {/* 3. Copy Link */}
            <button
              type="button"
              onClick={handleCopyLink}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
              title="نسخ رابط البوابة الموحدة"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-amber-400" />}
              <span>{copied ? 'تم النسخ' : 'نسخ الرابط'}</span>
            </button>

            {/* 4. Open Live Hub */}
            <a
              href={targetUrl}
              target="_blank"
              rel="noreferrer"
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 border border-teal-800/60 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
              title="فتح البوابة في نافذة جديدة"
            >
              <ExternalLink className="w-4 h-4" />
              <span className="hidden sm:inline">معاينة البوابة</span>
            </a>

            {/* Close Modal */}
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition cursor-pointer"
              title="إغلاق النافذة"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Container with Zoomed A4 Poster View */}
        <div className="overflow-y-auto p-4 sm:p-8 flex justify-center bg-slate-950/70">
          {/* THE OFFICIAL NAVY & GOLD A4 POSTER */}
          <div
            id="services-promo-poster-printable"
            ref={posterRef}
            className="w-full max-w-[660px] bg-gradient-to-b from-[#071324] via-[#0B1E38] to-[#081729] text-white rounded-3xl p-6 sm:p-8 border-4 border-[#D4AF37] shadow-2xl relative overflow-hidden"
            style={{ minHeight: '930px' }}
          >
            {/* Background Decorative Gold Accents */}
            <div className="absolute -top-24 -right-24 w-60 h-60 rounded-full bg-amber-500/10 blur-3xl pointer-events-none" />
            <div className="absolute -bottom-24 -left-24 w-60 h-60 rounded-full bg-teal-500/10 blur-3xl pointer-events-none" />

            {/* Inner Thin Border Line */}
            <div className="absolute inset-2 sm:inset-3 border border-amber-400/30 rounded-2xl pointer-events-none" />

            {/* Top Corner Ornaments */}
            <div className="absolute top-4 right-4 w-3 h-3 rounded-full bg-amber-400 shadow-md shadow-amber-400/50" />
            <div className="absolute top-4 left-4 w-3 h-3 rounded-full bg-amber-400 shadow-md shadow-amber-400/50" />
            <div className="absolute bottom-4 right-4 w-3 h-3 rounded-full bg-amber-400 shadow-md shadow-amber-400/50" />
            <div className="absolute bottom-4 left-4 w-3 h-3 rounded-full bg-amber-400 shadow-md shadow-amber-400/50" />

            {/* Header Section */}
            <div className="relative z-10 text-center space-y-2.5 pb-4 border-b border-amber-500/30">
              {/* Institution Emblem and Name */}
              <div className="flex items-center justify-between px-2">
                <div className="text-right">
                  <span className="text-[10px] text-slate-300 font-bold block">الجمهورية اليمنية</span>
                  <span className="text-[10px] text-amber-300 font-bold block">وزارة الصحة العامة والسكان</span>
                </div>

                <div className="flex flex-col items-center">
                  <div className="p-1.5 rounded-2xl bg-white/10 backdrop-blur-md border border-amber-400/40 shadow-md">
                    <AzalLogo size="md" showText={false} />
                  </div>
                </div>

                <div className="text-left font-mono" dir="ltr">
                  <span className="text-[10px] text-amber-300 font-bold block">AZAL HOSPITAL</span>
                  <span className="text-[9px] text-slate-400 block">FMS & SAFETY DEPT</span>
                </div>
              </div>

              {/* Hospital Title */}
              <div>
                <h1 className="text-xl sm:text-2xl font-black text-white tracking-wide">
                  مستشفى آزال النموذجي - صنعاء
                </h1>
                <p className="text-[11px] sm:text-xs text-amber-200/90 font-bold mt-0.5">
                  إدارة الأمن والسلامة المهنية وإدارة المرافق (FMS) • معتمد سباهي CBAHI
                </p>
              </div>

              {/* Attractive Grand Title Banner */}
              <div className="pt-2">
                <div className="inline-block px-4 py-1 rounded-full bg-amber-500/20 border border-amber-400/60 mb-1.5">
                  <span className="text-[10px] sm:text-xs font-black text-amber-300 tracking-wider">
                    ⚡ المنظومة الرقمية الشاملة لخدمات وتصاريح السلامة 2026
                  </span>
                </div>
                <h2 className="text-xl sm:text-3xl font-black text-white leading-tight bg-gradient-to-r from-amber-200 via-white to-amber-200 bg-clip-text text-transparent drop-shadow-sm">
                  بوابة الخدمات والتصاريح الموحدة لسلامة المنشأة
                </h2>
                <p className="text-[11px] sm:text-xs text-slate-300 mt-1 max-w-lg mx-auto">
                  المنصة الرقمية المتكاملة للبلاغات الفورية، تصاريح العمل للمقاولين، برامج التدريب، وإفادات السلامة
                </p>
              </div>
            </div>

            {/* Central Card: Large QR Code & Access Link */}
            <div className="relative z-10 my-4 sm:my-5">
              <div className="bg-white text-slate-950 rounded-2xl p-4 sm:p-5 border-2 border-amber-400 shadow-2xl text-center space-y-3 relative">
                {/* Gold Top Badge */}
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900 text-amber-300 text-[11px] font-black shadow-inner">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>الرمز الرقمي المعتمد للوصول المباشر (Zero-Auth Hub)</span>
                </div>

                {/* QR Code Container */}
                <div className="p-3 bg-slate-50 rounded-2xl inline-block border border-slate-200 shadow-inner">
                  {qrDataUrl ? (
                    <img
                      src={qrDataUrl}
                      alt="رمز QR بوابة الخدمات والتصاريح الموحدة"
                      className="w-40 h-40 sm:w-48 sm:h-48 object-contain mx-auto transition-transform hover:scale-105 duration-300"
                    />
                  ) : (
                    <div className="w-44 h-44 flex items-center justify-center text-slate-400 text-xs">
                      جاري تجهيز رمز الـ QR...
                    </div>
                  )}
                </div>

                {/* Clear Guiding Phrase (العبارة التوجيهية المطلوبة) */}
                <div className="bg-[#0B1E38] text-white rounded-xl p-3 border border-amber-400/40 shadow-inner">
                  <div className="flex items-center justify-center gap-2 text-amber-300 font-black text-xs sm:text-sm">
                    <Smartphone className="w-4 h-4 text-amber-400 animate-bounce" />
                    <span>امسح الكود بكاميرا هاتفك لبدء الخدمة فوراً دون الحاجة لتطبيقات إضافية</span>
                  </div>
                  <p className="text-[10px] text-slate-300 mt-1">
                    يعمل ذاتياً مع كاميرات جميع الهواتف (iPhone / Android) بدون أي تسجيل دخول مسبق
                  </p>
                </div>

                {/* Verified Target URL */}
                <div className="bg-slate-100 rounded-xl p-2.5 border border-slate-300 text-left">
                  <div className="text-[9px] text-slate-500 font-bold mb-0.5 text-right">
                    الرابط المعتمد للبوابة (Direct Target URL):
                  </div>
                  <div className="text-xs sm:text-sm text-teal-900 font-mono font-black select-all break-all" dir="ltr">
                    {targetUrl}
                  </div>
                </div>
              </div>
            </div>

            {/* The 4 Main Services Badges */}
            <div className="relative z-10 grid grid-cols-1 sm:grid-cols-2 gap-2.5 my-3">
              {/* 1. بلاغات المخاطر */}
              <div className="bg-slate-900/90 border border-amber-500/40 rounded-xl p-3 flex items-start gap-3 shadow-md hover:border-amber-400 transition">
                <div className="w-10 h-10 rounded-xl bg-amber-950/80 border border-amber-500/60 text-amber-400 flex items-center justify-center text-lg shrink-0 font-bold">
                  ⚠️
                </div>
                <div className="text-right">
                  <h4 className="text-xs sm:text-sm font-black text-amber-300">
                    بلاغات المخاطر الميدانية
                  </h4>
                  <p className="text-[10px] sm:text-[11px] text-slate-300 leading-snug mt-0.5">
                    إبلاغ فوري ومباشر عن أي مخاطر أو تسريبات أو مخالفات سلامة دون تسجيل دخول لسرعة الاستجابة.
                  </p>
                </div>
              </div>

              {/* 2. تصاريح المقاولين */}
              <div className="bg-slate-900/90 border border-sky-500/40 rounded-xl p-3 flex items-start gap-3 shadow-md hover:border-sky-400 transition">
                <div className="w-10 h-10 rounded-xl bg-sky-950/80 border border-sky-500/60 text-sky-400 flex items-center justify-center text-lg shrink-0 font-bold">
                  🛠️
                </div>
                <div className="text-right">
                  <h4 className="text-xs sm:text-sm font-black text-sky-300">
                    تصاريح عمل المقاولين
                  </h4>
                  <p className="text-[10px] sm:text-[11px] text-slate-300 leading-snug mt-0.5">
                    إصدار وتجديد تصاريح العمل (الساخن، المرتفع، الإنشائي) والتحقق الميداني الفوري من السريان.
                  </p>
                </div>
              </div>

              {/* 3. التدريب والتأهيل */}
              <div className="bg-slate-900/90 border border-purple-500/40 rounded-xl p-3 flex items-start gap-3 shadow-md hover:border-purple-400 transition">
                <div className="w-10 h-10 rounded-xl bg-purple-950/80 border border-purple-500/60 text-purple-400 flex items-center justify-center text-lg shrink-0 font-bold">
                  🎓
                </div>
                <div className="text-right">
                  <h4 className="text-xs sm:text-sm font-black text-purple-300">
                    التدريب والتأهيل الميداني
                  </h4>
                  <p className="text-[10px] sm:text-[11px] text-slate-300 leading-snug mt-0.5">
                    توجيه وتدريب الموظفين الجدد وحجز مقاعد السلامة ومكافحة الحريق وترشيح كوادر الأقسام.
                  </p>
                </div>
              </div>

              {/* 4. إفادات الإنجاز */}
              <div className="bg-slate-900/90 border border-emerald-500/40 rounded-xl p-3 flex items-start gap-3 shadow-md hover:border-emerald-400 transition">
                <div className="w-10 h-10 rounded-xl bg-emerald-950/80 border border-emerald-500/60 text-emerald-400 flex items-center justify-center text-lg shrink-0 font-bold">
                  ✅
                </div>
                <div className="text-right">
                  <h4 className="text-xs sm:text-sm font-black text-emerald-300">
                    إفادات الإنجاز والتشغيل
                  </h4>
                  <p className="text-[10px] sm:text-[11px] text-slate-300 leading-snug mt-0.5">
                    إشعارات تشغيل المحرقة الطبية وتوثيق معالجة الملاحظات المرفوعة وإصدار إفادات السلامة الرسمية.
                  </p>
                </div>
              </div>
            </div>

            {/* Official Footer: Signature and Certification */}
            <div className="relative z-10 pt-3 mt-3 border-t border-amber-500/30 text-center space-y-2">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-950/60 p-3 rounded-2xl border border-amber-500/20">
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 font-bold block">التوقيع والاعتماد الرسمي:</span>
                  <div className="text-sm font-black text-amber-300">
                    رئيس قسم الأمن والسلامة وإدارة المرافق (FMS): م/ نجيب قاسم غازي
                  </div>
                  <span className="text-[10px] text-emerald-400 font-mono font-bold block mt-0.5">
                    ✓ معتمد ومصادق عليه إلكترونياً
                  </span>
                </div>

                {/* Institutional Security Seal Stamp */}
                <div className="w-24 h-14 border-2 border-dashed border-amber-400 rounded-2xl flex flex-col items-center justify-center bg-amber-950/30 text-amber-300 text-[9px] font-black shrink-0">
                  <ShieldCheck className="w-4 h-4 text-amber-400 mb-0.5" />
                  <span>ختم السلامة الرسمي</span>
                  <span className="text-[8px] text-slate-300">AZAL FMS 2026</span>
                </div>
              </div>

              {/* Footnote */}
              <div className="text-[9px] text-slate-400 font-mono text-center">
                نظام إدارة السلامة الموحد • مستشفى آزال النموذجي • صنعاء، الجمهورية اليمنية • CBAHI Standards Compliant
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServicesHubPromoPosterModal;
