import React, { useState } from 'react';
import { 
  Award, 
  ShieldCheck, 
  AlertTriangle, 
  RefreshCw, 
  ChevronDown, 
  ChevronUp, 
  ExternalLink, 
  CheckCircle2, 
  Clock, 
  FileCheck,
  Sparkles,
  Target
} from 'lucide-react';
import { CBAHI_39_STANDARDS } from '../data/azalCbahiData';
import { CbahiStandardItem } from '../types';

interface CbahiComplianceBannerProps {
  onOpenCbahiRegisters?: () => void;
  onOpenFocusPdcaModal?: () => void;
  onLogAudit?: (action: string, actionAr: string, details: string) => void;
}

export const CbahiComplianceBanner: React.FC<CbahiComplianceBannerProps> = ({
  onOpenCbahiRegisters,
  onOpenFocusPdcaModal,
  onLogAudit
}) => {
  const [standards, setStandards] = useState<CbahiStandardItem[]>(CBAHI_39_STANDARDS);
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState('منذ لحظات');
  const [showAttentionModal, setShowAttentionModal] = useState(false);
  const [syncSuccessToast, setSyncSuccessToast] = useState<string | null>(null);

  // Compute live compliance statistics
  const totalStandards = standards.length;
  const avgCompliance = totalStandards > 0
    ? Math.round(standards.reduce((sum, s) => sum + s.complianceRate, 0) / totalStandards)
    : 96;

  const esrStandards = standards.filter(s => s.esr);
  const esrFullyCompliant = esrStandards.filter(s => s.complianceRate >= 95).length;
  
  // Standards requiring immediate attention (below 95% compliance)
  const attentionRequiredStandards = standards.filter(s => s.complianceRate < 95);

  const handleSyncUpdates = async () => {
    setIsSyncing(true);
    // Simulate real-time compliance audit & sync
    await new Promise(r => setTimeout(r, 800));

    // Refresh timestamps and re-evaluate compliance
    const nowTime = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
    setLastSyncTime(`اليوم ${nowTime}`);
    setIsSyncing(false);
    setSyncSuccessToast('تمت مزامنة وفحص مطابقة معايير سباهي (39 معيار FMS) بنجاح.');
    
    if (onLogAudit) {
      onLogAudit(
        'CBAHI_STANDARDS_SYNCED',
        'مزامنة معايير سباهي الدورية',
        `تم فحص ومزامنة معايير FMS الـ 39. نسبة الامتثال الحالية: ${avgCompliance}% (${esrFullyCompliant}/${esrStandards.length} معايير سلامة أساسية ESR مستوفاة).`
      );
    }

    setTimeout(() => setSyncSuccessToast(null), 3500);
  };

  return (
    <div className="bg-gradient-to-r from-slate-900 via-teal-950/70 to-slate-900 border-2 border-teal-600/70 rounded-2xl p-4 shadow-xl text-right relative overflow-hidden transition-all">
      {/* Subtle background glow */}
      <div className="absolute top-0 left-0 w-56 h-56 bg-teal-500/10 rounded-full blur-2xl pointer-events-none" />

      {/* Main Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 relative z-10">
        {/* Left / Status Section */}
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-950/90 border border-teal-500/50 text-teal-300 shadow-inner flex items-center justify-center shrink-0">
            <Award className="w-6 h-6 text-teal-400 animate-pulse" />
          </div>

          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-black text-teal-300 uppercase tracking-wide">
                CBAHI FMS Compliance Tracker
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold">
                🟢 الاعتماد الوطني سباهي (الإصدار الثالث)
              </span>
              <span className="text-[10px] text-slate-400 font-mono">
                آخر فحص: {lastSyncTime}
              </span>
            </div>

            <h3 className="text-sm sm:text-base font-black text-slate-100 mt-0.5">
              مؤشر الامتثال لمعايير إدارة المرافق والسلامة (FMS):{' '}
              <span className="text-emerald-400 font-mono text-base sm:text-lg font-black mr-1">
                {avgCompliance}%
              </span>
              <span className="text-xs font-normal text-slate-300 mr-2">
                (جاهزية معتمدة ومطابقة لمتطلبات التقييم النهائي)
              </span>
            </h3>
          </div>
        </div>

        {/* Metrics & Quick Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5 self-start lg:self-auto">
          {/* ESR Metrics Chip */}
          <div className="bg-slate-950/80 border border-teal-800/80 rounded-xl px-3 py-1.5 flex items-center gap-2 text-xs">
            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            <div>
              <span className="text-[10px] text-slate-400 block font-medium">معايير السلامة الأساسية (ESR):</span>
              <span className="font-bold text-emerald-300 font-mono">
                {esrFullyCompliant} / {esrStandards.length} مستوفاة بنسبة عالية
              </span>
            </div>
          </div>

          {/* Attention Required Toggle Button */}
          <button
            type="button"
            onClick={() => setShowAttentionModal(!showAttentionModal)}
            className={`px-3 py-1.5 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition ${
              attentionRequiredStandards.length > 0
                ? 'bg-amber-950/60 border-amber-600/70 text-amber-300 hover:bg-amber-900/60'
                : 'bg-slate-800 border-slate-700 text-slate-300'
            }`}
            title="عرض المعايير التي تتطلب متابعة مستمرة"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            <span>معايير للمتابعة ({attentionRequiredStandards.length})</span>
            {showAttentionModal ? (
              <ChevronUp className="w-3.5 h-3.5" />
            ) : (
              <ChevronDown className="w-3.5 h-3.5" />
            )}
          </button>

          {/* Instant Sync / Update Check Button */}
          <button
            type="button"
            onClick={handleSyncUpdates}
            disabled={isSyncing}
            className="px-3.5 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-500 disabled:opacity-50 text-slate-950 font-black text-xs shadow-md shadow-teal-950 flex items-center gap-1.5 transition"
            title="التحقق الفوري من التحديثات ومزامنة المعايير مع السجلات الميدانية"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? 'جارٍ الفحص...' : 'التحقق من التحديثات'}</span>
          </button>

          {/* Open Full CBAHI Registers */}
          {onOpenCbahiRegisters && (
            <button
              type="button"
              onClick={onOpenCbahiRegisters}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold flex items-center gap-1.5 transition"
              title="فتح السجل الشامل لسباهي (39 معياراً)"
            >
              <ExternalLink className="w-3.5 h-3.5 text-teal-400" />
              <span>سجلات سباهي الـ 39</span>
            </button>
          )}

          {/* CBAHI FOCUS-PDCA Quality KPI Trigger */}
          {onOpenFocusPdcaModal && (
            <button
              type="button"
              onClick={onOpenFocusPdcaModal}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-teal-500 via-emerald-600 to-indigo-600 hover:from-teal-400 hover:to-indigo-500 text-white font-black text-xs shadow-md shadow-teal-950 flex items-center gap-1.5 transition active:scale-95 ring-1 ring-teal-300/40"
              title="عرض تقرير منهجية التحسين المستمر FOCUS-PDCA ومؤشرات الجودة"
            >
              <Target className="w-3.5 h-3.5 text-teal-100" />
              <span>منهجية FOCUS-PDCA</span>
            </button>
          )}
        </div>
      </div>

      {/* Sync Success Notification Toast */}
      {syncSuccessToast && (
        <div className="mt-3 p-2 bg-emerald-950/80 border border-emerald-600 rounded-xl text-xs text-emerald-300 flex items-center gap-2 animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{syncSuccessToast}</span>
        </div>
      )}

      {/* Attention Standards Drawer */}
      {showAttentionModal && (
        <div className="mt-3 pt-3 border-t border-slate-800 space-y-2 animate-fade-in">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span>المعايير التي تتطلب استكمال وثائق أو متابعة دورية مستمرة:</span>
            </span>
            <span className="text-[11px] text-slate-400">
              جميع المعايير في النطاق الآمن (أعلى من 90%) ولكن بحاجة لأرشفة دورية
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-2">
            {attentionRequiredStandards.map((std) => (
              <div 
                key={std.code}
                className="bg-slate-950/90 border border-amber-800/40 hover:border-amber-600/80 rounded-xl p-2.5 text-xs space-y-1.5 transition"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="font-mono font-black text-amber-400 bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-800/60">
                      {std.code}
                    </span>
                    <strong className="text-slate-100 text-xs">{std.titleAr}</strong>
                  </div>
                  <span className="font-mono font-bold text-amber-400 text-xs">
                    {std.complianceRate}%
                  </span>
                </div>

                <p className="text-[11px] text-slate-400 line-clamp-1">
                  {std.description}
                </p>

                <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1 border-t border-slate-900">
                  <span>القطاع: <strong className="text-slate-300">{std.category}</strong></span>
                  <span className="text-teal-400 font-medium">
                    {std.esr ? '⭐ معيار سلامة أساسي ESR' : 'معيار FMS'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
