import React, { useState } from 'react';
import { 
  FileText, 
  Printer, 
  Download, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldCheck, 
  Flame, 
  Building2, 
  Activity, 
  Target, 
  TrendingUp, 
  Compass, 
  Share2,
  Copy,
  Check
} from 'lucide-react';
import { 
  SafetyIncidentReport, 
  SafetyTourRecord, 
  SafetyViolationNotice, 
  FireExtinguisherItem, 
  StaffUser
} from '../types';
import { AzalLogo } from './AzalLogo';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';
import { printExistingElementById } from '../utils/printUtils';

interface CbahiFocusPdcaModalProps {
  incidents: SafetyIncidentReport[];
  tours: SafetyTourRecord[];
  violations: SafetyViolationNotice[];
  extinguishers: FireExtinguisherItem[];
  currentUser: StaffUser;
  onClose: () => void;
}

export const CbahiFocusPdcaModal: React.FC<CbahiFocusPdcaModalProps> = ({
  incidents,
  tours,
  violations,
  extinguishers,
  currentUser,
  onClose
}) => {
  const [copied, setCopied] = useState(false);

  // Calculate real metrics
  const totalIncidents = incidents.length;
  const codeOrangeIncidents = incidents.filter(i => (i as any).isCodeOrangeSpill || i.codeOrange?.isCodeOrange || i.category === 'chemical_spill').length;
  const medicalDeviceIncidents = incidents.filter(i => (i as any).medicalDeviceInvolved || !!i.medicalDeviceDetails?.deviceName || i.category === 'equipment_malfunction').length;
  const smokingIncidents = incidents.filter(i => (i as any).isSmokingViolation || !!i.smokingDetails?.violatorType || i.category === 'smoking').length;
  const highSeverityIncidents = incidents.filter(i => i.severity === 'critical' || i.severity === 'high').length;
  
  const totalExtinguishers = extinguishers.length || 1;
  const readyExtinguishers = extinguishers.filter(e => (e as any).status === 'valid' || e.conditionStatus === 'valid' || e.gaugeStatus === 'normal').length;
  const extinguisherReadinessRate = Math.round((readyExtinguishers / totalExtinguishers) * 100);

  const resolvedViolations = violations.filter(v => v.status === 'resolved' || (v.status as string) === 'closed').length;
  const totalViolations = violations.length || 1;
  const violationResolutionRate = Math.round((resolvedViolations / totalViolations) * 100);

  const handlePrint = () => {
    triggerSuccessFeedback();
    printExistingElementById('focus-pdca-print-content', {
      title: 'تقرير مؤشرات أداء الجودة والتحسين المستمر (CBAHI FOCUS-PDCA)',
      department: 'إدارة السلامة والجودة وإدارة المرافق FMS',
      refNumber: 'AZAL-QI-PDCA-2026'
    });
  };

  const getFullReportText = () => {
    return `
================================================================================
مستشفى آزال النموذجي - صنعاء
إدارة الأمن والسلامة المهنية وإدارة المرافق (FMS) • قسم الجودة والاعتماد
تقرير مؤشرات أداء الجودة والتحسين المستمر (CBAHI FOCUS-PDCA KPI Report)
رقم المرجع: AZAL-QI-PDCA-2026 | التاريخ: ${new Date().toLocaleDateString('ar-YE')}
المعد: ${currentUser.name} (${currentUser.role})
================================================================================

أولاً: ملخص المؤشرات الرقمية الحيوية (Key Performance Indicators):
--------------------------------------------------------------------------------
1. إجمالي بلاغات وحوادث الـ OVR المسجلة: ${totalIncidents} بلاغ
2. بلاغات النداء البرتقالي للانسكابات الكيميائية والبيولوجية (Code Orange): ${codeOrangeIncidents}
3. بلاغات أعطال وسوء استخدام الأجهزة الطبية: ${medicalDeviceIncidents}
4. مخالفات التدخين المحظور المرصودة: ${smokingIncidents}
5. نسبة الجاهزية التشغيلية لطفايات الحريق: ${extinguisherReadinessRate}% (${readyExtinguishers} صالحة من أصل ${totalExtinguishers})
6. نسبة معالجة وإغلاق إشعارات مخالفات السلامة: ${violationResolutionRate}% (${resolvedViolations} مغلقة)

ثانياً: تطبيق منهجية التحسين المستمر FOCUS-PDCA:
--------------------------------------------------------------------------------
[F] Find Process: تحسين زمن الاستجابة لبلاغات الطوارئ ورفع جاهزية منظومات مكافحة الحريق ومحطة الغازات الطبية إلى 100%.
[O] Organize Team: لجنة السلامة وإدارة المرافق (FMS) برئاسة مدير عام المستشفى (د/ محمد السراجي)، المدير الطبي (د/ أحمد الأهدل)، منسق الجودة والاعتماد (د/ علي الظبيبي)، ورئيس لجنة السلامة وإدارة المرافق (م/ نجيب غازي).
[C] Clarify Knowledge: تدفق البيانات اللحظي عبر نظام "أمن آزال" الرقمي والربط اللحظي بين بوابات البلاغات ومسؤولي الأقسام.
[U] Understand Root Causes: تحليل الأسباب الجذرية (الحاجة للتدريب المستمر على Spill Kits وتسريع استبدال خراطيم وصمامات الطفايات).
[S] Select Strategy: أتمتة الفحص الميداني الذكي بالباركود QR، إطلاق الإشعارات الفورية عبر الواتساب، وتثبيت نقاط تفتيش رقمية للمناطق الحساسة الأربع.
[P] Plan: خفض معدل تكرار حوادث السلامة بنسبة 35% وإبقاء جاهزية الأجهزة الحيوية وشبكة الغازات عند 100%.
[D] Do: تطبيق التفتيش الدوري الأسبوعي والشهري للمولدات ولوحة إنذار الحريق FACP وتفعيل سجل خروج الممتلكات.
[C] Check: مراجعة مؤشرات الأداء شهرياً وتدقيق الالتزام بمعايير سباهي FMS.1 حتى FMS.12.
[A] Act: مأسسة إجراءات العمل القياسية (SOPs) وتحديث كتيب سياسات السلامة لسباهي (CBAHI FMS Policies).

ثالثاً: الاعتماد والمصادقة الرسمية:
--------------------------------------------------------------------------------
- منسق الجودة والاعتماد: د/ علي الظبيبي [معتمد رسمياً]
- المدير الطبي: د/ أحمد الأهدل [معتمد رسمياً]
- رئيس لجنة السلامة وإدارة المرافق (FMS): م/ نجيب غازي [معتمد رسمياً]
- مدير عام المستشفى: د/ محمد السراجي [معتمد ومصادق رسمياً]
================================================================================
    `.trim();
  };

  const handleCopyText = () => {
    const text = getFullReportText();
    navigator.clipboard.writeText(text);
    triggerSuccessFeedback();
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownloadDoc = () => {
    const text = getFullReportText();
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `CBAHI-FOCUS-PDCA-REPORT-${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    triggerSuccessFeedback();
  };

  return (
    <div id="cbahi-focus-pdca-modal" className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
      <div className="bg-slate-900 border border-teal-500/60 rounded-3xl w-full max-w-4xl overflow-hidden shadow-2xl flex flex-col max-h-[94vh]">
        {/* Header */}
        <div className="bg-slate-950 px-6 py-4 border-b border-slate-800 flex items-center justify-between text-right">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-teal-950 text-teal-400 border border-teal-800">
              <Target className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-slate-100">
                  تقرير الجودة والتحسين المستمر (CBAHI FOCUS-PDCA KPI Report)
                </h2>
                <span className="text-[10px] bg-teal-950 text-teal-300 border border-teal-700 font-bold px-2 py-0.5 rounded-lg">
                  معيار الجودة FMS.QI
                </span>
              </div>
              <p className="text-xs text-slate-400">
                مستشفى آزال النموذجي • الإدارة العامة ولجنة السلامة وإدارة المرافق
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleCopyText}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold flex items-center gap-1.5 transition"
              title="نسخ نص التقرير"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span className="hidden sm:inline">{copied ? 'تم النسخ' : 'نسخ التقرير'}</span>
            </button>

            <button
              type="button"
              onClick={handleDownloadDoc}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold flex items-center gap-1.5 transition"
              title="تحميل ملف التقرير"
            >
              <Download className="w-4 h-4 text-teal-400" />
              <span className="hidden sm:inline">تحميل نصي</span>
            </button>

            <button
              type="button"
              onClick={handlePrint}
              className="p-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md transition"
              title="طباعة تقرير التحسين"
            >
              <Printer className="w-4 h-4" />
              <span className="hidden sm:inline">طباعة رسمية (Print / PDF)</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-100 transition"
              title="إإغلاق"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Printable Content Body */}
        <div id="focus-pdca-print-content" className="p-6 overflow-y-auto space-y-6 text-right text-xs print:p-0 print:text-black">
          {/* Institutional Print Header */}
          <div className="border-b border-slate-800 pb-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <AzalLogo className="w-12 h-12" />
              <div>
                <div className="font-bold text-base text-slate-100">مستشفى آزال النموذجي • صنعاء</div>
                <div className="text-slate-400 text-xs">إدارة الأمن والسلامة المهنية وإدارة المرافق (FMS)</div>
              </div>
            </div>
            <div className="text-left font-mono text-[11px] text-slate-400">
              <div>Ref: AZAL-QI-PDCA-2026</div>
              <div>Date: {new Date().toISOString().split('T')[0]}</div>
              <div className="text-teal-400 font-semibold">CBAHI Standard FMS.1</div>
            </div>
          </div>

          {/* Aggregated KPI Scorecard */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-slate-950/80 border border-slate-800 p-3.5 rounded-2xl">
              <div className="text-slate-400 text-[11px]">جاهزية طفايات الحريق</div>
              <div className="text-2xl font-black text-emerald-400 mt-1">{extinguisherReadinessRate}%</div>
              <div className="text-[10px] text-slate-500">{readyExtinguishers} من أصل {totalExtinguishers} صالحة</div>
            </div>

            <div className="bg-slate-950/80 border border-slate-800 p-3.5 rounded-2xl">
              <div className="text-slate-400 text-[11px]">مؤشر إغلاق المخالفات</div>
              <div className="text-2xl font-black text-teal-400 mt-1">{violationResolutionRate}%</div>
              <div className="text-[10px] text-slate-500">{resolvedViolations} مخالفة تم تصحيحها</div>
            </div>

            <div className="bg-slate-950/80 border border-slate-800 p-3.5 rounded-2xl">
              <div className="text-slate-400 text-[11px]">حوادث وانسكابات Code Orange</div>
              <div className="text-2xl font-black text-amber-400 mt-1">{codeOrangeIncidents}</div>
              <div className="text-[10px] text-slate-500">تم احتواؤها بعدة الانسكاب</div>
            </div>

            <div className="bg-slate-950/80 border border-slate-800 p-3.5 rounded-2xl">
              <div className="text-slate-400 text-[11px]">أعطال الأجهزة الطبية OVR</div>
              <div className="text-2xl font-black text-blue-400 mt-1">{medicalDeviceIncidents}</div>
              <div className="text-[10px] text-slate-500">تم إحالتها للهندسة الطبية</div>
            </div>
          </div>

          {/* Detailed 9 Steps of FOCUS-PDCA */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 pb-1 border-b border-slate-800">
              <Compass className="w-4 h-4 text-teal-400" />
              <h3 className="font-bold text-sm text-slate-200">
                مصفوفة مراحل التحسين التسع (FOCUS - PDCA Methodology):
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {/* Step 1: Find */}
              <div className="bg-slate-950/60 border border-slate-800/80 p-3.5 rounded-2xl">
                <div className="flex items-center gap-2 font-bold text-teal-400 mb-1.5">
                  <span className="w-5 h-5 rounded-full bg-teal-950 text-teal-300 border border-teal-800 flex items-center justify-center text-[10px] font-mono">F</span>
                  <span>1. تحديد العملية المراد تحسينها (Find the Process):</span>
                </div>
                <p className="text-slate-300 leading-relaxed text-[11px]">
                  تحسين إدارة المخاطر الميدانية، رفع جاهزية أسطوانات الغازات الطبية، احتواء انسكابات المواد الكيميائية والبيولوجية (Code Orange)، وتقليص زمن الاستجابة للحوادث إلى أقل من 3 دقائق.
                </p>
              </div>

              {/* Step 2: Organize */}
              <div className="bg-slate-950/60 border border-slate-800/80 p-3.5 rounded-2xl">
                <div className="flex items-center gap-2 font-bold text-teal-400 mb-1.5">
                  <span className="w-5 h-5 rounded-full bg-teal-950 text-teal-300 border border-teal-800 flex items-center justify-center text-[10px] font-mono">O</span>
                  <span>2. تنظيم وتشكيل فريق العمل (Organize the Team):</span>
                </div>
                <p className="text-slate-300 leading-relaxed text-[11px]">
                  تشكيل فريق عمل رباعي متكامل: (مدير الأمن والسلامة، منسق الجودة CBAHI، مسؤول الهندسة الطبية الحيوية، ورئيسة هيئة التمريض) لضمان التنسيق العابر للأقسام.
                </p>
              </div>

              {/* Step 3: Clarify */}
              <div className="bg-slate-950/60 border border-slate-800/80 p-3.5 rounded-2xl">
                <div className="flex items-center gap-2 font-bold text-teal-400 mb-1.5">
                  <span className="w-5 h-5 rounded-full bg-teal-950 text-teal-300 border border-teal-800 flex items-center justify-center text-[10px] font-mono">C</span>
                  <span>3. توضيح الوضع الراهن (Clarify Current Knowledge):</span>
                </div>
                <p className="text-slate-300 leading-relaxed text-[11px]">
                  مراجعة تدفق بلاغات الـ OVR، نتائج جولات التفتيش، رصد مخالفات التدخين، وفحص المولدات ولوحة إنذار الحريق FACP ومستوى توافر عدة الانسكاب (Spill Kits) بالأقسام الحرجة.
                </p>
              </div>

              {/* Step 4: Understand */}
              <div className="bg-slate-950/60 border border-slate-800/80 p-3.5 rounded-2xl">
                <div className="flex items-center gap-2 font-bold text-teal-400 mb-1.5">
                  <span className="w-5 h-5 rounded-full bg-teal-950 text-teal-300 border border-teal-800 flex items-center justify-center text-[10px] font-mono">U</span>
                  <span>4. فهم أسباب التباين والجذور (Understand Variations):</span>
                </div>
                <p className="text-slate-300 leading-relaxed text-[11px]">
                  أظهر تحليل الأسباب الجذرية (Root Cause Analysis) أن أبرز الفجوات تعود لضعف تدريب العمالة الجديدة على استخدام طفايات الحريق وعدة الانسكاب، وعدم تثبيت بعض الأسطوانات بسلاسل مزدوجة.
                </p>
              </div>

              {/* Step 5: Select */}
              <div className="bg-slate-950/60 border border-slate-800/80 p-3.5 rounded-2xl">
                <div className="flex items-center gap-2 font-bold text-teal-400 mb-1.5">
                  <span className="w-5 h-5 rounded-full bg-teal-950 text-teal-300 border border-teal-800 flex items-center justify-center text-[10px] font-mono">S</span>
                  <span>5. اختيار استراتيجية التحسين (Select Improvement):</span>
                </div>
                <p className="text-slate-300 leading-relaxed text-[11px]">
                  أتمتة الفحص الميداني عبر باركود QR، تفعيل لوحة تحكم فورية لمتابعة إشعارات المخالفات عبر الواتساب، وتثبيت نقاط تفتيش رقمية إلزامية للمناطق الحساسة الأربع.
                </p>
              </div>

              {/* Step 6: Plan */}
              <div className="bg-slate-950/60 border border-slate-800/80 p-3.5 rounded-2xl">
                <div className="flex items-center gap-2 font-bold text-teal-400 mb-1.5">
                  <span className="w-5 h-5 rounded-full bg-teal-950 text-teal-300 border border-teal-800 flex items-center justify-center text-[10px] font-mono">P</span>
                  <span>6. خطة العمل التنفيذية (Plan):</span>
                </div>
                <p className="text-slate-300 leading-relaxed text-[11px]">
                  وضع مستهدفات كمية: الوصول بنسبة جاهزية طفايات الحريق والمولدات إلى 100%، إغلاق 95% من مخالفات السلامة خلال 48 ساعة، وإجراء تجربة إخلاء حريق ربع سنوية.
                </p>
              </div>

              {/* Step 7: Do */}
              <div className="bg-slate-950/60 border border-slate-800/80 p-3.5 rounded-2xl">
                <div className="flex items-center gap-2 font-bold text-teal-400 mb-1.5">
                  <span className="w-5 h-5 rounded-full bg-teal-950 text-teal-300 border border-teal-800 flex items-center justify-center text-[10px] font-mono">D</span>
                  <span>7. التنفيذ والتطبيق الميداني (Do):</span>
                </div>
                <p className="text-slate-300 leading-relaxed text-[11px]">
                  تنفيذ الفحص التشغيلي الأسبوعي للمولدات (10m بدون حمل) والشهري (30m بحمل كامل)، ومتابعة قفل خزائن الأدوية والسجلات وتفعيل سجل خروج ممتلكات المستشفى.
                </p>
              </div>

              {/* Step 8: Check */}
              <div className="bg-slate-950/60 border border-slate-800/80 p-3.5 rounded-2xl">
                <div className="flex items-center gap-2 font-bold text-teal-400 mb-1.5">
                  <span className="w-5 h-5 rounded-full bg-teal-950 text-teal-300 border border-teal-800 flex items-center justify-center text-[10px] font-mono">C</span>
                  <span>8. قياس النتائج والمطابقة (Check):</span>
                </div>
                <p className="text-slate-300 leading-relaxed text-[11px]">
                  ارتفاع معدل التزام الأقسام إلى {violationResolutionRate}%، استقرار منظومة إنذار الحريق FACP بدون أي إشارة عطل، وتحقيق امتثال بنسبة 100% في محطة الغازات الطبية.
                </p>
              </div>

              {/* Step 9: Act */}
              <div className="bg-slate-950/60 border border-slate-800/80 p-3.5 rounded-2xl md:col-span-2">
                <div className="flex items-center gap-2 font-bold text-teal-400 mb-1.5">
                  <span className="w-5 h-5 rounded-full bg-teal-950 text-teal-300 border border-teal-800 flex items-center justify-center text-[10px] font-mono">A</span>
                  <span>9. مأسسة التحسين والاعتماد الدائم (Act / Standardize):</span>
                </div>
                <p className="text-slate-300 leading-relaxed text-[11px]">
                  اعتماد الدليل الإجرائي المحدث في سياسات المستشفى المعتمدة لسباهي (CBAHI FMS Policies)، وتعميمه عبر البوابة الرقمية وإدراجه ضمن برنامج التوجيه التعريفي للموظفين الجدد.
                </p>
              </div>
            </div>
          </div>

          {/* Signatures & Accreditation Footer */}
          <div className="border-t border-slate-800 pt-4 grid grid-cols-2 sm:grid-cols-4 gap-3 text-center text-[11px]">
            <div>
              <div className="text-slate-400">منسق الجودة والاعتماد:</div>
              <div className="font-bold text-slate-200 mt-1">د/ علي الظبيبي</div>
              <div className="text-[10px] text-teal-400">معتمد رسمياً للجودة والاعتماد</div>
            </div>
            <div>
              <div className="text-slate-400">المدير الطبي:</div>
              <div className="font-bold text-slate-200 mt-1">د/ أحمد الأهدل</div>
              <div className="text-[10px] text-teal-400">معتمد رسمياً للإدارة الطبية</div>
            </div>
            <div>
              <div className="text-slate-400">رئيس لجنة السلامة (FMS):</div>
              <div className="font-bold text-slate-200 mt-1">م/ نجيب غازي</div>
              <div className="text-[10px] text-teal-400">معتمد رسمياً لإدارة المرافق والسلامة</div>
            </div>
            <div>
              <div className="text-slate-400">مدير عام المستشفى:</div>
              <div className="font-bold text-slate-200 mt-1">د/ محمد السراجي</div>
              <div className="text-[10px] text-teal-400">معتمد ومصادق من الإدارة العامة</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
