import React, { useState, useEffect } from 'react';
import {
  Flame,
  ShieldCheck,
  Clock,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Printer,
  Calendar,
  Users,
  Building2,
  ChevronDown,
  ArrowRight,
  Sparkles,
  Plus,
  Search,
  Filter,
  Eye,
  CheckSquare,
  Square,
  Award,
  Activity,
  Layers,
  Zap,
  TrendingUp,
  X,
  Share2,
  Download,
  FileSpreadsheet,
  HelpCircle,
  Tag
} from 'lucide-react';
import { FireDrillRecord, AnnualCbahieExecutiveSummary } from '../types';
import { INITIAL_FIRE_DRILL_RECORDS, generateAnnualCbahieSummary } from '../data/azalFireDrillData';
import { AZAL_DEPARTMENTS } from '../data/azalSafetyUpgradeData';
import { AzalLogo }from './AzalLogo';
import { VoiceDictationButton } from './VoiceDictationButton';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';

interface FireDrillEvaluationViewProps {
  isStandalonePublicRoute?: boolean;
  onClose?: () => void;
}

const STORAGE_KEY = 'azal_fire_drill_records_v1';

export const FireDrillEvaluationView: React.FC<FireDrillEvaluationViewProps> = ({
  isStandalonePublicRoute = false,
  onClose
}) => {
  // Drills state with local storage persistence
  const [drills, setDrills] = useState<FireDrillRecord[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem(STORAGE_KEY);
        if (saved) return JSON.parse(saved);
      } catch (e) {
        console.error('Error loading saved drills:', e);
      }
    }
    return INITIAL_FIRE_DRILL_RECORDS;
  });

  const [selectedDrill, setSelectedDrill] = useState<FireDrillRecord | null>(drills[0] || null);
  const [activeTab, setActiveTab] = useState<'list' | 'new' | 'annual-report'>('list');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'horizontal' | 'vertical'>('all');
  const [filterShift, setFilterShift] = useState<string>('all');
  const [showPrintModal, setShowPrintModal] = useState(false);
  const [showAnnualReportModal, setShowAnnualReportModal] = useState(false);

  // Form State for new drill
  const [newDrill, setNewDrill] = useState<Partial<FireDrillRecord>>({
    drillCode: `FD-2026-0${drills.length + 1}`,
    policyCodes: ['FMS-PLAN-008EA', 'FMS-PLAN-0011EA'],
    title: 'فرضية حريق وإخلاء وهمية - قسم الطوارئ والرقود',
    scenario: 'اشتعال لهب محاكى في غرفة التمريض بسبب ماس كهربائي مع تصاعد دخان وهمي كثيف.',
    date: new Date().toISOString().split('T')[0],
    shift: 'morning',
    department: 'قسم الطوارئ والإسعاف',
    floor: 'الدور الأرضي',
    evacuationType: 'horizontal',
    assemblyPointLocation: 'الممر الرئيسي خلف الأبواب المقاومة للحريق (المنطقة الآمنة)',
    codeRedAnnouncedAt: '10:00:00',
    fireTeamArrivedAt: '10:02:15',
    evacuationCompletedAt: '10:05:40',
    drillEndedAt: '10:15:00',
    calculatedEvacuationMinutes: 5.66,
    calculatedResponseMinutes: 2.25,
    totalParticipantsCount: 22,
    simulatedPatientsCount: 3,
    emptyRoomTagsVerified: true,
    emptyRoomTagsNotes: 'تم تعليق بطاقات "خالية / Empty" على كافة أبواب الغرف بعد التأكد من تفريغها.',
    raceAudit: {
      rescue: { status: 'compliant', score: 25, notes: 'إنقاذ سريع للحالات الوهمية ونقلهم عبر النقالات بأمان.' },
      alarm: { status: 'compliant', score: 25, notes: 'تفعيل كاسر الإنذار وإطلاق نداء Code Red خلال 15 ثانية.' },
      confine: { status: 'compliant', score: 25, notes: 'إغلاق الأبواب والنوافذ وعزل منطقة الحريق بالكامل.' },
      evacuate: { status: 'compliant', score: 23, notes: 'إخلاء منظم خلال زمن قياسي مطابق لسياسة المستشفى.' }
    },
    passAudit: {
      pull: true,
      aim: true,
      squeeze: true,
      sweep: true,
      usedExtinguisherType: 'بودرة كيميائية جافة ABC (6 كجم)',
      techniqueCompliant: true,
      notes: 'تم التدريب على الإمساك بالخرطوم وتوجيهه لقاعدة اللهب من مسافة آمنة.'
    },
    focusPdca: {
      find: 'رصد حاجة لزيادة وضوح مسار الإخلاء الإضافي وتثبيت لوحة إرشادية جديدة.',
      organize: 'فريق السلامة والصحة المهنية + رئيس قسم الطوارئ.',
      clarify: 'مراجعة خريطة الإخلاء المعلقة عند مدخل القسم.',
      understand: 'تعديل مكان مكتب الفرز أثر جزئياً على زاوية رؤية اللوحة السابقة.',
      select: 'نقل اللوحة الإرشادية إلى زاوية أعلى بإنارة فسفورية ذاتية.',
      plan: 'تثبيت اللوحة خلال 24 ساعة بالتنسيق مع قسم الصيانة.',
      do: 'تم تركيب اللوحة وتوجيه التمريض على الممر المحدث.',
      check: 'فحص سرعة الاستجابة في الفرضية القادمة.',
      act: 'اعتماد المخطط المحدث وتوزيعه على ملفات السلامة بالقسم.'
    },
    totalScore: 98,
    rating: 'ممتاز (Excellent)',
    safetyOfficerName: 'م/ نجيب غازي',
    safetyOfficerRole: 'رئيس قسم السلامة والصحة المهنية',
    safetyOfficerSigned: true,
    safetyOfficerSignedAt: `${new Date().toISOString().split('T')[0]} 11:30`,
    medicalDirectorName: 'د/ محمد السراجي',
    medicalDirectorRole: 'مدير عام المستشفى ورئيس لجنة السلامة العليا',
    medicalDirectorSigned: true,
    medicalDirectorSignedAt: `${new Date().toISOString().split('T')[0]} 12:45`,
    status: 'approved'
  });

  // Calculate live times whenever time fields change
  useEffect(() => {
    if (newDrill.codeRedAnnouncedAt && newDrill.evacuationCompletedAt) {
      try {
        const [h1, m1, s1 = 0] = newDrill.codeRedAnnouncedAt.split(':').map(Number);
        const [h2, m2, s2 = 0] = newDrill.evacuationCompletedAt.split(':').map(Number);
        const sec1 = h1 * 3600 + m1 * 60 + s1;
        const sec2 = h2 * 3600 + m2 * 60 + s2;
        if (sec2 >= sec1) {
          const diffMins = Number(((sec2 - sec1) / 60).toFixed(2));
          setNewDrill(prev => ({ ...prev, calculatedEvacuationMinutes: diffMins }));
        }
      } catch (e) {
        // ignore
      }
    }

    if (newDrill.codeRedAnnouncedAt && newDrill.fireTeamArrivedAt) {
      try {
        const [h1, m1, s1 = 0] = newDrill.codeRedAnnouncedAt.split(':').map(Number);
        const [h2, m2, s2 = 0] = newDrill.fireTeamArrivedAt.split(':').map(Number);
        const sec1 = h1 * 3600 + m1 * 60 + s1;
        const sec2 = h2 * 3600 + m2 * 60 + s2;
        if (sec2 >= sec1) {
          const diffMins = Number(((sec2 - sec1) / 60).toFixed(2));
          setNewDrill(prev => ({ ...prev, calculatedResponseMinutes: diffMins }));
        }
      } catch (e) {
        // ignore
      }
    }
  }, [newDrill.codeRedAnnouncedAt, newDrill.evacuationCompletedAt, newDrill.fireTeamArrivedAt]);

  // Recalculate Total Score
  useEffect(() => {
    if (!newDrill.raceAudit) return;
    const rScore = newDrill.raceAudit.rescue.score || 0;
    const aScore = newDrill.raceAudit.alarm.score || 0;
    const cScore = newDrill.raceAudit.confine.score || 0;
    const eScore = newDrill.raceAudit.evacuate.score || 0;
    let base = rScore + aScore + cScore + eScore; // max 100
    
    // Check PASS
    const pass = newDrill.passAudit;
    const passCompliant = pass?.pull && pass?.aim && pass?.squeeze && pass?.sweep;
    if (!passCompliant) {
      base = Math.max(0, base - 5);
    }
    // Check Empty Room Tags
    if (!newDrill.emptyRoomTagsVerified) {
      base = Math.max(0, base - 5);
    }

    let rating: FireDrillRecord['rating'] = 'ممتاز (Excellent)';
    if (base >= 90) rating = 'ممتاز (Excellent)';
    else if (base >= 80) rating = 'جيد جداً (Very Good)';
    else if (base >= 70) rating = 'مقبول (Acceptable)';
    else rating = 'يحتاج تحسين فوري (Needs Improvement)';

    setNewDrill(prev => ({
      ...prev,
      totalScore: base,
      rating
    }));
  }, [
    newDrill.raceAudit?.rescue.score,
    newDrill.raceAudit?.alarm.score,
    newDrill.raceAudit?.confine.score,
    newDrill.raceAudit?.evacuate.score,
    newDrill.passAudit?.pull,
    newDrill.passAudit?.aim,
    newDrill.passAudit?.squeeze,
    newDrill.passAudit?.sweep,
    newDrill.emptyRoomTagsVerified
  ]);

  // Save New Drill
  const handleSaveNewDrill = () => {
    const record: FireDrillRecord = {
      ...newDrill as FireDrillRecord,
      id: `DRILL-${Date.now()}`,
      drillCode: newDrill.drillCode || `FD-2026-0${drills.length + 1}`,
      policyCodes: ['FMS-PLAN-008EA', 'FMS-PLAN-0011EA'],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const updated = [record, ...drills];
    setDrills(updated);
    setSelectedDrill(record);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    } catch (e) {
      console.error('Save failed:', e);
    }
    triggerSuccessFeedback();
    setActiveTab('list');
  };

  // Filtered drills
  const filteredDrills = drills.filter(drill => {
    const matchQuery =
      drill.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      drill.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
      drill.drillCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
      drill.scenario.toLowerCase().includes(searchQuery.toLowerCase());

    const matchType = filterType === 'all' || drill.evacuationType === filterType;
    const matchShift = filterShift === 'all' || drill.shift === filterShift;

    return matchQuery && matchType && matchShift;
  });

  const annualSummary: AnnualCbahieExecutiveSummary = generateAnnualCbahieSummary(drills);

  // Print Handler
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="w-full space-y-4 pb-12 font-sans" dir="rtl">
      {/* Top Header Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="p-3 rounded-2xl bg-gradient-to-br from-rose-600 to-amber-600 text-white shadow-lg shadow-rose-900/30">
              <Flame className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-xl sm:text-2xl font-black text-white">
                  منظومة تقييم وتوثيق تجارب الحريق والإخلاء الفرضية
                </h1>
                <span className="bg-rose-950 text-rose-300 border border-rose-800 text-[11px] font-bold px-2.5 py-0.5 rounded-full">
                  FMS-PLAN-008EA & FMS-PLAN-0011EA
                </span>
                <span className="bg-amber-950 text-amber-300 border border-amber-800 text-[11px] font-bold px-2.5 py-0.5 rounded-full">
                  معايير سباهي (CBAHI FMS)
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-400 mt-1">
                توثيق زمني دقيق لنداء النداء الصوتي (Code Red)، استجابة فريق الطوارئ، تطبيق معايير RACE و PASS، ونموذج التحسين FOCUS-PDCA بمستشفى أزال النموذجي
              </p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-2 flex-wrap w-full md:w-auto justify-end">
            <button
              type="button"
              onClick={() => setActiveTab('new')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition shadow cursor-pointer active:scale-95 ${
                activeTab === 'new'
                  ? 'bg-rose-600 text-white shadow-rose-950'
                  : 'bg-slate-800 text-rose-300 hover:bg-slate-700 border border-rose-900/40'
              }`}
            >
              <Plus className="w-4 h-4" />
              <span>تسجيل فرضية جديدة</span>
            </button>

            <button
              type="button"
              onClick={() => setShowAnnualReportModal(true)}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white text-xs font-bold flex items-center gap-1.5 transition shadow-lg shadow-amber-950 cursor-pointer active:scale-95"
              title="توليد التقرير السنوي التجميعي المعتمد لسباهي"
            >
              <Award className="w-4 h-4" />
              <span>التقرير الإحصائي السنوي (CBAHI)</span>
            </button>

            {onClose && (
              <button
                type="button"
                onClick={onClose}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700"
                title="إغلاق"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Quick KPI Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-5 pt-4 border-t border-slate-800/80">
          <div className="bg-slate-950/60 rounded-xl p-2.5 border border-slate-800">
            <div className="text-[11px] text-slate-400">إجمالي الفرضيات المنفذة</div>
            <div className="text-xl font-black text-white mt-0.5">{drills.length} فرضيات</div>
            <div className="text-[10px] text-emerald-400 mt-0.5">✓ تغطية النوبات والمباني</div>
          </div>
          <div className="bg-slate-950/60 rounded-xl p-2.5 border border-slate-800">
            <div className="text-[11px] text-slate-400">متوسط زمن الإخلاء التام</div>
            <div className="text-xl font-black text-rose-400 mt-0.5">
              {annualSummary.fireDrillsSummary.averageEvacuationTimeMinutes} دقيقة
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">المعيار المستهدف: &lt; 6 دقائق</div>
          </div>
          <div className="bg-slate-950/60 rounded-xl p-2.5 border border-slate-800">
            <div className="text-[11px] text-slate-400">متوسط درجات المطابقة</div>
            <div className="text-xl font-black text-amber-400 mt-0.5">{annualSummary.fireDrillsSummary.averageScore}%</div>
            <div className="text-[10px] text-emerald-400 mt-0.5">تصنيف ممتاز ومطابق 🟢</div>
          </div>
          <div className="bg-slate-950/60 rounded-xl p-2.5 border border-slate-800">
            <div className="text-[11px] text-slate-400">بطاقات تفريغ الغرف (خالية)</div>
            <div className="text-xl font-black text-teal-400 mt-0.5">100% موثقة</div>
            <div className="text-[10px] text-teal-300 mt-0.5">معاينة كل باب غرفة معلقة</div>
          </div>
        </div>
      </div>

      {/* Main Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          type="button"
          onClick={() => setActiveTab('list')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition cursor-pointer ${
            activeTab === 'list'
              ? 'bg-slate-800 text-white border border-slate-700 shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <FileText className="w-4 h-4 text-rose-400" />
          <span>سجل الفرضيات المنفذة ({drills.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('new')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition cursor-pointer ${
            activeTab === 'new'
              ? 'bg-slate-800 text-white border border-slate-700 shadow-sm'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Plus className="w-4 h-4 text-amber-400" />
          <span>نموذج التقييم الفوري الجديد</span>
        </button>
      </div>

      {/* TAB 1: LIST & DETAIL VIEW */}
      {activeTab === 'list' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Left Column: List & Filters */}
          <div className="lg:col-span-5 space-y-3">
            {/* Search & Filters */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 space-y-2.5">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="بحث برمز الفرضية، القسم، السيناريو..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-9 pl-3 py-1.5 text-xs text-white placeholder-slate-500 focus:border-rose-500 focus:outline-none"
                />
              </div>

              <div className="flex items-center gap-2">
                <select
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value as any)}
                  className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-[11px] text-slate-300"
                >
                  <option value="all">كل أنواع الإخلاء</option>
                  <option value="horizontal">إخلاء أفقي (للطابق)</option>
                  <option value="vertical">إخلاء رأسي (للساحة)</option>
                </select>

                <select
                  value={filterShift}
                  onChange={(e) => setFilterShift(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1 text-[11px] text-slate-300"
                >
                  <option value="all">كل النوبات</option>
                  <option value="morning">نوبة صباحية</option>
                  <option value="evening">نوبة مسائية</option>
                  <option value="night">نوبة ليلية</option>
                </select>
              </div>
            </div>

            {/* Drills List */}
            <div className="space-y-2 max-h-[620px] overflow-y-auto pr-1 scrollbar-thin">
              {filteredDrills.length === 0 ? (
                <div className="p-8 text-center bg-slate-900/50 border border-slate-800 rounded-2xl text-slate-400 text-xs">
                  لا توجد نتائج تطابق خيارات البحث الحالية
                </div>
              ) : (
                filteredDrills.map((drill) => {
                  const isSelected = selectedDrill?.id === drill.id;
                  return (
                    <div
                      key={drill.id}
                      onClick={() => setSelectedDrill(drill)}
                      className={`p-3.5 rounded-2xl border transition-all cursor-pointer text-right relative overflow-hidden ${
                        isSelected
                          ? 'bg-slate-800/90 border-rose-500 shadow-md shadow-rose-950/20'
                          : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-black text-rose-400 bg-rose-950/80 px-2 py-0.5 rounded border border-rose-800">
                            {drill.drillCode}
                          </span>
                          <span className="text-[11px] text-slate-400">{drill.date}</span>
                        </div>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                            drill.totalScore >= 90
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                              : 'bg-amber-950 text-amber-300 border border-amber-800'
                          }`}
                        >
                          {drill.totalScore}% • {drill.rating.split(' ')[0]}
                        </span>
                      </div>

                      <h3 className="font-bold text-slate-100 text-xs mt-2 line-clamp-1">
                        {drill.title}
                      </h3>

                      <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2.5 pt-2 border-t border-slate-800/60">
                        <div>
                          <span>القسم: </span>
                          <span className="text-slate-200 font-semibold">{drill.department}</span>
                        </div>
                        <div className="flex items-center gap-1 text-rose-400 font-mono font-bold">
                          <Clock className="w-3 h-3" />
                          <span>{drill.calculatedEvacuationMinutes} دقيقة</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 mt-1.5 text-[10.5px]">
                        <span className="bg-slate-950 text-slate-300 px-2 py-0.5 rounded border border-slate-800">
                          {drill.evacuationType === 'horizontal' ? 'إخلاء أفقي للطابق' : 'إخلاء رأسي لنقطة التجمع'}
                        </span>
                        {drill.emptyRoomTagsVerified && (
                          <span className="text-teal-400 font-bold flex items-center gap-1">
                            ✓ بطاقات خالية
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Right Column: Selected Drill Comprehensive Dossier */}
          <div className="lg:col-span-7">
            {selectedDrill ? (
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xl space-y-4">
                {/* Dossier Header */}
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono text-sm font-black text-rose-400 bg-rose-950 px-2.5 py-0.5 rounded border border-rose-800">
                        {selectedDrill.drillCode}
                      </span>
                      <span className="text-xs text-slate-400">بتاريخ: {selectedDrill.date}</span>
                      <span className="bg-slate-800 text-slate-300 text-xs px-2 py-0.5 rounded font-semibold">
                        نوبة: {selectedDrill.shift === 'morning' ? 'صباحية' : selectedDrill.shift === 'evening' ? 'مسائية' : 'ليلية'}
                      </span>
                    </div>
                    <h2 className="text-base sm:text-lg font-black text-white mt-1.5">
                      {selectedDrill.title}
                    </h2>
                    <p className="text-xs text-slate-400">
                      الموقع: {selectedDrill.department} ({selectedDrill.floor})
                    </p>
                  </div>

                  {/* Print A4 Sheet Button */}
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setShowPrintModal(true)}
                      className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 text-xs font-bold flex items-center gap-1.5 transition shadow-sm cursor-pointer"
                    >
                      <Printer className="w-4 h-4 text-rose-400" />
                      <span>معاينة وطباعة A4</span>
                    </button>
                  </div>
                </div>

                {/* Scenario */}
                <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs space-y-1">
                  <div className="font-bold text-rose-300 flex items-center gap-1.5">
                    <Flame className="w-3.5 h-3.5 text-rose-400" />
                    <span>سيناريو الفرضية المعتمد:</span>
                  </div>
                  <p className="text-slate-300 leading-relaxed">{selectedDrill.scenario}</p>
                </div>

                {/* Response Timings Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
                  <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                    <div className="text-[10px] text-slate-400">إطلاق النداء Code Red</div>
                    <div className="font-mono text-xs font-bold text-amber-300 mt-1">
                      {selectedDrill.codeRedAnnouncedAt}
                    </div>
                  </div>
                  <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                    <div className="text-[10px] text-slate-400">وصول فريق الطوارئ</div>
                    <div className="font-mono text-xs font-bold text-rose-300 mt-1">
                      {selectedDrill.fireTeamArrivedAt}
                    </div>
                    <div className="text-[9px] text-slate-500">استجابة: {selectedDrill.calculatedResponseMinutes} د</div>
                  </div>
                  <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                    <div className="text-[10px] text-slate-400">اكتمال الإخلاء التام</div>
                    <div className="font-mono text-xs font-bold text-emerald-300 mt-1">
                      {selectedDrill.evacuationCompletedAt}
                    </div>
                  </div>
                  <div className="bg-slate-950 p-2.5 rounded-xl border border-rose-900/60 bg-rose-950/20">
                    <div className="text-[10px] text-rose-300 font-bold">زمن الإخلاء الإجمالي</div>
                    <div className="font-mono text-sm font-black text-rose-400 mt-0.5">
                      {selectedDrill.calculatedEvacuationMinutes} دقيقة
                    </div>
                  </div>
                </div>

                {/* Evacuation & Room Clearance Tags */}
                <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs space-y-2">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                    <div>
                      <strong className="text-slate-300">نوع ومسار الإخلاء: </strong>
                      <span className="text-white font-semibold">
                        {selectedDrill.evacuationType === 'horizontal' ? 'إخلاء أفقي للطابق خلف أبواب الحريق' : 'إخلاء رأسي إلى نقطة التجمع الخارجية'}
                      </span>
                    </div>
                    <div className="text-slate-400 text-[11px]">
                      المشاركون: <strong className="text-white">{selectedDrill.totalParticipantsCount}</strong> • حالات وهمية: <strong className="text-white">{selectedDrill.simulatedPatientsCount}</strong>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 pt-1 border-t border-slate-800 text-[11px]">
                    <div className="p-1 rounded bg-teal-950 text-teal-400 border border-teal-800">
                      <Tag className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <strong className="text-teal-300">بطاقات (خالية / Empty): </strong>
                      <span className="text-slate-300">{selectedDrill.emptyRoomTagsNotes}</span>
                    </div>
                  </div>
                </div>

                {/* RACE Criteria Audit */}
                <div className="space-y-2">
                  <div className="text-xs font-bold text-white flex items-center justify-between">
                    <span className="flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-rose-400" />
                      <span>تدقيق معايير خطة الاستجابة (RACE Standards):</span>
                    </span>
                    <span className="text-rose-400 font-mono">100 / {selectedDrill.totalScore} نقطة</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 space-y-1">
                      <div className="flex items-center justify-between">
                        <strong className="text-rose-400">R - Rescue (الإنقاذ الفوري):</strong>
                        <span className="text-emerald-400 font-bold font-mono">
                          {selectedDrill.raceAudit.rescue.score}/25
                        </span>
                      </div>
                      <p className="text-slate-300 text-[11px] leading-relaxed">
                        {selectedDrill.raceAudit.rescue.notes}
                      </p>
                    </div>

                    <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 space-y-1">
                      <div className="flex items-center justify-between">
                        <strong className="text-amber-400">A - Alarm (الإنذار والنداء):</strong>
                        <span className="text-emerald-400 font-bold font-mono">
                          {selectedDrill.raceAudit.alarm.score}/25
                        </span>
                      </div>
                      <p className="text-slate-300 text-[11px] leading-relaxed">
                        {selectedDrill.raceAudit.alarm.notes}
                      </p>
                    </div>

                    <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 space-y-1">
                      <div className="flex items-center justify-between">
                        <strong className="text-teal-400">C - Confine (الحصر والإغلاق):</strong>
                        <span className="text-emerald-400 font-bold font-mono">
                          {selectedDrill.raceAudit.confine.score}/25
                        </span>
                      </div>
                      <p className="text-slate-300 text-[11px] leading-relaxed">
                        {selectedDrill.raceAudit.confine.notes}
                      </p>
                    </div>

                    <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 space-y-1">
                      <div className="flex items-center justify-between">
                        <strong className="text-blue-400">E - Evacuate / Extinguish (الإخلاء والإطفاء):</strong>
                        <span className="text-emerald-400 font-bold font-mono">
                          {selectedDrill.raceAudit.evacuate.score}/25
                        </span>
                      </div>
                      <p className="text-slate-300 text-[11px] leading-relaxed">
                        {selectedDrill.raceAudit.evacuate.notes}
                      </p>
                    </div>
                  </div>
                </div>

                {/* PASS Extinguisher Audit */}
                <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs space-y-2">
                  <div className="font-bold text-amber-300 flex items-center justify-between">
                    <span>🧯 تدقيق استخدام طفايات الحريق (معايير PASS):</span>
                    <span className="text-[11px] text-slate-400 font-normal">
                      النوع: {selectedDrill.passAudit.usedExtinguisherType}
                    </span>
                  </div>

                  <div className="grid grid-cols-4 gap-1.5 text-center text-[11px]">
                    <div className="bg-slate-900 p-1.5 rounded-lg border border-slate-800">
                      <div className="text-slate-400 text-[9.5px]">P - Pull</div>
                      <div className="font-bold text-emerald-400">✓ سحب المسمار</div>
                    </div>
                    <div className="bg-slate-900 p-1.5 rounded-lg border border-slate-800">
                      <div className="text-slate-400 text-[9.5px]">A - Aim</div>
                      <div className="font-bold text-emerald-400">✓ توجيه للقاعدة</div>
                    </div>
                    <div className="bg-slate-900 p-1.5 rounded-lg border border-slate-800">
                      <div className="text-slate-400 text-[9.5px]">S - Squeeze</div>
                      <div className="font-bold text-emerald-400">✓ ضغط المقبض</div>
                    </div>
                    <div className="bg-slate-900 p-1.5 rounded-lg border border-slate-800">
                      <div className="text-slate-400 text-[9.5px]">S - Sweep</div>
                      <div className="font-bold text-emerald-400">✓ التحريك أفقياً</div>
                    </div>
                  </div>
                </div>

                {/* FOCUS-PDCA Cycle */}
                <div className="bg-gradient-to-br from-slate-950 to-slate-900 border border-slate-800 rounded-xl p-3 text-xs space-y-2">
                  <div className="font-bold text-teal-300 flex items-center gap-1.5">
                    <TrendingUp className="w-4 h-4 text-teal-400" />
                    <span>تحليل الفجوات وفرص التحسين بموجب نموذج FOCUS-PDCA:</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                    <div>
                      <strong className="text-amber-400">Find (رصد المشكلة): </strong>
                      <span className="text-slate-300">{selectedDrill.focusPdca.find}</span>
                    </div>
                    <div>
                      <strong className="text-teal-400">Organize (فريق المعالجة): </strong>
                      <span className="text-slate-300">{selectedDrill.focusPdca.organize}</span>
                    </div>
                    <div>
                      <strong className="text-teal-400">Plan (خطة الإجراء): </strong>
                      <span className="text-slate-300">{selectedDrill.focusPdca.plan}</span>
                    </div>
                    <div>
                      <strong className="text-emerald-400">Do & Act (التنفيذ والتوحيد): </strong>
                      <span className="text-slate-300">{selectedDrill.focusPdca.do}</span>
                    </div>
                  </div>
                </div>

                {/* Official Approvals & Endorsements */}
                <div className="bg-slate-950 border border-slate-800 rounded-xl p-3.5 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
                  <div className="text-center sm:text-right">
                    <div className="text-[10px] text-slate-400">إعداد وتدقيق مسؤول السلامة:</div>
                    <div className="font-bold text-white mt-0.5">{selectedDrill.safetyOfficerName}</div>
                    <div className="text-[10.5px] text-emerald-400 flex items-center justify-center sm:justify-start gap-1 mt-0.5">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>معتمد وموقع رقمياً ({selectedDrill.safetyOfficerSignedAt})</span>
                    </div>
                  </div>

                  <div className="text-center sm:text-left">
                    <div className="text-[10px] text-slate-400">مصادقة رئيس لجنة السلامة والمدير الطبي:</div>
                    <div className="font-bold text-white mt-0.5">{selectedDrill.medicalDirectorName}</div>
                    <div className="text-[10.5px] text-emerald-400 flex items-center justify-center sm:justify-end gap-1 mt-0.5">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>مصادق ومعتمد رسمياً ({selectedDrill.medicalDirectorSignedAt})</span>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="h-full flex items-center justify-center p-12 bg-slate-900 border border-slate-800 rounded-2xl text-slate-400 text-xs">
                اختر فرضية من القائمة للاطلاع على تفاصيلها الكاملة
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: NEW DRILL FORM */}
      {activeTab === 'new' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xl space-y-5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                <Plus className="w-5 h-5 text-rose-500" />
                <span>نموذج تسجيل وتقييم تجربة حريق وإخلاء وهمية</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                تعبئة معطيات الفرضية الميدانية وحساب الأزمنة ونسب المطابقة وفق السياسة FMS-PLAN-008EA
              </p>
            </div>

            <button
              type="button"
              onClick={() => setActiveTab('list')}
              className="text-xs text-slate-400 hover:text-white px-3 py-1.5 rounded-lg bg-slate-800"
            >
              العودة للسجل
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs text-slate-300 font-bold mb-1">رمز الفرضية:</label>
              <input
                type="text"
                value={newDrill.drillCode || ''}
                onChange={(e) => setNewDrill({ ...newDrill, drillCode: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-300 font-bold mb-1">تاريخ التنفيذ:</label>
              <input
                type="date"
                value={newDrill.date || ''}
                onChange={(e) => setNewDrill({ ...newDrill, date: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-300 font-bold mb-1">نوبة العمل:</label>
              <select
                value={newDrill.shift}
                onChange={(e) => setNewDrill({ ...newDrill, shift: e.target.value as any })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
              >
                <option value="morning">نوبة صباحية (Morning Shift)</option>
                <option value="evening">نوبة مسائية (Evening Shift)</option>
                <option value="night">نوبة ليلية (Night Shift)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-slate-300 font-bold mb-1">القسم المستهدف:</label>
              <select
                value={newDrill.department}
                onChange={(e) => setNewDrill({ ...newDrill, department: e.target.value })}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
              >
                {AZAL_DEPARTMENTS.map(dep => (
                  <option key={dep} value={dep}>{dep}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-slate-300 font-bold mb-1">الطابق والموقع الدقيق:</label>
              <input
                type="text"
                value={newDrill.floor || ''}
                onChange={(e) => setNewDrill({ ...newDrill, floor: e.target.value })}
                placeholder="مثال: الدور الثاني - الجناح الجراحي"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs text-slate-300 font-bold">سيناريو التجربة الوهمية المفترض:</label>
              <VoiceDictationButton
                onTranscript={(text) => setNewDrill(prev => ({
                  ...prev,
                  scenario: prev.scenario ? `${prev.scenario} ${text}` : text
                }))}
                size="sm"
              />
            </div>
            <textarea
              rows={2}
              value={newDrill.scenario || ''}
              onChange={(e) => setNewDrill({ ...newDrill, scenario: e.target.value })}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200"
            />
          </div>

          {/* Timing Grid */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-3.5 space-y-3">
            <h4 className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-amber-400" />
              <span>تسجيل التوقيتات اللحظية وحساب زمن الإخلاء التلقائي:</span>
            </h4>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">إطلاق نداء Code Red:</label>
                <input
                  type="text"
                  value={newDrill.codeRedAnnouncedAt || ''}
                  onChange={(e) => setNewDrill({ ...newDrill, codeRedAnnouncedAt: e.target.value })}
                  placeholder="10:04:15"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 font-mono text-xs text-white text-center"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">وصول فريق الطوارئ:</label>
                <input
                  type="text"
                  value={newDrill.fireTeamArrivedAt || ''}
                  onChange={(e) => setNewDrill({ ...newDrill, fireTeamArrivedAt: e.target.value })}
                  placeholder="10:06:20"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 font-mono text-xs text-white text-center"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">اكتمال الإخلاء التام:</label>
                <input
                  type="text"
                  value={newDrill.evacuationCompletedAt || ''}
                  onChange={(e) => setNewDrill({ ...newDrill, evacuationCompletedAt: e.target.value })}
                  placeholder="10:09:40"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 font-mono text-xs text-white text-center"
                />
              </div>

              <div className="bg-slate-900/90 rounded-lg p-2 border border-rose-800 text-center flex flex-col justify-center">
                <span className="text-[10px] text-rose-300 font-bold">زمن الإخلاء المحسوب:</span>
                <span className="font-mono text-base font-black text-rose-400 mt-0.5">
                  {newDrill.calculatedEvacuationMinutes || 0} دقيقة
                </span>
              </div>
            </div>
          </div>

          {/* Evacuation Type & Door Empty Tags */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-3">
              <label className="block text-xs text-slate-300 font-bold mb-1.5">نوع الإخلاء المنفذ:</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setNewDrill({ ...newDrill, evacuationType: 'horizontal' })}
                  className={`p-2 rounded-xl border text-xs font-bold transition cursor-pointer ${
                    newDrill.evacuationType === 'horizontal'
                      ? 'bg-rose-950 border-rose-600 text-rose-300'
                      : 'bg-slate-900 border-slate-800 text-slate-400'
                  }`}
                >
                  إخلاء أفقي (للطابق)
                </button>
                <button
                  type="button"
                  onClick={() => setNewDrill({ ...newDrill, evacuationType: 'vertical' })}
                  className={`p-2 rounded-xl border text-xs font-bold transition cursor-pointer ${
                    newDrill.evacuationType === 'vertical'
                      ? 'bg-rose-950 border-rose-600 text-rose-300'
                      : 'bg-slate-900 border-slate-800 text-slate-400'
                  }`}
                >
                  إخلاء رأسي (للساحة)
                </button>
              </div>
            </div>

            {/* Empty Room Tags Confirmation */}
            <div className="bg-slate-950 border border-teal-900/60 rounded-xl p-3 flex flex-col justify-center">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={newDrill.emptyRoomTagsVerified}
                  onChange={(e) => setNewDrill({ ...newDrill, emptyRoomTagsVerified: e.target.checked })}
                  className="w-4 h-4 rounded text-teal-600 bg-slate-900 border-slate-700"
                />
                <span className="text-xs font-bold text-teal-300">
                  تأكيد وضع بطاقات (خالية / Empty) على أبواب كافة الغرف التي تم إخلاؤها
                </span>
              </label>
              <p className="text-[10px] text-slate-400 mt-1 mr-6">
                معيار أساسي لضمان عدم بقاء أي مريض أو مرافق خلف الأبواب المغلقة.
              </p>
            </div>
          </div>

          {/* PASS Criteria Check */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-3.5 space-y-2">
            <h4 className="text-xs font-bold text-amber-300">🧯 تدقيق تقنية استخدام الطفايات (PASS):</h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <label className="flex items-center gap-2 bg-slate-900 p-2 rounded-lg border border-slate-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={newDrill.passAudit?.pull}
                  onChange={(e) => setNewDrill({
                    ...newDrill,
                    passAudit: { ...newDrill.passAudit!, pull: e.target.checked }
                  })}
                />
                <span className="text-xs text-slate-200 font-semibold">سحب المسمار (Pull)</span>
              </label>
              <label className="flex items-center gap-2 bg-slate-900 p-2 rounded-lg border border-slate-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={newDrill.passAudit?.aim}
                  onChange={(e) => setNewDrill({
                    ...newDrill,
                    passAudit: { ...newDrill.passAudit!, aim: e.target.checked }
                  })}
                />
                <span className="text-xs text-slate-200 font-semibold">توجيه للقاعدة (Aim)</span>
              </label>
              <label className="flex items-center gap-2 bg-slate-900 p-2 rounded-lg border border-slate-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={newDrill.passAudit?.squeeze}
                  onChange={(e) => setNewDrill({
                    ...newDrill,
                    passAudit: { ...newDrill.passAudit!, squeeze: e.target.checked }
                  })}
                />
                <span className="text-xs text-slate-200 font-semibold">ضغط المقبض (Squeeze)</span>
              </label>
              <label className="flex items-center gap-2 bg-slate-900 p-2 rounded-lg border border-slate-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={newDrill.passAudit?.sweep}
                  onChange={(e) => setNewDrill({
                    ...newDrill,
                    passAudit: { ...newDrill.passAudit!, sweep: e.target.checked }
                  })}
                />
                <span className="text-xs text-slate-200 font-semibold">التحريك أفقياً (Sweep)</span>
              </label>
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex items-center justify-between pt-3 border-t border-slate-800">
            <div className="text-xs text-slate-400">
              النتيجة التقديرية: <strong className="text-amber-400 font-mono text-sm">{newDrill.totalScore}%</strong> ({newDrill.rating})
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setActiveTab('list')}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={handleSaveNewDrill}
                className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-1.5 transition shadow-lg shadow-rose-950 cursor-pointer active:scale-95"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>اعتماد وحفظ تقرير الفرضية</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ANNUAL CBAHI REPORT MODAL */}
      {showAnnualReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/85 backdrop-blur-md overflow-y-auto animate-fadeIn">
          <div className="bg-slate-900 border border-amber-600/70 rounded-2xl max-w-4xl w-full p-4 sm:p-6 shadow-2xl space-y-4 my-6 max-h-[92vh] flex flex-col">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-amber-950 border border-amber-600 text-amber-300">
                  <Award className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-black text-white">
                    التقرير الإحصائي السنوي الشامل للاعتماد (CBAHI Annual Safety Report)
                  </h3>
                  <p className="text-xs text-amber-400 font-mono">
                    الكود المعتمد: {annualSummary.code} • السنة: {annualSummary.reportYear}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold flex items-center gap-1.5"
                >
                  <Printer className="w-4 h-4" />
                  <span>طباعة رسمية A4</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowAnnualReportModal(false)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Scrollable Report Content */}
            <div className="overflow-y-auto space-y-4 pr-1 text-xs scrollbar-thin">
              {/* Section 1: OVR & Incidents Stats */}
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-3.5 space-y-2">
                <h4 className="font-bold text-amber-300 text-xs flex items-center gap-1.5">
                  <Activity className="w-4 h-4 text-amber-400" />
                  <span>1. إحصائيات البلاغات وحوادث السلامة (OVR) ومعدلات الإغلاق:</span>
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-[11px]">
                  <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                    <div className="text-slate-400 text-[10px]">إجمالي البلاغات المسجلة</div>
                    <div className="text-base font-bold text-white mt-0.5">{annualSummary.incidentsStats.totalReported} بلاغاً</div>
                  </div>
                  <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                    <div className="text-slate-400 text-[10px]">الحوادث المغلقة والمعالجة</div>
                    <div className="text-base font-bold text-emerald-400 mt-0.5">{annualSummary.incidentsStats.resolvedCount} بلاغاً</div>
                  </div>
                  <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                    <div className="text-slate-400 text-[10px]">معدل إغلاق البلاغات</div>
                    <div className="text-base font-bold text-teal-400 mt-0.5">{annualSummary.incidentsStats.resolutionRate}%</div>
                  </div>
                  <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                    <div className="text-slate-400 text-[10px]">متوسط زمن الإغلاق</div>
                    <div className="text-base font-bold text-amber-400 mt-0.5">{annualSummary.incidentsStats.averageClosureTimeHours} ساعة</div>
                  </div>
                </div>
              </div>

              {/* Section 2: Critical Areas Audit */}
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-3.5 space-y-2">
                <h4 className="font-bold text-teal-300 text-xs flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-teal-400" />
                  <span>2. ملخص تدقيق الأماكن الحساسة الأربعة ومحطة الغازات والمحرقة الطبية:</span>
                </h4>
                <div className="space-y-1.5 text-[11px]">
                  <div className="flex items-start justify-between gap-2 p-1.5 rounded bg-slate-900">
                    <strong className="text-teal-400">العناية المركزة (ICU):</strong>
                    <span className="text-slate-200">{annualSummary.criticalAreasAudit.icuStatus}</span>
                  </div>
                  <div className="flex items-start justify-between gap-2 p-1.5 rounded bg-slate-900">
                    <strong className="text-teal-400">قسم التعقيم المركزي (CSSD):</strong>
                    <span className="text-slate-200">{annualSummary.criticalAreasAudit.cssdStatus}</span>
                  </div>
                  <div className="flex items-start justify-between gap-2 p-1.5 rounded bg-slate-900">
                    <strong className="text-teal-400">المختبر المركزي وبنك الدم:</strong>
                    <span className="text-slate-200">{annualSummary.criticalAreasAudit.centralLabStatus}</span>
                  </div>
                  <div className="flex items-start justify-between gap-2 p-1.5 rounded bg-slate-900">
                    <strong className="text-teal-400">محطة الغازات الطبية وتوليد الأكسجين:</strong>
                    <span className="text-slate-200">{annualSummary.criticalAreasAudit.medicalGasPlantStatus}</span>
                  </div>
                  <div className="flex items-start justify-between gap-2 p-1.5 rounded bg-slate-900">
                    <strong className="text-teal-400">المحرقة الطبية وإدارة النفايات:</strong>
                    <span className="text-slate-200">{annualSummary.criticalAreasAudit.incineratorStatus}</span>
                  </div>
                </div>
              </div>

              {/* Section 3: Engineering Life Safety */}
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-3.5 space-y-2">
                <h4 className="font-bold text-amber-300 text-xs flex items-center gap-1.5">
                  <Zap className="w-4 h-4 text-amber-400" />
                  <span>3. سجل المولد الاحتياطي ولوحة إنذار الحريق (FACP) ومطافئ الحريق:</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px]">
                  <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                    <strong className="text-amber-400 block mb-0.5">سجل المولد الاحتياطي:</strong>
                    <span className="text-slate-300">تشغيل أسبوعي بنسبة جاهزية {annualSummary.engineeringLifeSafety.backupGeneratorWeeklyRunRate}% مع اختبار الأحمال الحيوية بنجاح.</span>
                  </div>
                  <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                    <strong className="text-amber-400 block mb-0.5">لوحة إنذار الحريق (FACP):</strong>
                    <span className="text-slate-300">تم تنفيذ {annualSummary.engineeringLifeSafety.facpPanelInspectionsCount} فحصاً دورياً بنسبة تشغيل 100% وخلو تام من الأعطال المزمنة.</span>
                  </div>
                  <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                    <strong className="text-amber-400 block mb-0.5">مطافئ الحريق بالمستشفى:</strong>
                    <span className="text-slate-300">تمت معاينة {annualSummary.engineeringLifeSafety.extinguishersAuditedCount} طفاية بنسبة صلاحية 100% والتزام جدول الصيانة الدورية.</span>
                  </div>
                </div>
              </div>

              {/* Section 4: Fire Drills Annual Overview */}
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-3.5 space-y-2">
                <h4 className="font-bold text-rose-300 text-xs flex items-center gap-1.5">
                  <Flame className="w-4 h-4 text-rose-400" />
                  <span>4. نتائج وتوصيات تجارب الإخلاء الوهمية السنوية:</span>
                </h4>
                <div className="text-[11px] text-slate-300 space-y-1">
                  <p>
                    • نُفذت خلال العام <strong className="text-white font-mono">{annualSummary.fireDrillsSummary.totalDrillsExecuted}</strong> تجارب إخلاء فرضية تغطي نوبات الصباح والمساء، بمتوسط زمن إخلاء <strong className="text-rose-400 font-mono">{annualSummary.fireDrillsSummary.averageEvacuationTimeMinutes}</strong> دقيقة، ونسبة نجاح عامة <strong className="text-emerald-400 font-mono">{annualSummary.fireDrillsSummary.passedRoundsPercentage}%</strong>.
                  </p>
                  <p className="text-slate-400 bg-slate-900 p-2 rounded-lg border border-slate-800">
                    <strong className="text-teal-300">أبرز مجالات التطوير المعتمدة: </strong>
                    <span>{annualSummary.fireDrillsSummary.keyImprovementFocus}</span>
                  </p>
                </div>
              </div>

              {/* Section 5: Official Signatures & Endorsements */}
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-3.5 space-y-2">
                <h4 className="font-bold text-slate-200 text-xs">
                  5. الاعتمادات والمصادقة الرسمية للتقرير السنوي:
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center text-xs pt-1">
                  <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800">
                    <div className="text-[10px] text-slate-400">{annualSummary.signatures.qualityCoordinator.title}</div>
                    <div className="font-bold text-white mt-1">{annualSummary.signatures.qualityCoordinator.name}</div>
                    <div className="text-[10px] text-emerald-400 mt-1">✓ مصادق ومعتمد</div>
                  </div>

                  {annualSummary.signatures.medicalDirector && (
                    <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800">
                      <div className="text-[10px] text-slate-400">{annualSummary.signatures.medicalDirector.title}</div>
                      <div className="font-bold text-white mt-1">{annualSummary.signatures.medicalDirector.name}</div>
                      <div className="text-[10px] text-emerald-400 mt-1">✓ مصادق ومعتمد</div>
                    </div>
                  )}

                  <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800">
                    <div className="text-[10px] text-slate-400">{annualSummary.signatures.safetyOfficer.title}</div>
                    <div className="font-bold text-white mt-1">{annualSummary.signatures.safetyOfficer.name}</div>
                    <div className="text-[10px] text-emerald-400 mt-1">✓ مصادق ومعتمد</div>
                  </div>

                  <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800">
                    <div className="text-[10px] text-slate-400">
                      {annualSummary.signatures.generalDirector ? annualSummary.signatures.generalDirector.title : 'مدير عام المستشفى'}
                    </div>
                    <div className="font-bold text-white mt-1">
                      {annualSummary.signatures.generalDirector ? annualSummary.signatures.generalDirector.name : 'د/ محمد السراجي'}
                    </div>
                    <div className="text-[10px] text-emerald-400 mt-1">✓ مصادق ومعتمد</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* A4 PRINT VIEW MODAL FOR SELECTED DRILL */}
      {showPrintModal && selectedDrill && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/90 backdrop-blur-md overflow-y-auto animate-fadeIn">
          <div className="bg-white text-slate-900 rounded-xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl my-auto space-y-4 print:p-0 print:m-0 print:shadow-none print:border-none print:w-full">
            {/* Header for print preview */}
            <div className="flex items-center justify-between border-b pb-3 print:hidden">
              <span className="text-xs font-bold text-slate-500">معاينة التقرير الرسمي المعتمد للطباعة A4</span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handlePrint}
                  className="px-4 py-1.5 rounded-lg bg-rose-600 text-white font-bold text-xs flex items-center gap-1.5 shadow"
                >
                  <Printer className="w-4 h-4" />
                  <span>طباعة الآن (Ctrl + P)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowPrintModal(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-800"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Printable A4 Content */}
            <div className="border border-slate-300 rounded-lg p-6 space-y-4 text-xs font-sans" dir="rtl">
              {/* Formal Hospital Header */}
              <div className="flex items-center justify-between border-b-2 border-slate-900 pb-3">
                <div className="text-right">
                  <h2 className="text-base font-black text-slate-900">مستشفى أزال النموذجي</h2>
                  <p className="text-[11px] text-slate-600">إدارة الأمن والسلامة والصحة المهنية</p>
                  <p className="text-[10px] text-slate-500 font-mono">Azal Model Hospital - Safety Dept.</p>
                </div>
                <div className="flex flex-col items-center">
                  <AzalLogo variant="horizontal" size="sm" transparent={true} />
                  <span className="text-[9px] font-bold text-slate-700 mt-1">وثيقة رسمية معتمدة • معايير CBAHI</span>
                </div>
                <div className="text-left font-mono text-[10.5px]">
                  <div><strong>Ref:</strong> {selectedDrill.drillCode}</div>
                  <div><strong>Date:</strong> {selectedDrill.date}</div>
                  <div><strong>Policy:</strong> FMS-PLAN-008EA</div>
                </div>
              </div>

              {/* Title */}
              <div className="text-center py-1 bg-slate-100 rounded">
                <h3 className="text-sm font-black text-slate-900">
                  تقرير تقييم تجربة حريق وإخلاء وهمية (Fire Drill Evaluation Sheet)
                </h3>
              </div>

              {/* Basic Details Table */}
              <table className="w-full text-right border-collapse border border-slate-300 text-[11px]">
                <tbody>
                  <tr className="border-b border-slate-300 bg-slate-50">
                    <td className="p-1.5 font-bold border-l border-slate-300 w-1/4">القسم / الطابق:</td>
                    <td className="p-1.5 border-l border-slate-300 w-1/4">{selectedDrill.department} ({selectedDrill.floor})</td>
                    <td className="p-1.5 font-bold border-l border-slate-300 w-1/4">نوبة العمل / التوقيت:</td>
                    <td className="p-1.5 w-1/4">{selectedDrill.shift === 'morning' ? 'صباحية' : selectedDrill.shift === 'evening' ? 'مسائية' : 'ليلية'} ({selectedDrill.codeRedAnnouncedAt})</td>
                  </tr>
                  <tr className="border-b border-slate-300">
                    <td className="p-1.5 font-bold border-l border-slate-300">نوع الإخلاء:</td>
                    <td className="p-1.5 border-l border-slate-300">{selectedDrill.evacuationType === 'horizontal' ? 'إخلاء أفقي للطابق' : 'إخلاء رأسي لنقطة التجمع'}</td>
                    <td className="p-1.5 font-bold border-l border-slate-300">زمن الإخلاء التام:</td>
                    <td className="p-1.5 font-mono font-bold text-rose-700">{selectedDrill.calculatedEvacuationMinutes} دقيقة</td>
                  </tr>
                  <tr className="border-b border-slate-300 bg-slate-50">
                    <td className="p-1.5 font-bold border-l border-slate-300">إجمالي المشاركين:</td>
                    <td className="p-1.5 border-l border-slate-300">{selectedDrill.totalParticipantsCount} فرداً</td>
                    <td className="p-1.5 font-bold border-l border-slate-300">حالات المرضى الوهميين:</td>
                    <td className="p-1.5">{selectedDrill.simulatedPatientsCount} حالات</td>
                  </tr>
                  <tr>
                    <td className="p-1.5 font-bold border-l border-slate-300">بطاقات الغرف خالية:</td>
                    <td colSpan={3} className="p-1.5 text-teal-800 font-semibold">
                      ✓ مؤكدة - {selectedDrill.emptyRoomTagsNotes}
                    </td>
                  </tr>
                </tbody>
              </table>

              {/* Scenario */}
              <div className="border border-slate-300 p-2 rounded text-[10.5px]">
                <strong className="block text-slate-800 mb-0.5">سيناريو التجربة:</strong>
                <p className="text-slate-700 leading-relaxed">{selectedDrill.scenario}</p>
              </div>

              {/* RACE Audit */}
              <div className="space-y-1">
                <strong className="block text-slate-900 text-xs">معايير الاستجابة لإنقاذ الأرواح (RACE):</strong>
                <div className="grid grid-cols-2 gap-2 text-[10px]">
                  <div className="border border-slate-300 p-1.5 rounded">
                    <strong>R - Rescue: </strong> <span>{selectedDrill.raceAudit.rescue.notes}</span>
                  </div>
                  <div className="border border-slate-300 p-1.5 rounded">
                    <strong>A - Alarm: </strong> <span>{selectedDrill.raceAudit.alarm.notes}</span>
                  </div>
                  <div className="border border-slate-300 p-1.5 rounded">
                    <strong>C - Confine: </strong> <span>{selectedDrill.raceAudit.confine.notes}</span>
                  </div>
                  <div className="border border-slate-300 p-1.5 rounded">
                    <strong>E - Evacuate: </strong> <span>{selectedDrill.raceAudit.evacuate.notes}</span>
                  </div>
                </div>
              </div>

              {/* FOCUS-PDCA Improvement */}
              <div className="border border-slate-300 p-2 rounded text-[10px] space-y-1">
                <strong className="block text-slate-900">نموذج فرص التحسين (FOCUS-PDCA):</strong>
                <div className="grid grid-cols-2 gap-2">
                  <div><strong>رصد المشكلة (Find): </strong> {selectedDrill.focusPdca.find}</div>
                  <div><strong>الإجراء التصحيحي (Do & Act): </strong> {selectedDrill.focusPdca.do}</div>
                </div>
              </div>

              {/* Signatures */}
              <div className="pt-4 border-t border-slate-400 grid grid-cols-2 text-center text-xs">
                <div>
                  <div className="font-bold text-slate-800">{selectedDrill.safetyOfficerRole}</div>
                  <div className="mt-1 text-slate-900 font-semibold">{selectedDrill.safetyOfficerName}</div>
                  <div className="text-[9.5px] text-slate-500 mt-1">توقيع معتمد: ✓ {selectedDrill.safetyOfficerSignedAt}</div>
                </div>

                <div>
                  <div className="font-bold text-slate-800">{selectedDrill.medicalDirectorRole}</div>
                  <div className="mt-1 text-slate-900 font-semibold">{selectedDrill.medicalDirectorName}</div>
                  <div className="text-[9.5px] text-slate-500 mt-1">مصادقة رسمية: ✓ {selectedDrill.medicalDirectorSignedAt}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
