import React from 'react';
import { SafetyTourRecord, SafetyViolationNotice, FireExtinguisherItem, StaffUser } from '../types';
import { GeneralManagerReportsView } from './GeneralManagerReportsView';

interface SafetyExecutiveReportsModalProps {
  tours: SafetyTourRecord[];
  violations: SafetyViolationNotice[];
  extinguishers?: FireExtinguisherItem[];
  currentUser: StaffUser;
  onClose: () => void;
}

export const SafetyExecutiveReportsModal: React.FC<SafetyExecutiveReportsModalProps> = ({
  tours,
  violations,
  extinguishers = [],
  currentUser,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto modal-backdrop-blur">
      <div className="w-full max-w-5xl my-auto animate-in fade-in zoom-in-95 duration-200">
        <GeneralManagerReportsView
          tours={tours}
          violations={violations}
          extinguishers={extinguishers}
          currentUser={currentUser}
          onClose={onClose}
          isModal={true}
        />
      </div>
    </div>
  );
};
