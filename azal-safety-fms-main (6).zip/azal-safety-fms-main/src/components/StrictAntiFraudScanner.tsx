import React, { useEffect, useRef, useState } from 'react';
import { Html5Qrcode, Html5QrcodeSupportedFormats } from 'html5-qrcode';
import { 
  Camera, 
  X, 
  ShieldCheck, 
  AlertOctagon, 
  Zap, 
  RefreshCw, 
  CheckCircle2, 
  Lock,
  Sparkles,
  Layers
} from 'lucide-react';
import { PpmAsset } from '../data/azalPpmAssetsData';
import { AntiFraudScanProof, generateLiveScanProof } from '../utils/ppmDueEngine';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';

interface StrictAntiFraudScannerProps {
  assets: PpmAsset[];
  onClose: () => void;
  onScanSuccess: (asset: PpmAsset, proof: AntiFraudScanProof) => void;
}

export const StrictAntiFraudScanner: React.FC<StrictAntiFraudScannerProps> = ({
  assets,
  onClose,
  onScanSuccess
}) => {
  const scannerId = 'strict-live-camera-scanner-view';
  const html5QrcodeRef = useRef<Html5Qrcode | null>(null);
  
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [torchOn, setTorchOn] = useState(false);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [lastScannedCode, setLastScannedCode] = useState<string | null>(null);
  const [matchedAsset, setMatchedAsset] = useState<PpmAsset | null>(null);
  const [unrecognizedCode, setUnrecognizedCode] = useState<string | null>(null);
  const [currentTimeStr, setCurrentTimeStr] = useState<string>('');
  const [isProcessingMatch, setIsProcessingMatch] = useState(false);

  // Live timestamp ticking to ensure visual proof of live camera operation
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTimeStr(now.toLocaleTimeString('ar-YE', { 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit',
        hour12: true 
      }));
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  // Initialize strictly live camera via Html5Qrcode
  useEffect(() => {
    let isMounted = true;

    async function startLiveScanner() {
      try {
        setCameraError(null);
        setCameraActive(false);

        // Verify mediaDevices support
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          throw new Error('متصفحك أو جهازك لا يدعم فتح الكاميرا المباشرة MediaStream');
        }

        const scanner = new Html5Qrcode(scannerId, {
          formatsToSupport: [
            Html5QrcodeSupportedFormats.QR_CODE,
            Html5QrcodeSupportedFormats.CODE_128,
            Html5QrcodeSupportedFormats.CODE_39,
            Html5QrcodeSupportedFormats.EAN_13,
            Html5QrcodeSupportedFormats.UPC_A
          ],
          verbose: false
        });

        html5QrcodeRef.current = scanner;

        const config = {
          fps: 20,
          qrbox: { width: 260, height: 260 },
          aspectRatio: 1.0
        };

        await scanner.start(
          { facingMode },
          config,
          (decodedText) => {
            if (!isMounted) return;
            handleLiveCodeDetected(decodedText);
          },
          () => {
            // Frame scan without barcode, keep scanning smoothly
          }
        );

        if (isMounted) {
          setCameraActive(true);
        }
      } catch (err: any) {
        console.error('Live Camera Error:', err);
        if (isMounted) {
          setCameraError(
            err?.message || 'تعذر الوصول إلى عدسة الكاميرا المباشرة. يرجى منح إذن الكاميرا للتطبيق والتأكد من عدم استخدامها من تطبيق آخر.'
          );
        }
      }
    }

    startLiveScanner();

    return () => {
      isMounted = false;
      if (html5QrcodeRef.current) {
        html5QrcodeRef.current.stop().catch(() => {}).finally(() => {
          try {
            html5QrcodeRef.current?.clear();
          } catch {}
          html5QrcodeRef.current = null;
        });
      }
    };
  }, [facingMode]);

  // Handle scanned code from live camera
  const handleLiveCodeDetected = (rawCode: string) => {
    const cleanCode = rawCode.trim().toUpperCase();
    if (isProcessingMatch || cleanCode === lastScannedCode) return;

    setIsProcessingMatch(true);
    setLastScannedCode(cleanCode);

    // Audio beep feedback + vibration
    triggerSuccessFeedback();

    // Match code against asset inventory
    // Match either by asset_tag (e.g. AZ-GEN-01) or part of URL containing the tag
    const found = assets.find((a) => {
      const tag = a.asset_tag.toUpperCase();
      return cleanCode === tag || cleanCode.includes(tag) || cleanCode.endsWith(tag);
    });

    if (found) {
      setMatchedAsset(found);
      setUnrecognizedCode(null);

      // Generate verifiable proof
      const proof = generateLiveScanProof(found.asset_tag);

      // Stop camera cleanly before passing to form
      if (html5QrcodeRef.current) {
        html5QrcodeRef.current.stop().catch(() => {});
      }

      setTimeout(() => {
        onScanSuccess(found, proof);
      }, 700);
    } else {
      // Unrecognized code
      setUnrecognizedCode(cleanCode);
      setIsProcessingMatch(false);
      // Allow retry after 3 seconds
      setTimeout(() => {
        setUnrecognizedCode(null);
        setLastScannedCode(null);
      }, 3500);
    }
  };

  // Toggle Torch/Flashlight if available
  const handleToggleTorch = async () => {
    try {
      if (html5QrcodeRef.current) {
        const track = (html5QrcodeRef.current as any).getRunningTrack();
        if (track && track.applyConstraints) {
          const newTorch = !torchOn;
          await track.applyConstraints({
            advanced: [{ torch: newTorch }]
          });
          setTorchOn(newTorch);
        }
      }
    } catch (e) {
      console.warn('Torch not supported on this device/camera');
    }
  };

  // Switch facing mode (Back / Front)
  const handleSwitchCamera = () => {
    setFacingMode((prev) => (prev === 'environment' ? 'user' : 'environment'));
  };

  return (
    <div 
      id="strict-anti-fraud-scanner-modal"
      className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 text-right overflow-y-auto"
    >
      <div className="bg-slate-900 border-2 border-emerald-500/60 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl flex flex-col relative animate-in fade-in zoom-in-95 duration-200">
        
        {/* Top Header */}
        <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 p-4 border-b border-emerald-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shadow-inner">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-white font-extrabold text-sm sm:text-base">القارئ المباشر لمنع التلاعب</span>
                <span className="bg-rose-500/20 text-rose-400 border border-rose-500/40 text-[10px] px-2 py-0.5 rounded-full font-bold flex items-center gap-1 animate-pulse">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-500"></span>
                  عدسة حية فقط
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                فحص فوري للأصل عبر الكاميرا الحية • يُحظر رفع الصور نهائياً
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 p-2 rounded-xl transition-colors"
            title="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Anti-Fraud Security Guarantee Notice */}
        <div className="bg-emerald-950/60 border-b border-emerald-500/20 px-4 py-2 flex items-center justify-between text-[11px] text-emerald-300">
          <div className="flex items-center gap-1.5">
            <Lock className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span>نظام منع الغش النشط: يتم التحقق من البث الحي والختم الزمني المشفر</span>
          </div>
          <span className="font-mono text-[10px] bg-black/40 px-2 py-0.5 rounded text-emerald-400 border border-emerald-500/30">
            {currentTimeStr || '2026-09-21'}
          </span>
        </div>

        {/* Live Camera Viewport */}
        <div className="relative bg-black flex flex-col items-center justify-center min-h-[340px] sm:min-h-[380px] overflow-hidden">
          
          {/* HTML5-QRCode Scanner Container */}
          <div 
            id={scannerId} 
            className="w-full h-full max-h-[380px] object-cover"
          />

          {/* Fallback Error Message if Camera Access Fails */}
          {cameraError && (
            <div className="absolute inset-0 bg-slate-950/95 flex flex-col items-center justify-center p-6 text-center z-20">
              <div className="w-14 h-14 rounded-2xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 mb-3">
                <AlertOctagon className="w-8 h-8" />
              </div>
              <h4 className="text-white font-bold text-base mb-1">تعذر تشغيل عدسة الكاميرا</h4>
              <p className="text-slate-400 text-xs leading-relaxed max-w-sm mb-4">
                {cameraError}
              </p>
              <button
                onClick={() => setFacingMode((prev) => (prev === 'environment' ? 'environment' : 'environment'))}
                className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow-lg flex items-center gap-2"
              >
                <RefreshCw className="w-4 h-4" />
                إعادة المحاولة وتنشيط العدسة
              </button>
            </div>
          )}

          {/* Active Live Scanner Overlay */}
          {cameraActive && !matchedAsset && (
            <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-between p-4 z-10">
              {/* Top Bar Indicator */}
              <div className="w-full flex items-center justify-between">
                <div className="bg-black/60 backdrop-blur-md px-3 py-1 rounded-full border border-white/20 text-white text-[11px] font-mono flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
                  <span>LIVE CAM</span>
                </div>
                <div className="bg-emerald-950/80 backdrop-blur-md px-3 py-1 rounded-full border border-emerald-500/40 text-emerald-300 text-[10px] font-semibold">
                  مستشعر سباهي الرقمي
                </div>
              </div>

              {/* Center Targeting Reticle */}
              <div className="relative w-64 h-64 sm:w-72 sm:h-72 border-2 border-emerald-400/40 rounded-3xl overflow-hidden flex items-center justify-center">
                {/* Corner Marks */}
                <div className="absolute top-2 right-2 w-6 h-6 border-t-4 border-r-4 border-emerald-400 rounded-tr-lg"></div>
                <div className="absolute top-2 left-2 w-6 h-6 border-t-4 border-l-4 border-emerald-400 rounded-tl-lg"></div>
                <div className="absolute bottom-2 right-2 w-6 h-6 border-b-4 border-r-4 border-emerald-400 rounded-br-lg"></div>
                <div className="absolute bottom-2 left-2 w-6 h-6 border-b-4 border-l-4 border-emerald-400 rounded-bl-lg"></div>

                {/* Animated Laser Scan Beam */}
                <div className="absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-[0_0_15px_#10b981] animate-[scan_2s_ease-in-out_infinite]"></div>

                <div className="text-center text-slate-300/80 text-[11px] font-medium bg-black/50 px-3 py-1.5 rounded-xl border border-white/10 pointer-events-none">
                  وجّه العدسة نحو ملصق الباركود أو الـ QR
                </div>
              </div>

              {/* Bottom Instructions */}
              <div className="bg-black/70 backdrop-blur-md px-4 py-1.5 rounded-full border border-white/15 text-slate-300 text-[11px]">
                يتم قراءة كود الأصل ومطابقته فورياً مع الخطة المزمنة
              </div>
            </div>
          )}

          {/* Success Matched State */}
          {matchedAsset && (
            <div className="absolute inset-0 bg-emerald-950/95 flex flex-col items-center justify-center p-6 text-center z-30 animate-in fade-in zoom-in-95">
              <div className="w-16 h-16 rounded-3xl bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center text-emerald-400 mb-3 shadow-[0_0_25px_rgba(16,185,129,0.5)]">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[11px] font-bold px-3 py-1 rounded-full mb-2">
                تمت القراءة الحية والمطابقة بنجاح ✅
              </span>
              <h3 className="text-white font-black text-lg mb-1 font-mono">
                {matchedAsset.asset_tag}
              </h3>
              <p className="text-emerald-100 font-bold text-sm mb-1">
                {matchedAsset.name}
              </p>
              <p className="text-emerald-300/80 text-xs">
                {matchedAsset.categoryNameAr} • {matchedAsset.location}
              </p>
              <div className="mt-4 flex items-center gap-1.5 text-[11px] text-emerald-300">
                <Sparkles className="w-3.5 h-3.5 animate-spin" />
                <span>جاري فتح استمارة الفحص الدقيقة للجهاز...</span>
              </div>
            </div>
          )}

          {/* Unrecognized Code Alert */}
          {unrecognizedCode && (
            <div className="absolute bottom-4 inset-x-4 bg-rose-950/95 border border-rose-500/50 p-3 rounded-2xl shadow-xl flex items-center gap-3 text-right z-30 animate-in slide-in-from-bottom-2">
              <div className="w-10 h-10 rounded-xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400 shrink-0">
                <AlertOctagon className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-white font-bold text-xs">كود غير مسجل في سجل أصول مستشفى آزال!</div>
                <div className="text-rose-300 text-[11px] truncate font-mono">الكود المقروء: {unrecognizedCode}</div>
              </div>
            </div>
          )}
        </div>

        {/* Controls Bar */}
        <div className="bg-slate-950 p-3 sm:p-4 border-t border-slate-800 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={handleToggleTorch}
              className={`px-3 py-2 rounded-xl text-xs font-bold border transition-colors flex items-center gap-1.5 ${
                torchOn 
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' 
                  : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
              }`}
            >
              <Zap className="w-4 h-4" />
              <span>{torchOn ? 'إطفاء الفلاش' : 'تشغيل الفلاش'}</span>
            </button>

            <button
              onClick={handleSwitchCamera}
              className="px-3 py-2 rounded-xl text-xs font-bold border border-slate-700 bg-slate-800 text-slate-300 hover:bg-slate-700 transition-colors flex items-center gap-1.5"
            >
              <RefreshCw className="w-4 h-4" />
              <span>تبديل العدسة</span>
            </button>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl transition-colors"
          >
            إلغاء
          </button>
        </div>

        {/* Footer info note */}
        <div className="bg-slate-900 px-4 py-2 border-t border-slate-800/80 text-[10px] text-slate-500 text-center">
          حماية أصول الرعاية الكاملة • معتمد لمعايير CBAHI FMS لضمان التواجد الميداني الحقيقي
        </div>
      </div>
    </div>
  );
};
