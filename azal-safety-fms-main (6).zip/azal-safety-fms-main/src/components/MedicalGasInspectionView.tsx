import React, { useState, useEffect } from 'react';
import { 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  Plus, 
  Printer, 
  Search, 
  Filter, 
  Calendar, 
  ShieldCheck, 
  Wind,
  Layers,
  Trash2,
  Lock,
  ArrowUpDown
} from 'lucide-react';
import { MedicalGasCylinderCheckRecord, StaffUser } from '../types';
import { offlineStorage } from '../services/offlineStorage';
import { AZAL_HOSPITAL_LOCATIONS } from '../data/azalSecurityData';
import { AzalLogo } from './AzalLogo';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';
import { executeSmartPrint } from '../utils/printUtils';

interface MedicalGasInspectionViewProps {
  currentUser: StaffUser;
  onLogAudit: (action: string, actionAr: string, details: string) => void;
}

const INITIAL_GAS_CHECKS: MedicalGasCylinderCheckRecord[] = [
  {
    id: 'gas-check-001',
    checkDate: new Date().toISOString().split('T')[0],
    cylinderType: 'oxygen',
    location: 'محطة الغازات الطبية المركزية - المبنى الرئيسي',
    isChainedSecurely: true,
    valveSafetyCapPresent: true,
    oxygenIsolatedFromCombustibles: true,
    fullEmptySegregated: true,
    pressureStatus: 'adequate',
    inspectorName: 'م/ نجيب غازي',
    status: 'compliant',
    notes: 'تم فحص منظومة الأسطوانات المركزية، السلاسل الجدارية محكمة ومفصولة الفارغ عن الممتلئ.',
    createdAt: Date.now() - 1000 * 60 * 60 * 4
  },
  {
    id: 'gas-check-002',
    checkDate: new Date().toISOString().split('T')[0],
    cylinderType: 'oxygen',
    location: 'قسم الطوارئ والإسعاف - غرفة الإنعاش',
    isChainedSecurely: true,
    valveSafetyCapPresent: true,
    oxygenIsolatedFromCombustibles: true,
    fullEmptySegregated: true,
    pressureStatus: 'adequate',
    inspectorName: 'مشرف السلامة الميداني',
    status: 'compliant',
    notes: 'أسطوانة أكسجين احتياطي نقالة مربوطة بسلسلة جدارية وجاهزة للاستخدام الفوري.',
    createdAt: Date.now() - 1000 * 60 * 60 * 20
  },
  {
    id: 'gas-check-003',
    checkDate: new Date().toISOString().split('T')[0],
    cylinderType: 'nitrous_oxide',
    location: 'غرف العمليات الجراحية الكبرى - الدور الثالث',
    isChainedSecurely: true,
    valveSafetyCapPresent: true,
    oxygenIsolatedFromCombustibles: true,
    fullEmptySegregated: true,
    pressureStatus: 'adequate',
    inspectorName: 'م/ نجيب غازي',
    status: 'compliant',
    notes: 'مطابقة تامة لمعايير سباهي (CBAHI FMS.4) وإرشادات السلامة للمركز الجراحي.',
    createdAt: Date.now() - 1000 * 60 * 60 * 48
  }
];

export const MedicalGasInspectionView: React.FC<MedicalGasInspectionViewProps> = ({
  currentUser,
  onLogAudit
}) => {
  const [records, setRecords] = useState<MedicalGasCylinderCheckRecord[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [filterType, setFilterType] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Form State
  const [cylinderType, setCylinderType] = useState<'oxygen' | 'nitrous_oxide' | 'medical_air' | 'carbon_dioxide'>('oxygen');
  const [location, setLocation] = useState(AZAL_HOSPITAL_LOCATIONS[0]);
  const [isChainedSecurely, setIsChainedSecurely] = useState(true);
  const [valveSafetyCapPresent, setValveSafetyCapPresent] = useState(true);
  const [oxygenIsolatedFromCombustibles, setOxygenIsolatedFromCombustibles] = useState(true);
  const [fullEmptySegregated, setFullEmptySegregated] = useState(true);
  const [pressureStatus, setPressureStatus] = useState<'adequate' | 'low' | 'empty'>('adequate');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    loadRecords();
  }, []);

  const loadRecords = async () => {
    try {
      const stored = await offlineStorage.getMedicalGasChecks();
      if (stored && stored.length > 0) {
        setRecords(stored);
      } else {
        setRecords(INITIAL_GAS_CHECKS);
        for (const item of INITIAL_GAS_CHECKS) {
          await offlineStorage.saveMedicalGasCheck(item);
        }
      }
    } catch {
      setRecords(INITIAL_GAS_CHECKS);
    }
  };

  const handleCreateCheck = async (e: React.FormEvent) => {
    e.preventDefault();

    const isAllCompliant = isChainedSecurely && valveSafetyCapPresent && oxygenIsolatedFromCombustibles && fullEmptySegregated;
    const computedStatus: 'compliant' | 'non_compliant' | 'action_needed' = 
      isAllCompliant && pressureStatus !== 'empty' 
        ? 'compliant' 
        : !isChainedSecurely || !oxygenIsolatedFromCombustibles 
        ? 'non_compliant' 
        : 'action_needed';

    const newRecord: MedicalGasCylinderCheckRecord = {
      id: `gas-${Date.now()}`,
      checkDate: new Date().toISOString().split('T')[0],
      cylinderType,
      location,
      isChainedSecurely,
      valveSafetyCapPresent,
      oxygenIsolatedFromCombustibles,
      fullEmptySegregated,
      pressureStatus,
      inspectorName: currentUser.name,
      status: computedStatus,
      notes: notes.trim() || 'تم إجراء الفحص الدوري لأسطوانات الغازات الطبية وتوثيق المطابقة.',
      createdAt: Date.now()
    };

    const updated = [newRecord, ...records];
    setRecords(updated);
    await offlineStorage.saveMedicalGasCheck(newRecord);

    // Audio and haptic feedback
    triggerSuccessFeedback();

    onLogAudit(
      'MEDICAL_GAS_CHECK_LOGGED',
      'تسجيل فحص أسطوانات الغازات الطبية',
      `تم توثيق فحص أسطوانات (${cylinderType}) بموقع (${location}) - الحالة: ${computedStatus === 'compliant' ? 'مطابق' : 'غير مطابق'}`
    );

    setShowAddModal(false);
    setNotes('');
  };

  const handleDeleteRecord = async (id: string) => {
    if (confirm('هل أنت متأكد من رغبتك في حذف هذا السجل؟')) {
      const updated = records.filter(r => r.id !== id);
      setRecords(updated);
      await offlineStorage.deleteMedicalGasCheck(id);
    }
  };

  const handlePrint = () => {
    const tableRows = filtered.map((r, idx) => `
      <tr>
        <td style="font-weight:bold; font-family:monospace;">${idx + 1}</td>
        <td><strong>${r.cylinderType}</strong></td>
        <td>${r.location}</td>
        <td style="font-weight:bold;">${r.cylinderCount} أسطوانة</td>
        <td>${r.chainedAndSecured ? '<span class="badge-success">مؤمنة بسلاسل ✔</span>' : '<span class="badge-danger">غير مثبتة ✖</span>'}</td>
        <td>${r.fullEmptySegregated ? '<span class="badge-success">مفصولة ومميزة ✔</span>' : '<span class="badge-danger">غير مفصولة ✖</span>'}</td>
        <td>${r.pressureStatus === 'adequate' ? '<span class="badge-success">ضغط كافٍ</span>' : r.pressureStatus === 'low' ? '<span class="badge-warning">منخفض</span>' : '<span class="badge-danger">فارغة</span>'}</td>
        <td>${r.status === 'compliant' ? '<span class="badge-success">مطابق للسلامة</span>' : '<span class="badge-danger">غير مطابق</span>'}</td>
        <td>${r.inspectorName}</td>
        <td>${r.notes || '-'}</td>
      </tr>
    `).join('');

    const bodyHtml = `
      <div class="summary-grid">
        <div class="summary-card"><div class="val">${records.length}</div><div class="lbl">إجمالي الفحوصات</div></div>
        <div class="summary-card"><div class="val" style="color:#047857;">${compliantCount}</div><div class="lbl">مطابقة ومعتمدة</div></div>
        <div class="summary-card"><div class="val" style="color:#b91c1c;">${nonCompliantCount}</div><div class="lbl">مخالفة لسلامة الغازات</div></div>
        <div class="summary-card"><div class="val" style="color:#b45309;">${actionNeededCount}</div><div class="lbl">تتطلب تدخلاً عاجلاً</div></div>
      </div>
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>نوع الغاز</th>
            <th>الموقع / القسم</th>
            <th>العدد</th>
            <th>التثبيت بالسلاسل</th>
            <th>فصل الممتلئ/الفارغ</th>
            <th>حالة الضغط</th>
            <th>النتيجة</th>
            <th>المفتش</th>
            <th>الملاحظات والتوصيف</th>
          </tr>
        </thead>
        <tbody>
          ${tableRows || '<tr><td colspan="10" style="text-align:center; padding:12px;">لا توجد سجلات مسجلة</td></tr>'}
        </tbody>
      </table>
    `;

    executeSmartPrint(bodyHtml, {
      title: 'سجل فحص وتدقيق أسطوانات الغازات الطبية المعتمد',
      subtitle: 'معيار السلامة وإدارة المرافق CBAHI FMS.9 • شبكة الغازات الطبية والأسطوانات المضغوطة',
      refNumber: 'AZAL-MEDGAS-LOG-2026'
    });
  };

  const filtered = records.filter(r => {
    const matchType = filterType === 'all' || r.cylinderType === filterType;
    const matchStatus = filterStatus === 'all' || r.status === filterStatus;
    const matchSearch = r.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        r.inspectorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        (r.notes && r.notes.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchType && matchStatus && matchSearch;
  });

  const compliantCount = records.filter(r => r.status === 'compliant').length;
  const nonCompliantCount = records.filter(r => r.status === 'non_compliant').length;
  const actionNeededCount = records.filter(r => r.status === 'action_needed').length;

  return (
    <div id="medical-gas-inspection-view" className="space-y-4 text-right">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-teal-950/80 border border-slate-800 rounded-3xl p-5 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-teal-950 border border-teal-700 text-teal-400">
            <Wind className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-slate-100">
                سجل تفتيش أسطوانات الغازات الطبية (CBAHI FMS Medical Gas Check)
              </h2>
              <span className="text-[10px] bg-teal-950 text-teal-300 border border-teal-700 font-bold px-2 py-0.5 rounded-lg">
                معيار سباهي FMS.4
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              مراقبة التثبيت المزدوج بالسلاسل، سلامة الصمامات، عزل الأكسجين عن المواد الخطرة، وفصل الفارغ عن الممتلئ.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs shadow-md flex items-center gap-2 transition"
          >
            <Plus className="w-4 h-4" />
            <span>تسجيل فحص أسطوانة جديد</span>
          </button>

          <button
            type="button"
            onClick={handlePrint}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold flex items-center gap-1.5 transition"
          >
            <Printer className="w-4 h-4" />
            <span>طباعة السجل</span>
          </button>
        </div>
      </div>

      {/* KPI Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
          <div className="text-slate-400 text-xs">إجمالي فحوصات الغازات</div>
          <div className="text-2xl font-black text-slate-100 mt-1">{records.length}</div>
          <div className="text-[10px] text-teal-400 mt-1">سجلات دورية معتمدة</div>
        </div>

        <div className="bg-slate-900 border border-emerald-900/60 rounded-2xl p-4">
          <div className="text-slate-400 text-xs">مطابقة تامة 100% (Compliant)</div>
          <div className="text-2xl font-black text-emerald-400 mt-1">{compliantCount}</div>
          <div className="text-[10px] text-emerald-300 mt-1">سلاسل وصمامات وفصل كامل</div>
        </div>

        <div className="bg-slate-900 border border-rose-900/60 rounded-2xl p-4">
          <div className="text-slate-400 text-xs">غير مطابقة (مخاطر فورية)</div>
          <div className="text-2xl font-black text-rose-400 mt-1">{nonCompliantCount}</div>
          <div className="text-[10px] text-rose-300 mt-1">أسطوانات غير مثبتة أو غير معزولة</div>
        </div>

        <div className="bg-slate-900 border border-amber-900/60 rounded-2xl p-4">
          <div className="text-slate-400 text-xs">بحاجة لإجراء تصحيحي</div>
          <div className="text-2xl font-black text-amber-400 mt-1">{actionNeededCount}</div>
          <div className="text-[10px] text-amber-300 mt-1">أغطية ناقصة أو ضغط منخفض</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900/80 border border-slate-800 p-3 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex-1 min-w-[200px] relative">
          <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="بحث بالموقع، اسم المفتش، أو الملاحظات..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-9 pl-3 py-2 text-slate-200"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200"
          >
            <option value="all">كافة أنواع الغازات</option>
            <option value="oxygen">أكسجين طبي (O2)</option>
            <option value="nitrous_oxide">أكسيد النيتروز (N2O)</option>
            <option value="medical_air">هواء طبي مضغوط (Medical Air)</option>
            <option value="carbon_dioxide">ثاني أكسيد الكربون (CO2)</option>
          </select>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200"
          >
            <option value="all">كافة حالات المطابقة</option>
            <option value="compliant">مطابق ومعتمد (Compliant)</option>
            <option value="action_needed">بحاجة لإجراء تصحيحي</option>
            <option value="non_compliant">غير مطابق (Non-Compliant)</option>
          </select>
        </div>
      </div>

      {/* Gas Inspection Records Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-950 border-b border-slate-800 text-slate-400 font-bold">
              <tr>
                <th className="p-3.5">الغاز والموقع</th>
                <th className="p-3.5">تاريخ الفحص</th>
                <th className="p-3.5 text-center">التثبيت بسلاسل</th>
                <th className="p-3.5 text-center">غطاء الصمام</th>
                <th className="p-3.5 text-center">عزل الأكسجين</th>
                <th className="p-3.5 text-center">فصل الفارغ/الممتلئ</th>
                <th className="p-3.5 text-center">حالة الضغط</th>
                <th className="p-3.5">المفتش والملاحظات</th>
                <th className="p-3.5 text-center">القرار</th>
                <th className="p-3.5 text-center">إجراء</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={10} className="p-8 text-center text-slate-400">
                    لا توجد سجلات مطابقة لمعايير البحث
                  </td>
                </tr>
              ) : (
                filtered.map((record) => {
                  const gasName = 
                    record.cylinderType === 'oxygen' ? 'أكسجين طبي (O2)' :
                    record.cylinderType === 'nitrous_oxide' ? 'أكسيد النيتروز (N2O)' :
                    record.cylinderType === 'medical_air' ? 'هواء طبي مضغوط' : 'ثاني أكسيد الكربون (CO2)';
                  
                  return (
                    <tr key={record.id} className="hover:bg-slate-800/30 transition">
                      <td className="p-3.5">
                        <div className="font-bold text-slate-100">{gasName}</div>
                        <div className="text-[11px] text-slate-400">{record.location}</div>
                      </td>
                      <td className="p-3.5 text-slate-300 font-mono">
                        {record.checkDate}
                      </td>
                      <td className="p-3.5 text-center">
                        {record.isChainedSecurely ? (
                          <span className="text-emerald-400 font-bold bg-emerald-950/70 border border-emerald-800/80 px-2 py-0.5 rounded-lg text-[10px]">✓ مثبت بسلسلة</span>
                        ) : (
                          <span className="text-rose-400 font-bold bg-rose-950/70 border border-rose-800/80 px-2 py-0.5 rounded-lg text-[10px]">✕ غير مثبت</span>
                        )}
                      </td>
                      <td className="p-3.5 text-center">
                        {record.valveSafetyCapPresent ? (
                          <span className="text-emerald-400 font-bold text-xs">✓ سليم</span>
                        ) : (
                          <span className="text-amber-400 font-bold text-xs">✕ ناقص</span>
                        )}
                      </td>
                      <td className="p-3.5 text-center">
                        {record.oxygenIsolatedFromCombustibles ? (
                          <span className="text-emerald-400 font-bold text-xs">✓ معزول</span>
                        ) : (
                          <span className="text-rose-400 font-bold text-xs">✕ غير معزول</span>
                        )}
                      </td>
                      <td className="p-3.5 text-center">
                        {record.fullEmptySegregated ? (
                          <span className="text-emerald-400 font-bold text-xs">✓ مفصول</span>
                        ) : (
                          <span className="text-amber-400 font-bold text-xs">✕ مختلط</span>
                        )}
                      </td>
                      <td className="p-3.5 text-center">
                        <span className={`px-2 py-0.5 rounded-lg font-bold text-[10px] ${
                          record.pressureStatus === 'adequate' 
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' 
                            : record.pressureStatus === 'low' 
                            ? 'bg-amber-950 text-amber-300 border border-amber-800' 
                            : 'bg-slate-800 text-slate-400'
                        }`}>
                          {record.pressureStatus === 'adequate' ? 'كافٍ ومعتمد' : record.pressureStatus === 'low' ? 'منخفض' : 'فارغ'}
                        </span>
                      </td>
                      <td className="p-3.5">
                        <div className="text-slate-200 font-semibold">{record.inspectorName}</div>
                        <div className="text-[11px] text-slate-400 line-clamp-1">{record.notes}</div>
                      </td>
                      <td className="p-3.5 text-center">
                        <span className={`px-2.5 py-1 rounded-xl text-[11px] font-bold ${
                          record.status === 'compliant'
                            ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-700'
                            : record.status === 'non_compliant'
                            ? 'bg-rose-950/80 text-rose-300 border border-rose-700'
                            : 'bg-amber-950/80 text-amber-300 border border-amber-700'
                        }`}>
                          {record.status === 'compliant' ? 'مطابق سباهي' : record.status === 'non_compliant' ? 'غير مطابق' : 'إجراء تصحيحي'}
                        </span>
                      </td>
                      <td className="p-3.5 text-center">
                        <button
                          type="button"
                          onClick={() => handleDeleteRecord(record.id)}
                          className="p-1.5 rounded-lg bg-slate-800 text-rose-400 hover:bg-rose-950 hover:text-rose-300 transition"
                          title="حذف السجل"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* New Medical Gas Check Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-teal-600/60 rounded-3xl w-full max-w-xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
            <div className="bg-slate-950 px-5 py-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-teal-950 text-teal-400 border border-teal-800">
                  <Wind className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-100">
                    توثيق فحص أسطوانات الغازات الطبية (معايير CBAHI FMS)
                  </h3>
                  <p className="text-[11px] text-slate-400">مستشفى آزال النموذجي • السلامة وإدارة المرافق</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="p-1 rounded-lg bg-slate-800 text-slate-400 hover:text-slate-100"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateCheck} className="p-5 space-y-4 overflow-y-auto text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">نوع الغاز الطبي:</label>
                  <select
                    value={cylinderType}
                    onChange={(e) => setCylinderType(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                  >
                    <option value="oxygen">أكسجين طبي (O2)</option>
                    <option value="nitrous_oxide">أكسيد النيتروز (N2O)</option>
                    <option value="medical_air">هواء طبي مضغوط (Medical Air)</option>
                    <option value="carbon_dioxide">ثاني أكسيد الكربون (CO2)</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">الموقع داخل المستشفى:</label>
                  <select
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                  >
                    {AZAL_HOSPITAL_LOCATIONS.map((loc, idx) => (
                      <option key={idx} value={loc}>{loc}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* CBAHI FMS Core Inspection Checkpoints */}
              <div className="bg-slate-950/70 border border-teal-900/60 rounded-2xl p-3.5 space-y-3">
                <div className="text-teal-400 font-bold text-xs flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4" />
                  <span>عناصر التدقيق الإلزامية (معايير FMS.4):</span>
                </div>

                <label className="flex items-center justify-between p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 cursor-pointer">
                  <span className="text-slate-200">1. التثبيت بسلاسل جدارية مزدوجة لمنع السقوط:</span>
                  <input
                    type="checkbox"
                    checked={isChainedSecurely}
                    onChange={(e) => setIsChainedSecurely(e.target.checked)}
                    className="w-4 h-4 accent-teal-500 rounded"
                  />
                </label>

                <label className="flex items-center justify-between p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 cursor-pointer">
                  <span className="text-slate-200">2. سلامة الصمامات وتواجد أغطية الحماية (Safety Valve Caps):</span>
                  <input
                    type="checkbox"
                    checked={valveSafetyCapPresent}
                    onChange={(e) => setValveSafetyCapPresent(e.target.checked)}
                    className="w-4 h-4 accent-teal-500 rounded"
                  />
                </label>

                <label className="flex items-center justify-between p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 cursor-pointer">
                  <span className="text-slate-200">3. عزل أسطوانات الأكسجين عن المواد القابلة للاشتعال والزيوت:</span>
                  <input
                    type="checkbox"
                    checked={oxygenIsolatedFromCombustibles}
                    onChange={(e) => setOxygenIsolatedFromCombustibles(e.target.checked)}
                    className="w-4 h-4 accent-teal-500 rounded"
                  />
                </label>

                <label className="flex items-center justify-between p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 cursor-pointer">
                  <span className="text-slate-200">4. الفصل التام والتمييز الواضح بين الفارغ والممتلئ:</span>
                  <input
                    type="checkbox"
                    checked={fullEmptySegregated}
                    onChange={(e) => setFullEmptySegregated(e.target.checked)}
                    className="w-4 h-4 accent-teal-500 rounded"
                  />
                </label>
              </div>

              <div>
                <label className="text-slate-300 block mb-1 font-semibold">حالة ضغط الأسطوانة:</label>
                <select
                  value={pressureStatus}
                  onChange={(e) => setPressureStatus(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                >
                  <option value="adequate">ضغط كافٍ ومطابق للتشغيل (&gt; 150 bar)</option>
                  <option value="low">ضغط منخفض يستوجب التبديل</option>
                  <option value="empty">أسطوانة فارغة يجب نقلها لمنطقة الفارغ</option>
                </select>
              </div>

              <div>
                <label className="text-slate-300 block mb-1 font-semibold">ملاحظات الفحص الميداني والتوصيات:</label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="اكتب أي ملاحظات تتعلق بسلامة المحطة أو تسريب الغاز..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 text-xs"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>اعتماد وحفظ الفحص</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
