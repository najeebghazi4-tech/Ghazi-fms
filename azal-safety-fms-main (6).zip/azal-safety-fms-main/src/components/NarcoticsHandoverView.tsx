import React, { useState } from 'react';
import { 
  Pill, 
  ShieldCheck, 
  AlertTriangle, 
  CheckCircle2, 
  Flame, 
  KeyRound, 
  Activity, 
  FileCheck,
  RotateCcw
} from 'lucide-react';
import { ControlledSubstance, CrashCartChecklist, StaffUser } from '../types';

interface NarcoticsHandoverViewProps {
  narcoticsList: ControlledSubstance[];
  crashCart: CrashCartChecklist;
  currentUser: StaffUser;
  staffList: StaffUser[];
  onUpdateNarcotics: (updated: ControlledSubstance[]) => void;
  onUpdateCrashCart: (updated: CrashCartChecklist) => void;
  onLogAudit: (action: string, actionAr: string, details: string) => void;
}

export const NarcoticsHandoverView: React.FC<NarcoticsHandoverViewProps> = ({
  narcoticsList,
  crashCart,
  currentUser,
  staffList,
  onUpdateNarcotics,
  onUpdateCrashCart,
  onLogAudit,
}) => {
  const [items, setItems] = useState<ControlledSubstance[]>([...narcoticsList]);
  const [cart, setCart] = useState<CrashCartChecklist>({ ...crashCart });
  const [witnessStaffId, setWitnessStaffId] = useState(
    staffList.find((s) => s.id !== currentUser.id)?.id || staffList[0].id
  );
  const [witnessPin, setWitnessPin] = useState('');
  const [isWitnessVerified, setIsWitnessVerified] = useState(false);
  const [toastSuccess, setToastSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const witnessUser = staffList.find((s) => s.id === witnessStaffId) || staffList[0];

  const handleAdjustCount = (id: string, delta: number) => {
    setItems((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const newCount = Math.max(0, item.currentCount + delta);
          return {
            ...item,
            currentCount: newCount,
            lastCheckedBy: currentUser.name,
            lastCheckedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
          };
        }
        return item;
      })
    );
  };

  const handleVerifyWitness = () => {
    if (witnessPin === witnessUser.pin) {
      setIsWitnessVerified(true);
      setErrorMsg('');
    } else {
      setErrorMsg(`رمز PIN غير صحيح للشاهد المساعد (${witnessUser.name})`);
    }
  };

  const handleSaveAll = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isWitnessVerified) {
      setErrorMsg('يلزم قانونياً توثيق رمز الشاهد التمريضي الثاني لجرد المخدرات وعربة الإنعاش');
      return;
    }

    onUpdateNarcotics(items);
    onUpdateCrashCart({
      ...cart,
      checkedBy: currentUser.name,
      witnessedBy: witnessUser.name,
      checkedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
    });

    onLogAudit(
      'NARCOTICS_CRASH_CART_VERIFIED',
      'اعتماد جرد الأدوية المراقبة وعربة الإنعاش المشترك',
      `تم جرد رصيد المخدرات وفحص عربة الإنعاش (ختم: ${cart.lockTagNumber}) بتوثيق ${currentUser.name} وبشهادة ${witnessUser.name}.`
    );

    setToastSuccess(true);
    setTimeout(() => setToastSuccess(false), 3000);
  };

  return (
    <div id="narcotics-handover-view" className="space-y-4 pb-20 text-right">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-teal-950/80 via-slate-900 to-slate-900 border border-teal-800/60 rounded-2xl p-4 shadow-lg">
        <div className="flex items-center gap-2 mb-1">
          <div className="p-2 rounded-xl bg-teal-900/60 text-teal-300 border border-teal-700">
            <Pill className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-100">
              جرد وتسليم عهدة الأدوية المخدرة والمراقبة (Controlled Drugs)
            </h2>
            <p className="text-xs text-slate-400">
              إجراء أمان إلزامي ومحكم يتطلب مطابقة الرصيد الفعلي وشاهدين معتمدين بكل وردية
            </p>
          </div>
        </div>
      </div>

      {/* Controlled Substances Table Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-teal-400 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4" />
            <span>رصيد الخزنة الفولاذية الموثق (Schedule II & IV)</span>
          </h3>
          <span className="text-[11px] text-slate-400 font-mono">
            {items.length} أصناف دوائية مسجلة
          </span>
        </div>

        <div className="space-y-2.5">
          {items.map((substance) => (
            <div
              key={substance.id}
              className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
            >
              <div className="text-right">
                <h4 className="text-xs font-bold text-slate-100">{substance.name}</h4>
                <div className="flex items-center gap-2 mt-0.5 text-[11px] text-slate-400">
                  <span className="text-teal-400 font-mono font-semibold">{substance.strength}</span>
                  <span>•</span>
                  <span>آخر جرد: {substance.lastCheckedBy}</span>
                </div>
              </div>

              {/* Counter Buttons */}
              <div className="flex items-center gap-2 self-end sm:self-auto">
                <span className="text-[11px] text-slate-400">الرصيد الفعلي:</span>
                <div className="flex items-center bg-slate-900 border border-slate-700 rounded-lg overflow-hidden font-mono">
                  <button
                    type="button"
                    onClick={() => handleAdjustCount(substance.id, -1)}
                    className="w-8 h-8 flex items-center justify-center text-slate-300 hover:bg-slate-800 active:bg-slate-700 text-base font-bold"
                  >
                    -
                  </button>
                  <span className="w-10 text-center font-bold text-teal-300 text-sm">
                    {substance.currentCount}
                  </span>
                  <button
                    type="button"
                    onClick={() => handleAdjustCount(substance.id, 1)}
                    className="w-8 h-8 flex items-center justify-center text-slate-300 hover:bg-slate-800 active:bg-slate-700 text-base font-bold"
                  >
                    +
                  </button>
                </div>
                <span className="text-xs text-slate-400">{substance.unit}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Emergency Crash Cart Inspection Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-rose-400 flex items-center gap-1.5">
            <Activity className="w-4 h-4 text-rose-500" />
            <span>فحص وتدقيق عربة الإنعاش القلبي الرئوي (Crash Cart)</span>
          </h3>
          <span className="text-[11px] text-slate-400 font-mono">
            {cart.id}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2">
            <label className="flex items-center gap-2 cursor-pointer text-slate-200">
              <input
                type="checkbox"
                checked={cart.defibrillatorBatteryOk}
                onChange={(e) => setCart({ ...cart, defibrillatorBatteryOk: e.target.checked })}
                className="h-4 w-4 rounded bg-slate-900 border-slate-700 text-teal-500"
              />
              <span className="font-semibold">بطارية الصادم الآلي مشحونة وجاهزة للعمل (Defibrillator)</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer text-slate-200">
              <input
                type="checkbox"
                checked={cart.suctionWorking}
                onChange={(e) => setCart({ ...cart, suctionWorking: e.target.checked })}
                className="h-4 w-4 rounded bg-slate-900 border-slate-700 text-teal-500"
              />
              <span>جهاز الشفط الإسعافي (Suction Unit) يعمل بضغط كافٍ</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer text-slate-200">
              <input
                type="checkbox"
                checked={cart.laryngoscopeLightOk}
                onChange={(e) => setCart({ ...cart, laryngoscopeLightOk: e.target.checked })}
                className="h-4 w-4 rounded bg-slate-900 border-slate-700 text-teal-500"
              />
              <span>منظار الحنجرة وإضاءة شفرات التنبيب مجربة وسليمة</span>
            </label>
          </div>

          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-3">
            <div>
              <label className="text-slate-400 block mb-1">
                ضغط أسطوانة الأكسجين (PSI - الحد الأدنى الآمن 1500):
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  value={cart.oxygenTankPsi}
                  onChange={(e) => setCart({ ...cart, oxygenTankPsi: Number(e.target.value) })}
                  className="flex-1 bg-slate-900 border border-slate-700 rounded-lg p-2 font-mono font-bold text-slate-100 text-xs"
                />
                <span className={`text-xs font-bold px-2 py-1 rounded ${cart.oxygenTankPsi >= 1500 ? 'bg-emerald-950 text-emerald-300' : 'bg-rose-950 text-rose-300'}`}>
                  {cart.oxygenTankPsi >= 1500 ? 'آمن وممتلئ' : 'منخفض، يلزم استبدال'}
                </span>
              </div>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">
                رقم ختم القفل البلاستيكي الرصاصي (Tamper-Evident Seal Tag #):
              </label>
              <input
                type="text"
                value={cart.lockTagNumber}
                onChange={(e) => setCart({ ...cart, lockTagNumber: e.target.value })}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 font-mono text-teal-300 text-xs"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Dual Nurse Witness Sign-off */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3">
        <h3 className="text-xs font-bold text-teal-400 flex items-center gap-1.5">
          <KeyRound className="w-4 h-4" />
          <span>التوثيق والاعتماد المزدوج للشاهد التمريضي الثاني</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2">
            <span className="text-slate-400 block">الممارس المسؤول الحالي:</span>
            <div className="font-bold text-slate-100">{currentUser.name}</div>
            <span className="text-teal-400 text-[11px] block">{currentUser.roleTitleAr} ({currentUser.badgeNumber})</span>
          </div>

          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2">
            <label className="text-slate-400 block">الشاهد التمريضي الثاني المساعد:</label>
            <select
              value={witnessStaffId}
              disabled={isWitnessVerified}
              onChange={(e) => {
                setWitnessStaffId(e.target.value);
                setIsWitnessVerified(false);
              }}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-xs text-slate-100"
            >
              {staffList.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.badgeNumber})
                </option>
              ))}
            </select>

            {!isWitnessVerified ? (
              <div className="flex gap-2 pt-1">
                <input
                  type="password"
                  maxLength={4}
                  placeholder="رمز PIN الشاهد (4 أرقام)"
                  value={witnessPin}
                  onChange={(e) => setWitnessPin(e.target.value)}
                  className="flex-1 bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-center font-mono text-slate-100"
                />
                <button
                  type="button"
                  onClick={handleVerifyWitness}
                  className="px-3 py-1.5 rounded-lg bg-teal-700 hover:bg-teal-600 text-white font-bold"
                >
                  تأكيد الشاهد
                </button>
              </div>
            ) : (
              <div className="text-[11px] text-emerald-400 font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>تم توثيق شهادة الممارس الثاني برقم الهوية والرمز</span>
              </div>
            )}
          </div>
        </div>

        {errorMsg && (
          <div className="p-2.5 rounded-xl bg-rose-950/80 border border-rose-800 text-rose-300 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {toastSuccess && (
          <div className="p-3 rounded-xl bg-emerald-950/80 border border-emerald-700 text-emerald-300 text-xs flex items-center gap-2 animate-fade-in font-bold">
            <CheckCircle2 className="w-4 h-4" />
            <span>تم حفظ واعتماد محضر جرد المخدرات وعربة الإنعاش وتوثيقه في سجل الأمان المركزي!</span>
          </div>
        )}

        <div className="flex justify-end pt-2">
          <button
            type="button"
            onClick={handleSaveAll}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-bold text-xs shadow-lg shadow-teal-950 flex items-center gap-2 transition"
          >
            <FileCheck className="w-4 h-4" />
            <span>حفظ واعتماد الجرد في السجل الطبي المركزي</span>
          </button>
        </div>
      </div>
    </div>
  );
};
