import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw, Lock, Home, Trash2 } from 'lucide-react';
import { AzalLogo } from './AzalLogo';

interface ErrorBoundaryProps {
  children: ReactNode;
  fallback?: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
}

export class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  state: ErrorBoundaryState = {
    hasError: false,
    error: null,
    errorInfo: null,
  };

  constructor(props: ErrorBoundaryProps) {
    super(props);
  }

  static getDerivedStateFromError(error: Error): Partial<ErrorBoundaryState> {
    return {
      hasError: true,
      error,
    };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('CRITICAL UNHANDLED APPLICATION ERROR CAUGHT BY BOUNDARY:', error, errorInfo);
    this.setState({
      error,
      errorInfo,
    });
  }

  handleReload = () => {
    if (typeof window !== 'undefined') {
      window.location.reload();
    }
  };

  handleGoToLock = () => {
    if (typeof window !== 'undefined') {
      try {
        sessionStorage.removeItem('azal_auth_logged_in');
      } catch {}
      window.location.hash = '';
      window.location.pathname = '/';
      window.location.reload();
    }
  };

  handleGoToServices = () => {
    if (typeof window !== 'undefined') {
      window.location.hash = '#services';
      window.location.reload();
    }
  };

  handleHardReset = () => {
    if (typeof window !== 'undefined') {
      try {
        const preserveKeys = ['azal_fresh_clean_start_2026_sep', 'azal_fresh_start_clean_slate_2026_v3'];
        const preserved: Record<string, string> = {};
        preserveKeys.forEach((k) => {
          const val = localStorage.getItem(k);
          if (val) preserved[k] = val;
        });

        localStorage.clear();
        sessionStorage.clear();

        Object.entries(preserved).forEach(([k, v]) => {
          localStorage.setItem(k, v);
        });
      } catch (e) {
        console.warn('Storage cleanup failed', e);
      }
      window.location.hash = '';
      window.location.pathname = '/';
      window.location.reload();
    }
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      return (
        <div
          id="azal-error-boundary-screen"
          className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center p-4 sm:p-6 select-none font-sans"
          dir="rtl"
        >
          <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-7 shadow-2xl space-y-5 text-center">
            <div className="flex justify-center mb-1">
              <AzalLogo variant="horizontal" />
            </div>

            <div className="w-16 h-16 rounded-2xl bg-amber-950/80 border border-amber-600/50 flex items-center justify-center mx-auto text-amber-400 shadow-lg shadow-amber-950">
              <AlertTriangle className="w-8 h-8" />
            </div>

            <div className="space-y-1.5">
              <h1 className="text-base sm:text-lg font-bold text-slate-100">
                منظومة الحماية والاستعادة الذاتية
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                تم اعتراض وتطويق خطأ غير متوقع في واجهة العرض لمنع انهيار النظام أو ظهور شاشة فارغة.
              </p>
            </div>

            {this.state.error && (
              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-3 text-right max-h-36 overflow-y-auto text-left font-mono text-[11px] text-rose-300">
                <div className="text-slate-400 text-[10px] mb-1 font-sans text-right font-bold">
                  رمز الخطأ المعترض (Error Diagnostic):
                </div>
                <div className="select-all break-words" dir="ltr">
                  {this.state.error.name}: {this.state.error.message}
                </div>
              </div>
            )}

            <div className="flex flex-col gap-2 pt-1">
              <button
                type="button"
                onClick={this.handleReload}
                className="w-full py-2.5 px-4 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-teal-950 transition active:scale-98 cursor-pointer"
              >
                <RefreshCw className="w-4 h-4 animate-spin-slow" />
                <span>إعادة تحميل النظام وتحديث الشاشة</span>
              </button>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={this.handleGoToLock}
                  className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center gap-1.5 border border-slate-700 transition cursor-pointer"
                >
                  <Lock className="w-3.5 h-3.5 text-teal-400" />
                  <span>شاشة القفل الرئيسية</span>
                </button>

                <button
                  type="button"
                  onClick={this.handleGoToServices}
                  className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center gap-1.5 border border-slate-700 transition cursor-pointer"
                >
                  <Home className="w-3.5 h-3.5 text-amber-400" />
                  <span>بوابة الخدمات (#services)</span>
                </button>
              </div>

              <button
                type="button"
                onClick={this.handleHardReset}
                className="w-full py-2 px-3 rounded-xl bg-slate-900/60 hover:bg-rose-950/40 text-slate-400 hover:text-rose-300 font-semibold text-[11px] flex items-center justify-center gap-1.5 border border-slate-800 hover:border-rose-800 transition cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                <span>مسح الذاكرة المؤقتة وإعادة التهيئة النظيفة</span>
              </button>
            </div>

            <div className="text-[10px] text-slate-400 pt-2 border-t border-slate-800">
              مستشفى آزال النموذجي • إدارة الأمن والسلامة وإدارة المرافق FMS
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
