import React, { useState } from 'react';
import { 
  X, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldCheck, 
  Printer, 
  Save, 
  Clock, 
  User, 
  Building2,
  FileCheck,
  AlertOctagon,
  Sparkles
} from 'lucide-react';
import { PpmAsset } from '../data/azalPpmAssetsData';
import { AntiFraudScanProof, computeNextDueDate } from '../utils/ppmDueEngine';
import { executeSmartPrint } from '../utils/printUtils';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';

interface PpmInspectionAuditModalProps {
  asset: PpmAsset;
  scanProof?: AntiFraudScanProof | null;
  technicianName?: string;
  onClose: () => void;
  onSaveSuccess: (updatedAsset: PpmAsset, auditRecord: any) => void;
}

export const PpmInspectionAuditModal: React.FC<PpmInspectionAuditModalProps> = ({
  asset,
  scanProof,
  technicianName = '',
  onClose,
  onSaveSuccess
}) => {
  const [inspector, setInspector] = useState(technicianName || 'م. فني الصيانة والمرافق');
  const [checklistResults, setChecklistResults] = useState<Record<number, { status: 'pass' | 'fail' | 'na'; reading: string }>>(() => {
    const initial: Record<number, { status: 'pass' | 'fail' | 'na'; reading: string }> = {};
    asset.checklist_steps.forEach((step) => {
      initial[step.id] = { status: 'pass', reading: step.expected_value || 'مطابق' };
    });
    return initial;
  });

  const [overallOutcome, setOverallOutcome] = useState<'pass' | 'fail'>('pass');
  const [correctiveActions, setCorrectiveActions] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const todayStr = new Date().toISOString().split('T')[0];

  const handleStepStatusChange = (stepId: number, status: 'pass' | 'fail' | 'na') => {
    setChecklistResults((prev) => ({
      ...prev,
      [stepId]: { ...prev[stepId], status }
    }));
  };

  const handleStepReadingChange = (stepId: number, reading: string) => {
    setChecklistResults((prev) => ({
      ...prev,
      [stepId]: { ...prev[stepId], reading }
    }));
  };

  const handleSaveAudit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);

    try {
      const nextDue = computeNextDueDate(todayStr, asset.frequency);
      const updatedAsset: PpmAsset = {
        ...asset,
        last_pm_date: todayStr,
        next_pm_due: nextDue
      };

      const auditRecord = {
        id: `pm-rec-${Date.now()}`,
        asset_id: asset.id,
        asset_tag: asset.asset_tag,
        asset_name: asset.name,
        department: asset.categoryNameAr,
        inspection_date: todayStr,
        inspector_name: inspector,
        overall_outcome: overallOutcome === 'pass' ? 'ناجح ومطابق' : 'يحتاج صيانة علاجية',
        checklist_details: checklistResults,
        corrective_notes: correctiveActions,
        scan_proof_token: scanProof?.token || 'VERIFIED_OFFICIAL_SESSION',
        created_at: new Date().toISOString()
      };

      triggerSuccessFeedback();
      onSaveSuccess(updatedAsset, auditRecord);
    } catch (e) {
      console.error('Save error:', e);
    } finally {
      setIsSaving(false);
    }
  };

  const handlePrintAuditForm = () => {
    triggerSuccessFeedback();
    const rowsHtml = asset.checklist_steps.map((step, idx) => {
      const res = checklistResults[step.id] || { status: 'pass', reading: 'مطابق' };
      const statusText = res.status === 'pass' ? '✅ ناجح Pass' : res.status === 'fail' ? '❌ راسب Fail' : 'غير منطبق N/A';
      return `
        <tr>
          <td style="text-align:center; font-weight:bold;">${idx + 1}</td>
          <td>${step.step_text}</td>
          <td style="text-align:center; font-weight:bold; color:${res.status === 'pass' ? '#16a34a' : '#dc2626'};">${statusText}</td>
          <td>${res.reading}</td>
        </tr>
      `;
    }).join('');

    const contentHtml = `
      <div style="direction:rtl; text-align:right;">
        <div style="background:#f8fafc; border:1.5px solid #cbd5e1; border-radius:10px; padding:12px; margin-bottom:14px;">
          <table style="width:100%; border:none; margin:0;">
            <tr style="border:none;">
              <td style="border:none; padding:4px;"><strong>كود الأصل:</strong> <span style="font-family:monospace; font-size:14px; color:#0f766e;">${asset.asset_tag}</span></td>
              <td style="border:none; padding:4px;"><strong>اسم المعدة:</strong> ${asset.name}</td>
              <td style="border:none; padding:4px;"><strong>القسم:</strong> ${asset.categoryNameAr}</td>
            </tr>
            <tr style="border:none;">
              <td style="border:none; padding:4px;"><strong>دورية الفحص:</strong> ${asset.frequency}</td>
              <td style="border:none; padding:4px;"><strong>الموقع:</strong> ${asset.location}</td>
              <td style="border:none; padding:4px;"><strong>تاريخ الفحص:</strong> ${todayStr}</td>
            </tr>
            <tr style="border:none;">
              <td style="border:none; padding:4px;"><strong>المهندس الفاحص:</strong> ${inspector}</td>
              <td style="border:none; padding:4px;"><strong>الرمز المشفر لمكافحة الغش:</strong> <span style="font-family:monospace; font-size:10px;">${scanProof?.integrityHash || 'LIVE-VERIFIED'}</span></td>
              <td style="border:none; padding:4px;"><strong>النتيجة العامة:</strong> ${overallOutcome === 'pass' ? 'المعدة تعمل بكفاءة وأمان تام ✅' : 'المعدة تحتاج صيانة علاجية ❌'}</td>
            </tr>
          </table>
        </div>

        <h3 style="font-size:14px; font-weight:bold; color:#0f172a; margin-bottom:8px;">خطوات الفحص الهندسية والفنية الدقيقة المطلوبة للمطابقة والمعايرة</h3>
        <table style="width:100%; border-collapse:collapse; margin-bottom:16px;">
          <thead>
            <tr style="background:#f1f5f9;">
              <th style="border:1px solid #cbd5e1; padding:6px; width:35px; text-align:center;">م</th>
              <th style="border:1px solid #cbd5e1; padding:6px;">خطوة الفحص والمعايرة</th>
              <th style="border:1px solid #cbd5e1; padding:6px; width:120px; text-align:center;">الحالة</th>
              <th style="border:1px solid #cbd5e1; padding:6px; width:180px;">القراءات المقاسة والملحوظات</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
          </tbody>
        </table>

        ${correctiveActions ? `
          <div style="background:#fef2f2; border:1px solid #f87171; border-radius:8px; padding:10px; margin-bottom:14px; color:#991b1b;">
            <strong>الملاحظات والإجراءات التصحيحية المطلوبة:</strong>
            <p style="margin:4px 0 0 0;">${correctiveActions}</p>
          </div>
        ` : ''}

        <div style="border-top:1.5px solid #0f766e; padding-top:12px; margin-top:20px; display:flex; justify-content:space-between; text-align:center;">
          <div style="width:45%; border:1px dashed #cbd5e1; padding:8px; border-radius:6px;">
            <div style="font-size:10px; color:#64748b;">توقيع وإيعاد الفني الفاحص</div>
            <div style="font-weight:bold; margin-top:4px;">${inspector}</div>
          </div>
          <div style="width:45%; border:1px dashed #cbd5e1; padding:8px; border-radius:6px;">
            <div style="font-size:10px; color:#64748b;">اعتماد مدير الإدارة الهندسية والسلامة</div>
            <div style="font-weight:bold; margin-top:4px;">م. نجيب غازي - مسؤول السلامة FMS</div>
          </div>
        </div>
      </div>
    `;

    executeSmartPrint(contentHtml, {
      title: `استمارة فحص وتشيك - ${asset.name} (${asset.asset_tag})`,
      subtitle: `خطة الصيانة الوقائية السنوية والتشغيلية • ${asset.categoryNameAr}`,
      refNumber: `AZAL-PPM-${asset.asset_tag}-${Date.now().toString().slice(-4)}`
    });
  };

  return (
    <div 
      id="ppm-inspection-audit-modal"
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 text-right overflow-y-auto"
    >
      <div className="bg-slate-900 border border-emerald-500/50 rounded-3xl w-full max-w-4xl overflow-hidden shadow-2xl flex flex-col max-h-[94vh] animate-in fade-in zoom-in-95">
        
        {/* Header */}
        <div className="bg-slate-950 p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <FileCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-white font-extrabold text-base sm:text-lg">
                  استمارة الفحص الدوري والمعايرة الوقائية (PPM)
                </h3>
                <span className="bg-slate-800 text-emerald-400 font-mono font-bold text-xs px-2.5 py-0.5 rounded-lg border border-slate-700">
                  {asset.asset_tag}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {asset.name} • {asset.categoryNameAr} • الدورية: {asset.frequency}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 p-2 rounded-xl transition-colors"
            title="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Scan Anti-Fraud Badge */}
        {scanProof && (
          <div className="bg-emerald-950/70 border-b border-emerald-500/30 px-4 py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs text-emerald-300">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span className="font-bold">تم التحقق المباشر بالمسح الحي لباركود الجهاز:</span>
              <span className="font-mono bg-black/40 px-2 py-0.5 rounded text-emerald-400 border border-emerald-500/30">
                {scanProof.formattedTime}
              </span>
            </div>
            <div className="flex items-center gap-1.5 font-mono text-[10px] text-emerald-400/80">
              <span>Hash:</span>
              <span>{scanProof.integrityHash}</span>
            </div>
          </div>
        )}

        {/* Form Body */}
        <form onSubmit={handleSaveAudit} className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          
          {/* Top Asset & Inspector Meta Card */}
          <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-4 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div>
              <span className="text-slate-400 block mb-1">اسم المهندس / الفاحص المسؤول:</span>
              <input
                type="text"
                value={inspector}
                onChange={(e) => setInspector(e.target.value)}
                required
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold focus:border-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <span className="text-slate-400 block mb-1">الموقع الفعلي للأصل:</span>
              <div className="bg-slate-900 border border-slate-700/60 rounded-xl px-3 py-2 text-slate-300 font-semibold truncate">
                {asset.location}
              </div>
            </div>

            <div>
              <span className="text-slate-400 block mb-1">تاريخ الصيانة القادمة التلقائي:</span>
              <div className="bg-slate-900 border border-slate-700/60 rounded-xl px-3 py-2 text-emerald-400 font-mono font-bold">
                {computeNextDueDate(todayStr, asset.frequency)} ({asset.frequency})
              </div>
            </div>
          </div>

          {/* Detailed Technical Steps Table (From Official Hospital Master Forms) */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="text-white font-extrabold text-sm flex items-center gap-2">
                <span>خطوات الفحص الهندسية والمعايرة الدقيقة</span>
                <span className="text-xs text-emerald-400 font-normal">
                  ({asset.checklist_steps.length} بنود مطابقة معتمدة)
                </span>
              </h4>

              <div className="flex items-center gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => {
                    const allPass: Record<number, { status: 'pass' | 'fail' | 'na'; reading: string }> = {};
                    asset.checklist_steps.forEach((step) => {
                      allPass[step.id] = { status: 'pass', reading: step.expected_value || 'مطابق' };
                    });
                    setChecklistResults(allPass);
                    setOverallOutcome('pass');
                  }}
                  className="text-emerald-400 hover:text-emerald-300 font-bold"
                >
                  تحديد الكل (ناجح Pass)
                </button>
              </div>
            </div>

            <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-950">
              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead className="bg-slate-900/90 text-slate-300 font-bold border-b border-slate-800">
                    <tr>
                      <th className="p-3 w-10 text-center">#</th>
                      <th className="p-3">بند الفحص والمعايرة الفنية</th>
                      <th className="p-3 w-48 text-center">الحالة</th>
                      <th className="p-3 w-48">القراءة / الملاحظة</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {asset.checklist_steps.map((step, idx) => {
                      const current = checklistResults[step.id] || { status: 'pass', reading: '' };
                      return (
                        <tr key={step.id} className="hover:bg-slate-900/40 transition-colors">
                          <td className="p-3 text-slate-500 font-mono text-center">{idx + 1}</td>
                          <td className="p-3 text-slate-200 font-semibold leading-relaxed">
                            {step.step_text}
                          </td>
                          <td className="p-3">
                            <div className="flex items-center justify-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800">
                              <button
                                type="button"
                                onClick={() => handleStepStatusChange(step.id, 'pass')}
                                className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-colors ${
                                  current.status === 'pass'
                                    ? 'bg-emerald-600 text-white shadow-xs'
                                    : 'text-slate-400 hover:text-white'
                                }`}
                              >
                                ناجح
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  handleStepStatusChange(step.id, 'fail');
                                  setOverallOutcome('fail');
                                }}
                                className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-colors ${
                                  current.status === 'fail'
                                    ? 'bg-rose-600 text-white shadow-xs'
                                    : 'text-slate-400 hover:text-white'
                                }`}
                              >
                                راسب
                              </button>
                              <button
                                type="button"
                                onClick={() => handleStepStatusChange(step.id, 'na')}
                                className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-colors ${
                                  current.status === 'na'
                                    ? 'bg-slate-700 text-white'
                                    : 'text-slate-400 hover:text-white'
                                }`}
                              >
                                N/A
                              </button>
                            </div>
                          </td>
                          <td className="p-3">
                            <input
                              type="text"
                              value={current.reading}
                              onChange={(e) => handleStepReadingChange(step.id, e.target.value)}
                              placeholder={step.expected_value || 'القراءة المقاسة'}
                              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-slate-200 text-xs focus:border-emerald-500 focus:outline-none"
                            />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Overall Outcome Selector */}
          <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-4 space-y-3 text-xs">
            <h4 className="text-white font-extrabold text-sm">النتيجة النهائية والاعتماد الفني:</h4>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label 
                className={`flex items-center gap-3 p-3.5 rounded-2xl border cursor-pointer transition-all ${
                  overallOutcome === 'pass'
                    ? 'bg-emerald-950/40 border-emerald-500 text-emerald-300 shadow-md shadow-emerald-950/30'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <input
                  type="radio"
                  name="overallOutcome"
                  checked={overallOutcome === 'pass'}
                  onChange={() => setOverallOutcome('pass')}
                  className="hidden"
                />
                <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                  overallOutcome === 'pass' ? 'border-emerald-400 bg-emerald-500 text-white' : 'border-slate-600'
                }`}>
                  {overallOutcome === 'pass' && <CheckCircle2 className="w-4 h-4" />}
                </div>
                <div>
                  <div className="font-extrabold text-white text-sm">المعدة تعمل بكفاءة وأمان تام ✅</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">مطابقة للمعايير القياسية وخطة الصيانة الوقائية</div>
                </div>
              </label>

              <label 
                className={`flex items-center gap-3 p-3.5 rounded-2xl border cursor-pointer transition-all ${
                  overallOutcome === 'fail'
                    ? 'bg-rose-950/40 border-rose-500 text-rose-300 shadow-md shadow-rose-950/30'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <input
                  type="radio"
                  name="overallOutcome"
                  checked={overallOutcome === 'fail'}
                  onChange={() => setOverallOutcome('fail')}
                  className="hidden"
                />
                <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                  overallOutcome === 'fail' ? 'border-rose-400 bg-rose-500 text-white' : 'border-slate-600'
                }`}>
                  {overallOutcome === 'fail' && <AlertTriangle className="w-4 h-4" />}
                </div>
                <div>
                  <div className="font-extrabold text-white text-sm">المعدة تحتاج صيانة علاجية وسحب فوري ❌</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">وجود خلل جسيم يستدعي الإيقاف وطلب قطع الغيار</div>
                </div>
              </label>
            </div>

            <div>
              <span className="text-slate-400 block mb-1 font-semibold">ملاحظات الفاحص والتوصيات التصحيحية:</span>
              <textarea
                value={correctiveActions}
                onChange={(e) => setCorrectiveActions(e.target.value)}
                placeholder="أدخل أي ملاحظات فنية، قطع الغيار المطلوبة، أو نتائج المعايرة التفصيلية..."
                rows={2}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 text-white text-xs focus:border-emerald-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Modal Action Buttons */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
            <button
              type="button"
              onClick={handlePrintAuditForm}
              className="bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 transition-colors"
            >
              <Printer className="w-4 h-4 text-emerald-400" />
              <span>معاينة وطباعة الاستمارة الرسمية</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl transition-colors"
              >
                إلغاء
              </button>

              <button
                type="submit"
                disabled={isSaving}
                className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs sm:text-sm font-bold px-6 py-2.5 rounded-xl shadow-lg shadow-emerald-900/30 flex items-center gap-2 transition-transform active:scale-95"
              >
                <Save className="w-4 h-4" />
                <span>{isSaving ? 'جاري الحفظ...' : 'اعتماد وتوثيق الفحص الفوري'}</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
