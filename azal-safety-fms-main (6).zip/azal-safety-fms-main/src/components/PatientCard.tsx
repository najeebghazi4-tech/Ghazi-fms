import React from 'react';
import { 
  AlertTriangle, 
  Activity, 
  Heart, 
  Thermometer, 
  Wind, 
  ShieldAlert, 
  CheckCircle2, 
  Clock, 
  FileText, 
  ChevronLeft,
  Syringe,
  AlertCircle
} from 'lucide-react';
import { ISBARData } from '../types';

interface PatientCardProps {
  patient: ISBARData;
  privacyMode: boolean;
  onSelectISBAR: (patient: ISBARData) => void;
  onQuickVitals: (patient: ISBARData) => void;
  onInitiateHandover: (patient: ISBARData) => void;
}

export const PatientCard: React.FC<PatientCardProps> = ({
  patient,
  privacyMode,
  onSelectISBAR,
  onQuickVitals,
  onInitiateHandover,
}) => {
  // Masking helpers for privacy (HIPAA / Patient Safety mode)
  const displayName = privacyMode
    ? patient.fullName.split(' ').map((w, i) => (i === 0 ? w[0] + '***' : w)).join(' ')
    : patient.fullName;

  const displayMRN = privacyMode
    ? patient.mrn.replace(/\d(?=\d{2})/g, '*')
    : patient.mrn;

  // Acuity styling
  const acuityConfig = {
    critical: {
      label: 'حالة حرجة (Acuity 1)',
      bg: 'bg-rose-950/70 text-rose-300 border-rose-800/80',
      dot: 'bg-rose-500 animate-ping',
      borderLeft: 'border-r-4 border-r-rose-500',
    },
    guard: {
      label: 'مراقبة لصيقة (Acuity 2)',
      bg: 'bg-amber-950/70 text-amber-300 border-amber-800/80',
      dot: 'bg-amber-400',
      borderLeft: 'border-r-4 border-r-amber-500',
    },
    stable: {
      label: 'مستقر سريرياً (Acuity 3)',
      bg: 'bg-emerald-950/70 text-emerald-300 border-emerald-800/80',
      dot: 'bg-emerald-400',
      borderLeft: 'border-r-4 border-r-emerald-500',
    },
  }[patient.acuity];

  const pendingCount = patient.pendingTasks.filter((t) => !t.isCompleted).length;

  return (
    <div
      id={`patient-card-${patient.patientId}`}
      className={`bg-slate-900/90 border border-slate-800 hover:border-slate-700/80 rounded-2xl p-3.5 transition-all shadow-md relative overflow-hidden ${acuityConfig.borderLeft}`}
    >
      {/* Top Row: Bed Badge & Acuity Badge */}
      <div className="flex items-center justify-between gap-2 mb-2">
        <div className="flex items-center gap-2">
          <span className="bg-teal-950 text-teal-300 border border-teal-800/80 px-2.5 py-0.5 rounded-lg text-xs font-mono font-bold">
            {patient.bedNumber}
          </span>
          <span className="text-[11px] text-slate-400 bg-slate-950 px-2 py-0.5 rounded-md border border-slate-800">
            {patient.department}
          </span>
        </div>

        <div className={`flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-semibold border ${acuityConfig.bg}`}>
          <span className={`w-2 h-2 rounded-full ${acuityConfig.dot}`} />
          <span>{acuityConfig.label}</span>
        </div>
      </div>

      {/* Patient Main Info */}
      <div className="flex items-start justify-between gap-2 mb-2">
        <div className="text-right flex-1">
          <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <span>{displayName}</span>
            <span className="text-[11px] font-normal text-slate-400 font-mono">
              ({patient.age} سنة • {patient.gender === 'male' ? 'ذكر' : 'أنثى'})
            </span>
          </h3>
          <div className="flex items-center gap-2 mt-0.5">
            <span className="text-xs font-mono text-teal-400 bg-teal-950/50 px-1.5 py-0.2 rounded border border-teal-900/60">
              {displayMRN}
            </span>
            <span className="text-[11px] text-slate-400 truncate">
              الطبيب: {patient.attendingPhysician}
            </span>
          </div>
        </div>
      </div>

      {/* Primary Diagnosis */}
      <div className="bg-slate-950/70 rounded-xl p-2 border border-slate-800/80 mb-2.5">
        <div className="text-[10px] text-slate-400 font-medium mb-0.5">التشخيص الحالي (Situation):</div>
        <div className="text-xs font-semibold text-slate-200 line-clamp-2">
          {patient.primaryDiagnosis}
        </div>
      </div>

      {/* Allergies Critical Tag (If any) */}
      {patient.allergies.length > 0 && (
        <div className="flex flex-wrap items-center gap-1 mb-2.5">
          <span className="flex items-center gap-1 bg-rose-950/90 text-rose-300 border border-rose-800/70 text-[10px] font-bold px-2 py-0.5 rounded-md">
            <AlertCircle className="w-3 h-3 text-rose-400" />
            <span>تحسس:</span>
          </span>
          {patient.allergies.map((allergy, i) => (
            <span
              key={i}
              className="text-[10px] bg-rose-950/40 text-rose-200 border border-rose-900/50 px-2 py-0.5 rounded-md truncate max-w-[200px]"
            >
              {allergy}
            </span>
          ))}
        </div>
      )}

      {/* Vitals Summary Strip */}
      <div className="grid grid-cols-4 gap-1.5 bg-slate-950/90 rounded-xl p-2 border border-slate-800/70 mb-2.5 text-center">
        {/* Blood Pressure */}
        <div className="flex flex-col items-center">
          <span className="text-[10px] text-slate-400 flex items-center gap-0.5">
            <Activity className="w-2.5 h-2.5 text-blue-400" />
            <span>BP</span>
          </span>
          <span className="text-xs font-mono font-bold text-slate-200">
            {patient.vitals.bpSystolic}/{patient.vitals.bpDiastolic}
          </span>
        </div>

        {/* Heart Rate */}
        <div className="flex flex-col items-center">
          <span className="text-[10px] text-slate-400 flex items-center gap-0.5">
            <Heart className="w-2.5 h-2.5 text-rose-400" />
            <span>HR</span>
          </span>
          <span className={`text-xs font-mono font-bold ${patient.vitals.heartRate > 100 || patient.vitals.heartRate < 60 ? 'text-amber-400' : 'text-slate-200'}`}>
            {patient.vitals.heartRate}
          </span>
        </div>

        {/* SpO2 */}
        <div className="flex flex-col items-center">
          <span className="text-[10px] text-slate-400 flex items-center gap-0.5">
            <Wind className="w-2.5 h-2.5 text-teal-400" />
            <span>SpO2</span>
          </span>
          <span className={`text-xs font-mono font-bold ${patient.vitals.oxygenSat < 95 ? 'text-rose-400' : 'text-slate-200'}`}>
            {patient.vitals.oxygenSat}%
          </span>
        </div>

        {/* Temp */}
        <div className="flex flex-col items-center">
          <span className="text-[10px] text-slate-400 flex items-center gap-0.5">
            <Thermometer className="w-2.5 h-2.5 text-amber-400" />
            <span>Temp</span>
          </span>
          <span className={`text-xs font-mono font-bold ${patient.vitals.temperature > 37.5 ? 'text-rose-400' : 'text-slate-200'}`}>
            {patient.vitals.temperature}°
          </span>
        </div>
      </div>

      {/* Footer Tags & Actions */}
      <div className="flex items-center justify-between pt-1 border-t border-slate-800/80 text-xs">
        {/* Left: Pending tasks & lines */}
        <div className="flex items-center gap-2 text-[11px] text-slate-400">
          {pendingCount > 0 ? (
            <span className="flex items-center gap-1 text-amber-400 font-medium">
              <Clock className="w-3 h-3" />
              <span>{pendingCount} مهام معلقة</span>
            </span>
          ) : (
            <span className="flex items-center gap-1 text-emerald-400">
              <CheckCircle2 className="w-3 h-3" />
              <span>المهام مكتملة</span>
            </span>
          )}

          {patient.invasiveLines.length > 0 && (
            <span className="flex items-center gap-1 text-slate-400">
              <Syringe className="w-3 h-3 text-teal-400" />
              <span>{patient.invasiveLines.length} قساطر/أنابيب</span>
            </span>
          )}
        </div>

        {/* Right: Quick Action Buttons */}
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={() => onQuickVitals(patient)}
            className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-medium transition"
          >
            العلامات
          </button>
          <button
            type="button"
            onClick={() => onSelectISBAR(patient)}
            className="flex items-center gap-1 px-3 py-1 rounded-lg bg-teal-600 hover:bg-teal-500 active:bg-teal-700 text-white text-[11px] font-bold shadow transition"
          >
            <span>ملف ISBAR</span>
            <ChevronLeft className="w-3 h-3" />
          </button>
        </div>
      </div>
    </div>
  );
};
