import React, { useState } from 'react';
import { 
  X, 
  ShieldAlert, 
  AlertTriangle, 
  BellRing, 
  Flame, 
  Activity, 
  Radio, 
  CheckCircle2, 
  MapPin, 
  Clock, 
  UserCheck 
} from 'lucide-react';
import { EmergencyCodeDefinition, ActiveEmergencyAlert, EmergencyCodeType, StaffUser } from '../types';
import { AZAL_EMERGENCY_CODES, AZAL_HOSPITAL_LOCATIONS } from '../data/azalSecurityData';
import { VoiceDictationButton } from './VoiceDictationButton';

interface EmergencyCodesModalProps {
  activeAlerts: ActiveEmergencyAlert[];
  currentUser: StaffUser;
  onClose: () => void;
  onActivateCode: (newAlert: ActiveEmergencyAlert) => void;
  onResolveAlert: (alertId: string, resolutionNotes: string) => void;
}

export const EmergencyCodesModal: React.FC<EmergencyCodesModalProps> = ({
  activeAlerts,
  currentUser,
  onClose,
  onActivateCode,
  onResolveAlert,
}) => {
  const [selectedCode, setSelectedCode] = useState<EmergencyCodeDefinition | null>(null);
  const [selectedLocation, setSelectedLocation] = useState(AZAL_HOSPITAL_LOCATIONS[0]);
  const [customNotes, setCustomNotes] = useState('');
  const [resolutionInput, setResolutionInput] = useState('');
  const [resolvingAlertId, setResolvingAlertId] = useState<string | null>(null);

  const activeAlertsList = activeAlerts.filter((a) => a.status === 'active');

  const handleConfirmActivation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCode) return;

    const newAlert: ActiveEmergencyAlert = {
      id: `alert-${Date.now()}`,
      codeType: selectedCode.type,
      activatedAt: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
      activatedBy: `${currentUser.name} (${currentUser.roleTitleAr})`,
      location: selectedLocation,
      notes: customNotes.trim() || selectedCode.actionProtocolAr,
      status: 'active',
    };

    onActivateCode(newAlert);
    setSelectedCode(null);
    setCustomNotes('');
  };

  const handleConfirmResolution = (alertId: string) => {
    onResolveAlert(alertId, resolutionInput.trim() || 'تم احتواء الطارئ والتأكد من سلامة الموقع.');
    setResolvingAlertId(null);
    setResolutionInput('');
  };

  return (
    <div id="emergency-codes-modal" className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 text-right overflow-y-auto">
      <div className="bg-slate-900 border border-rose-600/60 rounded-3xl w-full max-w-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-slate-950 px-5 py-3.5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-rose-950 border border-rose-800 text-rose-400">
              <ShieldAlert className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100">
                منظومة أكواد الطوارئ المعتمدة - مستشفى أزال النموذجي
              </h3>
              <p className="text-xs text-slate-400">
                إطلاق واستجابة سريعة لكافة حالات الطوارئ والحوادث داخل المنشأة
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-100 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 space-y-5 overflow-y-auto">
          {/* Active Alerts Banner Section */}
          {activeAlertsList.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-rose-400 flex items-center gap-1.5">
                <BellRing className="w-4 h-4 text-rose-500 animate-bounce" />
                <span>حالات الطوارئ النشطة حالياً في المستشفى ({activeAlertsList.length}):</span>
              </h4>

              <div className="space-y-2">
                {activeAlertsList.map((alert) => {
                  const def = AZAL_EMERGENCY_CODES.find((c) => c.type === alert.codeType);
                  return (
                    <div
                      key={alert.id}
                      className={`p-3.5 rounded-2xl border ${def?.borderClass || 'border-rose-700'} ${def?.bgClass || 'bg-rose-950'} flex flex-col sm:flex-row sm:items-center justify-between gap-3`}
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-black text-slate-100 bg-black/40 px-2.5 py-0.5 rounded-md font-mono">
                            {def?.nameAr}
                          </span>
                          <span className="text-xs text-slate-300 font-semibold">
                            {alert.location}
                          </span>
                        </div>
                        <p className="text-xs text-slate-200 leading-relaxed">
                          {alert.notes}
                        </p>
                        <div className="flex items-center gap-3 text-[11px] text-slate-400">
                          <span>وقت الإطلاق: {alert.activatedAt}</span>
                          <span>بواسطة: {alert.activatedBy}</span>
                        </div>
                      </div>

                      {/* Resolve Button */}
                      <div className="shrink-0">
                        {resolvingAlertId === alert.id ? (
                          <div className="space-y-2 p-2 bg-black/50 rounded-xl border border-white/20 text-xs">
                            <div className="flex items-center gap-1.5">
                              <input
                                type="text"
                                placeholder="ملاحظات إنهاء الطارئ (مثال: تم إخماد الدخان)..."
                                value={resolutionInput}
                                onChange={(e) => setResolutionInput(e.target.value)}
                                className="w-full bg-slate-900 border border-slate-700 rounded p-1.5 text-xs text-slate-100"
                              />
                              <VoiceDictationButton
                                value={resolutionInput}
                                onChange={setResolutionInput}
                                title="إملاء صوتي لملاحظة إنهاء الطارئ"
                              />
                            </div>
                            <div className="flex gap-2">
                              <button
                                type="button"
                                onClick={() => handleConfirmResolution(alert.id)}
                                className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded font-bold text-[11px]"
                              >
                                تأكيد الإنهاء
                              </button>
                              <button
                                type="button"
                                onClick={() => setResolvingAlertId(null)}
                                className="px-2 py-1 bg-slate-800 text-slate-300 rounded text-[11px]"
                              >
                                إلغاء
                              </button>
                            </div>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => setResolvingAlertId(alert.id)}
                            className="px-3.5 py-2 bg-slate-950/80 hover:bg-slate-900 border border-white/20 text-emerald-300 text-xs font-bold rounded-xl flex items-center gap-1.5 transition"
                          >
                            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                            <span>إنهاء الكود وتأمين الموقع</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Activation Trigger Form (إذا اختار كود معين) */}
          {selectedCode ? (
            <form onSubmit={handleConfirmActivation} className="bg-slate-950 p-4 rounded-2xl border border-teal-700/60 space-y-3 animate-fade-in text-xs">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="font-bold text-slate-100 flex items-center gap-1.5">
                  <span className={`w-3 h-3 rounded-full ${selectedCode.colorClass.replace('text-', 'bg-')}`} />
                  <span>تأكيد إطلاق: {selectedCode.nameAr}</span>
                </span>
                <button
                  type="button"
                  onClick={() => setSelectedCode(null)}
                  className="text-slate-400 hover:text-slate-200"
                >
                  إلغاء الاختيار
                </button>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 leading-relaxed text-[11px]">
                <strong>البروتوكول المعتمد:</strong> {selectedCode.actionProtocolAr}
              </div>

              <div>
                <label className="text-slate-300 block mb-1 font-semibold">تحديد موقع البلاغ داخل مستشفى أزال:</label>
                <select
                  value={selectedLocation}
                  onChange={(e) => setSelectedLocation(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-slate-100 text-xs"
                >
                  {AZAL_HOSPITAL_LOCATIONS.map((loc, i) => (
                    <option key={i} value={loc}>
                      {loc}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-slate-300 font-semibold">تفاصيل إضافية عن الحالة الطارئة:</label>
                  <VoiceDictationButton
                    value={customNotes}
                    onChange={setCustomNotes}
                    showLabel
                    title="إملاء صوتي لتفاصيل الحالة الطارئة"
                  />
                </div>
                <textarea
                  rows={2}
                  placeholder="مثال: تصاعد دخان خفيف من لوحة التوزيع، بدأ إخلاء الغرفة رقم 104... (يمكنك الإملاء بالصوت)"
                  value={customNotes}
                  onChange={(e) => setCustomNotes(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-slate-100 placeholder-slate-500 text-xs focus:outline-none focus:border-rose-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedCode(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs"
                >
                  تراجع
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-black text-xs shadow-lg shadow-rose-950 flex items-center gap-1.5 transition"
                >
                  <BellRing className="w-4 h-4 animate-bounce" />
                  <span>إطلاق صفارات وتنبيه الكود فوراً</span>
                </button>
              </div>
            </form>
          ) : (
            /* Emergency Codes Grid */
            <div className="space-y-3">
              <span className="text-xs font-bold text-slate-300 block">
                اختر كود الطوارئ المطلوب إعلانه في المستشفى:
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {AZAL_EMERGENCY_CODES.map((code) => (
                  <button
                    key={code.type}
                    type="button"
                    onClick={() => setSelectedCode(code)}
                    className={`p-3.5 rounded-2xl border text-right transition-all group flex flex-col justify-between hover:scale-[1.01] active:scale-[0.99] ${code.bgClass} ${code.borderClass}`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <span className={`text-xs font-black ${code.colorClass}`}>
                          {code.nameAr}
                        </span>
                        <span className="text-[10px] font-mono text-slate-400">
                          {code.nameEn}
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 leading-relaxed font-medium">
                        {code.meaningAr}
                      </p>
                    </div>

                    <div className="mt-2.5 pt-2 border-t border-white/10 flex items-center justify-between text-[11px] text-slate-400 group-hover:text-slate-200">
                      <span>اضغط لتفعيل الكود وتوجيه الفرق</span>
                      <span className="font-bold text-teal-400">إطلاق ◄</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-950 px-5 py-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>غرفة عمليات الأمن والسلامة • هاتف الطوارئ الداخلي: <strong>111 / 999</strong></span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
