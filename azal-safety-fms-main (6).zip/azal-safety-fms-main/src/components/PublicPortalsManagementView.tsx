import React, { useState } from 'react';
import { 
  HardHat, 
  Flame, 
  GraduationCap, 
  Award, 
  Search, 
  Filter, 
  QrCode, 
  Copy, 
  Check, 
  Printer, 
  Share2, 
  Eye, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  XCircle, 
  ExternalLink, 
  Phone, 
  Building2, 
  Calendar, 
  User, 
  Layers, 
  FileText, 
  ShieldCheck,
  Lock,
  Sparkles,
  RefreshCw,
  Megaphone
} from 'lucide-react';
import { ServicesHubPromoPosterModal } from './ServicesHubPromoPosterModal';
import { 
  ContractorPermitNotice, 
  IncineratorOperationNotice, 
  NewHiresTrainingNotice, 
  TrainingNominationNotice,
  StaffUser 
} from '../types';
import { AzalLogo } from './AzalLogo';
import { cleanYemeniPhoneNumber, getIncidentWhatsAppUrl, getPublicAppBaseUrl } from '../utils/phoneUtils';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';
import { printExistingElementById } from '../utils/printUtils';
import { 
  STANDARD_SAFETY_PRECAUTIONS, 
  buildPermitVerificationUrl, 
  getPermitWhatsAppShareText 
} from '../utils/permitUrlUtils';

export type PublicPortalTab = 'services' | 'contractor' | 'incinerator' | 'new_hires' | 'training_nomination';

interface PublicPortalsManagementViewProps {
  currentUser: StaffUser;
  contractorNotices: ContractorPermitNotice[];
  incineratorNotices: IncineratorOperationNotice[];
  newHiresNotices: NewHiresTrainingNotice[];
  trainingNominations: TrainingNominationNotice[];
  onUpdateContractorNotice: (updated: ContractorPermitNotice) => void;
  onUpdateIncineratorNotice: (updated: IncineratorOperationNotice) => void;
  onUpdateNewHiresNotice: (updated: NewHiresTrainingNotice) => void;
  onUpdateTrainingNomination: (updated: TrainingNominationNotice) => void;
  onLogAudit: (action: string, actionAr: string, details: string) => void;
}

export const PublicPortalsManagementView: React.FC<PublicPortalsManagementViewProps> = ({
  currentUser,
  contractorNotices,
  incineratorNotices,
  newHiresNotices,
  trainingNominations,
  onUpdateContractorNotice,
  onUpdateIncineratorNotice,
  onUpdateNewHiresNotice,
  onUpdateTrainingNomination,
  onLogAudit,
}) => {
  const [activeTab, setActiveTab] = useState<PublicPortalTab>('contractor');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [copiedLink, setCopiedLink] = useState(false);
  const [showBadgeModal, setShowBadgeModal] = useState<PublicPortalTab | null>(null);
  const [showServicesQrModal, setShowServicesQrModal] = useState<boolean>(false);
  const [showPromoPosterModal, setShowPromoPosterModal] = useState<boolean>(false);

  // Detail Modals
  const [selectedContractor, setSelectedContractor] = useState<ContractorPermitNotice | null>(null);
  const [selectedIncinerator, setSelectedIncinerator] = useState<IncineratorOperationNotice | null>(null);
  const [selectedNewHire, setSelectedNewHire] = useState<NewHiresTrainingNotice | null>(null);
  const [selectedNomination, setSelectedNomination] = useState<TrainingNominationNotice | null>(null);

  // Contractor Approval Workflow States (Eng. Najib Ghazi)
  const [approvingContractor, setApprovingContractor] = useState<ContractorPermitNotice | null>(null);
  const [approvalRef, setApprovalRef] = useState<string>('');
  const [workingHoursInput, setWorkingHoursInput] = useState<string>('08:00 صباحاً - 04:00 عصراً');
  const [selectedPrecautions, setSelectedPrecautions] = useState<string[]>([]);
  const [customPrecautionInput, setCustomPrecautionInput] = useState<string>('');
  const [safetyNotesInput, setSafetyNotesInput] = useState<string>('');
  const [gatePassAllowed, setGatePassAllowed] = useState<boolean>(true);

  // WhatsApp Share Modal State
  const [sharePermitModal, setSharePermitModal] = useState<ContractorPermitNotice | null>(null);
  const [shareSuccessCopied, setShareSuccessCopied] = useState<boolean>(false);

  // Status update notes
  const [adminNoteInput, setAdminNoteInput] = useState('');

  const getUnifiedServicesUrl = () => {
    if (typeof window !== 'undefined' && window.location.origin) {
      return `${window.location.origin}/#services`;
    }
    return `${getPublicAppBaseUrl()}/#services`;
  };

  const getOriginPortalUrl = (hash: string) => {
    if (typeof window !== 'undefined' && window.location.origin) {
      return `${window.location.origin}/${hash}`;
    }
    return `${getPublicAppBaseUrl()}/${hash}`;
  };

  const origin = getPublicAppBaseUrl();

  const PORTAL_CONFIG = {
    services: {
      id: 'services',
      title: 'بوابة الخدمات والتصاريح الموحدة',
      subTitle: 'المنصة الرقمية الشاملة لكافة تصاريح المقاولين والتدريب وإشعارات التشغيل',
      route: '#services',
      url: getUnifiedServicesUrl(),
      icon: Sparkles,
      color: 'teal',
      accentBg: 'bg-teal-600',
      badgeBg: 'bg-teal-950 text-teal-300 border-teal-800',
      count: contractorNotices.length + incineratorNotices.length + newHiresNotices.length + trainingNominations.length,
      pendingCount: contractorNotices.filter(n => n.status === 'pending_review').length
    },
    contractor: {
      id: 'contractor',
      title: 'إشعارات وتصاريح المقاولين',
      subTitle: 'بوابة دخول وتصاريح الأعمال الهندسية والصيانة الخارجية',
      route: '#contractor',
      url: getOriginPortalUrl('#contractor'),
      icon: HardHat,
      color: 'amber',
      accentBg: 'bg-amber-600',
      badgeBg: 'bg-amber-950 text-amber-300 border-amber-800',
      count: contractorNotices.length,
      pendingCount: contractorNotices.filter(n => n.status === 'pending_review').length
    },
    incinerator: {
      id: 'incinerator',
      title: 'تشغيل المحرقة والنفايات الطبية',
      subTitle: 'إشعارات حرق النفايات الحيوية وفحص جاهزية شبكة الإطفاء',
      route: '#incinerator-portal',
      url: getOriginPortalUrl('#incinerator-portal'),
      icon: Flame,
      color: 'rose',
      accentBg: 'bg-rose-600',
      badgeBg: 'bg-rose-950 text-rose-300 border-rose-800',
      count: incineratorNotices.length,
      pendingCount: incineratorNotices.filter(n => n.status === 'scheduled').length
    },
    new_hires: {
      id: 'new_hires',
      title: 'تدريب الجدد (الموارد البشرية HR)',
      subTitle: 'قوائم الموظفين الجدد المطلوب تأهيلهم على السلامة والأكواد',
      route: '#new-hires-portal',
      url: getOriginPortalUrl('#new-hires-portal'),
      icon: GraduationCap,
      color: 'blue',
      accentBg: 'bg-blue-600',
      badgeBg: 'bg-blue-950 text-blue-300 border-blue-800',
      count: newHiresNotices.length,
      pendingCount: newHiresNotices.filter(n => n.status === 'new_request').length
    },
    training_nomination: {
      id: 'training_nomination',
      title: 'ترشيحات الدورات التدريبية',
      subTitle: 'ترشيحات رؤساء الأقسام لكوادرهم في مكافحة الحريق والإنقاذ',
      route: '#training-nomination-portal',
      url: getOriginPortalUrl('#training-nomination-portal'),
      icon: Award,
      color: 'purple',
      accentBg: 'bg-purple-600',
      badgeBg: 'bg-purple-950 text-purple-300 border-purple-800',
      count: trainingNominations.length,
      pendingCount: trainingNominations.filter(n => n.status === 'received').length
    }
  };

  const currentConfig = PORTAL_CONFIG[activeTab];

  const handleCopyPortalLink = async (url: string) => {
    try {
      if (navigator?.clipboard?.writeText) {
        await navigator.clipboard.writeText(url);
      } else {
        const textarea = document.createElement('textarea');
        textarea.value = url;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
      }
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  // Open Direct WhatsApp with formatting
  const handleOpenWhatsAppDirect = (phone: string, text: string) => {
    const cleaned = cleanYemeniPhoneNumber(phone);
    const url = `https://wa.me/${cleaned}?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  // Open Approval Modal for Contractor Work Permit
  const handleStartApproval = (notice: ContractorPermitNotice) => {
    setApprovingContractor(notice);
    // Generate official approval reference (e.g. AZAL-PERMIT-2026-XXXX)
    const existingRef = notice.permitNumber;
    const genCode = Math.floor(1000 + Math.random() * 9000);
    setApprovalRef(existingRef || `AZAL-PERMIT-2026-${genCode}`);
    setWorkingHoursInput(notice.workingHours || '08:00 صباحاً - 04:00 عصراً');
    
    // Default or existing precautions
    const initialPrecautions =
      notice.approvalPrecautions && notice.approvalPrecautions.length > 0
        ? [...notice.approvalPrecautions]
        : notice.safetyMeasures && notice.safetyMeasures.length > 0
        ? [...notice.safetyMeasures]
        : STANDARD_SAFETY_PRECAUTIONS.slice(0, 5);

    setSelectedPrecautions(initialPrecautions);
    setCustomPrecautionInput('');
    setSafetyNotesInput(
      notice.safetyNotes ||
      `تم فحص وتدقيق طلب المقاول واعتماد التصريح الميداني بموجب الاشتراطات المحددة.`
    );
    setGatePassAllowed(notice.gatePassAllowed !== false);
  };

  const handleTogglePrecaution = (item: string) => {
    if (selectedPrecautions.includes(item)) {
      setSelectedPrecautions(selectedPrecautions.filter((p) => p !== item));
    } else {
      setSelectedPrecautions([...selectedPrecautions, item]);
    }
  };

  const handleAddCustomPrecaution = () => {
    if (!customPrecautionInput.trim()) return;
    if (!selectedPrecautions.includes(customPrecautionInput.trim())) {
      setSelectedPrecautions([...selectedPrecautions, customPrecautionInput.trim()]);
    }
    setCustomPrecautionInput('');
  };

  const handleConfirmApproval = () => {
    if (!approvingContractor) return;

    const now = new Date();
    const dateStr = `${now.toLocaleDateString('ar-YE')} ${now.toLocaleTimeString('ar-YE', { hour: '2-digit', minute: '2-digit' })}`;

    const updated: ContractorPermitNotice = {
      ...approvingContractor,
      status: 'approved',
      permitNumber: approvalRef || `AZAL-PERMIT-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      approvedAt: dateStr,
      approvedBy: 'رئيس قسم الأمن والسلامة / م. نجيب غازي',
      approvalPrecautions: selectedPrecautions,
      workingHours: workingHoursInput,
      gatePassAllowed: gatePassAllowed,
      safetyNotes: safetyNotesInput,
    };

    onUpdateContractorNotice(updated);
    onLogAudit(
      'CONTRACTOR_PERMIT_APPROVED',
      'اعتماد تصريح مقاول',
      `تم اعتماد تصريح المقاول (${updated.contractorName}) برقم رسمي ${updated.permitNumber}`
    );

    const savedNotice = updated;
    setApprovingContractor(null);
    if (selectedContractor && selectedContractor.id === updated.id) {
      setSelectedContractor(updated);
    }

    // Immediately trigger WhatsApp Share Modal for rapid dispatch
    setSharePermitModal(savedNotice);
  };

  const handleOpenPermitVerification = (notice: ContractorPermitNotice) => {
    const url = buildPermitVerificationUrl(notice);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleShareWhatsAppPermit = (notice: ContractorPermitNotice, targetPhone?: string) => {
    const permitUrl = buildPermitVerificationUrl(notice);
    const message = getPermitWhatsAppShareText(notice, permitUrl);
    const cleaned = targetPhone ? cleanYemeniPhoneNumber(targetPhone) : '';
    const url = cleaned
      ? `https://wa.me/${cleaned}?text=${encodeURIComponent(message)}`
      : `https://wa.me/?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleCopyPermitLink = async (notice: ContractorPermitNotice) => {
    const permitUrl = buildPermitVerificationUrl(notice);
    try {
      if (navigator?.clipboard?.writeText) {
        await navigator.clipboard.writeText(permitUrl);
      } else {
        const textarea = document.createElement('textarea');
        textarea.value = permitUrl;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
      }
      setShareSuccessCopied(true);
      setTimeout(() => setShareSuccessCopied(false), 2500);
    } catch {
      setShareSuccessCopied(true);
      setTimeout(() => setShareSuccessCopied(false), 2500);
    }
  };

  // 1. Filtered Contractor Notices
  const filteredContractors = contractorNotices.filter((n) => {
    const matchesSearch = 
      n.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      n.contractorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      n.department.toLowerCase().includes(searchTerm.toLowerCase()) ||
      n.workDescription.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || n.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // 2. Filtered Incinerator Notices
  const filteredIncinerators = incineratorNotices.filter((n) => {
    const matchesSearch = 
      n.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      n.supervisorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (n.notes && n.notes.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesStatus = statusFilter === 'all' || n.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // 3. Filtered New Hires Notices
  const filteredNewHires = newHiresNotices.filter((n) => {
    const matchesSearch = 
      n.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      n.hrOfficerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      n.hires.some(h => h.fullName.toLowerCase().includes(searchTerm.toLowerCase()) || h.department.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesStatus = statusFilter === 'all' || n.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // 4. Filtered Nominations
  const filteredNominations = trainingNominations.filter((n) => {
    const matchesSearch = 
      n.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      n.requestingDepartment.toLowerCase().includes(searchTerm.toLowerCase()) ||
      n.supervisorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      n.trainingProgramTitleAr.toLowerCase().includes(searchTerm.toLowerCase()) ||
      n.nominees.some(nm => nm.fullName.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesStatus = statusFilter === 'all' || n.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div id="public-portals-management-hub" className="space-y-4 text-right">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-teal-950 border border-teal-800/50 rounded-2xl p-4 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-white rounded-2xl shadow-sm border border-slate-200">
            <AzalLogo size="md" showText={false} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-slate-100">
                إدارة البوابات والخدمات العامة (Zero-Auth Portals)
              </h2>
              <span className="text-[10px] bg-teal-950 text-teal-300 border border-teal-800 px-2 py-0.5 rounded font-bold">
                إشراف: م/ نجيب غازي
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              استقبال ومعالجة طلبات المقاولين، إشعارات المحرقة، تدريب الموظفين الجدد، وترشيحات الدورات الميدانية
            </p>
          </div>
        </div>

        {/* Action Buttons for Current Active Tab & Unified Services Hub */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={() => setShowPromoPosterModal(true)}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 via-amber-600 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 text-xs font-black flex items-center gap-1.5 transition shadow-md shadow-amber-950 cursor-pointer active:scale-95 ring-1 ring-amber-300/60"
            title="توليد وتصميم بوستر إعلاني رسمي للبوابة A4 بهوية كحلية وذهبية فاخرة"
          >
            <Megaphone className="w-4 h-4 text-slate-950" />
            <span>📢 توليد بوستر إعلان البوابة</span>
          </button>

          <button
            type="button"
            onClick={() => setShowServicesQrModal(true)}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 transition shadow-md shadow-teal-950 cursor-pointer active:scale-95"
            title="عرض وتوليد رمز QR لبوابة الخدمات والتصاريح الموحدة (#services)"
          >
            <QrCode className="w-4 h-4 text-amber-300" />
            <span>رمز QR البوابة الموحدة (#services)</span>
          </button>

          <button
            type="button"
            onClick={() => handleCopyPortalLink(getUnifiedServicesUrl())}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer active:scale-95"
            title="نسخ رابط بوابة الخدمات والتصاريح الموحدة"
          >
            {copiedLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-teal-400" />}
            <span>{copiedLink ? 'تم نسخ رابط #services' : 'نسخ رابط البوابة الموحدة'}</span>
          </button>

          <a
            href={getUnifiedServicesUrl()}
            onClick={(e) => {
              // Smooth in-app navigation when left-clicked without modifier keys
              if (!e.ctrlKey && !e.metaKey && !e.shiftKey) {
                e.preventDefault();
                window.location.hash = '#services';
              }
            }}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 border border-teal-800/80 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
            title="فتح ومعاينة بوابة الخدمات والتصاريح الموحدة"
          >
            <ExternalLink className="w-4 h-4" />
            <span>معاينة البوابة الموحدة</span>
          </a>

          <button
            type="button"
            onClick={() => setShowBadgeModal(activeTab)}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
            title="طباعة بطاقة ورمز QR للقسم الحالي"
          >
            <Printer className="w-4 h-4 text-slate-400" />
            <span>بطاقة القسم الحالي</span>
          </button>
        </div>
      </div>

      {/* 4 Main Tabs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
        {(['contractor', 'incinerator', 'new_hires', 'training_nomination'] as PublicPortalTab[]).map((tabKey) => {
          const cfg = PORTAL_CONFIG[tabKey];
          const Icon = cfg.icon;
          const isSelected = activeTab === tabKey;
          return (
            <button
              key={tabKey}
              type="button"
              onClick={() => {
                setActiveTab(tabKey);
                setStatusFilter('all');
                setSearchTerm('');
              }}
              className={`p-3.5 rounded-2xl border text-right transition flex flex-col justify-between gap-3 relative overflow-hidden ${
                isSelected 
                  ? 'bg-slate-900 border-teal-500 shadow-lg ring-1 ring-teal-500/50' 
                  : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 text-slate-400'
              }`}
            >
              {isSelected && (
                <div className="absolute top-0 right-0 left-0 h-1 bg-gradient-to-r from-teal-500 to-emerald-400" />
              )}

              <div className="flex items-start justify-between">
                <div className={`p-2 rounded-xl ${isSelected ? 'bg-slate-800 text-teal-400' : 'bg-slate-950 text-slate-500'}`}>
                  <Icon className="w-5 h-5" />
                </div>
                {cfg.pendingCount > 0 && (
                  <span className="bg-rose-500 text-white font-mono text-[11px] font-bold px-2 py-0.5 rounded-full shadow-sm animate-pulse">
                    {cfg.pendingCount} جديد
                  </span>
                )}
              </div>

              <div>
                <h3 className={`font-bold text-xs ${isSelected ? 'text-slate-100' : 'text-slate-300'}`}>
                  {cfg.title}
                </h3>
                <span className="text-[11px] text-slate-500 font-mono mt-0.5 block">
                  إجمالي المسجل: {cfg.count} إشعار
                </span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900 border border-slate-800 p-3 rounded-2xl flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 text-xs">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-500 absolute right-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={`بحث في سجل ${currentConfig.title} (بالرقم، الاسم، القسم)...`}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-9 pl-3 py-2 text-slate-200 text-xs focus:outline-none focus:border-teal-500"
          />
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <Filter className="w-4 h-4 text-slate-500 shrink-0" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 text-xs focus:outline-none focus:border-teal-500"
          >
            <option value="all">جميع الحالات</option>
            {activeTab === 'contractor' && (
              <>
                <option value="pending_review">قيد المراجعة والتدقيق</option>
                <option value="approved">معتمد ومصرح</option>
                <option value="active_work">جاري العمل بالموقع</option>
                <option value="completed">مكتمل ومغلق</option>
              </>
            )}
            {activeTab === 'incinerator' && (
              <>
                <option value="scheduled">مجدول للتشغيل</option>
                <option value="burning_in_progress">جاري الحرق الآن</option>
                <option value="completed">مكتمل بنجاح</option>
              </>
            )}
            {activeTab === 'new_hires' && (
              <>
                <option value="new_request">طلب جديد (HR)</option>
                <option value="induction_scheduled">مجدول بالدورة</option>
                <option value="completed">تم التدريب بنجاح</option>
              </>
            )}
            {activeTab === 'training_nomination' && (
              <>
                <option value="received">مستلم من القسم</option>
                <option value="enrolled">مدرج بالبرنامج</option>
                <option value="completed">تم إنهاء الدورة</option>
              </>
            )}
          </select>
        </div>
      </div>

      {/* Main Tab Content */}
      <div className="space-y-3">
        {/* 1. CONTRACTOR NOTICES TAB */}
        {activeTab === 'contractor' && (
          <div className="space-y-3">
            {filteredContractors.length === 0 ? (
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center text-slate-400">
                <HardHat className="w-10 h-10 text-slate-600 mx-auto mb-2" />
                <p className="font-bold text-sm text-slate-300">لا توجد تصاريح مقاولين مطابقة للبحث</p>
                <p className="text-xs text-slate-500 mt-1">يمكنك مشاركة رابط البوابة مع المقاولين لتسجيل تصاريحهم إلكترونياً.</p>
              </div>
            ) : (
              filteredContractors.map((notice) => (
                <div 
                  key={notice.id}
                  className="bg-slate-900 border border-slate-800 rounded-2xl p-4 hover:border-amber-500/50 transition space-y-3 shadow-md"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                    <div className="flex items-center gap-2.5">
                      <span className="p-2 bg-amber-950 text-amber-400 border border-amber-800 rounded-xl">
                        <HardHat className="w-4 h-4" />
                      </span>
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <strong className="font-mono text-xs text-amber-400">{notice.id}</strong>
                          {notice.status === 'approved' ? (
                            <div className="flex items-center gap-1.5">
                              <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800 flex items-center gap-1">
                                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                                <span>معتمد ومصرح بالعمل</span>
                              </span>
                              {notice.permitNumber && (
                                <span className="font-mono text-[10px] font-black text-emerald-300 bg-emerald-950/80 px-2 py-0.5 rounded-md border border-emerald-800/80">
                                  {notice.permitNumber}
                                </span>
                              )}
                            </div>
                          ) : notice.status === 'pending_review' ? (
                            <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-amber-950 text-amber-300 border border-amber-800 flex items-center gap-1.5">
                              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
                              <span>قيد المراجعة والاعتماد</span>
                            </span>
                          ) : notice.status === 'active_work' ? (
                            <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-blue-950 text-blue-300 border border-blue-800">
                              جاري العمل الميداني
                            </span>
                          ) : (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
                              مكتمل
                            </span>
                          )}
                        </div>
                        <h4 className="text-sm font-bold text-slate-100 mt-0.5">{notice.contractorName}</h4>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 text-xs">
                      <span className="text-slate-400">{notice.createdAt}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                    <div>
                      <span className="text-slate-400 block mb-0.5">القسم المعني:</span>
                      <strong className="text-slate-200">{notice.department}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block mb-0.5">عدد العمال:</span>
                      <strong className="text-slate-200">{notice.workersCount} عمال</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block mb-0.5">هاتف المقاول:</span>
                      <span className="font-mono text-slate-300" dir="ltr">{notice.contactPhone}</span>
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 bg-slate-950/80 p-3 rounded-xl border border-slate-800/80">
                    <span className="text-slate-400 font-bold ml-1">تفاصيل العمل:</span>
                    {notice.workDescription}
                  </p>

                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-800/60">
                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setSelectedContractor(notice)}
                        className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition"
                      >
                        <Eye className="w-3.5 h-3.5 text-amber-400" />
                        <span>عرض التفاصيل</span>
                      </button>

                      {notice.status === 'approved' ? (
                        <>
                          <button
                            type="button"
                            onClick={() => handleOpenPermitVerification(notice)}
                            className="px-3 py-1.5 rounded-xl bg-slate-950 hover:bg-slate-800 text-emerald-400 border border-emerald-800 text-xs font-bold flex items-center gap-1.5 transition"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                            <span>معاينة التصريح (#permit)</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => setSharePermitModal(notice)}
                            className="px-3 py-1.5 rounded-xl bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 text-xs font-bold flex items-center gap-1.5 transition shadow-sm"
                          >
                            <Share2 className="w-3.5 h-3.5 text-emerald-400" />
                            <span>مشاركة تصريح الدخول عبر واتساب</span>
                          </button>
                        </>
                      ) : (
                        <button
                          type="button"
                          onClick={() => {
                            const text = `مرحباً ${notice.contractorName}، بخصوص طلب تصريح العمل رقم ${notice.id} بمستشفى آزال النموذجي: جاري تدقيق الطلب من قبل إدارة الأمن والسلامة.`;
                            handleOpenWhatsAppDirect(notice.contactPhone, text);
                          }}
                          className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold flex items-center gap-1.5 transition"
                        >
                          <Phone className="w-3.5 h-3.5 text-slate-400" />
                          <span>تواصل سريع</span>
                        </button>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleStartApproval(notice)}
                        className={`px-3.5 py-1.5 rounded-xl text-white text-xs font-bold flex items-center gap-1.5 transition shadow-sm ${
                          notice.status === 'approved'
                            ? 'bg-slate-800 hover:bg-slate-700 text-slate-300'
                            : 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-950/60'
                        }`}
                      >
                        <ShieldCheck className="w-4 h-4 text-emerald-300" />
                        <span>{notice.status === 'approved' ? 'تعديل الشروط والاعتماد' : 'اعتماد وإصدار التصريح'}</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* 2. INCINERATOR NOTICES TAB */}
        {activeTab === 'incinerator' && (
          <div className="space-y-3">
            {filteredIncinerators.length === 0 ? (
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center text-slate-400">
                <Flame className="w-10 h-10 text-slate-600 mx-auto mb-2" />
                <p className="font-bold text-sm text-slate-300">لا توجد إشعارات تشغيل محرقة مطابقة</p>
              </div>
            ) : (
              filteredIncinerators.map((notice) => (
                <div 
                  key={notice.id}
                  className="bg-slate-900 border border-slate-800 rounded-2xl p-4 hover:border-rose-500/50 transition space-y-3 shadow-md"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                    <div className="flex items-center gap-2.5">
                      <span className="p-2 bg-rose-950 text-rose-400 border border-rose-800 rounded-xl">
                        <Flame className="w-4 h-4" />
                      </span>
                      <div>
                        <div className="flex items-center gap-2">
                          <strong className="font-mono text-xs text-rose-400">{notice.id}</strong>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            notice.status === 'completed' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' :
                            notice.status === 'burning_in_progress' ? 'bg-amber-950 text-amber-300 border border-amber-800 animate-pulse' :
                            'bg-blue-950 text-blue-300 border border-blue-800'
                          }`}>
                            {notice.status === 'completed' ? 'مكتمل ومغلق' :
                             notice.status === 'burning_in_progress' ? 'جاري الحرق الآن' : 'مجدول'}
                          </span>
                        </div>
                        <h4 className="text-sm font-bold text-slate-100 mt-0.5">مشرف التشغيل: {notice.supervisorName}</h4>
                      </div>
                    </div>

                    <div className="text-xs text-slate-400">
                      {notice.createdAt}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                    <div>
                      <span className="text-slate-400 block mb-0.5">وزن النفايات المجهزة:</span>
                      <strong className="text-emerald-400 font-mono text-sm">{notice.wasteWeightKg} كجم</strong>
                      {notice.bagsCount && <span className="text-slate-400 text-[11px] block">({notice.bagsCount} كيس)</span>}
                    </div>
                    <div>
                      <span className="text-slate-400 block mb-0.5">موعد التشغيل المقرر:</span>
                      <strong className="text-slate-200 font-mono">{notice.operationDateTime.replace('T', ' ')}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block mb-0.5">جاهزية الإطفاء والسلامة:</span>
                      <span className="text-emerald-400 font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>تم الإقرار والفحص</span>
                      </span>
                    </div>
                  </div>

                  {notice.notes && (
                    <p className="text-xs text-slate-300 bg-slate-950/80 p-3 rounded-xl border border-slate-800/80">
                      {notice.notes}
                    </p>
                  )}

                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-800/60">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setSelectedIncinerator(notice)}
                        className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition"
                      >
                        <Eye className="w-3.5 h-3.5 text-rose-400" />
                        <span>تفاصيل الفحص</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          const text = `مرحباً ${notice.supervisorName}، بخصوص إشعار تشغيل المحرقة رقم ${notice.id} (${notice.wasteWeightKg} كجم): يرجى التأكد من ضغط شبكة مياه الإطفاء قبل فتح الشحنة.`;
                          handleOpenWhatsAppDirect(notice.supervisorPhone, text);
                        }}
                        className="px-3 py-1.5 rounded-xl bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 text-xs font-bold flex items-center gap-1.5 transition"
                      >
                        <Share2 className="w-3.5 h-3.5 text-emerald-400" />
                        <span>واتساب للمشرف</span>
                      </button>
                    </div>

                    {notice.status === 'scheduled' && (
                      <button
                        type="button"
                        onClick={() => {
                          const updated: IncineratorOperationNotice = {
                            ...notice,
                            status: 'completed',
                            safetyNotes: `تم الإشراف الميداني والتأكد من إتمام الحرق الآمن بنجاح بواسطة م/ نجيب غازي.`
                          };
                          onUpdateIncineratorNotice(updated);
                          onLogAudit('INCINERATOR_NOTICE_COMPLETED', 'إتمام تشغيل المحرقة', `تم إغلاق إشعار تشغيل المحرقة ${notice.id}`);
                        }}
                        className="px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold flex items-center gap-1 transition"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>تأكيد الإشراف والإتمام</span>
                      </button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* 3. NEW HIRES TAB */}
        {activeTab === 'new_hires' && (
          <div className="space-y-3">
            {filteredNewHires.length === 0 ? (
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center text-slate-400">
                <GraduationCap className="w-10 h-10 text-slate-600 mx-auto mb-2" />
                <p className="font-bold text-sm text-slate-300">لا توجد إشعارات موظفين جدد مطابقة</p>
              </div>
            ) : (
              filteredNewHires.map((notice) => (
                <div 
                  key={notice.id}
                  className="bg-slate-900 border border-slate-800 rounded-2xl p-4 hover:border-blue-500/50 transition space-y-3 shadow-md"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                    <div className="flex items-center gap-2.5">
                      <span className="p-2 bg-blue-950 text-blue-400 border border-blue-800 rounded-xl">
                        <GraduationCap className="w-4 h-4" />
                      </span>
                      <div>
                        <div className="flex items-center gap-2">
                          <strong className="font-mono text-xs text-blue-400">{notice.id}</strong>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            notice.priority === 'urgent' ? 'bg-rose-950 text-rose-300 border border-rose-800' : 'bg-slate-800 text-slate-300'
                          }`}>
                            {notice.priority === 'urgent' ? 'عاجل جداً' : 'اعتيادي'}
                          </span>
                        </div>
                        <h4 className="text-sm font-bold text-slate-100 mt-0.5">مسؤول الموارد البشرية: {notice.hrOfficerName}</h4>
                      </div>
                    </div>

                    <div className="text-xs text-slate-400">
                      تاريخ المباشرة: {notice.startDate}
                    </div>
                  </div>

                  {/* Employees preview list */}
                  <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800">
                    <span className="text-xs font-bold text-blue-300 mb-2 block">
                      الكوادر الجدد المطلوب تدريبهم ({notice.hires.length}):
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                      {notice.hires.map((h) => (
                        <div key={h.id} className="p-2 bg-slate-900/90 rounded-lg border border-slate-800 flex items-center justify-between">
                          <div>
                            <strong className="text-slate-100 block">{h.fullName}</strong>
                            <span className="text-[11px] text-slate-400">{h.jobTitle} - {h.department}</span>
                          </div>
                          {h.phone && <span className="font-mono text-[10px] text-slate-400" dir="ltr">{h.phone}</span>}
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-800/60">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setSelectedNewHire(notice)}
                        className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition"
                      >
                        <Eye className="w-3.5 h-3.5 text-blue-400" />
                        <span>جدولة الدورة التدريبية</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          const text = `مرحباً أستاذ ${notice.hrOfficerName}، بخصوص إشعار الموظفين الجدد رقم ${notice.id} (${notice.hires.length} موظف): تم استلام البيانات وسيتم التنسيق لبرنامج السلامة المعتمد.`;
                          handleOpenWhatsAppDirect(notice.hrOfficerPhone, text);
                        }}
                        className="px-3 py-1.5 rounded-xl bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 text-xs font-bold flex items-center gap-1.5 transition"
                      >
                        <Share2 className="w-3.5 h-3.5 text-emerald-400" />
                        <span>واتساب لمسؤول HR</span>
                      </button>
                    </div>

                    {notice.status === 'new_request' && (
                      <button
                        type="button"
                        onClick={() => {
                          const updated: NewHiresTrainingNotice = {
                            ...notice,
                            status: 'completed',
                            safetyNotes: `تم إتمام الدورة التدريبية بنجاح وتسليم بطاقات السلامة لجميع الكوادر الجدد.`
                          };
                          onUpdateNewHiresNotice(updated);
                          onLogAudit('NEW_HIRES_TRAINED', 'إتمام تدريب موظفين جدد', `تم تدريب ${notice.hires.length} موظف جديد بإشعار ${notice.id}`);
                        }}
                        className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1 transition"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>اعتماد إنجاز التدريب</span>
                      </button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* 4. TRAINING NOMINATIONS TAB */}
        {activeTab === 'training_nomination' && (
          <div className="space-y-3">
            {filteredNominations.length === 0 ? (
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center text-slate-400">
                <Award className="w-10 h-10 text-slate-600 mx-auto mb-2" />
                <p className="font-bold text-sm text-slate-300">لا توجد ترشيحات دورات مطابقة</p>
              </div>
            ) : (
              filteredNominations.map((notice) => (
                <div 
                  key={notice.id}
                  className="bg-slate-900 border border-slate-800 rounded-2xl p-4 hover:border-purple-500/50 transition space-y-3 shadow-md"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                    <div className="flex items-center gap-2.5">
                      <span className="p-2 bg-purple-950 text-purple-400 border border-purple-800 rounded-xl">
                        <Award className="w-4 h-4" />
                      </span>
                      <div>
                        <div className="flex items-center gap-2">
                          <strong className="font-mono text-xs text-purple-400">{notice.id}</strong>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            notice.status === 'enrolled' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' :
                            notice.status === 'completed' ? 'bg-blue-950 text-blue-300 border border-blue-800' :
                            'bg-purple-950 text-purple-300 border border-purple-800'
                          }`}>
                            {notice.status === 'enrolled' ? 'مدرج بالخطة' :
                             notice.status === 'completed' ? 'تمت الدورة' : 'طلب ترشيح مستلم'}
                          </span>
                        </div>
                        <h4 className="text-sm font-bold text-slate-100 mt-0.5">{notice.trainingProgramTitleAr}</h4>
                      </div>
                    </div>

                    <div className="text-xs text-slate-400">
                      القسم: <strong className="text-slate-200">{notice.requestingDepartment}</strong>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                    <div>
                      <span className="text-slate-400 block mb-0.5">المشرف المرشح:</span>
                      <strong className="text-slate-200">{notice.supervisorName}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block mb-0.5">عدد الكوادر المرشحة:</span>
                      <strong className="text-purple-300 font-mono">{notice.nominees.length} كادر</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block mb-0.5">الموعد والوردية المقترحة:</span>
                      <span className="text-slate-300 font-mono">{notice.proposedDate} ({notice.proposedShift === 'morning' ? 'صباحي' : notice.proposedShift === 'evening' ? 'مسائي' : 'ليلي'})</span>
                    </div>
                  </div>

                  {notice.justification && (
                    <p className="text-xs text-slate-300 bg-slate-950/80 p-3 rounded-xl border border-slate-800/80">
                      <span className="text-slate-400 font-bold ml-1">مبررات الترشيح:</span>
                      {notice.justification}
                    </p>
                  )}

                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-800/60">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setSelectedNomination(notice)}
                        className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition"
                      >
                        <Eye className="w-3.5 h-3.5 text-purple-400" />
                        <span>قائمة المرشحين</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          const text = `مرحباً ${notice.supervisorName}، بخصوص ترشيح كوادر قسم ${notice.requestingDepartment} للدورة التدريبية (${notice.trainingProgramTitleAr}): تم إدراج طلبكم تحت رقم ${notice.id} وسنبلغكم بتأكيد الموعد والقاعة.`;
                          handleOpenWhatsAppDirect(notice.supervisorPhone, text);
                        }}
                        className="px-3 py-1.5 rounded-xl bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 text-xs font-bold flex items-center gap-1.5 transition"
                      >
                        <Share2 className="w-3.5 h-3.5 text-emerald-400" />
                        <span>واتساب لرئيس القسم</span>
                      </button>
                    </div>

                    {notice.status === 'received' && (
                      <button
                        type="button"
                        onClick={() => {
                          const updated: TrainingNominationNotice = {
                            ...notice,
                            status: 'enrolled',
                            safetyNotes: `تم اعتماد وقيد المرشحين بالدورة الميدانية بواسطة م/ نجيب غازي.`
                          };
                          onUpdateTrainingNomination(updated);
                          onLogAudit('NOMINATION_ENROLLED', 'اعتماد ترشيح دورة', `تم اعتماد ترشيح كوادر ${notice.requestingDepartment}`);
                        }}
                        className="px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold flex items-center gap-1 transition"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>اعتماد وقيد المرشحين</span>
                      </button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>

      {/* UNIFIED SERVICES HUB (#services) QR & LINK MODAL */}
      {showServicesQrModal && (
        <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-teal-600/50 rounded-3xl max-w-md w-full p-6 text-center space-y-4 shadow-2xl relative">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="font-bold text-sm text-teal-300 flex items-center gap-2">
                <QrCode className="w-5 h-5 text-amber-400" />
                <span>رمز QR ورابط بوابة الخدمات والتصاريح الموحدة</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowServicesQrModal(false)}
                className="text-slate-400 hover:text-slate-200 text-base"
              >
                ✕
              </button>
            </div>

            {/* Printable Badge Card Area */}
            <div id="printable-services-badge-card" className="bg-white text-slate-950 p-6 rounded-2xl shadow-xl border-4 border-teal-800 text-center space-y-3">
              <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                <div className="text-right">
                  <h3 className="font-black text-xs text-slate-900">مستشفى آزال النموذجي</h3>
                  <span className="text-[10px] text-teal-800 font-bold block">إدارة السلامة والصحة المهنية FMS</span>
                </div>
                <AzalLogo size="sm" showText={false} />
              </div>

              <div className="py-1">
                <span className="text-[10px] font-bold text-teal-700 bg-teal-50 px-2 py-0.5 rounded-full inline-block mb-1">
                  البوابة الرقمية الشاملة المباشرة (Zero-Auth)
                </span>
                <h2 className="font-black text-base text-slate-900">
                  بوابة الخدمات والتصاريح الموحدة
                </h2>
                <p className="text-[11px] text-slate-600 mt-1">
                  امسح الرمز بكاميرا الجوال للوصول الفوري لكافة تصاريح المقاولين، إشعارات المحرقة، وبرامج التدريب
                </p>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-2xl inline-block border-2 border-teal-200 shadow-inner">
                <img
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=240x240&margin=2&data=${encodeURIComponent(getUnifiedServicesUrl())}`}
                  alt="Unified Services Hub QR Code"
                  referrerPolicy="no-referrer"
                  className="w-44 h-44 object-contain mx-auto"
                />
              </div>

              {/* Target URL field */}
              <div className="bg-slate-100 rounded-xl p-2 border border-slate-200 text-left">
                <div className="text-[9px] text-slate-400 font-bold mb-0.5 text-right">الرابط المعتمد للبوابة الموحدة:</div>
                <div className="text-xs text-teal-900 font-mono font-bold select-all break-all" dir="ltr">
                  {getUnifiedServicesUrl()}
                </div>
              </div>

              <div className="text-[10px] text-slate-600 font-bold pt-1 border-t border-slate-200">
                إشراف: رئيس قسم السلامة والصحة المهنية / م. نجيب غازي
              </div>
            </div>

            {/* Modal Actions */}
            <div className="space-y-2 pt-1">
              <button
                type="button"
                onClick={() => {
                  setShowServicesQrModal(false);
                  setShowPromoPosterModal(true);
                }}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-600 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 font-black text-xs shadow-lg shadow-amber-950 flex items-center justify-center gap-2 transition cursor-pointer active:scale-95"
              >
                <Megaphone className="w-4 h-4 text-slate-950" />
                <span>📢 فتح وتوليد بوستر الإعلان الفاخر (A4 Portrait)</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    triggerSuccessFeedback();
                    printExistingElementById('printable-services-badge-card', {
                      title: 'ملصق اعتماد باركود بوابة الخدمات والتصاريح الموحدة',
                      subtitle: 'مستشفى آزال النموذجي • إدارة السلامة والصحة المهنية FMS',
                      refNumber: 'AZAL-SERVICES-HUB-QR'
                    });
                  }}
                  className="flex-1 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs shadow-md shadow-teal-950 flex items-center justify-center gap-2 transition cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>طباعة الملصق الرسمي</span>
                </button>

                <button
                  type="button"
                  onClick={async () => {
                    await handleCopyPortalLink(getUnifiedServicesUrl());
                  }}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border border-slate-700"
                >
                  {copiedLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-teal-400" />}
                  <span>{copiedLink ? 'تم النسخ' : 'نسخ الرابط'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* PRINTABLE QR BADGE MODAL */}
      {showBadgeModal && (
        <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-md w-full p-6 text-center space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                <Printer className="w-4 h-4 text-teal-400" />
                <span>بطاقة ورمز QR البوابة الرسمية</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowBadgeModal(null)}
                className="text-slate-400 hover:text-slate-200 text-base"
              >
                ✕
              </button>
            </div>

            {/* Printable Area */}
            <div id="printable-badge-card" className="bg-white text-slate-950 p-6 rounded-2xl shadow-xl border-4 border-slate-900 text-center space-y-3">
              <div className="flex items-center justify-between border-b pb-2">
                <div className="text-right">
                  <h3 className="font-black text-xs text-slate-900">مستشفى آزال النموذجي</h3>
                  <span className="text-[10px] text-teal-700 font-bold block">إدارة الأمن والسلامة</span>
                </div>
                <AzalLogo size="sm" showText={false} />
              </div>

              <div className="py-1">
                <span className="text-[10px] font-bold text-slate-500 block">بوابة الخدمة العامة (بدون تسجيل دخول)</span>
                <h2 className="font-black text-base text-slate-900 mt-0.5">
                  {PORTAL_CONFIG[showBadgeModal].title}
                </h2>
                <p className="text-[11px] text-slate-600 mt-1">
                  امسح رمز الاستجابة السريعة (QR) بكاميرا هاتفك للوصول المباشر وتعبئة النموذج
                </p>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl inline-block border-2 border-slate-200">
                <img
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(PORTAL_CONFIG[showBadgeModal].url)}`}
                  alt="Badge QR"
                  referrerPolicy="no-referrer"
                  className="w-36 h-36 object-contain mx-auto"
                />
              </div>

              <div className="border-t pt-2 text-[10px] text-slate-500 font-mono" dir="ltr">
                {PORTAL_CONFIG[showBadgeModal].url}
              </div>

              <div className="text-[10px] text-slate-700 font-bold">
                إشراف: رئيس قسم الأمن والسلامة / م. نجيب غازي
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  triggerSuccessFeedback();
                  printExistingElementById('printable-badge-card', {
                    title: `بطاقة اعتماد البوابة الرسمية - ${PORTAL_CONFIG[showBadgeModal].title}`,
                    subtitle: 'مستشفى آزال النموذجي • إدارة الأمن والسلامة وإدارة المرافق FMS',
                    refNumber: `AZAL-PORTAL-BADGE-${showBadgeModal.toUpperCase()}`
                  });
                }}
                className="flex-1 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs shadow-md flex items-center justify-center gap-2 transition"
              >
                <Printer className="w-4 h-4" />
                <span>طباعة البطاقة / الملصق</span>
              </button>

              <button
                type="button"
                onClick={() => handleCopyPortalLink(PORTAL_CONFIG[showBadgeModal].url)}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition"
              >
                {copiedLink ? 'تم النسخ' : 'نسخ الرابط'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CONTRACTOR DETAIL MODAL */}
      {selectedContractor && (
        <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-lg w-full p-6 text-right space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <HardHat className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-sm text-slate-100">تفاصيل تصريح دخول المقاول</h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedContractor(null)}
                className="text-slate-400 hover:text-slate-200 text-base"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="flex justify-between items-center bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-slate-400">رقم طلب التصريح:</span>
                <div className="flex items-center gap-2">
                  <strong className="font-mono text-amber-400">{selectedContractor.id}</strong>
                  {selectedContractor.permitNumber && (
                    <span className="font-mono text-xs font-black text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
                      {selectedContractor.permitNumber}
                    </span>
                  )}
                </div>
              </div>

              {selectedContractor.status === 'approved' && (
                <div className="bg-gradient-to-r from-emerald-950/80 to-slate-900 border border-emerald-700/60 p-3.5 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-emerald-300 font-bold flex items-center gap-1.5 text-xs">
                      <ShieldCheck className="w-4 h-4 text-emerald-400" />
                      <span>تصريح عمل رسمي معتمد ومفوض</span>
                    </span>
                    <span className="text-[11px] font-mono text-emerald-400 bg-emerald-900/60 px-2 py-0.5 rounded border border-emerald-600/40">
                      {selectedContractor.permitNumber}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-[11px] pt-1 border-t border-emerald-900/40">
                    <div>
                      <span className="text-slate-400 block">معتمد من:</span>
                      <strong className="text-slate-200">{selectedContractor.approvedBy || 'م. نجيب غازي'}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block">تاريخ الاعتماد:</span>
                      <strong className="text-slate-200 font-mono">{selectedContractor.approvedAt}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block">ساعات العمل المصرح بها:</span>
                      <strong className="text-amber-300">{selectedContractor.workingHours || '08:00 ص - 04:00 م'}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block">تفويض بوابة الحراسة:</span>
                      <strong className="text-emerald-300">مصرح بالدخول والتنفيذ</strong>
                    </div>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-2">
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-400 block mb-0.5">المقاول:</span>
                  <strong className="text-slate-100">{selectedContractor.contractorName}</strong>
                </div>
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-400 block mb-0.5">القسم المعني:</span>
                  <strong className="text-slate-100">{selectedContractor.department}</strong>
                </div>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                <span className="text-slate-400 font-bold block">تفاصيل الأعمال:</span>
                <p className="text-slate-200 leading-relaxed">{selectedContractor.workDescription}</p>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                <span className="text-slate-400 font-bold block">أسماء العمال الميدانيين ({selectedContractor.workersCount}):</span>
                <p className="text-slate-200 whitespace-pre-line">{selectedContractor.workersNames}</p>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1.5">
                <span className="text-slate-400 font-bold block">
                  {selectedContractor.status === 'approved' ? 'اشتراطات السلامة المعتمدة رسمياً:' : 'اشتراطات السلامة المقترحة من المقاول:'}
                </span>
                {(selectedContractor.approvalPrecautions && selectedContractor.approvalPrecautions.length > 0 
                  ? selectedContractor.approvalPrecautions 
                  : selectedContractor.safetyMeasures
                ).map((m, idx) => (
                  <div key={idx} className="flex items-center gap-1.5 text-slate-300">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>{m}</span>
                  </div>
                ))}
              </div>

              {selectedContractor.permitPhotoUrl && (
                <div>
                  <span className="text-slate-400 font-bold block mb-1">المرفق المصور:</span>
                  <img
                    src={selectedContractor.permitPhotoUrl}
                    alt="Permit Attachment"
                    className="w-full max-h-48 object-cover rounded-xl border border-slate-800"
                  />
                </div>
              )}
            </div>

            <div className="border-t border-slate-800 pt-3 flex flex-wrap items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => setSelectedContractor(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs"
              >
                إغلاق
              </button>

              <div className="flex flex-wrap items-center gap-2">
                {selectedContractor.status === 'approved' && (
                  <>
                    <button
                      type="button"
                      onClick={() => handleOpenPermitVerification(selectedContractor)}
                      className="px-3 py-2 rounded-xl bg-slate-950 hover:bg-slate-800 text-emerald-400 border border-emerald-800 text-xs font-bold flex items-center gap-1.5 transition"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>معاينة التصريح (#permit)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const target = selectedContractor;
                        setSelectedContractor(null);
                        setSharePermitModal(target);
                      }}
                      className="px-3 py-2 rounded-xl bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 text-xs font-bold flex items-center gap-1.5 transition"
                    >
                      <Share2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>مشاركة عبر واتساب</span>
                    </button>
                  </>
                )}

                <button
                  type="button"
                  onClick={() => {
                    const target = selectedContractor;
                    setSelectedContractor(null);
                    handleStartApproval(target);
                  }}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 transition shadow-md"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>{selectedContractor.status === 'approved' ? 'تعديل الشروط وإعادة الاعتماد' : 'اعتماد وإصدار التصريح'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* APPROVAL MODAL (ENG. NAJIB GHAZI SAFETY WORK PERMIT ISSUANCE) */}
      {approvingContractor && (
        <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-2xl w-full p-6 text-right space-y-4 shadow-2xl max-h-[92vh] overflow-y-auto">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-2xl bg-emerald-950 border border-emerald-700/60 flex items-center justify-center text-emerald-400 shadow-sm">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-100">اعتماد وإصدار تصريح عمل مقاول رسمي</h3>
                  <p className="text-[11px] text-slate-400">إدارة الأمن والسلامة والصحة المهنية - م. نجيب غازي</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setApprovingContractor(null)}
                className="text-slate-400 hover:text-slate-200 text-base p-1"
              >
                ✕
              </button>
            </div>

            {/* Contractor Summary Box */}
            <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 space-y-2 text-xs">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div>
                  <span className="text-slate-400 block text-[10px]">جهة المقاول:</span>
                  <strong className="text-slate-100 text-sm">{approvingContractor.contractorName}</strong>
                </div>
                <div className="text-left">
                  <span className="text-slate-400 block text-[10px]">القسم وموقع العمل:</span>
                  <strong className="text-amber-400">{approvingContractor.department}</strong>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-[11px]">
                <div>
                  <span className="text-slate-400 block">تاريخ البدء:</span>
                  <strong className="text-slate-200 font-mono">{approvingContractor.startDate}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block">تاريخ الانتهاء:</span>
                  <strong className="text-slate-200 font-mono">{approvingContractor.endDate}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block">طاقم العمال:</span>
                  <strong className="text-slate-200 font-mono">{approvingContractor.workersCount} عمال</strong>
                </div>
                <div>
                  <span className="text-slate-400 block">هاتف المقاول:</span>
                  <strong className="text-slate-200 font-mono" dir="ltr">{approvingContractor.contactPhone}</strong>
                </div>
              </div>

              <div className="pt-1 text-[11px] text-slate-300">
                <span className="text-slate-400 font-bold ml-1">نطاق الأعمال:</span>
                {approvingContractor.workDescription}
              </div>
            </div>

            {/* Form Controls */}
            <div className="space-y-3.5 text-xs">
              {/* Reference & Working Hours */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-bold block mb-1.5 flex items-center justify-between">
                    <span>الرقم المرجعي الرسمي للتصريح:</span>
                    <button
                      type="button"
                      onClick={() => setApprovalRef(`AZAL-PERMIT-2026-${Math.floor(1000 + Math.random() * 9000)}`)}
                      className="text-[10px] text-teal-400 hover:text-teal-300 flex items-center gap-1"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>توليد رقم جديد</span>
                    </button>
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      value={approvalRef}
                      onChange={(e) => setApprovalRef(e.target.value)}
                      className="w-full bg-slate-950 border border-emerald-700/60 rounded-xl px-3 py-2 text-emerald-300 font-mono font-bold text-xs focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                      dir="ltr"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-slate-300 font-bold block mb-1.5">ساعات العمل المصرح بها يومياً:</label>
                  <input
                    type="text"
                    value={workingHoursInput}
                    onChange={(e) => setWorkingHoursInput(e.target.value)}
                    placeholder="مثال: 08:00 صباحاً - 04:00 عصراً"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 text-xs focus:ring-1 focus:ring-teal-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Safety Precautions Checklist */}
              <div className="space-y-2 bg-slate-950 p-3.5 rounded-2xl border border-slate-800">
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-slate-200 font-bold block text-xs">
                      اشتراطات واحتياطات السلامة الإلزامية بالموقع:
                    </label>
                    <span className="text-[10px] text-slate-400">
                      حدد الاشتراطات الواجب الالتزام بها أثناء تنفيذ الأعمال ({selectedPrecautions.length} محددة)
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-[10px]">
                    <button
                      type="button"
                      onClick={() => setSelectedPrecautions([...STANDARD_SAFETY_PRECAUTIONS])}
                      className="text-teal-400 hover:underline"
                    >
                      تحديد الكل
                    </button>
                    <span className="text-slate-600">|</span>
                    <button
                      type="button"
                      onClick={() => setSelectedPrecautions([])}
                      className="text-rose-400 hover:underline"
                    >
                      إلغاء التحديد
                    </button>
                  </div>
                </div>

                <div className="space-y-1.5 max-h-52 overflow-y-auto pl-1">
                  {STANDARD_SAFETY_PRECAUTIONS.map((prec, idx) => {
                    const checked = selectedPrecautions.includes(prec);
                    return (
                      <label
                        key={idx}
                        className={`flex items-start gap-2.5 p-2 rounded-xl border transition cursor-pointer text-xs ${
                          checked
                            ? 'bg-emerald-950/40 border-emerald-800 text-slate-100'
                            : 'bg-slate-900/60 border-slate-800/80 text-slate-400 hover:bg-slate-900'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={() => handleTogglePrecaution(prec)}
                          className="mt-0.5 rounded text-emerald-600 focus:ring-emerald-500 bg-slate-900 border-slate-700"
                        />
                        <span className="leading-snug">{prec}</span>
                      </label>
                    );
                  })}
                </div>

                {/* Add Custom Precaution */}
                <div className="flex items-center gap-2 pt-2 border-t border-slate-800/80">
                  <input
                    type="text"
                    value={customPrecautionInput}
                    onChange={(e) => setCustomPrecautionInput(e.target.value)}
                    placeholder="إضافة اشتراط سلامة مخصص وموقع للمقاول..."
                    className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-slate-200 focus:ring-1 focus:ring-teal-500 focus:outline-none"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddCustomPrecaution();
                      }
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleAddCustomPrecaution}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition shrink-0"
                  >
                    + إضافة
                  </button>
                </div>
              </div>

              {/* Gate Pass Authorization & Directives */}
              <div className="space-y-2">
                <label className="flex items-center gap-2.5 p-3 rounded-2xl bg-emerald-950/30 border border-emerald-800/60 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={gatePassAllowed}
                    onChange={(e) => setGatePassAllowed(e.target.checked)}
                    className="rounded text-emerald-600 focus:ring-emerald-500 bg-slate-900 border-slate-700 w-4 h-4"
                  />
                  <div>
                    <strong className="text-emerald-300 text-xs block">
                      تفويض بوابة الأمن والحراسات بالمستشفى (Gate Pass Authorization)
                    </strong>
                    <span className="text-[10px] text-slate-400">
                      يسمح لطاقم المقاول بدخول المستشفى والمعدات المعتمدة خلال الساعات المحددة فقط.
                    </span>
                  </div>
                </label>

                <div>
                  <label className="text-slate-300 font-bold block mb-1">ملاحظات وتوجيهات السلامة الإدارية:</label>
                  <textarea
                    rows={2}
                    value={safetyNotesInput}
                    onChange={(e) => setSafetyNotesInput(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-slate-200 focus:ring-1 focus:ring-teal-500 focus:outline-none"
                    placeholder="أي توجيهات خاصة بتأمين الأجهزة الطبية أو تنسيق الإطفاء..."
                  />
                </div>
              </div>

              {/* Officer Signature Badge */}
              <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-teal-950 border border-teal-700 flex items-center justify-center text-teal-400">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">الضابط المعتمد:</span>
                    <strong className="text-slate-100">م. نجيب غازي - رئيس قسم الأمن والسلامة</strong>
                  </div>
                </div>
                <div className="text-left">
                  <span className="text-[10px] text-slate-400 block">الصلاحية الرسمية:</span>
                  <span className="text-emerald-400 font-bold text-[11px]">مفوض بالاعتماد الميداني</span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="border-t border-slate-800 pt-3 flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => setApprovingContractor(null)}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs"
              >
                إلغاء
              </button>

              <button
                type="button"
                onClick={handleConfirmApproval}
                className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition shadow-lg shadow-emerald-950"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>إصدار واعتماد التصريح رسمياً وتوليد وثيقة التحقق</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* INSTANT WHATSAPP SHARE MODAL */}
      {sharePermitModal && (
        <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-md w-full p-6 text-right space-y-4 shadow-2xl">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Share2 className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-sm text-slate-100">مشاركة وتفويض تصريح الدخول المعتمد</h3>
              </div>
              <button
                type="button"
                onClick={() => setSharePermitModal(null)}
                className="text-slate-400 hover:text-slate-200 text-base"
              >
                ✕
              </button>
            </div>

            {/* Official Permit Card Preview */}
            <div className="bg-emerald-950/50 border border-emerald-800/80 rounded-2xl p-4 text-center space-y-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-900 text-emerald-300 font-bold text-xs border border-emerald-700">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>تم اعتماد التصريح بنجاح</span>
              </div>
              <h4 className="font-bold text-sm text-slate-100">{sharePermitModal.contractorName}</h4>
              <p className="text-xs text-slate-300">
                القسم: <strong className="text-slate-100">{sharePermitModal.department}</strong>
              </p>
              <div className="font-mono text-sm font-black text-emerald-400 bg-slate-950/80 p-2 rounded-xl border border-emerald-900/60" dir="ltr">
                {sharePermitModal.permitNumber || sharePermitModal.id}
              </div>
            </div>

            {/* Quick Share Options */}
            <div className="space-y-2.5 text-xs">
              <p className="text-slate-400 text-[11px]">
                اختر وجهة المشاركة الفورية عبر واتساب لإرسال نص التفويض المعتمد ورابط التحقق المباشر:
              </p>

              {/* Share with Contractor */}
              <button
                type="button"
                onClick={() => handleShareWhatsAppPermit(sharePermitModal, sharePermitModal.contactPhone)}
                className="w-full p-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center justify-between transition shadow-md"
              >
                <div className="flex items-center gap-2">
                  <Share2 className="w-4 h-4" />
                  <span>إرسال لهاتف المقاول ({sharePermitModal.contactPhone})</span>
                </div>
                <span className="text-[10px] bg-emerald-700 px-2 py-0.5 rounded-full">1-Click</span>
              </button>

              {/* Share with Hospital Gate */}
              <button
                type="button"
                onClick={() => handleShareWhatsAppPermit(sharePermitModal)}
                className="w-full p-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold flex items-center justify-between border border-slate-700 transition"
              >
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                  <span>إرسال لبوابة الأمن والحراسات بالمستشفى</span>
                </div>
                <span className="text-[10px] text-slate-400">تطبيق واتساب</span>
              </button>

              {/* Copy Direct Link */}
              <button
                type="button"
                onClick={() => handleCopyPermitLink(sharePermitModal)}
                className="w-full p-2.5 rounded-2xl bg-slate-950 hover:bg-slate-800 text-slate-300 font-bold flex items-center justify-center gap-2 border border-slate-800 transition"
              >
                {shareSuccessCopied ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span className="text-emerald-400">تم نسخ رابط وثيقة التحقق للحافظة!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 text-slate-400" />
                    <span>نسخ رابط التحقق المباشر (#permit)</span>
                  </>
                )}
              </button>
            </div>

            {/* View Standalone Link Action */}
            <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
              <button
                type="button"
                onClick={() => {
                  handleOpenPermitVerification(sharePermitModal);
                  setSharePermitModal(null);
                }}
                className="text-teal-400 hover:text-teal-300 font-bold flex items-center gap-1"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>فتح صفحة التحقق الإلكترونية الآن</span>
              </button>

              <button
                type="button"
                onClick={() => setSharePermitModal(null)}
                className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 text-xs"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}

      {/* NEW HIRES DETAIL MODAL */}
      {selectedNewHire && (
        <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-lg w-full p-6 text-right space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <GraduationCap className="w-5 h-5 text-blue-400" />
                <h3 className="font-bold text-sm text-slate-100">بيانات الموظفين الجدد (HR)</h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedNewHire(null)}
                className="text-slate-400 hover:text-slate-200 text-base"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="flex justify-between bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="text-slate-400">رقم الإشعار:</span>
                <strong className="font-mono text-blue-400">{selectedNewHire.id}</strong>
              </div>

              <div className="space-y-2">
                <span className="text-slate-400 font-bold block">قائمة الكوادر ({selectedNewHire.hires.length}):</span>
                {selectedNewHire.hires.map((h, idx) => (
                  <div key={h.id} className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
                    <div>
                      <strong className="text-slate-100 block">{idx + 1}. {h.fullName}</strong>
                      <span className="text-slate-400 text-[11px]">{h.jobTitle} - {h.department}</span>
                    </div>
                    {h.phone && <span className="font-mono text-slate-300" dir="ltr">{h.phone}</span>}
                  </div>
                ))}
              </div>
            </div>

            <div className="border-t border-slate-800 pt-3 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setSelectedNewHire(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Services Hub Promo Poster Modal (A4 Portrait) */}
      <ServicesHubPromoPosterModal
        isOpen={showPromoPosterModal}
        onClose={() => setShowPromoPosterModal(false)}
      />
    </div>
  );
};
