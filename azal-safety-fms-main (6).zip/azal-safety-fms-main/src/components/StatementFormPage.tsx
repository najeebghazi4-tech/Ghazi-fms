import React, { useState, useEffect, useMemo } from 'react';
import { 
  CheckCircle2, 
  AlertTriangle, 
  Building2, 
  MapPin, 
  User, 
  FileText, 
  Camera, 
  Send, 
  MessageSquare, 
  Clock, 
  ShieldAlert, 
  Copy, 
  Check, 
  ArrowRight,
  ExternalLink,
  Lock
} from 'lucide-react';
import { AzalLogo } from './AzalLogo';
import { SafetyViolationNotice } from '../types';
import { supabase } from '../services/supabaseClient';
import { db } from '../services/firebase';
import { doc, getDoc } from 'firebase/firestore';

interface StatementFormPageProps {
  initialRefCode?: string;
  violations?: SafetyViolationNotice[];
  onResolveViolation?: (violationId: string, resolutionNote: string, afterPhotoUrl?: string, resolvedBy?: string) => void;
  onBackToApp?: () => void;
}

export const StatementFormPage: React.FC<StatementFormPageProps> = ({
  initialRefCode = '',
  violations = [],
  onResolveViolation,
  onBackToApp,
}) => {
  // Extract reference code from prop, hash (#statement?ref=...), or query params
  const [refCode, setRefCode] = useState<string>(() => {
    if (initialRefCode && initialRefCode.trim()) return initialRefCode.trim();
    if (typeof window !== 'undefined') {
      const hash = window.location.hash || '';
      const [_, queryString] = hash.split('?');
      const hashParams = new URLSearchParams(queryString || '');
      const paramRef = hashParams.get('ref') || hashParams.get('id');
      if (paramRef && paramRef.trim()) return decodeURIComponent(paramRef.trim());

      const urlParams = new URLSearchParams(window.location.search);
      const searchRef = urlParams.get('ref') || urlParams.get('id');
      if (searchRef && searchRef.trim()) return decodeURIComponent(searchRef.trim());
    }
    return '';
  });

  const [performerName, setPerformerName] = useState<string>('');
  const [statementAction, setStatementAction] = useState<string>('');
  const [completionPhoto, setCompletionPhoto] = useState<File | null>(null);
  const [completionPhotoPreview, setCompletionPhotoPreview] = useState<string | null>(null);
  
  const [isLoadingNotice, setIsLoadingNotice] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [isSuccess, setIsSuccess] = useState<boolean>(false);
  const [lastWaText, setLastWaText] = useState<string>('');
  const [copiedWa, setCopiedWa] = useState<boolean>(false);

  // Notice fetched details
  const [fetchedNotice, setFetchedNotice] = useState<{
    id: string;
    department: string;
    locationDetail?: string;
    description: string;
    requiredAction?: string;
    severity?: string;
    assignedTo?: string;
    deadlineAt?: string;
    createdAt?: string;
  } | null>(null);

  // Sync route on hashchange
  useEffect(() => {
    const parseUrlRef = () => {
      if (typeof window === 'undefined') return;
      const hash = window.location.hash || '';
      const [_, queryString] = hash.split('?');
      const hashParams = new URLSearchParams(queryString || '');
      const foundRef = hashParams.get('ref') || hashParams.get('id');
      if (foundRef && foundRef.trim()) {
        setRefCode(decodeURIComponent(foundRef.trim()));
      }
    };

    window.addEventListener('hashchange', parseUrlRef);
    return () => window.removeEventListener('hashchange', parseUrlRef);
  }, []);

  // Fetch notice data from local state, Supabase, or Firebase Firestore
  useEffect(() => {
    let isCancelled = false;
    const loadNoticeData = async () => {
      if (!refCode || !refCode.trim()) {
        setFetchedNotice(null);
        return;
      }

      const cleanRef = refCode.trim();
      setIsLoadingNotice(true);

      // 1. Check passed violations prop / localStorage
      const localMatched = (violations || []).find(
        (v) => v.id.toLowerCase() === cleanRef.toLowerCase()
      );
      if (localMatched) {
        if (!isCancelled) {
          setFetchedNotice({
            id: localMatched.id,
            department: localMatched.department,
            locationDetail: localMatched.locationDetail,
            description: localMatched.description,
            requiredAction: localMatched.requiredAction,
            severity: localMatched.severity,
            assignedTo: localMatched.assignedToCustom || localMatched.assignedTo,
            deadlineAt: localMatched.deadlineAt,
            createdAt: localMatched.createdAt,
          });
          setIsLoadingNotice(false);
        }
        return;
      }

      // Check localStorage violations
      try {
        const savedViolations = JSON.parse(localStorage.getItem('azal_violations_v1') || '[]');
        const found = savedViolations.find((v: any) => v.id?.toLowerCase() === cleanRef.toLowerCase());
        if (found) {
          if (!isCancelled) {
            setFetchedNotice({
              id: found.id,
              department: found.department,
              locationDetail: found.locationDetail,
              description: found.description,
              requiredAction: found.requiredAction,
              severity: found.severity,
              assignedTo: found.assignedToCustom || found.assignedTo,
              deadlineAt: found.deadlineAt,
              createdAt: found.createdAt,
            });
            setIsLoadingNotice(false);
          }
          return;
        }
      } catch {}

      // 2. Fetch from Supabase (safety_remediation_notices or audit_logs / inspections)
      try {
        const { data: supaData } = await supabase
          .from('safety_remediation_notices')
          .select('*');

        if (Array.isArray(supaData) && supaData.length > 0 && !isCancelled) {
          const matched = supaData.find(
            (s: any) =>
              (s.notice_number && s.notice_number.toLowerCase() === cleanRef.toLowerCase()) ||
              (s.id && String(s.id).toLowerCase() === cleanRef.toLowerCase())
          );
          if (matched) {
            setFetchedNotice({
              id: matched.notice_number || matched.id,
              department: matched.department_name || matched.department || 'القسم المعني بالمستشفى',
              locationDetail: matched.location_detail || matched.location || '',
              description: matched.hazard_description || matched.description || 'إشعار وملاحظة تصحيحية تتطلب المعالجة',
              requiredAction: matched.required_action || '',
              severity: matched.severity || 'متوسط',
              assignedTo: matched.assigned_to || '',
              deadlineAt: matched.deadline_at || 'عاجل',
              createdAt: matched.created_at || '',
            });
            setIsLoadingNotice(false);
            return;
          }
        }
      } catch (err) {
        console.warn('Supabase notice load warning:', err);
      }

      // 3. Fetch from Firebase Firestore
      try {
        const docRef = doc(db, 'violations', cleanRef);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists() && !isCancelled) {
          const fbData = docSnap.data();
          setFetchedNotice({
            id: fbData.id || cleanRef,
            department: fbData.department || 'قسم المستشفى',
            locationDetail: fbData.locationDetail || '',
            description: fbData.description || '',
            requiredAction: fbData.requiredAction || '',
            severity: fbData.severity || 'high',
            assignedTo: fbData.assignedToCustom || fbData.assignedTo || '',
            deadlineAt: fbData.deadlineAt || '',
            createdAt: fbData.createdAt || '',
          });
          setIsLoadingNotice(false);
          return;
        }
      } catch (fbErr) {
        console.warn('Firebase notice load warning:', fbErr);
      }

      // Fallback if not found: create clean structure with given ref
      if (!isCancelled) {
        setFetchedNotice({
          id: cleanRef,
          department: 'مستشفى آزال النموذجي - القسم المعني',
          locationDetail: 'الموقع الميداني المحدد بالإشعار',
          description: `إشعار معالجة وملاحظة سلامة مهنية برقم (${cleanRef}) تتطلب تصحيح الوضع وتوثيق الإفادة.`,
          requiredAction: 'إجراء المعالجة الهندسية / الفنية وتأمين الموقع وإرفاق صورة بعد التصحيح',
          severity: 'عاجل',
          deadlineAt: 'خلال 24 ساعة',
        });
        setIsLoadingNotice(false);
      }
    };

    loadNoticeData();
    return () => {
      isCancelled = true;
    };
  }, [refCode, violations]);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setCompletionPhoto(file);
    if (file) {
      const reader = new FileReader();
      reader.onload = () => setCompletionPhotoPreview(reader.result as string);
      reader.readAsDataURL(file);
    } else {
      setCompletionPhotoPreview(null);
    }
  };

  const handleSubmitStatement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!refCode.trim() || !statementAction.trim()) return;

    setIsSubmitting(true);
    const cleanRef = refCode.trim();
    const performer = performerName.trim() || 'فريق المعالجة الميداني';
    const note = statementAction.trim();
    const photo = completionPhotoPreview || undefined;
    const nowTimeStr = new Date().toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' });

    // 1. Update via callback
    if (onResolveViolation) {
      onResolveViolation(cleanRef, note, photo, performer);
    }

    // 2. Persist to Supabase safety_remediation_notices
    try {
      await supabase
        .from('safety_remediation_notices')
        .insert([{
          notice_number: cleanRef,
          department_name: fetchedNotice?.department || 'مستشفى آزال النموذجي',
          hazard_description: fetchedNotice?.description || '',
          action_taken: note,
          completed_by: performer,
          completed_at: new Date().toISOString(),
          status: 'قيد المراجعة والاعتماد'
        }]);
    } catch (supaErr) {
      console.warn('Supabase statement save error:', supaErr);
    }

    // 3. Save to localStorage incoming statements
    try {
      const existing = JSON.parse(localStorage.getItem('azal_incoming_statements') || '[]');
      const newStmt = {
        id: `STMT-${Date.now()}`,
        referenceId: cleanRef,
        department: fetchedNotice?.department || 'مستشفى آزال النموذجي',
        resolvedBy: performer,
        note: note,
        afterPhotoUrl: photo,
        submittedAt: nowTimeStr,
        timestamp: Date.now(),
      };
      localStorage.setItem('azal_incoming_statements', JSON.stringify([newStmt, ...existing]));
    } catch {}

    // 4. Construct WhatsApp formatted payload
    const photoText = photo ? 'تم إرفاق صورة الإنجاز وتوثيقها بالنظام' : 'لم تُرفق صورة';
    const waMessage = 
`✅ *إفادة إنجاز ومعالجة إشعار مخاطر - مستشفى آزال النموذجي* ✅
----------------------------------------
📌 *الرقم المرجعي للإشعار:* ${cleanRef}
🏢 *القسم / الموقع:* ${fetchedNotice?.department || 'مستشفى آزال'} ${fetchedNotice?.locationDetail ? `(${fetchedNotice.locationDetail})` : ''}
🛠️ *الإجراء المتخذ والمعالجة:* ${note}
👤 *القائم بالمعالجة:* ${performer}
📅 *تاريخ وساعة الإفادة:* ${nowTimeStr}
📷 *مرفق الإنجاز:* ${photoText}
----------------------------------------
مرسل إلى: قسم السلامة وإدارة المرافق (FMS) - م/ نجيب قاسم غازي`;

    setLastWaText(waMessage);

    // 5. Open WhatsApp directly
    const waUrl = `https://api.whatsapp.com/send?phone=96777738138&text=${encodeURIComponent(waMessage)}`;
    try {
      window.open(waUrl, '_blank', 'noopener,noreferrer');
    } catch {}

    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
    }, 400);
  };

  return (
    <div className="min-h-screen bg-slate-900/40 text-slate-100 flex flex-col justify-between py-6 px-4 rtl" dir="rtl">
      <div className="max-w-xl mx-auto w-full">
        {/* Header Bar */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 mb-6 shadow-xl flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-1.5 bg-white/5 rounded-xl border border-white/10">
              <AzalLogo variant="horizontal" size="sm" transparent={true} />
            </div>
            <div>
              <h1 className="text-sm font-black text-white flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-emerald-400" />
                <span>نموذج إفادة الإنجاز ومعالجة الإشعار</span>
              </h1>
              <p className="text-[11px] text-teal-400 font-medium">
                بوابة السلامة وإدارة المرافق (CBAHI / FMS)
              </p>
            </div>
          </div>

          {onBackToApp && (
            <button
              type="button"
              onClick={onBackToApp}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-bold transition flex items-center gap-1.5 border border-slate-700"
            >
              <span>لوحة التحكم</span>
              <ArrowRight className="w-3.5 h-3.5 rotate-180" />
            </button>
          )}
        </div>

        {/* Success Card */}
        {isSuccess ? (
          <div className="bg-slate-900 border border-emerald-500/30 rounded-2xl p-6 shadow-2xl text-center space-y-4 animate-fadeIn">
            <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/30 shadow-lg">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div>
              <h2 className="text-lg font-bold text-emerald-400">تم تسجيل واعتماد الإفادة بنجاح</h2>
              <p className="text-xs text-slate-400 mt-1">
                تم حفظ بيانات المعالجة وتحديث سجل الإشعار وإرسال التقرير لإدارة السلامة.
              </p>
            </div>

            <div className="bg-slate-950/80 p-3.5 rounded-xl border border-slate-800 text-xs text-right space-y-1">
              <div className="text-slate-400">الرقم المرجعي: <span className="text-white font-mono font-bold">{refCode}</span></div>
              <div className="text-slate-400">القسم: <span className="text-slate-200 font-medium">{fetchedNotice?.department}</span></div>
              <div className="text-slate-400">القائم بالمعالجة: <span className="text-slate-200 font-medium">{performerName || 'فريق المعالجة'}</span></div>
            </div>

            {lastWaText && (
              <div className="space-y-2 pt-2">
                <a
                  href={`https://api.whatsapp.com/send?phone=96777738138&text=${encodeURIComponent(lastWaText)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition shadow-lg"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>إعادة فتح المحادثة بالواتساب</span>
                </a>

                <button
                  type="button"
                  onClick={() => {
                    navigator.clipboard.writeText(lastWaText);
                    setCopiedWa(true);
                    setTimeout(() => setCopiedWa(false), 2000);
                  }}
                  className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition border border-slate-700"
                >
                  {copiedWa ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-slate-400" />}
                  <span>{copiedWa ? 'تم نسخ نص الرسالة' : 'نسخ نص رسالة الواتساب المعتمدة'}</span>
                </button>
              </div>
            )}

            <button
              type="button"
              onClick={() => {
                setIsSuccess(false);
                setStatementAction('');
                setCompletionPhoto(null);
                setCompletionPhotoPreview(null);
              }}
              className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl transition border border-slate-700"
            >
              تسجيل إفادة إضافية
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmitStatement} className="space-y-4 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-2xl">
            
            {/* Automatic Notice Card fetched from Supabase / DB */}
            {isLoadingNotice ? (
              <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 text-xs text-slate-400 flex items-center justify-center gap-2">
                <div className="w-4 h-4 border-2 border-teal-400 border-t-transparent rounded-full animate-spin"></div>
                <span>جاري تحميل ومطابقة بيانات الإشعار من السحابة...</span>
              </div>
            ) : fetchedNotice ? (
              <div className="p-4 rounded-xl bg-slate-950/80 border border-teal-500/30 text-xs space-y-2">
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                  <div className="flex items-center gap-1.5 text-teal-300 font-bold">
                    <ShieldAlert className="w-4 h-4 text-teal-400" />
                    <span>بيانات الإشعار المرتبط بالنظام</span>
                  </div>
                  <span className="font-mono bg-teal-500/10 text-teal-300 px-2 py-0.5 rounded border border-teal-500/20 font-bold">
                    {fetchedNotice.id}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-300">
                  <div className="flex items-center gap-1.5">
                    <Building2 className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span><strong className="text-slate-400">القسم:</strong> {fetchedNotice.department}</span>
                  </div>
                  {fetchedNotice.locationDetail && (
                    <div className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span><strong className="text-slate-400">الموقع:</strong> {fetchedNotice.locationDetail}</span>
                    </div>
                  )}
                </div>

                <div className="text-slate-300 bg-slate-900/60 p-2.5 rounded-lg border border-slate-800/60">
                  <strong className="text-amber-400 block mb-0.5">وصف الملاحظة / الخطر:</strong>
                  {fetchedNotice.description}
                </div>

                {fetchedNotice.requiredAction && (
                  <div className="text-slate-300 bg-emerald-950/30 p-2 rounded-lg border border-emerald-800/30">
                    <strong className="text-emerald-400 block mb-0.5">الإجراء المطلوب:</strong>
                    {fetchedNotice.requiredAction}
                  </div>
                )}
              </div>
            ) : null}

            {/* Read-Only Reference Code */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center justify-between">
                <span>الرقم المرجعي للإشعار (تم تثبيته تلقائياً)</span>
                <span className="text-[10px] text-teal-400 flex items-center gap-1">
                  <Lock className="w-3 h-3" />
                  <span>محمي للقراءة فقط</span>
                </span>
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={refCode}
                  readOnly
                  placeholder="AZAL-VIO-..."
                  className="w-full p-3 pr-10 border border-slate-700 bg-slate-950/90 text-teal-300 rounded-xl text-sm font-mono font-bold outline-none cursor-not-allowed select-all"
                />
                <Lock className="w-4 h-4 text-slate-500 absolute right-3.5 top-3.5" />
              </div>
            </div>

            {/* Performer Name */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                اسم القائم بالمعالجة / المنفذ
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={performerName}
                  onChange={(e) => setPerformerName(e.target.value)}
                  placeholder="مثال: م. أحمد الحمادي / فني الصيانة المناوب"
                  className="w-full p-2.5 pr-9 border border-slate-700 bg-slate-950 text-white rounded-xl text-xs outline-none focus:border-teal-500"
                />
                <User className="w-4 h-4 text-slate-500 absolute right-3 top-3" />
              </div>
            </div>

            {/* Statement / Action Taken */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                الإجراء المتخذ وتفاصيل المعالجة المنجزة <span className="text-red-400">*</span>
              </label>
              <textarea
                rows={4}
                required
                value={statementAction}
                onChange={(e) => setStatementAction(e.target.value)}
                placeholder="وضح الإجراءات الفنية والتصحيحية التي تم تنفيذها لمعالجة الملاحظة..."
                className="w-full p-3 border border-slate-700 bg-slate-950 text-white rounded-xl text-xs outline-none focus:border-teal-500 placeholder:text-slate-600 leading-relaxed"
              />
            </div>

            {/* Photo Proof */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center justify-between">
                <span>صورة إثبات الإنجاز بعد المعالجة</span>
                <span className="text-[10px] text-slate-400">توثيق فوتوغرافي معتمد</span>
              </label>
              <div className="p-3 border border-dashed border-slate-700 rounded-xl bg-slate-950/40 text-center">
                <input
                  type="file"
                  accept="image/*"
                  capture="environment"
                  onChange={handlePhotoUpload}
                  className="w-full text-xs text-slate-400 file:mr-4 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-teal-500/10 file:text-teal-300 hover:file:bg-teal-500/20 cursor-pointer"
                />
                {completionPhotoPreview && (
                  <div className="mt-3 flex items-center gap-3 p-2 bg-slate-900 rounded-xl border border-slate-800 text-right">
                    <img
                      src={completionPhotoPreview}
                      alt="معاينة إثبات الإنجاز"
                      className="w-14 h-14 object-cover rounded-lg border border-slate-700 shrink-0"
                    />
                    <div className="text-[11px] text-slate-300">
                      <p className="font-bold text-emerald-400">تم اختيار صورة الإثبات بنجاح</p>
                      <p className="text-slate-500 text-[10px]">سيتم تضمينها مباشرة في تقرير الإفادة والواتساب</p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting || !statementAction.trim()}
              className="w-full py-3.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl font-bold text-xs shadow-lg shadow-emerald-950/50 flex items-center justify-center gap-2 transition disabled:opacity-50 cursor-pointer active:scale-[0.99]"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{isSubmitting ? 'جاري الحفظ والتوجيه...' : 'حفظ واعتماد إفادة الإنجاز وإرسالها'}</span>
            </button>
          </form>
        )}
      </div>

      <div className="max-w-xl mx-auto w-full text-center text-[10px] text-slate-500 pt-6">
        نظام إدارة السلامة وتوثيق المرافق • مستشفى آزال النموذجي • 2026
      </div>
    </div>
  );
};
export default StatementFormPage;
