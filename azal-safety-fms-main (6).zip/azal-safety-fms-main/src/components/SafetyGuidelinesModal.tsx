import React, { useState, useEffect } from 'react';
import {
  AlertTriangle,
  Flame,
  ShieldAlert,
  Phone,
  Printer,
  X,
  CheckCircle2,
  Share2,
  Search,
  Plus,
  Trash2,
  Building2,
  FileText,
  HelpCircle,
  ExternalLink,
  Info,
  Wind,
  Droplets,
  HardHat,
  Ban,
  Bell,
  Sparkles,
  ArrowRight,
  BookmarkCheck,
  Check,
  Zap,
  Users
} from 'lucide-react';
import { AzalLogo } from './AzalLogo';
import { executeSmartPrint } from '../utils/printUtils';
import { GlobalPortalBackBar } from './public/GlobalPortalBackBar';

export interface SafetyGuidelineItem {
  id: string;
  category: 'prohibition' | 'emergency' | 'occupational';
  title: string;
  description: string;
  subPoints?: string[];
  referenceCode?: string; // e.g., FMS.23, CBAHI, NFPA 101, OSHA
  severity: 'critical' | 'high' | 'standard';
  actionableStep?: string;
  isCustom?: boolean;
}

const DEFAULT_GUIDELINES: SafetyGuidelineItem[] = [
  // 1. التحذيرات والمحظورات العاجلة (Strict Prohibitions)
  {
    id: 'prohib-1',
    category: 'prohibition',
    title: 'حظر إغلاق أو إعاقة مخارج ومسالك الطوارئ نهائياً',
    description: 'يمنع منعاً باتاً وضع أي أسرة، كراسٍ، كراتين، أو أجهزة ومعدات صيانة في الممرات المؤدية لمخارج الطوارئ أو أمام أبواب الهروب المقاومة للحريق.',
    subPoints: [
      'يجب أن تظل مسارات الهروب مضاءة ومفتوحة على مدار 24 ساعة دون أي عوائق.',
      'يحظر قفل أبواب مخارج الطوارئ بالمفاتيح أثناء تواجد المرضى أو الموظفين.',
      'أي عائق يُعتبر مخالفة حرجة من الدرجة الأولى يتم إزالتها فوراً وتغريم المتسبب.'
    ],
    referenceCode: 'معيار سباهي FMS.23 • كود السلامة الدولي NFPA 101',
    severity: 'critical',
    actionableStep: 'الإبلاغ الفوري عبر كود البلاغات المباشر حال رصد أي تكدس أو عائق'
  },
  {
    id: 'prohib-2',
    category: 'prohibition',
    title: 'حظر التدخين منعاً باتاً داخل كافة مرافق ومباني المستشفى',
    description: 'يُحظر التدخين التقليدي والإلكتروني قطيعاً في جميع الأقسام الطبية، الممرات، السلالم، المكاتب، غرف الاستراحة، وغرف المرضى ومحيط خزانات الأكسجين.',
    subPoints: [
      'حظر التدخين قطعي داخل حرم المستشفى وخاصة بالقرب من شبكات الغازات الطبية ومحطة الأكسجين المركزي.',
      'تفعيل حساسات الدخان الضوئية وغرامات المخالفة وتوجيه بلاغ إداري فوري للمخالفين.',
      'المستشفى بيئة صحية خالية من التدخين بنسبة 100% لحماية المرضى المنومين والأطفال.'
    ],
    referenceCode: 'سياسة حظر التدخين FMS-POL-003 • معايير الجودة CBAHI',
    severity: 'critical',
    actionableStep: 'تطبيق الإجراء الانضباطي المباشر بحق أي مدخن داخل المبنى'
  },
  {
    id: 'prohib-3',
    category: 'prohibition',
    title: 'منع استخدام التوصيلات الكهربائية العشوائية وأسلاك التمديد التجارية',
    description: 'يُمنع استخدام أي مشترك كهربائي (Extension Cord) تجاري أو غير معتمد، أو توصيل أحمال ثقيلة (سخانات، غلايات، ثلاجات، مكيفات) على مقابس عادية داخل غرف المرضى أو المحطات التمريضية.',
    subPoints: [
      'جميع التوصيلات للأجهزة الطبية يجب أن تكون عبر القواطع والمقابس المعزولة ومعتمدة من الإدارة الهندسية.',
      'يُصادر أي مشترك عشوائي غير مطابق للمواصفات من قبل ضابط السلامة خلال الجولات اليومية.',
      'فحص العزل الدوري للأسلاك وتجنب تمرير الأسلاك تحت السجاد أو عبر الأبواب.'
    ],
    referenceCode: 'معيار السلامة الكهربائية FMS.15 • معايير NFPA 99',
    severity: 'high',
    actionableStep: 'طلب تركيب مقبس رسمي معتمد عبر طلب صيانة لإدارة المرافق'
  },
  {
    id: 'prohib-4',
    category: 'prohibition',
    title: 'حظر ترك فتحات الأسقف المستعارة وأعمال الديكور مفتوحة دون تأمين',
    description: 'يُمنع فتح بلاطات الأسقف المستعارة (False Ceiling) لتمديد الكابلات أو الصيانة وتركها مكشوفة بعد انتهاء الدوام أو دون إشعار مسبق لقسم السلامة FMS.',
    subPoints: [
      'الأسقف المستعارة تشكل حاجزاً لاحتواء الدخان والحرارة، وتركها مكشوفاً يعطل فاعلية كواشف الدخان.',
      'ضرورة إعادة إغلاق البلاطات فور انتهاء العمل واستخدام ستائر الغبار (ICRA Dust Barriers).',
      'إشعار قسم السلامة لتفقد مسارات تمديدات المقاولين وحواجز الصد الناري.'
    ],
    referenceCode: 'معايير السيطرة على العدوى والسلامة ICRA / FMS.19',
    severity: 'high',
    actionableStep: 'إغلاق البلاطات بانتهاء نوبة العمل وتثبيت مانع انتشار الغبار'
  },
  {
    id: 'prohib-5',
    category: 'prohibition',
    title: 'حظر خلط أو رمي النفايات الحادة والطبية مع النفايات العادية',
    description: 'يُحظر منعاً باتاً التخلص من الحقن، المشارط، الإبر، أو الشاش الملوث بالدماء في أكياس القمامة السوداء العادية.',
    subPoints: [
      'الأدوات الحادة (الإبر والمشارط) توضع حصراً في حاويات الأمان الصلبة المقاومة للثقب (Sharp Containers).',
      'تُغلق حاوية الأدوات الحادة عند وصول الامتلاء إلى خط الثلثين (2/3) دون إعادة فتحها.',
      'النفايات الطبية الحيوية الملوثة توضع في الأكياس الصفراء الموسومة بشعار الخطر الحيوي Biohazard.'
    ],
    referenceCode: 'دليل إدارة النفايات الطبية FMS.12 • معايير PCI.18',
    severity: 'critical',
    actionableStep: 'الالتزام التام بفرز النفايات من المنبع واستخدام الأكياس المعتمدة'
  },

  // 2. إرشادات وتعليمات الطوارئ السريعة (Emergency Protocols)
  {
    id: 'emer-1',
    category: 'emergency',
    title: 'بروتوكول الاستجابة للحريق والرمز الأحمر (R.A.C.E Protocol)',
    description: 'الإجراء المعتمد والملزم لكافة كوادر مستشفى آزال عند اكتشاف حريق أو تصاعد دخان في أي قسم:',
    subPoints: [
      'R - Rescue (الإنقاذ): إخلاء أي مريض أو شخص معرض لخطر مباشر وفوري من موقع الغرفة.',
      'A - Alarm (الإنذار): كسر نقطة الإنذار اليدوية (Call Point) والاتصال فوراً بالبدالة لإعلان الرمز الأحمر (Code Red).',
      'C - Confine (الحصر): إغلاق جميع الأبواب والنوافذ لمنع انتشار الدخان والأكسجين عن بؤرة اللهب.',
      'E - Extinguish / Evacuate (المكافحة أو الإخلاء): مكافحة الحريق إذا كان صغيراً ومأمونا، أو الإخلاء فوراً وفق توجيهات قائد الفريق.'
    ],
    referenceCode: 'معايير سباهي FMS.22 • كود الحريق NFPA 101',
    severity: 'critical',
    actionableStep: 'حفظ خطوات RACE وتطبيقها دون ارتباك أثناء الفرضيات والحوادث'
  },
  {
    id: 'emer-2',
    category: 'emergency',
    title: 'قاعدة تشغيل واستخدام طفايات الحريق (P.A.S.S Rule)',
    description: 'خطوات التعامل السليم والمباشر مع طفايات الحريق اليدوية (البودرة الجافة / ثاني أكسيد الكربون CO2):',
    subPoints: [
      'P - Pull (اسحب): اسحب مسمار الأمان المعدني مع كسر شريط البلاستيك الرابط.',
      'A - Aim (وجّه): وجّه فوهة أو خرطوم القاذف نحو قاعدة اللهب وليس نحو قمة الدخان.',
      'S - Squeeze (اضغط): اضغط بقوة وثبات على مقبض التشغيل لدفع مادة الإطفاء.',
      'S - Sweep (حرّك): حرّك القاذف بمسح أفقي مستمر من جانب إلى جانب عند قاعدة الحريق.'
    ],
    referenceCode: 'دليل السلامة ومكافحة الحريق FMS-PLAN-008EA',
    severity: 'high',
    actionableStep: 'الوقوف على مسافة آمنة (2 إلى 3 أمتار) والحرص على أن يكون الظهر باتجاه مخرج آمن'
  },
  {
    id: 'emer-3',
    category: 'emergency',
    title: 'أرقام وخطوط الاتصال السريع بغرفة طوارئ مستشفى آزال',
    description: 'قنوات الاتصال المباشرة والمحمية للإبلاغ عن الحوادث، الرموز الطارئة، أو طلب التدخل الأمني والفني:',
    subPoints: [
      '📞 غرفة العمليات والتحكم المركزي (CCTV & Dispatch): تحويلة 100 / خط مباشر: 77738138',
      '🛡️ مكتب رئيس قسم السلامة وإدارة المرافق (FMS): تحويلة 202 - م/ نجيب قاسم غازي',
      '⚡ قسم الصيانة والتشغيل الطبي العام (USM/MEM): تحويلة 105',
      '🚨 قسم الطوارئ والاستقبال العام (ER Triage): تحويلة 101'
    ],
    referenceCode: 'دليل الاتصالات الطارئة FMS.25',
    severity: 'critical',
    actionableStep: 'حفظ التحويلات في لوحة الهواتف بالأقسام التمريضية والإدارية'
  },

  // 3. إرشادات السلامة المهنية والبيئية (Occupational & Environmental Safety)
  {
    id: 'occ-1',
    category: 'occupational',
    title: 'بروتوكول التعامل مع الانسكابات الكيميائية والدموية (Spill Kit Protocol)',
    description: 'إجراءات احتواء الانسكابات الخطرة في المختبرات، الصيدلية، الأقسام الطبية ومحطات التمريض:',
    subPoints: [
      'عزل منطقة الانسكاب فوراً ووضع لوحة التحذير الصفراء لمنع مرور الموظفين والمرضى.',
      'ارتداء مهمات الوقاية الشخصية الكاملة (قفازات كيميائية سميكة، نظارات واقية، كمامة N95/مخصصة).',
      'استخدام طقم الانسكاب (Spill Kit): وضع الحبال الماصة لتطويق السائل ثم نشر المسحوق الماص.',
      'جمع المخلفات بأدوات البلاستيك غير المعدنية والتخلص منها في كيس النفايات الخطرة الأصفر (Hazardous Waste).',
      'تطهير السطح بمحلول هيبوكلوريت الصوديوم المخفف (5000 ppm) للانسكابات الحيوية والدموية.'
    ],
    referenceCode: 'سياسة المواد الخطرة FMS-APP-070EA • معيار HAZMAT',
    severity: 'critical',
    actionableStep: 'التدرب العملي على استخدام طقم الانسكابات المتواجد بكل قسم'
  },
  {
    id: 'occ-2',
    category: 'occupational',
    title: 'الالتزام بمهمات الوقاية الشخصية (PPE) حسب طبيعة المخاطر',
    description: 'التقيد الصارم بارتداء أدوات الحماية الفردية لحماية الكوادر من المخاطر البيولوجية والفيزيائية والكيميائية:',
    subPoints: [
      'العناية المركزة وغرف العزل الجوي (AIIR): ارتداء كمامة N95، رداء واقٍ معقم، غطاء رأس، وواقي وجه (Face Shield).',
      'المختبر وبنك الدم: قفازات لاتكس/نيتريل، معطف معملي مقاوم، ونظارة سلامة لمنع رذاذ العينات.',
      'قسم التعقيم المركزي (CSSD) والغسيل: قفازات ثقيلة مقاومة للحرارة والمواد الكيميائية، ومريول بلاستيكي وأحذية سلامة مغلقة.',
      'ورش الصيانة والمقاولين: خوذة رأس صلبة، أحذية سلامة فولاذية (Safety Shoes)، ونظارات حماية من الشظايا.'
    ],
    referenceCode: 'معايير الصحة والمهنية OSH.7 • معيار سباهي FMS.17',
    severity: 'high',
    actionableStep: 'فحص سلامة أدوات الوقاية قبل الاستخدام واستبدال التالف فوراً'
  },
  {
    id: 'occ-3',
    category: 'occupational',
    title: 'ضوابط تصاريح العمل الساخن والأماكن المرتفعة لمقاولي الصيانة',
    description: 'يمنع بدء أي نشاط لحام، قص حراري، أو صيانة فوق مترين دون تصريح عمل مسبق وموقع من إدارة السلامة FMS:',
    subPoints: [
      'استخراج تصريح العمل الساخن (Hot Work Permit) عبر البوابة الرقمية (#contractor) قبل 24 ساعة من البدء.',
      'تأمين طفاية حريق بودرة 6 كجم على بعد مترين من موقع اللحام وتعيين مراقب حريق (Fire Watch).',
      'تغطية الأسطح القابلة للاشتعال بأغطية نسيجية مقاومة للحرارة (Fire Blankets).',
      'ارتداء حزام الأمان المزدوج (Full Body Harness) وتثبيته بنقطة ارتكاز صلبة عند العمل على السقالات أو السلالم المرتفعة.'
    ],
    referenceCode: 'نظام تصاريح العمل الآمن PTW • معيار سباهي FMS.20',
    severity: 'high',
    actionableStep: 'إيقاف أي مقاول لا يحمل تصريحاً معتمداً مع بطاقة الباركود الرسمية'
  }
];

interface SafetyGuidelinesModalProps {
  isOpen?: boolean;
  onClose: () => void;
  isStandalonePublicRoute?: boolean;
}

export const SafetyGuidelinesModal: React.FC<SafetyGuidelinesModalProps> = ({
  isOpen = true,
  onClose,
  isStandalonePublicRoute = false,
}) => {
  const [activeCategory, setActiveCategory] = useState<'all' | 'prohibition' | 'emergency' | 'occupational'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [guidelines, setGuidelines] = useState<SafetyGuidelineItem[]>(() => {
    try {
      const saved = localStorage.getItem('azal_safety_guidelines_v2');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {}
    return DEFAULT_GUIDELINES;
  });

  const [showAddForm, setShowAddForm] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newCategory, setNewCategory] = useState<'prohibition' | 'emergency' | 'occupational'>('prohibition');
  const [newRefCode, setNewRefCode] = useState('معايير سباهي CBAHI / FMS');
  const [newSeverity, setNewSeverity] = useState<'critical' | 'high' | 'standard'>('high');
  const [newSubPoints, setNewSubPoints] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Sync state to local storage when guidelines change
  useEffect(() => {
    try {
      localStorage.setItem('azal_safety_guidelines_v2', JSON.stringify(guidelines));
    } catch (e) {
      console.warn('Failed to save guidelines to storage', e);
    }
  }, [guidelines]);

  if (!isOpen) return null;

  // Filtered list
  const filteredList = guidelines.filter((item) => {
    const matchesCategory = activeCategory === 'all' || item.category === activeCategory;
    const matchesSearch =
      !searchQuery.trim() ||
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.referenceCode && item.referenceCode.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (item.subPoints && item.subPoints.some((p) => p.toLowerCase().includes(searchQuery.toLowerCase())));
    return matchesCategory && matchesSearch;
  });

  // Handle Add Guideline
  const handleAddGuideline = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newDesc.trim()) return;

    const subPointsArray = newSubPoints
      .split('\n')
      .map((p) => p.trim())
      .filter((p) => p.length > 0);

    const newItem: SafetyGuidelineItem = {
      id: `custom-${Date.now()}`,
      category: newCategory,
      title: newTitle.trim(),
      description: newDesc.trim(),
      subPoints: subPointsArray.length > 0 ? subPointsArray : undefined,
      referenceCode: newRefCode.trim() || 'معايير سباهي CBAHI',
      severity: newSeverity,
      isCustom: true,
      actionableStep: 'المتابعة والتنفيذ اليومي الفوري في القسم الطبي'
    };

    setGuidelines([newItem, ...guidelines]);
    setNewTitle('');
    setNewDesc('');
    setNewSubPoints('');
    setShowAddForm(false);
  };

  // Handle Delete Guideline
  const handleDeleteGuideline = (id: string) => {
    if (window.confirm('هل أنت متأكد من حذف هذا التوجيه؟')) {
      setGuidelines(guidelines.filter((g) => g.id !== id));
    }
  };

  // Reset to Defaults
  const handleResetDefaults = () => {
    if (window.confirm('هل تريد استعادة قائمة التحذيرات والإرشادات المعيارية الرسمية لمستشفى آزال؟')) {
      setGuidelines(DEFAULT_GUIDELINES);
      localStorage.removeItem('azal_safety_guidelines_v2');
    }
  };

  // Official Institutional A4 Wall-Poster Print Handler
  const handlePrintOfficialA4 = () => {
    const dateStr = new Date().toLocaleDateString('ar-EG', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    const prohibitionsHtml = guidelines
      .filter((g) => g.category === 'prohibition')
      .map(
        (item, idx) => `
        <div style="background:#fff1f2; border-right:4px solid #e11d48; padding:10px 14px; margin-bottom:8px; border-radius:4px;">
          <div style="font-weight:900; font-size:12.5px; color:#9f1239; margin-bottom:3px;">
            ${idx + 1}. ${item.title} <span style="font-size:10px; background:#ffe4e6; color:#be123c; padding:2px 6px; border-radius:3px; font-family:sans-serif; margin-right:4px;">[${item.referenceCode || 'CBAHI'}]</span>
          </div>
          <p style="font-size:11px; color:#334155; margin:0 0 4px 0; line-height:1.5;">${item.description}</p>
          ${
            item.subPoints && item.subPoints.length > 0
              ? `<ul style="margin:2px 0 0 16px; padding:0; font-size:10.5px; color:#475569; line-height:1.4;">
                  ${item.subPoints.map((sp) => `<li>${sp}</li>`).join('')}
                 </ul>`
              : ''
          }
        </div>
      `
      )
      .join('');

    const emergencyHtml = guidelines
      .filter((g) => g.category === 'emergency')
      .map(
        (item, idx) => `
        <div style="background:#fef2f2; border-right:4px solid #dc2626; padding:10px 14px; margin-bottom:8px; border-radius:4px;">
          <div style="font-weight:900; font-size:12.5px; color:#991b1b; margin-bottom:3px;">
            ${idx + 1}. ${item.title}
          </div>
          <p style="font-size:11px; color:#334155; margin:0 0 4px 0; line-height:1.5;">${item.description}</p>
          ${
            item.subPoints && item.subPoints.length > 0
              ? `<ul style="margin:2px 0 0 16px; padding:0; font-size:10.5px; color:#475569; line-height:1.4;">
                  ${item.subPoints.map((sp) => `<li>${sp}</li>`).join('')}
                 </ul>`
              : ''
          }
        </div>
      `
      )
      .join('');

    const occupationalHtml = guidelines
      .filter((g) => g.category === 'occupational')
      .map(
        (item, idx) => `
        <div style="background:#f0fdf4; border-right:4px solid #16a34a; padding:10px 14px; margin-bottom:8px; border-radius:4px;">
          <div style="font-weight:900; font-size:12.5px; color:#166534; margin-bottom:3px;">
            ${idx + 1}. ${item.title}
          </div>
          <p style="font-size:11px; color:#334155; margin:0 0 4px 0; line-height:1.5;">${item.description}</p>
          ${
            item.subPoints && item.subPoints.length > 0
              ? `<ul style="margin:2px 0 0 16px; padding:0; font-size:10.5px; color:#475569; line-height:1.4;">
                  ${item.subPoints.map((sp) => `<li>${sp}</li>`).join('')}
                 </ul>`
              : ''
          }
        </div>
      `
      )
      .join('');

    const bodyHtml = `
      <div style="direction:rtl; font-family:'Cairo', 'Tajawal', Tahoma, sans-serif; color:#0f172a; line-height:1.5;">
        
        <!-- Header Banner Notice -->
        <div style="background:#f8fafc; border:2px solid #0f766e; border-radius:6px; padding:12px 16px; margin-bottom:14px; display:flex; justify-content:space-between; align-items:center;">
          <div>
            <div style="font-size:15px; font-weight:900; color:#0f766e;">دليل إرشادات وتحذيرات السلامة والجاهزية المهنية السريع</div>
            <div style="font-size:11px; color:#475569;">وثيقة معتمدة وموجهة للتعليق في لوحات الإعلانات بجميع محطات التمريض، الأقسام الطبية، وغرف العمليات</div>
          </div>
          <div style="text-align:left; font-size:10px; font-family:monospace; color:#64748b;">
            تاريخ الإصدار: ${dateStr}<br/>
            كود المعيار: AZAL-FMS-SAFETY-GUIDE-2026
          </div>
        </div>

        <!-- Section 1: Strict Prohibitions -->
        <div style="margin-bottom:14px;">
          <div style="background:#881337; color:#fff; font-weight:900; font-size:12px; padding:5px 10px; border-radius:4px; margin-bottom:6px; display:inline-block;">
            🛑 أولاً: التحذيرات والمحظورات العاجلة والقطعية (Strict Prohibitions)
          </div>
          ${prohibitionsHtml}
        </div>

        <!-- Section 2: Emergency Protocols (RACE & PASS) -->
        <div style="margin-bottom:14px;">
          <div style="background:#991b1b; color:#fff; font-weight:900; font-size:12px; padding:5px 10px; border-radius:4px; margin-bottom:6px; display:inline-block;">
            📋 ثانياً: بروتوكول طوارئ الحريق والاستجابة الفورية (RACE & PASS Protocols)
          </div>
          ${emergencyHtml}
        </div>

        <!-- Section 3: Occupational & Environmental Safety -->
        <div style="margin-bottom:16px;">
          <div style="background:#166534; color:#fff; font-weight:900; font-size:12px; padding:5px 10px; border-radius:4px; margin-bottom:6px; display:inline-block;">
            ☣️ ثالثاً: إرشادات السلامة المهنية والبيئية والمهمات الوقائية (Occupational Safety)
          </div>
          ${occupationalHtml}
        </div>

        <!-- Quick Emergency Contacts Strip -->
        <div style="background:#fffbeb; border:1px dashed #d97706; padding:8px 12px; border-radius:6px; margin-bottom:14px; font-size:11px; color:#92400e; font-weight:bold; display:flex; justify-content:space-around;">
          <span>📞 غرفة العمليات والطوارئ: تحويلة 100 / خط مباشر: 77738138</span>
          <span>🛡️ إدارة السلامة FMS: تحويلة 202</span>
          <span>⚡ صيانة المرافق والتشغيل: تحويلة 105</span>
        </div>

        <!-- Official Department Endorsement & Signatures Box -->
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; border-top:2px solid #0f766e; padding-top:10px; margin-top:14px;">
          <div style="font-size:11px; color:#334155;">
            <strong>توجيه إداري ملزم:</strong> يجب على مسؤولي الأقسام ورؤساء التمريض إحاطة جميع الكوادر العاملة بهذه التوجيهات وضمان التزام الجميع بها في كل نوبة عمل، وتعتبر جزءاً لا يتجزأ من متطلبات تقييم الاعتماد الوطني (CBAHI).
          </div>
          <div style="text-align:left; font-size:11px; color:#0f172a;">
            <div style="font-weight:900; color:#0f766e; font-size:12px;">مستشفى آزال - الرعاية الكاملة</div>
            <div style="font-weight:bold; margin-top:2px;">رئيس قسم السلامة وإدارة المرافق (FMS)</div>
            <div style="font-weight:900; font-size:13px; color:#0f172a; margin-top:4px;">م/ نجيب قاسم غازي</div>
            <div style="font-size:9.5px; color:#64748b; font-family:monospace;">التوقيع والاعتماد الرسمي المعتمد • CBAHI Verified</div>
          </div>
        </div>

      </div>
    `;

    executeSmartPrint(bodyHtml, {
      title: 'دليل إرشادات وتحذيرات السلامة والجاهزية المهنية السريع',
      subtitle: 'مستشفى آزال - الرعاية الكاملة • إدارة الأمن والسلامة وإدارة المرافق (FMS) • معايير سباهي CBAHI',
      refNumber: 'AZAL-FMS-SAFETY-GUIDELINES-2026',
      inspectorName: 'م/ نجيب قاسم غازي (رئيس قسم السلامة وإدارة المرافق FMS)'
    });
  };

  // Copy quick link
  const handleCopyPortalLink = () => {
    const url = `${window.location.origin}/#guidelines`;
    navigator.clipboard.writeText(url).then(() => {
      setCopiedId('url');
      setTimeout(() => setCopiedId(null), 2000);
    });
  };

  // Share via WhatsApp
  const handleShareWhatsApp = () => {
    const text = `🚨 *دليل إرشادات وتحذيرات السلامة السريع - مستشفى آزال (الرعاية الكاملة)*\n\nإشراف: م/ نجيب قاسم غازي (رئيس قسم السلامة FMS)\nللاطلاع على التحذيرات وبروتوكولات الطوارئ (RACE & PASS):\n${window.location.origin}/#guidelines`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <div
      className={
        isStandalonePublicRoute
          ? 'min-h-screen bg-slate-950 text-slate-100 flex flex-col select-none font-sans'
          : 'fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto animate-fadeIn select-none'
      }
      dir="rtl"
    >
      {/* Top Universal Back Bar for Standalone Route */}
      {isStandalonePublicRoute && (
        <GlobalPortalBackBar
          title="مركز التعليمات والإرشادات والتحذيرات (Safety Guidelines & Hazard Alerts)"
          subtitle="مستشفى آزال - الرعاية الكاملة • معايير سباهي CBAHI FMS & NFPA"
          showServicesLink={true}
          onCustomBack={() => {
            if (typeof window !== 'undefined') {
              window.location.hash = '#services';
            }
            onClose();
          }}
        />
      )}

      <div
        className={`w-full bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col ${
          isStandalonePublicRoute
            ? 'max-w-5xl mx-auto my-4 flex-1'
            : 'max-w-5xl my-auto max-h-[92vh]'
        }`}
      >
        {/* Modal Top Header */}
        <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border-b border-slate-800 p-4 sm:p-5 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/95 backdrop-blur-sm rounded-2xl shadow-md border border-slate-200 shrink-0">
              <AzalLogo variant="horizontal" size="sm" transparent={true} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-rose-950 text-rose-300 border border-rose-800/60 animate-pulse">
                  ⚠️ معايير سباهي CBAHI
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-teal-950 text-teal-300 border border-teal-800/60">
                  إدارة المرافق والسلامة FMS
                </span>
              </div>
              <h2 className="text-base sm:text-lg font-black text-slate-100 tracking-tight mt-0.5">
                مركز التعليمات والإرشادات والتحذيرات (Safety Guidelines & Alerts)
              </h2>
              <p className="text-xs text-slate-400">
                الدليل المعتمد للتحذيرات والمحظورات العاجلة وبروتوكولات طوارئ الحريق والسلامة المهنية
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrintOfficialA4}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white text-xs font-black shadow-lg shadow-teal-950 transition active:scale-95 cursor-pointer"
              title="طباعة وتحميل دليل إرشادات السلامة السريع A4 موقع ومعتمد للتعليق بالأقسام"
            >
              <Printer className="w-4 h-4" />
              <span className="hidden sm:inline">طباعة الدليل المعتمد A4</span>
              <span className="sm:hidden">طباعة A4</span>
            </button>

            <button
              type="button"
              onClick={handleShareWhatsApp}
              className="p-2 rounded-xl bg-emerald-950 hover:bg-emerald-900 text-emerald-400 border border-emerald-800 transition active:scale-95 cursor-pointer"
              title="مشاركة الدليل عبر واتساب"
            >
              <Share2 className="w-4 h-4" />
            </button>

            {!isStandalonePublicRoute && (
              <button
                type="button"
                onClick={onClose}
                className="p-2 rounded-xl bg-slate-800 hover:bg-rose-950 hover:text-rose-400 text-slate-400 border border-slate-700 transition active:scale-95 cursor-pointer"
                title="إغلاق النافذة"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>

        {/* Action Controls & Navigation Tabs */}
        <div className="bg-slate-950/80 border-b border-slate-800 px-4 sm:px-6 py-3 space-y-3">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            {/* 3 Main Interactive Category Tabs */}
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setActiveCategory('all')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                  activeCategory === 'all'
                    ? 'bg-teal-600 text-white shadow-md'
                    : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                <span>الكل ({guidelines.length})</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveCategory('prohibition')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 ${
                  activeCategory === 'prohibition'
                    ? 'bg-rose-600 text-white shadow-md shadow-rose-950'
                    : 'bg-slate-900 text-rose-300 hover:text-white border border-rose-900/40'
                }`}
              >
                <Ban className="w-3.5 h-3.5" />
                <span>🛑 التحذيرات والمحظورات</span>
                <span className="px-1.5 py-0.2 rounded-full bg-black/40 text-[10px]">
                  {guidelines.filter((g) => g.category === 'prohibition').length}
                </span>
              </button>

              <button
                type="button"
                onClick={() => setActiveCategory('emergency')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 ${
                  activeCategory === 'emergency'
                    ? 'bg-amber-600 text-slate-950 shadow-md shadow-amber-950'
                    : 'bg-slate-900 text-amber-300 hover:text-white border border-amber-900/40'
                }`}
              >
                <Flame className="w-3.5 h-3.5" />
                <span>📋 بروتوكولات الطوارئ (RACE/PASS)</span>
                <span className="px-1.5 py-0.2 rounded-full bg-black/40 text-[10px]">
                  {guidelines.filter((g) => g.category === 'emergency').length}
                </span>
              </button>

              <button
                type="button"
                onClick={() => setActiveCategory('occupational')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition flex items-center gap-1.5 ${
                  activeCategory === 'occupational'
                    ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950'
                    : 'bg-slate-900 text-emerald-300 hover:text-white border border-emerald-900/40'
                }`}
              >
                <ShieldAlert className="w-3.5 h-3.5" />
                <span>☣️ السلامة المهنية والبيئية</span>
                <span className="px-1.5 py-0.2 rounded-full bg-black/40 text-[10px]">
                  {guidelines.filter((g) => g.category === 'occupational').length}
                </span>
              </button>
            </div>

            {/* Admin Add New Guideline Button */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowAddForm(!showAddForm)}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 text-xs font-bold border border-teal-700/50 flex items-center gap-1.5 transition active:scale-95"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{showAddForm ? 'إلغاء الإضافة' : 'إضافة توجيه جديد'}</span>
              </button>

              <button
                type="button"
                onClick={handleCopyPortalLink}
                className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white border border-slate-700 transition"
                title="نسخ رابط النافذة (#guidelines)"
              >
                {copiedId === 'url' ? <Check className="w-4 h-4 text-emerald-400" /> : <ExternalLink className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Search bar & Live Filter */}
          <div className="relative">
            <Search className="w-4 h-4 absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث في التحذيرات، الكود (FMS.23)، بروتوكول RACE، أو طفايات الحريق PASS..."
              className="w-full pl-3 pr-10 py-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-100 placeholder-slate-500 text-xs focus:outline-none focus:border-teal-500 focus:ring-1 focus:ring-teal-500 transition"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
              >
                مسح
              </button>
            )}
          </div>
        </div>

        {/* Scrollable Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5 bg-slate-950/40">

          {/* Admin Add Form Drawer */}
          {showAddForm && (
            <form
              onSubmit={handleAddGuideline}
              className="bg-slate-900 border-2 border-teal-500/60 rounded-2xl p-4 sm:p-5 space-y-4 shadow-xl animate-in slide-in-from-top duration-200"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-teal-950 text-teal-400 border border-teal-700 flex items-center justify-center font-bold">
                    <Plus className="w-4 h-4" />
                  </div>
                  <h3 className="text-sm font-bold text-slate-100">
                    إضافة تعليمات أو تحذير سلامة مخصص (لوحة المسؤول)
                  </h3>
                </div>
                <span className="text-[11px] text-teal-400 font-mono">
                  إشراف: م/ نجيب قاسم غازي
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">التصنيف الرئيسي:</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 focus:border-teal-500"
                  >
                    <option value="prohibition">🛑 محظورات عاجلة (Prohibition)</option>
                    <option value="emergency">📋 بروتوكول طوارئ (Emergency)</option>
                    <option value="occupational">☣️ سلامة مهنية وبيئية (Occupational)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">مستوى الأهمية والخطورة:</label>
                  <select
                    value={newSeverity}
                    onChange={(e) => setNewSeverity(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 focus:border-teal-500"
                  >
                    <option value="critical">🚨 حرج ومباشر (Critical)</option>
                    <option value="high">⚠️ مرتفع الأهمية (High)</option>
                    <option value="standard">ℹ️ إرشادي قياسي (Standard)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">كود المعيار المرجعي:</label>
                  <input
                    type="text"
                    value={newRefCode}
                    onChange={(e) => setNewRefCode(e.target.value)}
                    placeholder="مثال: CBAHI FMS.23 أو OSH"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 focus:border-teal-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 text-xs font-semibold mb-1">
                  عنوان التوجيه / المحظور:
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="مثال: حظر ترك إسطوانات الغازات الطبية دون سلاسل تثبيت أمان"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 text-xs focus:border-teal-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 text-xs font-semibold mb-1">
                  الشرح التفصيلي للتعليمات:
                </label>
                <textarea
                  rows={2}
                  required
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="اكتب التوجيه الواجب تنفيذه من قبل الكوادر..."
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 text-xs focus:border-teal-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 text-xs font-semibold mb-1">
                  بنود تفصيلية أو إجراءات تنفيذية (سطر لكل بند):
                </label>
                <textarea
                  rows={2}
                  value={newSubPoints}
                  onChange={(e) => setNewSubPoints(e.target.value)}
                  placeholder="• البند الأول&#10;• البند الثاني&#10;• البند الثالث"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 text-xs focus:border-teal-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold shadow-md shadow-teal-950"
                >
                  حفظ ونشر التوجيه
                </button>
              </div>
            </form>
          )}

          {/* Quick Notice Banner */}
          <div className="bg-gradient-to-r from-teal-950/60 via-slate-900 to-slate-900 border border-teal-800/40 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs shadow-md">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-teal-950 border border-teal-700 text-teal-400 flex items-center justify-center shrink-0">
                <BookmarkCheck className="w-5 h-5" />
              </div>
              <div>
                <strong className="text-teal-300 font-bold block">
                  دليل معتمد للمستشفى • معايير سباهي CBAHI FMS
                </strong>
                <span className="text-slate-300">
                  إشراف وتوقيع: <strong>م/ نجيب قاسم غازي</strong> (رئيس قسم السلامة وإدارة المرافق FMS)
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleResetDefaults}
                className="text-[11px] text-slate-400 hover:text-slate-200 underline"
                title="استعادة الإرشادات الافتراضية"
              >
                استعادة الافتراضيات
              </button>
            </div>
          </div>

          {/* RACE & PASS Visual Cards Banner if on Emergency or All */}
          {(activeCategory === 'all' || activeCategory === 'emergency') && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* RACE Protocol Visual Card */}
              <div className="bg-gradient-to-br from-rose-950/60 via-slate-900 to-slate-900 border border-rose-800/60 rounded-2xl p-4.5 sm:p-5 space-y-3 shadow-xl">
                <div className="flex items-center justify-between border-b border-rose-900/40 pb-2.5">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-rose-600 text-white flex items-center justify-center font-black shadow-md">
                      <Flame className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-black text-sm text-rose-200">
                        بروتوكول الاستجابة للحريق (R.A.C.E)
                      </h4>
                      <span className="text-[10px] text-rose-400 font-mono">
                        معتمد سباهي CBAHI FMS.22
                      </span>
                    </div>
                  </div>
                  <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800/50">
                    الرمز الأحمر Code Red
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div className="p-2.5 rounded-xl bg-slate-950/70 border border-rose-900/40 space-y-1">
                    <div className="font-black text-rose-400 flex items-center gap-1.5">
                      <span className="w-5 h-5 rounded-full bg-rose-600 text-white text-[11px] flex items-center justify-center font-mono">
                        R
                      </span>
                      <span>Rescue (الإنقاذ)</span>
                    </div>
                    <p className="text-[11px] text-slate-300 leading-snug">
                      إنقاذ أي شخص معرض لخطر مباشر من موقع الحريق فوراً.
                    </p>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-950/70 border border-rose-900/40 space-y-1">
                    <div className="font-black text-amber-400 flex items-center gap-1.5">
                      <span className="w-5 h-5 rounded-full bg-amber-600 text-slate-950 text-[11px] flex items-center justify-center font-mono">
                        A
                      </span>
                      <span>Alarm (الإنذار)</span>
                    </div>
                    <p className="text-[11px] text-slate-300 leading-snug">
                      كسر زجاج الإنذار والاتصال بالبدالة (تحويلة 100) لإعلان الكود.
                    </p>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-950/70 border border-rose-900/40 space-y-1">
                    <div className="font-black text-blue-400 flex items-center gap-1.5">
                      <span className="w-5 h-5 rounded-full bg-blue-600 text-white text-[11px] flex items-center justify-center font-mono">
                        C
                      </span>
                      <span>Confine (الحصر)</span>
                    </div>
                    <p className="text-[11px] text-slate-300 leading-snug">
                      إغلاق الأبواب والنوافذ لمنع وصول الهواء وتفشي الدخان.
                    </p>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-950/70 border border-rose-900/40 space-y-1">
                    <div className="font-black text-emerald-400 flex items-center gap-1.5">
                      <span className="w-5 h-5 rounded-full bg-emerald-600 text-white text-[11px] flex items-center justify-center font-mono">
                        E
                      </span>
                      <span>Extinguish (المكافحة/الإخلاء)</span>
                    </div>
                    <p className="text-[11px] text-slate-300 leading-snug">
                      إخماد الحريق الصغير بالطفاية، أو الإخلاء فوراً إن تعذر.
                    </p>
                  </div>
                </div>
              </div>

              {/* PASS Rule Visual Card */}
              <div className="bg-gradient-to-br from-amber-950/50 via-slate-900 to-slate-900 border border-amber-800/60 rounded-2xl p-4.5 sm:p-5 space-y-3 shadow-xl">
                <div className="flex items-center justify-between border-b border-amber-900/40 pb-2.5">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-black shadow-md">
                      <Zap className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-black text-sm text-amber-200">
                        قاعدة استخدام طفايات الحريق (P.A.S.S)
                      </h4>
                      <span className="text-[10px] text-amber-400 font-mono">
                        طفايات البودرة وCO2
                      </span>
                    </div>
                  </div>
                  <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800/50">
                    تشغيل الطفاية
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div className="p-2.5 rounded-xl bg-slate-950/70 border border-amber-900/40 space-y-1">
                    <div className="font-black text-amber-400 flex items-center gap-1.5">
                      <span className="w-5 h-5 rounded-full bg-amber-500 text-slate-950 text-[11px] flex items-center justify-center font-mono">
                        P
                      </span>
                      <span>Pull (اسحب)</span>
                    </div>
                    <p className="text-[11px] text-slate-300 leading-snug">
                      اسحب مسمار الأمان المعدني مع نزع شريط التثبيت.
                    </p>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-950/70 border border-amber-900/40 space-y-1">
                    <div className="font-black text-teal-400 flex items-center gap-1.5">
                      <span className="w-5 h-5 rounded-full bg-teal-500 text-slate-950 text-[11px] flex items-center justify-center font-mono">
                        A
                      </span>
                      <span>Aim (وجّه)</span>
                    </div>
                    <p className="text-[11px] text-slate-300 leading-snug">
                      وجّه قاذف الطفاية نحو قاعدة اللهب من مسافة 2-3 أمتار.
                    </p>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-950/70 border border-amber-900/40 space-y-1">
                    <div className="font-black text-indigo-400 flex items-center gap-1.5">
                      <span className="w-5 h-5 rounded-full bg-indigo-500 text-white text-[11px] flex items-center justify-center font-mono">
                        S
                      </span>
                      <span>Squeeze (اضغط)</span>
                    </div>
                    <p className="text-[11px] text-slate-300 leading-snug">
                      اضغط على مقبض التشغيل بقوة لتفريغ مادة الإطفاء.
                    </p>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-950/70 border border-amber-900/40 space-y-1">
                    <div className="font-black text-cyan-400 flex items-center gap-1.5">
                      <span className="w-5 h-5 rounded-full bg-cyan-500 text-slate-950 text-[11px] flex items-center justify-center font-mono">
                        S
                      </span>
                      <span>Sweep (حرّك)</span>
                    </div>
                    <p className="text-[11px] text-slate-300 leading-snug">
                      حرّك القاذف يميناً ويساراً بتغطية أفقية شاملة للقاعدة.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Guidelines Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredList.map((item) => {
              const isProhib = item.category === 'prohibition';
              const isEmerg = item.category === 'emergency';
              const isOcc = item.category === 'occupational';

              const cardBorderColor = isProhib
                ? 'border-rose-800/60 hover:border-rose-500'
                : isEmerg
                ? 'border-amber-800/60 hover:border-amber-500'
                : 'border-emerald-800/60 hover:border-emerald-500';

              const badgeColor = isProhib
                ? 'bg-rose-950 text-rose-300 border-rose-800/60'
                : isEmerg
                ? 'bg-amber-950 text-amber-300 border-amber-800/60'
                : 'bg-emerald-950 text-emerald-300 border-emerald-800/60';

              const headerIcon = isProhib ? (
                <Ban className="w-5 h-5 text-rose-400" />
              ) : isEmerg ? (
                <Flame className="w-5 h-5 text-amber-400" />
              ) : (
                <ShieldAlert className="w-5 h-5 text-emerald-400" />
              );

              return (
                <div
                  key={item.id}
                  className={`bg-slate-900/90 border ${cardBorderColor} rounded-2xl p-4.5 sm:p-5 flex flex-col justify-between space-y-3.5 shadow-lg transition-all duration-150 hover:shadow-xl`}
                >
                  <div className="space-y-2.5">
                    {/* Top Meta Header */}
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-xl bg-slate-950 flex items-center justify-center border border-slate-800">
                          {headerIcon}
                        </div>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${badgeColor}`}>
                          {isProhib ? '🛑 محظور قطعي' : isEmerg ? '📋 طوارئ وحريق' : '☣️ سلامة مهنية'}
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        {item.referenceCode && (
                          <span className="text-[10px] font-mono text-slate-400 bg-slate-950/90 px-2 py-0.5 rounded border border-slate-800">
                            {item.referenceCode}
                          </span>
                        )}
                        {item.isCustom && (
                          <button
                            type="button"
                            onClick={() => handleDeleteGuideline(item.id)}
                            className="text-rose-400 hover:text-rose-300 p-1 rounded hover:bg-rose-950"
                            title="حذف هذا التوجيه"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Title & Description */}
                    <div>
                      <h3 className="font-bold text-sm text-slate-100 leading-snug">
                        {item.title}
                      </h3>
                      <p className="text-xs text-slate-300 leading-relaxed mt-1">
                        {item.description}
                      </p>
                    </div>

                    {/* Sub Points */}
                    {item.subPoints && item.subPoints.length > 0 && (
                      <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800/80 space-y-1">
                        {item.subPoints.map((pt, pIdx) => (
                          <div key={pIdx} className="flex items-start gap-1.5 text-[11px] text-slate-300">
                            <span className="text-teal-400 font-bold shrink-0 mt-0.5">•</span>
                            <span className="leading-snug">{pt}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Actionable Footer */}
                  {item.actionableStep && (
                    <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                      <div className="flex items-center gap-1.5 text-teal-300 font-semibold">
                        <CheckCircle2 className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                        <span>{item.actionableStep}</span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {filteredList.length === 0 && (
            <div className="text-center py-12 bg-slate-900/40 rounded-2xl border border-slate-800 space-y-2">
              <Info className="w-8 h-8 text-slate-500 mx-auto" />
              <h4 className="text-sm font-bold text-slate-300">لا توجد نتائج مطابقة لبحثك</h4>
              <p className="text-xs text-slate-500">جرب البحث بكلمات مختلفة أو قم بإلغاء التصفية</p>
            </div>
          )}

          {/* Quick Internal Emergency Contacts Strip */}
          <div className="bg-gradient-to-r from-rose-950/40 via-slate-900 to-slate-950 border border-rose-900/50 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs shadow-lg">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-rose-600 text-white flex items-center justify-center font-bold shrink-0 shadow-md">
                <Phone className="w-4 h-4 animate-bounce" />
              </div>
              <div>
                <strong className="text-rose-200 font-bold block">
                  خطوط الطوارئ المباشرة بمستشفى آزال
                </strong>
                <span className="text-slate-400 text-[11px]">
                  العمليات والتحكم: تحويلة 100 • إدارة السلامة FMS: تحويلة 202 • الصيانة العامة: تحويلة 105
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <a
                href="tel:77738138"
                className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold flex items-center gap-1.5 transition active:scale-95 shadow-sm"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>اتصال مباشر (77738138)</span>
              </a>
            </div>
          </div>
        </div>

        {/* Modal Bottom Institutional Footer */}
        <div className="bg-slate-950 border-t border-slate-800 p-3 sm:p-4 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-teal-400" />
            <span>
              نظام إدارة السلامة والمرافق FMS • رئيس القسم: <strong>م/ نجيب قاسم غازي</strong>
            </span>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handlePrintOfficialA4}
              className="text-xs text-teal-300 hover:text-white font-bold underline flex items-center gap-1"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>تحميل وثيقة A4 المعتمدة</span>
            </button>
            <span className="text-slate-600">|</span>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold"
            >
              إغلاق
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
