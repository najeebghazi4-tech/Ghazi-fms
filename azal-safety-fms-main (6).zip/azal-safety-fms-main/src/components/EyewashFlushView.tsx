import React, { useState, useEffect } from 'react';
import { 
  Droplets, 
  Plus, 
  Search, 
  Filter, 
  Printer, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  ShieldCheck, 
  Sparkles, 
  X,
  Play,
  RotateCcw,
  Building2,
  Calendar,
  AlertCircle
} from 'lucide-react';
import { EyewashFlushRecord, StaffUser } from '../types';
import { AZAL_EYEWASH_STATIONS, INITIAL_EYEWASH_FLUSH_LOGS, EyewashStation } from '../data/azalEyewashData';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';
import { executeSmartPrint } from '../utils/printUtils';
import { AzalLogo } from './AzalLogo';

interface EyewashFlushViewProps {
  currentUser: StaffUser;
  onLogAudit: (action: string, actionAr: string, details: string) => void;
}

export const EyewashFlushView: React.FC<EyewashFlushViewProps> = ({
  currentUser,
  onLogAudit
}) => {
  const [stations, setStations] = useState<EyewashStation[]>(() => {
    try {
      const saved = localStorage.getItem('azal_eyewash_stations_v1');
      return saved ? JSON.parse(saved) : AZAL_EYEWASH_STATIONS;
    } catch {
      return AZAL_EYEWASH_STATIONS;
    }
  });

  const [logs, setLogs] = useState<EyewashFlushRecord[]>(() => {
    try {
      const saved = localStorage.getItem('azal_eyewash_logs_v1');
      return saved ? JSON.parse(saved) : INITIAL_EYEWASH_FLUSH_LOGS;
    } catch {
      return INITIAL_EYEWASH_FLUSH_LOGS;
    }
  });

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedStation, setSelectedStation] = useState<EyewashStation | null>(null);
  const [showLogModal, setShowLogModal] = useState(false);

  // Flush Checklist Form State
  const [flushDurationSeconds, setFlushDurationSeconds] = useState(180); // 3 minutes standard
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [timerSecondsLeft, setTimerSecondsLeft] = useState(180);
  const [waterClarity, setWaterClarity] = useState<'clean_clear' | 'sediment_cloudy' | 'rust_tint'>('clean_clear');
  const [waterTemperature, setWaterTemperature] = useState<'tepid' | 'cold' | 'hot'>('tepid');
  const [waterFlowAdequate, setWaterFlowAdequate] = useState(true);
  const [dualSprayPatternOk, setDualSprayPatternOk] = useState(true);
  const [dustCoversIntact, setDustCoversIntact] = useState(true);
  const [stayOpenValveOk, setStayOpenValveOk] = useState(true);
  const [pathwayUnobstructed, setPathwayUnobstructed] = useState(true);
  const [drainageWorking, setDrainageWorking] = useState(true);
  const [signageVisible, setSignageVisible] = useState(true);
  const [inspectorName, setInspectorName] = useState(currentUser.name || 'م/ نجيب غازي');
  const [notes, setNotes] = useState('تم تدفق المياه لمدة 3 دقائق كاملة للتخلص من الرواسب والصدأ والتأكد من نقاء وجاهزية المحطة وفقاً لمعايير ANSI Z358.1.');

  useEffect(() => {
    try {
      localStorage.setItem('azal_eyewash_stations_v1', JSON.stringify(stations));
    } catch (e) {
      console.warn('Failed to save eyewash stations', e);
    }
  }, [stations]);

  useEffect(() => {
    try {
      localStorage.setItem('azal_eyewash_logs_v1', JSON.stringify(logs));
    } catch (e) {
      console.warn('Failed to save eyewash logs', e);
    }
  }, [logs]);

  // 180-second Timer Logic
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isTimerRunning && timerSecondsLeft > 0) {
      interval = setInterval(() => {
        setTimerSecondsLeft(prev => prev - 1);
      }, 1000);
    } else if (timerSecondsLeft === 0 && isTimerRunning) {
      setIsTimerRunning(false);
      triggerSuccessFeedback();
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isTimerRunning, timerSecondsLeft]);

  const openFlushModal = (station: EyewashStation) => {
    setSelectedStation(station);
    setTimerSecondsLeft(180);
    setIsTimerRunning(false);
    setWaterClarity('clean_clear');
    setWaterTemperature('tepid');
    setWaterFlowAdequate(true);
    setDualSprayPatternOk(true);
    setDustCoversIntact(true);
    setStayOpenValveOk(true);
    setPathwayUnobstructed(true);
    setDrainageWorking(true);
    setSignageVisible(true);
    setNotes('تم تدفق المياه لمدة 3 دقائق كاملة للتخلص من الرواسب والتأكد من نقاء وجاهزية المحطة وفق معايير ANSI Z358.1.');
    setShowLogModal(true);
  };

  const handleSaveFlushRecord = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStation) return;

    const isAllPass = waterFlowAdequate && dualSprayPatternOk && dustCoversIntact && stayOpenValveOk && pathwayUnobstructed && drainageWorking && signageVisible && waterClarity === 'clean_clear';
    const recordStatus = isAllPass ? 'pass' : (waterFlowAdequate ? 'minor_issue' : 'out_of_service');

    const newRecord: EyewashFlushRecord = {
      id: `EW-FLUSH-${Date.now()}`,
      stationId: selectedStation.stationCode,
      stationCode: selectedStation.stationCode,
      stationName: selectedStation.department,
      location: selectedStation.locationDetail,
      department: selectedStation.department,
      flushDate: new Date().toISOString().split('T')[0],
      flushTime: new Date().toLocaleTimeString('ar-YE', { hour: '2-digit', minute: '2-digit' }),
      flowDurationSeconds: 180 - timerSecondsLeft > 0 ? 180 - timerSecondsLeft : 180,
      flushDurationSeconds: 180,
      waterClarity,
      waterTemperature,
      waterFlowAdequate,
      dualSprayPatternOk,
      dustCoversOperational: dustCoversIntact,
      dustCoversIntact,
      stayOpenValveOk,
      accessUnobstructed: pathwayUnobstructed,
      pathwayUnobstructed,
      signageVisible,
      drainageWorking,
      overallStatus: recordStatus,
      status: recordStatus,
      inspectorName,
      inspectorRole: 'مسؤول السلامة والصحة المهنية',
      notes,
      createdAt: Date.now(),
      synced: true
    };

    setLogs(prev => [newRecord, ...prev]);

    // Update Station status and lastFlushDate
    setStations(prev => prev.map(st => {
      if (st.id === selectedStation.id) {
        return {
          ...st,
          lastFlushDate: new Date().toISOString().split('T')[0],
          status: recordStatus === 'pass' ? 'compliant' : (recordStatus === 'minor_issue' ? 'due' : 'maintenance')
        };
      }
      return st;
    }));

    onLogAudit(
      'EYEWASH_WEEKLY_FLUSH',
      'فحص تدفق دوش وغسول عيون أسبوعي',
      `تم إجراء وتوثيق فحص التدفق الأسبوعي لمحطة ${selectedStation.stationCode} (${selectedStation.department}) - النتيجة: ${recordStatus === 'pass' ? 'مطابق وناجح' : 'ملاحظات صيانة'}`
    );

    triggerSuccessFeedback();
    setShowLogModal(false);
  };

  // KPIs
  const totalStations = stations.length;
  const compliantStations = stations.filter(s => s.status === 'compliant').length;
  const dueStations = stations.filter(s => s.status === 'due').length;
  const maintenanceStations = stations.filter(s => s.status === 'maintenance').length;
  const complianceRate = totalStations > 0 ? Math.round((compliantStations / totalStations) * 100) : 100;

  // Filtered Stations
  const filteredStations = stations.filter(st => {
    const matchSearch = st.stationCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        st.department.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        st.locationDetail.toLowerCase().includes(searchTerm.toLowerCase());
    const matchStatus = statusFilter === 'all' || st.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const handlePrintReport = () => {
    const bodyHtml = `
      <div style="font-family: Cairo, sans-serif; direction: rtl; padding: 20px;">
        <div style="text-align: center; border-bottom: 2px solid #0f766e; padding-bottom: 12px; margin-bottom: 20px;">
          <h1 style="color: #0f766e; margin: 0; font-size: 20px;">مستشفى آزال النموذجي - إدارة السلامة والصحة المهنية FMS</h1>
          <h2 style="color: #334155; margin: 5px 0 0 0; font-size: 16px;">سجل الفحص الدوري الأسبوعي لمحطات غسول العيون والدش الطارئ (ANSI Z358.1 & CBAHI)</h2>
          <p style="color: #64748b; font-size: 12px; margin: 4px 0 0 0;">تاريخ استخراج التقرير: ${new Date().toLocaleDateString('ar-YE')}</p>
        </div>

        <div style="display: flex; justify-content: space-around; background: #f0fdfa; border: 1px solid #ccfbf1; padding: 12px; border-radius: 8px; margin-bottom: 20px; font-size: 13px;">
          <div>إجمالي المحطات: <strong>${totalStations}</strong></div>
          <div>المحطات المطابقة: <strong style="color: #0d9488;">${compliantStations}</strong></div>
          <div>المحطات المستحقة للفحص: <strong style="color: #d97706;">${dueStations}</strong></div>
          <div>نسبة الامتثال: <strong>${complianceRate}%</strong></div>
        </div>

        <h3 style="font-size: 14px; border-bottom: 1px solid #cbd5e1; padding-bottom: 6px;">حالة محطات غسول العيون الحالية:</h3>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 25px; font-size: 12px;">
          <thead>
            <tr style="background: #e2e8f0; color: #1e293b;">
              <th style="border: 1px solid #cbd5e1; padding: 8px;">كود المحطة</th>
              <th style="border: 1px solid #cbd5e1; padding: 8px;">القسم الطبي</th>
              <th style="border: 1px solid #cbd5e1; padding: 8px;">الموقع التفصيلي</th>
              <th style="border: 1px solid #cbd5e1; padding: 8px;">نوع المحطة</th>
              <th style="border: 1px solid #cbd5e1; padding: 8px;">آخر فحص تدفق</th>
              <th style="border: 1px solid #cbd5e1; padding: 8px;">حالة الامتثال</th>
            </tr>
          </thead>
          <tbody>
            ${stations.map(st => `
              <tr>
                <td style="border: 1px solid #cbd5e1; padding: 6px; font-weight: bold;">${st.stationCode}</td>
                <td style="border: 1px solid #cbd5e1; padding: 6px;">${st.department}</td>
                <td style="border: 1px solid #cbd5e1; padding: 6px;">${st.locationDetail}</td>
                <td style="border: 1px solid #cbd5e1; padding: 6px;">${st.type === 'combination_shower_eyewash' ? 'دش طوارئ ومحطة غسول مزدوجة' : (st.type === 'wall_mounted_eyewash' ? 'محطة جدارية' : 'مثبت على الصنبور')}</td>
                <td style="border: 1px solid #cbd5e1; padding: 6px;">${st.lastFlushDate}</td>
                <td style="border: 1px solid #cbd5e1; padding: 6px; color: ${st.status === 'compliant' ? '#0d9488' : '#e11d48'}; font-weight: bold;">
                  ${st.status === 'compliant' ? 'مطابق ومعتمد' : (st.status === 'due' ? 'مستحق الفحص' : 'صيانة')}
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <h3 style="font-size: 14px; border-bottom: 1px solid #cbd5e1; padding-bottom: 6px;">آخر عمليات الفحص والتدفق الموثقة (السجل التاريخي):</h3>
        <table style="width: 100%; border-collapse: collapse; font-size: 11px;">
          <thead>
            <tr style="background: #f1f5f9;">
              <th style="border: 1px solid #cbd5e1; padding: 6px;">المحطة</th>
              <th style="border: 1px solid #cbd5e1; padding: 6px;">تاريخ الفحص</th>
              <th style="border: 1px solid #cbd5e1; padding: 6px;">مدة التدفق</th>
              <th style="border: 1px solid #cbd5e1; padding: 6px;">نقاء المياه</th>
              <th style="border: 1px solid #cbd5e1; padding: 6px;">الأغطية والصمامات</th>
              <th style="border: 1px solid #cbd5e1; padding: 6px;">المسار واللافتات</th>
              <th style="border: 1px solid #cbd5e1; padding: 6px;">المفتش</th>
              <th style="border: 1px solid #cbd5e1; padding: 6px;">النتيجة</th>
            </tr>
          </thead>
          <tbody>
            ${logs.slice(0, 10).map(lg => `
              <tr>
                <td style="border: 1px solid #cbd5e1; padding: 5px; font-weight: bold;">${lg.stationId || lg.stationCode}</td>
                <td style="border: 1px solid #cbd5e1; padding: 5px;">${lg.flushDate}</td>
                <td style="border: 1px solid #cbd5e1; padding: 5px;">${lg.flowDurationSeconds || lg.flushDurationSeconds || 180} ثانية</td>
                <td style="border: 1px solid #cbd5e1; padding: 5px;">${lg.waterClarity === 'clean_clear' ? 'نقية وخالية من الرواسب' : 'بها رواسب'}</td>
                <td style="border: 1px solid #cbd5e1; padding: 5px;">${lg.dustCoversIntact ? 'سليمة وتعمل تلقائياً' : 'ملاحظة'}</td>
                <td style="border: 1px solid #cbd5e1; padding: 5px;">${lg.pathwayUnobstructed ? 'المسار سالك واللافتة واضحة' : 'عائق بالمسار'}</td>
                <td style="border: 1px solid #cbd5e1; padding: 5px;">${lg.inspectorName}</td>
                <td style="border: 1px solid #cbd5e1; padding: 5px; font-weight: bold; color: ${lg.status === 'pass' || lg.overallStatus === 'pass' ? '#0d9488' : '#e11d48'};">
                  ${lg.status === 'pass' || lg.overallStatus === 'pass' ? 'مطابق ANSI' : 'ملاحظة'}
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <div style="margin-top: 30px; display: flex; justify-content: space-between; font-size: 12px; padding: 0 40px;">
          <div><strong>مسؤول السلامة والصحة المهنية:</strong><br><br>م/ نجيب غازي</div>
          <div><strong>رئيس قسم مكافحة العدوى IPC:</strong><br><br>.........................</div>
          <div><strong>مدير السلامة وإدارة المرافق FMS:</strong><br><br>.........................</div>
        </div>
      </div>
    `;

    executeSmartPrint(bodyHtml, {
      title: 'سجل الفحص والتدفق الأسبوعي لمحطات غسول العيون والدوش الطارئ',
      subtitle: 'مستشفى آزال النموذجي • إدارة السلامة والصحة المهنية FMS • معيار ANSI Z358.1',
      refNumber: 'AZAL-EYEWASH-FLUSH-2026'
    });
  };

  return (
    <div id="eyewash-flush-view" className="space-y-4 text-right">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-teal-950/70 to-slate-900 border border-teal-800/60 rounded-3xl p-5 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-teal-950 border border-teal-700 text-teal-400">
            <Droplets className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-slate-100">
                سجل الفحص والتدفق الأسبوعي لمحطات غسول العيون والدش الطارئ
              </h2>
              <span className="text-[10px] bg-teal-950 text-teal-300 border border-teal-700 font-bold px-2 py-0.5 rounded-lg">
                CBAHI FMS & ANSI Z358.1
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-1">
              توثيق تشغيل وتدفق محطات غسول العيون لمدة 3 دقائق أسبوعياً للتخلص من الرواسب، وفحص ضغط المياه والحرارة الفاترة (Tepid Water 16-38°C).
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handlePrintReport}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 flex items-center gap-1.5 transition"
          >
            <Printer className="w-4 h-4 text-teal-400" />
            <span>طباعة التقرير الشامل (Print / PDF)</span>
          </button>
        </div>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4">
          <div className="text-xs text-slate-400 font-bold">إجمالي المحطات المعتمدة</div>
          <div className="text-2xl font-black text-slate-100 mt-1">{totalStations}</div>
          <div className="text-[11px] text-slate-500 mt-0.5">موزعة على الأقسام الخطرة</div>
        </div>

        <div className="bg-slate-900/90 border border-teal-800/40 rounded-2xl p-4">
          <div className="text-xs text-teal-400 font-bold">مطابقة ومفحوصة أسبوعياً</div>
          <div className="text-2xl font-black text-teal-300 mt-1">{compliantStations}</div>
          <div className="text-[11px] text-teal-500/80 mt-0.5">جاهزة للاستجابة الفورية</div>
        </div>

        <div className="bg-slate-900/90 border border-amber-800/40 rounded-2xl p-4">
          <div className="text-xs text-amber-400 font-bold">مستحقة للفحص الأسبوعي</div>
          <div className="text-2xl font-black text-amber-300 mt-1">{dueStations}</div>
          <div className="text-[11px] text-amber-500/80 mt-0.5">مطلوب فحص التدفق 3 دقائق</div>
        </div>

        <div className="bg-slate-900/90 border border-cyan-800/40 rounded-2xl p-4">
          <div className="text-xs text-cyan-400 font-bold">نسبة الامتثال (ANSI Z358.1)</div>
          <div className="text-2xl font-black text-cyan-300 mt-1">{complianceRate}%</div>
          <div className="text-[11px] text-cyan-500/80 mt-0.5">معايير سباهي للأمان الكيميائي</div>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-3 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="بحث بالكود، القسم، أو الموقع..."
            className="w-full bg-slate-950 border border-slate-700 rounded-xl pr-9 pl-3 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-teal-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Filter className="w-3.5 h-3.5 text-slate-400" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-950 border border-slate-700 text-slate-200 text-xs rounded-xl px-3 py-1.5 focus:outline-none focus:border-teal-500"
          >
            <option value="all">كافة الحالات</option>
            <option value="compliant">مطابقة وجاهزة</option>
            <option value="due">مستحقة للفحص</option>
            <option value="maintenance">صيانة</option>
          </select>
        </div>
      </div>

      {/* Stations List Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredStations.map(station => {
          const isCompliant = station.status === 'compliant';
          return (
            <div
              key={station.id}
              className="bg-slate-900 border border-slate-800 hover:border-teal-700/60 rounded-2xl p-4 space-y-3 transition shadow-md"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-xs bg-slate-800 text-teal-300 px-2 py-0.5 rounded-lg border border-slate-700">
                      {station.stationCode}
                    </span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                      isCompliant 
                        ? 'bg-teal-950 text-teal-300 border border-teal-800'
                        : 'bg-amber-950 text-amber-300 border border-amber-800 animate-pulse'
                    }`}>
                      {isCompliant ? '✓ مطابق ومعتمد' : '⚠️ مستحق الفحص'}
                    </span>
                  </div>
                  <h3 className="text-sm font-bold text-slate-100 mt-2">{station.department}</h3>
                </div>

                <div className="p-2 rounded-xl bg-slate-800 text-teal-400">
                  <Droplets className="w-5 h-5" />
                </div>
              </div>

              <p className="text-xs text-slate-400 leading-relaxed">
                📍 {station.locationDetail}
              </p>

              <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
                <span>آخر فحص تدفق:</span>
                <span className="font-mono text-slate-200 font-bold">{station.lastFlushDate}</span>
              </div>

              <button
                type="button"
                onClick={() => openFlushModal(station)}
                className="w-full py-2 px-3 rounded-xl bg-teal-600 hover:bg-teal-500 text-slate-950 font-black text-xs flex items-center justify-center gap-1.5 transition shadow-md active:scale-98"
              >
                <Play className="w-3.5 h-3.5" />
                <span>تسجيل فحص تدفق أسبوعي (3 دقائق)</span>
              </button>
            </div>
          );
        })}
      </div>

      {/* Flush Inspection Log History Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-teal-400" />
            <h3 className="font-bold text-sm text-slate-100">
              سجل عمليات التدفق الأسبوعية السابقة المعتمدة
            </h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            {logs.length} سجل موثق
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-right border-collapse">
            <thead>
              <tr className="bg-slate-950/80 text-slate-400 border-b border-slate-800">
                <th className="p-3">كود المحطة</th>
                <th className="p-3">تاريخ الفحص</th>
                <th className="p-3">مدة التدفق</th>
                <th className="p-3">نقاء المياه</th>
                <th className="p-3">الحرارة الفاترة (Tepid)</th>
                <th className="p-3">الأغطية والصمام</th>
                <th className="p-3">المسار سالك</th>
                <th className="p-3">المفتش</th>
                <th className="p-3">النتيجة</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {logs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-800/40 transition">
                  <td className="p-3 font-mono font-bold text-teal-400">
                    {log.stationId || log.stationCode}
                  </td>
                  <td className="p-3 font-mono text-slate-300">{log.flushDate}</td>
                  <td className="p-3 font-mono">{log.flowDurationSeconds || log.flushDurationSeconds || 180} ثانية</td>
                  <td className="p-3">
                    <span className="text-teal-400 font-medium">✓ نقية وصافية</span>
                  </td>
                  <td className="p-3">
                    <span className="text-slate-300">16 - 38 °C (معتدلة)</span>
                  </td>
                  <td className="p-3">
                    <span className="text-teal-400">✓ سليمة وتعمل</span>
                  </td>
                  <td className="p-3">
                    <span className="text-teal-400">✓ سالك وبدون عوائق</span>
                  </td>
                  <td className="p-3 text-slate-300 font-medium">{log.inspectorName}</td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded-md bg-teal-950 text-teal-300 border border-teal-800 text-[10px] font-bold">
                      مطابق ANSI Z358.1
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Flush Inspection Modal with 180-second Interactive Timer */}
      {showLogModal && selectedStation && (
        <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-3 sm:p-4 backdrop-blur-sm animate-in fade-in">
          <div className="bg-slate-900 border border-teal-800 rounded-3xl max-w-xl w-full p-5 sm:p-6 space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-teal-950 border border-teal-700 text-teal-400 flex items-center justify-center">
                  <Droplets className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-100">
                    توثيق فحص التدفق الأسبوعي لمحطة غسول العيون
                  </h3>
                  <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                    <span className="font-mono text-teal-300 font-bold">{selectedStation.stationCode}</span>
                    <span>•</span>
                    <span>{selectedStation.department}</span>
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowLogModal(false)}
                className="text-slate-400 hover:text-slate-200 text-base"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Interactive 3-Minute Flush Timer */}
            <div className="bg-slate-950 border border-teal-900/70 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-inner">
              <div className="space-y-1 text-right">
                <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-teal-400" />
                  <span>معيار التدفق الزمني (3 دقائق / 180 ثانية ANSI Z358.1):</span>
                </span>
                <p className="text-[11px] text-slate-400">
                  يجب ترك المحطة تتدفق لمدة 3 دقائق للتخلص التام من أي رواسب، كلس أو صدأ متراكم في المواسير.
                </p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <div className="font-mono font-black text-xl text-teal-400 bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-800">
                  {Math.floor(timerSecondsLeft / 60)}:{(timerSecondsLeft % 60).toString().padStart(2, '0')}
                </div>
                <button
                  type="button"
                  onClick={() => setIsTimerRunning(!isTimerRunning)}
                  className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1 ${
                    isTimerRunning
                      ? 'bg-amber-600 text-slate-950 hover:bg-amber-500'
                      : 'bg-teal-600 text-slate-950 hover:bg-teal-500'
                  }`}
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>{isTimerRunning ? 'إيقاف مؤقت' : 'بدء التدفق'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setIsTimerRunning(false);
                    setTimerSecondsLeft(180);
                  }}
                  className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700"
                  title="إعادة ضبط"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Inspection Checklist Form */}
            <form onSubmit={handleSaveFlushRecord} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                {/* Check 1: تدفق المياه كافي */}
                <label className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer hover:border-slate-700">
                  <span className="text-slate-200">تدفق مياه مستمر وكافي للعينين معاً</span>
                  <input
                    type="checkbox"
                    checked={waterFlowAdequate}
                    onChange={(e) => setWaterFlowAdequate(e.target.checked)}
                    className="w-4 h-4 text-teal-600 rounded bg-slate-800 border-slate-700 focus:ring-0"
                  />
                </label>

                {/* Check 2: نمط الرش المزدوج */}
                <label className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer hover:border-slate-700">
                  <span className="text-slate-200">الرش يغطي العينين بالتساوي دون إيذاء</span>
                  <input
                    type="checkbox"
                    checked={dualSprayPatternOk}
                    onChange={(e) => setDualSprayPatternOk(e.target.checked)}
                    className="w-4 h-4 text-teal-600 rounded bg-slate-800 border-slate-700 focus:ring-0"
                  />
                </label>

                {/* Check 3: أغطية الحماية من الغبار */}
                <label className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer hover:border-slate-700">
                  <span className="text-slate-200">أغطية الحماية تفتح تلقائياً عند التدفق</span>
                  <input
                    type="checkbox"
                    checked={dustCoversIntact}
                    onChange={(e) => setDustCoversIntact(e.target.checked)}
                    className="w-4 h-4 text-teal-600 rounded bg-slate-800 border-slate-700 focus:ring-0"
                  />
                </label>

                {/* Check 4: صمام البقاء مفتوحاً */}
                <label className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer hover:border-slate-700">
                  <span className="text-slate-200">الصمام يظل مفتوحاً ذاتياً (Hands-Free)</span>
                  <input
                    type="checkbox"
                    checked={stayOpenValveOk}
                    onChange={(e) => setStayOpenValveOk(e.target.checked)}
                    className="w-4 h-4 text-teal-600 rounded bg-slate-800 border-slate-700 focus:ring-0"
                  />
                </label>

                {/* Check 5: المسار سالك */}
                <label className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer hover:border-slate-700">
                  <span className="text-slate-200">المسار للمحطة سالك وخالٍ من العوائق (≤10ث)</span>
                  <input
                    type="checkbox"
                    checked={pathwayUnobstructed}
                    onChange={(e) => setPathwayUnobstructed(e.target.checked)}
                    className="w-4 h-4 text-teal-600 rounded bg-slate-800 border-slate-700 focus:ring-0"
                  />
                </label>

                {/* Check 6: الصرف يعمل */}
                <label className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer hover:border-slate-700">
                  <span className="text-slate-200">حوض التصريف يعمل بدون انسداد أو تراكم</span>
                  <input
                    type="checkbox"
                    checked={drainageWorking}
                    onChange={(e) => setDrainageWorking(e.target.checked)}
                    className="w-4 h-4 text-teal-600 rounded bg-slate-800 border-slate-700 focus:ring-0"
                  />
                </label>
              </div>

              {/* Water Clarity & Temperature Selectors */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="space-y-1">
                  <label className="block text-slate-300 font-bold">نقاء وصفاء المياه:</label>
                  <select
                    value={waterClarity}
                    onChange={(e) => setWaterClarity(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-teal-500"
                  >
                    <option value="clean_clear">نقية وصافية تماماً (Clean & Clear)</option>
                    <option value="sediment_cloudy">بها عكارة خفيفة (Sediment / Cloudy)</option>
                    <option value="rust_tint">بها أثر صدأ يحتاج تصريف إضافي (Rust Tint)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="block text-slate-300 font-bold">حرارة المياه (ANSI Tepid 16-38°C):</label>
                  <select
                    value={waterTemperature}
                    onChange={(e) => setWaterTemperature(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-teal-500"
                  >
                    <option value="tepid">فاترة ومعتدلة 16 - 38 °C (Tepid - قياسي)</option>
                    <option value="cold">باردة جداً (&lt;16°C)</option>
                    <option value="hot">حارة (&gt;38°C - خطر)</option>
                  </select>
                </div>
              </div>

              {/* Notes */}
              <div className="space-y-1">
                <label className="block text-slate-300 font-bold text-xs">ملاحظات الفحص والتدفق:</label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={2}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-slate-200 focus:outline-none focus:border-teal-500"
                />
              </div>

              {/* Inspector Name */}
              <div className="space-y-1">
                <label className="block text-slate-300 font-bold text-xs">اسم المفتش المسؤول:</label>
                <input
                  type="text"
                  value={inspectorName}
                  onChange={(e) => setInspectorName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-teal-500"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowLogModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 text-xs"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-md"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>اعتماد وتوثيق الفحص الأسبوعي</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
