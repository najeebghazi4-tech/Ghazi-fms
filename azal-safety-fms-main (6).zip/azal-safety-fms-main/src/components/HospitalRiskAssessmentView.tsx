import React, { useState, useEffect, useMemo } from 'react';
import { 
  ShieldAlert, 
  AlertTriangle, 
  CheckCircle2, 
  Activity, 
  Plus, 
  Search, 
  Filter, 
  Printer, 
  Edit3, 
  Trash2, 
  X, 
  Clock, 
  Building2, 
  Flame, 
  Biohazard, 
  ShieldCheck, 
  HeartPulse, 
  Calendar, 
  User, 
  ArrowRight, 
  RotateCcw,
  Sparkles,
  Info,
  ChevronDown,
  Layers,
  Percent,
  Check,
  Target
} from 'lucide-react';
import { 
  HospitalRiskItem, 
  RiskCategory, 
  RiskLikelihood, 
  RiskSeverity, 
  RiskLevel, 
  RiskStatus,
  StaffUser
} from '../types';
import { 
  DEFAULT_HOSPITAL_RISKS, 
  LIKELIHOOD_SCALES, 
  SEVERITY_SCALES, 
  RISK_CATEGORIES,
  calculateRiskScore, 
  getRiskLevel, 
  getMatrixCellBg 
} from '../data/azalRiskData';
import { printHospitalRiskRegisterPdf } from '../utils/riskPrintTemplates';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';
import { supabase } from '../services/supabaseClient';

interface HospitalRiskAssessmentViewProps {
  currentUser?: StaffUser | null;
  onClose?: () => void;
  isStandalonePublicRoute?: boolean;
}

const STORAGE_KEY = 'azal_hospital_risks_v2';

export const HospitalRiskAssessmentView: React.FC<HospitalRiskAssessmentViewProps> = ({
  currentUser,
  onClose,
  isStandalonePublicRoute = false,
}) => {
  // 1. Core State
  const [risks, setRisks] = useState<HospitalRiskItem[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem(STORAGE_KEY);
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed) && parsed.length > 0) return parsed;
        }
      } catch (e) {
        console.warn('Failed to load risks from storage:', e);
      }
    }
    return DEFAULT_HOSPITAL_RISKS;
  });

  // 2. Filter & Search State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDeptFilter, setSelectedDeptFilter] = useState('all');
  const [selectedLevelFilter, setSelectedLevelFilter] = useState('all');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState('all');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState('all');
  const [selectedMatrixCell, setSelectedMatrixCell] = useState<{ l: number; s: number } | null>(null);

  // 3. Modals State
  const [showAddEditModal, setShowAddEditModal] = useState(false);
  const [editingRisk, setEditingRisk] = useState<HospitalRiskItem | null>(null);
  const [showProgressModal, setShowProgressModal] = useState(false);
  const [selectedRiskForProgress, setSelectedRiskForProgress] = useState<HospitalRiskItem | null>(null);

  // Form State for Add / Edit
  const [formDepartment, setFormDepartment] = useState('قسم العمليات والعناية المركزة ICU');
  const [formCategory, setFormCategory] = useState<RiskCategory>('facilities');
  const [formTitle, setFormTitle] = useState('');
  const [formHazardDesc, setFormHazardDesc] = useState('');
  const [formConsequences, setFormConsequences] = useState('');
  const [formLikelihood, setFormLikelihood] = useState<RiskLikelihood>(3);
  const [formSeverity, setFormSeverity] = useState<RiskSeverity>(3);
  const [formCurrentControls, setFormCurrentControls] = useState('');
  const [formActionPlan, setFormActionPlan] = useState('');
  const [formResponsiblePerson, setFormResponsiblePerson] = useState('م/ نجيب غازي (مدير السلامة والمرافق)');
  const [formResponsibleDept, setFormResponsibleDept] = useState('قسم السلامة والمرافق العامة');
  const [formTargetDate, setFormTargetDate] = useState(() => {
    const d = new Date();
    d.setMonth(d.getMonth() + 1);
    return d.toISOString().split('T')[0];
  });
  const [formCompletionPercent, setFormCompletionPercent] = useState(50);
  const [formResidualLikelihood, setFormResidualLikelihood] = useState<RiskLikelihood>(1);
  const [formResidualSeverity, setFormResidualSeverity] = useState<RiskSeverity>(2);
  const [formStatus, setFormStatus] = useState<RiskStatus>('in_progress');
  const [formNotes, setFormNotes] = useState('');

  // Quick progress modal form state
  const [progressPercentInput, setProgressPercentInput] = useState(50);
  const [progressStatusInput, setProgressStatusInput] = useState<RiskStatus>('in_progress');
  const [progressResidualL, setProgressResidualL] = useState<RiskLikelihood>(1);
  const [progressResidualS, setProgressResidualS] = useState<RiskSeverity>(2);
  const [progressActionNotes, setProgressActionNotes] = useState('');

  // Save to localStorage & Supabase
  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(risks));
      } catch (e) {
        console.warn('Storage error:', e);
      }
    }
  }, [risks]);

  // Sync with Supabase on mount
  useEffect(() => {
    async function syncFromSupabase() {
      try {
        const { data, error } = await supabase.from('hospital_risks').select('*');
        if (!error && Array.isArray(data) && data.length > 0) {
          setRisks(data);
        }
      } catch (e) {
        // graceful offline fallback
      }
    }
    syncFromSupabase();
  }, []);

  // Compute calculated live form score & level
  const currentFormScore = useMemo(() => {
    return calculateRiskScore(formLikelihood, formSeverity);
  }, [formLikelihood, formSeverity]);

  const currentFormLevel = useMemo(() => {
    return getRiskLevel(currentFormScore);
  }, [currentFormScore]);

  const currentResidualFormScore = useMemo(() => {
    return calculateRiskScore(formResidualLikelihood, formResidualSeverity);
  }, [formResidualLikelihood, formResidualSeverity]);

  const currentResidualFormLevel = useMemo(() => {
    return getRiskLevel(currentResidualFormScore);
  }, [currentResidualFormScore]);

  // Statistics Calculation
  const stats = useMemo(() => {
    const total = risks.length;
    const critical = risks.filter(r => r.initial_risk_score >= 20).length;
    const high = risks.filter(r => r.initial_risk_score >= 10 && r.initial_risk_score < 20).length;
    const moderate = risks.filter(r => r.initial_risk_score >= 5 && r.initial_risk_score < 10).length;
    const low = risks.filter(r => r.initial_risk_score < 5).length;
    const controlled = risks.filter(r => r.status === 'controlled' || r.completion_percentage === 100).length;
    const controlRate = total > 0 ? Math.round((controlled / total) * 100) : 100;
    
    // Average initial score vs average residual score
    const avgInitial = total > 0 
      ? (risks.reduce((acc, r) => acc + r.initial_risk_score, 0) / total).toFixed(1) 
      : '0.0';
    const avgResidual = total > 0 
      ? (risks.reduce((acc, r) => acc + (r.residual_risk_score || calculateRiskScore(r.residual_likelihood || 1, r.residual_severity || 2)), 0) / total).toFixed(1) 
      : '0.0';

    return {
      total,
      critical,
      high,
      moderate,
      low,
      controlled,
      controlRate,
      avgInitial,
      avgResidual
    };
  }, [risks]);

  // List of unique departments for filter
  const departmentsList = useMemo(() => {
    const set = new Set<string>();
    risks.forEach(r => {
      if (r.department) set.add(r.department);
    });
    return Array.from(set);
  }, [risks]);

  // Filtered Risks
  const filteredRisks = useMemo(() => {
    return risks.filter(r => {
      // Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchTitle = (r.title || '').toLowerCase().includes(q);
        const matchDesc = (r.hazard_description || '').toLowerCase().includes(q);
        const matchCode = (r.risk_code || '').toLowerCase().includes(q);
        const matchDept = (r.department || '').toLowerCase().includes(q);
        const matchPerson = (r.responsible_person || '').toLowerCase().includes(q);
        if (!matchTitle && !matchDesc && !matchCode && !matchDept && !matchPerson) return false;
      }

      // Department filter
      if (selectedDeptFilter !== 'all' && r.department !== selectedDeptFilter) {
        return false;
      }

      // Level filter
      if (selectedLevelFilter !== 'all') {
        const lvl = getRiskLevel(r.initial_risk_score).level;
        if (lvl !== selectedLevelFilter) return false;
      }

      // Category filter
      if (selectedCategoryFilter !== 'all' && r.category !== selectedCategoryFilter) {
        return false;
      }

      // Status filter
      if (selectedStatusFilter !== 'all') {
        if (selectedStatusFilter === 'controlled' && (r.status !== 'controlled' && r.completion_percentage < 100)) return false;
        if (selectedStatusFilter === 'in_progress' && (r.status === 'controlled' || r.completion_percentage === 100)) return false;
      }

      // 5x5 Matrix Cell filter
      if (selectedMatrixCell) {
        if (r.initial_likelihood !== selectedMatrixCell.l || r.initial_severity !== selectedMatrixCell.s) {
          return false;
        }
      }

      return true;
    });
  }, [risks, searchQuery, selectedDeptFilter, selectedLevelFilter, selectedCategoryFilter, selectedStatusFilter, selectedMatrixCell]);

  // Open modal for Adding a new risk
  const handleOpenAddModal = () => {
    setEditingRisk(null);
    setFormDepartment('قسم العمليات والعناية المركزة ICU');
    setFormCategory('facilities');
    setFormTitle('');
    setFormHazardDesc('');
    setFormConsequences('');
    setFormLikelihood(3);
    setFormSeverity(3);
    setFormCurrentControls('');
    setFormActionPlan('');
    setFormResponsiblePerson(currentUser?.name ? `${currentUser.name} (${currentUser.role})` : 'م/ نجيب غازي (مدير السلامة والمرافق)');
    setFormResponsibleDept('قسم السلامة وإدارة المرافق');
    const d = new Date();
    d.setMonth(d.getMonth() + 1);
    setFormTargetDate(d.toISOString().split('T')[0]);
    setFormCompletionPercent(40);
    setFormResidualLikelihood(1);
    setFormResidualSeverity(2);
    setFormStatus('in_progress');
    setFormNotes('');
    setShowAddEditModal(true);
  };

  // Open modal for Editing an existing risk
  const handleOpenEditModal = (risk: HospitalRiskItem) => {
    setEditingRisk(risk);
    setFormDepartment(risk.department);
    setFormCategory(risk.category);
    setFormTitle(risk.title);
    setFormHazardDesc(risk.hazard_description);
    setFormConsequences(risk.consequences || '');
    setFormLikelihood(risk.initial_likelihood);
    setFormSeverity(risk.initial_severity);
    setFormCurrentControls(risk.current_controls);
    setFormActionPlan(risk.action_plan);
    setFormResponsiblePerson(risk.responsible_person);
    setFormResponsibleDept(risk.responsible_dept || '');
    setFormTargetDate(risk.target_date);
    setFormCompletionPercent(risk.completion_percentage);
    setFormResidualLikelihood(risk.residual_likelihood || 1);
    setFormResidualSeverity(risk.residual_severity || 2);
    setFormStatus(risk.status);
    setFormNotes(risk.notes || '');
    setShowAddEditModal(true);
  };

  // Save Add / Edit
  const handleSaveRiskForm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formHazardDesc.trim()) {
      alert('يرجى كتابة عنوان الخطر ووصفه بدقة');
      return;
    }

    const catObj = RISK_CATEGORIES.find(c => c.id === formCategory);
    const score = calculateRiskScore(formLikelihood, formSeverity);
    const lvl = getRiskLevel(score).level;
    const resScore = calculateRiskScore(formResidualLikelihood, formResidualSeverity);
    const resLvl = getRiskLevel(resScore).level;

    if (editingRisk) {
      // Update
      const updated: HospitalRiskItem = {
        ...editingRisk,
        department: formDepartment.trim(),
        category: formCategory,
        category_name_ar: catObj?.nameAr || 'عام',
        title: formTitle.trim(),
        hazard_description: formHazardDesc.trim(),
        consequences: formConsequences.trim(),
        initial_likelihood: formLikelihood,
        initial_severity: formSeverity,
        initial_risk_score: score,
        initial_risk_level: lvl,
        current_controls: formCurrentControls.trim(),
        action_plan: formActionPlan.trim(),
        responsible_person: formResponsiblePerson.trim(),
        responsible_dept: formResponsibleDept.trim(),
        target_date: formTargetDate,
        completion_percentage: formCompletionPercent,
        residual_likelihood: formResidualLikelihood,
        residual_severity: formResidualSeverity,
        residual_risk_score: resScore,
        residual_risk_level: resLvl,
        status: formCompletionPercent === 100 ? 'controlled' : formStatus,
        notes: formNotes.trim(),
        updated_at: new Date().toISOString()
      };

      setRisks(prev => prev.map(r => r.id === updated.id ? updated : r));
      try {
        await supabase.from('hospital_risks').upsert([updated]);
      } catch (e) {}
    } else {
      // Create new
      const nextNum = risks.length + 1;
      const codeStr = `RSK-2026-${String(nextNum).padStart(3, '0')}`;
      const newRisk: HospitalRiskItem = {
        id: `RSK-${Date.now()}`,
        risk_code: codeStr,
        department: formDepartment.trim(),
        category: formCategory,
        category_name_ar: catObj?.nameAr || 'عام',
        title: formTitle.trim(),
        hazard_description: formHazardDesc.trim(),
        consequences: formConsequences.trim(),
        initial_likelihood: formLikelihood,
        initial_severity: formSeverity,
        initial_risk_score: score,
        initial_risk_level: lvl,
        current_controls: formCurrentControls.trim() || 'إجراءات تشغيلية اعتيادية',
        action_plan: formActionPlan.trim(),
        responsible_person: formResponsiblePerson.trim(),
        responsible_dept: formResponsibleDept.trim(),
        target_date: formTargetDate,
        completion_percentage: formCompletionPercent,
        residual_likelihood: formResidualLikelihood,
        residual_severity: formResidualSeverity,
        residual_risk_score: resScore,
        residual_risk_level: resLvl,
        status: formCompletionPercent === 100 ? 'controlled' : formStatus,
        notes: formNotes.trim(),
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      setRisks(prev => [newRisk, ...prev]);
      try {
        await supabase.from('hospital_risks').insert([newRisk]);
      } catch (e) {}
    }

    triggerSuccessFeedback();
    setShowAddEditModal(false);
  };

  // Open Quick Progress Modal
  const handleOpenProgressModal = (risk: HospitalRiskItem) => {
    setSelectedRiskForProgress(risk);
    setProgressPercentInput(risk.completion_percentage);
    setProgressStatusInput(risk.status);
    setProgressResidualL(risk.residual_likelihood || 1);
    setProgressResidualS(risk.residual_severity || 2);
    setProgressActionNotes(risk.notes || '');
    setShowProgressModal(true);
  };

  // Save Quick Progress
  const handleSaveProgress = async () => {
    if (!selectedRiskForProgress) return;
    const resScore = calculateRiskScore(progressResidualL, progressResidualS);
    const resLvl = getRiskLevel(resScore).level;
    const updatedStatus = progressPercentInput === 100 ? 'controlled' : progressStatusInput;

    const updated: HospitalRiskItem = {
      ...selectedRiskForProgress,
      completion_percentage: progressPercentInput,
      status: updatedStatus,
      residual_likelihood: progressResidualL,
      residual_severity: progressResidualS,
      residual_risk_score: resScore,
      residual_risk_level: resLvl,
      notes: progressActionNotes.trim(),
      last_review_date: new Date().toISOString().split('T')[0],
      reviewed_by: currentUser?.name || 'م/ نجيب غازي',
      updated_at: new Date().toISOString()
    };

    setRisks(prev => prev.map(r => r.id === updated.id ? updated : r));
    try {
      await supabase.from('hospital_risks').upsert([updated]);
    } catch (e) {}

    triggerSuccessFeedback();
    setShowProgressModal(false);
  };

  // Delete risk
  const handleDeleteRisk = async (id: string) => {
    if (confirm('هل أنت متأكد من حذف هذا السجل من مصفوفة وسجل المخاطر؟')) {
      setRisks(prev => prev.filter(r => r.id !== id));
      try {
        await supabase.from('hospital_risks').delete().eq('id', id);
      } catch (e) {}
    }
  };

  // Reset to default
  const handleResetToDefaults = () => {
    if (confirm('هل ترغب في استعادة سجل المخاطر النموذجي المعتمد لمستشفى آزال؟')) {
      setRisks(DEFAULT_HOSPITAL_RISKS);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_HOSPITAL_RISKS));
      triggerSuccessFeedback();
    }
  };

  // Export PDF
  const handleExportPdf = () => {
    printHospitalRiskRegisterPdf(
      filteredRisks,
      stats,
      {
        filterDept: selectedDeptFilter !== 'all' ? selectedDeptFilter : 'كافة أقسام المستشفى',
        filterLevel: selectedLevelFilter !== 'all' ? selectedLevelFilter : 'كافة مستويات الخطورة',
        printedBy: currentUser?.name ? `${currentUser.name} (${currentUser.role})` : 'م. نجيب غازي (مسؤول FMS)'
      }
    );
  };

  return (
    <div className="space-y-5 select-none font-sans" dir="rtl">
      
      {/* ========================================================================= */}
      {/* 1. RISK DASHBOARD HEADER & EXECUTIVE SUMMARY */}
      {/* ========================================================================= */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-6 shadow-xl relative overflow-hidden">
        {/* Background ambient glow */}
        <div className="absolute top-0 right-0 w-96 h-40 bg-teal-500/10 blur-3xl pointer-events-none rounded-full" />
        <div className="absolute bottom-0 left-0 w-80 h-40 bg-rose-500/10 blur-3xl pointer-events-none rounded-full" />

        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 border-b border-slate-800/80 pb-5 mb-5">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-teal-500 to-sky-600 flex items-center justify-center text-white shadow-lg shadow-teal-900/30 shrink-0">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-black text-white">
                  تحليل وسجل مصفوفة المخاطر الشاملة (5×5 Risk Matrix)
                </h2>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-teal-500/20 text-teal-300 border border-teal-500/30">
                  CBAHI FMS.1 & JCI
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                مستشفى آزال النموذجي • الرصد الاستباقي، تقييم الاحتمالية والأثر، وخطط الإجراءات التصحيحية المعتمدة
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5 w-full lg:w-auto">
            <button
              onClick={handleOpenAddModal}
              className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white text-xs sm:text-sm font-bold shadow-lg shadow-teal-950/40 transition active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة خطر وتقييم جديد</span>
            </button>

            <button
              onClick={handleExportPdf}
              className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700 hover:border-slate-600 text-xs sm:text-sm font-bold shadow transition active:scale-95"
              title="تصدير سجل المخاطر بصيغة PDF معتمدة للجان الجودة"
            >
              <Printer className="w-4 h-4 text-sky-400" />
              <span>📄 تصدير سجل المخاطر كـ PDF رسمي</span>
            </button>

            {onClose && (
              <button
                onClick={onClose}
                className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
                title="إغلاق"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>

        {/* 4 Stat KPI Boxes */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {/* Total Risks */}
          <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-3.5 relative overflow-hidden">
            <span className="text-[11px] font-bold text-slate-400 block">إجمالي المخاطر</span>
            <div className="text-2xl font-black text-white mt-1">{stats.total}</div>
            <span className="text-[10px] text-slate-500 block mt-0.5">خطر مرصود ومسجل</span>
          </div>

          {/* Critical Red */}
          <div 
            onClick={() => setSelectedLevelFilter(selectedLevelFilter === 'critical' ? 'all' : 'critical')}
            className={`cursor-pointer transition border rounded-2xl p-3.5 relative overflow-hidden ${
              selectedLevelFilter === 'critical'
                ? 'bg-rose-950 border-rose-500 ring-2 ring-rose-500/50'
                : 'bg-rose-950/40 border-rose-800/60 hover:border-rose-600'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-rose-300">حرجة (20-25)</span>
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
            </div>
            <div className="text-2xl font-black text-rose-400 mt-1">{stats.critical}</div>
            <span className="text-[10px] text-rose-300/70 block mt-0.5">أولوية عاجلة قصوى</span>
          </div>

          {/* High Orange */}
          <div 
            onClick={() => setSelectedLevelFilter(selectedLevelFilter === 'high' ? 'all' : 'high')}
            className={`cursor-pointer transition border rounded-2xl p-3.5 relative overflow-hidden ${
              selectedLevelFilter === 'high'
                ? 'bg-amber-950 border-amber-500 ring-2 ring-amber-500/50'
                : 'bg-amber-950/40 border-amber-800/60 hover:border-amber-600'
            }`}
          >
            <span className="text-[11px] font-bold text-amber-300 block">عالية (10-16)</span>
            <div className="text-2xl font-black text-amber-400 mt-1">{stats.high}</div>
            <span className="text-[10px] text-amber-300/70 block mt-0.5">متابعة إدارية حثيثة</span>
          </div>

          {/* Moderate Yellow */}
          <div 
            onClick={() => setSelectedLevelFilter(selectedLevelFilter === 'moderate' ? 'all' : 'moderate')}
            className={`cursor-pointer transition border rounded-2xl p-3.5 relative overflow-hidden ${
              selectedLevelFilter === 'moderate'
                ? 'bg-yellow-950 border-yellow-500 ring-2 ring-yellow-500/50'
                : 'bg-yellow-950/30 border-yellow-800/50 hover:border-yellow-600'
            }`}
          >
            <span className="text-[11px] font-bold text-yellow-300 block">متوسطة (5-9)</span>
            <div className="text-2xl font-black text-yellow-400 mt-1">{stats.moderate}</div>
            <span className="text-[10px] text-yellow-300/70 block mt-0.5">إجراءات تشغيلية</span>
          </div>

          {/* Low Green */}
          <div 
            onClick={() => setSelectedLevelFilter(selectedLevelFilter === 'low' ? 'all' : 'low')}
            className={`cursor-pointer transition border rounded-2xl p-3.5 relative overflow-hidden ${
              selectedLevelFilter === 'low'
                ? 'bg-emerald-950 border-emerald-500 ring-2 ring-emerald-500/50'
                : 'bg-emerald-950/30 border-emerald-800/50 hover:border-emerald-600'
            }`}
          >
            <span className="text-[11px] font-bold text-emerald-300 block">منخفضة (1-4)</span>
            <div className="text-2xl font-black text-emerald-400 mt-1">{stats.low}</div>
            <span className="text-[10px] text-emerald-300/70 block mt-0.5">مستوى مقبول</span>
          </div>

          {/* Controlled Rate */}
          <div className="bg-gradient-to-br from-teal-950/60 to-emerald-950/60 border border-teal-600/50 rounded-2xl p-3.5 relative overflow-hidden">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-teal-300">نسبة السيطرة</span>
              <CheckCircle2 className="w-3.5 h-3.5 text-teal-400" />
            </div>
            <div className="text-2xl font-black text-teal-300 mt-1">{stats.controlRate}%</div>
            <span className="text-[10px] text-teal-400/80 block mt-0.5">{stats.controlled} خطر مكتمل 100%</span>
          </div>
        </div>

        {/* 5x5 Matrix Visual Heatmap Card (Interactive) */}
        <div className="mt-5 bg-slate-950/80 border border-slate-800/90 rounded-2xl p-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-800 pb-3 mb-3">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-teal-400" />
              <h3 className="text-xs sm:text-sm font-bold text-white">
                خريطة مصفوفة المخاطر التفاعلية (5×5 Heatmap Matrix)
              </h3>
              <span className="text-[11px] text-slate-400">
                (انقر على أي خلية لتصفية المخاطر المطابقة مباشرة)
              </span>
            </div>

            {selectedMatrixCell && (
              <button
                onClick={() => setSelectedMatrixCell(null)}
                className="inline-flex items-center gap-1.5 text-xs font-bold text-rose-400 hover:text-rose-300 bg-rose-950/60 px-2.5 py-1 rounded-xl border border-rose-800/80 transition"
              >
                <X className="w-3.5 h-3.5" />
                <span>إلغاء تصفية الخلية (احتمالية: {selectedMatrixCell.l} × أثر: {selectedMatrixCell.s})</span>
              </button>
            )}
          </div>

          <div className="overflow-x-auto">
            <div className="min-w-[620px]">
              {/* Matrix Layout */}
              <div className="grid grid-cols-[100px_repeat(5,1fr)] gap-1.5 text-center">
                {/* Header Row: Severity (1 to 5) */}
                <div className="p-2 text-[11px] font-bold text-slate-400 flex items-center justify-center">
                  الاحتمالية \ الأثر
                </div>
                {SEVERITY_SCALES.map((sev) => (
                  <div key={sev.score} className="p-1.5 bg-slate-900 border border-slate-800 rounded-xl">
                    <span className="text-[10px] font-bold text-slate-300 block">{sev.score}</span>
                    <span className="text-[9.5px] text-slate-400 block truncate">{sev.labelAr}</span>
                  </div>
                ))}

                {/* 5 Rows for Likelihood (5 down to 1) */}
                {[5, 4, 3, 2, 1].map((lScore) => {
                  const lObj = LIKELIHOOD_SCALES.find(s => s.score === lScore);
                  return (
                    <React.Fragment key={lScore}>
                      {/* Likelihood Label */}
                      <div className="p-1.5 bg-slate-900 border border-slate-800 rounded-xl flex flex-col justify-center text-right pr-2">
                        <span className="text-[10px] font-bold text-slate-300">{lScore} - {lObj?.labelAr}</span>
                      </div>

                      {/* 5 Severity Columns for this row */}
                      {[1, 2, 3, 4, 5].map((sScore) => {
                        const cellScore = lScore * sScore;
                        const matchingRisks = risks.filter(
                          r => r.initial_likelihood === lScore && r.initial_severity === sScore
                        );
                        const isSelected = selectedMatrixCell?.l === lScore && selectedMatrixCell?.s === sScore;
                        const cellBg = getMatrixCellBg(cellScore);

                        return (
                          <div
                            key={`${lScore}-${sScore}`}
                            onClick={() => {
                              if (matchingRisks.length > 0) {
                                setSelectedMatrixCell(isSelected ? null : { l: lScore, s: sScore });
                              }
                            }}
                            className={`p-2 rounded-xl border transition flex flex-col items-center justify-center cursor-pointer min-h-[50px] ${
                              isSelected 
                                ? 'ring-2 ring-white scale-98 shadow-xl ' + cellBg 
                                : matchingRisks.length > 0
                                  ? `${cellBg} shadow-md`
                                  : 'bg-slate-900/60 border-slate-800/80 text-slate-600 hover:border-slate-700'
                            }`}
                            title={`الاحتمالية: ${lScore} | شدة الأثر: ${sScore} | ناتج الخطورة: ${cellScore} (${matchingRisks.length} مخاطر)`}
                          >
                            <span className="text-[10px] opacity-75 font-mono">{cellScore}</span>
                            {matchingRisks.length > 0 ? (
                              <span className="text-xs font-black mt-0.5 px-2 py-0.2 rounded-full bg-black/25">
                                {matchingRisks.length} {matchingRisks.length === 1 ? 'خطر' : 'مخاطر'}
                              </span>
                            ) : (
                              <span className="text-[10px] text-slate-600">-</span>
                            )}
                          </div>
                        );
                      })}
                    </React.Fragment>
                  );
                })}
              </div>

              {/* Heatmap Legend */}
              <div className="flex flex-wrap items-center justify-between gap-3 text-[11px] text-slate-400 mt-3 pt-2.5 border-t border-slate-800">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded-md bg-rose-600" />
                    <span>حرج (20-25)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded-md bg-amber-500" />
                    <span>عالي (10-16)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded-md bg-yellow-400" />
                    <span>متوسط (5-9)</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded-md bg-emerald-600" />
                    <span>منخفض (1-4)</span>
                  </div>
                </div>

                <div className="text-[10px] text-teal-400 font-mono">
                  معادلة تقييم الخطر: ناتج الخطورة = الاحتمالية (1-5) × شدة الأثر (1-5)
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 2. FILTERS & SEARCH CONTROLS */}
      {/* ========================================================================= */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 sm:p-4 space-y-3">
        <div className="flex flex-col sm:flex-row items-center gap-3">
          {/* Search Box */}
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث برقم الخطر، القسم، وصف التهديد، المسؤول..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-10 pl-4 py-2 text-xs sm:text-sm text-white focus:outline-none focus:border-teal-500 transition"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute left-3 top-2.5 text-slate-500 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Department Filter */}
          <div className="w-full sm:w-56">
            <select
              value={selectedDeptFilter}
              onChange={(e) => setSelectedDeptFilter(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-200 focus:outline-none focus:border-teal-500"
            >
              <option value="all">جميع الأقسام ({risks.length})</option>
              {departmentsList.map(dept => (
                <option key={dept} value={dept}>{dept}</option>
              ))}
            </select>
          </div>

          {/* Category Filter */}
          <div className="w-full sm:w-52">
            <select
              value={selectedCategoryFilter}
              onChange={(e) => setSelectedCategoryFilter(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-200 focus:outline-none focus:border-teal-500"
            >
              <option value="all">جميع التصنيفات</option>
              {RISK_CATEGORIES.map(c => (
                <option key={c.id} value={c.id}>{c.nameAr}</option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div className="w-full sm:w-40">
            <select
              value={selectedStatusFilter}
              onChange={(e) => setSelectedStatusFilter(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-200 focus:outline-none focus:border-teal-500"
            >
              <option value="all">كافة الحالات</option>
              <option value="in_progress">قيد المعالجة</option>
              <option value="controlled">تمت السيطرة ✓</option>
            </select>
          </div>
        </div>

        {/* Active Filter Chips & Counter */}
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs pt-1 border-t border-slate-800/80">
          <div className="flex flex-wrap items-center gap-1.5 text-slate-400">
            <span>النتائج المعروضة:</span>
            <strong className="text-teal-300 font-bold">{filteredRisks.length}</strong>
            <span>من إجمالي {risks.length} خطر مسجل</span>

            {(selectedDeptFilter !== 'all' || selectedLevelFilter !== 'all' || selectedCategoryFilter !== 'all' || selectedStatusFilter !== 'all' || selectedMatrixCell || searchQuery) && (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedDeptFilter('all');
                  setSelectedLevelFilter('all');
                  setSelectedCategoryFilter('all');
                  setSelectedStatusFilter('all');
                  setSelectedMatrixCell(null);
                }}
                className="mr-2 text-rose-400 hover:text-rose-300 font-bold inline-flex items-center gap-1"
              >
                <RotateCcw className="w-3 h-3" />
                <span>إعادة تعيين الفلاتر</span>
              </button>
            )}
          </div>

          <button
            onClick={handleResetToDefaults}
            className="text-[11px] text-slate-500 hover:text-slate-300 flex items-center gap-1"
            title="استعادة السجل الافتراضي"
          >
            <RotateCcw className="w-3 h-3" />
            <span>استعادة السجل النموذجي</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 3. HOSPITAL RISK REGISTER TABLE */}
      {/* ========================================================================= */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="bg-slate-950/90 text-slate-300 border-b border-slate-800">
                <th className="p-3.5 font-bold text-center w-28">كود الخطر</th>
                <th className="p-3.5 font-bold min-w-[140px]">القسم والتصنيف</th>
                <th className="p-3.5 font-bold min-w-[200px]">وصف الخطر والتهديد</th>
                <th className="p-3.5 font-bold text-center w-28">التقييم الأولي</th>
                <th className="p-3.5 font-bold min-w-[180px]">الضوابط وخطة العمل (CAP)</th>
                <th className="p-3.5 font-bold min-w-[130px]">المسؤول والموعد</th>
                <th className="p-3.5 font-bold text-center w-28">التقييم المتبقي</th>
                <th className="p-3.5 font-bold text-center w-36">الإنجاز والحالة</th>
                <th className="p-3.5 font-bold text-center w-24">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filteredRisks.length === 0 ? (
                <tr>
                  <td colSpan={9} className="p-8 text-center text-slate-400">
                    <div className="w-12 h-12 rounded-2xl bg-slate-800 flex items-center justify-center mx-auto mb-2 text-slate-500">
                      <ShieldCheck className="w-6 h-6" />
                    </div>
                    <p className="font-bold text-sm text-slate-300">لا توجد مخاطر مطابقة لشروط البحث والتصفية</p>
                    <p className="text-xs text-slate-500 mt-1">جرب تغيير معايير البحث أو إضافة خطر جديد للسجل</p>
                  </td>
                </tr>
              ) : (
                filteredRisks.map((risk) => {
                  const initialLvl = getRiskLevel(risk.initial_risk_score);
                  const resScore = risk.residual_risk_score || calculateRiskScore(risk.residual_likelihood || 1, risk.residual_severity || 2);
                  const resLvl = getRiskLevel(resScore);

                  return (
                    <tr key={risk.id} className="hover:bg-slate-850/50 transition">
                      {/* 1. Code & Level Badge */}
                      <td className="p-3.5 text-center align-top">
                        <span className="font-mono font-bold text-sky-400 block text-xs">
                          {risk.risk_code}
                        </span>
                        <span className={`inline-block mt-1.5 px-2 py-0.5 rounded-full text-[9.5px] font-bold border ${initialLvl.badgeClass}`}>
                          {initialLvl.labelAr}
                        </span>
                      </td>

                      {/* 2. Department & Category */}
                      <td className="p-3.5 align-top">
                        <strong className="text-white text-xs block leading-tight">{risk.department}</strong>
                        <span className="text-[11px] text-slate-400 block mt-1 flex items-center gap-1">
                          <Building2 className="w-3 h-3 text-teal-400 shrink-0" />
                          <span>{risk.category_name_ar}</span>
                        </span>
                      </td>

                      {/* 3. Title & Hazard Description */}
                      <td className="p-3.5 align-top">
                        <strong className="text-slate-100 text-xs block font-bold leading-snug">{risk.title}</strong>
                        <p className="text-slate-400 text-[11px] mt-1 line-clamp-2 leading-relaxed">
                          {risk.hazard_description}
                        </p>
                        {risk.consequences && (
                          <div className="mt-1 text-[10px] text-rose-400 flex items-center gap-1">
                            <AlertTriangle className="w-3 h-3 shrink-0" />
                            <span className="truncate">{risk.consequences}</span>
                          </div>
                        )}
                      </td>

                      {/* 4. Initial Assessment (L x S) */}
                      <td className="p-3.5 text-center align-top">
                        <div className="inline-flex flex-col items-center justify-center p-2 rounded-xl bg-slate-950 border border-slate-800 min-w-[65px]">
                          <span className={`text-base font-black ${initialLvl.colorText}`}>
                            {risk.initial_risk_score}
                          </span>
                          <span className="text-[9.5px] text-slate-500 font-mono mt-0.5">
                            ({risk.initial_likelihood} × {risk.initial_severity})
                          </span>
                        </div>
                      </td>

                      {/* 5. Controls & Action Plan */}
                      <td className="p-3.5 align-top">
                        <div className="text-[11px] text-slate-300 leading-tight">
                          <span className="text-slate-500 font-semibold block text-[10px]">الضوابط الحالية:</span>
                          <p className="line-clamp-1 text-slate-300 mt-0.5">{risk.current_controls || 'تحت المراجعة'}</p>
                        </div>
                        <div className="mt-1.5 text-[11px] text-teal-300 leading-tight">
                          <span className="text-teal-500 font-semibold block text-[10px]">خطة العمل (CAP):</span>
                          <p className="line-clamp-1 text-teal-200 mt-0.5">{risk.action_plan}</p>
                        </div>
                      </td>

                      {/* 6. Assignee & Target Date */}
                      <td className="p-3.5 align-top">
                        <strong className="text-slate-200 text-xs block leading-tight">{risk.responsible_person}</strong>
                        {risk.responsible_dept && (
                          <span className="text-[10px] text-slate-400 block">{risk.responsible_dept}</span>
                        )}
                        <span className="text-[10.5px] text-amber-400 font-mono font-bold block mt-1 flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          <span>{risk.target_date}</span>
                        </span>
                      </td>

                      {/* 7. Residual Assessment (Residual L x S) */}
                      <td className="p-3.5 text-center align-top">
                        <div className="inline-flex flex-col items-center justify-center p-2 rounded-xl bg-slate-950 border border-slate-800 min-w-[65px]">
                          <span className={`text-sm font-black ${resLvl.colorText}`}>
                            {resScore}
                          </span>
                          <span className="text-[9px] text-slate-500 font-mono">
                            ({risk.residual_likelihood || 1} × {risk.residual_severity || 2})
                          </span>
                          <span className={`inline-block mt-1 px-1.5 py-0.2 rounded text-[8px] font-bold ${resLvl.badgeClass}`}>
                            {resLvl.labelAr}
                          </span>
                        </div>
                      </td>

                      {/* 8. Progress & Status */}
                      <td className="p-3.5 text-center align-top">
                        <button
                          onClick={() => handleOpenProgressModal(risk)}
                          className="w-full text-right bg-slate-950 hover:bg-slate-900 border border-slate-800 p-2 rounded-xl transition block group"
                          title="انقر لتحديث نسبة الإنجاز وإعادة التقييم"
                        >
                          <div className="flex items-center justify-between text-[11px] font-bold mb-1">
                            <span className={risk.completion_percentage === 100 ? 'text-emerald-400' : 'text-sky-400'}>
                              {risk.completion_percentage}%
                            </span>
                            <span className="text-[9.5px] text-slate-400 group-hover:text-teal-300">
                              تحديث ✎
                            </span>
                          </div>
                          <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                            <div 
                              className={`h-full transition-all ${
                                risk.completion_percentage === 100 
                                  ? 'bg-emerald-500' 
                                  : 'bg-gradient-to-r from-sky-500 to-teal-500'
                              }`}
                              style={{ width: `${risk.completion_percentage}%` }}
                            />
                          </div>
                          <div className="mt-1 text-center">
                            <span className={`text-[9px] font-bold ${
                              risk.status === 'controlled' || risk.completion_percentage === 100 
                                ? 'text-emerald-400' 
                                : 'text-amber-400'
                            }`}>
                              {risk.status === 'controlled' || risk.completion_percentage === 100 ? 'تمت السيطرة ✓' : 'قيد المعالجة'}
                            </span>
                          </div>
                        </button>
                      </td>

                      {/* 9. Actions */}
                      <td className="p-3.5 text-center align-top">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => handleOpenEditModal(risk)}
                            className="p-1.5 text-slate-400 hover:text-sky-300 hover:bg-slate-800 rounded-lg transition"
                            title="تعديل تفاصيل الخطر"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteRisk(risk.id)}
                            className="p-1.5 text-slate-500 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition"
                            title="حذف الخطر"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 4. MODAL: ADD / EDIT RISK ASSESSMENT FORM */}
      {/* ========================================================================= */}
      {showAddEditModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-sm overflow-y-auto" dir="rtl">
          <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between px-5 py-4 bg-slate-950 border-b border-slate-800 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-teal-500/20 border border-teal-500/30 flex items-center justify-center text-teal-400">
                  <ShieldAlert className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-white">
                    {editingRisk ? 'تعديل وتقييم الخطر المسجل' : 'إضافة وتقييم خطر جديد بمصفوفة المخاطر'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    نموذج التقييم الذكي وفق معايير CBAHI FMS.1 و مصفوفة المخاطر 5×5
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowAddEditModal(false)}
                className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body Form */}
            <form onSubmit={handleSaveRiskForm} className="p-5 space-y-5 overflow-y-auto flex-1 custom-scrollbar">
              
              {/* Row 1: Department & Category */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1">
                    <Building2 className="w-3.5 h-3.5 text-teal-400" />
                    <span>القسم أو الموقع المعني:</span>
                    <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formDepartment}
                    onChange={(e) => setFormDepartment(e.target.value)}
                    placeholder="مثال: قسم العناية المركزة ICU، محطة الغازات، الطوارئ..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-teal-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1">
                    <Layers className="w-3.5 h-3.5 text-teal-400" />
                    <span>تصنيف الخطر الأساسي:</span>
                    <span className="text-rose-400">*</span>
                  </label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value as RiskCategory)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-teal-500"
                  >
                    {RISK_CATEGORIES.map(c => (
                      <option key={c.id} value={c.id}>{c.nameAr}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Row 2: Title & Detailed Hazard Description */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1">
                  <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
                  <span>عنوان الخطر والتهديد:</span>
                  <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="مثال: انقطاع التيار الكهربائي وتأخر لوحة ATS للمولدات..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    وصف الخطر والسيناريو المحتمل بالتفصيل:
                  </label>
                  <textarea
                    rows={2}
                    required
                    value={formHazardDesc}
                    onChange={(e) => setFormHazardDesc(e.target.value)}
                    placeholder="اشرح مسببات الخطر ومكانه والظروف المؤدية لحدوثه..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-teal-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    الآثار والتبعات المتوقعة في حال حدوثه (Consequences):
                  </label>
                  <textarea
                    rows={2}
                    value={formConsequences}
                    onChange={(e) => setFormConsequences(e.target.value)}
                    placeholder="مثال: توقف أجهزة الإنعاش، تلوث الهواء، إصابات، خسائر مالية..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-teal-500"
                  />
                </div>
              </div>

              {/* ========================================================================= */}
              {/* DYNAMIC 5x5 ASSESSMENT INTERACTIVE SELECTORS */}
              {/* ========================================================================= */}
              <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <div className="flex items-center gap-2">
                    <Target className="w-4 h-4 text-teal-400" />
                    <h4 className="text-xs sm:text-sm font-bold text-white">
                      التقييم الأولي لمستوى الخطورة (Initial Risk Matrix Assessment):
                    </h4>
                  </div>
                  
                  {/* Live Calculated Score Badge */}
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-400">ناتج الخطورة:</span>
                    <span className={`px-3 py-1 rounded-xl font-mono font-black text-sm border ${currentFormLevel.badgeClass}`}>
                      {currentFormScore} • {currentFormLevel.labelAr}
                    </span>
                  </div>
                </div>

                {/* 1. Likelihood Selector (1 to 5) */}
                <div>
                  <label className="block text-xs font-bold text-slate-200 mb-2">
                    1. الاحتمالية (Likelihood) - اختر من 1 إلى 5:
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-5 gap-2">
                    {LIKELIHOOD_SCALES.map((scale) => {
                      const isSelected = formLikelihood === scale.score;
                      return (
                        <div
                          key={scale.score}
                          onClick={() => setFormLikelihood(scale.score)}
                          className={`p-2.5 rounded-xl border transition cursor-pointer text-right flex flex-col justify-between ${
                            isSelected
                              ? 'bg-teal-950/80 border-teal-500 text-white shadow-lg ring-1 ring-teal-500'
                              : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-sm text-teal-300 font-mono">{scale.score}</span>
                            {isSelected && <Check className="w-3.5 h-3.5 text-teal-400" />}
                          </div>
                          <div className="mt-1">
                            <strong className="text-xs text-white block leading-tight">{scale.labelAr}</strong>
                            <p className="text-[10px] text-slate-400 mt-0.5 leading-snug line-clamp-2">
                              {scale.frequencyDesc}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* 2. Severity Selector (1 to 5) */}
                <div>
                  <label className="block text-xs font-bold text-slate-200 mb-2">
                    2. شدة الأثر (Severity) - اختر من 1 إلى 5:
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-5 gap-2">
                    {SEVERITY_SCALES.map((scale) => {
                      const isSelected = formSeverity === scale.score;
                      return (
                        <div
                          key={scale.score}
                          onClick={() => setFormSeverity(scale.score)}
                          className={`p-2.5 rounded-xl border transition cursor-pointer text-right flex flex-col justify-between ${
                            isSelected
                              ? 'bg-amber-950/80 border-amber-500 text-white shadow-lg ring-1 ring-amber-500'
                              : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-sm text-amber-300 font-mono">{scale.score}</span>
                            {isSelected && <Check className="w-3.5 h-3.5 text-amber-400" />}
                          </div>
                          <div className="mt-1">
                            <strong className="text-xs text-white block leading-tight">{scale.labelAr}</strong>
                            <p className="text-[10px] text-slate-400 mt-0.5 leading-snug line-clamp-2">
                              {scale.impactDesc}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Actionable Guidance Note based on Score */}
                <div className={`p-3 rounded-xl border text-xs leading-relaxed flex items-start gap-2.5 ${
                  currentFormScore >= 20 ? 'bg-rose-950/70 border-rose-600 text-rose-200' :
                  currentFormScore >= 10 ? 'bg-amber-950/70 border-amber-600 text-amber-200' :
                  currentFormScore >= 5 ? 'bg-yellow-950/60 border-yellow-600 text-yellow-200' :
                  'bg-emerald-950/60 border-emerald-600 text-emerald-200'
                }`}>
                  <Info className="w-4 h-4 shrink-0 mt-0.5" />
                  <div>
                    <strong>التوجيه المعياري: </strong>
                    <span>{currentFormLevel.descriptionAr}</span>
                  </div>
                </div>
              </div>

              {/* Row 3: Current Controls & Action Plan */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    الضوابط والتدابير الوقائية الحالية القائمة:
                  </label>
                  <textarea
                    rows={2}
                    value={formCurrentControls}
                    onChange={(e) => setFormCurrentControls(e.target.value)}
                    placeholder="مثال: صيانة دورية، فحص أسبوعي، طفايات حريق، كتيبات MSDS..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-teal-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1">
                    <span>خطة الإجراءات الوقائية والتصحيحية (Action Plan / CAP):</span>
                    <span className="text-rose-400">*</span>
                  </label>
                  <textarea
                    rows={2}
                    required
                    value={formActionPlan}
                    onChange={(e) => setFormActionPlan(e.target.value)}
                    placeholder="حدد الإجراءات الإضافية لتقليل الاحتمالية والأثر..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-teal-500"
                  />
                </div>
              </div>

              {/* Row 4: Assignee, Target Date & Progress Slider */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1">
                    <User className="w-3.5 h-3.5 text-teal-400" />
                    <span>المسؤول عن التنفيذ:</span>
                  </label>
                  <input
                    type="text"
                    value={formResponsiblePerson}
                    onChange={(e) => setFormResponsiblePerson(e.target.value)}
                    placeholder="اسم المهندس / المنصب المسؤول..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-teal-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-amber-400" />
                    <span>تاريخ الإنجاز المستهدف:</span>
                  </label>
                  <input
                    type="date"
                    value={formTargetDate}
                    onChange={(e) => setFormTargetDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
                    <span className="flex items-center gap-1">
                      <Percent className="w-3.5 h-3.5 text-sky-400" />
                      <span>نسبة الإنجاز والمعالجة:</span>
                    </span>
                    <strong className="text-sky-400">{formCompletionPercent}%</strong>
                  </label>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    step={5}
                    value={formCompletionPercent}
                    onChange={(e) => setFormCompletionPercent(Number(e.target.value))}
                    className="w-full accent-teal-500 cursor-pointer"
                  />
                </div>
              </div>

              {/* Residual Risk Assessment (التقييم المتبقي بعد الضوابط) */}
              <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-3.5 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>التقييم المتبقي المتوقع بعد تنفيذ خطة العمل (Residual Risk):</span>
                  </span>
                  <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${currentResidualFormLevel.badgeClass}`}>
                    الناتج المتبقي: {currentResidualFormScore} ({currentResidualFormLevel.labelAr})
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">الاحتمالية المتبقية (1-5):</label>
                    <select
                      value={formResidualLikelihood}
                      onChange={(e) => setFormResidualLikelihood(Number(e.target.value) as RiskLikelihood)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-xs text-white"
                    >
                      {LIKELIHOOD_SCALES.map(s => (
                        <option key={s.score} value={s.score}>{s.score} - {s.labelAr}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">شدة الأثر المتبقية (1-5):</label>
                    <select
                      value={formResidualSeverity}
                      onChange={(e) => setFormResidualSeverity(Number(e.target.value) as RiskSeverity)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-xs text-white"
                    >
                      {SEVERITY_SCALES.map(s => (
                        <option key={s.score} value={s.score}>{s.score} - {s.labelAr}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800 shrink-0">
                <button
                  type="button"
                  onClick={() => setShowAddEditModal(false)}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-300 hover:bg-slate-800 transition"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-teal-950 transition active:scale-95"
                >
                  {editingRisk ? 'حفظ التعديلات والتحديث' : 'حفظ الخطر في السجل المعتمد'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. MODAL: QUICK UPDATE PROGRESS & RESIDUAL RISK */}
      {/* ========================================================================= */}
      {showProgressModal && selectedRiskForProgress && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-sm" dir="rtl">
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700 rounded-3xl shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h4 className="text-sm font-bold text-white">
                  تحديث نسبة المعالجة وإعادة تقييم الخطر المتبقي
                </h4>
                <p className="text-[11px] text-teal-400 font-mono mt-0.5">
                  {selectedRiskForProgress.risk_code} • {selectedRiskForProgress.title}
                </p>
              </div>
              <button
                onClick={() => setShowProgressModal(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Progress Slider */}
            <div>
              <div className="flex items-center justify-between text-xs font-bold text-slate-300 mb-1.5">
                <span>نسبة إنجاز خطة المعالجة (CAP):</span>
                <strong className="text-teal-400 text-sm">{progressPercentInput}%</strong>
              </div>
              <input
                type="range"
                min={0}
                max={100}
                step={5}
                value={progressPercentInput}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  setProgressPercentInput(val);
                  if (val === 100) setProgressStatusInput('controlled');
                }}
                className="w-full accent-teal-500 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500 mt-1">
                <span>0% (قيد البدء)</span>
                <span>50% (نصف مكتمل)</span>
                <span>100% (تمت السيطرة بالكامل)</span>
              </div>
            </div>

            {/* Residual Likelihood & Severity */}
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2.5">
              <span className="text-xs font-bold text-slate-300 block">
                إعادة تقييم الخطر المتبقي (Residual Risk Score):
              </span>
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="text-[10px] text-slate-400 block mb-1">الاحتمالية المتبقية (1-5):</label>
                  <select
                    value={progressResidualL}
                    onChange={(e) => setProgressResidualL(Number(e.target.value) as RiskLikelihood)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white text-xs"
                  >
                    {LIKELIHOOD_SCALES.map(s => (
                      <option key={s.score} value={s.score}>{s.score} - {s.labelAr}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[10px] text-slate-400 block mb-1">شدة الأثر المتبقية (1-5):</label>
                  <select
                    value={progressResidualS}
                    onChange={(e) => setProgressResidualS(Number(e.target.value) as RiskSeverity)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white text-xs"
                  >
                    {SEVERITY_SCALES.map(s => (
                      <option key={s.score} value={s.score}>{s.score} - {s.labelAr}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="text-center pt-1">
                <span className="text-[11px] text-slate-400">ناتج الخطر المتبقي بعد الإجراءات: </span>
                <strong className="text-emerald-400 font-mono font-black text-sm">
                  {calculateRiskScore(progressResidualL, progressResidualS)}
                </strong>
              </div>
            </div>

            {/* Action Notes */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                ملاحظات المتابعة والتدقيق:
              </label>
              <textarea
                rows={2}
                value={progressActionNotes}
                onChange={(e) => setProgressActionNotes(e.target.value)}
                placeholder="أدخل ملخص الإجراءات المنفذة وتاريخ التدقيق..."
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white"
              />
            </div>

            {/* Buttons */}
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setShowProgressModal(false)}
                className="px-3 py-2 text-xs font-bold text-slate-400 hover:text-white"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={handleSaveProgress}
                className="px-5 py-2 bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold rounded-xl shadow transition"
              >
                اعتماد التحديث
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
