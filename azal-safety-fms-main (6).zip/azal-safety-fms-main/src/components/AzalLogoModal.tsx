import React, { useState } from 'react';
import { 
  X, 
  Download, 
  Sparkles, 
  Heart, 
  Award, 
  Printer, 
  Sun, 
  Leaf, 
  CheckCircle2, 
  Palette 
} from 'lucide-react';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';
import { executeSmartPrint } from '../utils/printUtils';

interface AzalLogoModalProps {
  onClose: () => void;
}

export const AzalLogoModal: React.FC<AzalLogoModalProps> = ({ onClose }) => {
  const [previewBg, setPreviewBg] = useState<'white' | 'dark'>('white');
  const [previewType, setPreviewType] = useState<'horizontal' | 'shield'>('shield');

  const handleDownloadSVG = () => {
    const link = document.createElement('a');
    link.href = previewType === 'shield' ? '/azal-official-shield.svg' : '/azal-logo.svg';
    link.download = previewType === 'shield' ? 'Azal_Hospital_Official_Paper_Shield.svg' : 'Azal_Hospital_Official_Logo.svg';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDownloadIconSVG = () => {
    const link = document.createElement('a');
    link.href = '/icon.svg';
    link.download = 'Azal_Hospital_App_Icon.svg';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrintBadge = () => {
    triggerSuccessFeedback();
    const badgeHtml = `
      <div style="text-align:center; padding:30px; max-width:650px; margin:0 auto; border:2px solid #0d9488; border-radius:16px;">
        <div style="margin-bottom:20px;">
          <img src="/azal-logo.svg" alt="شعار مستشفى آزال النموذجي" style="max-height:100px; margin:0 auto; display:block;" />
        </div>
        <div style="font-size:20px; font-weight:900; color:#0f172a; margin-bottom:6px;">الهوية البصرية والعلامة الرسمية المعتمدة</div>
        <div style="font-size:13px; color:#0d9488; font-weight:bold; margin-bottom:24px;">مستشفى آزال • الرعاية الكاملة • AZAL Hospital</div>

        <div style="text-align:right; font-size:13px; line-height:1.8; color:#334155; margin-bottom:24px;">
          <p><strong>• إكليل الورقة الخضراء:</strong> منحنى انسيابي دائم الخضرة يرمز للبيئة الصحية الآمنة والرعاية المستمرة.</p>
          <p><strong>• برعم الوردة القرمزي (النبض):</strong> يرمز لروح الحياة وسرعة الاستجابة الطبية والإنقاذ على مدار 24 ساعة.</p>
          <p><strong>• شمس آزال والورقة المتوجة:</strong> القرص البرتقالي الشمسي يعبر عن إشراقة الشفاء والأمل والدفء الإنساني.</p>
          <p><strong>• شعار "الرعاية الكاملة":</strong> الالتزام المؤسسي بأعلى معايير جودة الرعاية وسلامة المرضى.</p>
        </div>

        <div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:12px; padding:12px; font-size:11px; color:#64748b;">
          وثيقة اعتماد الهوية البصرية • إدارة العلاقات العامة والجودة والاعتماد CBAHI • مستشفى آزال النموذجي
        </div>
      </div>
    `;

    executeSmartPrint(badgeHtml, {
      title: 'دليل الهوية البصرية الرسمية - مستشفى آزال النموذجي',
      subtitle: 'مستشفى آزال • الرعاية الكاملة • إدارة الجودة والاعتماد',
      refNumber: 'AZAL-BRAND-IDENTITY-2026'
    });
  };

  return (
    <div id="azal-logo-modal" className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 text-right overflow-y-auto">
      <div className="bg-slate-900 border border-emerald-500/40 rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-slate-950 px-5 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-950/80 border border-emerald-800/80 text-emerald-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100">
                الهوية البصرية الرسمية لمستشفى آزال - الرعاية الكاملة
              </h3>
              <p className="text-xs text-emerald-400">
                مستشفى آزال • الرعاية الكاملة • AZAL Hospital
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-100 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-5 overflow-y-auto">
          {/* Controls: Type and Background Toggle */}
          <div className="flex flex-wrap items-center justify-between gap-2 bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-xs">
            <div className="flex items-center gap-1">
              <span className="text-slate-400 font-medium ml-1">نموذج الشعار:</span>
              <button
                type="button"
                onClick={() => setPreviewType('shield')}
                className={`px-3 py-1 rounded-lg font-bold transition text-xs flex items-center gap-1.5 ${
                  previewType === 'shield'
                    ? 'bg-emerald-600 text-white shadow'
                    : 'text-slate-400 hover:text-slate-200 bg-slate-800'
                }`}
              >
                <span>🛡️ درع الأوراق والمستندات الرسمية</span>
              </button>
              <button
                type="button"
                onClick={() => setPreviewType('horizontal')}
                className={`px-3 py-1 rounded-lg font-bold transition text-xs flex items-center gap-1.5 ${
                  previewType === 'horizontal'
                    ? 'bg-emerald-600 text-white shadow'
                    : 'text-slate-400 hover:text-slate-200 bg-slate-800'
                }`}
              >
                <span>📜 الشعار الأفقي الكامل</span>
              </button>
            </div>

            <div className="flex items-center gap-1">
              <span className="text-slate-400 font-medium">الخلفية:</span>
              <button
                type="button"
                onClick={() => setPreviewBg('white')}
                className={`px-2.5 py-1 rounded-lg font-bold transition text-xs flex items-center gap-1 ${
                  previewBg === 'white' 
                    ? 'bg-white text-slate-900 shadow' 
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <span className="w-2.5 h-2.5 rounded-full bg-slate-200 border border-slate-400" />
                <span>البيضاء</span>
              </button>
              <button
                type="button"
                onClick={() => setPreviewBg('dark')}
                className={`px-2.5 py-1 rounded-lg font-bold transition text-xs flex items-center gap-1 ${
                  previewBg === 'dark' 
                    ? 'bg-slate-800 text-teal-300 border border-teal-500/40 shadow' 
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <span className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-600" />
                <span>الداكنة</span>
              </button>
            </div>
          </div>

          {/* Logo High-Res Preview Box */}
          <div className={`relative p-6 sm:p-8 rounded-2xl border transition-all flex flex-col items-center justify-center text-center shadow-inner ${
            previewBg === 'white' 
              ? 'bg-white border-slate-200 shadow-md' 
              : 'bg-gradient-to-b from-slate-950 via-slate-900 to-teal-950/50 border-teal-800/50'
          }`}>
            <div className="w-full max-w-lg relative group flex items-center justify-center">
              <img
                src={previewType === 'shield' ? '/azal-official-shield.svg' : '/azal-logo.svg'}
                alt="شعار مستشفى أزال الرسمي"
                className={`w-auto object-contain filter drop-shadow-sm group-hover:scale-[1.02] transition-transform duration-300 ${
                  previewType === 'shield' ? 'h-64 sm:h-72' : 'w-full h-auto max-h-52'
                }`}
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="mt-4 pt-3 border-t border-slate-200/40 w-full flex items-center justify-center gap-2">
              <span className={`text-xs font-bold ${previewBg === 'white' ? 'text-slate-600' : 'text-emerald-400'}`}>
                {previewType === 'shield' 
                  ? 'نموذج درع الأوراق والتقارير الرسمية المعتمد (طباعة المستندات والهوية المؤسسية)'
                  : 'الشعار الأفقي الرسمي الكامل • مستشفى أزال النموذجي • الرعاية الكاملة'
                }
              </span>
            </div>
          </div>

          {/* Official Brand Identity & Color Palette */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
              <Palette className="w-4 h-4 text-emerald-400" />
              <span>لوحة ألوان الهوية المعتمدة (Official Color Palette):</span>
            </h4>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-[#6DB33F] shrink-0 border border-emerald-400/40 shadow-sm" />
                <div>
                  <span className="font-bold text-slate-200 block text-[11px]">أخضر النماء والرعاية</span>
                  <span className="text-slate-400 text-[10px] font-mono">#6DB33F</span>
                </div>
              </div>

              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-[#E11D48] shrink-0 border border-rose-400/40 shadow-sm" />
                <div>
                  <span className="font-bold text-slate-200 block text-[11px]">أحمر برعم الحياة</span>
                  <span className="text-slate-400 text-[10px] font-mono">#E11D48</span>
                </div>
              </div>

              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-[#F58220] shrink-0 border border-amber-400/40 shadow-sm" />
                <div>
                  <span className="font-bold text-slate-200 block text-[11px]">شمس أزال المشرقة</span>
                  <span className="text-slate-400 text-[10px] font-mono">#F58220</span>
                </div>
              </div>

              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-[#111827] shrink-0 border border-slate-600 shadow-sm" />
                <div>
                  <span className="font-bold text-slate-200 block text-[11px]">الأسود الفخم الرصين</span>
                  <span className="text-slate-400 text-[10px] font-mono">#111827</span>
                </div>
              </div>
            </div>
          </div>

          {/* Heraldic & Symbolism Explanation */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold text-teal-400 flex items-center gap-1.5">
              <Award className="w-4 h-4 text-emerald-400" />
              <span>دلالات ومعاني عناصر الشعار المعتمد:</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-start gap-2.5">
                <div className="p-1.5 rounded-lg bg-emerald-950 text-emerald-400 shrink-0 mt-0.5">
                  <Leaf className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-slate-200 block">إكليل الورقة الخضراء والشفاء:</span>
                  <span className="text-slate-400 text-[11px] leading-relaxed">
                    منحنى انسيابي دائم الخضرة يحتضن الحياة ويرمز للبيئة الصحية الآمنة والرعاية المستمرة.
                  </span>
                </div>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-start gap-2.5">
                <div className="p-1.5 rounded-lg bg-rose-950 text-rose-400 shrink-0 mt-0.5">
                  <Heart className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-slate-200 block">برعم الوردة القرمزي (النبض):</span>
                  <span className="text-slate-400 text-[11px] leading-relaxed">
                    يرمز لروح الحياة النابضة وسرعة الاستجابة الطبية والإنقاذ العاجل على مدار 24 ساعة.
                  </span>
                </div>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-start gap-2.5">
                <div className="p-1.5 rounded-lg bg-amber-950 text-amber-400 shrink-0 mt-0.5">
                  <Sun className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-slate-200 block">شمس أزال والورقة المتوجة:</span>
                  <span className="text-slate-400 text-[11px] leading-relaxed">
                    القرص البرتقالي الشمسي فوق حرف الألف يعبر عن إشراقة الشفاء والأمل والدفء الإنساني.
                  </span>
                </div>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-start gap-2.5">
                <div className="p-1.5 rounded-lg bg-teal-950 text-teal-400 shrink-0 mt-0.5">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-slate-200 block">شعار "الرعاية الكاملة":</span>
                  <span className="text-slate-400 text-[11px] leading-relaxed">
                    الالتزام المؤسسي بأعلى معايير جودة الرعاية وسلامة المرضى والكوادر الطبية.
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="bg-slate-950 px-5 py-3.5 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrintBadge}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold flex items-center gap-1.5 transition"
            >
              <Printer className="w-4 h-4" />
              <span>طباعة الهوية</span>
            </button>
            <button
              type="button"
              onClick={handleDownloadIconSVG}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-emerald-400 rounded-xl text-xs font-bold flex items-center gap-1.5 transition border border-emerald-800/60"
            >
              <Download className="w-4 h-4" />
              <span>تحميل الأيقونة</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 text-slate-400 hover:text-slate-200 rounded-xl text-xs font-semibold"
            >
              إغلاق
            </button>
            <button
              type="button"
              onClick={handleDownloadSVG}
              className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-slate-950 font-black rounded-xl text-xs shadow-lg shadow-emerald-950 flex items-center gap-1.5 transition active:scale-95"
            >
              <Download className="w-4 h-4" />
              <span>تحميل الشعار الكامل (SVG)</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
