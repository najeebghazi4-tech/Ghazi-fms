import React, { useState } from 'react';
import { ArrowRight, Lock, ShieldCheck, X } from 'lucide-react';

interface GlobalPortalBackBarProps {
  onBack?: () => void;
  title?: string;
}

export const GlobalPortalBackBar: React.FC<GlobalPortalBackBarProps> = ({
  onBack,
  title = 'بوابة البلاغات والسلامة العامة'
}) => {
  const [showPinModal, setShowPinModal] = useState(false);
  const [pin, setPin] = useState('');
  const [pinError, setPinError] = useState(false);

  const handleOpenAuth = () => {
    setPin('');
    setPinError(false);
    setShowPinModal(true);
  };

  const handleVerifyPin = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin.trim() === '1984') {
      setShowPinModal(false);
      if (onBack) {
        onBack();
      } else {
        window.location.href = '/';
      }
    } else {
      setPinError(true);
      setPin('');
    }
  };

  return (
    <>
      {/* الشريط العلوي للبوابة */}
      <header className="bg-slate-900 text-white shadow-md border-b border-slate-800 sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-4 py-2.5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-sm md:text-base font-bold text-white tracking-wide">
              {title}
            </span>
          </div>

          <button
            onClick={handleOpenAuth}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs md:text-sm font-medium bg-slate-800 hover:bg-slate-700 active:bg-slate-600 text-slate-200 border border-slate-700 rounded-lg shadow-sm transition"
            title="الدخول للوحة التحكم المعتمدة"
          >
            <Lock className="w-3.5 h-3.5 text-amber-400" />
            <span>لوحة التحكم</span>
            <ArrowRight className="w-4 h-4 text-slate-400" />
          </button>
        </div>
      </header>

      {/* نافذة التحقق من الرمز السري */}
      {showPinModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 text-slate-800 shadow-2xl border border-slate-100 relative text-right" dir="rtl">
            <button
              onClick={() => setShowPinModal(false)}
              className="absolute left-4 top-4 text-slate-400 hover:text-slate-600"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-12 h-12 bg-amber-50 rounded-2xl flex items-center justify-center mx-auto mb-3 border border-amber-200 text-amber-600">
              <ShieldCheck className="w-6 h-6" />
            </div>

            <h3 className="text-center font-bold text-base text-slate-800 mb-1">
              منطقة إدارية مقيدة
            </h3>
            <p className="text-center text-xs text-slate-500 mb-4">
              أدخل رمز المرور الإداري للوصول إلى لوحة التحكم
            </p>

            <form onSubmit={handleVerifyPin} className="space-y-4">
              <div>
                <input
                  type="password"
                  inputMode="numeric"
                  maxLength={4}
                  autoFocus
                  placeholder="••••"
                  value={pin}
                  onChange={(e) => {
                    setPin(e.target.value);
                    if (pinError) setPinError(false);
                  }}
                  className="w-full text-center tracking-widest text-2xl font-bold py-2.5 px-4 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none"
                />
                {pinError && (
                  <p className="text-rose-600 text-xs text-center mt-1 font-semibold">
                    رمز المرور غير صحيح!
                  </p>
                )}
              </div>

              <div className="flex gap-2">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 rounded-xl text-sm transition shadow-sm"
                >
                  دخول
                </button>
                <button
                  type="button"
                  onClick={() => setShowPinModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-xl text-sm transition"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
};
