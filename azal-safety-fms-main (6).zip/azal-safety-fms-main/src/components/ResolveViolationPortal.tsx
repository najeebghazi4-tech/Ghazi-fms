import React, { useState, useRef, useMemo, useEffect } from 'react';
import { 
  Camera, 
  CheckCircle2, 
  AlertTriangle, 
  Save, 
  FileCheck, 
  Globe,
  Send,
  Phone,
  MessageSquare,
  Copy,
  Check,
  Share2
} from 'lucide-react';
import { SafetyViolationNotice, SafetyIncidentReport } from '../types';
import { AzalLogo } from './AzalLogo';
import { 
  sanitizeInput, 
  validateImageFile, 
  validateMediaFile,
  checkRateLimit 
} from '../utils/securityUtils';
import { cleanYemeniPhoneNumber } from '../utils/phoneUtils';
import { cloudSync } from '../services/cloudSyncService';
import { supabase } from '../services/supabaseClient';
import { VoiceDictationButton } from './VoiceDictationButton';
import { db } from '../services/firebase';
import { doc, getDoc } from 'firebase/firestore';
import { GlobalPortalBackBar } from './public/GlobalPortalBackBar';

interface ResolveViolationPortalProps {
  violationId: string;
  violations?: SafetyViolationNotice[];
  incidents?: SafetyIncidentReport[];
  onResolveViolation: (violationId: string, resolutionNote: string, afterPhotoUrl?: string, resolvedBy?: string) => void;
  onBackToApp?: () => void;
}

export const ResolveViolationPortal: React.FC<ResolveViolationPortalProps> = ({
  violationId,
  violations = [],
  incidents = [],
  onResolveViolation,
}) => {
  // Parse ID directly from parameter, hash (#statement?ref=... or #resolve?id=...) or search params
  const effectiveId = useMemo(() => {
    if (violationId && violationId !== 'DEFAULT') return violationId;
    if (typeof window !== 'undefined') {
      const hash = window.location.hash || '';
      if (hash.includes('?')) {
        const hp = new URLSearchParams(hash.split('?')[1]);
        const hid = hp.get('ref') || hp.get('id') || hp.get('resolve');
        if (hid) return decodeURIComponent(hid.trim());
      }
      const sp = new URLSearchParams(window.location.search);
      const sid = sp.get('ref') || sp.get('id') || sp.get('resolve');
      if (sid) return decodeURIComponent(sid.trim());
    }
    return (violationId && violationId !== 'DEFAULT') ? violationId : '';
  }, [violationId]);

  // Load all violations from prop or local storage
  const allViolations: SafetyViolationNotice[] = useMemo(() => {
    const list: SafetyViolationNotice[] = [...(violations || [])];
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('azal_violations_v1');
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            parsed.forEach((item) => {
              if (item && item.id && !list.some((x) => x.id.toLowerCase() === item.id.toLowerCase())) {
                list.push(item);
              }
            });
          }
        }
      } catch {}
      try {
        const savedIdb = localStorage.getItem('azal_idb_violations');
        if (savedIdb) {
          const parsed = JSON.parse(savedIdb);
          if (Array.isArray(parsed)) {
            parsed.forEach((item) => {
              if (item && item.id && !list.some((x) => x.id.toLowerCase() === item.id.toLowerCase())) {
                list.push(item);
              }
            });
          }
        }
      } catch {}
    }
    return list;
  }, [violations]);

  // Load all incidents from prop or local storage
  const allIncidents: SafetyIncidentReport[] = useMemo(() => {
    const list: SafetyIncidentReport[] = [...(incidents || [])];
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('azal_safety_incidents_v1');
        if (saved) {
          const parsed = JSON.parse(saved);
          if (Array.isArray(parsed)) {
            parsed.forEach((item) => {
              if (item && item.id && !list.some((x) => String(x.id).toLowerCase() === String(item.id).toLowerCase())) {
                list.push(item);
              }
            });
          }
        }
      } catch {}
      try {
        const savedIdb = localStorage.getItem('azal_idb_incidents');
        if (savedIdb) {
          const parsed = JSON.parse(savedIdb);
          if (Array.isArray(parsed)) {
            parsed.forEach((item) => {
              if (item && item.id && !list.some((x) => String(x.id).toLowerCase() === String(item.id).toLowerCase())) {
                list.push(item);
              }
            });
          }
        }
      } catch {}
    }
    return list;
  }, [incidents]);

  // Look up by ID or by publicToken UUID in violations
  const [firestoreNotice, setFirestoreNotice] = useState<SafetyViolationNotice | null>(null);

  useEffect(() => {
    let active = true;
    const fetchFromFirestore = async () => {
      if (!effectiveId || effectiveId === 'DEFAULT') return;
      try {
        const cleanId = effectiveId.trim();
        // 1. Try violations
        const vioRef = doc(db, 'violations', cleanId);
        const vioSnap = await getDoc(vioRef);
        if (vioSnap.exists() && active) {
          setFirestoreNotice(vioSnap.data() as SafetyViolationNotice);
          return;
        }

        // 2. Try incidents
        const incRef = doc(db, 'incidents', cleanId);
        const incSnap = await getDoc(incRef);
        if (incSnap.exists() && active) {
          const incData = incSnap.data() as SafetyIncidentReport;
          setFirestoreNotice({
            id: String(incData.id),
            tourId: 'incident-report',
            department: incData.department || 'إدارة الأمن والسلامة',
            locationDetail: incData.locationDetail || 'مستشفى آزال النموذجي',
            description: incData.categoryAr + (incData.description ? ` - ${incData.description}` : ''),
            assignedTo: 'فريق المعالجة الميدانية / قسم السلامة',
            assignedToCustom: 'فريق المعالجة الميدانية',
            deadlineHours: 24,
            deadlineAt: 'عاجل خلال 24 ساعة',
            severity: (incData.severity as any) || 'high',
            status: incData.status === 'resolved' ? 'resolved' : 'pending',
            resolutionNote: incData.resolutionNotes || '',
            resolvedBy: incData.resolvedBy || '',
            createdAt: incData.reportedAt || new Date().toLocaleDateString('ar-EG'),
            timestamp: Date.now(),
            synced: true,
          });
        }
      } catch (err) {
        console.warn('Firestore fetch notice error:', err);
      }
    };
    fetchFromFirestore();
    return () => { active = false; };
  }, [effectiveId]);

  const matchedViolation = useMemo(() => {
    const cleanEffective = effectiveId.trim().toLowerCase();
    const cleanNum = cleanEffective.replace(/\D/g, '');

    return allViolations.find((v) => {
      if (!v) return false;
      const vId = String(v.id).trim().toLowerCase();
      const pToken = v.publicToken ? String(v.publicToken).trim().toLowerCase() : '';
      const vNum = vId.replace(/\D/g, '');

      return (
        vId === cleanEffective ||
        pToken === cleanEffective ||
        vId.replace('-2026-', '-') === cleanEffective.replace('-2026-', '-') ||
        cleanEffective.replace('-2026-', '-') === vId ||
        (cleanNum.length > 0 && vNum === cleanNum) ||
        vId.endsWith(cleanEffective) ||
        cleanEffective.endsWith(vId)
      );
    });
  }, [allViolations, effectiveId]);

  // Look up by numeric ID or codeNumber in incidents
  const matchedIncident = useMemo(() => {
    if (matchedViolation) return null;
    const cleanEffective = effectiveId.trim().toLowerCase();
    const cleanNum = cleanEffective.replace(/\D/g, '');

    return allIncidents.find((i) => {
      if (!i) return false;
      const iId = String(i.id).trim().toLowerCase();
      const code = i.codeNumber ? String(i.codeNumber).trim().toLowerCase() : '';
      const iNum = iId.replace(/\D/g, '');

      return (
        iId === cleanEffective ||
        code === cleanEffective ||
        (cleanNum.length > 0 && iNum === cleanNum) ||
        code.endsWith(cleanEffective) ||
        cleanEffective.endsWith(code)
      );
    });
  }, [matchedViolation, allIncidents, effectiveId]);

  // Build unified notice view for the public resolution form
  const violation: SafetyViolationNotice = useMemo(() => {
    if (matchedViolation) return matchedViolation;
    if (firestoreNotice) return firestoreNotice;

    if (matchedIncident) {
      return {
        id: String(matchedIncident.id),
        tourId: 'incident-report',
        department: matchedIncident.department || 'إدارة الأمن والسلامة',
        locationDetail: matchedIncident.locationDetail || 'مستشفى آزال النموذجي',
        description: matchedIncident.categoryAr + (matchedIncident.description ? ` - ${matchedIncident.description}` : ''),
        assignedTo: 'فريق المعالجة الميدانية / قسم السلامة',
        assignedToCustom: 'فريق المعالجة الميدانية',
        deadlineHours: 24,
        deadlineAt: 'عاجل خلال 24 ساعة',
        severity: (matchedIncident.severity as any) || 'high',
        status: matchedIncident.status === 'resolved' ? 'resolved' : 'pending',
        resolutionNote: matchedIncident.resolutionNotes || '',
        resolvedBy: matchedIncident.resolvedBy || '',
        createdAt: matchedIncident.reportedAt || new Date().toLocaleDateString('ar-EG'),
        timestamp: Date.now(),
        synced: true,
      };
    }

    if (typeof window !== 'undefined') {
      const hash = window.location.hash || '';
      const search = window.location.search || '';
      const hashParams = hash.includes('?') ? new URLSearchParams(hash.split('?')[1]) : new URLSearchParams();
      const searchParams = new URLSearchParams(search);

      const urlDept = hashParams.get('dept') || searchParams.get('dept');
      const urlDesc = hashParams.get('desc') || searchParams.get('desc');
      const urlLoc = hashParams.get('loc') || searchParams.get('loc');
      const urlAssigned = hashParams.get('assigned') || searchParams.get('assigned');
      const urlDeadline = hashParams.get('deadline') || searchParams.get('deadline');

      return {
        id: effectiveId && effectiveId !== 'DEFAULT' ? effectiveId : 'AZAL-VIO-NEW',
        tourId: 'direct-public-route',
        department: urlDept ? decodeURIComponent(urlDept) : 'مستشفى آزال النموذجي',
        locationDetail: urlLoc ? decodeURIComponent(urlLoc) : 'موقع الملاحظة المسجلة',
        description: urlDesc 
          ? decodeURIComponent(urlDesc) 
          : `إشعار وملاحظة سلامة مهنية برقم (${effectiveId}) تتطلب المعالجة وتأمين الموقع ورفع إفادة الإنجاز والصور التوثيقية.`,
        assignedTo: urlAssigned ? decodeURIComponent(urlAssigned) : 'الجهة المكلفة بالمعالجة',
        assignedToCustom: urlAssigned ? decodeURIComponent(urlAssigned) : undefined,
        deadlineHours: 24,
        deadlineAt: urlDeadline ? decodeURIComponent(urlDeadline) : 'خلال 24 ساعة من تاريخ الإشعار',
        severity: 'high',
        status: 'pending',
        createdAt: new Date().toLocaleDateString('ar-EG'),
        timestamp: Date.now(),
        synced: true,
      };
    }

    return {
      id: effectiveId || '7',
      tourId: 'tour-general',
      department: 'قسم الطوارئ والإسعاف',
      locationDetail: 'مستشفى آزال النموذجي',
      description: 'ملاحظة سلامة تتطلب المعالجة العاجلة',
      assignedTo: 'قسم الصيانة والسلامة',
      deadlineHours: 24,
      deadlineAt: 'خلال 24 ساعة',
      severity: 'high',
      status: 'pending',
      createdAt: new Date().toLocaleDateString('ar-EG'),
      timestamp: Date.now(),
      synced: true,
    };
  }, [matchedViolation, matchedIncident, effectiveId]);

  const [noticeRef, setNoticeRef] = useState<string>(() => {
    if (effectiveId && effectiveId !== 'DEFAULT') return effectiveId;
    return '';
  });

  useEffect(() => {
    if (effectiveId && effectiveId !== 'DEFAULT') {
      setNoticeRef(effectiveId);
    }
  }, [effectiveId]);

  const [resolvedBy, setResolvedBy] = useState('');
  const [resolutionNote, setResolutionNote] = useState('');
  const [afterPhotoUrl, setAfterPhotoUrl] = useState('');
  const [afterMediaType, setAfterMediaType] = useState<'image' | 'video'>('image');
  const [isSuccess, setIsSuccess] = useState(false);
  const [securityError, setSecurityError] = useState<string | null>(null);
  const [managerPhone, setManagerPhone] = useState('771701323');
  const [copiedNotice, setCopiedNotice] = useState(false);
  const [isCloudSyncing, setIsCloudSyncing] = useState(false);
  const [cloudSyncDone, setCloudSyncDone] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handlePhotoCapture = async (e: React.ChangeEvent<HTMLInputElement>) => {
    setSecurityError(null);
    const file = e.target.files?.[0];
    if (file) {
      const validation = await validateMediaFile(file, 30);
      if (!validation.valid) {
        setSecurityError(validation.error || 'الملف المرفوع غير صالح.');
        if (fileInputRef.current) fileInputRef.current.value = '';
        return;
      }

      setAfterMediaType(validation.mediaType || (file.type.startsWith('video/') ? 'video' : 'image'));
      const reader = new FileReader();
      reader.onload = () => {
        setAfterPhotoUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const generateDispatchText = () => {
    const actor = violation.resolvedBy || resolvedBy || 'المسؤول الميداني';
    const note = violation.resolutionNote || resolutionNote || 'تمت المعالجة والإنجاز.';
    const portalDirectUrl = typeof window !== 'undefined' ? window.location.href : '';

    return `*إفادة إنجاز ومعالجة إشعار سلامة بمستشفى آزال النموذجي* 🟢
━━━━━━━━━━━━━━━━━━━━
📌 *رقم الإشعار:* ${violation.id}
🏢 *القسم:* ${violation.department}
📍 *الموقع:* ${violation.locationDetail}
👷‍♂️ *المكلف بالإنجاز:* ${party}
✍️ *الموثق / المنفذ:* ${actor}
📝 *نص الإفادة:* ${note}
✅ *الحالة:* تم الرد والمعالجة بنجاح
🌐 *رابط المراجعة والاعتماد:* ${portalDirectUrl}
━━━━━━━━━━━━━━━━━━━━
_تم التوثيق والاعتماد عبر نظام السلامة والأمان لمستشفى آزال النموذجي_`;
  };

  const handleSendWhatsApp = () => {
    const text = generateDispatchText();
    const phone = cleanYemeniPhoneNumber(managerPhone) || '967771701323';
    const url = `https://wa.me/${phone}?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleSendSMS = () => {
    const text = generateDispatchText();
    const phone = cleanYemeniPhoneNumber(managerPhone) || '771701323';
    const url = `sms:${phone}?body=${encodeURIComponent(text)}`;
    window.location.href = url;
  };

  const handleCopyNotice = () => {
    const text = generateDispatchText();
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setCopiedNotice(true);
      setTimeout(() => setCopiedNotice(false), 3000);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSecurityError(null);

    const rateLimit = checkRateLimit('resolve_violation', 5, 60000);
    if (!rateLimit.allowed) {
      setSecurityError(rateLimit.message || 'تم تجاوز الحد الأقصى للمحاولات.');
      return;
    }

    const cleanNote = sanitizeInput(resolutionNote);
    const cleanResolvedBy = sanitizeInput(resolvedBy);

    if (!cleanNote || !cleanResolvedBy) {
      setSecurityError('يرجى كتابة اسم المسؤول وتفاصيل الإفادة بشكل سليم.');
      return;
    }

    if (violation) {
      const targetId = noticeRef.trim() || violation.id;
      setIsCloudSyncing(true);
      // 1. Invoke local application state resolution
      onResolveViolation(targetId, cleanNote, afterPhotoUrl || undefined, cleanResolvedBy);

      // 2. Direct Firestore writes (both violation update and instant notification)
      try {
        const currentIso = new Date().toISOString();
        const currentFormatted = `${new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })} ${new Date().toLocaleDateString('ar-EG')}`;

        const updatePayload = {
          ...violation,
          id: targetId,
          status: 'resolved',
          statusAr: 'تمت المعالجة',
          resolutionNote: cleanNote,
          resolvedBy: cleanResolvedBy,
          afterPhotoUrl: afterPhotoUrl || undefined,
          resolvedAt: currentFormatted,
          synced: true,
        };

        // Supabase direct sync
        try {
          await supabase.from('safety_violations').update({
            status: 'تمت المعالجة',
            resolved_at: currentIso,
            resolved_by: cleanResolvedBy,
            resolution_note: cleanNote,
            after_photo_url: afterPhotoUrl || null,
          }).eq('id', targetId);

          await supabase.from('violations').update({
            status: 'تمت المعالجة',
            resolved_at: currentIso,
            resolved_by: cleanResolvedBy,
            resolution_note: cleanNote,
            after_photo_url: afterPhotoUrl || null,
          }).eq('id', targetId);
        } catch (supErr) {
          console.warn('[Supabase Sync Warning]:', supErr);
        }

        await cloudSync.pushRecord('violations', targetId, updatePayload);
        if (matchedIncident) {
          await supabase.from('incident_reports').update({
            status: 'تمت المعالجة',
            resolved_at: currentIso,
            resolved_by: cleanResolvedBy,
            resolution_note: cleanNote,
            after_photo_url: afterPhotoUrl || null,
          }).eq('id', matchedIncident.id);

          await cloudSync.pushRecord('incidents', String(matchedIncident.id), {
            ...matchedIncident,
            status: 'resolved',
            resolutionNotes: cleanNote,
            resolvedBy: cleanResolvedBy,
            afterPhotoUrl: afterPhotoUrl || undefined,
            resolvedAt: currentIso
          });
        }

        await cloudSync.pushNotification({
          id: `notif-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          type: 'violation_responded',
          title: `إفادة معالجة: ${targetId}`,
          body: `قام ${cleanResolvedBy} بتوثيق إفادة إنجاز للمخالفة (${targetId}): "${cleanNote}"`,
          violationId: targetId,
          department: violation.department,
          resolvedBy: cleanResolvedBy,
          resolutionNote: cleanNote,
          afterPhotoUrl: afterPhotoUrl || undefined,
          timestamp: Date.now(),
          createdAt: new Date().toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' }),
          read: false,
        });
        setCloudSyncDone(true);
      } catch (err) {
        console.warn('Direct Firestore push warning:', err);
      } finally {
        setIsCloudSyncing(false);
        setIsSuccess(true);
      }
    }
  };

  const isAlreadyResolved = violation.status === 'resolved' || violation.status === 'responded';
  const party = violation.assignedToCustom || violation.assignedTo;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between text-right" dir="rtl">
      {/* Sticky Universal Header Back Bar */}
      <GlobalPortalBackBar
        title={`إفادة إنجاز معالجة إشعار (${violation.id})`}
        subtitle="مستشفى آزال النموذجي • إدارة السلامة • إغلاق الملاحظة الميدانية"
        showServicesLink={true}
      />

      <div className="flex-1 flex flex-col justify-between py-6 px-3 sm:px-4">
      {/* Top Header */}
      <header className="max-w-md w-full mx-auto flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-white rounded-xl shadow-sm border border-slate-200">
            <AzalLogo size="sm" showText={false} />
          </div>
          <div>
            <h1 className="text-xs font-black text-slate-100">
              مستشفى آزال النموذجي
            </h1>
            <span className="text-[10px] text-teal-400 font-bold block">إدارة الأمن والسلامة</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 text-xs text-slate-400 font-mono">
          <span className="hidden sm:inline">إشعار:</span>
          <strong className="text-teal-400 font-bold bg-slate-900 px-2.5 py-1 rounded-xl border border-slate-800">
            {violation.id}
          </strong>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-md w-full mx-auto my-auto py-5 space-y-4">
        <div className="text-center space-y-2">
          <div className="flex flex-wrap items-center justify-center gap-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-950 text-teal-300 border border-teal-800 text-xs font-bold">
              <FileCheck className="w-3.5 h-3.5 text-teal-400" />
              <span>إفادة إنجاز المعالجة</span>
            </div>
            <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800 text-[10px] font-bold">
              <Globe className="w-3 h-3 text-emerald-400" />
              <span>بوابة المعالجة العامة (Zero Login)</span>
            </div>
          </div>
          <p className="text-xs text-slate-400 max-w-xs mx-auto">
            بوابة مستقلة لتوثيق إجراءات تصحيح ومعالجة الخلل ورفع صور الإنجاز فوراً
          </p>
        </div>

        {isSuccess || isAlreadyResolved ? (
          /* Standalone Confirmation Card - Strictly No Buttons to Return to System */
          <div className="bg-slate-900 border border-emerald-600/60 rounded-3xl p-6 text-center space-y-4 shadow-xl animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-700 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <div className="space-y-1">
              <h2 className="text-base font-bold text-slate-100">
                تم الإرسال بنجاح / شكراً لتعاونكم
              </h2>
              <p className="text-xs text-emerald-400 font-bold">
                تم توثيق واعتماد إفادة الإنجاز وتغيير الحالة إلى: 🟢 تم الرد والمعالجة
              </p>
              <p className="text-[11px] text-slate-400 pt-1">
                شكراً لجهودكم في الحفاظ على أعلى معايير السلامة المهنية بمستشفى آزال النموذجي.
              </p>
            </div>

            <div className="bg-slate-950 border border-slate-800 p-3.5 rounded-2xl text-right text-xs space-y-2.5">
              <div>
                <span className="text-slate-400 block text-[11px]">نص الإفادة المسجلة:</span>
                <p className="text-slate-200 font-semibold mt-0.5 leading-relaxed">
                  {violation.resolutionNote || resolutionNote}
                </p>
              </div>
              {(violation.resolvedBy || resolvedBy) && (
                <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
                  <span>تم التوثيق بواسطة:</span>
                  <strong className="text-teal-300 font-bold">
                    {violation.resolvedBy || resolvedBy}
                  </strong>
                </div>
              )}
              {(afterPhotoUrl || violation.afterPhotoUrl) && (
                <div className="pt-2 border-t border-slate-800 text-[11px]">
                  <span className="text-slate-400 block mb-1">ملف الإثبات المرفق للإنجاز:</span>
                  {afterMediaType === 'video' || (afterPhotoUrl || violation.afterPhotoUrl || '').startsWith('data:video') ? (
                    <video
                      src={afterPhotoUrl || violation.afterPhotoUrl}
                      controls
                      className="w-full max-h-48 rounded-xl bg-black object-contain"
                    />
                  ) : (
                    <img
                      src={afterPhotoUrl || violation.afterPhotoUrl}
                      alt="صورة المعالجة المرفقة"
                      className="w-full max-h-48 object-cover rounded-xl border border-slate-700"
                    />
                  )}
                </div>
              )}
            </div>

            {/* Direct Notification to Safety Manager Actions */}
            <div className="bg-slate-950 border border-emerald-800/80 rounded-2xl p-4 text-right space-y-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                  <Send className="w-3.5 h-3.5 text-emerald-400" />
                  <span>إرسال إشعار فوري لمدير السلامة</span>
                </span>
                <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded-full font-bold">
                  إشعار فوري مباشر
                </span>
              </div>

              <p className="text-[11px] text-slate-400">
                أرسل إفادة المعالجة فوراً لمدير الأمن والسلامة عبر الواتساب أو رسالة SMS لتأكيد إنجاز المهمة ووصول الإشعار إليه:
              </p>

              {/* Phone number input (prefilled with default) */}
              <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5">
                <span className="text-[11px] text-slate-400 whitespace-nowrap">رقم هاتف المدير:</span>
                <input
                  type="tel"
                  value={managerPhone}
                  onChange={(e) => setManagerPhone(e.target.value)}
                  className="bg-transparent text-emerald-300 font-mono text-xs w-full focus:outline-none text-left"
                  dir="ltr"
                  placeholder="771701323"
                />
              </div>

              <div className="space-y-2">
                {/* WhatsApp Button */}
                <button
                  type="button"
                  onClick={handleSendWhatsApp}
                  className="w-full py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-950 flex items-center justify-center gap-2 transition active:scale-95"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>📲 إرسال إشعار فوري عبر واتساب (WhatsApp)</span>
                </button>

                {/* SMS Button */}
                <button
                  type="button"
                  onClick={handleSendSMS}
                  className="w-full py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-950 flex items-center justify-center gap-2 transition active:scale-95"
                >
                  <Phone className="w-4 h-4" />
                  <span>💬 إرسال إشعار فوري عبر رسالة SMS للشريحة</span>
                </button>

                {/* Copy Text Button */}
                <button
                  type="button"
                  onClick={handleCopyNotice}
                  className="w-full py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-2 transition active:scale-95"
                >
                  {copiedNotice ? <Check className="w-3.5 h-3.5 text-teal-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedNotice ? 'تم نسخ نص الإفادة بنجاح ✓' : '📋 نسخ نص الإفادة لمشاركتها يدوياً'}</span>
                </button>
              </div>

              {/* Cloud Sync Status */}
              <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
                <span>المزامنة السحابية الفورية:</span>
                <span className="text-emerald-400 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  <span>تم التحديث في السحابة المركزية للمستشفى</span>
                </span>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Violation Details Summary Card */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 text-xs space-y-2.5 shadow-md">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="font-bold text-amber-400 flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  <span>الملاحظة المطلوب معالجتها:</span>
                </span>
                <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono">
                  رقم: {violation.id}
                </span>
              </div>

              <p className="text-slate-100 font-semibold text-xs leading-relaxed">
                "{violation.description}"
              </p>

              <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-400 bg-slate-950/60 p-2.5 rounded-xl">
                <div>
                  <span className="block text-slate-500">القسم:</span>
                  <strong className="text-slate-200">{violation.department}</strong>
                </div>
                <div>
                  <span className="block text-slate-500">الموقع:</span>
                  <span className="text-slate-300">{violation.locationDetail}</span>
                </div>
                <div>
                  <span className="block text-slate-500">الجهة المكلفة:</span>
                  <strong className="text-amber-300">{party}</strong>
                </div>
                <div>
                  <span className="block text-slate-500">المهلة المقررة:</span>
                  <span className="text-slate-300 font-mono">{violation.deadlineAt}</span>
                </div>
              </div>
            </div>

            {/* Resolution Form */}
            <form
              onSubmit={handleSubmit}
              className="bg-slate-900 border border-teal-900/60 rounded-3xl p-5 space-y-4 shadow-xl text-xs"
            >
              <div className="border-b border-slate-800 pb-2">
                <h3 className="text-xs font-bold text-teal-300 flex items-center gap-1.5">
                  <FileCheck className="w-4 h-4 text-teal-400" />
                  <span>توثيق الإجراء المتخذ:</span>
                </h3>
              </div>

              {/* Reference ID Field */}
              <div>
                <label className="block text-slate-200 font-bold mb-1">
                  الرقم المرجعي للإشعار المطلوب إفادته <span className="text-teal-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={noticeRef}
                  onChange={(e) => setNoticeRef(e.target.value)}
                  placeholder="مثال: AZAL-VIO-001"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-teal-300 font-mono text-xs focus:outline-none focus:border-teal-500 font-bold"
                />
                <span className="text-[10px] text-slate-400 mt-1 block">
                  تم تعبئته تلقائياً من رمز الإشعار المرجعي (ref) ويمكن تعديله عند الحاجة.
                </span>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-slate-200 font-bold">
                    اسم المسؤول / المنفّذ للإجراء <span className="text-teal-400">*</span>
                  </label>
                  <VoiceDictationButton
                    value={resolvedBy}
                    onChange={setResolvedBy}
                    title="إملاء صوتي لاسم المنفذ"
                  />
                </div>
                <input
                  type="text"
                  required
                  value={resolvedBy}
                  onChange={(e) => setResolvedBy(e.target.value)}
                  placeholder="مثال: فني الصيانة / مهند الأنسي"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-slate-100 text-xs focus:outline-none focus:border-teal-500"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-slate-200 font-bold">
                    شرح ما تم إنجازه بالتفصيل <span className="text-teal-400">*</span>
                  </label>
                  <VoiceDictationButton
                    value={resolutionNote}
                    onChange={setResolutionNote}
                    showLabel
                    title="إملاء صوتي لشرح المعالجة المنجزة"
                  />
                </div>
                <textarea
                  id="reportDescription"
                  required
                  rows={3}
                  value={resolutionNote}
                  onChange={(e) => setResolutionNote(e.target.value)}
                  placeholder="مثال: تم إخلاء كافة الصناديق والمخلفات وتأمين الموقع واختبار عمل المنظومة... (يمكنك الإملاء بالصوت)"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-100 text-xs focus:outline-none focus:border-teal-500 leading-relaxed"
                />
              </div>

              {/* After Fix Media (Photo / Video) */}
              <div>
                <label className="block text-slate-200 font-bold mb-1">
                  توثيق الإنجاز (صورة أو فيديو للمعالجة - Photo / Video)
                </label>
                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/*,video/*"
                  onChange={handlePhotoCapture}
                  className="hidden"
                />

                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-teal-500 text-slate-200 flex items-center gap-2 text-xs font-semibold transition flex-1 justify-center cursor-pointer"
                    >
                      <Camera className="w-4 h-4 text-teal-400" />
                      <span>{afterPhotoUrl ? 'تغيير صورة / فيديو المعالجة' : 'التقاط صورة أو فيديو بعد الإنجاز'}</span>
                    </button>
                  </div>

                  {afterPhotoUrl && (
                    <div className="relative rounded-2xl border border-teal-500/70 p-2 bg-slate-950/80">
                      {afterMediaType === 'video' || afterPhotoUrl.startsWith('data:video') ? (
                        <video
                          src={afterPhotoUrl}
                          controls
                          className="w-full max-h-52 rounded-xl bg-black object-contain"
                        />
                      ) : (
                        <img
                          src={afterPhotoUrl}
                          alt="معاينة الإصلاح"
                          className="w-full max-h-52 object-cover rounded-xl border border-slate-800"
                        />
                      )}
                      <span className="text-[10px] text-teal-300 font-bold block text-center mt-1">
                        ✓ تم إرفاق ملف الإثبات بنجاح ({afterMediaType === 'video' || afterPhotoUrl.startsWith('data:video') ? 'فيديو' : 'صورة'})
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* Security or Validation Error Alert */}
              {securityError && (
                <div className="p-3 rounded-xl bg-rose-950/80 border border-rose-700 text-rose-200 text-xs flex items-center gap-2 animate-in fade-in">
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>{securityError}</span>
                </div>
              )}

              <button
                type="submit"
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-bold text-xs shadow-lg shadow-teal-950 flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>حفظ واعتماد إفادة الإنجاز فوراً</span>
              </button>
            </form>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="text-center text-[11px] text-slate-500 py-3 border-t border-slate-900 max-w-md w-full mx-auto">
        مستشفى آزال النموذجي • إدارة الأمن والسلامة • الرعاية الكاملة
      </footer>
      </div>
    </div>
  );
};
