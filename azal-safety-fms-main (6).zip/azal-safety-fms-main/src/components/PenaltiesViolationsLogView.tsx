import React, { useState, useEffect, useMemo } from 'react';
import {
  ShieldAlert,
  Plus,
  Search,
  Filter,
  Printer,
  RefreshCw,
  Trash2,
  AlertTriangle,
  FileText,
  UserX,
  Building2,
  Scale,
  Calendar,
  CheckCircle2,
  AlertCircle,
  X,
  FileCheck
} from 'lucide-react';
import { supabase } from '../services/supabaseClient';
import { PenaltyRecord, PenaltyType, StaffUser } from '../types';
import { executeSmartPrint } from '../utils/printUtils';

interface PenaltiesViolationsLogViewProps {
  currentUser?: StaffUser;
  onLogAudit?: (action: string, actionAr: string, details: string) => void;
}

const COMMON_DEPARTMENTS = [
  'قسم الصيانة والمرافق (FMS & USM)',
  'قسم النظافة والنفايات الطبية والمحرقة',
  'قسم الطوارئ والحوادث (ER)',
  'العمليات الجراحية (OR)',
  'العناية المركزة (ICU)',
  'قسم التغذية والمطبخ المركزي',
  'المختبر المركزي وبنك الدم',
  'قسم الأمن والسلامة والحراسات',
  'الهندسة الطبية الحيوية (MEM)',
  'قسم التمريض العام',
  'قسم الصيدلية والمستودعات',
  'مقاولو الباطن وشركات الصيانة المتعاقدة',
];

const COMMON_VIOLATION_TYPES = [
  'التدخين داخل مرافق المستشفى أو جوار مناطق الخطر والمولدات',
  'عدم ارتداء مهمات الوقاية الشخصية (PPE) المقررة',
  'سد أو إعاقة مخارج الطوارئ ومسارات الهروب وبكرات الحريق',
  'القيام بأعمال صيانة ساخنة (لحام/قطع) دون تصريح عمل مسبق (Hot Work)',
  'سوء تداول أو تخزين المواد الكيميائية الخطرة بالمخالفة لمعايير MSDS',
  'التخلص غير الآمن من النفايات الطبية الحادة في غير الأوعية المخصصة (Safety Box)',
  'التلاعب بصمامات الغازات الطبية أو لوحات التحكم بالإنذار FACP',
  'إهمال فصل التيار الكهربائي أثناء أعمال الصيانة الدورية',
];

const PENALTY_TYPES: PenaltyType[] = [
  'تنبيه شفهي',
  'لفت نظر',
  'إنذار كتابي',
  'خصم مالي',
  'إيقاف مؤقت',
];

export const PenaltiesViolationsLogView: React.FC<PenaltiesViolationsLogViewProps> = ({
  currentUser,
  onLogAudit,
}) => {
  const [penalties, setPenalties] = useState<PenaltyRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [deptFilter, setDeptFilter] = useState<string>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    violator_name: '',
    department: COMMON_DEPARTMENTS[0],
    job_title: '',
    reference_notice_id: `AZAL-VIO-${Math.floor(100 + Math.random() * 900)}`,
    violation_type: COMMON_VIOLATION_TYPES[0],
    penalty_type: 'إنذار كتابي' as PenaltyType,
    penalty_details: '',
    approved_by: currentUser?.name ? `${currentUser.name} - إدارة السلامة` : 'م. نجيب غازي - رئيس السلامة FMS',
    notes: '',
    penalty_date: new Date().toISOString().split('T')[0],
  });

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => {
      setNotification(null);
    }, 4000);
  };

  // Load penalties from Supabase
  const loadPenalties = async () => {
    try {
      setRefreshing(true);
      const { data, error } = await supabase
        .from('penalties_log')
        .select('*')
        .order('penalty_date', { ascending: false });

      if (error) {
        console.error('[Supabase] Error fetching penalties_log:', error);
        showNotification('error', 'تعذر جلب البيانات من Supabase، تم الرجوع للنسخة المحلية');
      } else if (data) {
        setPenalties(data as PenaltyRecord[]);
      }
    } catch (err) {
      console.error('[Supabase] Load error:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadPenalties();
  }, []);

  // Save new penalty record to Supabase
  const handleCreatePenalty = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.violator_name.trim()) {
      showNotification('error', 'يرجى إدخال اسم المخالف');
      return;
    }

    setIsSubmitting(true);
    const newRecord: Partial<PenaltyRecord> = {
      violator_name: formData.violator_name.trim(),
      department: formData.department,
      job_title: formData.job_title.trim() || 'موظف',
      reference_notice_id: formData.reference_notice_id.trim() || `AZAL-VIO-${Date.now().toString().slice(-4)}`,
      violation_type: formData.violation_type.trim(),
      penalty_type: formData.penalty_type,
      penalty_details: formData.penalty_details.trim() || `تم اتخاذ إجراء ${formData.penalty_type} لمخالفة معايير السلامة المهنية.`,
      approved_by: formData.approved_by.trim() || 'إدارة السلامة والمرافق',
      notes: formData.notes.trim(),
      penalty_date: formData.penalty_date,
      created_at: new Date().toISOString(),
    };

    try {
      const { data, error } = await supabase
        .from('penalties_log')
        .insert([newRecord]);

      if (error) {
        console.warn('[Supabase Insert Error]:', error);
      }

      showNotification('success', 'تم قيد العقوبة في السجل بنجاح ومزامنتها مع قاعدة بيانات Supabase');
      setShowAddModal(false);

      // Reset form
      setFormData({
        violator_name: '',
        department: COMMON_DEPARTMENTS[0],
        job_title: '',
        reference_notice_id: `AZAL-VIO-${Math.floor(100 + Math.random() * 900)}`,
        violation_type: COMMON_VIOLATION_TYPES[0],
        penalty_type: 'إنذار كتابي',
        penalty_details: '',
        approved_by: currentUser?.name ? `${currentUser.name} - إدارة السلامة` : 'م. نجيب غازي - رئيس السلامة FMS',
        notes: '',
        penalty_date: new Date().toISOString().split('T')[0],
      });

      // Audit log
      if (onLogAudit) {
        onLogAudit(
          'RECORD_PENALTY',
          'قيد عقوبة إدارية',
          `تم تسجيل عقوبة (${newRecord.penalty_type}) على الموظف (${newRecord.violator_name}) بالقسم (${newRecord.department}) إشعار #${newRecord.reference_notice_id}.`
        );
      }

      await loadPenalties();
    } catch (err) {
      console.error('Save penalty error:', err);
      showNotification('error', 'حدث خطأ أثناء حفظ العقوبة');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Delete penalty record
  const handleDeletePenalty = async (id: string | number, name: string) => {
    if (!window.confirm(`هل أنت متأكد من حذف سجل العقوبة للموظف: "${name}"؟`)) {
      return;
    }

    try {
      setPenalties(prev => prev.filter(p => p.id !== id));
      const { error } = await supabase
        .from('penalties_log')
        .delete()
        .eq('id', id);

      if (error) {
        console.warn('[Supabase Delete Error]:', error);
      }
      showNotification('success', 'تم حذف السجل من قاعدة البيانات');

      if (onLogAudit) {
        onLogAudit('DELETE_PENALTY_RECORD', 'حذف عقوبة إدارية', `تم حذف سجل الجزاء للموظف (${name}).`);
      }
    } catch (err) {
      console.error('Delete error:', err);
    }
  };

  // Filtered penalties
  const filteredPenalties = useMemo(() => {
    return penalties.filter(p => {
      const matchSearch =
        searchTerm.trim() === '' ||
        p.violator_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.department.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.job_title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.reference_notice_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.violation_type.toLowerCase().includes(searchTerm.toLowerCase());

      const matchType = typeFilter === 'all' || p.penalty_type === typeFilter;
      const matchDept = deptFilter === 'all' || p.department === deptFilter;

      return matchSearch && matchType && matchDept;
    });
  }, [penalties, searchTerm, typeFilter, deptFilter]);

  // Statistics
  const totalCount = penalties.length;
  const writtenWarnings = penalties.filter(p => p.penalty_type === 'إنذار كتابي').length;
  const financialDeductions = penalties.filter(p => p.penalty_type === 'خصم مالي').length;
  const attentionNotices = penalties.filter(p => p.penalty_type === 'لفت نظر' || p.penalty_type === 'تنبيه شفهي').length;
  const suspensions = penalties.filter(p => p.penalty_type === 'إيقاف مؤقت').length;

  // Export official PDF report for HR & General Directorate
  const handleExportPdf = () => {
    const rowsHtml = filteredPenalties
      .map(
        (p, idx) => `
        <tr style="border-bottom: 1px solid #e2e8f0; font-size: 11px;">
          <td style="padding: 8px; text-align: center; font-weight: bold; background-color: #f8fafc;">${idx + 1}</td>
          <td style="padding: 8px; font-weight: bold; color: #0f172a;">${p.violator_name}</td>
          <td style="padding: 8px; color: #334155;">${p.department}<br/><span style="color: #64748b; font-size: 10px;">${p.job_title}</span></td>
          <td style="padding: 8px; text-align: center; font-family: monospace; font-weight: bold; color: #0369a1;">${p.reference_notice_id}</td>
          <td style="padding: 8px; color: #b91c1c; font-weight: 500;">${p.violation_type}</td>
          <td style="padding: 8px; text-align: center;">
            <span style="display: inline-block; padding: 3px 8px; border-radius: 6px; font-size: 10px; font-weight: bold; ${
              p.penalty_type === 'خصم مالي' || p.penalty_type === 'إيقاف مؤقت'
                ? 'background-color: #fee2e2; color: #991b1b;'
                : p.penalty_type === 'إنذار كتابي'
                ? 'background-color: #ffedd5; color: #9a3412;'
                : 'background-color: #e0e7ff; color: #3730a3;'
            }">
              ${p.penalty_type}
            </span>
          </td>
          <td style="padding: 8px; font-size: 10px; color: #334155;">${p.penalty_details}</td>
          <td style="padding: 8px; text-align: center; font-size: 10px; color: #475569;">${p.penalty_date}</td>
          <td style="padding: 8px; font-size: 10px; color: #475569;">${p.approved_by}</td>
        </tr>
      `
      )
      .join('');

    const contentHtml = `
      <div style="font-family: 'Segoe UI', Tahoma, sans-serif; direction: rtl; text-align: right; color: #0f172a;">
        <!-- Confidential & Official Notice Badge -->
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #dc2626; padding-bottom: 8px; margin-bottom: 16px;">
          <div>
            <span style="background-color: #fee2e2; color: #991b1b; padding: 4px 10px; border-radius: 4px; font-size: 11px; font-weight: bold;">
              سري وهام جداً • للاستخدام الإداري والقانوني فقط
            </span>
          </div>
          <div style="font-size: 11px; color: #475569;">
            توجيه إلى: <strong>الإدارة العامة • إدارة الموارد البشرية والشؤون القانونية</strong>
          </div>
        </div>

        <!-- Summary KPIs -->
        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 16px;">
          <div style="background-color: #f8fafc; border: 1px solid #cbd5e1; padding: 8px; border-radius: 6px; text-align: center;">
            <div style="font-size: 10px; color: #475569;">إجمالي الجزاءات المسجلة</div>
            <div style="font-size: 18px; font-weight: 900; color: #0f172a;">${totalCount}</div>
          </div>
          <div style="background-color: #fff7ed; border: 1px solid #fed7aa; padding: 8px; border-radius: 6px; text-align: center;">
            <div style="font-size: 10px; color: #9a3412;">الإنذارات الكتابية</div>
            <div style="font-size: 18px; font-weight: 900; color: #ea580c;">${writtenWarnings}</div>
          </div>
          <div style="background-color: #fef2f2; border: 1px solid #fecaca; padding: 8px; border-radius: 6px; text-align: center;">
            <div style="font-size: 10px; color: #991b1b;">الخصومات والإيقافات</div>
            <div style="font-size: 18px; font-weight: 900; color: #dc2626;">${financialDeductions + suspensions}</div>
          </div>
          <div style="background-color: #f0fdf4; border: 1px solid #bbf7d0; padding: 8px; border-radius: 6px; text-align: center;">
            <div style="font-size: 10px; color: #166534;">التنبيهات ولفت النظر</div>
            <div style="font-size: 18px; font-weight: 900; color: #16a34a;">${attentionNotices}</div>
          </div>
        </div>

        <table style="width: 100%; border-collapse: collapse; border: 1px solid #cbd5e1; border-radius: 6px; overflow: hidden; margin-bottom: 20px;">
          <thead>
            <tr style="background-color: #1e293b; color: #ffffff; font-size: 10px; font-weight: bold;">
              <th style="padding: 8px 4px; text-align: center; width: 30px;">#</th>
              <th style="padding: 8px; text-align: right;">اسم الموظف المخالف</th>
              <th style="padding: 8px; text-align: right;">القسم والمسمى</th>
              <th style="padding: 8px; text-align: center;">رقم الإشعار</th>
              <th style="padding: 8px; text-align: right;">نوع المخالفة المرتكبة</th>
              <th style="padding: 8px; text-align: center;">نوع الجزاء</th>
              <th style="padding: 8px; text-align: right;">تفاصيل القرار الإداري</th>
              <th style="padding: 8px; text-align: center;">التاريخ</th>
              <th style="padding: 8px; text-align: right;">جهة الاعتماد</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml || '<tr><td colspan="9" style="text-align: center; padding: 20px; color: #64748b;">لا توجد جزاءات مسجلة</td></tr>'}
          </tbody>
        </table>

        <!-- Regulatory Statement -->
        <div style="font-size: 10px; color: #475569; background-color: #f8fafc; border: 1px solid #e2e8f0; padding: 8px; border-radius: 6px; line-height: 1.6; margin-bottom: 20px;">
          <strong>ملاحظة إدارية:</strong> صدرت هذه القرارات وفقاً للائحة الجزاءات والتحقيق الإداري المعتمدة بمستشفى آزال النموذجي، ومعايير السلامة المهنية وإدارة المرافق (FMS & OHS) لمنع تكرار الممارسات غير الآمنة وحماية سلامة المرضى والمنشأة.
        </div>

        <!-- Endorsement Signatures -->
        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; border-top: 2px solid #e2e8f0; padding-top: 15px;">
          <div style="text-align: center; font-size: 11px;">
            <p style="font-weight: bold; margin-bottom: 3px; color: #0f172a;">رئيس قسم السلامة وإدارة المرافق (FMS)</p>
            <p style="color: #64748b; margin-bottom: 25px;">م. نجيب غازي</p>
            <div style="border-top: 1px dashed #94a3b8; width: 70%; margin: 0 auto; padding-top: 4px; color: #475569;">التوقيع: .....................</div>
          </div>
          <div style="text-align: center; font-size: 11px;">
            <p style="font-weight: bold; margin-bottom: 3px; color: #0f172a;">مدير إدارة الموارد البشرية والشؤون الإدارية</p>
            <p style="color: #64748b; margin-bottom: 25px;">أ. مدير الموارد البشرية</p>
            <div style="border-top: 1px dashed #94a3b8; width: 70%; margin: 0 auto; padding-top: 4px; color: #475569;">التوقيع: .....................</div>
          </div>
          <div style="text-align: center; font-size: 11px;">
            <p style="font-weight: bold; margin-bottom: 3px; color: #0f172a;">اعتماد: مدير عام مستشفى آزال النموذجي</p>
            <p style="color: #64748b; margin-bottom: 25px;">د. محمد السراجي</p>
            <div style="border-top: 1px dashed #94a3b8; width: 70%; margin: 0 auto; padding-top: 4px; color: #475569;">الختم الرسمي والتوقيع</div>
          </div>
        </div>
      </div>
    `;

    executeSmartPrint(contentHtml, {
      title: 'سجل العقوبات والجزاءات الإدارية لمخالفات السلامة المهنية والمرافق',
      subtitle: 'مستشفى آزال النموذجي • موجه للمدير العام والموارد البشرية والشؤون القانونية',
      refNumber: `AZAL-PEN-REP-${new Date().getFullYear()}-${Date.now().toString().slice(-4)}`,
      date: new Date().toLocaleDateString('ar-YE', { year: 'numeric', month: 'long', day: 'numeric' }),
    });
  };

  return (
    <div className="space-y-4 pb-20 animate-in fade-in duration-200">
      {/* Toast Notification */}
      {notification && (
        <div
          className={`fixed top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-2xl shadow-2xl text-xs font-bold border flex items-center gap-2 transition-all ${
            notification.type === 'success'
              ? 'bg-emerald-950/95 text-emerald-200 border-emerald-500'
              : 'bg-rose-950/95 text-rose-200 border-rose-500'
          }`}
        >
          {notification.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          )}
          <span>{notification.message}</span>
        </div>
      )}

      {/* Screen Header */}
      <div className="bg-gradient-to-r from-slate-900 via-rose-950/40 to-slate-900 border border-rose-800/40 rounded-3xl p-4 sm:p-5 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-rose-600/20 border border-rose-500/40 text-rose-400 flex items-center justify-center shrink-0 shadow-inner">
            <Scale className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-black text-white">
                سجل العقوبات والجزاءات الإدارية لمخالفات السلامة
              </h2>
              <span className="text-[10px] bg-rose-950 text-rose-300 border border-rose-600/50 px-2 py-0.5 rounded-full font-bold">
                Supabase: penalties_log
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              توثيق وأرشفة الجزاءات القانونية للمخالفات الميدانية بالتنسيق بين إدارة السلامة FMS والموارد البشرية (HR).
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-rose-950 transition active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>قيد عقوبة جديدة</span>
          </button>

          <button
            type="button"
            onClick={handleExportPdf}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold flex items-center gap-1.5 transition active:scale-95"
            title="تصدير التقرير للإدارة العامة والموارد البشرية"
          >
            <Printer className="w-4 h-4 text-rose-400" />
            <span>تصدير PDF للإدارة وHR</span>
          </button>

          <button
            type="button"
            onClick={loadPenalties}
            disabled={refreshing}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition active:scale-95"
            title="تحديث البيانات من Supabase"
          >
            <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin text-rose-400' : ''}`} />
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3">
        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-2xl flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700 text-slate-300 flex items-center justify-center shrink-0">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 block font-medium">إجمالي الجزاءات</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl font-black text-white">{totalCount}</span>
              <span className="text-[10px] text-slate-500">حالة مقيدة</span>
            </div>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-2xl flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center shrink-0">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 block font-medium">الإنذارات الكتابية</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl font-black text-amber-400">{writtenWarnings}</span>
              <span className="text-[10px] text-amber-500/80">إنذار رسمي</span>
            </div>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-2xl flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 flex items-center justify-center shrink-0">
            <Scale className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 block font-medium">الخصومات والإيقافات</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl font-black text-rose-400">{financialDeductions + suspensions}</span>
              <span className="text-[10px] text-rose-500/80">قرار مالي/إداري</span>
            </div>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-2xl flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 text-blue-400 flex items-center justify-center shrink-0">
            <FileCheck className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 block font-medium">تنبيهات ولفت نظر</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl font-black text-blue-300">{attentionNotices}</span>
              <span className="text-[10px] text-blue-500/80">توجيه توعوي</span>
            </div>
          </div>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-2xl flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 text-xs">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-500 absolute right-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="بحث باسم الموظف، القسم، رقم الإشعار المرجعي، أو نوع المخالفة..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-9 pl-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500 transition"
          />
          {searchTerm && (
            <button
              type="button"
              onClick={() => setSearchTerm('')}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
            >
              ✕
            </button>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Penalty Type Filter */}
          <div className="flex items-center gap-1 bg-slate-950 border border-slate-800 rounded-xl px-2 py-1">
            <span className="text-[11px] text-slate-500">النوع:</span>
            <select
              value={typeFilter}
              onChange={e => setTypeFilter(e.target.value)}
              className="bg-transparent text-slate-300 text-xs font-bold focus:outline-none cursor-pointer"
            >
              <option value="all">كافة الجزاءات</option>
              {PENALTY_TYPES.map(t => (
                <option key={t} value={t} className="bg-slate-900">{t}</option>
              ))}
            </select>
          </div>

          {/* Department Filter */}
          <div className="flex items-center gap-1 bg-slate-950 border border-slate-800 rounded-xl px-2 py-1">
            <span className="text-[11px] text-slate-500">القسم:</span>
            <select
              value={deptFilter}
              onChange={e => setDeptFilter(e.target.value)}
              className="bg-transparent text-slate-300 text-xs font-bold focus:outline-none cursor-pointer max-w-[140px] truncate"
            >
              <option value="all">كافة الأقسام</option>
              {COMMON_DEPARTMENTS.map(d => (
                <option key={d} value={d} className="bg-slate-900">{d}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Main Penalties Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 text-[11px] select-none">
                <th className="py-3 px-3 text-center w-10">#</th>
                <th className="py-3 px-3">الموظف المخالف</th>
                <th className="py-3 px-3">القسم والمسمى</th>
                <th className="py-3 px-3 text-center">الإشعار المرجعي</th>
                <th className="py-3 px-3">نوع المخالفة المرتكبة</th>
                <th className="py-3 px-3 text-center">نوع الجزاء</th>
                <th className="py-3 px-3">تفاصيل القرار</th>
                <th className="py-3 px-3 text-center">تاريخ الجزاء</th>
                <th className="py-3 px-3 text-center">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {loading ? (
                <tr>
                  <td colSpan={9} className="text-center py-12 text-slate-400">
                    <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-rose-400" />
                    <span>جاري تحميل سجل الجزاءات من Supabase...</span>
                  </td>
                </tr>
              ) : filteredPenalties.length === 0 ? (
                <tr>
                  <td colSpan={9} className="text-center py-12 text-slate-500">
                    <UserX className="w-8 h-8 mx-auto mb-2 opacity-30" />
                    <p className="font-bold text-sm">لا توجد عقوبات أو جزاءات مطابقة للبحث</p>
                    <p className="text-[11px] mt-1">سجل المخالفات الإدارية خالٍ في التصفية الحالية</p>
                  </td>
                </tr>
              ) : (
                filteredPenalties.map((pen, idx) => (
                  <tr
                    key={pen.id}
                    className="hover:bg-slate-800/40 transition-colors group"
                  >
                    <td className="py-3 px-3 text-center text-slate-500 font-mono text-[11px]">
                      {idx + 1}
                    </td>

                    {/* Violator Name */}
                    <td className="py-3 px-3">
                      <div className="font-bold text-white text-xs">
                        {pen.violator_name}
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5">
                        المعتمد: {pen.approved_by}
                      </div>
                    </td>

                    {/* Department & Job */}
                    <td className="py-3 px-3">
                      <div className="text-slate-200 font-medium text-xs">
                        {pen.department}
                      </div>
                      <div className="text-[10px] text-slate-500 mt-0.5">
                        {pen.job_title}
                      </div>
                    </td>

                    {/* Reference Notice */}
                    <td className="py-3 px-3 text-center">
                      <span className="font-mono font-bold text-[11px] bg-slate-950 border border-slate-800 px-2 py-1 rounded-lg text-sky-400 inline-block">
                        {pen.reference_notice_id}
                      </span>
                    </td>

                    {/* Violation Type */}
                    <td className="py-3 px-3 max-w-[200px]">
                      <div className="text-rose-300 font-medium text-xs leading-snug">
                        {pen.violation_type}
                      </div>
                    </td>

                    {/* Penalty Type Badge */}
                    <td className="py-3 px-3 text-center">
                      <span
                        className={`inline-block px-2.5 py-1 rounded-xl text-[10px] font-bold border ${
                          pen.penalty_type === 'خصم مالي' || pen.penalty_type === 'إيقاف مؤقت'
                            ? 'bg-rose-950/80 text-rose-300 border-rose-700/60'
                            : pen.penalty_type === 'إنذار كتابي'
                            ? 'bg-amber-950/80 text-amber-300 border-amber-700/60'
                            : 'bg-indigo-950/80 text-indigo-300 border-indigo-700/60'
                        }`}
                      >
                        {pen.penalty_type}
                      </span>
                    </td>

                    {/* Details */}
                    <td className="py-3 px-3 max-w-[220px]">
                      <div className="text-slate-300 text-[11px] leading-snug line-clamp-2">
                        {pen.penalty_details}
                      </div>
                      {pen.notes && (
                        <div className="text-[10px] text-slate-500 mt-0.5 italic truncate">
                          ملاحظة: {pen.notes}
                        </div>
                      )}
                    </td>

                    {/* Date */}
                    <td className="py-3 px-3 text-center text-slate-400 font-mono text-[11px]">
                      {pen.penalty_date}
                    </td>

                    {/* Actions */}
                    <td className="py-3 px-3 text-center">
                      <button
                        type="button"
                        onClick={() => handleDeletePenalty(pen.id, pen.violator_name)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-950/30 transition"
                        title="حذف هذا السجل"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add New Penalty Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 w-full max-w-2xl rounded-3xl p-5 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-rose-600/20 text-rose-400 flex items-center justify-center">
                  <Scale className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">قيد عقوبة وجزاء إداري جديد</h3>
                  <p className="text-[11px] text-slate-400">حفظ مباشر في جدول penalties_log بقاعدة بيانات Supabase</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreatePenalty} className="space-y-3.5 mt-4 text-xs">
              {/* Violator Name & Job Title */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    اسم الموظف المخالف <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.violator_name}
                    onChange={e => setFormData({ ...formData, violator_name: e.target.value })}
                    placeholder="الاسم الرباعي للموظف..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">المسمى الوظيفي</label>
                  <input
                    type="text"
                    value={formData.job_title}
                    onChange={e => setFormData({ ...formData, job_title: e.target.value })}
                    placeholder="مثال: فني صيانة، ممرض، عامل نظافة..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
                  />
                </div>
              </div>

              {/* Department & Reference Notice ID */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    القسم التابع له <span className="text-rose-400">*</span>
                  </label>
                  <select
                    value={formData.department}
                    onChange={e => setFormData({ ...formData, department: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-rose-500"
                  >
                    {COMMON_DEPARTMENTS.map(dept => (
                      <option key={dept} value={dept}>{dept}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    رقم الإشعار المرجعي <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.reference_notice_id}
                    onChange={e => setFormData({ ...formData, reference_notice_id: e.target.value })}
                    placeholder="AZAL-VIO-001"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-rose-500"
                  />
                </div>
              </div>

              {/* Violation Type */}
              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  نوع المخالفة <span className="text-rose-400">*</span>
                </label>
                <select
                  value={formData.violation_type}
                  onChange={e => setFormData({ ...formData, violation_type: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-rose-500"
                >
                  {COMMON_VIOLATION_TYPES.map(vt => (
                    <option key={vt} value={vt}>{vt}</option>
                  ))}
                  <option value="مخالفة أخرى مخصصة">مخالفة أخرى مخصصة</option>
                </select>
              </div>

              {/* Penalty Type & Date */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    نوع العقوبة / الجزاء <span className="text-rose-400">*</span>
                  </label>
                  <select
                    value={formData.penalty_type}
                    onChange={e => setFormData({ ...formData, penalty_type: e.target.value as PenaltyType })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-rose-500"
                  >
                    {PENALTY_TYPES.map(pt => (
                      <option key={pt} value={pt}>{pt}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">تاريخ توقيع الجزاء</label>
                  <input
                    type="date"
                    required
                    value={formData.penalty_date}
                    onChange={e => setFormData({ ...formData, penalty_date: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none"
                  />
                </div>
              </div>

              {/* Penalty Details */}
              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  تفاصيل الجزاء والإجراء المتخذ <span className="text-rose-400">*</span>
                </label>
                <textarea
                  rows={2}
                  required
                  value={formData.penalty_details}
                  onChange={e => setFormData({ ...formData, penalty_details: e.target.value })}
                  placeholder="مثال: خصم يومين من الراتب مع توجيه إنذار أخير بالفصل في حال تكرار التدخين قرب المولدات..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none resize-none"
                />
              </div>

              {/* Approver & Notes */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">جهة الاعتماد</label>
                  <input
                    type="text"
                    value={formData.approved_by}
                    onChange={e => setFormData({ ...formData, approved_by: e.target.value })}
                    placeholder="م. نجيب غازي / د. محمد السراجي"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">ملاحظات إدارية / ملف الموظف</label>
                  <input
                    type="text"
                    value={formData.notes}
                    onChange={e => setFormData({ ...formData, notes: e.target.value })}
                    placeholder="تم حفظ نسخة في ملف الموظف بقسم الموارد البشرية..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold flex items-center gap-1.5 shadow-lg shadow-rose-950 disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <CheckCircle2 className="w-4 h-4" />
                  )}
                  <span>قيد العقوبة في Supabase</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default PenaltiesViolationsLogView;
