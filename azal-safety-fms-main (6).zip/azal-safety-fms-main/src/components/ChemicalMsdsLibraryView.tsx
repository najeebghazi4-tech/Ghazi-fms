import React, { useState, useMemo, useEffect } from 'react';
import {
  FlaskConical,
  Search,
  Printer,
  AlertTriangle,
  Shield,
  Eye,
  HeartPulse,
  Flame,
  Droplets,
  Wind,
  Plus,
  X,
  CheckCircle2,
  ExternalLink,
  PhoneCall,
  FileText,
  Building2,
  SlidersHorizontal,
  Bookmark,
  Sparkles,
  QrCode,
  Layers,
  HelpCircle
} from 'lucide-react';
import { ChemicalMsdsItem, Nfpa704Diamond } from '../types';
import { INITIAL_MSDS_DATABASE, AZAL_HOSPITAL_POLICY_CODE, AZAL_SAFETY_EMERGENCY_PHONE } from '../data/azalMsdsData';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';
import { executeSmartPrint } from '../utils/printUtils';
import { getPublicAppBaseUrl } from '../utils/phoneUtils';

interface ChemicalMsdsLibraryViewProps {
  onClose?: () => void;
  isStandalonePublicRoute?: boolean;
  onSelectForCodeOrange?: (chemical: ChemicalMsdsItem) => void;
  initialSelectedId?: string;
}

// Visual NFPA 704 Diamond Component
export const Nfpa704DiamondBadge: React.FC<{ diamond: Nfpa704Diamond; size?: 'sm' | 'md' | 'lg' }> = ({
  diamond,
  size = 'md'
}) => {
  const dim = size === 'sm' ? 48 : size === 'lg' ? 96 : 68;
  const strokeW = size === 'sm' ? 1 : 1.5;
  const fontSize = size === 'sm' ? 9 : size === 'lg' ? 18 : 13;
  const centerDim = dim / 2;
  const offset = dim / 4;

  return (
    <div 
      className="relative inline-flex items-center justify-center select-none"
      style={{ width: `${dim}px`, height: `${dim}px` }}
      title={`معين NFPA 704: الصحة ${diamond.health} | القابلية للاشتعال ${diamond.flammability} | النشاط ${diamond.instability} ${diamond.special ? `| خاص: ${diamond.special}` : ''}`}
    >
      <svg width={dim} height={dim} viewBox={`0 0 ${dim} ${dim}`} className="overflow-visible">
        {/* Diamond frame rotated 45 degrees */}
        <g transform={`translate(${centerDim}, ${centerDim}) rotate(45)`}>
          {/* Top: Flammability (Red) */}
          <rect
            x={-offset}
            y={-offset}
            width={offset}
            height={offset}
            fill="#dc2626"
            stroke="#ffffff"
            strokeWidth={strokeW}
          />
          {/* Left: Health (Blue) */}
          <rect
            x={-offset}
            y={0}
            width={offset}
            height={offset}
            fill="#2563eb"
            stroke="#ffffff"
            strokeWidth={strokeW}
          />
          {/* Right: Instability / Reactivity (Yellow) */}
          <rect
            x={0}
            y={-offset}
            width={offset}
            height={offset}
            fill="#eab308"
            stroke="#ffffff"
            strokeWidth={strokeW}
          />
          {/* Bottom: Special (White) */}
          <rect
            x={0}
            y={0}
            width={offset}
            height={offset}
            fill="#f8fafc"
            stroke="#ffffff"
            strokeWidth={strokeW}
          />
        </g>
      </svg>

      {/* Numbers and Labels positioned without rotation */}
      {/* Top: Flammability (Red) */}
      <span
        className="absolute font-black text-white pointer-events-none drop-shadow"
        style={{ top: '6%', fontSize: `${fontSize}px` }}
      >
        {diamond.flammability}
      </span>
      {/* Left: Health (Blue) */}
      <span
        className="absolute font-black text-white pointer-events-none drop-shadow"
        style={{ left: '14%', fontSize: `${fontSize}px` }}
      >
        {diamond.health}
      </span>
      {/* Right: Instability (Yellow) */}
      <span
        className="absolute font-black text-slate-950 pointer-events-none font-bold"
        style={{ right: '14%', fontSize: `${fontSize}px` }}
      >
        {diamond.instability}
      </span>
      {/* Bottom: Special (White) */}
      <span
        className="absolute font-black text-slate-900 pointer-events-none uppercase font-mono tracking-tighter"
        style={{ bottom: '8%', fontSize: `${Math.max(8, fontSize - 3)}px` }}
      >
        {diamond.special || '-'}
      </span>
    </div>
  );
};

export const ChemicalMsdsLibraryView: React.FC<ChemicalMsdsLibraryViewProps> = ({
  onClose,
  isStandalonePublicRoute = false,
  onSelectForCodeOrange,
  initialSelectedId
}) => {
  // Local storage integration for custom added chemicals
  const [msdsList, setMsdsList] = useState<ChemicalMsdsItem[]>(() => {
    try {
      const saved = localStorage.getItem('azal_chemical_msds_v1');
      if (saved) {
        const parsed: ChemicalMsdsItem[] = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Merge defaults with custom additions
          const customItems = parsed.filter(item => item.isCustom);
          return [...INITIAL_MSDS_DATABASE, ...customItems];
        }
      }
    } catch (e) {
      console.warn('Error reading stored MSDS database:', e);
    }
    return INITIAL_MSDS_DATABASE;
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDepartment, setSelectedDepartment] = useState<string>('all');
  const [selectedHazardFilter, setSelectedHazardFilter] = useState<string>('all');
  const [activeItemModal, setActiveItemModal] = useState<ChemicalMsdsItem | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showLabelPreviewModal, setShowLabelPreviewModal] = useState<ChemicalMsdsItem | null>(null);

  // Check URL params or initialSelectedId on mount
  useEffect(() => {
    if (initialSelectedId) {
      const match = msdsList.find(i => i.id === initialSelectedId);
      if (match) setActiveItemModal(match);
      return;
    }

    if (typeof window !== 'undefined') {
      const hash = window.location.hash || '';
      const search = window.location.search || '';
      let targetId: string | null = null;

      if (hash.includes('?')) {
        const params = new URLSearchParams(hash.split('?')[1]);
        targetId = params.get('id') || params.get('chem') || params.get('msds');
      }
      if (!targetId && search) {
        const params = new URLSearchParams(search);
        targetId = params.get('id') || params.get('chem') || params.get('msds');
      }

      if (targetId) {
        const found = msdsList.find(item => item.id.toLowerCase() === targetId?.toLowerCase());
        if (found) {
          setActiveItemModal(found);
        }
      }
    }
  }, [initialSelectedId, msdsList]);

  // Save changes
  const saveCustomChemical = (newChem: ChemicalMsdsItem) => {
    const updated = [newChem, ...msdsList.filter(i => i.id !== newChem.id)];
    setMsdsList(updated);
    try {
      localStorage.setItem('azal_chemical_msds_v1', JSON.stringify(updated.filter(i => i.isCustom)));
    } catch (e) {
      console.warn('Failed saving custom chemical', e);
    }
    triggerSuccessFeedback();
    setShowAddModal(false);
    setActiveItemModal(newChem);
  };

  // Filtered chemical list
  const filteredList = useMemo(() => {
    return msdsList.filter(chem => {
      const query = searchQuery.trim().toLowerCase();
      const matchesSearch =
        !query ||
        chem.nameAr.toLowerCase().includes(query) ||
        chem.nameEn.toLowerCase().includes(query) ||
        chem.casNumber.toLowerCase().includes(query) ||
        (chem.chemicalFormula && chem.chemicalFormula.toLowerCase().includes(query)) ||
        (chem.commonNameAr && chem.commonNameAr.toLowerCase().includes(query)) ||
        chem.primaryDepartments.some(d => d.toLowerCase().includes(query)) ||
        chem.hazardClassifications.some(h => h.toLowerCase().includes(query));

      const matchesDept =
        selectedDepartment === 'all' ||
        chem.primaryDepartments.some(d => d.includes(selectedDepartment));

      const matchesHazard =
        selectedHazardFilter === 'all' ||
        (selectedHazardFilter === 'flammable' && chem.nfpa704.flammability >= 2) ||
        (selectedHazardFilter === 'toxic' && chem.nfpa704.health >= 3) ||
        (selectedHazardFilter === 'oxidizer' && (chem.nfpa704.special === 'OX' || chem.hazardClassifications.some(h => h.includes('مؤكسد')))) ||
        (selectedHazardFilter === 'corrosive' && (chem.nfpa704.special === 'COR' || chem.hazardClassifications.some(h => h.includes('تآكل') || h.includes('كاو')))) ||
        (selectedHazardFilter === 'carcinogen' && chem.hazardClassifications.some(h => h.includes('مسرطن')));

      return matchesSearch && matchesDept && matchesHazard;
    });
  }, [msdsList, searchQuery, selectedDepartment, selectedHazardFilter]);

  // Generate QR Code URL for a chemical MSDS
  const getChemicalMsdsUrl = (chemId: string) => {
    const baseUrl = getPublicAppBaseUrl();
    return `${baseUrl}#msds?id=${encodeURIComponent(chemId)}`;
  };

  // Handle Printing Official Container Warning Label (A6 / A5 format)
  const handlePrintChemicalLabel = (chem: ChemicalMsdsItem) => {
    triggerSuccessFeedback();
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&margin=2&data=${encodeURIComponent(getChemicalMsdsUrl(chem.id))}`;

    const labelHtml = `
      <div style="max-width: 155mm; margin: 0 auto; border: 3px solid #0f766e; border-radius: 12px; padding: 14px; background: #ffffff; box-shadow: 0 4px 12px rgba(0,0,0,0.06); direction: rtl; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Tahoma, sans-serif;">
        <!-- Header Strip -->
        <div style="display: flex; align-items: center; justify-content: space-between; border-bottom: 2px solid #0f766e; padding-bottom: 8px; margin-bottom: 10px;">
          <div style="text-align: right;">
            <div style="font-size: 15px; font-weight: 900; color: #0f766e;">مستشفى آزال النموذجي • AZAL Hospital</div>
            <div style="font-size: 10px; font-weight: bold; color: #475569;">إدارة السلامة المهنية وإدارة المرافق (FMS) • معتمد CBAHI</div>
          </div>
          <div style="text-align: left; font-size: 9px; color: #64748b; font-family: monospace;">
            <span style="background: #f0fdfa; color: #0f766e; border: 1px solid #0f766e; padding: 2px 6px; border-radius: 4px; font-weight: bold;">كود السياسة: ${chem.fmsPolicyCode}</span>
          </div>
        </div>

        <!-- Chemical Title Box -->
        <div style="background: #f8fafc; border: 1.5px solid #cbd5e1; border-radius: 8px; padding: 10px 12px; margin-bottom: 12px; display: flex; align-items: center; justify-content: space-between;">
          <div style="flex: 1; padding-left: 12px;">
            <div style="font-size: 18px; font-weight: 900; color: #0f172a; line-height: 1.3;">${chem.nameAr}</div>
            <div style="font-size: 12px; font-weight: bold; color: #0d9488; margin-top: 2px; direction: ltr; text-align: right;">${chem.nameEn}</div>
            ${chem.concentration ? `<div style="font-size: 10.5px; color: #475569; margin-top: 3px;"><strong>التركيز / الصيغة:</strong> ${chem.concentration} (${chem.chemicalFormula || ''})</div>` : ''}
            <div style="font-size: 10.5px; color: #475569;"><strong>رقم تسجيل الكاس (CAS No):</strong> <span style="font-family: monospace; font-weight: bold;">${chem.casNumber}</span></div>
          </div>
          
          <div style="text-align: center; border-right: 1.5px dashed #cbd5e1; padding-right: 14px;">
            <span style="display: inline-block; background: ${chem.signalWord.includes('خطر') ? '#dc2626' : '#d97706'}; color: #ffffff; font-weight: 900; font-size: 13px; padding: 4px 12px; border-radius: 6px; letter-spacing: 0.5px; margin-bottom: 6px;">
              ⚠️ كلمة التنبيه: ${chem.signalWord}
            </span>
            <div style="font-size: 9.5px; color: #64748b; font-weight: bold;">ملصق الحاوية المعتمد</div>
          </div>
        </div>

        <!-- Middle Grid: NFPA Diamond + Hazard & PPE -->
        <div style="display: grid; grid-template-columns: 110px 1fr; gap: 12px; align-items: stretch; margin-bottom: 12px;">
          <!-- NFPA Box -->
          <div style="border: 1px solid #cbd5e1; border-radius: 8px; padding: 8px; text-align: center; background: #fafafa; display: flex; flex-direction: column; align-items: center; justify-content: center;">
            <div style="font-size: 9px; font-weight: 900; color: #334155; margin-bottom: 6px;">معين المخاطر NFPA 704</div>
            <div style="position: relative; width: 70px; height: 70px;">
              <svg width="70" height="70" viewBox="0 0 70 70">
                <g transform="translate(35, 35) rotate(45)">
                  <rect x="-17.5" y="-17.5" width="17.5" height="17.5" fill="#dc2626" stroke="#fff" stroke-width="1.5" />
                  <rect x="-17.5" y="0" width="17.5" height="17.5" fill="#2563eb" stroke="#fff" stroke-width="1.5" />
                  <rect x="0" y="-17.5" width="17.5" height="17.5" fill="#eab308" stroke="#fff" stroke-width="1.5" />
                  <rect x="0" y="0" width="17.5" height="17.5" fill="#f8fafc" stroke="#fff" stroke-width="1.5" />
                </g>
              </svg>
              <span style="position: absolute; top: 4px; left: 0; right: 0; text-align: center; font-weight: 900; color: #fff; font-size: 13px;">${chem.nfpa704.flammability}</span>
              <span style="position: absolute; top: 25px; left: 8px; font-weight: 900; color: #fff; font-size: 13px;">${chem.nfpa704.health}</span>
              <span style="position: absolute; top: 25px; right: 8px; font-weight: 900; color: #000; font-size: 13px;">${chem.nfpa704.instability}</span>
              <span style="position: absolute; bottom: 5px; left: 0; right: 0; text-align: center; font-weight: 900; color: #0f172a; font-size: 10px; font-family: monospace;">${chem.nfpa704.special || '-'}</span>
            </div>
            <div style="font-size: 8px; color: #64748b; margin-top: 4px; line-height: 1.2;">
              أحمر: اشتعال | أزرق: صحة<br/>أصفر: نشاط | أبيض: خاص
            </div>
          </div>

          <!-- Hazards & PPE Highlights -->
          <div style="border: 1px solid #cbd5e1; border-radius: 8px; padding: 8px 10px; background: #ffffff;">
            <div style="font-size: 11px; font-weight: 900; color: #991b1b; margin-bottom: 4px;">⚠️ أبرز المخاطر الصحية والفيزيائية:</div>
            <ul style="margin: 0 0 8px 0; padding-right: 14px; font-size: 10px; color: #334155; line-height: 1.4;">
              ${chem.hazardClassifications.slice(0, 3).map(h => `<li>${h}</li>`).join('')}
            </ul>

            <div style="font-size: 11px; font-weight: 900; color: #0f766e; margin-bottom: 4px;">🛡️ مهمات الوقاية الشخصية الإلزامية (Mandatory PPE):</div>
            <div style="font-size: 9.5px; color: #1e293b; line-height: 1.4; background: #f0fdfa; border: 1px solid #ccfbf1; padding: 6px; border-radius: 6px;">
              <strong>• العين والوجه:</strong> ${chem.requiredPpe.eyeFace}<br/>
              <strong>• اليدين:</strong> ${chem.requiredPpe.gloves}<br/>
              <strong>• التنفس:</strong> ${chem.requiredPpe.respiratory}
            </div>
          </div>
        </div>

        <!-- First Aid Quick Strip -->
        <div style="background: #fffbeb; border: 1px solid #fef3c7; border-radius: 6px; padding: 6px 10px; margin-bottom: 10px; font-size: 9.5px; color: #92400e; line-height: 1.4;">
          <strong>🚑 الإسعاف الأولي الطارئ:</strong>
          <span>العين: غسيل بمحطة العيون 15 دقيقة • الجلد: ماء جاري وصابون 15 دقيقة • الاستنشاق: نقل للمكان المفتوح والتهوية • البلع: يمنع إحداث القيء واستدعاء الطوارئ.</span>
        </div>

        <!-- Footer: Barcode + Emergency Phone -->
        <div style="display: flex; align-items: center; justify-content: space-between; background: #f1f5f9; border: 1px solid #cbd5e1; border-radius: 8px; padding: 8px 12px;">
          <div style="display: flex; align-items: center; gap: 10px;">
            <img src="${qrUrl}" alt="MSDS QR" style="width: 55px; height: 55px; display: block; border-radius: 4px; border: 1px solid #94a3b8; background: #fff;" />
            <div style="text-align: right;">
              <div style="font-size: 10px; font-weight: 900; color: #0f172a;">امسح رمز QR للمطالعة الفورية لصحيفة MSDS</div>
              <div style="font-size: 8.5px; color: #64748b;">تحديث دوري معتمد • إدارة الجودة والاعتماد FMS</div>
            </div>
          </div>

          <div style="text-align: center; background: #ffffff; border: 1.5px solid #dc2626; border-radius: 6px; padding: 4px 10px;">
            <div style="font-size: 9px; font-weight: bold; color: #dc2626;">📞 طوارئ السلامة والانسكابات (24/7)</div>
            <div style="font-size: 15px; font-weight: 900; color: #0f172a; font-family: monospace; direction: ltr;">777738138</div>
          </div>
        </div>
      </div>
    `;

    executeSmartPrint(labelHtml, {
      title: `ملصق تحذير عبوة - ${chem.nameAr}`,
      subtitle: `مستشفى آزال النموذجي • ملصق معتمد لسلامة المواد الكيميائية (FMS-APP-070EA)`,
      refNumber: `AZAL-CHEM-LABEL-${chem.id.toUpperCase().slice(0, 10)}`
    });
  };

  // Handle Full Formal A4 MSDS Document Print
  const handlePrintFullMsdsSheet = (chem: ChemicalMsdsItem) => {
    triggerSuccessFeedback();
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&margin=2&data=${encodeURIComponent(getChemicalMsdsUrl(chem.id))}`;

    const sheetHtml = `
      <div style="direction: rtl; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Tahoma, sans-serif; color: #0f172a;">
        <!-- Header Banner -->
        <div style="background: #f8fafc; border: 2px solid #0f766e; border-radius: 8px; padding: 14px; margin-bottom: 18px; display: flex; align-items: center; justify-content: space-between;">
          <div>
            <div style="font-size: 20px; font-weight: 900; color: #0f766e;">صحيفة بيانات سلامة المادة (Material Safety Data Sheet - MSDS)</div>
            <div style="font-size: 15px; font-weight: bold; color: #0f172a; margin-top: 4px;">${chem.nameAr} • ${chem.nameEn}</div>
            <div style="font-size: 11px; color: #64748b; margin-top: 4px;">
              <strong>السياسة المؤسسية:</strong> ${chem.fmsPolicyCode} | <strong>رقم CAS:</strong> ${chem.casNumber} | <strong>الصيغة:</strong> ${chem.chemicalFormula || 'غير متوفرة'}
            </div>
          </div>
          <div style="text-align: center;">
            <span style="display: inline-block; background: ${chem.signalWord.includes('خطر') ? '#dc2626' : '#d97706'}; color: #fff; font-weight: 900; font-size: 13px; padding: 6px 14px; border-radius: 6px;">
              ${chem.signalWord}
            </span>
          </div>
        </div>

        <!-- Section 1: Chemical Identification & Primary Departments -->
        <h3 style="font-size: 14px; font-weight: 900; color: #0f766e; border-bottom: 1.5px solid #cbd5e1; padding-bottom: 4px; margin-bottom: 8px;">
          1. التعريف بالمادة والأقسام المستهدفة (Identification & Usage)
        </h3>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 14px; font-size: 11px;">
          <tr>
            <td style="width: 25%; font-weight: bold; background: #f1f5f9; padding: 6px; border: 1px solid #cbd5e1;">الاسم الشائع / التجاري:</td>
            <td style="padding: 6px; border: 1px solid #cbd5e1;">${chem.commonNameAr || chem.nameAr}</td>
            <td style="width: 20%; font-weight: bold; background: #f1f5f9; padding: 6px; border: 1px solid #cbd5e1;">التركيز المعتمد:</td>
            <td style="padding: 6px; border: 1px solid #cbd5e1;">${chem.concentration || 'حسب المواصفة'}</td>
          </tr>
          <tr>
            <td style="font-weight: bold; background: #f1f5f9; padding: 6px; border: 1px solid #cbd5e1;">الأقسام المستخدمة بالمستشفى:</td>
            <td colspan="3" style="padding: 6px; border: 1px solid #cbd5e1;">${chem.primaryDepartments.join(' • ')}</td>
          </tr>
        </table>

        <!-- Section 2: Hazard Identification & NFPA Diamond -->
        <h3 style="font-size: 14px; font-weight: 900; color: #0f766e; border-bottom: 1.5px solid #cbd5e1; padding-bottom: 4px; margin-bottom: 8px;">
          2. تصنيف المخاطر ومعين الجمعية الوطنية للوقاية من الحرائق (NFPA 704)
        </h3>
        <div style="display: grid; grid-template-columns: 140px 1fr; gap: 14px; margin-bottom: 14px; align-items: center;">
          <div style="text-align: center; border: 1px solid #cbd5e1; padding: 10px; border-radius: 8px; background: #fafafa;">
            <div style="font-size: 11px; font-weight: bold; margin-bottom: 6px;">معين NFPA 704</div>
            <div style="font-size: 11px; line-height: 1.6;">
              <span style="color: #2563eb; font-weight: bold;">الصحة (Health): ${chem.nfpa704.health}</span><br/>
              <span style="color: #dc2626; font-weight: bold;">الاشتعال (Flammability): ${chem.nfpa704.flammability}</span><br/>
              <span style="color: #ca8a04; font-weight: bold;">النشاط (Instability): ${chem.nfpa704.instability}</span><br/>
              <span style="color: #334155; font-weight: bold;">خاص (Special): ${chem.nfpa704.special || 'لا يوجد'}</span>
            </div>
          </div>
          <div>
            <div style="font-weight: bold; font-size: 11px; margin-bottom: 4px; color: #991b1b;">التصنيفات الخطرة:</div>
            <ul style="margin: 0; padding-right: 16px; font-size: 11px; line-height: 1.5; color: #334155;">
              ${chem.hazardClassifications.map(h => `<li>${h}</li>`).join('')}
            </ul>
          </div>
        </div>

        <!-- Section 3: Required PPE -->
        <h3 style="font-size: 14px; font-weight: 900; color: #0f766e; border-bottom: 1.5px solid #cbd5e1; padding-bottom: 4px; margin-bottom: 8px;">
          3. معدات الوقاية الشخصية الإلزامية (Mandatory PPE)
        </h3>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 14px; font-size: 11px;">
          <tr>
            <td style="width: 25%; font-weight: bold; background: #f1f5f9; padding: 6px; border: 1px solid #cbd5e1;">العين والوجه:</td>
            <td style="padding: 6px; border: 1px solid #cbd5e1;">${chem.requiredPpe.eyeFace}</td>
          </tr>
          <tr>
            <td style="font-weight: bold; background: #f1f5f9; padding: 6px; border: 1px solid #cbd5e1;">حماية اليدين (القفازات):</td>
            <td style="padding: 6px; border: 1px solid #cbd5e1;">${chem.requiredPpe.gloves}</td>
          </tr>
          <tr>
            <td style="font-weight: bold; background: #f1f5f9; padding: 6px; border: 1px solid #cbd5e1;">الحماية التنفسية:</td>
            <td style="padding: 6px; border: 1px solid #cbd5e1;">${chem.requiredPpe.respiratory}</td>
          </tr>
          <tr>
            <td style="font-weight: bold; background: #f1f5f9; padding: 6px; border: 1px solid #cbd5e1;">الجسم والأقدام:</td>
            <td style="padding: 6px; border: 1px solid #cbd5e1;">${chem.requiredPpe.body} ${chem.requiredPpe.footwear ? `• ${chem.requiredPpe.footwear}` : ''}</td>
          </tr>
        </table>

        <!-- Section 4: First Aid -->
        <h3 style="font-size: 14px; font-weight: 900; color: #0f766e; border-bottom: 1.5px solid #cbd5e1; padding-bottom: 4px; margin-bottom: 8px;">
          4. تدابير الإسعافات الأولية الفورية (First Aid Measures)
        </h3>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 14px; font-size: 11px;">
          <tr>
            <td style="width: 25%; font-weight: bold; background: #fef2f2; color: #991b1b; padding: 6px; border: 1px solid #fca5a5;">ملامسة العينين:</td>
            <td style="padding: 6px; border: 1px solid #cbd5e1;">${chem.firstAid.eyeContact}</td>
          </tr>
          <tr>
            <td style="font-weight: bold; background: #fef2f2; color: #991b1b; padding: 6px; border: 1px solid #fca5a5;">ملامسة الجلد:</td>
            <td style="padding: 6px; border: 1px solid #cbd5e1;">${chem.firstAid.skinContact}</td>
          </tr>
          <tr>
            <td style="font-weight: bold; background: #fef2f2; color: #991b1b; padding: 6px; border: 1px solid #fca5a5;">الاستنشاق:</td>
            <td style="padding: 6px; border: 1px solid #cbd5e1;">${chem.firstAid.inhalation}</td>
          </tr>
          <tr>
            <td style="font-weight: bold; background: #fef2f2; color: #991b1b; padding: 6px; border: 1px solid #fca5a5;">الابتلاع:</td>
            <td style="padding: 6px; border: 1px solid #cbd5e1;">${chem.firstAid.ingestion}</td>
          </tr>
        </table>

        <!-- Section 5: Spill Response & Code Orange -->
        <h3 style="font-size: 14px; font-weight: 900; color: #0f766e; border-bottom: 1.5px solid #cbd5e1; padding-bottom: 4px; margin-bottom: 8px;">
          5. خطة الاستجابة للانسكابات والنداء البرتقالي (Code Orange & Spill Containment)
        </h3>
        <div style="background: #fffbeb; border: 1px solid #fef3c7; border-radius: 8px; padding: 10px; margin-bottom: 14px; font-size: 11px; line-height: 1.5;">
          <p style="margin: 0 0 6px 0;"><strong>• الانسكاب البسيط (&lt; 50 مل):</strong> ${chem.spillResponse.minorSpill}</p>
          <p style="margin: 0 0 6px 0;"><strong>• الانسكاب الكبير (&gt; 50 مل - كود برتقالي):</strong> ${chem.spillResponse.majorSpill}</p>
          <p style="margin: 0 0 6px 0;"><strong>• مادة المحايدة / التثبيت:</strong> ${chem.spillResponse.neutralizer}</p>
          <p style="margin: 0 0 6px 0;"><strong>• التخلص من النفايات:</strong> ${chem.spillResponse.wasteDisposal}</p>
          <p style="margin: 0;"><strong>• عدة الانسكاب الواجب توفرها:</strong> ${chem.spillResponse.spillKitRequired}</p>
        </div>

        <!-- Section 6: Storage & Emergency Contacts -->
        <div style="display: grid; grid-template-columns: 1fr 180px; gap: 12px; align-items: center; border-top: 2px solid #0f766e; padding-top: 12px;">
          <div style="font-size: 11px; line-height: 1.6; color: #334155;">
            <strong>شروط التخزين:</strong> ${chem.storage.storageConditions}<br/>
            <strong>المواد المحظور تخزينها بجوارها:</strong> ${chem.storage.incompatibilities}<br/>
            <strong>متطلبات التهوية:</strong> ${chem.storage.ventilationRequired}
          </div>
          <div style="text-align: center; border: 2px dashed #0f766e; border-radius: 8px; padding: 8px; background: #f0fdfa;">
            <img src="${qrUrl}" alt="MSDS Online QR" style="width: 70px; height: 70px; margin: 0 auto 4px auto; display: block;" />
            <div style="font-size: 9px; font-weight: bold; color: #0f766e;">طوارئ السلامة المباشر 24/7</div>
            <div style="font-size: 14px; font-weight: 900; color: #0f172a; font-family: monospace;">${AZAL_SAFETY_EMERGENCY_PHONE}</div>
          </div>
        </div>
      </div>
    `;

    executeSmartPrint(sheetHtml, {
      title: `صحيفة بيانات السلامة (MSDS) - ${chem.nameAr}`,
      subtitle: `مستشفى آزال النموذجي • إدارة السلامة والجودة والاعتماد CBAHI (FMS-APP-070EA)`,
      refNumber: `MSDS-${chem.casNumber}-${chem.id.toUpperCase().slice(0, 8)}`
    });
  };

  return (
    <div className="space-y-4 pb-12 max-w-7xl mx-auto">
      {/* Top Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-teal-950 to-slate-900 border border-teal-800/60 rounded-2xl p-4 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-teal-600/30 border border-teal-500/50 flex items-center justify-center text-teal-300 shadow-inner">
              <FlaskConical className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-xl sm:text-2xl font-black text-white">
                  مكتبة صحائف بيانات سلامة المواد (Digital MSDS Library)
                </h1>
                <span className="bg-teal-500/20 text-teal-300 border border-teal-500/40 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full">
                  سياسة: {AZAL_HOSPITAL_POLICY_CODE}
                </span>
                <span className="bg-orange-500/20 text-orange-300 border border-orange-500/40 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                  <span>☣️</span>
                  <span>جاهزية الكود البرتقالي</span>
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
                الدليل الرقمي التفاعلي المعتمد لمستشفى آزال النموذجي لاستعراض بطاقات المواد الكيميائية، وتصنيف المخاطر NFPA 704، وتدابير مهمات الوقاية (PPE) وإجراءات السيطرة على الانسكابات وطباعة ملصقات العبوات.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full md:w-auto justify-end flex-wrap">
            <a
              href={`tel:${AZAL_SAFETY_EMERGENCY_PHONE}`}
              className="px-3.5 py-2 rounded-xl bg-rose-950/80 hover:bg-rose-900 text-rose-200 border border-rose-700/60 font-bold text-xs flex items-center gap-1.5 transition shadow-sm"
              title="خط طوارئ السلامة والانسكابات المباشر"
            >
              <PhoneCall className="w-4 h-4 text-rose-400 animate-pulse" />
              <span>طوارئ السلامة: {AZAL_SAFETY_EMERGENCY_PHONE}</span>
            </a>

            <button
              type="button"
              onClick={() => setShowAddModal(true)}
              className="px-3.5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-teal-950 transition active:scale-95 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة مادة جديدة</span>
            </button>

            {onClose && (
              <button
                type="button"
                onClick={onClose}
                className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs flex items-center gap-1 transition"
              >
                <X className="w-4 h-4" />
                <span>إغلاق</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3.5 shadow-sm space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث بالاسم العربي، الإنجليزي، رقم CAS (مثال: 111-30-8)، الصيغة، أو القسم..."
              className="w-full bg-slate-950 border border-slate-700 focus:border-teal-500 rounded-xl pr-9 pl-4 py-2 text-xs sm:text-sm text-slate-100 placeholder-slate-500 outline-none transition"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
              >
                مسح
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <select
              value={selectedDepartment}
              onChange={(e) => setSelectedDepartment(e.target.value)}
              className="bg-slate-950 border border-slate-700 focus:border-teal-500 text-slate-200 text-xs rounded-xl px-3 py-2 outline-none font-medium"
            >
              <option value="all">جميع الأقسام الطبية والمرافق</option>
              <option value="التعقيم">قسم التعقيم المركزي (CSSD)</option>
              <option value="المختبر">المختبر وبنك الدم</option>
              <option value="الأنسجة">مختبر الأنسجة والباثولوجي</option>
              <option value="المناظير">وحدة المناظير</option>
              <option value="العمليات">غرف العمليات الجراحية (OR)</option>
              <option value="النظافة">النظافة ومكافحة العدوى</option>
            </select>

            <select
              value={selectedHazardFilter}
              onChange={(e) => setSelectedHazardFilter(e.target.value)}
              className="bg-slate-950 border border-slate-700 focus:border-teal-500 text-slate-200 text-xs rounded-xl px-3 py-2 outline-none font-medium"
            >
              <option value="all">جميع تصنيفات الخطورة</option>
              <option value="flammable">🔥 مواد قابلة للاشتعال</option>
              <option value="toxic">☠️ سمية حادة وتنفسية</option>
              <option value="oxidizer">💥 مواد مؤكسدة (Oxidizer)</option>
              <option value="corrosive">🧪 مواد كاوية ومسببة للتآكل</option>
              <option value="carcinogen">⚠️ مسببات التسرطن (Carcinogen)</option>
            </select>
          </div>
        </div>

        {/* Quick Department Badges */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px] scrollbar-thin">
          <span className="text-slate-400 font-bold ml-1 whitespace-nowrap">الوصول السريع:</span>
          {[
            { id: 'all', label: 'الكل' },
            { id: 'التعقيم', label: 'التعقيم CSSD' },
            { id: 'الأنسجة', label: 'مختبر الأنسجة (Histology)' },
            { id: 'المختبر', label: 'بنك الدم والمختبر' },
            { id: 'النظافة', label: 'الكلور ومكافحة العدوى' }
          ].map(tab => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setSelectedDepartment(tab.id)}
              className={`px-2.5 py-1 rounded-lg font-bold transition whitespace-nowrap ${
                selectedDepartment === tab.id
                  ? 'bg-teal-600 text-white shadow-sm'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
          <span className="text-slate-500 text-[10px] mr-auto">
            عرض {filteredList.length} من أصل {msdsList.length} مادة مسجلة
          </span>
        </div>
      </div>

      {/* Chemical Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredList.map((chem) => {
          const isDanger = chem.signalWord.includes('خطر');
          return (
            <div
              key={chem.id}
              className="bg-slate-900 border border-slate-800 hover:border-teal-700/80 rounded-2xl p-4 transition-all duration-200 hover:shadow-xl flex flex-col justify-between group relative"
            >
              {/* Top Row: NFPA Diamond + Names */}
              <div>
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <span
                        className={`text-[10px] font-black px-2 py-0.5 rounded-md uppercase tracking-wider ${
                          isDanger
                            ? 'bg-rose-950 text-rose-300 border border-rose-700'
                            : 'bg-amber-950 text-amber-300 border border-amber-700'
                        }`}
                      >
                        {chem.signalWord}
                      </span>
                      {chem.isCustom && (
                        <span className="text-[9px] bg-teal-950 text-teal-300 border border-teal-800 px-1.5 py-0.2 rounded font-bold">
                          مضاف محلياً
                        </span>
                      )}
                    </div>
                    <h2 className="text-base font-black text-slate-100 group-hover:text-teal-300 transition-colors line-clamp-1">
                      {chem.nameAr}
                    </h2>
                    <p className="text-xs text-slate-400 font-medium line-clamp-1 direction-ltr text-right">
                      {chem.nameEn}
                    </p>
                    <div className="text-[11px] text-teal-400/90 font-mono mt-0.5">
                      CAS: {chem.casNumber} {chem.chemicalFormula ? `• ${chem.chemicalFormula}` : ''}
                    </div>
                  </div>

                  {/* NFPA Diamond Preview */}
                  <div className="flex-shrink-0 bg-slate-950 p-1 rounded-xl border border-slate-800 shadow-inner">
                    <Nfpa704DiamondBadge diamond={chem.nfpa704} size="md" />
                  </div>
                </div>

                {/* Primary Departments Chips */}
                <div className="flex flex-wrap gap-1 mb-2.5">
                  {chem.primaryDepartments.map((dept, idx) => (
                    <span
                      key={idx}
                      className="text-[9.5px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded-md border border-slate-700/60 font-medium"
                    >
                      {dept}
                    </span>
                  ))}
                </div>

                {/* Key Hazards Preview */}
                <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-2.5 mb-3 text-[11px] space-y-1">
                  <div className="text-slate-400 font-bold flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                    <span>أبرز المخاطر المحددة:</span>
                  </div>
                  <ul className="text-slate-300 space-y-0.5 pr-3 list-disc list-inside">
                    {chem.hazardClassifications.slice(0, 2).map((h, i) => (
                      <li key={i} className="line-clamp-1">{h}</li>
                    ))}
                  </ul>
                </div>

                {/* Required PPE summary icons */}
                <div className="flex items-center gap-2 text-[10px] text-slate-400 bg-slate-800/40 p-2 rounded-lg border border-slate-800 mb-3">
                  <Shield className="w-3.5 h-3.5 text-teal-400 flex-shrink-0" />
                  <span className="line-clamp-1">
                    <strong>الوقاية:</strong> {chem.requiredPpe.gloves} • {chem.requiredPpe.eyeFace}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 border-t border-slate-800 space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setActiveItemModal(chem)}
                    className="py-1.5 px-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs flex items-center justify-center gap-1 transition shadow-sm cursor-pointer"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>عرض الـ MSDS</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handlePrintChemicalLabel(chem)}
                    className="py-1.5 px-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 font-bold text-xs flex items-center justify-center gap-1 border border-teal-800/60 transition cursor-pointer"
                    title="طباعة ملصق تحذير معتمد مقاس A6/A5 للصقه على الحاوية"
                  >
                    <Printer className="w-3.5 h-3.5 text-teal-400" />
                    <span>ملصق العبوة</span>
                  </button>
                </div>

                <div className="flex items-center justify-between text-[11px] px-1 text-slate-400">
                  <button
                    type="button"
                    onClick={() => handlePrintFullMsdsSheet(chem)}
                    className="hover:text-teal-300 flex items-center gap-1 transition cursor-pointer"
                  >
                    <Printer className="w-3 h-3 text-slate-400" />
                    <span>طباعة A4 PDF</span>
                  </button>

                  {onSelectForCodeOrange && (
                    <button
                      type="button"
                      onClick={() => onSelectForCodeOrange(chem)}
                      className="text-orange-400 hover:text-orange-300 font-bold flex items-center gap-1 transition cursor-pointer"
                    >
                      <span>تحديد للانسكاب</span>
                      <span>☣️</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filteredList.length === 0 && (
        <div className="text-center py-12 bg-slate-900 border border-slate-800 rounded-2xl p-6">
          <FlaskConical className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-200 mb-1">لا توجد مواد تطابق معايير البحث الحالية</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto mb-4">
            جرب تعديل كلمة البحث أو إزالة فلاتر الأقسام والخطورة لاستعراض كافة صحائف السلامة.
          </p>
          <button
            type="button"
            onClick={() => {
              setSearchQuery('');
              setSelectedDepartment('all');
              setSelectedHazardFilter('all');
            }}
            className="px-4 py-2 rounded-xl bg-teal-600 text-white text-xs font-bold"
          >
            إعادة تعيين الفلاتر
          </button>
        </div>
      )}

      {/* Modal: Full Detailed MSDS Card */}
      {activeItemModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/80 backdrop-blur-md overflow-y-auto animate-fadeIn">
          <div className="bg-slate-900 border border-teal-800 rounded-2xl max-w-3xl w-full p-4 sm:p-6 shadow-2xl space-y-4 my-6 max-h-[92vh] flex flex-col">
            {/* Modal Header */}
            <div className="flex items-start justify-between gap-3 border-b border-slate-800 pb-3">
              <div className="flex items-start gap-3">
                <div className="p-2.5 rounded-xl bg-teal-950 border border-teal-800 text-teal-400 mt-1">
                  <FlaskConical className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h2 className="text-lg sm:text-xl font-black text-white">
                      {activeItemModal.nameAr}
                    </h2>
                    <span
                      className={`text-[10px] font-black px-2 py-0.5 rounded-md ${
                        activeItemModal.signalWord.includes('خطر')
                          ? 'bg-rose-950 text-rose-300 border border-rose-700'
                          : 'bg-amber-950 text-amber-300 border border-amber-700'
                      }`}
                    >
                      {activeItemModal.signalWord}
                    </span>
                  </div>
                  <p className="text-xs text-teal-400 font-semibold direction-ltr text-right">
                    {activeItemModal.nameEn}
                  </p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    رقم CAS: <span className="font-mono text-slate-200">{activeItemModal.casNumber}</span> • الصيغة: <span className="font-mono text-slate-200">{activeItemModal.chemicalFormula || '-'}</span> • السياسة: {activeItemModal.fmsPolicyCode}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handlePrintChemicalLabel(activeItemModal)}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-400 transition"
                  title="طباعة ملصق العبوة"
                >
                  <Printer className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setActiveItemModal(null)}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Body Scrollable */}
            <div className="overflow-y-auto space-y-4 pr-1 pl-1 text-xs scrollbar-thin">
              {/* NFPA & Hazard Overview */}
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-3.5 flex flex-col sm:flex-row items-center gap-4">
                <div className="flex-shrink-0 text-center">
                  <Nfpa704DiamondBadge diamond={activeItemModal.nfpa704} size="lg" />
                  <div className="text-[10px] text-slate-400 mt-1 font-bold">معين NFPA 704</div>
                </div>

                <div className="flex-1 space-y-1.5 text-slate-300">
                  <div className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4" />
                    <span>تصنيفات ومخاطر المادة:</span>
                  </div>
                  <ul className="space-y-1 pr-3 list-disc list-inside text-slate-200">
                    {activeItemModal.hazardClassifications.map((h, idx) => (
                      <li key={idx} className="leading-relaxed">{h}</li>
                    ))}
                  </ul>
                  {activeItemModal.concentration && (
                    <div className="text-[11px] text-teal-300 font-semibold pt-1">
                      التركيز المعتمد في المستشفى: {activeItemModal.concentration}
                    </div>
                  )}
                </div>
              </div>

              {/* Section: Mandatory PPE */}
              <div className="border border-teal-900/60 bg-teal-950/20 rounded-xl p-3.5 space-y-2">
                <div className="text-xs font-black text-teal-300 flex items-center gap-1.5">
                  <Shield className="w-4 h-4 text-teal-400" />
                  <span>معدات الوقاية الشخصية الإلزامية (Mandatory PPE):</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                  <div className="bg-slate-900/90 border border-slate-800 p-2.5 rounded-lg">
                    <strong className="text-teal-400 block mb-0.5">👁️ العين والوجه:</strong>
                    <span className="text-slate-200">{activeItemModal.requiredPpe.eyeFace}</span>
                  </div>
                  <div className="bg-slate-900/90 border border-slate-800 p-2.5 rounded-lg">
                    <strong className="text-teal-400 block mb-0.5">🧤 اليدين والقفازات:</strong>
                    <span className="text-slate-200">{activeItemModal.requiredPpe.gloves}</span>
                  </div>
                  <div className="bg-slate-900/90 border border-slate-800 p-2.5 rounded-lg">
                    <strong className="text-teal-400 block mb-0.5">🫁 الحماية التنفسية:</strong>
                    <span className="text-slate-200">{activeItemModal.requiredPpe.respiratory}</span>
                  </div>
                  <div className="bg-slate-900/90 border border-slate-800 p-2.5 rounded-lg">
                    <strong className="text-teal-400 block mb-0.5">🦺 المريلة والأقدام:</strong>
                    <span className="text-slate-200">
                      {activeItemModal.requiredPpe.body} {activeItemModal.requiredPpe.footwear ? `• ${activeItemModal.requiredPpe.footwear}` : ''}
                    </span>
                  </div>
                </div>
              </div>

              {/* Section: First Aid Measures */}
              <div className="border border-rose-900/60 bg-rose-950/20 rounded-xl p-3.5 space-y-2">
                <div className="text-xs font-black text-rose-300 flex items-center gap-1.5">
                  <HeartPulse className="w-4 h-4 text-rose-400" />
                  <span>تدابير الإسعافات الأولية المباشرة (Immediate First Aid):</span>
                </div>
                <div className="space-y-1.5 text-[11px] text-slate-200">
                  <div className="bg-slate-900/90 border border-slate-800 p-2.5 rounded-lg">
                    <strong className="text-rose-400">ملامسة العين:</strong> {activeItemModal.firstAid.eyeContact}
                  </div>
                  <div className="bg-slate-900/90 border border-slate-800 p-2.5 rounded-lg">
                    <strong className="text-rose-400">ملامسة الجلد:</strong> {activeItemModal.firstAid.skinContact}
                  </div>
                  <div className="bg-slate-900/90 border border-slate-800 p-2.5 rounded-lg">
                    <strong className="text-rose-400">الاستنشاق:</strong> {activeItemModal.firstAid.inhalation}
                  </div>
                  <div className="bg-slate-900/90 border border-slate-800 p-2.5 rounded-lg">
                    <strong className="text-rose-400">الابتلاع:</strong> {activeItemModal.firstAid.ingestion}
                  </div>
                </div>
              </div>

              {/* Section: Spill Response & Code Orange */}
              <div className="border border-orange-900/60 bg-orange-950/20 rounded-xl p-3.5 space-y-2">
                <div className="text-xs font-black text-orange-300 flex items-center gap-1.5">
                  <span>☣️</span>
                  <span>إجراءات تنظيف الانسكاب والنداء البرتقالي (Spill Kit & Code Orange):</span>
                </div>
                <div className="space-y-1.5 text-[11px] text-slate-200">
                  <div className="bg-slate-900/90 border border-slate-800 p-2.5 rounded-lg">
                    <strong className="text-orange-400 block mb-0.5">الانسكاب البسيط (&lt; 50 مل):</strong>
                    <span>{activeItemModal.spillResponse.minorSpill}</span>
                  </div>
                  <div className="bg-slate-900/90 border border-slate-800 p-2.5 rounded-lg">
                    <strong className="text-orange-400 block mb-0.5">الانسكاب الكبير (&gt; 50 مل):</strong>
                    <span>{activeItemModal.spillResponse.majorSpill}</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <div className="bg-slate-900/90 border border-slate-800 p-2.5 rounded-lg">
                      <strong className="text-amber-300 block mb-0.5">المحايدة والتثبيت:</strong>
                      <span>{activeItemModal.spillResponse.neutralizer}</span>
                    </div>
                    <div className="bg-slate-900/90 border border-slate-800 p-2.5 rounded-lg">
                      <strong className="text-amber-300 block mb-0.5">التخلص من المخلفات:</strong>
                      <span>{activeItemModal.spillResponse.wasteDisposal}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Section: Storage & Handling */}
              <div className="border border-slate-800 bg-slate-950/60 rounded-xl p-3.5 space-y-1.5 text-[11px] text-slate-300">
                <div className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                  <Building2 className="w-4 h-4 text-teal-400" />
                  <span>شروط التخزين والمناولة والتهوية:</span>
                </div>
                <p><strong>• ظروف الحفظ:</strong> {activeItemModal.storage.storageConditions}</p>
                <p><strong>• المواد المحظور تخزينها بجوارها:</strong> {activeItemModal.storage.incompatibilities}</p>
                <p><strong>• متطلبات التهوية:</strong> {activeItemModal.storage.ventilationRequired}</p>
              </div>
            </div>

            {/* Modal Footer Actions */}
            <div className="pt-3 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="text-slate-400 text-[11px] flex items-center gap-1.5">
                <PhoneCall className="w-3.5 h-3.5 text-rose-400" />
                <span>طوارئ السلامة المباشر 24 ساعة:</span>
                <strong className="text-white font-mono">{AZAL_SAFETY_EMERGENCY_PHONE}</strong>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                <button
                  type="button"
                  onClick={() => handlePrintChemicalLabel(activeItemModal)}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 border border-teal-800/60 font-bold text-xs flex items-center gap-1.5 transition"
                >
                  <Printer className="w-4 h-4 text-teal-400" />
                  <span>طباعة ملصق العبوة (A6/A5)</span>
                </button>

                <button
                  type="button"
                  onClick={() => handlePrintFullMsdsSheet(activeItemModal)}
                  className="px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs flex items-center gap-1.5 transition shadow-lg shadow-teal-950"
                >
                  <Printer className="w-4 h-4" />
                  <span>طباعة الوثيقة كاملة (A4 PDF)</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Add New Chemical to MSDS Library */}
      {showAddModal && (
        <AddChemicalMsdsModal
          onClose={() => setShowAddModal(false)}
          onSave={saveCustomChemical}
        />
      )}
    </div>
  );
};

// Subcomponent: Add New Chemical Modal
const AddChemicalMsdsModal: React.FC<{
  onClose: () => void;
  onSave: (chem: ChemicalMsdsItem) => void;
}> = ({ onClose, onSave }) => {
  const [nameAr, setNameAr] = useState('');
  const [nameEn, setNameEn] = useState('');
  const [commonNameAr, setCommonNameAr] = useState('');
  const [casNumber, setCasNumber] = useState('');
  const [chemicalFormula, setChemicalFormula] = useState('');
  const [concentration, setConcentration] = useState('');
  const [departmentsInput, setDepartmentsInput] = useState('المختبر, قسم التعقيم');
  const [signalWord, setSignalWord] = useState<'خطر (Danger)' | 'تحذير (Warning)'>('خطر (Danger)');
  
  // NFPA 704
  const [health, setHealth] = useState(2);
  const [flammability, setFlammability] = useState(0);
  const [instability, setInstability] = useState(0);
  const [special, setSpecial] = useState('');

  // Hazards & PPE
  const [hazardsInput, setHazardsInput] = useState('مخرش للعين والجلد, سام عند الاستنشاق');
  const [eyeFacePpe, setEyeFacePpe] = useState('نظارات واقية كيميائية محكمة');
  const [glovesPpe, setGlovesPpe] = useState('قفازات نيتريل سميكة مقاومة للكيماويات');
  const [respiratoryPpe, setRespiratoryPpe] = useState('كمامة بخار عضوي / فلتر كيميائي');
  const [bodyPpe, setBodyPpe] = useState('مريلة كيميائية مقاومة للسوائل');

  // First Aid
  const [eyeFirstAid, setEyeFirstAid] = useState('غسل فوري بماء جاري لمدة 15 دقيقة مع فتح الأجفان.');
  const [skinFirstAid, setSkinFirstAid] = useState('غسل الجلد بالماء الجاري والصابون ونزع الملابس الملوثة.');
  const [inhalationFirstAid, setInhalationFirstAid] = useState('نقل المصاب إلى الهواء الطلق النقي فوراً واستدعاء الطبيب.');
  const [ingestionFirstAid, setIngestionFirstAid] = useState('عدم إحداث التقيؤ وشرب الماء ونقل المصاب للطوارئ فوراً.');

  // Spill Response
  const [minorSpill, setMinorSpill] = useState('امتصاص بمواد ماصة خاملة ومسح السطح بالماء.');
  const [majorSpill, setMajorSpill] = useState('إطلاق كود برتقالي، عزل المنطقة وارتداء الـ PPE واستخدام عدة الانسكاب.');
  const [neutralizer, setNeutralizer] = useState('حبيبات امتصاص كيميائية خاملة.');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameAr.trim() || !casNumber.trim()) {
      alert('يرجى إدخال اسم المادة ورقم CAS');
      return;
    }

    const newItem: ChemicalMsdsItem = {
      id: `custom-chem-${Date.now()}`,
      nameAr: nameAr.trim(),
      nameEn: nameEn.trim() || nameAr.trim(),
      commonNameAr: commonNameAr.trim() || undefined,
      casNumber: casNumber.trim(),
      chemicalFormula: chemicalFormula.trim() || undefined,
      concentration: concentration.trim() || undefined,
      primaryDepartments: departmentsInput.split(/[,،]/).map(d => d.trim()).filter(Boolean),
      fmsPolicyCode: AZAL_HOSPITAL_POLICY_CODE,
      signalWord,
      nfpa704: {
        health: Number(health) || 0,
        flammability: Number(flammability) || 0,
        instability: Number(instability) || 0,
        special: special.trim() || undefined
      },
      hazardClassifications: hazardsInput.split(/[,،\n]/).map(h => h.trim()).filter(Boolean),
      hazardStatements: [],
      precautionaryStatements: [],
      requiredPpe: {
        eyeFace: eyeFacePpe.trim(),
        gloves: glovesPpe.trim(),
        respiratory: respiratoryPpe.trim(),
        body: bodyPpe.trim()
      },
      firstAid: {
        eyeContact: eyeFirstAid.trim(),
        skinContact: skinFirstAid.trim(),
        inhalation: inhalationFirstAid.trim(),
        ingestion: ingestionFirstAid.trim()
      },
      spillResponse: {
        minorSpill: minorSpill.trim(),
        majorSpill: majorSpill.trim(),
        neutralizer: neutralizer.trim(),
        wasteDisposal: 'توضع المخلفات في أكياس النفايات الخطرة المعتمدة وتغلق بإحكام.',
        spillKitRequired: 'عدة انسكاب كيميائي معتمدة متوفرة بالقسم.'
      },
      storage: {
        storageConditions: 'يحفظ في مكان بارد وجاف وجيد التهوية.',
        incompatibilities: 'تجنب خلطه مع المواد غير المتوافقة والمؤكسدات.',
        ventilationRequired: 'هود سحب أو تهوية ميكانيكية فعالة.'
      },
      emergencyContact: AZAL_SAFETY_EMERGENCY_PHONE,
      isCustom: true,
      updatedAt: new Date().toISOString()
    };

    onSave(newItem);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="bg-slate-900 border border-teal-800 rounded-2xl max-w-2xl w-full p-5 shadow-2xl space-y-4 my-6 max-h-[92vh] flex flex-col">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <FlaskConical className="w-5 h-5 text-teal-400" />
            <h2 className="text-base sm:text-lg font-black text-white">
              إضافة مادة كيميائية جديدة لمكتبة الـ MSDS
            </h2>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="overflow-y-auto space-y-3.5 pr-1 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-bold mb-1">الاسم بالعربية *</label>
              <input
                type="text"
                required
                value={nameAr}
                onChange={e => setNameAr(e.target.value)}
                placeholder="مثال: حمض الكبريتيك 98%"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-bold mb-1">الاسم بالإنجليزية *</label>
              <input
                type="text"
                required
                value={nameEn}
                onChange={e => setNameEn(e.target.value)}
                placeholder="مثال: Sulfuric Acid 98%"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100 direction-ltr text-right"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-slate-300 font-bold mb-1">رقم CAS *</label>
              <input
                type="text"
                required
                value={casNumber}
                onChange={e => setCasNumber(e.target.value)}
                placeholder="مثال: 7664-93-9"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100 font-mono"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-bold mb-1">الصيغة الكيميائية</label>
              <input
                type="text"
                value={chemicalFormula}
                onChange={e => setChemicalFormula(e.target.value)}
                placeholder="مثال: H2SO4"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100 font-mono"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-bold mb-1">كلمة التنبيه</label>
              <select
                value={signalWord}
                onChange={e => setSignalWord(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
              >
                <option value="خطر (Danger)">خطر (Danger)</option>
                <option value="تحذير (Warning)">تحذير (Warning)</option>
              </select>
            </div>
          </div>

          {/* NFPA 704 Controls */}
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
            <div className="font-bold text-slate-300 mb-2">معين تصنيف المخاطر NFPA 704 (0 إلى 4):</div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <div>
                <label className="text-[10px] text-blue-400 font-bold block mb-0.5">الصحة (0-4):</label>
                <input
                  type="number"
                  min="0"
                  max="4"
                  value={health}
                  onChange={e => setHealth(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-center text-white font-bold"
                />
              </div>
              <div>
                <label className="text-[10px] text-red-400 font-bold block mb-0.5">الاشتعال (0-4):</label>
                <input
                  type="number"
                  min="0"
                  max="4"
                  value={flammability}
                  onChange={e => setFlammability(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-center text-white font-bold"
                />
              </div>
              <div>
                <label className="text-[10px] text-yellow-400 font-bold block mb-0.5">النشاط (0-4):</label>
                <input
                  type="number"
                  min="0"
                  max="4"
                  value={instability}
                  onChange={e => setInstability(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-center text-white font-bold"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-300 font-bold block mb-0.5">خاص (W, OX, COR):</label>
                <input
                  type="text"
                  maxLength={5}
                  value={special}
                  onChange={e => setSpecial(e.target.value.toUpperCase())}
                  placeholder="COR"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-center text-white font-mono uppercase"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-slate-300 font-bold mb-1">الأقسام المستخدمة (مفصولة بفواصل)</label>
            <input
              type="text"
              value={departmentsInput}
              onChange={e => setDepartmentsInput(e.target.value)}
              placeholder="مثال: المختبر, قسم التعقيم, غرف العمليات"
              className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-bold mb-1">أبرز المخاطر الصحية والفيزيائية</label>
            <textarea
              rows={2}
              value={hazardsInput}
              onChange={e => setHazardsInput(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
            />
          </div>

          {/* PPE */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <div>
              <label className="block text-teal-400 font-bold mb-1">قفازات اليدين الموصى بها:</label>
              <input
                type="text"
                value={glovesPpe}
                onChange={e => setGlovesPpe(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-1.5 text-slate-100 text-[11px]"
              />
            </div>
            <div>
              <label className="block text-teal-400 font-bold mb-1">حماية العين والوجه:</label>
              <input
                type="text"
                value={eyeFacePpe}
                onChange={e => setEyeFacePpe(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-1.5 text-slate-100 text-[11px]"
              />
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs shadow-lg shadow-teal-950"
            >
              حفظ المادة في المكتبة
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
