import React, { useState, useEffect } from 'react';
import { 
  Package, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  Plus, 
  Printer, 
  Search, 
  Filter, 
  Key, 
  UserCheck, 
  ShieldCheck, 
  Trash2, 
  Calendar,
  Lock,
  ArrowRightCircle
} from 'lucide-react';
import { LostAndFoundItemRecord, StaffUser } from '../types';
import { offlineStorage } from '../services/offlineStorage';
import { AZAL_HOSPITAL_LOCATIONS } from '../data/azalSecurityData';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';
import { executeSmartPrint } from '../utils/printUtils';
import { PatientValuablesTrackerView } from './PatientValuablesTrackerView';
import { Shield } from 'lucide-react';

interface LostAndFoundLogViewProps {
  currentUser: StaffUser;
  onLogAudit: (action: string, actionAr: string, details: string) => void;
}

const INITIAL_LOST_FOUND: LostAndFoundItemRecord[] = [
  {
    id: 'lf-001',
    itemReference: 'LF-2026-012',
    foundDate: new Date().toISOString().split('T')[0],
    foundLocation: 'استراحة انتظار العيادات الخارجية - الدور الأول',
    itemCategory: 'electronics',
    description: 'هاتف ذكي سامسونج جالاكسي S23 أسود مع كفر جلدي كحلي',
    finderName: 'أحمد صالح (عامل نظافة)',
    custodyLocation: 'خزنة الأمانات بمكتب مدير الأمن',
    status: 'safekeeping',
    notes: 'الهاتف مقفل بكلمة مرور، الشاشة سليمة ومحتفظ به في الأمانات.',
    createdAt: Date.now() - 1000 * 60 * 60 * 8
  },
  {
    id: 'lf-002',
    itemReference: 'LF-2026-011',
    foundDate: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3).toISOString().split('T')[0],
    foundLocation: 'مكتب استقبال الطوارئ الرئيسي',
    itemCategory: 'documents',
    description: 'محفظة جلدية بنية بداخلها بطاقة شخصية ورخصة قيادة باسم / خالد عبده',
    finderName: 'موظف استقبال الطوارئ',
    custodyLocation: 'خزنة الأمانات',
    status: 'returned_to_owner',
    claimedByName: 'خالد عبده الحبيشي',
    claimedByPhone: '773456789',
    claimedByIdNumber: '01010049281',
    handedOverDate: new Date().toISOString().split('T')[0],
    securityOfficerHandover: 'م/ نجيب غازي',
    notes: 'تم التحقق من مطابقة بطاقة الهوية وتوقيع المستلم على سند التسليم.',
    createdAt: Date.now() - 1000 * 60 * 60 * 72
  },
  {
    id: 'lf-003',
    itemReference: 'LF-2026-010',
    foundDate: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5).toISOString().split('T')[0],
    foundLocation: 'مسجد المستشفى - الدور الأرضي',
    itemCategory: 'jewelry_watch',
    description: 'ساعة يد رجالية فضية ماركة Citizen',
    finderName: 'أحد المصلين',
    custodyLocation: 'خزنة الأمانات بمكتب الأمن',
    status: 'safekeeping',
    notes: 'تم العثور عليها على رف المصاحف بالمسجد.',
    createdAt: Date.now() - 1000 * 60 * 60 * 120
  }
];

export const LostAndFoundLogView: React.FC<LostAndFoundLogViewProps> = ({
  currentUser,
  onLogAudit
}) => {
  const [subTab, setSubTab] = useState<'general' | 'patient_valuables'>('general');
  const [items, setItems] = useState<LostAndFoundItemRecord[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedHandoverItem, setSelectedHandoverItem] = useState<LostAndFoundItemRecord | null>(null);

  // Form State
  const [foundLocation, setFoundLocation] = useState(AZAL_HOSPITAL_LOCATIONS[0]);
  const [itemCategory, setItemCategory] = useState<'money' | 'electronics' | 'documents' | 'jewelry_watch' | 'luggage' | 'other'>('electronics');
  const [description, setDescription] = useState('');
  const [finderName, setFinderName] = useState('');
  const [custodyLocation, setCustodyLocation] = useState('خزنة أمانات مكتب الأمن الرئيسي');
  const [notes, setNotes] = useState('');

  // Handover Modal State
  const [claimedByName, setClaimedByName] = useState('');
  const [claimedByPhone, setClaimedByPhone] = useState('');
  const [claimedByIdNumber, setClaimedByIdNumber] = useState('');

  useEffect(() => {
    loadItems();
  }, []);

  const loadItems = async () => {
    try {
      const stored = await offlineStorage.getLostAndFoundItems();
      if (stored && stored.length > 0) {
        setItems(stored);
      } else {
        setItems(INITIAL_LOST_FOUND);
        for (const item of INITIAL_LOST_FOUND) {
          await offlineStorage.saveLostAndFoundItem(item);
        }
      }
    } catch {
      setItems(INITIAL_LOST_FOUND);
    }
  };

  const handleCreateItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim() || !finderName.trim()) return;

    const currentYear = new Date().getFullYear();
    const count = items.length + 1;
    const itemReference = `LF-${currentYear}-${String(count).padStart(3, '0')}`;

    const newItem: LostAndFoundItemRecord = {
      id: `lf-${Date.now()}`,
      itemReference,
      foundDate: new Date().toISOString().split('T')[0],
      foundLocation,
      itemCategory,
      description: description.trim(),
      finderName: finderName.trim(),
      custodyLocation,
      status: 'safekeeping',
      notes: notes.trim() || 'تم استلام الأمانة وحفظها في خزنة مكتب الأمن المعتمدة.',
      createdAt: Date.now()
    };

    const updated = [newItem, ...items];
    setItems(updated);
    await offlineStorage.saveLostAndFoundItem(newItem);

    // Audio and haptic feedback
    triggerSuccessFeedback();

    onLogAudit(
      'LOST_AND_FOUND_REGISTERED',
      'تسجيل أمانة جديدة في سجل المفقودات والموجودات',
      `تم إيداع (${newItem.description}) برقم مرجعي (${newItem.itemReference})`
    );

    setShowAddModal(false);
    setDescription('');
    setFinderName('');
    setNotes('');
  };

  const handleHandoverSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedHandoverItem || !claimedByName.trim() || !claimedByIdNumber.trim()) return;

    const today = new Date().toISOString().split('T')[0];
    const updatedItem: LostAndFoundItemRecord = {
      ...selectedHandoverItem,
      status: 'returned_to_owner',
      claimedByName: claimedByName.trim(),
      claimedByPhone: claimedByPhone.trim() || undefined,
      claimedByIdNumber: claimedByIdNumber.trim(),
      handedOverDate: today,
      securityOfficerHandover: currentUser.name,
      notes: (selectedHandoverItem.notes ? selectedHandoverItem.notes + '\n' : '') + 
             `[تم تسليم الأمانة لصاحبها الشرعي بموجب الهوية (${claimedByIdNumber}) والتوقيع في ${today} بواسطة ${currentUser.name}]`
    };

    const updated = items.map(i => i.id === selectedHandoverItem.id ? updatedItem : i);
    setItems(updated);
    await offlineStorage.saveLostAndFoundItem(updatedItem);

    // Audio and haptic feedback
    triggerSuccessFeedback();

    onLogAudit(
      'LOST_AND_FOUND_HANDOVER',
      'تسليم أمانة لصاحبها الشرعي',
      `تم تسليم الأمانة (${selectedHandoverItem.itemReference}) للمستلم: ${claimedByName}`
    );

    setSelectedHandoverItem(null);
    setClaimedByName('');
    setClaimedByPhone('');
    setClaimedByIdNumber('');
  };

  const handleDelete = async (id: string) => {
    if (confirm('هل أنت متأكد من حذف هذا السجل؟')) {
      const updated = items.filter(i => i.id !== id);
      setItems(updated);
      await offlineStorage.deleteLostAndFoundItem(id);
    }
  };

  const handlePrint = () => {
    const tableRows = filtered.map((item, idx) => {
      const catAr = 
        item.itemCategory === 'electronics' ? 'أجهزة وإلكترونيات' :
        item.itemCategory === 'money_wallets' ? 'أموال ومحافظ' :
        item.itemCategory === 'documents' ? 'وثائق وهويات' :
        item.itemCategory === 'gold_jewelry' ? 'ذهب ومجوهرات' : 'أمتعة ومتنوعات';

      const statusBadge = item.status === 'returned_to_owner'
        ? '<span class="badge-success">تم التسليم لصاحبها ✔</span>'
        : '<span class="badge-warning">في الحفظ والأمانات</span>';

      return `
        <tr>
          <td style="font-weight:bold;">${idx + 1}</td>
          <td style="font-family:monospace; font-weight:bold;">${item.itemReference}</td>
          <td><strong>${item.description}</strong></td>
          <td>${catAr}</td>
          <td>${item.foundLocation}</td>
          <td>${item.foundDate}</td>
          <td>${item.finderName}</td>
          <td>${item.custodyLocation}</td>
          <td>${statusBadge}</td>
          <td>${item.claimedByName ? `${item.claimedByName} (${item.claimedByIdNumber || '-'})` : '-'}</td>
          <td>${item.notes || '-'}</td>
        </tr>
      `;
    }).join('');

    const bodyHtml = `
      <div class="summary-grid">
        <div class="summary-card"><div class="val">${items.length}</div><div class="lbl">إجمالي الأمانات المقيدة</div></div>
        <div class="summary-card"><div class="val" style="color:#b45309;">${safekeepingCount}</div><div class="lbl">أمانات في خزنة الأمن حالياً</div></div>
        <div class="summary-card"><div class="val" style="color:#047857;">${returnedCount}</div><div class="lbl">أمانات سُلِّمت لأصحابها رسمياً</div></div>
      </div>
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>الرقم المرجعي</th>
            <th>وصف الأمانة والمحتويات</th>
            <th>التصنيف</th>
            <th>موقع العثور عليها</th>
            <th>تاريخ العثور</th>
            <th>اسم المعثور / المُسلِّم</th>
            <th>موقع الحفظ</th>
            <th>الحالة</th>
            <th>بيانات المستلم الشرعي</th>
            <th>ملاحظات الضبط والتسليم</th>
          </tr>
        </thead>
        <tbody>
          ${tableRows || '<tr><td colspan="11" style="text-align:center; padding:12px;">لا توجد أمانات مسجلة</td></tr>'}
        </tbody>
      </table>
    `;

    executeSmartPrint(bodyHtml, {
      title: 'سجل إيداع وتسليم الأمانات والمفقودات الرسمية (Lost & Found Log)',
      subtitle: 'مستشفى آزال النموذجي • إدارة الأمن والسلامة العامة • مكتب شؤون الحراسات',
      refNumber: 'AZAL-LOST-FOUND-2026'
    });
  };

  const filtered = items.filter(item => {
    const matchStatus = statusFilter === 'all' || item.status === statusFilter;
    const matchCategory = categoryFilter === 'all' || item.itemCategory === categoryFilter;
    const matchSearch = item.itemReference.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        item.foundLocation.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        (item.claimedByName && item.claimedByName.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchStatus && matchCategory && matchSearch;
  });

  const safekeepingCount = items.filter(i => i.status === 'safekeeping').length;
  const returnedCount = items.filter(i => i.status === 'returned_to_owner').length;

  const getCategoryBadge = (cat: string) => {
    switch (cat) {
      case 'electronics': return <span className="bg-blue-950 text-blue-300 border border-blue-800 px-2 py-0.5 rounded-md text-[10px]">📱 أجهزة وإلكترونيات</span>;
      case 'money': return <span className="bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded-md text-[10px]">💵 نقود ومبالغ</span>;
      case 'documents': return <span className="bg-purple-950 text-purple-300 border border-purple-800 px-2 py-0.5 rounded-md text-[10px]">📄 وثائق وهويات</span>;
      case 'jewelry_watch': return <span className="bg-amber-950 text-amber-300 border border-amber-800 px-2 py-0.5 rounded-md text-[10px]">⌚ ساعات ومجوهرات</span>;
      case 'luggage': return <span className="bg-teal-950 text-teal-300 border border-teal-800 px-2 py-0.5 rounded-md text-[10px]">🎒 حقائب وأمتعة</span>;
      default: return <span className="bg-slate-800 text-slate-300 px-2 py-0.5 rounded-md text-[10px]">📦 أخرى</span>;
    }
  };

  return (
    <div id="lost-and-found-log-view" className="space-y-4 text-right">
      {/* Module Subtabs: General Lost & Found vs. Patient Valuables 180-Day Tracker */}
      <div className="flex items-center gap-2 bg-slate-900/90 border border-slate-800 p-1.5 rounded-2xl">
        <button
          type="button"
          onClick={() => setSubTab('general')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 ${
            subTab === 'general'
              ? 'bg-indigo-600 text-white shadow-md'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>سجل المفقودات والمتروكات العامة (General Lost & Found)</span>
        </button>

        <button
          type="button"
          onClick={() => setSubTab('patient_valuables')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 ${
            subTab === 'patient_valuables'
              ? 'bg-teal-600 text-white shadow-md'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
          }`}
        >
          <Shield className="w-4 h-4" />
          <span>أمانات ومقتنيات المرضى والنزلاء (Patient Valuables & 180-Day Tracker) 🛡️</span>
        </button>
      </div>

      {subTab === 'patient_valuables' ? (
        <PatientValuablesTrackerView currentUser={currentUser} onLogAudit={onLogAudit} />
      ) : (
        <>
          {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-indigo-950/70 border border-slate-800 rounded-3xl p-5 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-indigo-950 border border-indigo-800 text-indigo-400">
            <Package className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-slate-100">
                سجل المفقودات والموجودات والأمانات (Lost & Found Log)
              </h2>
              <span className="text-[10px] bg-indigo-950 text-indigo-300 border border-indigo-800 font-bold px-2 py-0.5 rounded-lg">
                معايير الحراسات الأمنية FMS
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              تسجيل الأمانات المعثور عليها بالمستشفى، مواصفاتها، موقع الحفظ، وتوثيق إجراءات التسليم للمالك الشرعي.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md flex items-center gap-2 transition"
          >
            <Plus className="w-4 h-4" />
            <span>تسجيل أمانة جديدة</span>
          </button>

          <button
            type="button"
            onClick={handlePrint}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold flex items-center gap-1.5 transition"
          >
            <Printer className="w-4 h-4" />
            <span>طباعة السجل (Print / PDF)</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
          <div className="text-xs text-slate-400">إجمالي الأمانات المقيدة</div>
          <div className="text-2xl font-black text-slate-100 mt-1">{items.length}</div>
          <div className="text-[10px] text-teal-400 mt-1">سجلات رسمية موثقة</div>
        </div>

        <div className="bg-slate-900 border border-amber-900/60 rounded-2xl p-4">
          <div className="text-xs text-slate-400">محتفظ بها في خزنة الأمانات</div>
          <div className="text-2xl font-black text-amber-400 mt-1">{safekeepingCount}</div>
          <div className="text-[10px] text-amber-300 mt-1">بانتظار مراجعة أصحابها</div>
        </div>

        <div className="bg-slate-900 border border-emerald-900/60 rounded-2xl p-4">
          <div className="text-xs text-slate-400">سُلّمت لأصحابها الشرعيين</div>
          <div className="text-2xl font-black text-emerald-400 mt-1">{returnedCount}</div>
          <div className="text-[10px] text-emerald-300 mt-1">مع التوقيع ورقم الهوية</div>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="bg-slate-900/80 border border-slate-800 p-3 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex-1 min-w-[200px] relative">
          <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="بحث بالرقم المرجعي، المواصفات، الموقع، أو اسم المستلم..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-9 pl-3 py-2 text-slate-200"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200"
          >
            <option value="all">كافة التصنيفات</option>
            <option value="electronics">إلكترونيات وهواتف</option>
            <option value="money">مبالغ نقدية</option>
            <option value="documents">وثائق وبطائق شخصية</option>
            <option value="jewelry_watch">ساعات ومصوغات</option>
            <option value="luggage">حقائب وأمتعة</option>
            <option value="other">أخرى</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200"
          >
            <option value="all">كافة الحالات</option>
            <option value="safekeeping">في الحفظ والأمانات</option>
            <option value="returned_to_owner">سُلّمت للمالك الشرعي</option>
          </select>
        </div>
      </div>

      {/* Items Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-950 border-b border-slate-800 text-slate-400 font-bold">
              <tr>
                <th className="p-3.5">الرقم المرجعي والتصنيف</th>
                <th className="p-3.5">وصف ومواصفات الأمانة</th>
                <th className="p-3.5">مكان وتاريخ العثور</th>
                <th className="p-3.5">الشخص العاثر وموقع الحفظ</th>
                <th className="p-3.5 text-center">الحالة</th>
                <th className="p-3.5">بيانات الاستلام والتسليم</th>
                <th className="p-3.5 text-center">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-400">
                    لا توجد أمانات مطابقة لمعايير البحث
                  </td>
                </tr>
              ) : (
                filtered.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-800/30 transition">
                    <td className="p-3.5">
                      <span className="font-mono font-bold text-indigo-400 bg-indigo-950 px-2 py-0.5 rounded-lg border border-indigo-800">
                        {item.itemReference}
                      </span>
                      <div className="mt-1.5">{getCategoryBadge(item.itemCategory)}</div>
                    </td>
                    <td className="p-3.5">
                      <div className="font-bold text-slate-100">{item.description}</div>
                      <div className="text-[11px] text-slate-400 mt-0.5 line-clamp-2">{item.notes}</div>
                    </td>
                    <td className="p-3.5">
                      <div className="text-slate-200">{item.foundLocation}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{item.foundDate}</div>
                    </td>
                    <td className="p-3.5">
                      <div className="text-slate-300 font-semibold">{item.finderName}</div>
                      <div className="text-[10px] text-indigo-300">{item.custodyLocation}</div>
                    </td>
                    <td className="p-3.5 text-center">
                      <span className={`px-2.5 py-1 rounded-xl text-[10px] font-bold ${
                        item.status === 'returned_to_owner'
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                          : 'bg-amber-950 text-amber-300 border border-amber-800'
                      }`}>
                        {item.status === 'returned_to_owner' ? '✓ سُلّمت لصاحبها' : 'محتفظ بها بالخزنة'}
                      </span>
                    </td>
                    <td className="p-3.5">
                      {item.status === 'returned_to_owner' ? (
                        <div>
                          <div className="font-bold text-emerald-400">{item.claimedByName}</div>
                          <div className="text-[10px] text-slate-400 font-mono">هوية: {item.claimedByIdNumber}</div>
                          <div className="text-[10px] text-slate-500">مسؤول التسليم: {item.securityOfficerHandover}</div>
                        </div>
                      ) : (
                        <span className="text-slate-500 text-[11px]">في الانتظار بمكتب الأمن</span>
                      )}
                    </td>
                    <td className="p-3.5 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        {item.status === 'safekeeping' && (
                          <button
                            type="button"
                            onClick={() => setSelectedHandoverItem(item)}
                            className="px-2.5 py-1 rounded-lg bg-indigo-950 hover:bg-indigo-900 text-indigo-300 border border-indigo-800 text-[10px] font-bold transition flex items-center gap-1"
                            title="تسليم الأمانة لصاحبها"
                          >
                            <ArrowRightCircle className="w-3 h-3" />
                            <span>تسليم</span>
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => handleDelete(item.id)}
                          className="p-1.5 rounded-lg bg-slate-800 text-rose-400 hover:bg-rose-950 hover:text-rose-300 transition"
                          title="حذف"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Handover Modal */}
      {selectedHandoverItem && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-indigo-600/60 rounded-3xl w-full max-w-md overflow-hidden shadow-2xl flex flex-col">
            <div className="bg-slate-950 px-5 py-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-indigo-950 text-indigo-400 border border-indigo-800">
                  <UserCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-100">
                    محضر تسليم أمانة للمالك الشرعي
                  </h3>
                  <p className="text-[11px] text-slate-400">مرجع: {selectedHandoverItem.itemReference}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedHandoverItem(null)}
                className="p-1 rounded-lg bg-slate-800 text-slate-400 hover:text-slate-100"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleHandoverSubmit} className="p-5 space-y-3 text-xs">
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
                <span className="text-slate-400">الأمانة المسلّمة:</span>
                <div className="font-bold text-slate-100 mt-1">{selectedHandoverItem.description}</div>
              </div>

              <div>
                <label className="text-slate-300 block mb-1 font-semibold">اسم المستلم الرباعي:</label>
                <input
                  type="text"
                  required
                  placeholder="الاسم مطابقاً للبطاقة الشخصية..."
                  value={claimedByName}
                  onChange={(e) => setClaimedByName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                />
              </div>

              <div>
                <label className="text-slate-300 block mb-1 font-semibold">رقم البطاقة الشخصية / إثبات الهوية:</label>
                <input
                  type="text"
                  required
                  placeholder="الرقم الوطني / جواز السفر..."
                  value={claimedByIdNumber}
                  onChange={(e) => setClaimedByIdNumber(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100 font-mono"
                />
              </div>

              <div>
                <label className="text-slate-300 block mb-1 font-semibold">رقم هاتف المستلم للتواصل:</label>
                <input
                  type="tel"
                  placeholder="77XXXXXXX"
                  value={claimedByPhone}
                  onChange={(e) => setClaimedByPhone(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100 font-mono"
                />
              </div>

              <div className="p-3 rounded-2xl bg-indigo-950/40 border border-indigo-900/60 text-[11px] text-slate-300">
                يقر المستلم باستلامه الأمانة المذكورة أعلاه بحالتها السليمة، ويعتبر هذا السند إخلاء لطرف إدارة أمن المستشفى.
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setSelectedHandoverItem(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 text-xs"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>تأكيد التسليم وتوقيع المحضر</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* New Item Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-indigo-600/60 rounded-3xl w-full max-w-xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
            <div className="bg-slate-950 px-5 py-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-indigo-950 text-indigo-400 border border-indigo-800">
                  <Package className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-100">
                    تسجيل أمانة جديدة في سجل المفقودات
                  </h3>
                  <p className="text-[11px] text-slate-400">مستشفى آزال النموذجي • أمن المستشفى والأمانات</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="p-1 rounded-lg bg-slate-800 text-slate-400 hover:text-slate-100"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateItem} className="p-5 space-y-3.5 overflow-y-auto text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">تصنيف الأمانة:</label>
                  <select
                    value={itemCategory}
                    onChange={(e) => setItemCategory(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                  >
                    <option value="electronics">📱 أجهزة إلكترونية وهواتف ذكية</option>
                    <option value="money">💵 مبالغ مالية ونقود</option>
                    <option value="documents">📄 وثائق وهويات رسمية</option>
                    <option value="jewelry_watch">⌚ ساعات ومجوهرات ثمينة</option>
                    <option value="luggage">🎒 حقائب وأمتعة شخصية</option>
                    <option value="other">📦 أخرى</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">مكان العثور داخل المستشفى:</label>
                  <select
                    value={foundLocation}
                    onChange={(e) => setFoundLocation(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                  >
                    {AZAL_HOSPITAL_LOCATIONS.map((loc, idx) => (
                      <option key={idx} value={loc}>{loc}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="text-slate-300 block mb-1 font-semibold">وصف ومواصفات الأمانة بالتفصيل:</label>
                <input
                  type="text"
                  required
                  placeholder="اللون، الماركة، أي علامات مميزة..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">اسم الشخص الذي عثر عليها وصفتها:</label>
                  <input
                    type="text"
                    required
                    placeholder="فلان بن فلان (تمريض / زائر / أمن)..."
                    value={finderName}
                    onChange={(e) => setFinderName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                  />
                </div>
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">مكان الحفظ والأمانات:</label>
                  <input
                    type="text"
                    value={custodyLocation}
                    onChange={(e) => setCustodyLocation(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 block mb-1 font-semibold">ملاحظات إضافية:</label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="أي متعلقات أخرى، حالة الشيء عند الاستلام..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 text-xs"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>حفظ وإيداع الأمانة</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      </>
      )}
    </div>
  );
};
