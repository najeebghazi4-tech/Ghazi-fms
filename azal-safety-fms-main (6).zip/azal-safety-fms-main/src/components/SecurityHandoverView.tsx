import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Radio, 
  Key, 
  Video, 
  DoorClosed, 
  CheckCircle2, 
  Lock, 
  UserCheck, 
  FileCheck, 
  Clock, 
  Printer, 
  AlertCircle 
} from 'lucide-react';
import { SecurityShiftHandover, StaffUser } from '../types';
import { AzalLogo } from './AzalLogo';
import { VoiceDictationButton } from './VoiceDictationButton';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';
import { executeSmartPrint } from '../utils/printUtils';

interface SecurityHandoverViewProps {
  handovers: SecurityShiftHandover[];
  currentUser: StaffUser;
  onSaveHandover: (newHandover: SecurityShiftHandover) => void;
  onLogAudit: (action: string, actionAr: string, details: string) => void;
}

export const SecurityHandoverView: React.FC<SecurityHandoverViewProps> = ({
  handovers,
  currentUser,
  onSaveHandover,
  onLogAudit,
}) => {
  const [shiftType, setShiftType] = useState<'morning' | 'evening' | 'night'>('morning');
  const [incomingGuard, setIncomingGuard] = useState('مشرف الأمن / منصور الحيمي');
  const [outgoingGuard, setOutgoingGuard] = useState(currentUser.name);
  const [radiosCount, setRadiosCount] = useState(8);
  const [keysChecked, setKeysChecked] = useState(true);
  const [cctvChecked, setCctvChecked] = useState(true);
  const [gatesSecured, setGatesSecured] = useState(true);
  const [specialNotes, setSpecialNotes] = useState('');
  const [securityPin, setSecurityPin] = useState('');
  const [pinError, setPinError] = useState('');
  const [isSignedSuccess, setIsSignedSuccess] = useState(false);

  const handleSubmitHandover = (e: React.FormEvent) => {
    e.preventDefault();
    if (securityPin.length < 4) {
      setPinError('يرجى إدخال رمز PIN الأمني المكون من 4 أرقام لتأكيد الاستلام');
      return;
    }
    setPinError('');

    const newHandover: SecurityShiftHandover = {
      id: `sec-handover-${Date.now()}`,
      shiftDate: new Date().toISOString().split('T')[0],
      shiftType,
      outgoingGuardName: outgoingGuard,
      incomingGuardName: incomingGuard,
      walkieTalkiesOperational: radiosCount,
      emergencyMasterKeysPresent: keysChecked,
      cctvAllActive: cctvChecked,
      hospitalGatesSecured: gatesSecured,
      activeIncidentsCount: 0,
      specialInstructions: specialNotes.trim() || 'تم تدقيق كافة المنافذ والبوابات ولا توجد خروقات أمنية.',
      verificationHash: `AZAL-SEC-${Math.random().toString(36).substring(2, 8).toUpperCase()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`,
      signedAt: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
    };

    onSaveHandover(newHandover);
    setIsSignedSuccess(true);
    setSecurityPin('');
    setTimeout(() => setIsSignedSuccess(false), 4000);

    // Audio and haptic feedback
    triggerSuccessFeedback();

    onLogAudit(
      'SECURITY_SHIFT_HANDOVER_SIGNED',
      'توقيع محضر تسليم وردية أمن مستشفى أزال',
      `تم تسليم الوردية (${shiftType === 'morning' ? 'صباحية' : shiftType === 'evening' ? 'مسائية' : 'ليلية'}) بين ${outgoingGuard} و ${incomingGuard} ببصمة مشفرة: ${newHandover.verificationHash}.`
    );
  };

  const handlePrint = () => {
    const tableRows = handovers.map((h, idx) => {
      const shiftAr = h.shiftType === 'morning' ? 'صباحية' : h.shiftType === 'evening' ? 'مسائية' : 'ليلية';
      return `
        <tr>
          <td style="font-weight:bold;">${idx + 1}</td>
          <td>${h.shiftDate}</td>
          <td><strong>الوردية ${shiftAr}</strong></td>
          <td>${h.outgoingGuardName}</td>
          <td>${h.incomingGuardName}</td>
          <td>${h.walkieTalkiesOperational} أجهزة</td>
          <td>${h.emergencyMasterKeysPresent ? 'مكتملة ✔' : 'ناقصة ✖'}</td>
          <td>${h.cctvAllActive ? 'تعمل بنسبة 100% ✔' : 'تعطل جزئي ⚠'}</td>
          <td>${h.hospitalGatesSecured ? 'مؤمنة بالكامل ✔' : 'ملاحظات'}</td>
          <td style="font-family:monospace; font-size:10px;">${h.verificationHash}</td>
          <td>${h.specialInstructions || '-'}</td>
        </tr>
      `;
    }).join('');

    const bodyHtml = `
      <div class="summary-grid">
        <div class="summary-card"><div class="val">${handovers.length}</div><div class="lbl">إجمالي محاضر التسليم الموثقة</div></div>
        <div class="summary-card"><div class="val" style="color:#047857;">100%</div><div class="lbl">جاهزية المنافذ والأجهزة</div></div>
        <div class="summary-card"><div class="val" style="color:#0284c7;">مشفر</div><div class="lbl">بصمات أمنية رقمية معتمدة</div></div>
      </div>
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>تاريخ الوردية</th>
            <th>نوع الوردية</th>
            <th>المُسَلِّم (الوردية المنتهية)</th>
            <th>المُسْتَلِم (الوردية القادمة)</th>
            <th>أجهزة اللاسلكي</th>
            <th>مفاتيح الطوارئ</th>
            <th>كاميرات CCTV</th>
            <th>حالة البوابات</th>
            <th>كود البصمة الرقمية</th>
            <th>التعليمات الخاصة</th>
          </tr>
        </thead>
        <tbody>
          ${tableRows || '<tr><td colspan="11" style="text-align:center; padding:12px;">لا توجد محاضر تسليم مسجلة</td></tr>'}
        </tbody>
      </table>
    `;

    executeSmartPrint(bodyHtml, {
      title: 'محضر تسليم واستلام نوبات الحراسة والأمن الميداني',
      subtitle: 'مستشفى آزال النموذجي • إدارة الأمن والسلامة وإدارة المرافق FMS • غرفة العمليات والمراقبة',
      refNumber: 'AZAL-SEC-HANDOVER-2026'
    });
  };

  return (
    <div id="security-handover-view" className="space-y-4 pb-20 text-right">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-teal-950 border border-teal-800/50 rounded-2xl p-4 shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-950/80 border border-teal-800 text-teal-400">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-100">
              تسليم واستلام ورديات أمن مستشفى أزال النموذجي
            </h2>
            <p className="text-xs text-slate-400">
              توثيق استلام العهد الأمنية: أجهزة اللاسلكي، مفاتيح الطوارئ، وشاشات المراقبة المركزية
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handlePrint}
          className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold flex items-center gap-1.5 transition self-start sm:self-auto"
        >
          <Printer className="w-4 h-4" />
          <span>طباعة المحضر الرسمي (Print / PDF)</span>
        </button>
      </div>

      {isSignedSuccess && (
        <div className="p-3 bg-emerald-950/90 border border-emerald-600 rounded-2xl text-emerald-200 text-xs flex items-center gap-2 animate-bounce">
          <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          <span>تم اعتماد وتوقيع محضر تسليم وردية الأمن بنجاح وإصدار البصمة المشفرة!</span>
        </div>
      )}

      {/* Handover Form */}
      <form onSubmit={handleSubmitHandover} className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-4 text-xs">
        <h3 className="text-sm font-bold text-teal-400 border-b border-slate-800 pb-2 flex items-center gap-2">
          <FileCheck className="w-4 h-4" />
          <span>بيانات محضر التسليم الحالي (الوردية الجارية)</span>
        </h3>

        {/* Shift and Guard Names */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="text-slate-300 block mb-1 font-semibold">فترة الوردية:</label>
            <select
              value={shiftType}
              onChange={(e) => setShiftType(e.target.value as any)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
            >
              <option value="morning">الوردية الصباحية (07:00 ص - 03:00 م)</option>
              <option value="evening">الوردية المسائية (03:00 م - 11:00 م)</option>
              <option value="night">الوردية الليلية (11:00 م - 07:00 ص)</option>
            </select>
          </div>

          <div>
            <label className="text-slate-300 block mb-1 font-semibold">مشرف الأمن المُسلِّم (الخارج):</label>
            <input
              type="text"
              value={outgoingGuard}
              onChange={(e) => setOutgoingGuard(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
            />
          </div>

          <div>
            <label className="text-slate-300 block mb-1 font-semibold">مشرف الأمن المُستلِم (القادم):</label>
            <input
              type="text"
              value={incomingGuard}
              onChange={(e) => setIncomingGuard(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
            />
          </div>
        </div>

        {/* Asset Checklist Checklist */}
        <div className="space-y-2 pt-2 border-t border-slate-800">
          <span className="font-bold text-slate-300 block">تدقيق العهد والمعدات الأمنية:</span>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {/* Walkie Talkies */}
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Radio className="w-4 h-4 text-teal-400" />
                <span className="text-slate-200">أجهزة اللاسلكي المشحونة والشغالة:</span>
              </div>
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min="0"
                  max="20"
                  value={radiosCount}
                  onChange={(e) => setRadiosCount(Number(e.target.value))}
                  className="w-14 bg-slate-900 border border-slate-700 rounded-lg p-1 text-center text-slate-100 font-mono font-bold"
                />
                <span className="text-slate-400 text-[10px]">أجهزة</span>
              </div>
            </div>

            {/* Master Keys */}
            <label className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center justify-between cursor-pointer hover:bg-slate-950/80">
              <div className="flex items-center gap-2">
                <Key className="w-4 h-4 text-amber-400" />
                <span className="text-slate-200">حزم مفاتيح الطوارئ الرئيسية (Master Keys):</span>
              </div>
              <input
                type="checkbox"
                checked={keysChecked}
                onChange={(e) => setKeysChecked(e.target.checked)}
                className="w-4 h-4 accent-teal-600 rounded"
              />
            </label>

            {/* CCTV System */}
            <label className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center justify-between cursor-pointer hover:bg-slate-950/80">
              <div className="flex items-center gap-2">
                <Video className="w-4 h-4 text-sky-400" />
                <span className="text-slate-200">كاميرات المراقبة وغرفة التحكم (CCTV):</span>
              </div>
              <input
                type="checkbox"
                checked={cctvChecked}
                onChange={(e) => setCctvChecked(e.target.checked)}
                className="w-4 h-4 accent-teal-600 rounded"
              />
            </label>

            {/* Hospital Gates */}
            <label className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center justify-between cursor-pointer hover:bg-slate-950/80">
              <div className="flex items-center gap-2">
                <DoorClosed className="w-4 h-4 text-emerald-400" />
                <span className="text-slate-200">بوابات المستشفى الرئيسية ومسارات الإسعاف مؤمنة:</span>
              </div>
              <input
                type="checkbox"
                checked={gatesSecured}
                onChange={(e) => setGatesSecured(e.target.checked)}
                className="w-4 h-4 accent-teal-600 rounded"
              />
            </label>
          </div>
        </div>

        {/* Special Instructions */}
        <div>
          <div className="flex items-center justify-between mb-1">
            <label className="text-slate-300 font-semibold">ملاحظات وتعليمات خاصة للوردية القادمة:</label>
            <VoiceDictationButton
              value={specialNotes}
              onChange={setSpecialNotes}
              showLabel
              title="إملاء صوتي لتعليمات الوردية"
            />
          </div>
          <textarea
            rows={2}
            placeholder="مثال: تشديد الرقابة على بوابة الإسعاف، مراقبة وفد الزوار في الدور الثالث... (يمكنك الإملاء بالصوت)"
            value={specialNotes}
            onChange={(e) => setSpecialNotes(e.target.value)}
            className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 placeholder-slate-500 text-xs focus:outline-none focus:border-teal-500"
          />
        </div>

        {/* Electronic PIN Sign-off */}
        <div className="bg-slate-950 p-3.5 rounded-xl border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <span className="font-bold text-amber-300 block flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5" />
              <span>التوقيع الإلكتروني لمشرف الأمن (PIN Verification):</span>
            </span>
            <span className="text-[11px] text-slate-400">
              أدخل رمز PIN الخاص بك لإصدار الختم الرقمي المشفر لمحضر التسليم
            </span>
            {pinError && <p className="text-rose-400 text-[11px] mt-1">{pinError}</p>}
          </div>

          <div className="flex items-center gap-2">
            <input
              type="password"
              maxLength={4}
              placeholder="رمز PIN (4 أرقام)"
              value={securityPin}
              onChange={(e) => setSecurityPin(e.target.value)}
              className="w-32 bg-slate-900 border border-slate-700 rounded-xl p-2 text-center text-slate-100 font-mono tracking-widest text-xs"
            />
            <button
              type="submit"
              className="px-4 py-2 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-bold rounded-xl text-xs shadow-lg shadow-teal-950 flex items-center gap-1.5 transition"
            >
              <UserCheck className="w-4 h-4" />
              <span>اعتماد وتوقيع المحضر</span>
            </button>
          </div>
        </div>
      </form>

      {/* History of Signed Handovers */}
      <div className="space-y-3 pt-2">
        <h3 className="text-xs font-bold text-slate-400 flex items-center gap-1.5">
          <Clock className="w-3.5 h-3.5 text-teal-400" />
          <span>سجل محاضر تسليم ورديات الأمن السابقة:</span>
        </h3>

        {handovers.map((h) => (
          <div
            key={h.id}
            className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-xs space-y-2 shadow-sm"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded font-bold bg-teal-950 text-teal-300 border border-teal-800 text-[10px]">
                  {h.shiftType === 'morning' ? 'وردية صباحية' : h.shiftType === 'evening' ? 'وردية مسائية' : 'وردية ليلية'}
                </span>
                <span className="font-bold text-slate-200">{h.shiftDate} ({h.signedAt})</span>
              </div>
              <span className="font-mono text-[10px] text-amber-400 bg-black/50 px-2 py-0.5 rounded border border-amber-900/50">
                {h.verificationHash}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-300 text-[11px]">
              <div>المُسلِّم: <strong>{h.outgoingGuardName}</strong></div>
              <div>المُستلِم: <strong>{h.incomingGuardName}</strong></div>
            </div>

            <p className="text-slate-400 text-[11px]">
              <strong>التعليمات:</strong> {h.specialInstructions}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};
