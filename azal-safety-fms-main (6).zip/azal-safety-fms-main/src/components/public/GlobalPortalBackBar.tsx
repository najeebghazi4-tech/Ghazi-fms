import React from 'react';
import { ArrowRight, Building2, Home } from 'lucide-react';
import { AzalLogo } from '../AzalLogo';

export interface GlobalPortalBackBarProps {
  title?: string;
  subtitle?: string;
  category?: string;
  onCustomBack?: () => void;
  showServicesLink?: boolean;
  isHubPage?: boolean;
  actions?: React.ReactNode;
}

export const navigatePortalBack = (customBack?: () => void, isHubPage: boolean = false) => {
  if (customBack) {
    customBack();
    return;
  }

  if (typeof window === 'undefined') return;

  const currentHash = (window.location.hash || '').toLowerCase();

  // If we are currently on the services hub itself:
  if (isHubPage || currentHash === '#services' || currentHash === '#/services') {
    if (window.history.length > 1) {
      window.history.back();
      // Safety timeout: if after 200ms the hash is still services, clear hash to lock screen
      setTimeout(() => {
        if ((window.location.hash || '').toLowerCase().includes('services')) {
          window.location.hash = '';
        }
      }, 200);
    } else {
      window.location.hash = '';
    }
    return;
  }

  // If we are on a subpage (#report, #statement, #contractor, #permit, #incinerator, #new-hires, #training-nomination, #pm, etc.):
  const initialHash = window.location.hash;
  if (window.history.length > 1) {
    window.history.back();
    // Safety fallback: if after 220ms the user is still on the same hash (e.g. direct external entry),
    // fallback gracefully to the services hub
    setTimeout(() => {
      if (window.location.hash === initialHash) {
        window.location.hash = '#services';
      }
    }, 220);
  } else {
    window.location.hash = '#services';
  }
};

export const GlobalPortalBackBar: React.FC<GlobalPortalBackBarProps> = ({
  title,
  subtitle,
  category = 'مستشفى آزال • الرعاية الكاملة • إدارة السلامة FMS',
  onCustomBack,
  showServicesLink = true,
  isHubPage = false,
  actions,
}) => {
  return (
    <nav 
      aria-label="شريط التنقل والرجوع العام"
      className="sticky top-0 z-50 w-full backdrop-blur-md bg-slate-950/95 border-b border-slate-800 shadow-md transition-all select-none" 
      dir="rtl"
    >
      <div className="max-w-6xl w-full mx-auto px-3 sm:px-5 py-2.5 flex items-center justify-between gap-2.5">
        
        {/* Right Side: Back/Exit Primary Button & Services Link */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => navigatePortalBack(onCustomBack, isHubPage)}
            className="group px-3 py-1.5 sm:px-4 sm:py-2 rounded-xl bg-slate-900 hover:bg-slate-800 active:bg-slate-750 text-slate-100 border border-slate-700 hover:border-amber-500/70 font-black text-xs sm:text-sm flex items-center gap-1.5 transition-all duration-150 active:scale-95 shadow-sm cursor-pointer"
            title={isHubPage ? 'خروج / العودة للشاشة الرئيسية' : 'الرجوع للصفحة السابقة أو بوابة الخدمات'}
          >
            <span className="text-amber-400 group-hover:-translate-x-0.5 transition font-mono font-bold text-sm">←</span>
            <span>رجوع / خروج</span>
          </button>

          {!isHubPage && showServicesLink && (
            <a
              href="#services"
              className="hidden xs:inline-flex items-center gap-1.5 px-3 py-1.5 sm:py-2 rounded-xl bg-teal-950/70 hover:bg-teal-900 border border-teal-800/80 text-teal-300 text-xs font-bold transition shadow-sm"
              title="الانتقال المباشر لبوابة الخدمات والتصاريح الموحدة"
            >
              <Building2 className="w-3.5 h-3.5 text-teal-400 shrink-0" />
              <span className="hidden sm:inline">بوابة الخدمات</span>
            </a>
          )}
        </div>

        {/* Center / Left Side: Page Title and Logo */}
        <div className="flex items-center gap-2 sm:gap-3 min-w-0 text-left sm:text-right">
          <div className="flex flex-col min-w-0">
            {title ? (
              <>
                <h1 className="text-xs sm:text-sm font-black text-slate-100 truncate">
                  {title}
                </h1>
                <span className="text-[10px] text-slate-400 truncate hidden xs:block">
                  {subtitle || category}
                </span>
              </>
            ) : (
              <span className="text-xs font-bold text-slate-300 truncate">
                {category}
              </span>
            )}
          </div>

          <div className="p-1 bg-white rounded-xl shadow-sm border border-slate-200 shrink-0 hidden sm:block">
            <AzalLogo size="xs" showText={false} />
          </div>

          {actions && (
            <div className="flex items-center gap-1.5 shrink-0 pr-1 border-r border-slate-800 mr-1">
              {actions}
            </div>
          )}
        </div>

      </div>
    </nav>
  );
};
