import React, { useState, useEffect } from 'react';
import { 
  Wind, 
  Gauge, 
  Activity, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  ArrowLeft, 
  ShieldCheck, 
  Printer, 
  RefreshCw, 
  Send, 
  Sparkles, 
  Building2, 
  Check, 
  Share2, 
  Info,
  Clock,
  Sliders,
  FileText,
  DoorClosed,
  Fan
} from 'lucide-react';
import { collection, addDoc, getDocs, query, orderBy, limit } from 'firebase/firestore';
import { db } from '../../services/firebase';
import { NegativePressureLog } from '../../types';
import { INITIAL_NEGATIVE_PRESSURE_ROOMS, INITIAL_NEGATIVE_PRESSURE_LOGS } from '../../data/azalNegativePressureData';
import { GlobalPortalBackBar } from './GlobalPortalBackBar';
import { AzalLogo } from '../AzalLogo';
import { executeSmartPrint } from '../../utils/printUtils';
import { triggerSuccessFeedback } from '../../utils/feedbackUtils';

interface NegativePressurePortalProps {
  onBackToHub?: () => void;
  onLogAudit?: (action: string, actionAr: string, details: string) => void;
}

export const NegativePressurePortal: React.FC<NegativePressurePortalProps> = ({
  onBackToHub,
  onLogAudit
}) => {
  const [logs, setLogs] = useState<NegativePressureLog[]>([]);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submittedSuccess, setSubmittedSuccess] = useState(false);
  const [activeTab, setActiveTab] = useState<'inspect' | 'history'>('inspect');

  // Form Fields
  const [selectedRoomCode, setSelectedRoomCode] = useState(INITIAL_NEGATIVE_PRESSURE_ROOMS[0].roomCode);
  const [pressureValuePa, setPressureValuePa] = useState<number>(-5.0);
  const [pressureUnit, setPressureUnit] = useState<'Pa' | 'in_wg'>('Pa');
  const [smokeTestResult, setSmokeTestResult] = useState<'pass_inward' | 'fail_outward' | 'fail_stagnant'>('pass_inward');
  const [doorSweepSealIntact, setDoorSweepSealIntact] = useState(true);
  const [anteroomDoorClosed, setAnteroomDoorClosed] = useState(true);
  const [exhaustFanOperational, setExhaustFanOperational] = useState(true);
  const [hepaFilterDifferentialOk, setHepaFilterDifferentialOk] = useState(true);
  const [airChangesPerHour, setAirChangesPerHour] = useState<number>(14);
  const [inspectorName, setInspectorName] = useState('م/ نجيب غازي');
  const [inspectorRole, setInspectorRole] = useState('رئيس قسم السلامة وإدارة المرافق FMS');
  const [inspectorBadgeNumber, setInspectorBadgeNumber] = useState('AZAL-FMS-01');
  const [correctiveAction, setCorrectiveAction] = useState('');

  const selectedRoom = INITIAL_NEGATIVE_PRESSURE_ROOMS.find(r => r.roomCode === selectedRoomCode) || INITIAL_NEGATIVE_PRESSURE_ROOMS[0];

  // Calculated Compliance Status
  const isPressureNegative = pressureUnit === 'Pa' ? pressureValuePa <= -2.5 : pressureValuePa <= -0.01;
  const isSmokePass = smokeTestResult === 'pass_inward';
  const isAllMechanicalPass = doorSweepSealIntact && anteroomDoorClosed && exhaustFanOperational && hepaFilterDifferentialOk;
  
  const overallStatus: 'compliant' | 'warning' | 'failed' = 
    (isPressureNegative && isSmokePass && isAllMechanicalPass) ? 'compliant' :
    (!isPressureNegative || smokeTestResult === 'fail_outward' || !exhaustFanOperational) ? 'failed' : 'warning';

  useEffect(() => {
    loadInspectionLogs();
  }, []);

  const loadInspectionLogs = async () => {
    setLoading(true);
    try {
      // 1. Try local storage first for instant load
      let cached: NegativePressureLog[] = [];
      try {
        const local = localStorage.getItem('azal_negative_pressure_logs_v1');
        if (local) {
          cached = JSON.parse(local);
        }
      } catch (e) {
        console.warn('Failed to read negative pressure logs from localStorage', e);
      }

      // 2. Fetch from Firestore (negative_pressure_logs)
      try {
        const q = query(collection(db, 'negative_pressure_logs'), orderBy('createdAt', 'desc'), limit(50));
        const snap = await getDocs(q);
        if (!snap.empty) {
          const remoteLogs: NegativePressureLog[] = snap.docs.map(doc => ({
            id: doc.id,
            ...(doc.data() as Omit<NegativePressureLog, 'id'>)
          }));
          setLogs(remoteLogs);
          localStorage.setItem('azal_negative_pressure_logs_v1', JSON.stringify(remoteLogs));
          setLoading(false);
          return;
        }
      } catch (err) {
        console.warn('[Firestore] Fetching negative_pressure_logs failed, using cached/initial:', err);
      }

      // 3. Fallback to cached or initial demo logs
      if (cached && cached.length > 0) {
        setLogs(cached);
      } else {
        setLogs(INITIAL_NEGATIVE_PRESSURE_LOGS);
        localStorage.setItem('azal_negative_pressure_logs_v1', JSON.stringify(INITIAL_NEGATIVE_PRESSURE_LOGS));
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);

    const now = new Date();
    const newLog: NegativePressureLog = {
      id: `npl-${Date.now()}`,
      roomCode: selectedRoom.roomCode,
      roomName: selectedRoom.roomName,
      department: selectedRoom.department,
      floor: selectedRoom.floor,
      inspectionDate: now.toISOString().split('T')[0],
      inspectionTime: now.toTimeString().split(' ')[0].substring(0, 5),
      pressureValuePa: Number(pressureValuePa),
      pressureUnit,
      gaugeReadingStatus: pressureValuePa <= -2.5 ? 'normal_negative' : pressureValuePa < 0 ? 'critical_low' : 'positive_leakage',
      smokeTestResult,
      doorSweepSealIntact,
      anteroomDoorClosed,
      exhaustFanOperational,
      hepaFilterDifferentialOk,
      airChangesPerHour: Number(airChangesPerHour),
      overallStatus,
      inspectorName: inspectorName.trim() || 'م/ نجيب غازي',
      inspectorRole: inspectorRole.trim() || 'رئيس قسم السلامة OSH/FMS',
      inspectorBadgeNumber: inspectorBadgeNumber.trim() || 'AZAL-FMS-01',
      correctiveAction: correctiveAction.trim() || (overallStatus === 'compliant' ? 'الضغط سلبي مطابق ومعايير العزل فعالة.' : 'يجب إجراء معايرة لمروحة الطرد وصيانة عوازل الباب فوراً.'),
      createdAt: Date.now(),
      synced: true
    };

    // Update local state and storage
    const updated = [newLog, ...logs];
    setLogs(updated);
    try {
      localStorage.setItem('azal_negative_pressure_logs_v1', JSON.stringify(updated));
    } catch (e) {
      console.warn('Failed saving to localStorage', e);
    }

    // Persist to Cloud Firestore table 'negative_pressure_logs'
    try {
      await addDoc(collection(db, 'negative_pressure_logs'), newLog);
    } catch (err) {
      console.warn('[Firestore] Direct write to negative_pressure_logs warning:', err);
    }

    triggerSuccessFeedback();
    if (onLogAudit) {
      onLogAudit(
        'SMOKE_TEST_RECORDED',
        'توثيق اختبار شريط الدخان وغرف العزل',
        `تم تسجيل فحص (${newLog.roomName}) - القراءة: ${newLog.pressureValuePa} Pa - الحالة: ${newLog.overallStatus === 'compliant' ? 'مطابق' : 'غير مطابق'}`
      );
    }

    setSubmitting(false);
    setSubmittedSuccess(true);
    setTimeout(() => setSubmittedSuccess(false), 3500);

    // Reset notes
    setCorrectiveAction('');
  };

  const handlePrintReport = (log?: NegativePressureLog) => {
    const targetLogs = log ? [log] : logs;
    const tableRows = targetLogs.map((item, idx) => {
      const statusBadge = item.overallStatus === 'compliant'
        ? '<span class="badge-success">مطابق للضغط السلبي ✔</span>'
        : item.overallStatus === 'warning'
        ? '<span class="badge-warning">حرج / يحتاج متابعة ⚠</span>'
        : '<span class="badge-danger">غير مطابق / خطر تسرب ✖</span>';

      const smokeBadge = item.smokeTestResult === 'pass_inward'
        ? '<span style="color:#047857; font-weight:bold;">سليم للداخل ⇚</span>'
        : item.smokeTestResult === 'fail_outward'
        ? '<span style="color:#b91c1c; font-weight:bold;">للخارج (تسرب) ⇛</span>'
        : '<span style="color:#b45309; font-weight:bold;">ركود / تعادل ⏸</span>';

      return `
        <tr>
          <td style="font-weight:bold;">${idx + 1}</td>
          <td style="font-family:monospace; font-weight:bold;">${item.roomCode}</td>
          <td><strong>${item.roomName}</strong><br><small style="color:#64748b;">${item.department} - ${item.floor}</small></td>
          <td style="direction:ltr; font-family:monospace; font-weight:bold; color:#0284c7;">${item.pressureValuePa} ${item.pressureUnit}</td>
          <td>${smokeBadge}</td>
          <td>${item.airChangesPerHour ? `${item.airChangesPerHour} ACH` : '-'}</td>
          <td>${item.exhaustFanOperational ? 'تعمل بانتظام ✔' : 'متوقفة ✖'}</td>
          <td>${item.doorSweepSealIntact ? 'محكمة ✔' : 'تالفة ✖'}</td>
          <td>${statusBadge}</td>
          <td>${item.inspectionDate} ${item.inspectionTime}</td>
          <td>${item.inspectorName}<br><small style="color:#64748b;">${item.inspectorRole}</small></td>
          <td>${item.correctiveAction || '-'}</td>
        </tr>
      `;
    }).join('');

    const bodyHtml = `
      <div class="summary-grid">
        <div class="summary-card">
          <div class="val">${targetLogs.length}</div>
          <div class="lbl">إجمالي فحوصات غرف العزل الموثقة</div>
        </div>
        <div class="summary-card">
          <div class="val" style="color:#047857;">${targetLogs.filter(l => l.overallStatus === 'compliant').length}</div>
          <div class="lbl">غرف مطابقة للضغط السلبي والتدفق</div>
        </div>
        <div class="summary-card">
          <div class="val" style="color:#b91c1c;">${targetLogs.filter(l => l.overallStatus === 'failed').length}</div>
          <div class="lbl">غرف غير مطابقة / تحت الإجراء العاجل</div>
        </div>
      </div>
      <table style="font-size:11px;">
        <thead>
          <tr>
            <th>#</th>
            <th>كود الغرفة</th>
            <th>اسم غرفة العزل والموقع</th>
            <th>فرق الضغط المقاس</th>
            <th>شريط الدخان (Smoke Test)</th>
            <th>تغيير الهواء (ACH)</th>
            <th>مروحة الطرد</th>
            <th>عوازل الباب</th>
            <th>الحالة الإجمالية</th>
            <th>التاريخ والوقت</th>
            <th>المفتش المعتمد</th>
            <th>الإجراء التصحيحي / الملاحظات</th>
          </tr>
        </thead>
        <tbody>
          ${tableRows || '<tr><td colspan="12" style="text-align:center;">لا توجد سجلات فحص</td></tr>'}
        </tbody>
      </table>
    `;

    executeSmartPrint(bodyHtml, {
      title: 'محضر فحص غرف العزل الجوي واختبار شريط الدخان (Smoke Trail & Negative Pressure Test)',
      subtitle: 'مستشفى آزال • الرعاية الكاملة • إدارة السلامة FMS وإدارة مكافحة العدوى IPC • معايير سباهي FMS.10 & PCI.8',
      refNumber: `AZAL-AIIR-SMOKE-${new Date().getFullYear()}`
    });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans antialiased flex flex-col select-none overflow-x-hidden" dir="rtl">
      {/* Sticky Universal Back Bar */}
      <GlobalPortalBackBar
        title="وحدة سلامة غرف العزل بالضغط السلبي (Negative Pressure & Smoke Test)"
        subtitle="مستشفى آزال • الرعاية الكاملة • معايير سباهي FMS.10 & IPC ومكافحة العدوى"
        showServicesLink={true}
        onCustomBack={() => {
          if (onBackToHub) {
            onBackToHub();
          } else if (typeof window !== 'undefined') {
            window.location.hash = '#services';
          }
        }}
      />

      <div className="max-w-5xl w-full mx-auto p-3 sm:p-6 space-y-6">
        
        {/* Header Banner */}
        <header className="bg-gradient-to-r from-teal-950 via-slate-900 to-slate-900 border border-teal-800/60 rounded-3xl p-6 sm:p-7 shadow-2xl relative overflow-hidden">
          <div className="absolute -top-20 -right-20 w-64 h-64 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-5 relative z-10">
            <div className="flex items-center gap-4">
              <div className="p-2 bg-white/95 backdrop-blur-sm rounded-2xl shadow-xl border border-slate-200 shrink-0">
                <AzalLogo variant="horizontal" size="sm" transparent={true} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-teal-950 text-teal-300 border border-teal-800 text-[11px] font-bold">
                    CBAHI FMS.10 & IPC-PCI.8
                  </span>
                  <span className="text-xs text-slate-400 font-mono">#isolation & #smoke-test</span>
                </div>
                <h1 className="text-lg sm:text-xl md:text-2xl font-black text-slate-100 mt-1">
                  مسار فحص غرف العزل بالضغط السلبي واختبار شريط الدخان
                </h1>
                <p className="text-xs sm:text-sm text-slate-300 mt-1">
                  تسجيل نتائج اختبار تدفق الهواء لشريط الدخان (Smoke Trail Test)، وتوثيق فرق الضغط (Magnehelic/Digital)، وفحص كفاءة الطرد لغرف العزل ومختبر الدرن
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => handlePrintReport()}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs flex items-center gap-1.5 transition cursor-pointer shadow-md active:scale-95"
              >
                <Printer className="w-4 h-4 text-teal-400" />
                <span>طباعة السجل الرسمي (A4)</span>
              </button>
            </div>
          </div>

          {/* Sub Navigation Tabs */}
          <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveTab('inspect')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
                activeTab === 'inspect'
                  ? 'bg-teal-600 text-white shadow-lg shadow-teal-950 ring-1 ring-teal-400/40'
                  : 'bg-slate-900/80 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <Sliders className="w-4 h-4" />
              <span>استمارة الفحص السريع وتسجيل القراءة</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('history')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
                activeTab === 'history'
                  ? 'bg-teal-600 text-white shadow-lg shadow-teal-950 ring-1 ring-teal-400/40'
                  : 'bg-slate-900/80 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>سجل الفحوصات الميدانية الموثقة ({logs.length})</span>
            </button>
          </div>
        </header>

        {submittedSuccess && (
          <div className="p-4 rounded-2xl bg-emerald-950/80 border border-emerald-500 text-emerald-200 text-sm font-bold flex items-center gap-3 shadow-xl animate-in fade-in">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span>تم حفظ نتيجة فحص غرفة العزل واختبار شريط الدخان بنجاح وتوثيقها بجدول negative_pressure_logs.</span>
          </div>
        )}

        {activeTab === 'inspect' ? (
          <form onSubmit={handleSubmit} className="space-y-6">
            
            {/* 1. Location & Unit Selection Card */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2.5">
                  <Building2 className="w-5 h-5 text-teal-400" />
                  <h3 className="text-sm font-black text-slate-100">
                    1. اختيار غرفة العزل أو الوحدة الخاضعة للاختبار
                  </h3>
                </div>
                <span className="text-xs text-slate-400">معايير سباهي والتحكم بالعدوى</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {INITIAL_NEGATIVE_PRESSURE_ROOMS.map((room) => {
                  const isSelected = selectedRoomCode === room.roomCode;
                  return (
                    <div
                      key={room.roomCode}
                      onClick={() => setSelectedRoomCode(room.roomCode)}
                      className={`p-3.5 rounded-2xl border transition-all duration-150 cursor-pointer flex flex-col justify-between space-y-2 ${
                        isSelected
                          ? 'bg-teal-950/70 border-teal-500 ring-2 ring-teal-500/30 shadow-md'
                          : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 hover:bg-slate-800/60'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between">
                          <span className="font-mono text-xs font-bold text-teal-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                            {room.roomCode}
                          </span>
                          {isSelected && <Check className="w-4 h-4 text-teal-400" />}
                        </div>
                        <h4 className="text-xs font-bold text-slate-100 mt-2 line-clamp-2">
                          {room.roomName}
                        </h4>
                      </div>
                      <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-400">
                        <span>{room.department}</span>
                        <span className="font-mono text-teal-300 font-bold">{room.targetPressure}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* 2. Differential Pressure & Smoke Test Inputs Card */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl space-y-6">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2.5">
                  <Gauge className="w-5 h-5 text-teal-400" />
                  <h3 className="text-sm font-black text-slate-100">
                    2. قياس فرق الضغط (Differential Pressure) واختبار شريط الدخان (Smoke Trail)
                  </h3>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`px-2.5 py-0.5 rounded-full text-xs font-black ${
                    overallStatus === 'compliant'
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-700'
                      : overallStatus === 'warning'
                      ? 'bg-amber-950 text-amber-300 border border-amber-700'
                      : 'bg-rose-950 text-rose-300 border border-rose-700'
                  }`}>
                    {overallStatus === 'compliant' ? 'مطابق للضغط السلبي ✔' : overallStatus === 'warning' ? 'حرج / يتطلب متابعة ⚠' : 'غير مطابق / خطر تسرب ✖'}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                
                {/* A) Pressure Measurement */}
                <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                      <Gauge className="w-4 h-4 text-teal-400" />
                      <span>قراءة فرق الضغط المقاس:</span>
                    </label>
                    <div className="flex items-center gap-1 text-xs">
                      <button
                        type="button"
                        onClick={() => setPressureUnit('Pa')}
                        className={`px-2.5 py-1 rounded-lg font-mono font-bold transition ${
                          pressureUnit === 'Pa' ? 'bg-teal-600 text-white' : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        باكال (Pa)
                      </button>
                      <button
                        type="button"
                        onClick={() => setPressureUnit('in_wg')}
                        className={`px-2.5 py-1 rounded-lg font-mono font-bold transition ${
                          pressureUnit === 'in_wg' ? 'bg-teal-600 text-white' : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        in w.g.
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <input
                      type="number"
                      step="0.1"
                      value={pressureValuePa}
                      onChange={(e) => setPressureValuePa(parseFloat(e.target.value) || 0)}
                      className="w-32 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-base font-mono font-bold text-slate-100 text-center focus:outline-none focus:border-teal-500"
                      dir="ltr"
                      required
                    />
                    <div className="flex-1 space-y-1">
                      <div className="text-xs text-slate-300 font-bold">
                        {pressureValuePa <= -2.5 ? (
                          <span className="text-emerald-400 flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            ضغط سلبي فعال (مطابق لمعايير سباهي CDC/CBAHI)
                          </span>
                        ) : pressureValuePa < 0 ? (
                          <span className="text-amber-400 flex items-center gap-1">
                            <AlertTriangle className="w-3.5 h-3.5" />
                            ضغط سلبي ضعيف جداً (أقل من الحد الأدنى -2.5 Pa)
                          </span>
                        ) : (
                          <span className="text-rose-400 flex items-center gap-1">
                            <XCircle className="w-3.5 h-3.5" />
                            ضغط إيجابي أو متعادل (خطر تسرب الهواء لداخل المستشفى)
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500">
                        الحد الأدنى لغرف العزل: -2.5 باسكال (-0.01 in w.g.)، ولمختبر الدرن: -5.0 باسكال
                      </p>
                    </div>
                  </div>

                  {/* Preset Quick Buttons */}
                  <div className="flex flex-wrap items-center gap-1.5 pt-1">
                    <span className="text-[11px] text-slate-400">قراءات نموذجية:</span>
                    {[-2.5, -4.5, -6.5, -8.0, -10.0, 0.0, 2.0].map((val) => (
                      <button
                        key={val}
                        type="button"
                        onClick={() => setPressureValuePa(val)}
                        className={`px-2 py-0.5 rounded text-[11px] font-mono font-bold border ${
                          pressureValuePa === val
                            ? 'bg-teal-700 text-white border-teal-500'
                            : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
                        }`}
                      >
                        {val} Pa
                      </button>
                    ))}
                  </div>
                </div>

                {/* B) Smoke Trail Test Result (Crucial CBAHI Item) */}
                <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 space-y-3">
                  <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                    <Wind className="w-4 h-4 text-teal-400" />
                    <span>نتيجة اختبار شريط الدخان (Smoke Trail Test):</span>
                  </label>

                  <div className="grid grid-cols-1 gap-2.5">
                    {/* Option 1: Inward (Pass) */}
                    <div
                      onClick={() => setSmokeTestResult('pass_inward')}
                      className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                        smokeTestResult === 'pass_inward'
                          ? 'bg-emerald-950/70 border-emerald-500 ring-2 ring-emerald-500/30'
                          : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-lg bg-emerald-950 text-emerald-400 border border-emerald-700 flex items-center justify-center font-black">
                          ⇚
                        </div>
                        <div>
                          <div className="text-xs font-black text-slate-100">
                            تدفق سليم للداخل (Pass - Inward Airflow)
                          </div>
                          <div className="text-[11px] text-slate-400">
                            الدخان ينجذب بسلاسة من أسفل الباب نحو داخل غرفة العزل
                          </div>
                        </div>
                      </div>
                      {smokeTestResult === 'pass_inward' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                    </div>

                    {/* Option 2: Outward (Fail / Dangerous) */}
                    <div
                      onClick={() => setSmokeTestResult('fail_outward')}
                      className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                        smokeTestResult === 'fail_outward'
                          ? 'bg-rose-950/70 border-rose-500 ring-2 ring-rose-500/30'
                          : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-lg bg-rose-950 text-rose-400 border border-rose-700 flex items-center justify-center font-black">
                          ⇛
                        </div>
                        <div>
                          <div className="text-xs font-black text-slate-100">
                            تدفق للخارج / تسرب هوائي (Fail - Outward Airflow)
                          </div>
                          <div className="text-[11px] text-rose-300">
                            الدخان يندفع للخارج نحو الممر (خطر وبائي وتسرب ميكروبي)
                          </div>
                        </div>
                      </div>
                      {smokeTestResult === 'fail_outward' && <XCircle className="w-4 h-4 text-rose-400" />}
                    </div>

                    {/* Option 3: Stagnant / Neutral */}
                    <div
                      onClick={() => setSmokeTestResult('fail_stagnant')}
                      className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                        smokeTestResult === 'fail_stagnant'
                          ? 'bg-amber-950/70 border-amber-500 ring-2 ring-amber-500/30'
                          : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-lg bg-amber-950 text-amber-400 border border-amber-700 flex items-center justify-center font-black">
                          ⏸
                        </div>
                        <div>
                          <div className="text-xs font-black text-slate-100">
                            ركود هوائي / تعادل الضغط (Fail - Stagnant Air)
                          </div>
                          <div className="text-[11px] text-slate-400">
                            الدخان يرتفع عمودياً دون حركة تفريغ واضحة
                          </div>
                        </div>
                      </div>
                      {smokeTestResult === 'fail_stagnant' && <AlertTriangle className="w-4 h-4 text-amber-400" />}
                    </div>
                  </div>
                </div>

              </div>

              {/* Physical Verification Checklist */}
              <div className="pt-3 border-t border-slate-800 space-y-3">
                <h4 className="text-xs font-bold text-slate-300">
                  الفحص العيني المكمل لمنظومة العزل الميكانيكية:
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                  <label className="flex items-center gap-2 p-3 rounded-xl bg-slate-950/60 border border-slate-800 cursor-pointer hover:bg-slate-800/60">
                    <input
                      type="checkbox"
                      checked={doorSweepSealIntact}
                      onChange={(e) => setDoorSweepSealIntact(e.target.checked)}
                      className="w-4 h-4 rounded text-teal-600 bg-slate-900 border-slate-700"
                    />
                    <span>عوازل وحواف الباب سليمة</span>
                  </label>

                  <label className="flex items-center gap-2 p-3 rounded-xl bg-slate-950/60 border border-slate-800 cursor-pointer hover:bg-slate-800/60">
                    <input
                      type="checkbox"
                      checked={anteroomDoorClosed}
                      onChange={(e) => setAnteroomDoorClosed(e.target.checked)}
                      className="w-4 h-4 rounded text-teal-600 bg-slate-900 border-slate-700"
                    />
                    <span>باب غرفة الممر الانتقائي مغلق</span>
                  </label>

                  <label className="flex items-center gap-2 p-3 rounded-xl bg-slate-950/60 border border-slate-800 cursor-pointer hover:bg-slate-800/60">
                    <input
                      type="checkbox"
                      checked={exhaustFanOperational}
                      onChange={(e) => setExhaustFanOperational(e.target.checked)}
                      className="w-4 h-4 rounded text-teal-600 bg-slate-900 border-slate-700"
                    />
                    <span>مروحة الطرد العادم تعمل</span>
                  </label>

                  <label className="flex items-center gap-2 p-3 rounded-xl bg-slate-950/60 border border-slate-800 cursor-pointer hover:bg-slate-800/60">
                    <input
                      type="checkbox"
                      checked={hepaFilterDifferentialOk}
                      onChange={(e) => setHepaFilterDifferentialOk(e.target.checked)}
                      className="w-4 h-4 rounded text-teal-600 bg-slate-900 border-slate-700"
                    />
                    <span>فرق ضغط فلتر هيبا سليم</span>
                  </label>
                </div>
              </div>

              {/* Air Changes & Notes */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300">
                    معدل تغيير الهواء المقدر (ACH - Air Changes/Hour):
                  </label>
                  <input
                    type="number"
                    value={airChangesPerHour}
                    onChange={(e) => setAirChangesPerHour(parseFloat(e.target.value) || 12)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 font-mono focus:outline-none focus:border-teal-500"
                    dir="ltr"
                    min="1"
                    max="40"
                  />
                  <span className="text-[11px] text-slate-500">
                    المعيار المطلوب لغرف العزل الجوي AIIR: لا يقل عن 12 دورة/ساعة
                  </span>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300">
                    ملاحظات الفحص والإجراء التصحيحي:
                  </label>
                  <input
                    type="text"
                    value={correctiveAction}
                    onChange={(e) => setCorrectiveAction(e.target.value)}
                    placeholder="مثال: الضغط سلبي وتدفق الهواء منتظم، لا توجد ملاحظات..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-teal-500"
                  />
                </div>
              </div>

              {/* Inspector Sign-off Details */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-slate-800">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">اسم المفتش المعتمد:</label>
                  <input
                    type="text"
                    value={inspectorName}
                    onChange={(e) => setInspectorName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-teal-500"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">الصفة / الإدارة:</label>
                  <input
                    type="text"
                    value={inspectorRole}
                    onChange={(e) => setInspectorRole(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-teal-500"
                    required
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-300">الرقم الوظيفي / الكود:</label>
                  <input
                    type="text"
                    value={inspectorBadgeNumber}
                    onChange={(e) => setInspectorBadgeNumber(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 font-mono focus:outline-none focus:border-teal-500"
                    dir="ltr"
                  />
                </div>
              </div>

              {/* Submit Button */}
              <div className="pt-4 flex items-center justify-between border-t border-slate-800">
                <div className="text-xs text-slate-400">
                  سيتم حفظ البيانات مباشرة في جدول <code className="text-teal-400 font-mono bg-slate-950 px-1.5 py-0.5 rounded">negative_pressure_logs</code>
                </div>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-6 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 disabled:opacity-50 text-white font-black text-xs flex items-center gap-2 transition cursor-pointer shadow-lg shadow-teal-950 active:scale-95"
                >
                  <Send className="w-4 h-4" />
                  <span>{submitting ? 'جاري التوثيق والحفظ...' : 'اعتماد وحفظ نتيجة الفحص'}</span>
                </button>
              </div>

            </div>

          </form>
        ) : (
          /* History View */
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-black text-slate-100">
                  سجل الفحوصات الدورية لغرف العزل بالضغط السلبي
                </h3>
                <p className="text-xs text-slate-400">
                  توثيق اختبارات شريط الدخان وفروق الضغط المعتمدة لمعايير سباهي
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={loadInspectionLogs}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 text-teal-400 ${loading ? 'animate-spin' : ''}`} />
                  <span>تحديث السجل</span>
                </button>
                <button
                  type="button"
                  onClick={() => handlePrintReport()}
                  className="px-3.5 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-black flex items-center gap-1.5 transition cursor-pointer shadow-md"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>طباعة الكل (A4)</span>
                </button>
              </div>
            </div>

            {loading ? (
              <div className="p-8 text-center text-slate-400 text-xs">جاري تحميل سجلات غرف العزل...</div>
            ) : logs.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-xs">لا توجد فحوصات مسجلة بعد. قم بتسجيل أول اختبار الآن.</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-400 font-bold bg-slate-950/60">
                      <th className="p-3">#</th>
                      <th className="p-3">غرفة العزل</th>
                      <th className="p-3">فرق الضغط</th>
                      <th className="p-3">شريط الدخان</th>
                      <th className="p-3">الحالة العامة</th>
                      <th className="p-3">التاريخ والوقت</th>
                      <th className="p-3">المفتش المعتمد</th>
                      <th className="p-3 text-center">إجراءات</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {logs.map((item, idx) => (
                      <tr key={item.id || idx} className="hover:bg-slate-800/40 transition">
                        <td className="p-3 font-mono font-bold text-slate-500">{idx + 1}</td>
                        <td className="p-3">
                          <div className="font-bold text-slate-100">{item.roomName}</div>
                          <div className="text-[11px] text-slate-400 font-mono">{item.roomCode} • {item.department}</div>
                        </td>
                        <td className="p-3 font-mono font-bold text-teal-300" dir="ltr">
                          {item.pressureValuePa} {item.pressureUnit}
                        </td>
                        <td className="p-3">
                          {item.smokeTestResult === 'pass_inward' ? (
                            <span className="text-emerald-400 font-bold flex items-center gap-1">
                              <span>⇚</span> سليم للداخل
                            </span>
                          ) : item.smokeTestResult === 'fail_outward' ? (
                            <span className="text-rose-400 font-bold flex items-center gap-1">
                              <span>⇛</span> تسرب للخارج
                            </span>
                          ) : (
                            <span className="text-amber-400 font-bold flex items-center gap-1">
                              <span>⏸</span> ركود هوائي
                            </span>
                          )}
                        </td>
                        <td className="p-3">
                          <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                            item.overallStatus === 'compliant'
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                              : item.overallStatus === 'warning'
                              ? 'bg-amber-950 text-amber-300 border border-amber-800'
                              : 'bg-rose-950 text-rose-300 border border-rose-800'
                          }`}>
                            {item.overallStatus === 'compliant' ? 'مطابق ✔' : item.overallStatus === 'warning' ? 'حرج ⚠' : 'غير مطابق ✖'}
                          </span>
                        </td>
                        <td className="p-3 text-[11px] text-slate-400">
                          {item.inspectionDate} {item.inspectionTime}
                        </td>
                        <td className="p-3 text-[11px] text-slate-300">
                          {item.inspectorName}
                        </td>
                        <td className="p-3 text-center">
                          <button
                            type="button"
                            onClick={() => handlePrintReport(item)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-teal-900 text-teal-400 transition cursor-pointer"
                            title="طباعة محضر الفحص الفردي"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

      </div>
    </div>
  );
};
