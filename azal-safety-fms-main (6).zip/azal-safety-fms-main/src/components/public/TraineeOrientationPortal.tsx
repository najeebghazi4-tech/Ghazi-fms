import React, { useState } from 'react';
import { 
  Award, 
  Send, 
  CheckCircle2, 
  QrCode, 
  Phone, 
  User, 
  Copy, 
  Check, 
  AlertTriangle, 
  Calendar, 
  ShieldAlert, 
  Flame, 
  HeartHandshake, 
  Building2, 
  Clock, 
  ExternalLink,
  Printer,
  FileCheck,
  Sparkles,
  Share2,
  Lock,
  ChevronDown
} from 'lucide-react';
import { AzalLogo } from '../AzalLogo';
import { AZAL_DEPARTMENTS } from '../../data/azalSafetyUpgradeData';
import { 
  sanitizeInput, 
  checkRateLimit, 
  generateSecureUuid 
} from '../../utils/securityUtils';
import { 
  cleanYemeniPhoneNumber, 
  getPublicAppBaseUrl, 
  openWhatsAppDirect 
} from '../../utils/phoneUtils';
import { triggerSuccessFeedback } from '../../utils/feedbackUtils';
import { executeSmartPrint } from '../../utils/printUtils';

export interface TraineeRecord {
  id: string;
  fullName: string;
  phone: string;
  idNumber: string;
  category: string;
  department: string;
  supervisorName: string;
  confirmedRules: string[];
  submittedAt: string;
  timestamp: number;
}

const ORIENTATION_ITEMS = [
  {
    id: 'evacuation',
    title: 'خطة الإخلاء ومخارج الطوارئ ونقاط التجمع',
    description: 'تمت قراءة وفهم خطة الإخلاء والتعرف على مخارج الطوارئ ونقاط التجمع الآمنة المحددة بمستشفى آزال.',
    icon: Flame,
    color: 'text-amber-400'
  },
  {
    id: 'emergency_codes',
    title: 'أكواد الطوارئ الطبية والميدانية المعتمدة',
    description: 'معرفة معاني أكواد الطوارئ (Code Red للحريق، Code Blue لإنعاش القلب، Code Yellow للكوارث والطوارئ العامة).',
    icon: ShieldAlert,
    color: 'text-rose-400'
  },
  {
    id: 'ppe_biosafety',
    title: 'مهمات الوقاية الشخصية والسلامة الحيوية (PPE / HazMat)',
    description: 'الالتزام التام بارتداء وسائل الوقاية المقررة بكل قسم وتجنب ملامسة النفايات الحيوية أو الانسكابات الخطرة.',
    icon: Award,
    color: 'text-teal-400'
  },
  {
    id: 'internal_hotline',
    title: 'أرقام الطوارئ والبلاغ الفوري للأمن والسلامة',
    description: 'حفظ واستخدام الأرقام الداخلية لإدارة الأمن والسلامة للإبلاغ السريع عن أي خطر أو عطل يهدد سلامة المرضى والكوادر.',
    icon: Phone,
    color: 'text-blue-400'
  },
  {
    id: 'equipment_safety',
    title: 'حماية وتأمين معدات الإطفاء وممرات الإخلاء',
    description: 'التعهد بعدم العبث بطفايات الحريق، أجهزة الإنذار، أو سد ممرات وأبواب الهروب بأي عوائق أو أجهزة.',
    icon: AlertTriangle,
    color: 'text-yellow-400'
  },
  {
    id: 'confidentiality',
    title: 'سرية معلومات المرضى وحرمة المنشأة الطبية',
    description: 'الالتزام التام بقوانين خصوصية المرضى والملفات الطبية وعدم التصوير أو نشر أي بيانات تخص المستشفى.',
    icon: HeartHandshake,
    color: 'text-emerald-400'
  }
];

const TRAINEE_CATEGORIES = [
  'طبيب امتياز / مقيم زائر',
  'متدرب تمريض / قبالة',
  'فني مختبرات / أشعة متدرب',
  'صيدلي متدرب',
  'متدرب صيانة أجهزة طبية وهندسية',
  'متطوع / كادر مؤقت',
  'زائر أكاديمي / استشاري زائر',
  'فئة أخرى'
];

export const TraineeOrientationPortal: React.FC = () => {
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [idNumber, setIdNumber] = useState('');
  const [category, setCategory] = useState(TRAINEE_CATEGORIES[0]);
  const [department, setDepartment] = useState(AZAL_DEPARTMENTS[0]);
  const [supervisorName, setSupervisorName] = useState('');
  
  // Checklist items
  const [checkedItems, setCheckedItems] = useState<Record<string, boolean>>({
    evacuation: true,
    emergency_codes: true,
    ppe_biosafety: true,
    internal_hotline: true,
    equipment_safety: true,
    confidentiality: true
  });
  
  const [legalConfirmed, setLegalConfirmed] = useState(false);
  const [submittedRecord, setSubmittedRecord] = useState<TraineeRecord | null>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [copiedBadge, setCopiedBadge] = useState(false);
  const [showQrModal, setShowQrModal] = useState(false);

  const portalUrl = `${getPublicAppBaseUrl()}/#trainee`;
  const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=320x320&margin=4&data=${encodeURIComponent(portalUrl)}`;

  const toggleItem = (id: string) => {
    setCheckedItems(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const handleSelectAll = () => {
    const allChecked = Object.fromEntries(ORIENTATION_ITEMS.map(item => [item.id, true]));
    setCheckedItems(allChecked);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    const rate = checkRateLimit('trainee_orientation_submit', 5, 60000);
    if (!rate.allowed) {
      setFormError(rate.message || 'تم تجاوز الحد المسموح.');
      return;
    }

    const cleanName = sanitizeInput(fullName);
    if (!cleanName || cleanName.length < 3) {
      setFormError('يرجى إدخال اسم المتدرب/الزائر الرباعي بشكل صحيح.');
      return;
    }

    const cleanPhone = cleanYemeniPhoneNumber(phone);
    if (!cleanPhone || cleanPhone.length < 9) {
      setFormError('يرجى إدخال رقم هاتف يمني صحيح (مثلاً 77XXXXXXX).');
      return;
    }

    const unconfirmed = ORIENTATION_ITEMS.filter(i => !checkedItems[i.id]);
    if (unconfirmed.length > 0) {
      setFormError(`يرجى تأكيد كافة بنود السلامة والتعريف الـ 6 (متبقي: ${unconfirmed.length} بند لم تؤكده).`);
      return;
    }

    if (!legalConfirmed) {
      setFormError('يرجى وضع علامة الموافقة والتعهد على إقرار الالتزام النظامي.');
      return;
    }

    const suffix = generateSecureUuid().slice(0, 4).toUpperCase();
    const recordId = `AZAL-TRN-${new Date().getFullYear()}-${suffix}`;

    const newRecord: TraineeRecord = {
      id: recordId,
      fullName: cleanName,
      phone: cleanPhone,
      idNumber: sanitizeInput(idNumber) || 'غير محدد',
      category,
      department,
      supervisorName: sanitizeInput(supervisorName) || 'رئيس القسم المستضيف',
      confirmedRules: ORIENTATION_ITEMS.map(i => i.title),
      submittedAt: new Date().toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' }),
      timestamp: Date.now()
    };

    // Store in session and state
    try {
      const existing: TraineeRecord[] = JSON.parse(localStorage.getItem('azal_trainee_orientations') || '[]');
      existing.unshift(newRecord);
      localStorage.setItem('azal_trainee_orientations', JSON.stringify(existing.slice(0, 50)));
    } catch {
      // ignore
    }

    setSubmittedRecord(newRecord);
  };

  const generateWhatsAppShareText = (record: TraineeRecord) => {
    return `🏥 *إشعار إنجاز إقرار تدريب وتعريف السلامة والطوارئ* 🏥
*مستشفى آزال النموذجي - إدارة الأمن والسلامة العامة*

نفيدكم بأنه تم إتمام وتوثيق إقرار السلامة والإخلاء الإلكتروني للآتي بياناته:

👤 *الاسم:* ${record.fullName}
🏷️ *الفئة:* ${record.category}
🏢 *القسم المستضيف:* ${record.department}
👨‍⚕️ *المشرف/المنسق:* ${record.supervisorName}
📱 *رقم الهاتف:* ${record.phone}
🆔 *الرقم المرجعي المعتمد:* ${record.id}
⏰ *وقت التوثيق:* ${record.submittedAt}

✅ *بنود الإقرار المؤكدة:*
1. خطة الإخلاء ونقاط التجمع
2. أكواد الطوارئ المعتمدة (Code Red / Blue / Yellow)
3. مهمات الوقاية الشخصية والسلامة الحيوية
4. أرقام الطوارئ الداخلية
5. حماية أجهزة الإطفاء وممرات الهروب
6. الالتزام بسرية المرضى وحرمة المنشأة

🔗 *رابط التحقق الإلكتروني:*
${portalUrl}`;
  };

  const handleShareWhatsApp = (record: TraineeRecord) => {
    const text = generateWhatsAppShareText(record);
    openWhatsAppDirect('771701323', text);
  };

  const handleCopyBadge = async (record: TraineeRecord) => {
    const text = generateWhatsAppShareText(record);
    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(text);
      }
      setCopiedBadge(true);
      setTimeout(() => setCopiedBadge(false), 2500);
    } catch {
      setCopiedBadge(true);
      setTimeout(() => setCopiedBadge(false), 2500);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between select-none dir-rtl font-sans" dir="rtl">
      {/* Header */}
      <header className="bg-slate-900/90 border-b border-slate-800 backdrop-blur-md sticky top-0 z-20 px-4 py-3">
        <div className="max-w-xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-teal-950 border border-teal-800 text-teal-400">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-sm font-black text-slate-100">
                بوابة المتدربين والزوار
              </h1>
              <p className="text-[11px] text-slate-400">
                مستشفى آزال النموذجي • إقرار السلامة والطوارئ والإخلاء
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setShowQrModal(true)}
            className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 border border-teal-500/30 text-xs font-bold flex items-center gap-1.5 transition"
            title="ملصق الباركود QR المخصص للتعليق"
          >
            <QrCode className="w-4 h-4" />
            <span className="hidden sm:inline">ملصق QR</span>
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-xl w-full mx-auto p-4 flex-1">
        {submittedRecord ? (
          /* Success Certificate Badge */
          <div className="bg-slate-900 border-2 border-emerald-500/70 rounded-3xl p-6 text-center space-y-4 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-600 flex items-center justify-center mx-auto shadow-lg shadow-emerald-950">
              <CheckCircle2 className="w-9 h-9" />
            </div>

            <div>
              <div className="inline-block px-3 py-1 rounded-full bg-emerald-950 border border-emerald-700 text-emerald-300 font-bold text-xs mb-2">
                🟢 تم اعتماد وتوثيق إقرار السلامة الإلكتروني
              </div>
              <h2 className="text-lg font-black text-slate-100">
                أهلاً بكم في مستشفى آزال النموذجي
              </h2>
              <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto leading-relaxed">
                تم تسجيل إقراركم بنجاح في قاعدة بيانات الأمن والسلامة والصحة المهنية لعام 2026.
              </p>
            </div>

            {/* Official Digital Badge Card */}
            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 text-right space-y-2.5 shadow-inner">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-xs text-slate-400">الرقم المرجعي للإقرار:</span>
                <strong className="text-emerald-400 font-mono text-sm">{submittedRecord.id}</strong>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">اسم المتدرب / الزائر:</span>
                <strong className="text-slate-100">{submittedRecord.fullName}</strong>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">الفئة والصفة:</span>
                <span className="text-amber-300 font-bold">{submittedRecord.category}</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">القسم المستضيف:</span>
                <span className="text-teal-300 font-bold">{submittedRecord.department}</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400">المشرف المباشر:</span>
                <span className="text-slate-200">{submittedRecord.supervisorName}</span>
              </div>
              <div className="flex items-center justify-between text-xs border-t border-slate-800 pt-2">
                <span className="text-slate-400">تاريخ ووقت التوثيق:</span>
                <span className="text-slate-300 font-mono">{submittedRecord.submittedAt}</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2 pt-2">
              <button
                type="button"
                onClick={() => handleShareWhatsApp(submittedRecord)}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs shadow-lg shadow-emerald-950 flex items-center justify-center gap-2 transition active:scale-95 cursor-pointer"
              >
                <Share2 className="w-4 h-4" />
                <span>إرسال إشعار الإقرار عبر واتساب لمسؤول السلامة / المشرف</span>
              </button>

              <button
                type="button"
                onClick={() => handleCopyBadge(submittedRecord)}
                className="w-full py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer"
              >
                {copiedBadge ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                <span>{copiedBadge ? 'تم نسخ بيانات الإقرار' : 'نسخ نص الإقرار الرسمي'}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setSubmittedRecord(null);
                  setFullName('');
                  setPhone('');
                  setIdNumber('');
                  setLegalConfirmed(false);
                }}
                className="w-full py-2 rounded-2xl bg-slate-950 hover:bg-slate-900 text-slate-400 font-bold text-xs transition"
              >
                تسجيل إقرار لمتدرب أو زائر آخر
              </button>
            </div>
          </div>
        ) : (
          /* Orientation Declaration Form */
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Introductory Card */}
            <div className="bg-gradient-to-r from-teal-950/40 via-slate-900 to-slate-900 border border-teal-800/60 rounded-3xl p-4 sm:p-5 shadow-lg space-y-2">
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-lg bg-teal-900/80 text-teal-300">
                  <FileCheck className="w-4 h-4" />
                </span>
                <h2 className="text-sm font-black text-teal-200">
                  إقرار وتعهد الالتزام باشتراطات السلامة والخطط الطارئة
                </h2>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                أهلاً بكم في مستشفى آزال. يُلزم كافة المتدربين والكوادر الزائرة بالاطلاع وتأكيد بنود السلامة، أكواد الطوارئ، وإجراءات الإخلاء الطبي المعتمدة قبل البدء بالمهام الميدانية.
              </p>
            </div>

            {/* Error Message */}
            {formError && (
              <div className="p-3.5 rounded-2xl bg-rose-950/80 border border-rose-700 text-rose-200 text-xs flex items-center gap-2 animate-shake">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            {/* Personal Data Section */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-5 space-y-3.5 shadow-md">
              <h3 className="text-xs font-bold text-slate-200 flex items-center gap-2 border-b border-slate-800 pb-2">
                <User className="w-3.5 h-3.5 text-teal-400" />
                <span>أولاً: البيانات الشخصية والأكاديمية</span>
              </h3>

              <div>
                <label className="text-[11px] font-bold text-slate-300 block mb-1">
                  اسم المتدرب / الزائر (رباعياً) <span className="text-rose-400">*</span>:
                </label>
                <input
                  type="text"
                  required
                  placeholder="مثال: د. أحمد محمد صالح العولقي"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-teal-500 transition"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-bold text-slate-300 block mb-1">
                    رقم الهاتف / الواتساب <span className="text-rose-400">*</span>:
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="77XXXXXXX"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    dir="ltr"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-teal-500 transition font-mono"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-300 block mb-1">
                    رقم البطاقة الشخصية / الجامعية:
                  </label>
                  <input
                    type="text"
                    placeholder="رقم الهوية أو الرقم الأكاديمي"
                    value={idNumber}
                    onChange={(e) => setIdNumber(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-teal-500 transition"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-bold text-slate-300 block mb-1">
                    الفئة والصفة التدريبية <span className="text-rose-400">*</span>:
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-teal-500 transition"
                  >
                    {TRAINEE_CATEGORIES.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-300 block mb-1">
                    القسم / الوحدة المستضيفة <span className="text-rose-400">*</span>:
                  </label>
                  <select
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-teal-500 transition"
                  >
                    {AZAL_DEPARTMENTS.map(dept => (
                      <option key={dept} value={dept}>{dept}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-300 block mb-1">
                  المشرف المباشر أو المنسق في المستشفى:
                </label>
                <input
                  type="text"
                  placeholder="مثال: د. رئيس قسم الطوارئ / مشرف التدريب السريري"
                  value={supervisorName}
                  onChange={(e) => setSupervisorName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-teal-500 transition"
                />
              </div>
            </div>

            {/* Orientation Checklist Section */}
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-5 space-y-3 shadow-md">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <h3 className="text-xs font-bold text-slate-200 flex items-center gap-2">
                  <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
                  <span>ثانياً: بنود إقرار السلامة والإخلاء الطبي (يرجى التأكيد على جميع البنود)</span>
                </h3>
                <button
                  type="button"
                  onClick={handleSelectAll}
                  className="text-[11px] text-teal-400 hover:text-teal-300 font-bold transition"
                >
                  تحديد الكل ✓
                </button>
              </div>

              <div className="space-y-2.5 pt-1">
                {ORIENTATION_ITEMS.map((item) => {
                  const Icon = item.icon;
                  const isChecked = Boolean(checkedItems[item.id]);

                  return (
                    <div
                      key={item.id}
                      onClick={() => toggleItem(item.id)}
                      className={`p-3 rounded-2xl border transition cursor-pointer flex items-start gap-3 select-none ${
                        isChecked
                          ? 'bg-slate-950/80 border-teal-600/70 shadow-sm'
                          : 'bg-slate-950/40 border-slate-800 opacity-70 hover:opacity-100'
                      }`}
                    >
                      <div className={`mt-0.5 w-5 h-5 rounded-lg border flex items-center justify-center shrink-0 transition ${
                        isChecked 
                          ? 'bg-teal-600 border-teal-500 text-white' 
                          : 'border-slate-700 bg-slate-900'
                      }`}>
                        {isChecked && <Check className="w-3.5 h-3.5" />}
                      </div>

                      <div className="flex-1 space-y-0.5">
                        <div className="flex items-center gap-1.5">
                          <Icon className={`w-3.5 h-3.5 ${item.color}`} />
                          <h4 className="text-xs font-bold text-slate-100">
                            {item.title}
                          </h4>
                        </div>
                        <p className="text-[11px] text-slate-400 leading-relaxed">
                          {item.description}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Legal Commitment Box */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-4 sm:p-5 space-y-3">
              <label className="flex items-start gap-3 cursor-pointer select-none">
                <input
                  type="checkbox"
                  required
                  checked={legalConfirmed}
                  onChange={(e) => setLegalConfirmed(e.target.checked)}
                  className="mt-1 w-4 h-4 rounded text-teal-600 focus:ring-0 focus:outline-none bg-slate-950 border-slate-700 cursor-pointer"
                />
                <span className="text-xs text-slate-300 leading-relaxed font-semibold">
                  أقر وأتعهد أنا الموقع أعلاه بالالتزام التام بكافة التعليمات الصادرة عن إدارة الأمن والسلامة والصحة المهنية بمستشفى آزال النموذجي، وإدراك مسؤوليتي الإدارية والمهنية عن أي تقصير أو مخالفة.
                </span>
              </label>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-teal-600 via-emerald-600 to-teal-500 hover:from-teal-500 hover:to-emerald-500 text-white font-black text-xs shadow-xl shadow-teal-950/60 flex items-center justify-center gap-2 transition active:scale-95 cursor-pointer"
            >
              <FileCheck className="w-4 h-4" />
              <span>توثيق واعتماد إقرار السلامة إلكترونياً</span>
            </button>
          </form>
        )}
      </main>

      {/* Printable Poster QR Modal */}
      {showQrModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-sm w-full p-5 sm:p-6 text-center space-y-4 shadow-2xl animate-in zoom-in-95">
            <div className="bg-white p-3 rounded-2xl inline-block shadow-lg mx-auto border-2 border-slate-200">
              <img
                src={qrImageUrl}
                alt="رمز QR بوابة المتدربين والزوار"
                className="w-48 h-48 mx-auto object-contain block"
              />
            </div>

            <div>
              <h3 className="text-sm font-bold text-slate-100 flex items-center justify-center gap-1.5">
                <Award className="w-4 h-4 text-teal-400" />
                <span>ملصق QR بوابة المتدربين والزوار</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                رمز رسمي مخصص للتعليق في قاعات التدريب، الاستقبال، وإدارة الموارد البشرية لمسحه وتعبئة إقرار السلامة والإخلاء.
              </p>
            </div>

            <div className="bg-slate-950 border border-slate-800 rounded-xl p-2 text-right">
              <span className="text-[10px] text-slate-400 block mb-1">الرابط المباشر:</span>
              <input
                type="text"
                readOnly
                value={portalUrl}
                onClick={(e) => (e.target as HTMLInputElement).select()}
                dir="ltr"
                className="w-full bg-transparent text-teal-300 font-mono text-xs px-1 outline-none select-all font-semibold"
              />
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => {
                  triggerSuccessFeedback();
                  const posterHtml = `
                    <div style="text-align:center; padding:20px; max-width:600px; margin:0 auto; border:2px dashed #0d9488; border-radius:16px;">
                      <div style="font-size:24px; font-weight:900; color:#0f172a; margin-bottom:4px;">برنامج التهيئة والتعريف بالسلامة المهنية</div>
                      <div style="font-size:14px; color:#0d9488; font-weight:bold; margin-bottom:16px;">مستشفى آزال النموذجي • قسم التدريب والتعليم المستمر والجودة CBAHI</div>
                      
                      <p style="font-size:13px; color:#475569; line-height:1.6; margin-bottom:20px;">
                        أهلاً بكم في مستشفى آزال النموذجي. يرجى مسح رمز الاستجابة السريعة (QR) أدناه للبدء في الاختبار والاطلاع على سياسات السلامة وخطة الإخلاء وإجراءات الطوارئ.
                      </p>

                      <div style="display:inline-block; padding:16px; background:#fff; border:2px solid #cbd5e1; border-radius:16px; box-shadow:0 4px 12px rgba(0,0,0,0.08); margin-bottom:20px;">
                        <img 
                          src="https://api.qrserver.com/v1/create-qr-code/?size=300x300&margin=4&data=${encodeURIComponent(portalUrl)}" 
                          alt="QR Code" 
                          style="width:240px; height:240px; display:block;"
                        />
                      </div>

                      <div style="background:#f0fdfa; border:1px solid #99f6e4; border-radius:12px; padding:12px; margin-bottom:16px; font-size:12px; color:#115e59;">
                        <strong>📞 رقم عمليات الطوارئ والسلامة بالمستشفى:</strong> <span dir="ltr" style="font-weight:bold; font-size:15px; color:#0d9488;">777738138</span>
                      </div>

                      <div style="font-size:11px; color:#94a3b8;">
                        متطلب إلزامي لكافة الكوادر الجديدة والمتدربين قبل استلام العمل الميداني وفق معايير CBAHI
                      </div>
                    </div>
                  `;

                  executeSmartPrint(posterHtml, {
                    title: 'ملصق بوابة تهيئة المتدربين والكوادر الجديدة - مستشفى آزال النموذجي',
                    subtitle: 'ملصق معتمد لقسم الموارد البشرية والتدريب',
                    refNumber: 'AZAL-TRAINEE-QR-2026'
                  });
                }}
                className="flex-1 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>طباعة الملصق (Poster / PDF)</span>
              </button>
              <button
                type="button"
                onClick={() => setShowQrModal(false)}
                className="py-2 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-slate-800/80 py-3 text-center text-slate-500 text-[11px]">
        مستشفى آزال النموذجي • إدارة الأمن والسلامة العامة والصحة المهنية (CBAHI / JCI)
      </footer>
    </div>
  );
};
