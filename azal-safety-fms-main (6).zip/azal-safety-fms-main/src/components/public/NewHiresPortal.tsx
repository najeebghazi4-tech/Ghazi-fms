import React, { useState, useEffect } from 'react';
import { 
  GraduationCap, 
  Send, 
  CheckCircle2, 
  QrCode, 
  Phone, 
  User, 
  Copy, 
  Check, 
  AlertTriangle, 
  Calendar, 
  Plus, 
  Trash2, 
  Share2, 
  Building2, 
  UserCheck, 
  Briefcase 
} from 'lucide-react';
import { NewHiresTrainingNotice, NewHireEmployee } from '../../types';
import { AZAL_DEPARTMENTS } from '../../data/azalSafetyUpgradeData';
import { AzalLogo } from '../AzalLogo';
import { 
  sanitizeInput, 
  checkRateLimit, 
  generateSecureUuid 
} from '../../utils/securityUtils';
import { cleanYemeniPhoneNumber, getPublicAppBaseUrl } from '../../utils/phoneUtils';
import { GlobalPortalBackBar } from './GlobalPortalBackBar';

interface NewHiresPortalProps {
  onSubmitNotice: (notice: NewHiresTrainingNotice) => void;
}

export const NewHiresPortal: React.FC<NewHiresPortalProps> = ({
  onSubmitNotice,
}) => {
  const [hrOfficerName, setHrOfficerName] = useState('');
  const [hrOfficerPhone, setHrOfficerPhone] = useState('');
  const [startDate, setStartDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [priority, setPriority] = useState<'urgent' | 'routine'>('urgent');
  const [notes, setNotes] = useState('');

  // Dynamic Employees List
  const [hires, setHires] = useState<NewHireEmployee[]>([
    {
      id: 'h-init-1',
      fullName: '',
      jobTitle: '',
      department: AZAL_DEPARTMENTS[0],
      phone: ''
    }
  ]);

  const [submitted, setSubmitted] = useState(false);
  const [submittedNotice, setSubmittedNotice] = useState<NewHiresTrainingNotice | null>(null);
  const [showQrModal, setShowQrModal] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [securityError, setSecurityError] = useState<string | null>(null);

  const portalUrl = `${getPublicAppBaseUrl()}/#new-hires-portal`;

  const handleAddHireRow = () => {
    setHires([
      ...hires,
      {
        id: `h-${Date.now()}-${hires.length + 1}`,
        fullName: '',
        jobTitle: '',
        department: AZAL_DEPARTMENTS[0],
        phone: ''
      }
    ]);
  };

  const handleRemoveHireRow = (id: string) => {
    if (hires.length <= 1) return;
    setHires(hires.filter(h => h.id !== id));
  };

  const handleUpdateHire = (id: string, field: keyof NewHireEmployee, value: string) => {
    setHires(hires.map(h => h.id === id ? { ...h, [field]: value } : h));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSecurityError(null);

    const rateLimit = checkRateLimit('new_hires_notice_submit', 5, 60000);
    if (!rateLimit.allowed) {
      setSecurityError(rateLimit.message || 'تم تجاوز الحد الأقصى للمحاولات، يرجى الانتظار.');
      return;
    }

    const cleanOfficer = sanitizeInput(hrOfficerName);
    if (!cleanOfficer) {
      setSecurityError('يرجى إدخال اسم مسؤول الموارد البشرية.');
      return;
    }

    const cleanPhone = cleanYemeniPhoneNumber(hrOfficerPhone);

    // Validate hires
    const validHires = hires.filter(h => h.fullName.trim().length > 0);
    if (validHires.length === 0) {
      setSecurityError('يرجى إدخال اسم موظف جديد واحد على الأقل.');
      return;
    }

    const sanitizedHires: NewHireEmployee[] = validHires.map((h, i) => ({
      id: h.id || `h-${i}`,
      fullName: sanitizeInput(h.fullName),
      jobTitle: sanitizeInput(h.jobTitle) || 'موظف صحي / إداري',
      department: h.department || AZAL_DEPARTMENTS[0],
      phone: cleanYemeniPhoneNumber(h.phone) || h.phone
    }));

    const secureSuffix = generateSecureUuid().split('-')[0].toUpperCase();
    const newNoticeId = `AZAL-HR-${new Date().getFullYear()}-${secureSuffix}`;

    const newNotice: NewHiresTrainingNotice = {
      id: newNoticeId,
      hrOfficerName: cleanOfficer,
      hrOfficerPhone: cleanPhone || hrOfficerPhone,
      startDate,
      priority,
      hires: sanitizedHires,
      notes: sanitizeInput(notes) || undefined,
      status: 'new_request',
      createdAt: `${new Date().toLocaleDateString('ar-EG')} ${new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}`,
      timestamp: Date.now(),
      synced: true,
    };

    onSubmitNotice(newNotice);
    setSubmittedNotice(newNotice);
    setSubmitted(true);
  };

  const resetForm = () => {
    setHires([
      {
        id: `h-${Date.now()}`,
        fullName: '',
        jobTitle: '',
        department: AZAL_DEPARTMENTS[0],
        phone: ''
      }
    ]);
    setNotes('');
    setSubmittedNotice(null);
    setSubmitted(false);
  };

  const handleCopyLink = async () => {
    try {
      if (navigator?.clipboard?.writeText) {
        await navigator.clipboard.writeText(portalUrl);
      } else {
        const textarea = document.createElement('textarea');
        textarea.value = portalUrl;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
      }
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  const handleSendWhatsAppToAdmin = () => {
    if (!submittedNotice) return;
    const n = submittedNotice;
    const hiresListText = n.hires.map((h, idx) => {
      return `${idx + 1}. *${h.fullName}* - ${h.jobTitle} (${h.department})${h.phone ? ` - هاتف: ${h.phone}` : ''}`;
    }).join('\n');

    const text = `🏥 *مستشفى آزال النموذجي - إدارة الأمن والسلامة*
🎓 *إشعار الموظفين الجدد للتدريب التعريفي بالسلامة (HR)*
---------------------------------------
🔖 *رقم الإشعار:* ${n.id}
👤 *مسؤول الموارد البشرية:* ${n.hrOfficerName}
📞 *هاتف التنسيق:* ${n.hrOfficerPhone}
📅 *تاريخ المباشرة:* ${n.startDate}
⚡ *درجة الأولوية:* ${n.priority === 'urgent' ? 'عاجل (خلال 24-48 ساعة)' : 'اعتيادي (الدورة الدورية)'}
👥 *عدد الموظفين الجدد:* ${n.hires.length} كادر
📋 *قائمة الموظفين الجدد:*
${hiresListText}
${n.notes ? `\n📝 *ملاحظات خاصة:* ${n.notes}` : ''}
---------------------------------------
🌐 الرابط المباشر للبوابة:
${portalUrl}

يرجى إدراجهم ضمن برنامج التدريب على أكواد الطوارئ واستخدام الطفايات والإخلاء.`;

    const shareUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
    window.open(shareUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between text-right" dir="rtl">
      {/* Sticky Universal Header Back Bar */}
      <GlobalPortalBackBar
        title="توجيه وتدريب الموظفين الجدد (Orientation)"
        subtitle="مستشفى آزال النموذجي • إدارة الموارد البشرية والتدريب"
        showServicesLink={true}
        actions={
          <button
            type="button"
            onClick={() => setShowQrModal(true)}
            className="px-2.5 py-1 sm:px-3 sm:py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 text-xs font-bold flex items-center gap-1.5 transition"
          >
            <QrCode className="w-3.5 h-3.5 text-blue-400" />
            <span className="hidden sm:inline">رمز QR</span>
          </button>
        }
      />

      <div className="flex-1 flex flex-col justify-between py-6 px-3 sm:px-4">
      {/* Header */}
      <header className="max-w-2xl w-full mx-auto flex items-center justify-between pb-4 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="p-1 bg-white rounded-xl shadow-sm border border-slate-200">
            <AzalLogo size="xs" showText={false} />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="text-xs font-black text-slate-100">
                مستشفى آزال
              </h2>
              <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-700/60">
                الرعاية الكاملة
              </span>
            </div>
            <span className="text-[10px] text-blue-400 font-bold block">إدارة الموارد البشرية والتدريب (FMS)</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowQrModal(true)}
            className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 text-xs font-bold flex items-center gap-1.5 transition"
          >
            <QrCode className="w-4 h-4 text-blue-400" />
            <span className="hidden sm:inline">رمز QR للبوابة</span>
          </button>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-2xl w-full mx-auto my-auto py-6">
        <div className="text-center space-y-2 mb-6">
          <div className="inline-block p-2.5 sm:p-3 bg-white/95 backdrop-blur-sm rounded-2xl shadow-lg border border-slate-200 mb-1 max-w-xs hover:scale-105 transition-transform">
            <AzalLogo variant="horizontal" size="md" transparent={true} />
          </div>
          <h1 className="text-lg font-black text-slate-100">
            إشعار الموظفين الجدد لدورة السلامة المهنية
          </h1>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-950/80 text-blue-300 border border-blue-800 text-xs font-bold">
            <GraduationCap className="w-4 h-4 text-blue-400" />
            <span>بوابة الموارد البشرية HR (تنسيق مباشر بدون تسجيل دخول)</span>
          </div>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            تنسيق فوري بين إدارة الموارد البشرية وقسم السلامة لتدريب الكوادر الجديدة على أكواد المستشفى ومكافحة الحرائق قبل استلام العمل.
          </p>
        </div>

        {submitted && submittedNotice ? (
          /* Confirmation Card */
          <div className="bg-slate-900 border border-emerald-600/70 rounded-3xl p-6 text-center space-y-5 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-700 flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 className="w-9 h-9" />
            </div>

            <div>
              <h2 className="text-base font-bold text-slate-100">
                تم إرسال الإشعار بنجاح إلى إدارة الأمن والسلامة
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                تم استلام بيانات الموظفين الجدد وجدولة الدورة التأهيلية تحت إشراف م/ نجيب غازي.
              </p>
            </div>

            {/* Summary */}
            <div className="bg-slate-950 border border-slate-800 p-4 rounded-2xl text-right space-y-2 text-xs">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-slate-400">رقم الإشعار المرجعي:</span>
                <strong className="text-blue-400 font-mono text-sm">{submittedNotice.id}</strong>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">مسؤول الموارد البشرية:</span>
                <span className="font-bold text-slate-200">{submittedNotice.hrOfficerName}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">عدد الكوادر الجدد:</span>
                <span className="font-mono text-emerald-400 font-bold">{submittedNotice.hires.length} موظف</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">تاريخ المباشرة:</span>
                <span className="font-mono text-slate-200">{submittedNotice.startDate}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">درجة الأولوية:</span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                  submittedNotice.priority === 'urgent' ? 'bg-rose-950 text-rose-300 border border-rose-800' : 'bg-slate-800 text-slate-300'
                }`}>
                  {submittedNotice.priority === 'urgent' ? 'عاجل (مباشر)' : 'اعتيادي'}
                </span>
              </div>
            </div>

            {/* Actions */}
            <div className="space-y-2 pt-1">
              <button
                type="button"
                onClick={handleSendWhatsAppToAdmin}
                className="w-full py-3.5 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-950 flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <Share2 className="w-4 h-4" />
                <span>إرسال نسخة للإدارة عبر واتساب</span>
              </button>

              <button
                type="button"
                onClick={resetForm}
                className="w-full py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition cursor-pointer"
              >
                إرسال دفعة موظفين جديدة
              </button>

              <a
                href="#services"
                className="w-full py-2.5 rounded-2xl bg-slate-900 border border-slate-700 hover:bg-slate-800 text-slate-300 font-bold text-xs transition cursor-pointer flex items-center justify-center gap-2"
              >
                <span>العودة لبوابة الخدمات الموحدة (#services)</span>
              </a>
            </div>
          </div>
        ) : (
          <form
            onSubmit={handleSubmit}
            className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 space-y-4 shadow-xl text-xs"
          >
            {securityError && (
              <div className="p-3 bg-rose-950/80 border border-rose-800 rounded-xl text-rose-300 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{securityError}</span>
              </div>
            )}

            {/* HR Officer Info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-200 font-bold mb-1">
                  اسم مسؤول الموارد البشرية <span className="text-blue-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={hrOfficerName}
                  onChange={(e) => setHrOfficerName(e.target.value)}
                  placeholder="الاسم الكامل لمسؤول HR"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-slate-100 text-xs focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-slate-200 font-bold mb-1">
                  رقم هاتف مسؤول HR للتنسيق <span className="text-blue-400">*</span>
                </label>
                <input
                  type="tel"
                  required
                  value={hrOfficerPhone}
                  onChange={(e) => setHrOfficerPhone(e.target.value)}
                  placeholder="9677XXXXXXXX"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-slate-100 text-xs font-mono focus:outline-none focus:border-blue-500"
                  dir="ltr"
                />
              </div>
            </div>

            {/* Start Date & Priority */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-200 font-bold mb-1">
                  تاريخ مباشرة العمل <span className="text-blue-400">*</span>
                </label>
                <input
                  type="date"
                  required
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-slate-100 text-xs font-mono focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-slate-200 font-bold mb-1">
                  درجة أولوية التدريب <span className="text-blue-400">*</span>
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setPriority('urgent')}
                    className={`py-2.5 px-3 rounded-xl border text-center font-bold text-xs transition ${
                      priority === 'urgent'
                        ? 'bg-rose-950/80 border-rose-500 text-rose-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    عاجل (خلال 24-48 ساعة)
                  </button>
                  <button
                    type="button"
                    onClick={() => setPriority('routine')}
                    className={`py-2.5 px-3 rounded-xl border text-center font-bold text-xs transition ${
                      priority === 'routine'
                        ? 'bg-blue-950/80 border-blue-500 text-blue-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    اعتيادي (الدورة الدورية)
                  </button>
                </div>
              </div>
            </div>

            {/* Dynamic New Hires List */}
            <div className="pt-2">
              <div className="flex items-center justify-between mb-2">
                <label className="block text-slate-200 font-bold">
                  بيانات الموظفين الجدد المطلوب تدريبهم ({hires.length}) <span className="text-blue-400">*</span>
                </label>
                <button
                  type="button"
                  onClick={handleAddHireRow}
                  className="px-2.5 py-1 rounded-lg bg-blue-950 hover:bg-blue-900 text-blue-300 border border-blue-800 text-[11px] font-bold flex items-center gap-1 transition"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>إضافة موظف آخر</span>
                </button>
              </div>

              <div className="space-y-3">
                {hires.map((hire, idx) => (
                  <div 
                    key={hire.id}
                    className="bg-slate-950/80 border border-slate-800 rounded-2xl p-3.5 space-y-2.5 relative"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-blue-400 flex items-center gap-1.5">
                        <UserCheck className="w-3.5 h-3.5" />
                        <span>موظف #{idx + 1}</span>
                      </span>
                      {hires.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveHireRow(hire.id)}
                          className="text-slate-500 hover:text-rose-400 p-1"
                          title="حذف هذا الموظف"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <input
                        type="text"
                        required
                        value={hire.fullName}
                        onChange={(e) => handleUpdateHire(hire.id, 'fullName', e.target.value)}
                        placeholder="الاسم الكامل للموظف *"
                        className="bg-slate-900 border border-slate-700/80 rounded-xl px-3 py-2 text-slate-100 text-xs focus:outline-none focus:border-blue-500"
                      />

                      <input
                        type="text"
                        value={hire.jobTitle}
                        onChange={(e) => handleUpdateHire(hire.id, 'jobTitle', e.target.value)}
                        placeholder="المسمى الوظيفي (طبيب، تمريض، فني...)"
                        className="bg-slate-900 border border-slate-700/80 rounded-xl px-3 py-2 text-slate-100 text-xs focus:outline-none focus:border-blue-500"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <select
                        value={hire.department}
                        onChange={(e) => handleUpdateHire(hire.id, 'department', e.target.value)}
                        className="bg-slate-900 border border-slate-700/80 rounded-xl px-3 py-2 text-slate-100 text-xs focus:outline-none focus:border-blue-500"
                      >
                        {AZAL_DEPARTMENTS.map((dept) => (
                          <option key={dept} value={dept}>
                            {dept}
                          </option>
                        ))}
                      </select>

                      <input
                        type="tel"
                        value={hire.phone}
                        onChange={(e) => handleUpdateHire(hire.id, 'phone', e.target.value)}
                        placeholder="رقم الهاتف للتنسيق (اختياري)"
                        className="bg-slate-900 border border-slate-700/80 rounded-xl px-3 py-2 text-slate-100 text-xs font-mono focus:outline-none focus:border-blue-500"
                        dir="ltr"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Notes */}
            <div>
              <label className="block text-slate-200 font-bold mb-1">
                ملاحظات أو متطلبات خاصة بالتدريب
              </label>
              <textarea
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="أية ملاحظات خاصة بوردية العمل، أو توقيت التدريب المفضل..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-100 text-xs focus:outline-none focus:border-blue-500 resize-none"
              />
            </div>

            {/* Submit */}
            <button
              type="submit"
              className="w-full py-3.5 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-950/50 flex items-center justify-center gap-2 transition cursor-pointer mt-4"
            >
              <Send className="w-4 h-4" />
              <span>إرسال إشعار تدريب الموظفين لإدارة السلامة</span>
            </button>
          </form>
        )}
      </main>

      {/* Footer */}
      <footer className="max-w-2xl w-full mx-auto pt-4 border-t border-slate-800 text-center text-[11px] text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
        <span>مستشفى آزال النموذجي - إدارة الموارد البشرية والتدريب</span>
        <div className="flex items-center gap-3 text-slate-400">
          <button
            type="button"
            onClick={handleCopyLink}
            className="hover:text-blue-400 flex items-center gap-1 transition"
          >
            {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedLink ? 'تم نسخ الرابط' : 'نسخ رابط البوابة'}</span>
          </button>
        </div>
      </footer>

      {/* QR Modal */}
      {showQrModal && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                <QrCode className="w-4 h-4 text-blue-400" />
                <span>رمز QR بوابة تدريب الجدد (HR)</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowQrModal(false)}
                className="text-slate-400 hover:text-slate-200 text-base"
              >
                ✕
              </button>
            </div>

            <div className="p-4 bg-white rounded-2xl inline-block shadow-lg mx-auto">
              <img
                src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(portalUrl)}`}
                alt="New Hires Portal QR Code"
                referrerPolicy="no-referrer"
                className="w-40 h-40 object-contain mx-auto"
              />
            </div>

            <p className="text-xs text-slate-300">
              امسح الكود لفتح بوابة تدريب الموظفين الجدد مباشرة لمسؤولي الموارد البشرية.
            </p>

            <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between gap-2">
              <span className="text-[10px] text-slate-400 truncate font-mono" dir="ltr">
                {portalUrl}
              </span>
              <button
                type="button"
                onClick={handleCopyLink}
                className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-blue-400 text-[10px] font-bold shrink-0"
              >
                {copiedLink ? 'تم النسخ' : 'نسخ'}
              </button>
            </div>

            <button
              type="button"
              onClick={() => setShowQrModal(false)}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs"
            >
              إغلاق
            </button>
          </div>
        </div>
      )}
      </div>
    </div>
  );
};
