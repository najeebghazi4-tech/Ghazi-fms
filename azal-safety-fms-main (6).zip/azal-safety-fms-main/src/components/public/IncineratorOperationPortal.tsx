import React, { useState, useRef, useEffect } from 'react';
import { 
  Flame, 
  Camera, 
  Send, 
  CheckCircle2, 
  QrCode, 
  Phone, 
  User, 
  Copy, 
  Check, 
  AlertTriangle, 
  ShieldCheck, 
  Calendar, 
  Clock, 
  Scale, 
  Package, 
  Share2,
  Trash2,
  Biohazard
} from 'lucide-react';
import { IncineratorOperationNotice } from '../../types';
import { AzalLogo } from '../AzalLogo';
import { 
  sanitizeInput, 
  validateImageFile, 
  checkRateLimit, 
  generateSecureUuid 
} from '../../utils/securityUtils';
import { cleanYemeniPhoneNumber, getPublicAppBaseUrl } from '../../utils/phoneUtils';
import { cloudSync } from '../../services/cloudSyncService';
import { GlobalPortalBackBar } from './GlobalPortalBackBar';

interface IncineratorOperationPortalProps {
  onSubmitNotice: (notice: IncineratorOperationNotice) => void;
}

const WASTE_TYPES = [
  { id: 'sharps', label: 'نفايات حادة (إبر، مشارط، زجاج مكسور)', color: 'border-rose-800 text-rose-300' },
  { id: 'infectious_bio', label: 'نفايات حيوية ومعدية (ضمادات، عينات دم، مخلفات عمليات)', color: 'border-amber-800 text-amber-300' },
  { id: 'pharmaceutical', label: 'أدوية ومستحضرات صيدلانية منتهية', color: 'border-blue-800 text-blue-300' },
  { id: 'general', label: 'نفايات عامة معالجة ومفرزة', color: 'border-slate-800 text-slate-300' },
];

const DEFAULT_SAFETY_CHECKS = [
  'فحص جاهزية خراطيم الإطفاء ومضخات شبكة مكافحة الحريق الخاصة بالمحرقة',
  'معاينة مداخن وفلاتر المحرقة والتأكد من سلامة نظام الشفط والتهوية الميكانيكية',
  'إلزام عمال التشغيل بارتداء البزات الواقية والأقنعة الكيميائية والقفازات المقاومة للحرارة',
  'التأكد من خلو محيط غرفة المحرقة من أي مواد كيميائية سريعة الاشتعال أو اسطوانات غاز'
];

export const IncineratorOperationPortal: React.FC<IncineratorOperationPortalProps> = ({
  onSubmitNotice,
}) => {
  const [supervisorName, setSupervisorName] = useState('');
  const [supervisorPhone, setSupervisorPhone] = useState('');
  const [wasteWeightKg, setWasteWeightKg] = useState<number>(120);
  const [bagsCount, setBagsCount] = useState<number>(15);
  const [selectedWasteTypes, setSelectedWasteTypes] = useState<string[]>(['sharps', 'infectious_bio']);
  const [operationDateTime, setOperationDateTime] = useState(() => {
    const d = new Date();
    d.setHours(d.getHours() + 1, 0, 0, 0);
    return d.toISOString().slice(0, 16);
  });
  const [expectedDurationHours, setExpectedDurationHours] = useState<number>(3);
  const [selectedChecks, setSelectedChecks] = useState<string[]>(DEFAULT_SAFETY_CHECKS);
  const [notes, setNotes] = useState('');
  const [photoUrl, setPhotoUrl] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [submittedNotice, setSubmittedNotice] = useState<IncineratorOperationNotice | null>(null);
  const [showQrModal, setShowQrModal] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [securityError, setSecurityError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const portalUrl = `${getPublicAppBaseUrl()}/#incinerator-portal`;

  const toggleWasteType = (typeId: string) => {
    if (selectedWasteTypes.includes(typeId)) {
      setSelectedWasteTypes(selectedWasteTypes.filter(t => t !== typeId));
    } else {
      setSelectedWasteTypes([...selectedWasteTypes, typeId]);
    }
  };

  const toggleCheck = (checkItem: string) => {
    if (selectedChecks.includes(checkItem)) {
      setSelectedChecks(selectedChecks.filter(c => c !== checkItem));
    } else {
      setSelectedChecks([...selectedChecks, checkItem]);
    }
  };

  const handlePhotoCapture = async (e: React.ChangeEvent<HTMLInputElement>) => {
    setSecurityError(null);
    const file = e.target.files?.[0];
    if (file) {
      const validation = await validateImageFile(file, 5);
      if (!validation.valid) {
        setSecurityError(validation.error || 'الملف المرفوع غير صالح.');
        if (fileInputRef.current) fileInputRef.current.value = '';
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        setPhotoUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSecurityError(null);

    const rateLimit = checkRateLimit('incinerator_notice_submit', 5, 60000);
    if (!rateLimit.allowed) {
      setSecurityError(rateLimit.message || 'تم تجاوز الحد الأقصى للمحاولات، يرجى الانتظار.');
      return;
    }

    const cleanSupervisor = sanitizeInput(supervisorName);
    if (!cleanSupervisor) {
      setSecurityError('يرجى إدخال اسم مشرف قسم النظافة والنفايات.');
      return;
    }

    if (selectedWasteTypes.length === 0) {
      setSecurityError('يرجى تحديد نوع واحد على الأقل من النفايات الطبية.');
      return;
    }

    const cleanPhone = cleanYemeniPhoneNumber(supervisorPhone);
    const cleanNotes = sanitizeInput(notes);

    const secureSuffix = generateSecureUuid().split('-')[0].toUpperCase();
    const newNoticeId = `AZAL-INCIN-${new Date().getFullYear()}-${secureSuffix}`;

    const newNotice: IncineratorOperationNotice = {
      id: newNoticeId,
      supervisorName: cleanSupervisor,
      supervisorPhone: cleanPhone || supervisorPhone,
      wasteWeightKg: Number(wasteWeightKg) || 10,
      bagsCount: bagsCount ? Number(bagsCount) : undefined,
      wasteTypes: selectedWasteTypes,
      operationDateTime,
      expectedDurationHours: Number(expectedDurationHours) || 2,
      safetyCheckConfirmed: selectedChecks.length === DEFAULT_SAFETY_CHECKS.length,
      safetyChecks: selectedChecks,
      notes: cleanNotes || undefined,
      photoUrl: photoUrl || undefined,
      status: 'scheduled',
      createdAt: `${new Date().toLocaleDateString('ar-EG')} ${new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}`,
      timestamp: Date.now(),
      synced: true,
    };

    onSubmitNotice(newNotice);
    cloudSync.syncIncineratorBatch(newNotice).catch(() => {});
    setSubmittedNotice(newNotice);
    setSubmitted(true);
  };

  const resetForm = () => {
    setNotes('');
    setPhotoUrl('');
    setSubmittedNotice(null);
    setSubmitted(false);
  };

  const handleCopyLink = async () => {
    try {
      if (navigator?.clipboard?.writeText) {
        await navigator.clipboard.writeText(portalUrl);
      } else {
        const textarea = document.createElement('textarea');
        textarea.value = portalUrl;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
      }
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  const handleSendWhatsAppToAdmin = () => {
    if (!submittedNotice) return;
    const n = submittedNotice;
    const wasteLabels = n.wasteTypes.map(t => {
      return WASTE_TYPES.find(w => w.id === t)?.label || t;
    }).join(' ، ');

    const checksText = n.safetyChecks.length > 0
      ? n.safetyChecks.map(c => ` ✅ ${c}`).join('\n')
      : ' ⚠️ فحص عام';

    const text = `🏥 *مستشفى آزال النموذجي - إدارة الأمن والسلامة*
🔥 *إشعار حرق النفايات الطبية وتشغيل المحرقة*
---------------------------------------
🔖 *رقم الإشعار:* ${n.id}
👤 *مشرف قسم النظافة:* ${n.supervisorName}
📞 *هاتف المشرف:* ${n.supervisorPhone}
⚖️ *الوزن الإجمالي للنفايات:* ${n.wasteWeightKg} كجم
📦 *عدد الأكياس / الحاويات:* ${n.bagsCount || 'غير محدد'}
☣️ *نوع النفايات المجهزة:* ${wasteLabels}
⏰ *موعد بدء التشغيل المقرر:* ${n.operationDateTime.replace('T', ' ')}
⏳ *المدة المتوقعة للتشغيل:* ${n.expectedDurationHours} ساعات
🛡️ *جاهزية اشتراطات السلامة والإطفاء:*
${checksText}
${n.notes ? `📝 *ملاحظات إضافية:* ${n.notes}\n` : ''}---------------------------------------
🌐 الرابط المباشر للبوابة:
${portalUrl}

يرجى إشراف ضابط السلامة الميداني والتأكد من ضغط شبكة المياه والمطافئ.`;

    const shareUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
    window.open(shareUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between text-right" dir="rtl">
      {/* Sticky Universal Header Back Bar */}
      <GlobalPortalBackBar
        title="إشعار تشغيل المحرقة الطبية"
        subtitle="مستشفى آزال النموذجي • إدارة النفايات الطبية والأمن والسلامة"
        showServicesLink={true}
        actions={
          <button
            type="button"
            onClick={() => setShowQrModal(true)}
            className="px-2.5 py-1 sm:px-3 sm:py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 text-xs font-bold flex items-center gap-1.5 transition"
          >
            <QrCode className="w-3.5 h-3.5 text-rose-400" />
            <span className="hidden sm:inline">رمز QR</span>
          </button>
        }
      />

      <div className="flex-1 flex flex-col justify-between py-6 px-3 sm:px-4">
      {/* Header */}
      <header className="max-w-2xl w-full mx-auto flex items-center justify-between pb-4 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="p-1 bg-white rounded-xl shadow-sm border border-slate-200">
            <AzalLogo size="xs" showText={false} />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="text-xs font-black text-slate-100">
                مستشفى آزال
              </h2>
              <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-700/60">
                الرعاية الكاملة
              </span>
            </div>
            <span className="text-[10px] text-rose-400 font-bold block">إدارة النفايات الطبية والأمن والسلامة (FMS)</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowQrModal(true)}
            className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 text-xs font-bold flex items-center gap-1.5 transition"
          >
            <QrCode className="w-4 h-4 text-rose-400" />
            <span className="hidden sm:inline">رمز QR للبوابة</span>
          </button>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-2xl w-full mx-auto my-auto py-6">
        <div className="text-center space-y-2 mb-6">
          <div className="inline-block p-2.5 sm:p-3 bg-white/95 backdrop-blur-sm rounded-2xl shadow-lg border border-slate-200 mb-1 max-w-xs hover:scale-105 transition-transform">
            <AzalLogo variant="horizontal" size="md" transparent={true} />
          </div>
          <h1 className="text-lg font-black text-slate-100">
            إشعار حرق النفايات الطبية وتشغيل المحرقة
          </h1>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-950/80 text-rose-300 border border-rose-800 text-xs font-bold">
            <Flame className="w-4 h-4 text-rose-400" />
            <span>بوابة إشعار تشغيل المحرقة وفحص منظومة الإطفاء</span>
          </div>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            يجب تقديم هذا الإشعار قبل تشغيل محرقة المستشفى بساعتين على الأقل للتنسيق الميداني مع قسم السلامة.
          </p>
        </div>

        {submitted && submittedNotice ? (
          /* Confirmation Card */
          <div className="bg-slate-900 border border-emerald-600/70 rounded-3xl p-6 text-center space-y-5 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-700 flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 className="w-9 h-9" />
            </div>

            <div>
              <h2 className="text-base font-bold text-slate-100">
                تم إرسال الإشعار بنجاح إلى إدارة الأمن والسلامة
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                تم إخطار فريق السلامة الميداني بموعد وجاهزية تشغيل المحرقة لإجراء المعاينة والإشراف.
              </p>
            </div>

            {/* Summary */}
            <div className="bg-slate-950 border border-slate-800 p-4 rounded-2xl text-right space-y-2 text-xs">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-slate-400">رقم الإشعار المرجعي:</span>
                <strong className="text-rose-400 font-mono text-sm">{submittedNotice.id}</strong>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">مشرف النظافة:</span>
                <span className="font-bold text-slate-200">{submittedNotice.supervisorName}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">وزن النفايات المجهزة:</span>
                <span className="font-mono text-emerald-400 font-bold">{submittedNotice.wasteWeightKg} كجم ({submittedNotice.bagsCount} أكياس)</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">موعد التشغيل المقرر:</span>
                <span className="font-mono text-slate-200">{submittedNotice.operationDateTime.replace('T', ' ')}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">المدة المتوقعة:</span>
                <span className="text-slate-300">{submittedNotice.expectedDurationHours} ساعات</span>
              </div>
            </div>

            {/* Actions */}
            <div className="space-y-2 pt-1">
              <button
                type="button"
                onClick={handleSendWhatsAppToAdmin}
                className="w-full py-3.5 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-950 flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <Share2 className="w-4 h-4" />
                <span>إرسال نسخة للإدارة عبر واتساب</span>
              </button>

              <button
                type="button"
                onClick={resetForm}
                className="w-full py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition cursor-pointer"
              >
                تقديم إشعار تشغيل جديد
              </button>

              <a
                href="#services"
                className="w-full py-2.5 rounded-2xl bg-slate-900 border border-slate-700 hover:bg-slate-800 text-slate-300 font-bold text-xs transition cursor-pointer flex items-center justify-center gap-2"
              >
                <span>العودة لبوابة الخدمات الموحدة (#services)</span>
              </a>
            </div>
          </div>
        ) : (
          <form
            onSubmit={handleSubmit}
            className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 space-y-4 shadow-xl text-xs"
          >
            {securityError && (
              <div className="p-3 bg-rose-950/80 border border-rose-800 rounded-xl text-rose-300 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{securityError}</span>
              </div>
            )}

            {/* Supervisor Details */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-200 font-bold mb-1">
                  اسم مشرف قسم النظافة والنفايات <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={supervisorName}
                  onChange={(e) => setSupervisorName(e.target.value)}
                  placeholder="الاسم الكامل للمشرف المسؤول"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-slate-100 text-xs focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block text-slate-200 font-bold mb-1">
                  رقم هاتف المشرف للتنسيق المباشر <span className="text-rose-400">*</span>
                </label>
                <input
                  type="tel"
                  required
                  value={supervisorPhone}
                  onChange={(e) => setSupervisorPhone(e.target.value)}
                  placeholder="9677XXXXXXXX"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-slate-100 text-xs font-mono focus:outline-none focus:border-rose-500"
                  dir="ltr"
                />
              </div>
            </div>

            {/* Waste Weight and Bags */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-200 font-bold mb-1">
                  كمية / وزن النفايات المجهزة (كجم) <span className="text-rose-400">*</span>
                </label>
                <div className="relative">
                  <input
                    type="number"
                    required
                    min={1}
                    max={2000}
                    value={wasteWeightKg}
                    onChange={(e) => setWasteWeightKg(Math.max(1, parseFloat(e.target.value) || 0))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-slate-100 text-xs font-mono focus:outline-none focus:border-rose-500 pl-12"
                  />
                  <span className="absolute left-3 top-2.5 text-slate-500 font-bold text-[11px]">كجم</span>
                </div>
              </div>

              <div>
                <label className="block text-slate-200 font-bold mb-1">
                  عدد الأكياس والحاويات المقاومة للثقب
                </label>
                <input
                  type="number"
                  min={1}
                  max={500}
                  value={bagsCount}
                  onChange={(e) => setBagsCount(Math.max(1, parseInt(e.target.value) || 1))}
                  placeholder="مثال: 15 كيس"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-slate-100 text-xs font-mono focus:outline-none focus:border-rose-500"
                />
              </div>
            </div>

            {/* Waste Types Selection */}
            <div>
              <label className="block text-slate-200 font-bold mb-2">
                نوعية النفايات الطبية المطلوب حرقها <span className="text-rose-400">*</span>
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {WASTE_TYPES.map((type) => {
                  const isChecked = selectedWasteTypes.includes(type.id);
                  return (
                    <button
                      key={type.id}
                      type="button"
                      onClick={() => toggleWasteType(type.id)}
                      className={`p-2.5 rounded-xl border text-right flex items-center gap-2.5 transition ${
                        isChecked 
                          ? 'bg-rose-950/70 border-rose-500 text-rose-200' 
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      <Biohazard className={`w-4 h-4 shrink-0 ${isChecked ? 'text-rose-400' : 'text-slate-500'}`} />
                      <span className="text-[11px] font-semibold">{type.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Operation Date & Duration */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-200 font-bold mb-1">
                  موعد وتوقيت تشغيل المحرقة المحدد <span className="text-rose-400">*</span>
                </label>
                <input
                  type="datetime-local"
                  required
                  value={operationDateTime}
                  onChange={(e) => setOperationDateTime(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-slate-100 text-xs font-mono focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block text-slate-200 font-bold mb-1">
                  مدة التشغيل المتوقعة (ساعات)
                </label>
                <input
                  type="number"
                  min={1}
                  max={12}
                  value={expectedDurationHours}
                  onChange={(e) => setExpectedDurationHours(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-slate-100 text-xs font-mono focus:outline-none focus:border-rose-500"
                />
              </div>
            </div>

            {/* Safety Confirmation Checklist */}
            <div className="pt-2">
              <label className="block text-slate-200 font-bold mb-2">
                إقرار فحص وسائل السلامة وجاهزية الإطفاء:
              </label>
              <div className="space-y-2 bg-slate-950/70 p-3 rounded-2xl border border-slate-800">
                {DEFAULT_SAFETY_CHECKS.map((checkItem, idx) => {
                  const checked = selectedChecks.includes(checkItem);
                  return (
                    <label key={idx} className="flex items-start gap-2.5 cursor-pointer text-slate-300 hover:text-slate-100">
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() => toggleCheck(checkItem)}
                        className="mt-0.5 rounded border-slate-700 text-rose-500 focus:ring-rose-500 bg-slate-900"
                      />
                      <span className="text-[11px] leading-relaxed">{checkItem}</span>
                    </label>
                  );
                })}
              </div>
            </div>

            {/* Notes */}
            <div>
              <label className="block text-slate-200 font-bold mb-1">
                ملاحظات إضافية (أقسام التوريد، حالة المحرقة، أخرى)
              </label>
              <textarea
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="أية تفاصيل إضافية حول شحنة النفايات أو جاهزية غرفة المحرقة..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-100 text-xs focus:outline-none focus:border-rose-500 resize-none"
              />
            </div>

            {/* Photo Attachment */}
            <div>
              <label className="block text-slate-200 font-bold mb-1">
                صورة توثيقية للأكياس المجهزة أو شاشة درجات الحرارة (اختياري)
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/*"
                  capture="environment"
                  onChange={handlePhotoCapture}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:bg-slate-800 text-slate-300 flex items-center gap-2 transition"
                >
                  <Camera className="w-4 h-4 text-rose-400" />
                  <span>التقاط أو إرفاق صورة</span>
                </button>

                {photoUrl && (
                  <div className="relative">
                    <img
                      src={photoUrl}
                      alt="Incinerator preview"
                      referrerPolicy="no-referrer"
                      className="w-12 h-12 object-cover rounded-xl border border-rose-500"
                    />
                    <button
                      type="button"
                      onClick={() => setPhotoUrl('')}
                      className="absolute -top-1.5 -right-1.5 bg-rose-600 text-white rounded-full w-4 h-4 flex items-center justify-center text-[10px]"
                    >
                      ×
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Submit */}
            <button
              type="submit"
              className="w-full py-3.5 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-lg shadow-rose-950/50 flex items-center justify-center gap-2 transition cursor-pointer mt-4"
            >
              <Send className="w-4 h-4" />
              <span>إرسال إشعار تشغيل المحرقة لإدارة السلامة</span>
            </button>
          </form>
        )}
      </main>

      {/* Footer */}
      <footer className="max-w-2xl w-full mx-auto pt-4 border-t border-slate-800 text-center text-[11px] text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
        <span>مستشفى آزال النموذجي - وحدة التخلص الآمن من النفايات الطبية</span>
        <div className="flex items-center gap-3 text-slate-400">
          <button
            type="button"
            onClick={handleCopyLink}
            className="hover:text-rose-400 flex items-center gap-1 transition"
          >
            {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedLink ? 'تم نسخ الرابط' : 'نسخ رابط البوابة'}</span>
          </button>
        </div>
      </footer>

      {/* QR Modal */}
      {showQrModal && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                <QrCode className="w-4 h-4 text-rose-400" />
                <span>رمز QR إشعار المحرقة</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowQrModal(false)}
                className="text-slate-400 hover:text-slate-200 text-base"
              >
                ✕
              </button>
            </div>

            <div className="p-4 bg-white rounded-2xl inline-block shadow-lg mx-auto">
              <img
                src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(portalUrl)}`}
                alt="Incinerator Portal QR Code"
                referrerPolicy="no-referrer"
                className="w-40 h-40 object-contain mx-auto"
              />
            </div>

            <p className="text-xs text-slate-300">
              امسح الكود لفتح بوابة إشعار حرق النفايات الطبية مباشرة من هاتف المشرف.
            </p>

            <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between gap-2">
              <span className="text-[10px] text-slate-400 truncate font-mono" dir="ltr">
                {portalUrl}
              </span>
              <button
                type="button"
                onClick={handleCopyLink}
                className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-rose-400 text-[10px] font-bold shrink-0"
              >
                {copiedLink ? 'تم النسخ' : 'نسخ'}
              </button>
            </div>

            <button
              type="button"
              onClick={() => setShowQrModal(false)}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs"
            >
              إغلاق
            </button>
          </div>
        </div>
      )}
      </div>
    </div>
  );
};
