import React, { useState, useRef, useEffect } from 'react';
import { 
  HardHat, 
  Camera, 
  MapPin, 
  FileText, 
  Send, 
  CheckCircle2, 
  QrCode, 
  Phone, 
  User, 
  Copy, 
  Check, 
  AlertTriangle, 
  ShieldCheck, 
  Calendar, 
  Clock, 
  Users, 
  Wrench, 
  Flame, 
  Zap, 
  Building2, 
  Share2 
} from 'lucide-react';
import { ContractorPermitNotice } from '../../types';
import { AZAL_DEPARTMENTS } from '../../data/azalSafetyUpgradeData';
import { AzalLogo } from '../AzalLogo';
import { 
  sanitizeInput, 
  validateImageFile, 
  checkRateLimit, 
  generateSecureUuid 
} from '../../utils/securityUtils';
import { cleanYemeniPhoneNumber, getPublicAppBaseUrl } from '../../utils/phoneUtils';
import { cloudSync } from '../../services/cloudSyncService';
import { GlobalPortalBackBar } from './GlobalPortalBackBar';

interface ContractorPermitPortalProps {
  onSubmitNotice: (notice: ContractorPermitNotice) => void;
}

const WORK_TYPES = [
  { id: 'electrical', label: 'تمديدات وصيانة كهربائية', icon: Zap },
  { id: 'hot_work', label: 'أعمال ساخنة / لحام وقص معادن', icon: Flame },
  { id: 'civil_maintenance', label: 'صيانة مدنية وبناء وديكور', icon: Building2 },
  { id: 'plumbing', label: 'سباكة وتمديدات صحية وشبكات مياه', icon: Wrench },
  { id: 'hvac', label: 'تكييف وتبريد وتهوية مركزية', icon: HardHat },
  { id: 'medical_gas', label: 'شبكة ومحابس الغازات الطبية', icon: AlertTriangle },
  { id: 'other', label: 'أعمال أخرى متخصصة', icon: Wrench },
];

const DEFAULT_SAFETY_MEASURES = [
  'توفير طفايات حريق معتمدة وصالحة ومناسبة لنوع العمل بجوار الموقع',
  'تطبيق إجراءات عزل مصادر الطاقة والغازات (Lockout / Tagout)',
  'إلزام جميع عمال المقاول بارتداء مهمات الوقاية الشخصية (PPE) الكاملة',
  'تعيين مراقب سلامة معتمد بالموقع طوال فترة العمل',
  'إخلاء محيط العمل من المواد القابلة للاشتعال وحماية الممرات'
];

export const ContractorPermitPortal: React.FC<ContractorPermitPortalProps> = ({
  onSubmitNotice,
}) => {
  const [selectedDept, setSelectedDept] = useState(AZAL_DEPARTMENTS[0]);
  const [isCustomDept, setIsCustomDept] = useState(false);
  const [customDept, setCustomDept] = useState('');
  const [contractorName, setContractorName] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [applicantName, setApplicantName] = useState('');
  const [workType, setWorkType] = useState('electrical');
  const [workTypeCustom, setWorkTypeCustom] = useState('');
  const [workDescription, setWorkDescription] = useState('');
  const [workersCount, setWorkersCount] = useState<number>(2);
  const [workersNames, setWorkersNames] = useState('');
  const [expectedStartDate, setExpectedStartDate] = useState(() => {
    const d = new Date();
    d.setHours(d.getHours() + 1, 0, 0, 0);
    return d.toISOString().slice(0, 16);
  });
  const [expectedEndDate, setExpectedEndDate] = useState(() => {
    const d = new Date();
    d.setHours(d.getHours() + 8, 0, 0, 0);
    return d.toISOString().slice(0, 16);
  });
  const [selectedMeasures, setSelectedMeasures] = useState<string[]>(DEFAULT_SAFETY_MEASURES);
  const [photoUrl, setPhotoUrl] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [submittedNotice, setSubmittedNotice] = useState<ContractorPermitNotice | null>(null);
  const [showQrModal, setShowQrModal] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [securityError, setSecurityError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const portalUrl = `${getPublicAppBaseUrl()}/#contractor`;

  const toggleMeasure = (measure: string) => {
    if (selectedMeasures.includes(measure)) {
      setSelectedMeasures(selectedMeasures.filter(m => m !== measure));
    } else {
      setSelectedMeasures([...selectedMeasures, measure]);
    }
  };

  const handlePhotoCapture = async (e: React.ChangeEvent<HTMLInputElement>) => {
    setSecurityError(null);
    const file = e.target.files?.[0];
    if (file) {
      const validation = await validateImageFile(file, 5);
      if (!validation.valid) {
        setSecurityError(validation.error || 'الملف المرفوع غير صالح.');
        if (fileInputRef.current) fileInputRef.current.value = '';
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        setPhotoUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSecurityError(null);

    const rateLimit = checkRateLimit('contractor_permit_submit', 5, 60000);
    if (!rateLimit.allowed) {
      setSecurityError(rateLimit.message || 'تم تجاوز الحد الأقصى للمحاولات، يرجى الانتظار قليلاً.');
      return;
    }

    const cleanContractor = sanitizeInput(contractorName);
    if (!cleanContractor) {
      setSecurityError('يرجى كتابة اسم المقاول أو جهة التنفيذ.');
      return;
    }

    const cleanDesc = sanitizeInput(workDescription);
    if (!cleanDesc) {
      setSecurityError('يرجى توضيح تفاصيل ونطاق الأعمال المطلوبة.');
      return;
    }

    const cleanPhone = cleanYemeniPhoneNumber(contactPhone);
    const cleanApplicant = sanitizeInput(applicantName) || cleanContractor;
    const cleanWorkers = sanitizeInput(workersNames);
    const cleanCustomDept = sanitizeInput(customDept);

    const finalDept = isCustomDept && cleanCustomDept ? cleanCustomDept : selectedDept;

    const secureSuffix = generateSecureUuid().split('-')[0].toUpperCase();
    const newNoticeId = `AZAL-CTR-${new Date().getFullYear()}-${secureSuffix}`;

    const newNotice: ContractorPermitNotice = {
      id: newNoticeId,
      department: finalDept,
      contractorName: cleanContractor,
      contactPhone: cleanPhone || contactPhone,
      workType: workType as any,
      workTypeCustom: workType === 'other' ? sanitizeInput(workTypeCustom) : undefined,
      workDescription: cleanDesc,
      workersCount: Math.max(1, Number(workersCount) || 1),
      workersNames: cleanWorkers || 'لم يتم إدراج القائمة بالتفصيل',
      expectedStartDate,
      expectedEndDate,
      safetyMeasures: selectedMeasures,
      permitPhotoUrl: photoUrl || undefined,
      applicantName: cleanApplicant,
      status: 'pending_review',
      createdAt: `${new Date().toLocaleDateString('ar-EG')} ${new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}`,
      timestamp: Date.now(),
      synced: true,
    };

    // Save to parent state and persistent storage
    onSubmitNotice(newNotice);
    cloudSync.syncContractorPermit(newNotice).catch(() => {});
    setSubmittedNotice(newNotice);
    setSubmitted(true);
  };

  const resetForm = () => {
    setContractorName('');
    setContactPhone('');
    setApplicantName('');
    setWorkDescription('');
    setWorkersNames('');
    setPhotoUrl('');
    setSubmittedNotice(null);
    setSubmitted(false);
  };

  const handleCopyLink = async () => {
    try {
      if (navigator?.clipboard?.writeText) {
        await navigator.clipboard.writeText(portalUrl);
      } else {
        const textarea = document.createElement('textarea');
        textarea.value = portalUrl;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
      }
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  const handleSendWhatsAppToAdmin = () => {
    if (!submittedNotice) return;
    const n = submittedNotice;
    const workLabel = WORK_TYPES.find(w => w.id === n.workType)?.label || n.workType;
    const measuresText = n.safetyMeasures.length > 0
      ? n.safetyMeasures.map(m => ` • ${m}`).join('\n')
      : ' • تطبيق معايير السلامة العامة';

    const text = `🏥 *مستشفى آزال النموذجي - إدارة الأمن والسلامة*
📋 *إشعار وتصريح دخول مقاول خارجي جديد*
---------------------------------------
🔖 *رقم التصريح:* ${n.id}
🏢 *القسم المعني:* ${n.department}
👷‍♂️ *اسم المقاول / الجهة:* ${n.contractorName}
📞 *هاتف التنسيق:* ${n.contactPhone}
👤 *مقدم الطلب / المشرف:* ${n.applicantName}
🔨 *طبيعة العمل:* ${workLabel}${n.workTypeCustom ? ` (${n.workTypeCustom})` : ''}
📝 *تفاصيل العمل:* ${n.workDescription}
👥 *عدد العمال:* ${n.workersCount} فرد
📋 *أسماء العمال:*
${n.workersNames}
⏰ *موعد البدء:* ${n.expectedStartDate.replace('T', ' ')}
⏳ *موعد الانتهاء المتوقع:* ${n.expectedEndDate.replace('T', ' ')}
🛡️ *اشتراطات السلامة المقررة:*
${measuresText}
---------------------------------------
🌐 الرابط المباشر للبوابة:
${portalUrl}

يرجى مراجعة الطلب من قبل ضابط السلامة واعتماد التصريح الميداني.`;

    const shareUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
    window.open(shareUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between text-right" dir="rtl">
      {/* Sticky Universal Header Back Bar */}
      <GlobalPortalBackBar
        title="تصريح أعمال المقاول الخارجي"
        subtitle="مستشفى آزال النموذجي • إدارة السلامة والصحة المهنية"
        showServicesLink={true}
        actions={
          <button
            type="button"
            onClick={() => setShowQrModal(true)}
            className="px-2.5 py-1 sm:px-3 sm:py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 text-xs font-bold flex items-center gap-1.5 transition"
          >
            <QrCode className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">رمز QR</span>
          </button>
        }
      />

      <div className="flex-1 flex flex-col justify-between py-6 px-3 sm:px-4">
      {/* Sandboxed Header */}
      <header className="max-w-2xl w-full mx-auto flex items-center justify-between pb-4 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="p-1 bg-white rounded-xl shadow-sm border border-slate-200">
            <AzalLogo size="xs" showText={false} />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="text-xs font-black text-slate-100">
                مستشفى آزال
              </h2>
              <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-700/60">
                الرعاية الكاملة
              </span>
            </div>
            <span className="text-[10px] text-amber-400 font-bold block">إدارة الأمن والسلامة وإدارة المرافق (FMS)</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <a
            href="#permit"
            className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-teal-400 border border-teal-800/80 text-xs font-bold flex items-center gap-1.5 transition"
            title="التحقق من سريان تصريح مقاول"
          >
            <span>فحص سريان تصريح</span>
          </a>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-2xl w-full mx-auto my-auto py-6">
        <div className="text-center space-y-2 mb-6">
          <div className="inline-block p-2.5 sm:p-3 bg-white/95 backdrop-blur-sm rounded-2xl shadow-lg border border-slate-200 mb-1 max-w-xs hover:scale-105 transition-transform">
            <AzalLogo variant="horizontal" size="md" transparent={true} />
          </div>
          <h1 className="text-lg font-black text-slate-100">
            بوابة تصاريح ودخول المقاولين الخارجيين
          </h1>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-950/80 text-amber-300 border border-amber-800 text-xs font-bold">
            <HardHat className="w-4 h-4 text-amber-400" />
            <span>تسجيل إشعار أعمال مقاول (دخول مباشر بدون تسجيل دخول)</span>
          </div>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            وفقاً للوائح السلامة بمستشفى آزال، يمنع بدء أي أعمال مدنية، كهربائية، أو لحام دون تصريح مسبق من قسم السلامة.
          </p>
        </div>

        {submitted && submittedNotice ? (
          /* Standalone Confirmation Card */
          <div className="bg-slate-900 border border-emerald-600/70 rounded-3xl p-6 text-center space-y-5 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-700 flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 className="w-9 h-9" />
            </div>

            <div>
              <h2 className="text-base font-bold text-slate-100">
                تم إرسال الإشعار بنجاح إلى إدارة الأمن والسلامة
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                تم تسجيل طلب التصريح فوراً في سجل المقاولين تحت إشراف رئيس قسم السلامة م/ نجيب غازي.
              </p>
            </div>

            {/* Notice Summary Box */}
            <div className="bg-slate-950 border border-slate-800 p-4 rounded-2xl text-right space-y-2 text-xs">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-slate-400">رقم الإشعار المرجعي:</span>
                <strong className="text-amber-400 font-mono text-sm">{submittedNotice.id}</strong>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">القسم المعني:</span>
                <span className="font-bold text-slate-200">{submittedNotice.department}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">جهة التنفيذ / المقاول:</span>
                <span className="font-bold text-slate-200">{submittedNotice.contractorName}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">طبيعة العمل:</span>
                <span className="font-bold text-amber-300">
                  {WORK_TYPES.find(w => w.id === submittedNotice.workType)?.label || submittedNotice.workType}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">عدد العمال:</span>
                <span className="font-mono text-slate-200">{submittedNotice.workersCount} عمال</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">وقت البدء المقرر:</span>
                <span className="font-mono text-slate-300">{submittedNotice.expectedStartDate.replace('T', ' ')}</span>
              </div>
            </div>

            {/* Direct 1-Click WhatsApp Dispatch Button */}
            <div className="space-y-2 pt-1">
              <button
                type="button"
                onClick={handleSendWhatsAppToAdmin}
                className="w-full py-3.5 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-950 flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <Share2 className="w-4 h-4" />
                <span>إرسال نسخة للإدارة عبر واتساب</span>
              </button>

              <button
                type="button"
                onClick={resetForm}
                className="w-full py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition cursor-pointer"
              >
                تسجيل تصريح مقاول جديد
              </button>

              <a
                href="#services"
                className="w-full py-2.5 rounded-2xl bg-slate-900 border border-slate-700 hover:bg-slate-800 text-slate-300 font-bold text-xs transition cursor-pointer flex items-center justify-center gap-2"
              >
                <span>العودة لبوابة الخدمات الموحدة (#services)</span>
              </a>
            </div>
          </div>
        ) : (
          <form
            onSubmit={handleSubmit}
            className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 space-y-4 shadow-xl text-xs"
          >
            {securityError && (
              <div className="p-3 bg-rose-950/80 border border-rose-800 rounded-xl text-rose-300 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{securityError}</span>
              </div>
            )}

            {/* Department */}
            <div>
              <label className="block text-slate-200 font-bold mb-1.5">
                القسم أو الموقع المعني بالأعمال داخل المستشفى <span className="text-amber-400">*</span>
              </label>
              {!isCustomDept ? (
                <div className="space-y-2">
                  <select
                    value={selectedDept}
                    onChange={(e) => {
                      if (e.target.value === '__other__') {
                        setIsCustomDept(true);
                      } else {
                        setSelectedDept(e.target.value);
                      }
                    }}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-slate-100 text-xs focus:outline-none focus:border-amber-500"
                  >
                    {AZAL_DEPARTMENTS.map((dept) => (
                      <option key={dept} value={dept}>
                        {dept}
                      </option>
                    ))}
                    <option value="__other__">+ قسم / موقع آخر (كتابة يدوية)</option>
                  </select>
                </div>
              ) : (
                <div className="space-y-2">
                  <input
                    type="text"
                    value={customDept}
                    onChange={(e) => setCustomDept(e.target.value)}
                    placeholder="اكتب اسم القسم أو الموقع الدقيق..."
                    className="w-full bg-slate-950 border border-amber-800/80 rounded-xl px-3 py-2.5 text-slate-100 text-xs focus:outline-none focus:border-amber-500"
                  />
                  <button
                    type="button"
                    onClick={() => setIsCustomDept(false)}
                    className="text-[11px] text-amber-400 underline"
                  >
                    العودة للقائمة المعتمدة
                  </button>
                </div>
              )}
            </div>

            {/* Contractor & Phone */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-200 font-bold mb-1">
                  اسم المقاول / الشركة المنفذة <span className="text-amber-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={contractorName}
                  onChange={(e) => setContractorName(e.target.value)}
                  placeholder="مثال: شركة النصر للمقاولات"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-slate-100 text-xs focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-slate-200 font-bold mb-1">
                  رقم هاتف المقاول / المشرف المسؤول <span className="text-amber-400">*</span>
                </label>
                <input
                  type="tel"
                  required
                  value={contactPhone}
                  onChange={(e) => setContactPhone(e.target.value)}
                  placeholder="9677XXXXXXXX"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-slate-100 text-xs font-mono focus:outline-none focus:border-amber-500"
                  dir="ltr"
                />
              </div>
            </div>

            {/* Applicant Name */}
            <div>
              <label className="block text-slate-200 font-bold mb-1">
                اسم المشرف الميداني أو مقدم الطلب
              </label>
              <input
                type="text"
                value={applicantName}
                onChange={(e) => setApplicantName(e.target.value)}
                placeholder="الاسم الكامل لمسؤول التنسيق الميداني"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-slate-100 text-xs focus:outline-none focus:border-amber-500"
              />
            </div>

            {/* Work Type Selection */}
            <div>
              <label className="block text-slate-200 font-bold mb-2">
                طبيعة ونوع الأعمال <span className="text-amber-400">*</span>
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {WORK_TYPES.map((type) => {
                  const Icon = type.icon;
                  const isSelected = workType === type.id;
                  return (
                    <button
                      key={type.id}
                      type="button"
                      onClick={() => setWorkType(type.id)}
                      className={`p-2.5 rounded-xl border text-right flex items-center gap-2.5 transition ${
                        isSelected 
                          ? 'bg-amber-950/70 border-amber-500 text-amber-200' 
                          : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <Icon className={`w-4 h-4 shrink-0 ${isSelected ? 'text-amber-400' : 'text-slate-500'}`} />
                      <span className="font-semibold">{type.label}</span>
                    </button>
                  );
                })}
              </div>
              {workType === 'other' && (
                <input
                  type="text"
                  value={workTypeCustom}
                  onChange={(e) => setWorkTypeCustom(e.target.value)}
                  placeholder="يرجى تحديد نوع العمل بدقة..."
                  className="mt-2 w-full bg-slate-950 border border-amber-800/80 rounded-xl px-3 py-2 text-slate-100 text-xs focus:outline-none focus:border-amber-500"
                />
              )}
            </div>

            {/* Work Description */}
            <div>
              <label className="block text-slate-200 font-bold mb-1">
                تفاصيل ونطاق الأعمال المطلوب تنفيذها <span className="text-amber-400">*</span>
              </label>
              <textarea
                required
                rows={3}
                value={workDescription}
                onChange={(e) => setWorkDescription(e.target.value)}
                placeholder="صف تفاصيل الأعمال بدقة، المواد المستخدمة، والأجهزة المراد تركيبها أو صيانتها..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-100 text-xs focus:outline-none focus:border-amber-500 resize-none"
              />
            </div>

            {/* Workers Count & Names */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="sm:col-span-1">
                <label className="block text-slate-200 font-bold mb-1">
                  عدد العمال <span className="text-amber-400">*</span>
                </label>
                <input
                  type="number"
                  min={1}
                  max={50}
                  value={workersCount}
                  onChange={(e) => setWorkersCount(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-slate-100 text-xs font-mono focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-slate-200 font-bold mb-1">
                  أسماء العمال وأرقام هوياتهم <span className="text-amber-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={workersNames}
                  onChange={(e) => setWorkersNames(e.target.value)}
                  placeholder="مثال: أحمد علي (بطاقة 102)، محمد صالح..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-slate-100 text-xs focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            {/* Dates */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-200 font-bold mb-1">
                  تاريخ ووقت البدء المقرر <span className="text-amber-400">*</span>
                </label>
                <input
                  type="datetime-local"
                  required
                  value={expectedStartDate}
                  onChange={(e) => setExpectedStartDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-slate-100 text-xs font-mono focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-slate-200 font-bold mb-1">
                  تاريخ ووقت الانتهاء المتوقع <span className="text-amber-400">*</span>
                </label>
                <input
                  type="datetime-local"
                  required
                  value={expectedEndDate}
                  onChange={(e) => setExpectedEndDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-slate-100 text-xs font-mono focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            {/* Safety Measures Checklist */}
            <div className="pt-2">
              <label className="block text-slate-200 font-bold mb-2">
                تدابير واشتراطات السلامة المقررة بالموقع:
              </label>
              <div className="space-y-2 bg-slate-950/70 p-3 rounded-2xl border border-slate-800">
                {DEFAULT_SAFETY_MEASURES.map((measure, idx) => {
                  const checked = selectedMeasures.includes(measure);
                  return (
                    <label key={idx} className="flex items-start gap-2.5 cursor-pointer text-slate-300 hover:text-slate-100">
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() => toggleMeasure(measure)}
                        className="mt-0.5 rounded border-slate-700 text-amber-500 focus:ring-amber-500 bg-slate-900"
                      />
                      <span className="text-[11px] leading-relaxed">{measure}</span>
                    </label>
                  );
                })}
              </div>
            </div>

            {/* Optional Photo Attachment */}
            <div>
              <label className="block text-slate-200 font-bold mb-1">
                صورة التصريح أو بطاقة المقاول أو موقع العمل (اختياري)
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/*"
                  capture="environment"
                  onChange={handlePhotoCapture}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:bg-slate-800 text-slate-300 flex items-center gap-2 transition"
                >
                  <Camera className="w-4 h-4 text-amber-400" />
                  <span>التقاط أو إرفاق صورة</span>
                </button>

                {photoUrl && (
                  <div className="relative">
                    <img
                      src={photoUrl}
                      alt="Permit preview"
                      referrerPolicy="no-referrer"
                      className="w-12 h-12 object-cover rounded-xl border border-amber-500"
                    />
                    <button
                      type="button"
                      onClick={() => setPhotoUrl('')}
                      className="absolute -top-1.5 -right-1.5 bg-rose-600 text-white rounded-full w-4 h-4 flex items-center justify-center text-[10px]"
                    >
                      ×
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full py-3.5 rounded-2xl bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs shadow-lg shadow-amber-950/50 flex items-center justify-center gap-2 transition cursor-pointer mt-4"
            >
              <Send className="w-4 h-4" />
              <span>إرسال إشعار التصريح إلى قسم السلامة</span>
            </button>
          </form>
        )}
      </main>

      {/* Sandboxed Footer */}
      <footer className="max-w-2xl w-full mx-auto pt-4 border-t border-slate-800 text-center text-[11px] text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
        <span>مستشفى آزال النموذجي - وحدة الأمن والسلامة والصحة المهنية</span>
        <div className="flex items-center gap-3 text-slate-400">
          <button
            type="button"
            onClick={handleCopyLink}
            className="hover:text-amber-400 flex items-center gap-1 transition"
          >
            {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedLink ? 'تم نسخ الرابط' : 'نسخ رابط البوابة'}</span>
          </button>
        </div>
      </footer>

      {/* QR Code Modal */}
      {showQrModal && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                <QrCode className="w-4 h-4 text-amber-400" />
                <span>رمز QR تصاريح المقاولين</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowQrModal(false)}
                className="text-slate-400 hover:text-slate-200 text-base"
              >
                ✕
              </button>
            </div>

            <div className="p-4 bg-white rounded-2xl inline-block shadow-lg mx-auto">
              <img
                src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(portalUrl)}`}
                alt="Contractor Portal QR Code"
                referrerPolicy="no-referrer"
                className="w-40 h-40 object-contain mx-auto"
              />
            </div>

            <p className="text-xs text-slate-300">
              امسح الكود بكاميرا الهاتف لفتح بوابة تصاريح المقاولين مباشرة دون تسجيل دخول.
            </p>

            <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between gap-2">
              <span className="text-[10px] text-slate-400 truncate font-mono" dir="ltr">
                {portalUrl}
              </span>
              <button
                type="button"
                onClick={handleCopyLink}
                className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-amber-400 text-[10px] font-bold shrink-0"
              >
                {copiedLink ? 'تم النسخ' : 'نسخ'}
              </button>
            </div>

            <button
              type="button"
              onClick={() => setShowQrModal(false)}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs"
            >
              إغلاق
            </button>
          </div>
        </div>
      )}
      </div>
    </div>
  );
};
