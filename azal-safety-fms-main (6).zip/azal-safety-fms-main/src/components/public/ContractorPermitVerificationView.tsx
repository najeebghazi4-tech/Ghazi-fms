import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  HardHat, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  Printer, 
  Share2, 
  Copy, 
  Check, 
  Phone, 
  Calendar, 
  Users, 
  Building2, 
  FileText, 
  QrCode, 
  Lock, 
  ShieldAlert, 
  Flame, 
  ExternalLink,
  ChevronRight
} from 'lucide-react';
import { ContractorPermitNotice } from '../../types';
import { AzalLogo } from '../AzalLogo';
import { 
  buildPermitVerificationUrl, 
  parsePermitFromUrl, 
  getPermitWhatsAppShareText 
} from '../../utils/permitUrlUtils';
import { cleanYemeniPhoneNumber } from '../../utils/phoneUtils';
import { triggerSuccessFeedback } from '../../utils/feedbackUtils';
import { printExistingElementById } from '../../utils/printUtils';
import { GlobalPortalBackBar } from './GlobalPortalBackBar';

interface ContractorPermitVerificationViewProps {
  permitId?: string | null;
  savedPermits?: ContractorPermitNotice[];
  onBackToPortal?: () => void;
}

export const ContractorPermitVerificationView: React.FC<ContractorPermitVerificationViewProps> = ({
  permitId,
  savedPermits = [],
  onBackToPortal
}) => {
  const [copied, setCopied] = useState(false);
  const [showShareOptions, setShowShareOptions] = useState(false);

  // 1. Resolve permit data: Look up in local storage/props, or reconstruct from URL search/hash params
  const [permit, setPermit] = useState<ContractorPermitNotice | null>(() => {
    // A. Check in saved permits list by ID or permitNumber
    if (permitId) {
      const match = savedPermits.find(
        (p) =>
          p.id.toLowerCase() === permitId.toLowerCase() ||
          (p.permitNumber && p.permitNumber.toLowerCase() === permitId.toLowerCase())
      );
      if (match) return match;
    }

    // B. Reconstruct from URL search params or hash (Self-contained!)
    if (typeof window !== 'undefined') {
      const parsed = parsePermitFromUrl(window.location.href);
      if (parsed && (parsed.id || parsed.permitNumber)) {
        return {
          id: parsed.id || permitId || 'AZAL-CTR-2026-001',
          permitNumber: parsed.permitNumber || `AZAL-PERMIT-2026-${(parsed.id || '1088').replace(/\D/g, '').slice(-4) || '1088'}`,
          department: parsed.department || 'القسم المعني',
          contractorName: parsed.contractorName || 'المقاول المصرح له',
          contactPhone: parsed.contactPhone || '',
          workType: parsed.workType || 'civil_maintenance',
          workDescription: parsed.workDescription || 'أعمال هندسية وصيانة مصرح بها بالمستشفى',
          workersCount: parsed.workersCount || 1,
          workersNames: parsed.workersNames || 'العمال المصرح لهم بموجب الهويات المرفقة',
          expectedStartDate: parsed.expectedStartDate || new Date().toISOString(),
          expectedEndDate: parsed.expectedEndDate || new Date().toISOString(),
          workingHours: parsed.workingHours || '08:00 صباحاً - 04:00 عصراً',
          status: parsed.status || 'approved',
          approvedBy: parsed.approvedBy || 'رئيس قسم الأمن والسلامة / م. نجيب غازي',
          approvedAt: parsed.approvedAt || new Date().toLocaleDateString('ar-YE'),
          approvalPrecautions: parsed.approvalPrecautions || parsed.safetyMeasures || [],
          safetyMeasures: parsed.safetyMeasures || [],
          applicantName: parsed.contractorName || 'مشرف المقاول',
          safetyNotes: parsed.safetyNotes,
          createdAt: new Date().toLocaleDateString('ar-YE'),
          timestamp: Date.now()
        };
      }
    }

    // Fallback: If savedPermits has items, return the first one
    return savedPermits[0] || null;
  });

  // Re-check when permitId changes or window location updates
  useEffect(() => {
    if (permitId && savedPermits.length > 0) {
      const match = savedPermits.find(
        (p) =>
          p.id.toLowerCase() === permitId.toLowerCase() ||
          (p.permitNumber && p.permitNumber.toLowerCase() === permitId.toLowerCase())
      );
      if (match) {
        setPermit(match);
        return;
      }
    }

    if (typeof window !== 'undefined') {
      const parsed = parsePermitFromUrl(window.location.href);
      if (parsed && (parsed.id || parsed.permitNumber)) {
        setPermit((prev) => ({
          ...(prev || {}),
          ...parsed,
          id: parsed.id || prev?.id || 'AZAL-CTR-2026-001',
          contractorName: parsed.contractorName || prev?.contractorName || 'المقاول المصرح له',
          applicantName: parsed.applicantName || prev?.applicantName || 'المقاول المصرح له',
          department: parsed.department || prev?.department || 'القسم المعني',
          workType: parsed.workType || prev?.workType || 'civil_maintenance',
          workDescription: parsed.workDescription || prev?.workDescription || 'أعمال هندسية وصيانة',
          workersCount: parsed.workersCount || prev?.workersCount || 1,
          workersNames: parsed.workersNames || prev?.workersNames || '',
          expectedStartDate: parsed.expectedStartDate || prev?.expectedStartDate || '',
          expectedEndDate: parsed.expectedEndDate || prev?.expectedEndDate || '',
          status: parsed.status || prev?.status || 'approved',
          createdAt: prev?.createdAt || new Date().toLocaleDateString('ar-YE'),
          timestamp: prev?.timestamp || Date.now(),
          safetyMeasures: parsed.safetyMeasures || prev?.safetyMeasures || []
        } as ContractorPermitNotice));
      }
    }
  }, [permitId, savedPermits]);

  if (!permit) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-4">
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 max-w-md w-full text-center space-y-4 shadow-2xl">
          <ShieldAlert className="w-12 h-12 text-rose-500 mx-auto animate-pulse" />
          <h2 className="text-base font-bold text-slate-100">لم يتم العثور على تصريح المقاول</h2>
          <p className="text-xs text-slate-400">
            الرابط غير مكتمل أو لم يتم إرفاق معرف التصريح المطلوب. يرجى التحقق من الرابط المستلم من قسم الأمن والسلامة.
          </p>
          {onBackToPortal && (
            <button
              type="button"
              onClick={onBackToPortal}
              className="w-full py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs shadow-md transition"
            >
              الانتقال إلى بوابة طلبات التصاريح
            </button>
          )}
        </div>
      </div>
    );
  }

  const permitUrl = buildPermitVerificationUrl(permit);
  const isApproved = permit.status === 'approved' || permit.status === 'active_work';
  const isPending = permit.status === 'pending_review';
  const isCompleted = permit.status === 'completed';

  const permitOfficialNo =
    permit.permitNumber ||
    `AZAL-PERMIT-2026-${permit.id.replace(/\D/g, '').slice(-4) || '1088'}`;

  const precautions =
    permit.approvalPrecautions && permit.approvalPrecautions.length > 0
      ? permit.approvalPrecautions
      : permit.safetyMeasures && permit.safetyMeasures.length > 0
      ? permit.safetyMeasures
      : [
          'توفير طفاية حريق يدوية مناسبة بالموقع وصالحة للاستخدام',
          'ارتداء مهمات الوقاية الشخصية PPE الكاملة لجميع العمال',
          'عزل منطقة العمل وتطويقها بأشرطة تحذيرية صفراء',
          'مراقبة الموقع والتنسيق الدائم مع قسم الأمن والسلامة'
        ];

  const handleCopyLink = async () => {
    try {
      if (navigator?.clipboard?.writeText) {
        await navigator.clipboard.writeText(permitUrl);
      } else {
        const ta = document.createElement('textarea');
        ta.value = permitUrl;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handleShareWhatsApp = (targetPhone?: string) => {
    const message = getPermitWhatsAppShareText(permit, permitUrl);
    const phoneToUse = targetPhone ? cleanYemeniPhoneNumber(targetPhone) : '';
    const url = phoneToUse
      ? `https://wa.me/${phoneToUse}?text=${encodeURIComponent(message)}`
      : `https://wa.me/?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handlePrint = () => {
    triggerSuccessFeedback();
    printExistingElementById('official-contractor-permit-badge', {
      title: `تصريح عمل ومقاولة معتمد - ${permit.contractorCompany || 'مستشفى آزال'}`,
      subtitle: 'مستشفى آزال النموذجي • إدارة السلامة والصحة المهنية والأمن • وثيقة دخول رسمية',
      refNumber: permit.id
    });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-start font-sans select-none print:p-0 print:bg-white print:text-black" dir="rtl">
      {/* Sticky Universal Header Back Bar */}
      <div className="w-full print:hidden">
        <GlobalPortalBackBar
          title="التحقق من سريان تصريح المقاول"
          subtitle="مستشفى آزال النموذجي • إدارة السلامة والصحة المهنية"
          onCustomBack={onBackToPortal}
          showServicesLink={true}
        />
      </div>

      <div className="w-full max-w-2xl p-3 sm:p-6">
      {/* Top Bar / Navigation (Hidden in print) */}
      <div className="w-full flex items-center justify-between gap-3 mb-4 print:hidden">
        <div className="flex items-center gap-2">
          {onBackToPortal ? (
            <button
              type="button"
              onClick={onBackToPortal}
              className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-xs font-bold text-slate-300 flex items-center gap-1.5 transition"
            >
              <ChevronRight className="w-4 h-4" />
              <span>تقديم طلب تصريح</span>
            </button>
          ) : (
            <a
              href="#contractor-portal"
              className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-xs font-bold text-slate-300 flex items-center gap-1.5 transition"
            >
              <ChevronRight className="w-4 h-4" />
              <span>تقديم طلب جديد</span>
            </a>
          )}
          <span className="text-[11px] text-slate-500 font-mono">
            وثيقة التحقق الإلكتروني المعتمدة
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handlePrint}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white transition shadow-sm"
            title="طباعة الوثيقة"
          >
            <Printer className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={handleCopyLink}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white transition shadow-sm flex items-center gap-1 text-xs"
            title="نسخ الرابط"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
          </button>
          <button
            type="button"
            onClick={() => setShowShareOptions(!showShareOptions)}
            className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 transition shadow-sm"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>مشاركة عبر واتساب</span>
          </button>
        </div>
      </div>

      {/* WhatsApp Share Options Drawer / Flyout (Hidden in print) */}
      {showShareOptions && (
        <div className="w-full max-w-2xl mb-4 bg-slate-900 border border-emerald-800/80 rounded-2xl p-4 shadow-xl text-right animate-in fade-in slide-in-from-top-2 duration-200 print:hidden space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h4 className="text-xs font-bold text-emerald-400 flex items-center gap-2">
              <Share2 className="w-4 h-4" />
              <span>إرسال تصريح الدخول عبر واتساب مباشرة</span>
            </h4>
            <button
              type="button"
              onClick={() => setShowShareOptions(false)}
              className="text-slate-400 hover:text-slate-200 text-xs"
            >
              ✕
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            {permit.contactPhone && (
              <button
                type="button"
                onClick={() => handleShareWhatsApp(permit.contactPhone)}
                className="p-3 bg-slate-950 hover:bg-emerald-950/50 border border-slate-800 hover:border-emerald-700 rounded-xl text-right transition flex items-center justify-between"
              >
                <div>
                  <strong className="text-slate-200 block">إرسال لهاتف المقاول</strong>
                  <span className="font-mono text-[11px] text-slate-400" dir="ltr">
                    {permit.contactPhone}
                  </span>
                </div>
                <Phone className="w-4 h-4 text-emerald-400" />
              </button>
            )}

            <button
              type="button"
              onClick={() => handleShareWhatsApp()}
              className="p-3 bg-slate-950 hover:bg-emerald-950/50 border border-slate-800 hover:border-emerald-700 rounded-xl text-right transition flex items-center justify-between"
            >
              <div>
                <strong className="text-slate-200 block">إرسال لحراسة البوابة الأمنية</strong>
                <span className="text-[11px] text-slate-400">فتح اختيار جهة الاتصال في واتساب</span>
              </div>
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* OFFICIAL VERIFIED BADGE CARD (PRINTABLE & DISPLAYABLE) */}
      {/* ========================================================================= */}
      <div 
        id="official-contractor-permit-badge"
        className="w-full max-w-2xl bg-slate-900 border-2 border-emerald-500/80 rounded-3xl p-5 sm:p-7 shadow-2xl space-y-6 relative overflow-hidden print:bg-white print:border-2 print:border-black print:text-black print:rounded-none print:shadow-none print:max-w-none print:w-full print:p-6"
      >
        {/* Subtle Watermark for Security */}
        <div className="absolute inset-0 pointer-events-none opacity-[0.03] print:opacity-[0.05] flex items-center justify-center">
          <ShieldCheck className="w-[500px] h-[500px] text-emerald-400" />
        </div>

        {/* 1. Hospital Header */}
        <div className="flex items-center justify-between border-b border-slate-800 print:border-black pb-4 relative z-10">
          <div className="text-right">
            <h1 className="text-base sm:text-lg font-black text-slate-100 print:text-black tracking-tight">
              مستشفى آزال النموذجي
            </h1>
            <p className="text-xs font-bold text-teal-400 print:text-teal-800">
              إدارة السلامة والصحة المهنية والأمن
            </p>
            <span className="text-[10px] text-slate-400 print:text-slate-600 block mt-0.5">
              منظومة الرقابة وتصاريح العمل الإلكترونية المعتمدة
            </span>
          </div>

          <div className="flex items-center gap-3">
            <AzalLogo variant="horizontal" size="sm" transparent={true} />
          </div>
        </div>

        {/* 2. Document Title & Big Official Status Bar */}
        <div className="text-center space-y-2 relative z-10">
          <span className="text-[11px] font-bold text-slate-400 print:text-slate-600 uppercase tracking-wider block">
            وثيقة دخول وتفويض أمني رسمي
          </span>
          <h2 className="text-lg sm:text-xl font-black text-slate-100 print:text-black">
            تصريح عمل ودخول مقاول معتمد - مستشفى آزال النموذجي
          </h2>

          {/* Status Badge */}
          {isApproved && (
            <div className="p-3 rounded-2xl bg-gradient-to-r from-emerald-950 via-emerald-900 to-teal-950 border-2 border-emerald-500 text-emerald-200 print:bg-emerald-100 print:text-emerald-950 print:border-emerald-600 flex items-center justify-center gap-3 shadow-lg shadow-emerald-950/50">
              <ShieldCheck className="w-6 h-6 text-emerald-400 print:text-emerald-700 animate-pulse" />
              <div className="text-right sm:text-center">
                <span className="text-sm sm:text-base font-black tracking-wide block">
                  معتمد ومصرح بالعمل والدخول
                </span>
                <span className="text-[11px] text-emerald-300 print:text-emerald-800 font-mono">
                  تم استيفاء معايير واشتراطات السلامة المهنية الرسمية
                </span>
              </div>
            </div>
          )}

          {isPending && (
            <div className="p-3 rounded-2xl bg-amber-950/80 border-2 border-amber-500 text-amber-200 print:bg-amber-100 print:text-amber-950 print:border-amber-600 flex items-center justify-center gap-3 shadow-lg">
              <Clock className="w-6 h-6 text-amber-400 animate-spin" />
              <div>
                <span className="text-sm font-black block">قيد المراجعة والاعتماد الفني</span>
                <span className="text-[11px] text-amber-300 font-mono">
                  غير مصرح بالدخول حتى صدور الاعتماد والتوقيع النهائي
                </span>
              </div>
            </div>
          )}

          {isCompleted && (
            <div className="p-3 rounded-2xl bg-blue-950/80 border-2 border-blue-500 text-blue-200 print:bg-blue-100 print:text-blue-950 flex items-center justify-center gap-3 shadow-lg">
              <CheckCircle2 className="w-6 h-6 text-blue-400" />
              <div>
                <span className="text-sm font-black block">أعمال مكتملة ومغلقة رسمياً</span>
                <span className="text-[11px] text-blue-300 font-mono">تم إنهاء الأعمال وإخلاء الموقع</span>
              </div>
            </div>
          )}
        </div>

        {/* 3. Permit Reference Numbers */}
        <div className="bg-slate-950 print:bg-slate-50 p-3 sm:p-4 rounded-2xl border border-slate-800 print:border-slate-300 flex flex-wrap items-center justify-between gap-3 text-xs relative z-10">
          <div>
            <span className="text-slate-400 print:text-slate-600 block text-[11px]">
              رقم التصريح والاعتماد الرسمي:
            </span>
            <strong className="text-sm font-mono text-emerald-400 print:text-emerald-800 font-black">
              {permitOfficialNo}
            </strong>
          </div>

          <div>
            <span className="text-slate-400 print:text-slate-600 block text-[11px]">
              رقم طلب التسجيل:
            </span>
            <strong className="text-xs font-mono text-amber-400 print:text-amber-800">
              {permit.id}
            </strong>
          </div>

          <div>
            <span className="text-slate-400 print:text-slate-600 block text-[11px]">
              تاريخ وتوقيت الإصدار:
            </span>
            <span className="font-mono text-slate-300 print:text-slate-700">
              {permit.approvedAt || permit.createdAt}
            </span>
          </div>
        </div>

        {/* 4. Core Permit Parameters (Contractor, Location, Work Scope, Time) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs relative z-10">
          <div className="bg-slate-950/90 print:bg-white p-3.5 rounded-2xl border border-slate-800 print:border-slate-300 space-y-1">
            <span className="text-slate-400 print:text-slate-600 flex items-center gap-1.5 font-bold">
              <HardHat className="w-4 h-4 text-amber-400" />
              <span>اسم المقاول / الجهة المنفذة:</span>
            </span>
            <p className="text-sm font-bold text-slate-100 print:text-black">
              {permit.contractorName}
            </p>
            {permit.contactPhone && (
              <span className="font-mono text-[11px] text-slate-400 print:text-slate-600 block" dir="ltr">
                هاتف: {permit.contactPhone}
              </span>
            )}
          </div>

          <div className="bg-slate-950/90 print:bg-white p-3.5 rounded-2xl border border-slate-800 print:border-slate-300 space-y-1">
            <span className="text-slate-400 print:text-slate-600 flex items-center gap-1.5 font-bold">
              <Building2 className="w-4 h-4 text-teal-400" />
              <span>الموقع والقسم المعني بالمستشفى:</span>
            </span>
            <p className="text-sm font-bold text-slate-100 print:text-black">
              {permit.department}
            </p>
            <span className="text-[11px] text-teal-400 print:text-teal-700 font-bold block">
              نوع العمل: {permit.workType === 'hot_work' ? 'أعمال ساخنة (لحام/لهب)' :
                         permit.workType === 'electrical' ? 'أعمال كهروميكانيكية' :
                         permit.workType === 'civil_maintenance' ? 'صيانة مدنية وإنشائية' :
                         permit.workType === 'medical_gas' ? 'شبكات غازات طبية' :
                         permit.workType === 'hvac' ? 'تكييف وتهوية مركزية' : 'أعمال عامة'}
            </span>
          </div>

          <div className="bg-slate-950/90 print:bg-white p-3.5 rounded-2xl border border-slate-800 print:border-slate-300 space-y-1">
            <span className="text-slate-400 print:text-slate-600 flex items-center gap-1.5 font-bold">
              <Calendar className="w-4 h-4 text-blue-400" />
              <span>فترة وساعات العمل المصرح بها:</span>
            </span>
            <div className="font-mono text-slate-200 print:text-black space-y-0.5">
              <div>
                من: <strong className="text-teal-300 print:text-teal-800">{permit.expectedStartDate.replace('T', ' ')}</strong>
              </div>
              <div>
                إلى: <strong className="text-teal-300 print:text-teal-800">{permit.expectedEndDate.replace('T', ' ')}</strong>
              </div>
              <div className="pt-1 text-[11px] text-amber-300 print:text-amber-800 font-bold">
                ساعات العمل اليومية: {permit.workingHours || '08:00 صباحاً - 04:00 عصراً'}
              </div>
            </div>
          </div>

          <div className="bg-slate-950/90 print:bg-white p-3.5 rounded-2xl border border-slate-800 print:border-slate-300 space-y-1">
            <span className="text-slate-400 print:text-slate-600 flex items-center gap-1.5 font-bold">
              <Users className="w-4 h-4 text-purple-400" />
              <span>عدد الكوادر المصرح لهم:</span>
            </span>
            <p className="text-sm font-bold text-slate-100 print:text-black">
              ({permit.workersCount}) عمال وفنيين مصرح لهم
            </p>
            <span className="text-[11px] text-slate-400 print:text-slate-600 block">
              مشرف التنفيذ: {permit.applicantName || permit.contractorName}
            </span>
          </div>
        </div>

        {/* 5. Work Scope & Details */}
        <div className="bg-slate-950/90 print:bg-white p-4 rounded-2xl border border-slate-800 print:border-slate-300 space-y-1.5 text-xs relative z-10">
          <span className="text-slate-400 print:text-slate-700 font-bold flex items-center gap-1.5">
            <FileText className="w-4 h-4 text-slate-400" />
            <span>طبيعة ونطاق الأعمال المعتمدة:</span>
          </span>
          <p className="text-slate-200 print:text-black leading-relaxed font-medium">
            {permit.workDescription}
          </p>
        </div>

        {/* 6. List of Authorized Workers (Crucial for Hospital Security Gate) */}
        <div className="bg-slate-950/90 print:bg-white p-4 rounded-2xl border border-slate-800 print:border-slate-300 space-y-2 text-xs relative z-10">
          <div className="flex items-center justify-between">
            <span className="text-slate-400 print:text-slate-700 font-bold flex items-center gap-1.5">
              <Users className="w-4 h-4 text-emerald-400" />
              <span>قائمة العمال المصرح لهم بالدخول ({permit.workersCount}):</span>
            </span>
            <span className="text-[10px] text-amber-400 print:text-amber-800 font-bold">
              مطابقة بطاقة الهوية إلزامية
            </span>
          </div>
          <div className="bg-slate-900/90 print:bg-slate-100 p-3 rounded-xl border border-slate-800/80 print:border-slate-300">
            <p className="text-slate-200 print:text-black whitespace-pre-line leading-relaxed font-mono text-[11px]">
              {permit.workersNames || 'العمال التابعين للمقاول المذكورين في تفويض المؤسسة'}
            </p>
          </div>
        </div>

        {/* 7. Mandatory OSH Precautions */}
        <div className="bg-slate-950/90 print:bg-white p-4 rounded-2xl border border-slate-800 print:border-slate-300 space-y-2.5 text-xs relative z-10">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-teal-400" />
            <h3 className="font-bold text-slate-200 print:text-black">
              اشتراطات ومعايير السلامة المهنية الإلزامية المطلوبة من المقاول:
            </h3>
          </div>

          <div className="grid grid-cols-1 gap-1.5">
            {precautions.map((item, idx) => (
              <div 
                key={idx} 
                className="flex items-start gap-2 text-slate-300 print:text-slate-800 bg-slate-900/60 print:bg-transparent p-2 rounded-xl"
              >
                <CheckCircle2 className="w-4 h-4 text-emerald-400 print:text-emerald-700 shrink-0 mt-0.5" />
                <span className="leading-snug text-[11px] font-medium">{item}</span>
              </div>
            ))}
          </div>
        </div>

        {/* 8. Security Guard Directives */}
        <div className="bg-amber-950/40 print:bg-amber-50 border border-amber-800/60 print:border-amber-400 p-3.5 rounded-2xl text-xs space-y-1 relative z-10">
          <div className="flex items-center gap-2 text-amber-300 print:text-amber-900 font-bold">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>تعليمات أمن البوابات والحراسة بمستشفى آزال:</span>
          </div>
          <p className="text-amber-200/90 print:text-amber-900 leading-relaxed text-[11px]">
            يُمنع منعاً باتاً دخول أي فني أو عامل غير وارد اسمه في هذا التصريح. يجب التأكد من ارتداء أحذية السلامة (Safety Shoes) والخوذات قبل السماح بالدخول، وإشعار ضابط السلامة فور بدء الأعمال الساخنة.
          </p>
        </div>

        {/* 9. Official Digital Stamp, Signature & QR Code */}
        <div className="border-t-2 border-slate-800 print:border-black pt-4 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs relative z-10">
          {/* QR Code for Instant Physical Verification */}
          <div className="flex items-center gap-3 bg-slate-950 print:bg-white p-2.5 rounded-2xl border border-slate-800 print:border-slate-300">
            <img
              src={`https://api.qrserver.com/v1/create-qr-code/?size=140x140&data=${encodeURIComponent(permitUrl)}`}
              alt="Verification QR Code"
              referrerPolicy="no-referrer"
              className="w-20 h-20 object-contain rounded-lg border print:border-black"
            />
            <div className="text-right">
              <span className="text-[10px] text-slate-400 print:text-slate-600 block">رمز التحقق الفوري (QR)</span>
              <strong className="text-slate-200 print:text-black text-[11px] block">امسح للتحقق المباشر</strong>
              <span className="text-[9px] font-mono text-emerald-400 print:text-emerald-800 block mt-0.5">
                AZAL-SECURE-VERIFIED
              </span>
            </div>
          </div>

          {/* Official Signatory & Seal */}
          <div className="text-center sm:text-left space-y-1">
            <span className="text-[10px] text-slate-400 print:text-slate-600 block">
              الاعتماد والتوقيع الرقمي الرسمي:
            </span>
            <strong className="text-xs text-slate-100 print:text-black block font-black">
              {permit.approvedBy || 'رئيس قسم الأمن والسلامة / م. نجيب غازي'}
            </strong>
            <span className="text-[11px] text-teal-400 print:text-teal-800 font-bold block">
              مستشفى آزال النموذجي - صنعاء
            </span>

            {/* Simulated Digital Security Seal Badge */}
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950 print:bg-emerald-100 text-emerald-300 print:text-emerald-900 border border-emerald-700 print:border-emerald-600 text-[10px] font-mono font-bold mt-1">
              <Lock className="w-3 h-3 text-emerald-400" />
              <span>DIGITALLY SIGNED & VERIFIED</span>
            </div>
          </div>
        </div>

        {/* Footer info */}
        <div className="border-t border-slate-800/60 print:border-slate-300 pt-3 flex items-center justify-between text-[10px] text-slate-500 print:text-slate-600 relative z-10">
          <span>مستشفى آزال النموذجي - ص.ب 15286 صنعاء، الجمهورية اليمنية</span>
          <span className="font-mono" dir="ltr">azal-safety-permit-v2</span>
        </div>
      </div>

      {/* Floating Action Bar (Bottom Mobile Bar - Hidden in print) */}
      <div className="w-full max-w-2xl mt-4 flex items-center justify-between gap-2 print:hidden">
        <button
          type="button"
          onClick={handlePrint}
          className="flex-1 py-3 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-200 text-xs font-bold flex items-center justify-center gap-2 transition shadow-lg"
        >
          <Printer className="w-4 h-4 text-teal-400" />
          <span>طباعة الوثيقة / PDF</span>
        </button>

        <button
          type="button"
          onClick={() => setShowShareOptions(true)}
          className="flex-1 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center justify-center gap-2 transition shadow-lg shadow-emerald-950"
        >
          <Share2 className="w-4 h-4" />
          <span>مشاركة عبر واتساب</span>
        </button>
      </div>
      </div>
    </div>
  );
};
