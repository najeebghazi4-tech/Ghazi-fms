import React, { useState } from 'react';
import { 
  HardHat, 
  Flame, 
  Users, 
  GraduationCap, 
  ShieldAlert, 
  Building2, 
  CheckCircle2, 
  ArrowLeft, 
  Share2, 
  Copy, 
  Check, 
  QrCode, 
  Phone, 
  ShieldCheck, 
  Search, 
  FileText, 
  Sparkles,
  AlertTriangle,
  HeartPulse,
  BadgeCheck,
  ChevronRight,
  ExternalLink,
  Info,
  Megaphone,
  Wind,
  Gauge
} from 'lucide-react';
import { ServicesHubPromoPosterModal } from '../ServicesHubPromoPosterModal';
import { AzalLogo } from '../AzalLogo';
import { getPublicAppBaseUrl } from '../../utils/phoneUtils';
import { GlobalPortalBackBar } from './GlobalPortalBackBar';

interface UnifiedServicesHubPortalProps {
  onNavigatePortal?: (portal: 'contractor' | 'incinerator' | 'new-hires' | 'training-nomination' | 'incident' | 'permit' | 'msds' | 'negative-pressure' | 'guidelines' | 'risk-matrix') => void;
}

export const UnifiedServicesHubPortal: React.FC<UnifiedServicesHubPortalProps> = ({
  onNavigatePortal,
}) => {
  const [permitSearchInput, setPermitSearchInput] = useState('');
  const [copiedLink, setCopiedLink] = useState(false);
  const [showQrModal, setShowQrModal] = useState(false);
  const [showPosterModal, setShowPosterModal] = useState(false);
  const [showTrainingSelectionModal, setShowTrainingSelectionModal] = useState(false);

  const navigateTo = (portal: 'contractor' | 'incinerator' | 'new-hires' | 'training-nomination' | 'incident' | 'permit' | 'msds' | 'negative-pressure' | 'guidelines' | 'risk-matrix', customId?: string) => {
    if (typeof window !== 'undefined') {
      if (portal === 'permit') {
        const query = customId ? `?id=${encodeURIComponent(customId.trim())}` : '';
        window.location.hash = `#permit${query}`;
      } else if (portal === 'incident') {
        window.location.hash = '#report';
      } else if (portal === 'contractor') {
        window.location.hash = '#contractor';
      } else if (portal === 'negative-pressure') {
        window.location.hash = '#negative-pressure';
      } else if (portal === 'guidelines') {
        window.location.hash = '#guidelines';
      } else if (portal === 'risk-matrix') {
        window.location.hash = '#risk-matrix';
      } else {
        window.location.hash = `#${portal}-portal`;
      }
    }
    if (onNavigatePortal) {
      onNavigatePortal(portal);
    }
  };

  const getHubUrl = () => {
    if (typeof window !== 'undefined' && window.location.origin) {
      return `${window.location.origin}/#services`;
    }
    return `${getPublicAppBaseUrl()}/#services`;
  };

  const handleCopyHubLink = async () => {
    const hubUrl = getHubUrl();
    try {
      if (navigator?.clipboard?.writeText) {
        await navigator.clipboard.writeText(hubUrl);
      } else {
        const textarea = document.createElement('textarea');
        textarea.value = hubUrl;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
      }
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  const handleShareWhatsAppHub = () => {
    const hubUrl = getHubUrl();
    const text = `🏥 مستشفى آزال النموذجي - بوابة الخدمات والتصاريح الموحدة لإدارة الأمن والسلامة والصحة المهنية:\n\nالحاوية الرقمية الشاملة لجميع الخدمات والتصاريح الميدانية:\n1. قسم المقاولين وتصاريح العمل (طلب تصريح عمل جديد والتحقق الميداني من السريان)\n2. قسم التدريب والتأهيل الميداني (توجيه الموظفين الجدد وترشيح كوادر الأقسام للتدريب)\n3. قسم البلاغات والتشغيل اليومي (تقديم بلاغ خطر/إفادة، وإشعار تشغيل المحرقة الطبية)\n\nرابط البوابة المباشر:\n${hubUrl}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans antialiased flex flex-col select-none overflow-x-hidden" dir="rtl">
      {/* Sticky Universal Header Back Bar */}
      <GlobalPortalBackBar
        title="بوابة الخدمات والتصاريح الموحدة"
        subtitle="مستشفى آزال النموذجي • إدارة الأمن والسلامة OSH & FMS"
        isHubPage={true}
      />

      <div className="max-w-5xl w-full mx-auto space-y-6 p-3 sm:p-6">
        
        {/* Top Header & Branding (Public Isolated Sandbox) */}
        <header className="bg-slate-900/90 border border-slate-800/90 rounded-3xl p-6 sm:p-8 text-center space-y-4 shadow-2xl relative overflow-hidden backdrop-blur-md">
          {/* Subtle Ambient Background Accent */}
          <div className="absolute -top-24 -right-24 w-72 h-72 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-24 -left-24 w-72 h-72 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

          {/* Logo & Department Seal */}
          <div className="flex flex-col items-center justify-center space-y-3">
            <div className="inline-block p-3 sm:p-4 bg-white/95 backdrop-blur-sm rounded-3xl shadow-2xl border border-slate-200 max-w-xs sm:max-w-md hover:scale-[1.02] transition-transform">
              <AzalLogo variant="horizontal" size="xl" transparent={true} />
            </div>

            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-800/90 text-teal-300 border border-slate-700/80 text-xs font-bold shadow-inner">
              <ShieldCheck className="w-4 h-4 text-teal-400" />
              <span>مستشفى آزال • الرعاية الكاملة • إدارة السلامة والمرافق (FMS)</span>
            </div>
          </div>

          {/* Main Title & Subtitle */}
          <div className="space-y-2 max-w-2xl mx-auto">
            <h1 className="text-xl sm:text-2xl lg:text-3xl font-black text-slate-100 tracking-tight leading-snug">
              بوابة الخدمات والتصاريح الموحدة
            </h1>
            <p className="text-sm sm:text-base text-slate-300 font-medium">
              الحاوية الشاملة المعتمدة لجميع الخدمات الخارجية، تصاريح العمل، التدريب الميداني، وبلاغات السلامة
            </p>
          </div>

          {/* Supervisory Info & Quick Actions */}
          <div className="pt-2 flex flex-wrap items-center justify-center gap-2.5 text-xs">
            <div className="px-3.5 py-1.5 rounded-xl bg-slate-950/80 border border-slate-800 text-slate-300 flex items-center gap-1.5">
              <BadgeCheck className="w-4 h-4 text-teal-400" />
              <span>إشراف: <strong>م/ نجيب قاسم غازي</strong> (رئيس قسم السلامة وإدارة المرافق FMS)</span>
            </div>

            <button
              type="button"
              onClick={handleShareWhatsAppHub}
              className="px-3.5 py-1.5 rounded-xl bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 font-bold flex items-center gap-1.5 transition cursor-pointer shadow-sm active:scale-95"
              title="مشاركة رابط البوابة عبر واتساب"
            >
              <Share2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>مشاركة البوابة</span>
            </button>

            <button
              type="button"
              onClick={handleCopyHubLink}
              className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 font-bold flex items-center gap-1.5 transition cursor-pointer active:scale-95"
              title="نسخ الرابط المباشر"
            >
              {copiedLink ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">تم النسخ!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-slate-400" />
                  <span>نسخ الرابط (#services)</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => navigateTo('guidelines')}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-600 via-orange-600 to-rose-600 hover:from-amber-500 hover:to-rose-500 text-white font-black flex items-center gap-1.5 transition cursor-pointer shadow-md active:scale-95 ring-1 ring-amber-300/40"
              title="مركز التعليمات والإرشادات والتحذيرات (Safety Guidelines & Hazard Alerts Center)"
            >
              <AlertTriangle className="w-3.5 h-3.5 text-amber-200" />
              <span>إرشادات وتحذيرات السلامة ⚠️</span>
            </button>

            <button
              type="button"
              onClick={() => setShowPosterModal(true)}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-600 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 font-black flex items-center gap-1.5 transition cursor-pointer shadow-md active:scale-95 ring-1 ring-amber-300/50"
              title="عرض وتوليد بوستر إعلان البوابة الرسمي A4 للطباعة والتحميل"
            >
              <Megaphone className="w-3.5 h-3.5 text-slate-950" />
              <span>بوستر إعلان البوابة (A4)</span>
            </button>

            <button
              type="button"
              onClick={() => setShowQrModal(true)}
              className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 font-bold flex items-center gap-1.5 transition cursor-pointer active:scale-95"
              title="عرض رمز QR"
            >
              <QrCode className="w-3.5 h-3.5 text-teal-400" />
              <span>رمز QR</span>
            </button>
          </div>
        </header>

        {/* 3 Main Categorized Service Sections */}
        <main className="space-y-6">

          {/* Section A: قسم المقاولين وتصاريح العمل */}
          <section className="bg-gradient-to-br from-amber-950/30 via-slate-900 to-slate-900 border border-amber-800/50 hover:border-amber-600/70 rounded-3xl p-5 sm:p-7 shadow-2xl transition-all duration-200 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-amber-900/30 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-amber-950/90 text-amber-400 border border-amber-700/70 flex items-center justify-center shadow-lg shrink-0">
                  <HardHat className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-amber-950 text-amber-300 border border-amber-700/60">
                      القسم الأول
                    </span>
                    <h2 className="text-lg font-black text-slate-100">
                      قسم المقاولين وتصاريح العمل
                    </h2>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    إصدار تفويضات الأعمال الميدانية، تصاريح العمل الحار والمرتفعات، والتحقق الميداني لبوابات الحراسة
                  </p>
                </div>
              </div>

              <div className="text-[11px] font-mono text-amber-300/80 bg-slate-950/60 px-3 py-1.5 rounded-xl border border-amber-900/40 w-fit">
                #contractor & #permit
              </div>
            </div>

            {/* Quick Permit Search & Verification Bar */}
            <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 flex flex-col md:flex-row items-center justify-between gap-3 shadow-inner">
              <div className="flex items-center gap-2.5 text-right w-full md:w-auto">
                <ShieldCheck className="w-5 h-5 text-amber-400 shrink-0" />
                <span className="text-xs text-slate-300 font-bold">
                  فحص سريان تصريح مقاول بالرقم أو الكود:
                </span>
              </div>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  navigateTo('permit', permitSearchInput);
                }}
                className="w-full md:w-auto flex items-center gap-2"
              >
                <input
                  type="text"
                  value={permitSearchInput}
                  onChange={(e) => setPermitSearchInput(e.target.value)}
                  placeholder="رقم التصريح (مثال: AZAL-CTR-2026-001)"
                  className="w-full md:w-64 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-100 placeholder-slate-500 font-mono focus:outline-none focus:border-amber-500"
                  dir="ltr"
                />
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-slate-950 font-black text-xs flex items-center gap-1.5 transition cursor-pointer shadow-md shrink-0 active:scale-95"
                >
                  <Search className="w-3.5 h-3.5" />
                  <span>فحص</span>
                </button>
              </form>
            </div>

            {/* The 2 Primary Action Buttons */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
              {/* Button 1: تصريح المقاول الخارجي */}
              <button
                type="button"
                onClick={() => navigateTo('contractor')}
                className="group p-5 rounded-2xl bg-gradient-to-r from-amber-950/70 to-slate-900 hover:from-amber-900/60 hover:to-slate-800/90 border border-amber-700/60 hover:border-amber-500 text-right space-y-2 transition-all duration-200 shadow-lg hover:shadow-xl cursor-pointer active:scale-[0.98]"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold shadow-md group-hover:scale-105 transition">
                      <HardHat className="w-5 h-5" />
                    </div>
                    <span className="font-bold text-sm text-slate-100 group-hover:text-amber-300 transition">
                      تصريح المقاول الخارجي
                    </span>
                  </div>
                  <ArrowLeft className="w-4 h-4 text-amber-400 group-hover:-translate-x-1 transition" />
                </div>
                <p className="text-xs text-slate-300 leading-relaxed pr-11">
                  يفتح نموذج تصريح العمل الحار، المرتفعات، الحفر، والأعمال المدنية لتسجيل المشرف وتفويض العمال
                </p>
                <div className="flex items-center gap-2 pr-11 text-[11px] text-amber-400/90 font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>إلزامي قبل مباشرة أي أعمال داخل المستشفى</span>
                </div>
              </button>

              {/* Button 2: التحقق من سريان التصريح */}
              <button
                type="button"
                onClick={() => navigateTo('permit')}
                className="group p-5 rounded-2xl bg-gradient-to-r from-slate-900 to-amber-950/40 hover:from-slate-800 hover:to-amber-900/50 border border-slate-700 hover:border-amber-500 text-right space-y-2 transition-all duration-200 shadow-lg hover:shadow-xl cursor-pointer active:scale-[0.98]"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-slate-800 text-amber-400 border border-amber-600/50 flex items-center justify-center font-bold shadow-md group-hover:scale-105 transition">
                      <ShieldCheck className="w-5 h-5" />
                    </div>
                    <span className="font-bold text-sm text-slate-100 group-hover:text-amber-300 transition">
                      التحقق من سريان التصريح
                    </span>
                  </div>
                  <ArrowLeft className="w-4 h-4 text-amber-400 group-hover:-translate-x-1 transition" />
                </div>
                <p className="text-xs text-slate-300 leading-relaxed pr-11">
                  فحص صلاحية الكود ورقم التصريح، التحقق من التوقيع والختم المعتمد، والتفويض الأمني لحراسة البوابة
                </p>
                <div className="flex items-center gap-2 pr-11 text-[11px] text-teal-400 font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>معاينة البطاقة الرقمية الرسمية وتصديرها</span>
                </div>
              </button>
            </div>
          </section>

          {/* Section B: قسم التدريب والتأهيل الميداني (بطاقة موحدة للتدريب) */}
          <section className="bg-gradient-to-br from-teal-950/30 via-slate-900 to-slate-900 border border-teal-800/50 hover:border-teal-600/70 rounded-3xl p-5 sm:p-7 shadow-2xl transition-all duration-200 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-teal-900/30 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-teal-950/90 text-teal-400 border border-teal-700/70 flex items-center justify-center shadow-lg shrink-0">
                  <GraduationCap className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-teal-950 text-teal-300 border border-teal-700/60">
                      القسم الثاني • بطاقة موحدة
                    </span>
                    <h2 className="text-lg font-black text-slate-100">
                      قسم التدريب والتأهيل الميداني
                    </h2>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    البرامج التأهيلية لكوادر الأقسام، تدريب التوجيه الأولي، وبناء فرق الاستجابة لمكافحة الحرائق والإخلاء
                  </p>
                </div>
              </div>

              <div className="text-[11px] font-mono text-teal-300/80 bg-slate-950/60 px-3 py-1.5 rounded-xl border border-teal-900/40 w-fit">
                #training & #new-hires
              </div>
            </div>

            {/* Unified Training Options Container */}
            <div className="bg-slate-950/80 border border-teal-900/40 rounded-2xl p-4 sm:p-5 space-y-4 shadow-inner">
              <div className="flex items-center justify-between text-xs text-teal-300 font-bold border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-teal-400" />
                  <span>اختر مسار التدريب والتأهيل المطلوب:</span>
                </div>
                <span className="text-[11px] text-slate-400 font-normal">
                  انقر على أي من الخيارين لفتح النموذج المعتمد
                </span>
              </div>

              {/* The 2 Clear Training Choices */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {/* Option 1: تدريب وتوجيه الموظفين الجدد (Orientation) */}
                <div
                  onClick={() => navigateTo('new-hires')}
                  className="group p-4 rounded-xl bg-slate-900 hover:bg-slate-800/90 border border-teal-800/40 hover:border-teal-500 transition-all duration-150 flex flex-col justify-between cursor-pointer space-y-3 shadow-md hover:shadow-teal-950/50"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg bg-teal-950 text-teal-400 border border-teal-700/60 flex items-center justify-center font-bold">
                          <Users className="w-4 h-4" />
                        </div>
                        <span className="text-[11px] font-bold text-teal-300 bg-teal-950/80 px-2 py-0.5 rounded border border-teal-800/60">
                          الخيار 1
                        </span>
                      </div>
                      <ArrowLeft className="w-4 h-4 text-teal-400 group-hover:-translate-x-1 transition" />
                    </div>

                    <h3 className="font-bold text-sm text-slate-100 group-hover:text-teal-300 transition">
                      تدريب وتوجيه الموظفين الجدد (Orientation)
                    </h3>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      إشعار قسم السلامة بوصول موظفين جدد من الموارد البشرية لجدولة التدريب الإلزامي على أكواد الطوارئ والإخلاء.
                    </p>
                  </div>

                  <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400 font-medium">
                    <span>يشمل التعريف بخطة الطوارئ ومسارات النجاة</span>
                    <span className="text-teal-400 font-bold group-hover:underline">فتح النموذج ←</span>
                  </div>
                </div>

                {/* Option 2: ترشيح الموظفين للتدريب على السلامة */}
                <div
                  onClick={() => navigateTo('training-nomination')}
                  className="group p-4 rounded-xl bg-slate-900 hover:bg-slate-800/90 border border-teal-800/40 hover:border-teal-500 transition-all duration-150 flex flex-col justify-between cursor-pointer space-y-3 shadow-md hover:shadow-teal-950/50"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-lg bg-teal-950 text-teal-400 border border-teal-700/60 flex items-center justify-center font-bold">
                          <GraduationCap className="w-4 h-4" />
                        </div>
                        <span className="text-[11px] font-bold text-teal-300 bg-teal-950/80 px-2 py-0.5 rounded border border-teal-800/60">
                          الخيار 2
                        </span>
                      </div>
                      <ArrowLeft className="w-4 h-4 text-teal-400 group-hover:-translate-x-1 transition" />
                    </div>

                    <h3 className="font-bold text-sm text-slate-100 group-hover:text-teal-300 transition">
                      ترشيح الموظفين للتدريب على السلامة
                    </h3>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      ترشيح مسؤولي وكوادر الأقسام للدورات التخصصية في مكافحة الحرائق، الإنعاش القلبي، الإسعافات، والإخلاء الطبي.
                    </p>
                  </div>

                  <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400 font-medium">
                    <span>بناء فرق الاستجابة السريعة وتوثيق الساعات</span>
                    <span className="text-teal-400 font-bold group-hover:underline">فتح النموذج ←</span>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Section C: قسم البلاغات والتشغيل اليومي */}
          <section className="bg-gradient-to-br from-emerald-950/30 via-slate-900 to-slate-900 border border-emerald-800/50 hover:border-emerald-600/70 rounded-3xl p-5 sm:p-7 shadow-2xl transition-all duration-200 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-emerald-900/30 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-emerald-950/90 text-emerald-400 border border-emerald-700/70 flex items-center justify-center shadow-lg shrink-0">
                  <ShieldAlert className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-emerald-950 text-emerald-300 border border-emerald-700/60">
                      القسم الثالث
                    </span>
                    <h2 className="text-lg font-black text-slate-100">
                      قسم البلاغات والتشغيل اليومي
                    </h2>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    الرصد الفوري لملاحظات ومخاطر السلامة، وتقديم الإفادات، وإشعارات تشغيل محرقة النفايات الطبية
                  </p>
                </div>
              </div>

              <div className="text-[11px] font-mono text-emerald-300/80 bg-slate-950/60 px-3 py-1.5 rounded-xl border border-emerald-900/40 w-fit">
                #report & #incinerator
              </div>
            </div>

            {/* The 2 Primary Action Buttons */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
              {/* Button 1: تقديم بلاغ خطر / إفادة حادث */}
              <button
                type="button"
                onClick={() => navigateTo('incident')}
                className="group p-5 rounded-2xl bg-gradient-to-r from-emerald-950/70 to-slate-900 hover:from-emerald-900/60 hover:to-slate-800/90 border border-emerald-700/60 hover:border-emerald-500 text-right space-y-2 transition-all duration-200 shadow-lg hover:shadow-xl cursor-pointer active:scale-[0.98]"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold shadow-md group-hover:scale-105 transition">
                      <ShieldAlert className="w-5 h-5" />
                    </div>
                    <span className="font-bold text-sm text-slate-100 group-hover:text-emerald-300 transition">
                      تقديم بلاغ خطر / إفادة حادث
                    </span>
                  </div>
                  <ArrowLeft className="w-4 h-4 text-emerald-400 group-hover:-translate-x-1 transition" />
                </div>
                <p className="text-xs text-slate-300 leading-relaxed pr-11">
                  الربط المباشر مع استمارة البلاغات والإفادات الرسمية للإبلاغ عن أي تسرب، تعثر، مخاطر كهربائية أو إفادات حوادث
                </p>
                <div className="flex items-center gap-2 pr-11 text-[11px] text-emerald-400/90 font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>إرسال فوري مع تنبيه واتساب و SMS لطوارئ السلامة</span>
                </div>
              </button>

              {/* Button 2: إشعار تشغيل المحرقة والنفايات الطبية */}
              <button
                type="button"
                onClick={() => navigateTo('incinerator')}
                className="group p-5 rounded-2xl bg-gradient-to-r from-slate-900 to-rose-950/40 hover:from-slate-800 hover:to-rose-900/50 border border-slate-700 hover:border-rose-500 text-right space-y-2 transition-all duration-200 shadow-lg hover:shadow-xl cursor-pointer active:scale-[0.98]"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-slate-800 text-rose-400 border border-rose-700/60 flex items-center justify-center font-bold shadow-md group-hover:scale-105 transition">
                      <Flame className="w-5 h-5" />
                    </div>
                    <span className="font-bold text-sm text-slate-100 group-hover:text-rose-300 transition">
                      إشعار تشغيل المحرقة والنفايات الطبية
                    </span>
                  </div>
                  <ArrowLeft className="w-4 h-4 text-rose-400 group-hover:-translate-x-1 transition" />
                </div>
                <p className="text-xs text-slate-300 leading-relaxed pr-11">
                  توثيق دورة الحرق الآمن، كميات وأوزان النفايات الطبية الخطرة، وفحص الفلاتر ودرجات حرارة التشغيل
                </p>
                <div className="flex items-center gap-2 pr-11 text-[11px] text-rose-400/90 font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>سجل بيئي وصحي يومي معتمد لمعايير الجودة والرقابة</span>
                </div>
              </button>
            </div>
          </section>

          {/* Section D: سلامة غرف العزل بالضغط السلبي واختبار الدخان (CBAHI FMS) */}
          <section className="bg-gradient-to-br from-cyan-950/30 via-slate-900 to-slate-900 border border-cyan-800/50 hover:border-cyan-600/70 rounded-3xl p-5 sm:p-7 shadow-2xl transition-all duration-200 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-cyan-900/30 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-cyan-950/90 text-cyan-400 border border-cyan-700/70 flex items-center justify-center shadow-lg shrink-0">
                  <Wind className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-cyan-950 text-cyan-300 border border-cyan-700/60">
                      معايير سباهي CBAHI
                    </span>
                    <h2 className="text-lg font-black text-slate-100">
                      سلامة غرف العزل بالضغط السلبي (Negative Pressure & Smoke Test)
                    </h2>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    فحص فرق الضغط التفاضلي، اختبار تيار الدخان (Smoke Trail)، وإحكام العزل لغرف عزل العناية المركزة والمناظير ومختبر الدرن
                  </p>
                </div>
              </div>

              <div className="text-[11px] font-mono text-cyan-300/80 bg-slate-950/60 px-3 py-1.5 rounded-xl border border-cyan-900/40 w-fit">
                #negative-pressure
              </div>
            </div>

            {/* Action Button */}
            <div className="pt-1">
              <button
                type="button"
                onClick={() => navigateTo('negative-pressure')}
                className="w-full group p-5 rounded-2xl bg-gradient-to-r from-cyan-950/70 to-slate-900 hover:from-cyan-900/60 hover:to-slate-800/90 border border-cyan-700/60 hover:border-cyan-500 text-right space-y-2 transition-all duration-200 shadow-lg hover:shadow-xl cursor-pointer active:scale-[0.98]"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-cyan-600 text-slate-950 flex items-center justify-center font-bold shadow-md group-hover:scale-105 transition">
                      <Gauge className="w-5 h-5" />
                    </div>
                    <span className="font-bold text-sm text-slate-100 group-hover:text-cyan-300 transition">
                      فتح واجهة فحص وتوثيق غرف العزل واختبار شريط الدخان
                    </span>
                  </div>
                  <ArrowLeft className="w-4 h-4 text-cyan-400 group-hover:-translate-x-1 transition" />
                </div>
                <p className="text-xs text-slate-300 leading-relaxed pr-11">
                  تسجيل قراءات فرق الضغط اليومية (Pascals)، اختبار اتجاه تدفق الدخان إلى الداخل، فحص سلامة جوان وسدادات الأبواب، والتنبيه التلقائي في حال تسرب الضغط الإيجابي
                </p>
                <div className="flex items-center gap-2 pr-11 text-[11px] text-cyan-400/90 font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>معتمد لمعايير مكافحة العدوى والاعتماد الوطني FMS / IPC</span>
                </div>
              </button>
            </div>
          </section>

          {/* Section E: مركز التعليمات والإرشادات والتحذيرات (Safety Guidelines & Hazard Alerts Center) */}
          <section className="bg-gradient-to-br from-rose-950/30 via-slate-900 to-slate-900 border border-rose-800/50 hover:border-rose-600/70 rounded-3xl p-5 sm:p-7 shadow-2xl transition-all duration-200 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-rose-900/30 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-rose-950/90 text-rose-400 border border-rose-700/70 flex items-center justify-center shadow-lg shrink-0">
                  <AlertTriangle className="w-6 h-6 animate-pulse" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-rose-950 text-rose-300 border border-rose-700/60">
                      معايير سباهي CBAHI FMS
                    </span>
                    <h2 className="text-lg font-black text-slate-100">
                      مركز التعليمات والإرشادات والتحذيرات (Safety Guidelines & Alerts)
                    </h2>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    التحذيرات والمحظورات العاجلة، بروتوكولات طوارئ الحريق (RACE & PASS)، وضوابط السلامة المهنية والبيئية
                  </p>
                </div>
              </div>

              <div className="text-[11px] font-mono text-rose-300/80 bg-slate-950/60 px-3 py-1.5 rounded-xl border border-rose-900/40 w-fit">
                #guidelines
              </div>
            </div>

            {/* 3 Interactive Category Highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-rose-900/40 space-y-1">
                <div className="text-xs font-black text-rose-300 flex items-center gap-1.5">
                  <span>🛑 المحظورات العاجلة</span>
                </div>
                <p className="text-[11px] text-slate-400 leading-snug">
                  حظر إغلاق مسالك ومخارج الطوارئ (FMS.23)، منع التدخين، والتوصيلات العشوائية
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-amber-900/40 space-y-1">
                <div className="text-xs font-black text-amber-300 flex items-center gap-1.5">
                  <span>📋 بروتوكول RACE & PASS</span>
                </div>
                <p className="text-[11px] text-slate-400 leading-snug">
                  إجراءات الاستجابة للحريق وتشغيل الطفايات وخطوط الطوارئ السريعة المباشرة
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-emerald-900/40 space-y-1">
                <div className="text-xs font-black text-emerald-300 flex items-center gap-1.5">
                  <span>☣️ السلامة المهنية والبيئية</span>
                </div>
                <p className="text-[11px] text-slate-400 leading-snug">
                  أطقم الانسكابات (Spill Kits)، مهمات الوقاية PPE، وتصاريح العمل الساخن
                </p>
              </div>
            </div>

            {/* Action Trigger */}
            <div className="pt-1">
              <button
                type="button"
                onClick={() => navigateTo('guidelines')}
                className="w-full group p-5 rounded-2xl bg-gradient-to-r from-rose-950/70 to-slate-900 hover:from-rose-900/60 hover:to-slate-800/90 border border-rose-700/60 hover:border-rose-500 text-right space-y-2 transition-all duration-200 shadow-lg hover:shadow-xl cursor-pointer active:scale-[0.98]"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-rose-600 text-white flex items-center justify-center font-bold shadow-md group-hover:scale-105 transition">
                      <AlertTriangle className="w-5 h-5" />
                    </div>
                    <span className="font-bold text-sm text-slate-100 group-hover:text-rose-300 transition">
                      دخول مركز التعليمات والإرشادات وطباعة الدليل الورقي A4 المعتمد
                    </span>
                  </div>
                  <ArrowLeft className="w-4 h-4 text-rose-400 group-hover:-translate-x-1 transition" />
                </div>
                <p className="text-xs text-slate-300 leading-relaxed pr-11">
                  تصفح كافة التحذيرات التفاعلية وتوليد دليل إرشادات السلامة السريع A4 موقعاً من م/ نجيب قاسم غازي (رئيس قسم السلامة وإدارة المرافق FMS) للتعليق في الأقسام
                </p>
                <div className="flex items-center gap-2 pr-11 text-[11px] text-rose-400/90 font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>معتمد للتعليق في محطات التمريض وغرف العمليات ومكاتب الأقسام</span>
                </div>
              </button>
            </div>
          </section>

          {/* Section F: سجل ومصفوفة تقييم المخاطر الشاملة (Hospital Risk Assessment & Matrix 5x5) */}
          <section className="bg-gradient-to-br from-teal-950/30 via-slate-900 to-slate-900 border border-teal-800/50 hover:border-teal-600/70 rounded-3xl p-5 sm:p-7 shadow-2xl transition-all duration-200 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-teal-900/30 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-teal-950/90 text-teal-400 border border-teal-700/70 flex items-center justify-center shadow-lg shrink-0">
                  <ShieldAlert className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-teal-950 text-teal-300 border border-teal-700/60">
                      معايير سباهي CBAHI FMS.1
                    </span>
                    <h2 className="text-lg font-black text-slate-100">
                      سجل ومصفوفة تقييم المخاطر الشاملة (Hospital 5×5 Risk Matrix)
                    </h2>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    تحليل احتمالية وشدة الأثر للمخاطر الهندسية والطبية والحرائق والمواد الخطرة والأمن مع خطط المعالجة CAP والتصدير المعتمد
                  </p>
                </div>
              </div>

              <div className="text-[11px] font-mono text-teal-300/80 bg-slate-950/60 px-3 py-1.5 rounded-xl border border-teal-900/40 w-fit">
                #risk-matrix
              </div>
            </div>

            {/* Action Button */}
            <div className="pt-1">
              <button
                type="button"
                onClick={() => navigateTo('risk-matrix')}
                className="w-full group p-5 rounded-2xl bg-gradient-to-r from-teal-950/70 to-slate-900 hover:from-teal-900/60 hover:to-slate-800/90 border border-teal-700/60 hover:border-teal-500 text-right space-y-2 transition-all duration-200 shadow-lg hover:shadow-xl cursor-pointer active:scale-[0.98]"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center font-bold shadow-md group-hover:scale-105 transition">
                      <ShieldAlert className="w-5 h-5" />
                    </div>
                    <span className="font-bold text-sm text-slate-100 group-hover:text-teal-300 transition">
                      فتح لوحة وسجل مصفوفة المخاطر الشاملة (5×5 Risk Heatmap)
                    </span>
                  </div>
                  <ArrowLeft className="w-4 h-4 text-teal-400 group-hover:-translate-x-1 transition" />
                </div>
                <p className="text-xs text-slate-300 leading-relaxed pr-11">
                  تقييم المخاطر اللحظي، خريطة المصفوفة الحرارية التفاعلية، تحديث مؤشرات السيطرة والتقييم المتبقي، وتصدير سجل المخاطر الرسمي PDF بتوقيع رئيس السلامة والجودة
                </p>
                <div className="flex items-center gap-2 pr-11 text-[11px] text-teal-400/90 font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>معتمد للجودة والاعتماد الوطني والمستشفيات النموذجية CBAHI / JCI</span>
                </div>
              </button>
            </div>
          </section>

        </main>

        {/* Security & Emergency Protocol Footer Card */}
        <footer className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-6 text-xs space-y-4 shadow-xl">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 border-b border-slate-800 pb-4">
            <div className="flex items-center gap-3 text-right">
              <div className="w-10 h-10 rounded-2xl bg-rose-950/80 border border-rose-800 text-rose-400 flex items-center justify-center shrink-0">
                <HeartPulse className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <h4 className="font-bold text-slate-100 text-sm">خط الطوارئ الداخلي المباشر للسلامة</h4>
                <p className="text-slate-400 text-[11px]">في حالات الحريق، تسرب الغازات، أو الأكواد الطارئة بمستشفى آزال</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <a
                href="tel:96777738138"
                className="px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold flex items-center gap-1.5 transition shadow-sm active:scale-95"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>اتصال الطوارئ (96777738138)</span>
              </a>
              <button
                type="button"
                onClick={() => {
                  const text = 'مرحباً، بلاغ طارئ موجه إلى إدارة الأمن والسلامة بمستشفى آزال النموذجي:';
                  window.open(`https://wa.me/96777738138?text=${encodeURIComponent(text)}`, '_blank', 'noopener,noreferrer');
                }}
                className="px-3.5 py-2 rounded-xl bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 font-bold flex items-center gap-1.5 transition active:scale-95 cursor-pointer"
              >
                <Share2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>واتساب الطوارئ</span>
              </button>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-2 text-slate-400 text-[11px]">
            <p>
              بوابة الخدمات والتصاريح الموحدة هي المنصة الرقمية المعتمدة لجميع النماذج الخارجية والربط المباشر مع إدارة السلامة.
            </p>
            <span className="font-mono text-slate-400">
              © مستشفى آزال النموذجي - صنعاء | الإصدار 3.0
            </span>
          </div>
        </footer>

      </div>

      {/* QR Code Modal for Physical Gate Posters */}
      {showQrModal && (
        <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                <QrCode className="w-4 h-4 text-teal-400" />
                <span>رمز الاستجابة السريعة (QR Code)</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowQrModal(false)}
                className="text-slate-400 hover:text-slate-200 text-base cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="bg-white p-4 rounded-2xl inline-block shadow-inner">
              <img
                src={`https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(getHubUrl())}`}
                alt="QR Code للبوابة الموحدة"
                className="w-48 h-48 mx-auto"
              />
            </div>

            <p className="text-xs text-slate-300">
              امسح الرمز بكاميرا الهاتف للوصول الفوري إلى بوابة الخدمات والتصاريح الموحدة لإدارة السلامة بمستشفى آزال.
            </p>

            <div className="bg-slate-950 border border-teal-800 rounded-xl p-2 text-left">
              <div className="text-[10px] text-slate-400 font-bold mb-0.5 text-right">الرابط المعتمد للبوابة (Target URL):</div>
              <div className="text-xs text-teal-300 font-mono font-bold select-all break-all" dir="ltr">
                {getHubUrl()}
              </div>
            </div>

            <div className="space-y-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setShowQrModal(false);
                  setShowPosterModal(true);
                }}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-amber-600 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 font-black text-xs flex items-center justify-center gap-2 transition cursor-pointer shadow-md"
              >
                <Megaphone className="w-4 h-4 text-slate-950" />
                <span>📢 فتح وتوليد بوستر الإعلان الرسمي (A4 Portrait)</span>
              </button>

              <div className="flex items-center justify-center gap-2">
                <button
                  type="button"
                  onClick={handleCopyHubLink}
                  className="flex-1 px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>نسخ الرابط</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowQrModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition cursor-pointer"
                >
                  إغلاق
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      {/* Services Hub Promo Poster Modal */}
      <ServicesHubPromoPosterModal
        isOpen={showPosterModal}
        onClose={() => setShowPosterModal(false)}
      />
    </div>
  );
};
