import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  Lock, 
  ShieldCheck, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  TrendingUp, 
  Printer, 
  Flame, 
  HardHat, 
  GraduationCap, 
  FileText, 
  RefreshCw, 
  ExternalLink,
  ChevronRight,
  Eye,
  LogOut,
  Sparkles,
  Download,
  Share2
} from 'lucide-react';
import { 
  SafetyViolationNotice, 
  SafetyTourRecord, 
  FireExtinguisherItem, 
  SafetyIncidentReport, 
  ContractorPermitNotice, 
  IncineratorOperationNotice, 
  TrainingNominationNotice,
  StaffUser
} from '../../types';
import { AzalLogo } from '../AzalLogo';
import { GeneralManagerReportsView } from '../GeneralManagerReportsView';
import { cloudSync, SyncStatus } from '../../services/cloudSyncService';
import { getPublicAppBaseUrl } from '../../utils/phoneUtils';
import { GlobalPortalBackBar } from './GlobalPortalBackBar';

interface GeneralDirectorExecutivePortalProps {
  violations: SafetyViolationNotice[];
  tours: SafetyTourRecord[];
  extinguishers: FireExtinguisherItem[];
  incidents: SafetyIncidentReport[];
  permits: ContractorPermitNotice[];
  incineratorBatches: IncineratorOperationNotice[];
  trainingNominations: TrainingNominationNotice[];
  isOnline: boolean;
  onExit?: () => void;
}

export const GeneralDirectorExecutivePortal: React.FC<GeneralDirectorExecutivePortalProps> = ({
  violations,
  tours,
  extinguishers,
  incidents,
  permits,
  incineratorBatches,
  trainingNominations,
  isOnline,
  onExit
}) => {
  // Pin authentication state: 1234 or 8888 required
  const [isUnlocked, setIsUnlocked] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      if (sessionStorage.getItem('azal_gm_unlocked') === 'true') return true;
      const search = window.location.search.toLowerCase();
      const hash = window.location.hash.toLowerCase();
      if (
        search.includes('pin=1234') ||
        search.includes('pin=8888') ||
        hash.includes('pin=1234') ||
        hash.includes('pin=8888') ||
        search.includes('auth=gm') ||
        hash.includes('auth=gm')
      ) {
        sessionStorage.setItem('azal_gm_unlocked', 'true');
        return true;
      }
    }
    return false;
  });
  const [pin, setPin] = useState('');
  const [pinError, setPinError] = useState('');
  const [syncStatus, setSyncStatus] = useState<SyncStatus>('connected');
  const [lastSyncedAt, setLastSyncedAt] = useState<number>(Date.now());
  const [activeTab, setActiveTab] = useState<'kpi' | 'violations' | 'official_report' | 'portals'>('kpi');

  // General Director staff representation
  const executiveUser: StaffUser = {
    id: 'GM-01',
    name: 'د/ محمد السراجي',
    nameEn: 'Dr. Mohammed Al-Saraji',
    role: 'general_director',
    roleTitleAr: 'مدير عام المستشفى',
    badgeNumber: 'AZAL-GM-01',
    department: 'الإدارة العامة',
    pin: '1234',
    avatarColor: 'bg-amber-600',
  };

  useEffect(() => {
    const unsub = cloudSync.subscribeStatus((status, time) => {
      setSyncStatus(status);
      setLastSyncedAt(time);
    });
    return unsub;
  }, []);

  const handleDigit = (digit: string) => {
    if (pin.length < 4) {
      const newPin = pin + digit;
      setPin(newPin);
      setPinError('');
      if (newPin.length === 4) {
        verifyPin(newPin);
      }
    }
  };

  const handleBackspace = () => {
    setPin(prev => prev.slice(0, -1));
    setPinError('');
  };

  const verifyPin = (code: string) => {
    if (code === '8888' || code === '1234') {
      setIsUnlocked(true);
      sessionStorage.setItem('azal_gm_unlocked', 'true');
      setPinError('');
    } else {
      setPinError('الرمز السري غير صحيح. يرجى إدخال رمز المرور السري المصرح للمدير العام');
      setTimeout(() => setPin(''), 500);
    }
  };

  const handleLogout = () => {
    sessionStorage.removeItem('azal_gm_unlocked');
    setIsUnlocked(false);
    setPin('');
  };

  // Metric calculations
  const totalViolations = violations.length;
  const resolvedCount = violations.filter(v => v.status === 'resolved' || v.status === 'responded').length;
  const overdueCount = violations.filter(v => v.status === 'overdue').length;
  const pendingCount = violations.filter(v => v.status === 'pending').length;
  const complianceRate = totalViolations > 0 ? Math.round((resolvedCount / totalViolations) * 100) : 100;

  const validExtinguishers = extinguishers.filter(e => e.conditionStatus === 'valid' && e.gaugeStatus === 'normal').length;
  const extinguisherRate = extinguishers.length > 0 ? Math.round((validExtinguishers / extinguishers.length) * 100) : 100;

  // ---------------------------------------------------------------------------
  // 1. PIN Lock Screen for Executive Director
  // ---------------------------------------------------------------------------
  if (!isUnlocked) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between select-none dir-rtl font-sans" dir="rtl">
        <GlobalPortalBackBar
          title="بوابة الإدارة العامة الرقابية (Director Portal)"
          subtitle="مستشفى آزال النموذجي • شاشة التحقق من هوية المدير العام"
          showServicesLink={true}
          onCustomBack={onExit}
        />
        <div className="flex-1 flex flex-col justify-between p-4 sm:p-6">
        <div className="w-full max-w-sm mx-auto text-center pt-4 flex flex-col items-center">
          <AzalLogo variant="horizontal" />
          
          <div className="mt-4 inline-flex items-center gap-2 bg-amber-950/80 border border-amber-700/80 text-amber-300 px-3.5 py-1 rounded-full text-xs font-bold shadow-lg">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
            <span>بوابة الإدارة العامة • Direct Executive Portal</span>
          </div>

          <h1 className="text-lg font-black text-slate-100 mt-3 flex items-center justify-center gap-2">
            <Lock className="w-4 h-4 text-amber-400" />
            <span>دخول الأخ الدكتور / محمد السراجي (مدير عام المستشفى)</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-xs leading-relaxed">
            للوصول إلى المؤشرات الرقابية اللحظية وتقارير السلامة المزامنة سحابياً، يرجى إدخال رمز المرور السري المصرح للمدير العام
          </p>

          <div className="mt-2 flex items-center gap-2 text-[11px] text-emerald-400 font-mono">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span>مزامنة سحابية نشطة (Firebase Cloud Sync ⚡)</span>
          </div>
        </div>

        {/* Keypad */}
        <div className="w-full max-w-xs mx-auto flex flex-col items-center my-auto py-4">
          <div className="flex justify-center items-center gap-3 mb-6 dir-ltr">
            {[0, 1, 2, 3].map((i) => {
              const isFilled = pin.length > i;
              return (
                <div
                  key={i}
                  className={`w-11 h-12 rounded-xl border-2 flex items-center justify-center transition-all ${
                    isFilled
                      ? 'border-amber-500 bg-amber-950/40 text-amber-300 scale-105 shadow-md shadow-amber-950/50'
                      : 'border-slate-800 bg-slate-900/60 text-slate-600'
                  }`}
                >
                  {isFilled ? <span className="text-xl font-black">●</span> : <span className="text-slate-700">―</span>}
                </div>
              );
            })}
          </div>

          {pinError && (
            <div className="w-full mb-3 p-2 bg-rose-950/60 border border-rose-800 text-rose-300 text-xs rounded-xl text-center font-medium animate-shake">
              {pinError}
            </div>
          )}

          <div className="grid grid-cols-3 gap-2.5 w-full">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
              <button
                key={digit}
                type="button"
                onClick={() => handleDigit(digit)}
                className="h-14 rounded-2xl bg-slate-900/90 hover:bg-amber-950/40 active:bg-amber-900/60 border border-slate-800 hover:border-amber-700/60 text-lg font-black text-slate-100 transition shadow-sm active:scale-95 flex items-center justify-center"
              >
                {digit}
              </button>
            ))}
            <button
              type="button"
              onClick={() => setPin('')}
              className="h-14 rounded-2xl bg-slate-900/60 hover:bg-slate-800 border border-slate-800 text-xs font-bold text-slate-400 transition active:scale-95 flex items-center justify-center"
            >
              مسح
            </button>
            <button
              type="button"
              onClick={() => handleDigit('0')}
              className="h-14 rounded-2xl bg-slate-900/90 hover:bg-amber-950/40 active:bg-amber-900/60 border border-slate-800 hover:border-amber-700/60 text-lg font-black text-slate-100 transition shadow-sm active:scale-95 flex items-center justify-center"
            >
              0
            </button>
            <button
              type="button"
              onClick={handleBackspace}
              className="h-14 rounded-2xl bg-slate-900/60 hover:bg-slate-800 border border-slate-800 text-xs font-bold text-slate-300 transition active:scale-95 flex items-center justify-center"
            >
              ⌫ حذف
            </button>
          </div>
        </div>

        <div className="text-center pb-2">
          {onExit && (
            <button
              type="button"
              onClick={onExit}
              className="text-xs text-slate-400 hover:text-slate-200 underline"
            >
              العودة إلى الشاشة الرئيسية
            </button>
          )}
        </div>
        </div>
      </div>
    );
  }

  // ---------------------------------------------------------------------------
  // 2. Unlocked Executive Director Dashboard (Read-Only Mode)
  // ---------------------------------------------------------------------------
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans select-text pb-12" dir="rtl">
      {/* Universal Sticky Back Bar */}
      <GlobalPortalBackBar
        title="لوحة المتابعة الرقابية للإدارة العامة • د. محمد السراجي"
        subtitle="مستشفى آزال النموذجي • منظومة المتابعة والاعتماد الرقابي المباشر"
        showServicesLink={true}
        onCustomBack={onExit}
      />

      {/* Top Executive Header */}
      <header className="no-print sticky top-12 z-30 bg-slate-950/95 backdrop-blur-md border-b border-amber-900/40 px-3 sm:px-6 py-3 shadow-xl">
        <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <AzalLogo size="md" showText={false} />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-sm sm:text-base font-black text-slate-100">
                  لوحة المتابعة الرقابية للإدارة العامة • مستشفى آزال النموذجي
                </h1>
                <span className="text-[10px] bg-amber-950 border border-amber-700 text-amber-300 px-2 py-0.5 rounded-full font-bold">
                  صاحب الصلاحية • Read-Only
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                الأخ الدكتور / محمد السراجي (مدير عام المستشفى) • متابعة لحظية ومساءلة الأقسام عن بعد
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Cloud Sync Status Badge */}
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-950/60 border border-emerald-800/80 text-emerald-300 text-xs font-mono">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span>مزامَن سحابياً ⚡</span>
            </div>

            <button
              type="button"
              onClick={() => window.location.reload()}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 transition"
              title="تحديث البيانات"
            >
              <RefreshCw className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={handleLogout}
              className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-rose-950 hover:text-rose-300 hover:border-rose-800 border border-slate-800 text-xs font-bold text-slate-400 transition flex items-center gap-1"
              title="قفل الشاشة"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>قفل</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-6xl w-full mx-auto px-3 sm:px-6 py-4 space-y-5">
        {/* Strict Read-Only Notification Banner */}
        <div className="no-print bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-900 border border-amber-800/60 rounded-2xl p-3 px-4 flex flex-wrap items-center justify-between gap-3 text-xs text-amber-200">
          <div className="flex items-center gap-2.5">
            <Eye className="w-4 h-4 text-amber-400 shrink-0" />
            <span>
              <strong>نمط المتابعة والاعتماد الرقابي (Executive Read-Only):</strong> يتم تحديث هذه الشاشة تلقائياً بالبيانات المدخلة من قبل رئيس قسم الأمن والسلامة (م/ نجيب غازي) ومشرفي المستشفى عبر السحابة.
            </span>
          </div>
          <span className="text-[11px] font-mono text-slate-400">
            آخر مزامنة: {new Date(lastSyncedAt).toLocaleTimeString('ar-EG')}
          </span>
        </div>

        {/* Tab Navigation Switcher */}
        <div className="no-print flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3">
          <button
            type="button"
            onClick={() => setActiveTab('kpi')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
              activeTab === 'kpi'
                ? 'bg-amber-600 text-white shadow-lg shadow-amber-950'
                : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
            }`}
          >
            <TrendingUp className="w-4 h-4" />
            <span>المؤشرات والجاهزية ({totalViolations})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('violations')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
              activeTab === 'violations'
                ? 'bg-amber-600 text-white shadow-lg shadow-amber-950'
                : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
            }`}
          >
            <AlertTriangle className="w-4 h-4" />
            <span>المخالفات ومساءلة الأقسام ({overdueCount} متأخرة 🔴)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('official_report')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
              activeTab === 'official_report'
                ? 'bg-amber-600 text-white shadow-lg shadow-amber-950'
                : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>تقرير السلامة الرسمي للطباعة A4</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('portals')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
              activeTab === 'portals'
                ? 'bg-amber-600 text-white shadow-lg shadow-amber-950'
                : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
            }`}
          >
            <HardHat className="w-4 h-4" />
            <span>المقاولون والمحرقة والتدريب ({permits.length + incineratorBatches.length + trainingNominations.length})</span>
          </button>
        </div>

        {/* =========================================================================
         * TAB 1: EXECUTIVE KPI & METRICS OVERVIEW
         * ========================================================================= */}
        {activeTab === 'kpi' && (
          <div className="space-y-4 animate-in fade-in duration-200">
            {/* KPI Cards Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              {/* Card 1: Tours */}
              <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl text-center space-y-1">
                <span className="text-xs text-slate-400 block font-medium">الجولات المنفذة</span>
                <span className="text-2xl font-black font-mono text-slate-100 block">{tours.length}</span>
                <span className="text-[10px] text-teal-400 font-bold block">جولة تفتيشية</span>
              </div>

              {/* Card 2: Extinguishers */}
              <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl text-center space-y-1">
                <span className="text-xs text-slate-400 block font-medium">الطفايات المفحوصة</span>
                <span className="text-2xl font-black font-mono text-slate-100 block">{extinguishers.length}</span>
                <span className="text-[10px] text-blue-400 font-bold block">{extinguisherRate}% جاهزية</span>
              </div>

              {/* Card 3: Total Violations */}
              <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl text-center space-y-1">
                <span className="text-xs text-slate-400 block font-medium">إجمالي الملاحظات</span>
                <span className="text-2xl font-black font-mono text-slate-100 block">{totalViolations}</span>
                <span className="text-[10px] text-amber-400 font-bold block">مرصودة بالنظام</span>
              </div>

              {/* Card 4: Resolved */}
              <div className="bg-emerald-950/30 border border-emerald-800/60 p-4 rounded-2xl text-center space-y-1">
                <span className="text-xs text-emerald-300 block font-medium">المخالفات المنجزة 🟢</span>
                <span className="text-2xl font-black font-mono text-emerald-400 block">{resolvedCount}</span>
                <span className="text-[10px] text-emerald-400/80 font-bold block">{complianceRate}% إنجاز</span>
              </div>

              {/* Card 5: Overdue */}
              <div className="bg-rose-950/40 border-2 border-rose-800 p-4 rounded-2xl text-center space-y-1">
                <span className="text-xs text-rose-300 block font-black">المتأخرة / لم يُرد 🔴</span>
                <span className="text-2xl font-black font-mono text-rose-400 block">{overdueCount}</span>
                <span className="text-[10px] text-rose-400 font-bold block">تستوجب المساءلة</span>
              </div>

              {/* Card 6: Pending */}
              <div className="bg-amber-950/30 border border-amber-800/60 p-4 rounded-2xl text-center space-y-1">
                <span className="text-xs text-amber-300 block font-medium">قيد المتابعة 🟡</span>
                <span className="text-2xl font-black font-mono text-amber-400 block">{pendingCount}</span>
                <span className="text-[10px] text-amber-400 font-bold block">ضمن المهلة</span>
              </div>
            </div>

            {/* Live Incidents Alert Banner (if any) */}
            {incidents.length > 0 && (
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold text-slate-200 flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-teal-400" />
                    <span>سجل بلاغات وحوادث السلامة المسجلة حديثاً</span>
                  </h3>
                  <span className="text-xs text-slate-400 font-mono">({incidents.length}) بلاغ</span>
                </div>
                <div className="space-y-2">
                  {incidents.slice(0, 3).map((inc) => (
                    <div key={inc.id} className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
                      <div>
                        <strong className="text-slate-200 block">{inc.incidentType} - {inc.location}</strong>
                        <span className="text-[11px] text-slate-400">{inc.description}</span>
                      </div>
                      <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono text-[10px]">
                        {inc.createdAt}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* =========================================================================
         * TAB 2: DETAILED VIOLATIONS & DEPARTMENT ACCOUNTABILITY TABLE
         * ========================================================================= */}
        {activeTab === 'violations' && (
          <div className="space-y-3 animate-in fade-in duration-200">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                <span>جدول المخالفات والإشعارات الرقابية وحالة تفاعل الأقسام</span>
              </h2>
              <span className="text-xs text-slate-400 font-mono">
                إجمالي ({violations.length}) إشعار مسجل
              </span>
            </div>

            <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-900">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="bg-slate-950 border-b border-slate-800 text-slate-300 font-bold">
                    <th className="p-3 w-12 text-center">م</th>
                    <th className="p-3 w-28">رقم الإشعار</th>
                    <th className="p-3">القسم والموقع</th>
                    <th className="p-3">المسؤول / المكلف</th>
                    <th className="p-3 w-24">المهلة</th>
                    <th className="p-3">وصف المخالفة</th>
                    <th className="p-3 w-48">الموقف الإداري</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {violations.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="p-8 text-center text-slate-400 text-xs">
                        لا توجد إشعارات مخالفات مسجلة حالياً - النظام جاهز للعمل الفعلي الميداني
                      </td>
                    </tr>
                  ) : (
                    violations.map((v, idx) => {
                    const isOverdue = v.status === 'overdue';
                    const isResolved = v.status === 'resolved' || v.status === 'responded';
                    const isPending = v.status === 'pending';

                    return (
                      <tr 
                        key={v.id} 
                        className={
                          isOverdue 
                            ? 'bg-rose-950/20 border-r-4 border-r-rose-600' 
                            : isResolved 
                            ? 'bg-emerald-950/10' 
                            : 'bg-amber-950/10'
                        }
                      >
                        <td className="p-3 text-center font-mono font-bold text-slate-400">{idx + 1}</td>
                        <td className="p-3 font-mono font-bold text-slate-300">{v.id}</td>
                        <td className="p-3">
                          <strong className="text-slate-100 block">{v.department}</strong>
                          <span className="text-[11px] text-slate-400">{v.locationDetail}</span>
                        </td>
                        <td className="p-3 text-slate-300">
                          {v.assignedToCustom || v.assignedTo}
                        </td>
                        <td className="p-3 font-mono text-[11px] text-slate-400">
                          {v.deadlineHours} ساعة
                        </td>
                        <td className="p-3 text-slate-200 leading-relaxed max-w-xs">
                          {v.description}
                          {v.resolutionNote && (
                            <div className="mt-1 text-[11px] text-emerald-300 bg-emerald-950/40 p-1 rounded">
                              إفادة: {v.resolutionNote}
                            </div>
                          )}
                        </td>
                        <td className="p-3">
                          {isOverdue && (
                            <div className="p-2 rounded-xl bg-rose-900/60 border border-rose-600 text-rose-100 space-y-0.5">
                              <span className="font-bold text-[11px] block">🔴 تقصير إداري / متأخر</span>
                              <span className="text-[10px] block font-black">"معلق / لم يتم الرد حتى تاريخه"</span>
                            </div>
                          )}
                          {isResolved && (
                            <div className="p-2 rounded-xl bg-emerald-950/40 border border-emerald-800 text-emerald-300 font-bold text-[11px]">
                              🟢 تم الإنجاز والمعالجة
                            </div>
                          )}
                          {isPending && (
                            <div className="p-2 rounded-xl bg-amber-950/40 border border-amber-800 text-amber-300 font-bold text-[11px]">
                              🟡 قيد الإجراء والمتابعة
                            </div>
                          )}
                        </td>
                      </tr>
                    );
                  }))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* =========================================================================
         * TAB 3: OFFICIAL EXECUTIVE REPORT READY FOR PRINT (A4)
         * ========================================================================= */}
        {activeTab === 'official_report' && (
          <div className="space-y-3 animate-in fade-in duration-200">
            <GeneralManagerReportsView
              tours={tours}
              violations={violations}
              extinguishers={extinguishers}
              currentUser={executiveUser}
            />
          </div>
        )}

        {/* =========================================================================
         * TAB 4: CONTRACTORS, INCINERATOR, AND TRAINING PORTALS
         * ========================================================================= */}
        {activeTab === 'portals' && (
          <div className="space-y-4 animate-in fade-in duration-200">
            {/* 1. Contractor Work Permits */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-amber-300 flex items-center gap-2">
                  <HardHat className="w-4 h-4 text-amber-400" />
                  <span>تصاريح أعمال مقاولي المستشفى (Contractor Work Permits)</span>
                </h3>
                <span className="text-xs text-slate-400 font-mono">({permits.length}) تصريح</span>
              </div>
              {permits.length === 0 ? (
                <div className="p-4 text-center text-slate-500 text-xs bg-slate-950/60 rounded-xl border border-slate-800/80">
                  لا توجد تصاريح أعمال مقاولين مسجلة حالياً
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {permits.map(p => (
                    <div key={p.id} className="bg-slate-950 border border-slate-800 p-3 rounded-xl space-y-1 text-xs">
                      <div className="flex justify-between items-center">
                        <strong className="text-slate-100">{p.contractorName}</strong>
                        <span className="font-mono text-amber-400 text-[10px]">{p.id}</span>
                      </div>
                      <div className="text-slate-400">نوع العمل: {p.workType} • الموقع: {p.workLocation}</div>
                      <div className="text-[10px] text-teal-400 font-mono">تاريخ البدء: {p.startDate} - الانتهاء: {p.endDate}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* 2. Medical Incinerator Logs */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-rose-300 flex items-center gap-2">
                  <Flame className="w-4 h-4 text-rose-400" />
                  <span>سجلات تشغيل المحرقة الطبية وإتلاف النفايات (Incinerator Batches)</span>
                </h3>
                <span className="text-xs text-slate-400 font-mono">({incineratorBatches.length}) دفعة</span>
              </div>
              {incineratorBatches.length === 0 ? (
                <div className="p-4 text-center text-slate-500 text-xs bg-slate-950/60 rounded-xl border border-slate-800/80">
                  لا توجد دفعات تشغيل محرقة مسجلة حالياً
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {incineratorBatches.map(b => (
                    <div key={b.id} className="bg-slate-950 border border-slate-800 p-3 rounded-xl space-y-1 text-xs">
                      <div className="flex justify-between items-center">
                        <strong className="text-slate-100 font-mono">دفعة #{b.batchNumber}</strong>
                        <span className="font-mono text-emerald-400 text-xs font-bold">{b.weightKg} كجم</span>
                      </div>
                      <div className="text-slate-400">المشغل: {b.operatorName} • النوع: {b.wasteType}</div>
                      <div className="text-[10px] text-slate-500 font-mono">درجة الحرارة: {b.furnaceTempC}°C • التاريخ: {b.createdAt}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* 3. Training Nominations */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-teal-300 flex items-center gap-2">
                  <GraduationCap className="w-4 h-4 text-teal-400" />
                  <span>ترشيحات تدريب السلامة والصحة المهنية (Training Nominations)</span>
                </h3>
                <span className="text-xs text-slate-400 font-mono">({trainingNominations.length}) مرشح</span>
              </div>
              {trainingNominations.length === 0 ? (
                <div className="p-4 text-center text-slate-500 text-xs bg-slate-950/60 rounded-xl border border-slate-800/80">
                  لا توجد ترشيحات دورات تدريبية مسجلة حالياً
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {trainingNominations.map(t => (
                    <div key={t.id} className="bg-slate-950 border border-slate-800 p-3 rounded-xl space-y-1 text-xs">
                      <div className="flex justify-between items-center">
                        <strong className="text-slate-100">{t.staffName}</strong>
                        <span className="text-teal-400 font-mono text-[10px]">{t.department}</span>
                      </div>
                      <div className="text-slate-400">الدورة: {t.courseName}</div>
                      <div className="text-[10px] text-slate-500 font-mono">تاريخ التسجيل: {t.createdAt}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
