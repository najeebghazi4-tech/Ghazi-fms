import React, { useState, useEffect } from 'react';
import { 
  Award, 
  Send, 
  CheckCircle2, 
  QrCode, 
  Phone, 
  User, 
  Copy, 
  Check, 
  AlertTriangle, 
  Calendar, 
  Plus, 
  Trash2, 
  Share2, 
  Building2, 
  Clock, 
  Flame, 
  ShieldAlert, 
  Biohazard, 
  HeartHandshake 
} from 'lucide-react';
import { TrainingNominationNotice, NominatedStaff } from '../../types';
import { AZAL_DEPARTMENTS } from '../../data/azalSafetyUpgradeData';
import { AzalLogo } from '../AzalLogo';
import { 
  sanitizeInput, 
  checkRateLimit, 
  generateSecureUuid 
} from '../../utils/securityUtils';
import { cleanYemeniPhoneNumber, getPublicAppBaseUrl } from '../../utils/phoneUtils';
import { GlobalPortalBackBar } from './GlobalPortalBackBar';

interface TrainingNominationPortalProps {
  onSubmitNotice: (notice: TrainingNominationNotice) => void;
}

const TRAINING_PROGRAMS = [
  {
    id: 'firefighting_rescue',
    title: 'مكافحة الحرائق، استخدام الطفايات، وخطط الإخلاء الطبي',
    icon: Flame,
    color: 'text-amber-400 border-amber-500'
  },
  {
    id: 'emergency_codes',
    title: 'أكواد الطوارئ المعتمدة بمستشفى آزال (Code Red, Blue, Yellow)',
    icon: ShieldAlert,
    color: 'text-rose-400 border-rose-500'
  },
  {
    id: 'osh_standards',
    title: 'معايير السلامة والصحة المهنية (CBAHI / JCI / FMS)',
    icon: Award,
    color: 'text-teal-400 border-teal-500'
  },
  {
    id: 'biosafety',
    title: 'السلامة الحيوية وإدارة الانسكابات الكيميائية والدموية (HazMat)',
    icon: Biohazard,
    color: 'text-purple-400 border-purple-500'
  },
  {
    id: 'evacuation_hazmat',
    title: 'الإسعافات الأولية والتعامل مع الإصابات المهنية الحادة',
    icon: HeartHandshake,
    color: 'text-emerald-400 border-emerald-500'
  }
];

export const TrainingNominationPortal: React.FC<TrainingNominationPortalProps> = ({
  onSubmitNotice,
}) => {
  // Sandbox security
  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.history.pushState(null, document.title, window.location.href);
      const handlePopState = () => {
        window.history.pushState(null, document.title, window.location.href);
      };
      window.addEventListener('popstate', handlePopState);
      return () => {
        window.removeEventListener('popstate', handlePopState);
      };
    }
  }, []);

  const [selectedDept, setSelectedDept] = useState(AZAL_DEPARTMENTS[0]);
  const [isCustomDept, setIsCustomDept] = useState(false);
  const [customDept, setCustomDept] = useState('');
  const [supervisorName, setSupervisorName] = useState('');
  const [supervisorPhone, setSupervisorPhone] = useState('');
  const [trainingProgram, setTrainingProgram] = useState('emergency_codes');
  const [trainingProgramCustom, setTrainingProgramCustom] = useState('');
  const [proposedDate, setProposedDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 3);
    return d.toISOString().slice(0, 10);
  });
  const [proposedShift, setProposedShift] = useState<'morning' | 'evening' | 'night'>('morning');
  const [justification, setJustification] = useState('');

  // Nominees list
  const [nominees, setNominees] = useState<NominatedStaff[]>([
    {
      id: 'nom-1',
      fullName: '',
      jobTitle: '',
      phone: ''
    }
  ]);

  const [submitted, setSubmitted] = useState(false);
  const [submittedNotice, setSubmittedNotice] = useState<TrainingNominationNotice | null>(null);
  const [showQrModal, setShowQrModal] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [securityError, setSecurityError] = useState<string | null>(null);

  const portalUrl = `${getPublicAppBaseUrl()}/#training-nomination-portal`;

  const handleAddNominee = () => {
    setNominees([
      ...nominees,
      {
        id: `nom-${Date.now()}-${nominees.length + 1}`,
        fullName: '',
        jobTitle: '',
        phone: ''
      }
    ]);
  };

  const handleRemoveNominee = (id: string) => {
    if (nominees.length <= 1) return;
    setNominees(nominees.filter(n => n.id !== id));
  };

  const handleUpdateNominee = (id: string, field: keyof NominatedStaff, value: string) => {
    setNominees(nominees.map(n => n.id === id ? { ...n, [field]: value } : n));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSecurityError(null);

    const rateLimit = checkRateLimit('nomination_notice_submit', 5, 60000);
    if (!rateLimit.allowed) {
      setSecurityError(rateLimit.message || 'تم تجاوز الحد الأقصى للمحاولات، يرجى الانتظار.');
      return;
    }

    const cleanSupervisor = sanitizeInput(supervisorName);
    if (!cleanSupervisor) {
      setSecurityError('يرجى كتابة اسم رئيس القسم أو المشرف المرشح.');
      return;
    }

    const cleanPhone = cleanYemeniPhoneNumber(supervisorPhone);

    const validNominees = nominees.filter(n => n.fullName.trim().length > 0);
    if (validNominees.length === 0) {
      setSecurityError('يرجى إدخال اسم مرشح واحد على الأقل للدورة.');
      return;
    }

    const sanitizedNominees: NominatedStaff[] = validNominees.map((n, i) => ({
      id: n.id || `nom-${i}`,
      fullName: sanitizeInput(n.fullName),
      jobTitle: sanitizeInput(n.jobTitle) || 'كادر طبي / فني',
      phone: cleanYemeniPhoneNumber(n.phone) || n.phone
    }));

    const finalDept = isCustomDept && customDept.trim() ? sanitizeInput(customDept) : selectedDept;
    const selectedProgObj = TRAINING_PROGRAMS.find(p => p.id === trainingProgram);
    const progTitle = selectedProgObj?.title || sanitizeInput(trainingProgramCustom) || 'برنامج تدريب السلامة';

    const secureSuffix = generateSecureUuid().split('-')[0].toUpperCase();
    const newNoticeId = `AZAL-NOM-${new Date().getFullYear()}-${secureSuffix}`;

    const newNotice: TrainingNominationNotice = {
      id: newNoticeId,
      requestingDepartment: finalDept,
      supervisorName: cleanSupervisor,
      supervisorPhone: cleanPhone || supervisorPhone,
      trainingProgram: trainingProgram as any,
      trainingProgramTitleAr: progTitle,
      proposedDate,
      proposedShift,
      nominees: sanitizedNominees,
      justification: sanitizeInput(justification) || undefined,
      status: 'received',
      createdAt: `${new Date().toLocaleDateString('ar-EG')} ${new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}`,
      timestamp: Date.now(),
      synced: true,
    };

    onSubmitNotice(newNotice);
    setSubmittedNotice(newNotice);
    setSubmitted(true);
  };

  const resetForm = () => {
    setNominees([
      {
        id: `nom-${Date.now()}`,
        fullName: '',
        jobTitle: '',
        phone: ''
      }
    ]);
    setJustification('');
    setSubmittedNotice(null);
    setSubmitted(false);
  };

  const handleCopyLink = async () => {
    try {
      if (navigator?.clipboard?.writeText) {
        await navigator.clipboard.writeText(portalUrl);
      } else {
        const textarea = document.createElement('textarea');
        textarea.value = portalUrl;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
      }
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  const handleSendWhatsAppToAdmin = () => {
    if (!submittedNotice) return;
    const n = submittedNotice;
    const shiftAr = n.proposedShift === 'morning' ? 'الوردية الصباحية' : n.proposedShift === 'evening' ? 'الوردية المسائية' : 'الوردية الليلية';

    const nomineesText = n.nominees.map((nm, idx) => {
      return `${idx + 1}. *${nm.fullName}* - ${nm.jobTitle}${nm.phone ? ` (هاتف: ${nm.phone})` : ''}`;
    }).join('\n');

    const text = `🏥 *مستشفى آزال النموذجي - إدارة الأمن والسلامة*
🎖️ *استمارة ترشيح كوادر للدورات التدريبية*
---------------------------------------
🔖 *رقم الاستمارة:* ${n.id}
🏢 *القسم الطالب:* ${n.requestingDepartment}
👤 *المشرف المرشح:* ${n.supervisorName}
📞 *هاتف المشرف:* ${n.supervisorPhone}
📚 *البرنامج المطلوب:* ${n.trainingProgramTitleAr}
📅 *الموعد المقترح:* ${n.proposedDate} (${shiftAr})
👥 *عدد المرشحين:* ${n.nominees.length} كادر
📋 *أسماء الكوادر المرشحة:*
${nomineesText}
${n.justification ? `\n💡 *مبررات الترشيح:* ${n.justification}` : ''}
---------------------------------------
🌐 الرابط المباشر للبوابة:
${portalUrl}

يرجى إدراج المرشحين ضمن جدول الدورات واعتماد التنسيق مع القسم المعني.`;

    const shareUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
    window.open(shareUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between text-right" dir="rtl">
      {/* Sticky Universal Header Back Bar */}
      <GlobalPortalBackBar
        title="استمارة ترشيح الكوادر للدورات التدريبية"
        subtitle="مستشفى آزال النموذجي • مركز التعليم المستمر وإدارة السلامة"
        showServicesLink={true}
        actions={
          <button
            type="button"
            onClick={() => setShowQrModal(true)}
            className="px-2.5 py-1 sm:px-3 sm:py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 text-xs font-bold flex items-center gap-1.5 transition"
          >
            <QrCode className="w-3.5 h-3.5 text-purple-400" />
            <span className="hidden sm:inline">رمز QR</span>
          </button>
        }
      />

      <div className="flex-1 flex flex-col justify-between py-6 px-3 sm:px-4">
      {/* Header */}
      <header className="max-w-2xl w-full mx-auto flex items-center justify-between pb-4 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="p-1 bg-white rounded-xl shadow-sm border border-slate-200">
            <AzalLogo size="xs" showText={false} />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="text-xs font-black text-slate-100">
                مستشفى آزال
              </h2>
              <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-700/60">
                الرعاية الكاملة
              </span>
            </div>
            <span className="text-[10px] text-purple-400 font-bold block">مركز التعليم الطبي المستمر والسلامة المهنية (FMS)</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowQrModal(true)}
            className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 text-xs font-bold flex items-center gap-1.5 transition"
          >
            <QrCode className="w-4 h-4 text-purple-400" />
            <span className="hidden sm:inline">رمز QR للبوابة</span>
          </button>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-2xl w-full mx-auto my-auto py-6">
        <div className="text-center space-y-2 mb-6">
          <div className="inline-block p-2.5 sm:p-3 bg-white/95 backdrop-blur-sm rounded-2xl shadow-lg border border-slate-200 mb-1 max-w-xs hover:scale-105 transition-transform">
            <AzalLogo variant="horizontal" size="md" transparent={true} />
          </div>
          <h1 className="text-lg font-black text-slate-100">
            استمارة ترشيح الكوادر للدورات التدريبية
          </h1>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-950/80 text-purple-300 border border-purple-800 text-xs font-bold">
            <Award className="w-4 h-4 text-purple-400" />
            <span>ترشيح رؤساء الأقسام لكوادرهم (مباشر بدون تسجيل دخول)</span>
          </div>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            تتيح هذه البوابة لرؤساء الأقسام الطبية والتمريضية والإدارية ترشيح موظفيهم لحضور ورش السلامة ومكافحة الحرائق.
          </p>
        </div>

        {submitted && submittedNotice ? (
          /* Confirmation Card */
          <div className="bg-slate-900 border border-emerald-600/70 rounded-3xl p-6 text-center space-y-5 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-700 flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 className="w-9 h-9" />
            </div>

            <div>
              <h2 className="text-base font-bold text-slate-100">
                تم إرسال الإشعار بنجاح إلى إدارة الأمن والسلامة
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                تم تسجيل ترشيح كوادركم وسيتواصل معكم قسم التدريب والسلامة لتأكيد الموعد والقاعة.
              </p>
            </div>

            {/* Summary */}
            <div className="bg-slate-950 border border-slate-800 p-4 rounded-2xl text-right space-y-2 text-xs">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-slate-400">رقم الاستمارة:</span>
                <strong className="text-purple-400 font-mono text-sm">{submittedNotice.id}</strong>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">القسم الطالب:</span>
                <span className="font-bold text-slate-200">{submittedNotice.requestingDepartment}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">البرنامج التدريبي:</span>
                <span className="font-bold text-purple-300">{submittedNotice.trainingProgramTitleAr}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">عدد المرشحين:</span>
                <span className="font-mono text-emerald-400 font-bold">{submittedNotice.nominees.length} كادر</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">الموعد المقترح:</span>
                <span className="font-mono text-slate-200">{submittedNotice.proposedDate}</span>
              </div>
            </div>

            {/* Actions */}
            <div className="space-y-2 pt-1">
              <button
                type="button"
                onClick={handleSendWhatsAppToAdmin}
                className="w-full py-3.5 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-950 flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <Share2 className="w-4 h-4" />
                <span>إرسال نسخة للإدارة عبر واتساب</span>
              </button>

              <button
                type="button"
                onClick={resetForm}
                className="w-full py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition cursor-pointer"
              >
                تقديم ترشيح دورة أخرى
              </button>

              <a
                href="#services"
                className="w-full py-2.5 rounded-2xl bg-slate-900 border border-slate-700 hover:bg-slate-800 text-slate-300 font-bold text-xs transition cursor-pointer flex items-center justify-center gap-2"
              >
                <span>العودة لبوابة الخدمات الموحدة (#services)</span>
              </a>
            </div>
          </div>
        ) : (
          <form
            onSubmit={handleSubmit}
            className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 space-y-4 shadow-xl text-xs"
          >
            {securityError && (
              <div className="p-3 bg-rose-950/80 border border-rose-800 rounded-xl text-rose-300 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{securityError}</span>
              </div>
            )}

            {/* Department */}
            <div>
              <label className="block text-slate-200 font-bold mb-1.5">
                القسم الطالب للتدريب <span className="text-purple-400">*</span>
              </label>
              {!isCustomDept ? (
                <div className="space-y-2">
                  <select
                    value={selectedDept}
                    onChange={(e) => {
                      if (e.target.value === '__other__') {
                        setIsCustomDept(true);
                      } else {
                        setSelectedDept(e.target.value);
                      }
                    }}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-slate-100 text-xs focus:outline-none focus:border-purple-500"
                  >
                    {AZAL_DEPARTMENTS.map((dept) => (
                      <option key={dept} value={dept}>
                        {dept}
                      </option>
                    ))}
                    <option value="__other__">+ قسم آخر (كتابة يدوية)</option>
                  </select>
                </div>
              ) : (
                <div className="space-y-2">
                  <input
                    type="text"
                    value={customDept}
                    onChange={(e) => setCustomDept(e.target.value)}
                    placeholder="اكتب اسم القسم..."
                    className="w-full bg-slate-950 border border-purple-800/80 rounded-xl px-3 py-2.5 text-slate-100 text-xs focus:outline-none focus:border-purple-500"
                  />
                  <button
                    type="button"
                    onClick={() => setIsCustomDept(false)}
                    className="text-[11px] text-purple-400 underline"
                  >
                    العودة للقائمة المعتمدة
                  </button>
                </div>
              )}
            </div>

            {/* Supervisor Info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-200 font-bold mb-1">
                  اسم رئيس القسم / المشرف المرشح <span className="text-purple-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={supervisorName}
                  onChange={(e) => setSupervisorName(e.target.value)}
                  placeholder="الاسم الكامل للمشرف"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-slate-100 text-xs focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-slate-200 font-bold mb-1">
                  رقم هاتف المشرف للتنسيق <span className="text-purple-400">*</span>
                </label>
                <input
                  type="tel"
                  required
                  value={supervisorPhone}
                  onChange={(e) => setSupervisorPhone(e.target.value)}
                  placeholder="9677XXXXXXXX"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-slate-100 text-xs font-mono focus:outline-none focus:border-purple-500"
                  dir="ltr"
                />
              </div>
            </div>

            {/* Training Program */}
            <div>
              <label className="block text-slate-200 font-bold mb-2">
                البرنامج التدريبي المطلوب <span className="text-purple-400">*</span>
              </label>
              <div className="space-y-2">
                {TRAINING_PROGRAMS.map((prog) => {
                  const Icon = prog.icon;
                  const isSelected = trainingProgram === prog.id;
                  return (
                    <button
                      key={prog.id}
                      type="button"
                      onClick={() => setTrainingProgram(prog.id)}
                      className={`w-full p-3 rounded-2xl border text-right flex items-center gap-3 transition ${
                        isSelected 
                          ? 'bg-purple-950/70 border-purple-500 text-purple-200 shadow-md' 
                          : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <Icon className={`w-5 h-5 shrink-0 ${isSelected ? 'text-purple-400' : 'text-slate-500'}`} />
                      <span className="font-semibold text-xs leading-relaxed">{prog.title}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Proposed Date & Shift */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-200 font-bold mb-1">
                  الموعد المقترح للتدريب <span className="text-purple-400">*</span>
                </label>
                <input
                  type="date"
                  required
                  value={proposedDate}
                  onChange={(e) => setProposedDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-slate-100 text-xs font-mono focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-slate-200 font-bold mb-1">
                  الوردية المناسبة للكوادر <span className="text-purple-400">*</span>
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  <button
                    type="button"
                    onClick={() => setProposedShift('morning')}
                    className={`py-2.5 px-2 rounded-xl border text-center font-bold text-xs transition ${
                      proposedShift === 'morning'
                        ? 'bg-purple-950 border-purple-500 text-purple-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    صباحية
                  </button>
                  <button
                    type="button"
                    onClick={() => setProposedShift('evening')}
                    className={`py-2.5 px-2 rounded-xl border text-center font-bold text-xs transition ${
                      proposedShift === 'evening'
                        ? 'bg-purple-950 border-purple-500 text-purple-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    مسائية
                  </button>
                  <button
                    type="button"
                    onClick={() => setProposedShift('night')}
                    className={`py-2.5 px-2 rounded-xl border text-center font-bold text-xs transition ${
                      proposedShift === 'night'
                        ? 'bg-purple-950 border-purple-500 text-purple-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    ليلية
                  </button>
                </div>
              </div>
            </div>

            {/* Nominees List */}
            <div className="pt-2">
              <div className="flex items-center justify-between mb-2">
                <label className="block text-slate-200 font-bold">
                  أسماء الكوادر المرشحة ({nominees.length}) <span className="text-purple-400">*</span>
                </label>
                <button
                  type="button"
                  onClick={handleAddNominee}
                  className="px-2.5 py-1 rounded-lg bg-purple-950 hover:bg-purple-900 text-purple-300 border border-purple-800 text-[11px] font-bold flex items-center gap-1 transition"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>إضافة مرشح آخر</span>
                </button>
              </div>

              <div className="space-y-2.5">
                {nominees.map((nominee, idx) => (
                  <div 
                    key={nominee.id}
                    className="bg-slate-950/80 border border-slate-800 rounded-2xl p-3 space-y-2 relative"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold text-purple-400">
                        مرشح #{idx + 1}
                      </span>
                      {nominees.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveNominee(nominee.id)}
                          className="text-slate-500 hover:text-rose-400 p-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <input
                        type="text"
                        required
                        value={nominee.fullName}
                        onChange={(e) => handleUpdateNominee(nominee.id, 'fullName', e.target.value)}
                        placeholder="الاسم الكامل *"
                        className="bg-slate-900 border border-slate-700/80 rounded-xl px-3 py-2 text-slate-100 text-xs focus:outline-none focus:border-purple-500"
                      />

                      <input
                        type="text"
                        value={nominee.jobTitle}
                        onChange={(e) => handleUpdateNominee(nominee.id, 'jobTitle', e.target.value)}
                        placeholder="المسمى الوظيفي"
                        className="bg-slate-900 border border-slate-700/80 rounded-xl px-3 py-2 text-slate-100 text-xs focus:outline-none focus:border-purple-500"
                      />

                      <input
                        type="tel"
                        value={nominee.phone}
                        onChange={(e) => handleUpdateNominee(nominee.id, 'phone', e.target.value)}
                        placeholder="رقم الهاتف (اختياري)"
                        className="bg-slate-900 border border-slate-700/80 rounded-xl px-3 py-2 text-slate-100 text-xs font-mono focus:outline-none focus:border-purple-500"
                        dir="ltr"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Justification */}
            <div>
              <label className="block text-slate-200 font-bold mb-1">
                مبررات الترشيح أو أية ملاحظات تفصيلية
              </label>
              <textarea
                rows={2}
                value={justification}
                onChange={(e) => setJustification(e.target.value)}
                placeholder="أسباب الترشيح (مثلاً: التحاق موظفين جدد، تحديث مهارات الإخلاء في القسم...)"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-100 text-xs focus:outline-none focus:border-purple-500 resize-none"
              />
            </div>

            {/* Submit */}
            <button
              type="submit"
              className="w-full py-3.5 rounded-2xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-lg shadow-purple-950/50 flex items-center justify-center gap-2 transition cursor-pointer mt-4"
            >
              <Send className="w-4 h-4" />
              <span>إرسال استمارة الترشيح لإدارة السلامة والتدريب</span>
            </button>
          </form>
        )}
      </main>

      {/* Footer */}
      <footer className="max-w-2xl w-full mx-auto pt-4 border-t border-slate-800 text-center text-[11px] text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
        <span>مستشفى آزال النموذجي - مركز التدريب والتطوير المستمر</span>
        <div className="flex items-center gap-3 text-slate-400">
          <button
            type="button"
            onClick={handleCopyLink}
            className="hover:text-purple-400 flex items-center gap-1 transition"
          >
            {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedLink ? 'تم نسخ الرابط' : 'نسخ رابط البوابة'}</span>
          </button>
        </div>
      </footer>

      {/* QR Modal */}
      {showQrModal && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                <QrCode className="w-4 h-4 text-purple-400" />
                <span>رمز QR استمارة ترشيح الدورات</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowQrModal(false)}
                className="text-slate-400 hover:text-slate-200 text-base"
              >
                ✕
              </button>
            </div>

            <div className="p-4 bg-white rounded-2xl inline-block shadow-lg mx-auto">
              <img
                src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(portalUrl)}`}
                alt="Training Nomination Portal QR Code"
                referrerPolicy="no-referrer"
                className="w-40 h-40 object-contain mx-auto"
              />
            </div>

            <p className="text-xs text-slate-300">
              امسح الكود لفتح استمارة ترشيح الكوادر للدورات التدريبية مباشرة.
            </p>

            <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between gap-2">
              <span className="text-[10px] text-slate-400 truncate font-mono" dir="ltr">
                {portalUrl}
              </span>
              <button
                type="button"
                onClick={handleCopyLink}
                className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-purple-400 text-[10px] font-bold shrink-0"
              >
                {copiedLink ? 'تم النسخ' : 'نسخ'}
              </button>
            </div>

            <button
              type="button"
              onClick={() => setShowQrModal(false)}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs"
            >
              إغلاق
            </button>
          </div>
        </div>
      )}
      </div>
    </div>
  );
};
