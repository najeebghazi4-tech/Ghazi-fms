import React, { useState, useEffect } from 'react';
import { 
  Flame, 
  Plus, 
  Search, 
  Filter, 
  Printer, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  ShieldCheck, 
  FileSpreadsheet, 
  Edit3, 
  Save, 
  X,
  Gauge,
  Camera,
  QrCode,
  Sparkles,
  Trash2,
  Droplets
} from 'lucide-react';
import { FireExtinguisherItem, ExtinguisherType, StaffUser } from '../types';
import { AzalLogo } from './AzalLogo';
import { sanitizeInput } from '../utils/securityUtils';
import { VoiceDictationButton } from './VoiceDictationButton';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';
import { executeSmartPrint } from '../utils/printUtils';
import { FireExtinguisherQrScannerModal } from './FireExtinguisherQrScannerModal';
import { FireExtinguisherQuickInspectionModal } from './FireExtinguisherQuickInspectionModal';
import { FireExtinguisherQrPrintModal } from './FireExtinguisherQrPrintModal';
import { EyewashFlushView } from './EyewashFlushView';

interface FireExtinguisherViewProps {
  extinguishers: FireExtinguisherItem[];
  currentUser: StaffUser;
  onSaveExtinguisher: (item: FireExtinguisherItem) => void;
  onDeleteExtinguisher?: (id: string) => void;
  onLogAudit: (action: string, actionAr: string, details: string) => void;
}

export const FireExtinguisherView: React.FC<FireExtinguisherViewProps> = ({
  extinguishers,
  currentUser,
  onSaveExtinguisher,
  onDeleteExtinguisher,
  onLogAudit,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeSubTab, setActiveSubTab] = useState<'extinguishers' | 'eyewash'>('extinguishers');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [showModal, setShowModal] = useState(false);
  const [editingItem, setEditingItem] = useState<FireExtinguisherItem | null>(null);
  const [deleteConfirmItem, setDeleteConfirmItem] = useState<FireExtinguisherItem | null>(null);

  // QR Scanner & Inspection State
  const [showQrScanner, setShowQrScanner] = useState(false);
  const [showQrPrintModal, setShowQrPrintModal] = useState(false);
  const [quickInspectItem, setQuickInspectItem] = useState<FireExtinguisherItem | null>(null);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  useEffect(() => {
    if (successToast) {
      const timer = setTimeout(() => setSuccessToast(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [successToast]);

  // Form fields
  const [serialNumber, setSerialNumber] = useState('');
  const [location, setLocation] = useState('');
  const [type, setType] = useState<ExtinguisherType>('dry_powder');
  const [expiryDate, setExpiryDate] = useState('');
  const [weight, setWeight] = useState('6 كجم');
  const [gaugeStatus, setGaugeStatus] = useState<'normal' | 'low' | 'recharge'>('normal');
  const [conditionStatus, setConditionStatus] = useState<'valid' | 'needs_maintenance' | 'expired' | 'damaged'>('valid');
  const [notes, setNotes] = useState('');
  const [isMrSafeNonMagnetic, setIsMrSafeNonMagnetic] = useState(false);
  const [mriZone, setMriZone] = useState<'Zone I' | 'Zone II' | 'Zone III' | 'Zone IV (Scanner Room)'>('Zone IV (Scanner Room)');

  // Inspector sign-off (Strictly Safety Officer only - No Center Director)
  const [inspectorName, setInspectorName] = useState('م/ نجيب غازي');
  const [inspectorRole, setInspectorRole] = useState('رئيس قسم الأمن والسلامة');

  const openNewModal = () => {
    setEditingItem(null);
    setSerialNumber(`EXT-AZAL-${String(extinguishers.length + 1).padStart(3, '0')}`);
    setLocation('');
    setType('dry_powder');
    setExpiryDate(new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]);
    setWeight('6 كجم');
    setGaugeStatus('normal');
    setConditionStatus('valid');
    setNotes('تم فحص الطفاية والتأكد من سلامة الخرطوم والبودرة وقفل الأمان.');
    setIsMrSafeNonMagnetic(false);
    setMriZone('Zone IV (Scanner Room)');
    setInspectorName('م/ نجيب غازي');
    setInspectorRole('رئيس قسم الأمن والسلامة');
    setShowModal(true);
  };

  const openEditModal = (item: FireExtinguisherItem) => {
    setEditingItem(item);
    setSerialNumber(item.serialNumber);
    setLocation(item.location);
    setType(item.type);
    setExpiryDate(item.expiryDate);
    setWeight(item.weight);
    setGaugeStatus(item.gaugeStatus);
    setConditionStatus(item.conditionStatus);
    setNotes(item.notes);
    setIsMrSafeNonMagnetic(!!item.isMrSafeNonMagnetic || item.type.includes('mri'));
    setMriZone(item.mriZone || 'Zone IV (Scanner Room)');
    setInspectorName(item.inspectorName || currentUser.name);
    setInspectorRole(item.inspectorRole || 'مسؤول الأمن والسلامة والصحة المهنية');
    setShowModal(true);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanSerial = sanitizeInput(serialNumber);
    const cleanLocation = sanitizeInput(location);
    if (!cleanSerial || !cleanLocation || !expiryDate) return;

    const typeNames: Record<string, string> = {
      dry_powder: 'بودرة جافة (Dry Powder)',
      co2: 'ثاني أكسيد الكربون (CO2)',
      water: 'ماء مضغوط (Water)',
      foam: 'رغوة كيميائية (Foam)',
      wet_chemical: 'كيماويات رطبة للمطابخ (Wet Chemical - Class K)',
      clean_agent_mri: 'غاز نظيف للرنين غير ممغنط (MR-Safe Clean Agent)',
      water_mist_mri: 'ضباب مائي نقي غير ممغنط للرنين (MR-Safe Water Mist)'
    };

    const cleanInspector = sanitizeInput(inspectorName) || 'م/ نجيب غازي';
    const cleanRole = sanitizeInput(inspectorRole) || 'رئيس قسم الأمن والسلامة';

    const isMRI = isMrSafeNonMagnetic || type === 'clean_agent_mri' || type === 'water_mist_mri';

    const newItem: FireExtinguisherItem = {
      id: editingItem ? editingItem.id : `ext-${Date.now()}`,
      serialNumber: cleanSerial,
      location: cleanLocation,
      type,
      typeAr: typeNames[type] || 'طفاية حريق',
      expiryDate,
      weight: sanitizeInput(weight) || '6 كجم',
      gaugeStatus,
      conditionStatus,
      notes: sanitizeInput(notes),
      lastInspectedAt: new Date().toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' }),
      inspectorName: cleanInspector,
      inspectorRole: cleanRole,
      signatureProof: `مُعتمد إلكترونياً • ${cleanInspector} (${new Date().toLocaleDateString('ar-EG')})`,
      synced: true,
      isMrSafeNonMagnetic: isMRI,
      mriZone: isMRI ? mriZone : undefined,
    };

    onSaveExtinguisher(newItem);
    setShowModal(false);

    // Audio and haptic feedback
    triggerSuccessFeedback();

    onLogAudit(
      editingItem ? 'FIRE_EXTINGUISHER_UPDATED' : 'FIRE_EXTINGUISHER_ADDED',
      editingItem ? 'تحديث فحص طفاية حريق' : 'تسجيل طفاية حريق جديدة',
      `تم اعتماد فحص الطفاية رقم ${newItem.serialNumber} بموقع (${newItem.location}) بواسطة: ${newItem.inspectorName}.`
    );
  };

  const handleExportPDF = () => {
    const tableRows = filteredItems.map((item, idx) => {
      const typeAr = 
        item.type === 'co2' ? 'ثاني أكسيد الكربون (CO2)' :
        item.type === 'foam' ? 'رغوة (Foam)' :
        item.type === 'water' ? 'ماء (Water)' :
        item.type === 'wet_chemical' ? 'كيماوي رطب (Wet Chem)' : 'بودرة جافة (DCP)';

      const statusBadge = 
        item.conditionStatus === 'valid' ? '<span class="badge-success">صالحة وجاهزة ✔</span>' :
        item.conditionStatus === 'needs_maintenance' ? '<span class="badge-warning">تحتاج صيانة ⚠</span>' :
        '<span class="badge-danger">منتهية الصلاحية ✖</span>';

      return `
        <tr>
          <td style="font-weight:bold;">${idx + 1}</td>
          <td style="font-family:monospace; font-weight:bold;">${item.serialNumber}</td>
          <td>${typeAr}</td>
          <td>${item.weightCapacity || item.weight || '-'}</td>
          <td>${item.location}</td>
          <td>${item.lastInspectionDate || item.lastInspectedAt || '-'}</td>
          <td>${item.expiryDate}</td>
          <td>${(item.gaugeStatus === 'normal' || (item.gaugeStatus as string) === 'green') ? 'المؤشر في الأخضر ✔' : 'غير سليم ✖'}</td>
          <td>${statusBadge}</td>
          <td>${item.inspectorName}</td>
          <td>${item.notes || '-'}</td>
        </tr>
      `;
    }).join('');

    const bodyHtml = `
      <div class="summary-grid">
        <div class="summary-card"><div class="val">${extinguishers.length}</div><div class="lbl">إجمالي طفايات الحريق</div></div>
        <div class="summary-card"><div class="val" style="color:#047857;">${validCount}</div><div class="lbl">صالحة وجاهزة فوراً</div></div>
        <div class="summary-card"><div class="val" style="color:#b45309;">${maintenanceCount}</div><div class="lbl">بحاجة لصيانة وضغط</div></div>
        <div class="summary-card"><div class="val" style="color:#b91c1c;">${expiredCount}</div><div class="lbl">منتهية الصلاحية</div></div>
      </div>
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>الرقم التسلسلي</th>
            <th>نوع الطفاية</th>
            <th>السعة / الوزن</th>
            <th>الموقع الميداني</th>
            <th>تاريخ آخر فحص</th>
            <th>تاريخ الانتهاء</th>
            <th>حالة المؤشر (Gauge)</th>
            <th>الحالة الفنية</th>
            <th>المفتش المعتمد</th>
            <th>ملاحظات</th>
          </tr>
        </thead>
        <tbody>
          ${tableRows || '<tr><td colspan="11" style="text-align:center; padding:12px;">لا توجد طفايات مسجلة</td></tr>'}
        </tbody>
      </table>
    `;

    executeSmartPrint(bodyHtml, {
      title: 'سجل تدقيق وفحص طفايات الحريق والجاهزية الميدانية',
      subtitle: 'مستشفى آزال النموذجي • إدارة السلامة ومكافحة الحريق • معايير سباهي FMS.7',
      refNumber: 'AZAL-FIRE-EXT-LOG-2026'
    });
  };

  const filteredItems = extinguishers.filter((item) => {
    const matchesSearch =
      item.serialNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.notes.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = 
      typeFilter === 'all' ? true :
      typeFilter === 'mr_safe' ? (!!item.isMrSafeNonMagnetic || item.type.includes('mri')) :
      item.type === typeFilter;
    const matchesStatus = statusFilter === 'all' || item.conditionStatus === statusFilter;
    return matchesSearch && matchesType && matchesStatus;
  });

  const validCount = extinguishers.filter((e) => e.conditionStatus === 'valid').length;
  const maintenanceCount = extinguishers.filter((e) => e.conditionStatus === 'needs_maintenance').length;
  const expiredCount = extinguishers.filter((e) => e.conditionStatus === 'expired').length;
  const mrSafeCount = extinguishers.filter((e) => !!e.isMrSafeNonMagnetic || e.type.includes('mri')).length;

  return (
    <div id="fire-extinguishers-module" className="space-y-4 pb-20 text-right">
      {/* Sub-Tab Navigation Bar */}
      <div className="flex flex-col sm:flex-row items-center gap-2 p-1.5 bg-slate-900 border border-slate-800 rounded-2xl shadow-md">
        <button
          type="button"
          onClick={() => setActiveSubTab('extinguishers')}
          className={`w-full sm:w-1/2 py-2.5 px-4 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 ${
            activeSubTab === 'extinguishers'
              ? 'bg-gradient-to-r from-red-600 to-rose-700 text-white shadow-md'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
          }`}
        >
          <Flame className="w-4 h-4" />
          <span>سجل طفايات الحريق (مع الطفايات غير الممغنطة للرنين MR-Safe)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('eyewash')}
          className={`w-full sm:w-1/2 py-2.5 px-4 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 ${
            activeSubTab === 'eyewash'
              ? 'bg-gradient-to-r from-teal-600 to-emerald-700 text-slate-950 font-black shadow-md'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
          }`}
        >
          <Droplets className="w-4 h-4" />
          <span>محطات غسول العيون والدش الطارئ (ANSI Z358.1 & CBAHI) 🚿</span>
        </button>
      </div>

      {activeSubTab === 'eyewash' ? (
        <EyewashFlushView currentUser={currentUser} onLogAudit={onLogAudit} />
      ) : (
        <>
      {/* Top Banner with Actions */}
      <div className="bg-gradient-to-r from-red-950 via-slate-900 to-slate-900 border border-red-800/60 rounded-2xl p-4 shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-red-950/90 border border-red-700 text-red-400 shadow-md">
            <Flame className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-slate-100">
                سجل واستمارة فحص طفايات الحريق الميدانية
              </h2>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                اعتماد أمني موحّد
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              متابعة صلاحية وأوزان ومواقع طفايات الحريق وفقاً لمعايير الدفاع المدني والسلامة المهنية
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
          {/* Prominent QR Camera Scanner Button */}
          <button
            type="button"
            onClick={() => setShowQrScanner(true)}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white text-xs font-bold shadow-lg shadow-red-950/60 flex items-center gap-2 transition hover:scale-[1.02] active:scale-[0.98] border border-red-400/40"
            title="فتح كاميرا الهاتف ومسح كود QR الخاص بطفاية الحريق لإجراء الفحص الفوري"
          >
            <Camera className="w-4 h-4 animate-pulse text-amber-200" />
            <span>📷 مسح كود الطفاية (QR Scan)</span>
          </button>

          {/* QR Labels Generator / Print Button */}
          <button
            type="button"
            onClick={() => setShowQrPrintModal(true)}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-teal-800/80 hover:border-teal-600 text-xs font-bold shadow flex items-center gap-1.5 transition"
            title="توليد وطباعة ملصقات ورموز QR لكافة الطفايات الـ 28 للصقها على الأسطوانات"
          >
            <QrCode className="w-4 h-4 text-teal-400" />
            <span>🏷️ طباعة باركود وملصقات الطفايات (28)</span>
          </button>

          <button
            type="button"
            onClick={handleExportPDF}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold shadow flex items-center gap-1.5 transition"
            title="تصدير وطباعة استمارة فحص طفايات الحريق الرسمية"
          >
            <Printer className="w-4 h-4 text-teal-400" />
            <span>طباعة / تصدير PDF</span>
          </button>

          <button
            type="button"
            onClick={openNewModal}
            className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold shadow-lg shadow-red-950 flex items-center gap-1.5 transition"
          >
            <Plus className="w-4 h-4" />
            <span>تسجيل فحص طفاية جديدة</span>
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
        <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl">
          <span className="text-[11px] text-slate-400 block font-medium">إجمالي الطفايات المسجلة</span>
          <span className="text-lg font-bold text-slate-100 font-mono mt-0.5 block">{extinguishers.length}</span>
        </div>
        <div className="p-3 bg-teal-950/50 border border-teal-800/80 rounded-xl">
          <span className="text-[11px] text-teal-300 block font-medium">🧲 طفايات رنين (MR-Safe)</span>
          <span className="text-lg font-bold text-teal-400 font-mono mt-0.5 block">{mrSafeCount}</span>
        </div>
        <div className="p-3 bg-emerald-950/40 border border-emerald-900/60 rounded-xl">
          <span className="text-[11px] text-emerald-300 block font-medium">صالحة ومطابقة 🟢</span>
          <span className="text-lg font-bold text-emerald-400 font-mono mt-0.5 block">{validCount}</span>
        </div>
        <div className="p-3 bg-amber-950/40 border border-amber-900/60 rounded-xl">
          <span className="text-[11px] text-amber-300 block font-medium">تحتاج صيانة / إعادة شحن 🟡</span>
          <span className="text-lg font-bold text-amber-400 font-mono mt-0.5 block">{maintenanceCount}</span>
        </div>
        <div className="p-3 bg-rose-950/40 border border-rose-900/60 rounded-xl">
          <span className="text-[11px] text-rose-300 block font-medium">منتهية الصلاحية 🔴</span>
          <span className="text-lg font-bold text-rose-400 font-mono mt-0.5 block">{expiredCount}</span>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="flex flex-col sm:flex-row gap-2 text-xs">
        <div className="relative flex-1 flex items-center">
          <Search className="w-4 h-4 text-slate-500 absolute right-3 top-2.5 pointer-events-none" />
          <input
            type="text"
            placeholder="بحث برقم الطفاية، الموقع، الملاحظات..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pr-9 pl-11 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-red-600"
          />
          <div className="absolute left-1.5 top-1.5">
            <VoiceDictationButton
              value={searchTerm}
              onChange={setSearchTerm}
              title="بحث صوتي في سجل الطفايات"
            />
          </div>
        </div>

        <select
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value)}
          className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-red-600"
        >
          <option value="all">كافة أنواع الطفايات</option>
          <option value="mr_safe">🧲 طفايات الرنين المغناطيسي غير الممغنطة (MR-Safe)</option>
          <option value="dry_powder">بودرة جافة (Dry Powder)</option>
          <option value="co2">ثاني أكسيد الكربون (CO2)</option>
          <option value="water">ماء مضغوط (Water)</option>
          <option value="foam">رغوة كيميائية (Foam)</option>
          <option value="wet_chemical">كيماويات رطبة للمطابخ (Wet Chemical - Class K)</option>
          <option value="clean_agent_mri">غاز نظيف MR-Safe Clean Agent</option>
          <option value="water_mist_mri">ضباب مائي نقي MR-Safe Water Mist</option>
        </select>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-red-600"
        >
          <option value="all">كافة الحالات الفنية</option>
          <option value="valid">مطابقة وصالحة</option>
          <option value="needs_maintenance">تحتاج صيانة / إعادة شحن</option>
          <option value="expired">منتهية الصلاحية</option>
        </select>
      </div>

      {/* Dynamic Table Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-md">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="bg-slate-950/80 text-slate-400 border-b border-slate-800 font-semibold">
                <th className="py-3 px-3">رقم الطفاية</th>
                <th className="py-3 px-3">الموقع الدقيق</th>
                <th className="py-3 px-3">النوع</th>
                <th className="py-3 px-3">تاريخ الانتهاء</th>
                <th className="py-3 px-3">الوزن والضغط</th>
                <th className="py-3 px-3">الحالة الفنية</th>
                <th className="py-3 px-3">اعتماد الفحص</th>
                <th className="py-3 px-3 text-center">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredItems.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500">
                    لا توجد طفايات حريق تطابق معايير البحث الحالية.
                  </td>
                </tr>
              ) : (
                filteredItems.map((item) => {
                  const isExpired = new Date(item.expiryDate) < new Date();
                  return (
                    <tr key={item.id} className="hover:bg-slate-800/50 transition">
                      <td className="py-3 px-3 font-mono font-bold text-red-400">
                        {item.serialNumber}
                      </td>
                      <td className="py-3 px-3 text-slate-200 max-w-[200px] truncate" title={item.location}>
                        {item.location}
                      </td>
                      <td className="py-3 px-3 text-slate-300">
                        <div className="flex flex-col gap-1 items-start">
                          <span className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-[11px]">
                            {item.typeAr}
                          </span>
                          {(item.isMrSafeNonMagnetic || item.type.includes('mri')) && (
                            <span className="px-1.5 py-0.5 rounded bg-teal-950 text-teal-300 border border-teal-800 text-[10px] font-bold inline-flex items-center gap-1">
                              <span>🧲 MR-Safe</span>
                              <span className="text-teal-400">({item.mriZone || 'Zone IV'})</span>
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-3 px-3 font-mono">
                        <span className={isExpired ? 'text-rose-400 font-bold' : 'text-slate-300'}>
                          {item.expiryDate}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-slate-300">
                        <div className="flex items-center gap-1.5 font-mono">
                          <span>{item.weight}</span>
                          <span className={`text-[10px] px-1.5 py-0.2 rounded ${
                            item.gaugeStatus === 'normal' 
                              ? 'bg-emerald-950 text-emerald-400' 
                              : 'bg-amber-950 text-amber-400'
                          }`}>
                            {item.gaugeStatus === 'normal' ? 'الضغط سليم' : 'الضغط منخفض'}
                          </span>
                        </div>
                      </td>
                      <td className="py-3 px-3">
                        {item.conditionStatus === 'valid' && (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-400 bg-emerald-950/70 border border-emerald-800/80 px-2 py-0.5 rounded-full">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>صالحة للاستخدام</span>
                          </span>
                        )}
                        {item.conditionStatus === 'needs_maintenance' && (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-400 bg-amber-950/70 border border-amber-800/80 px-2 py-0.5 rounded-full">
                            <AlertTriangle className="w-3 h-3" />
                            <span>تحتاج صيانة / شحن</span>
                          </span>
                        )}
                        {item.conditionStatus === 'expired' && (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-rose-400 bg-rose-950/70 border border-rose-800/80 px-2 py-0.5 rounded-full">
                            <AlertTriangle className="w-3 h-3" />
                            <span>منتهية الصلاحية</span>
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-3">
                        <div className="text-[11px]">
                          <span className="font-bold text-slate-200 block">{item.inspectorName}</span>
                          <span className="text-[10px] text-teal-400 block">{item.inspectorRole}</span>
                          <span className="text-[9px] text-slate-500 font-mono">{item.lastInspectedAt}</span>
                        </div>
                      </td>
                      <td className="py-3 px-3 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => setQuickInspectItem(item)}
                            className="px-2.5 py-1.5 rounded-lg bg-teal-950/80 hover:bg-teal-900 border border-teal-700/80 text-teal-300 text-[11px] font-bold flex items-center gap-1 transition shadow-sm"
                            title="فحص شهري سريع لهذه الطفاية (QR)"
                          >
                            <Camera className="w-3 h-3 text-teal-400" />
                            <span>فحص</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => openEditModal(item)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-teal-950 hover:text-teal-300 text-slate-300 border border-slate-700/60 transition"
                            title="تعديل بيانات الطفاية"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setDeleteConfirmItem(item)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-950 hover:text-rose-300 text-rose-400 border border-slate-700/60 transition"
                            title="حذف هذا البند من السجل الرسمي"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Audit Sign-off Confirmation Note */}
        <div className="p-3 bg-slate-950/90 border-t border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-teal-400 shrink-0" />
            <span>
              نظام الاعتماد الرسمي: يقتصر اعتماد الفحص حصراً على <strong>مسؤول الأمن والسلامة</strong> (تم إلغاء خانة مدير المركز نهائياً).
            </span>
          </div>
          <span className="text-[11px] text-slate-500">
            كافة السجلات مؤرخة ومحمية ضد التعديل غير المصرح به
          </span>
        </div>
      </div>

      {/* Modal: Add or Edit Extinguisher Inspection */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-200 my-auto">
            <div className="bg-gradient-to-r from-red-950 via-slate-900 to-slate-900 p-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-red-950 border border-red-800 text-red-400">
                  <Flame className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-100">
                    {editingItem ? 'تحديث فحص طفاية حريق' : 'تسجيل وتوثيق فحص طفاية حريق جديدة'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    مستشفى آزال النموذجي • إدارة الأمن والسلامة
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="p-4 space-y-3.5 text-xs text-right">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    رقم الطفاية الكودي <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={serialNumber}
                    onChange={(e) => setSerialNumber(e.target.value)}
                    placeholder="مثال: EXT-AZAL-001"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 font-mono text-xs focus:outline-none focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    نوع الطفاية <span className="text-red-400">*</span>
                  </label>
                  <select
                    value={type}
                    onChange={(e) => {
                      const newType = e.target.value as ExtinguisherType;
                      setType(newType);
                      if (newType === 'clean_agent_mri' || newType === 'water_mist_mri') {
                        setIsMrSafeNonMagnetic(true);
                      }
                    }}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 text-xs focus:outline-none focus:border-red-500"
                  >
                    <option value="dry_powder">بودرة جافة (Dry Powder)</option>
                    <option value="co2">ثاني أكسيد الكربون (CO2)</option>
                    <option value="water">ماء مضغوط (Water)</option>
                    <option value="foam">رغوة كيميائية (Foam)</option>
                    <option value="wet_chemical">كيماويات رطبة للمطابخ (Wet Chemical - Class K)</option>
                    <option value="clean_agent_mri">🧲 غاز نظيف غير ممغنط للرنين (MR-Safe Clean Agent)</option>
                    <option value="water_mist_mri">🧲 ضباب مائي نقي غير ممغنط للرنين (MR-Safe Water Mist)</option>
                  </select>
                </div>
              </div>

              {/* MR-Safe / MRI Suite Classification */}
              <div className="p-3 bg-slate-950/90 border border-teal-800/70 rounded-2xl space-y-2.5">
                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isMrSafeNonMagnetic}
                      onChange={(e) => {
                        const checked = e.target.checked;
                        setIsMrSafeNonMagnetic(checked);
                        if (checked && type !== 'clean_agent_mri' && type !== 'water_mist_mri') {
                          setType('clean_agent_mri');
                        }
                      }}
                      className="w-4 h-4 text-teal-600 rounded bg-slate-900 border-slate-700 focus:ring-0"
                    />
                    <span className="font-bold text-teal-300 text-xs flex items-center gap-1.5">
                      <span>🧲 طفاية مخصصة للرنين المغناطيسي وغير ممغنطة (MR-Safe Non-Magnetic)</span>
                    </span>
                  </label>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-teal-950 text-teal-300 border border-teal-800 font-bold">
                    معيار ACR / CBAHI FMS
                  </span>
                </div>

                {isMrSafeNonMagnetic && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 border-t border-slate-800 text-xs">
                    <div>
                      <label className="block text-slate-300 font-bold mb-1">
                        نطاق جناح الرنين المغناطيسي (MRI Zone)
                      </label>
                      <select
                        value={mriZone}
                        onChange={(e) => setMriZone(e.target.value as any)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 text-slate-100 text-xs focus:outline-none focus:border-teal-500"
                      >
                        <option value="Zone IV (Scanner Room)">Zone IV (غرفة جهاز الرنين المغناطيسي - أقصى حقل مغناطيسي)</option>
                        <option value="Zone III">Zone III (غرفة التحكم والكونسول وغرفة المرضى المقيدين)</option>
                        <option value="Zone II">Zone II (منطقة الاستقبال والفرز والتحضير)</option>
                        <option value="Zone I">Zone I (المنطقة الخارجية العامة)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-slate-300 font-bold mb-1">
                        مواصفات الأسطوانة غير الممغنطة
                      </label>
                      <div className="text-[11px] text-teal-400/90 bg-teal-950/40 p-2 rounded-xl border border-teal-900/50">
                        جسم ألومنيوم خالص / ستانلس غير ممغنط تم اختباره حتى 3.0 تسلا بدون أي قوى جذب مغناطيسية.
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-slate-300 font-bold">
                    الموقع الدقيق للطفاية في المستشفى <span className="text-red-400">*</span>
                  </label>
                  <VoiceDictationButton
                    value={location}
                    onChange={setLocation}
                    title="إملاء صوتي لموقع الطفاية"
                  />
                </div>
                <input
                  type="text"
                  required
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="مثال: الدور الأرضي - بهو الطوارئ الرئيسي بجوار مخرج 1"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 text-xs focus:outline-none focus:border-red-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    تاريخ الانتهاء والصلاحية <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={expiryDate}
                    onChange={(e) => setExpiryDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 text-xs focus:outline-none focus:border-red-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    الوزن / السعة <span className="text-red-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    placeholder="مثال: 6 كجم / 9 لتر"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 text-xs focus:outline-none focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    مؤشر الضغط (Gauge)
                  </label>
                  <select
                    value={gaugeStatus}
                    onChange={(e) => setGaugeStatus(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 text-xs focus:outline-none focus:border-red-500"
                  >
                    <option value="normal">سليم (في النطاق الأخضر)</option>
                    <option value="low">منخفض (يحتاج إعادة شحن)</option>
                    <option value="recharge">تفريغ كامل (معطل)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  الحالة الفنية العامة
                </label>
                <select
                  value={conditionStatus}
                  onChange={(e) => setConditionStatus(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 text-xs focus:outline-none focus:border-red-500"
                >
                  <option value="valid">مطابقة وجاهزة للاستخدام الفوري</option>
                  <option value="needs_maintenance">تحتاج صيانة وفحص صمام</option>
                  <option value="expired">منتهية الصلاحية</option>
                  <option value="damaged">تالفة وبحاجة استبدال فوري</option>
                </select>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-slate-300 font-bold">
                    ملاحظات وتوصيات الفحص الميداني
                  </label>
                  <VoiceDictationButton
                    value={notes}
                    onChange={setNotes}
                    showLabel
                    title="إملاء صوتي لملاحظات الفحص"
                  />
                </div>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="أدخل أي ملاحظات حول خرطوم التفريغ، مسمار الأمان، أو سهولة الوصول... (يمكنك الإملاء بالصوت)"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-slate-100 text-xs focus:outline-none focus:border-red-500"
                />
              </div>

              {/* Dedicated Sign-off Block: STRICTLY SAFETY OFFICER ONLY */}
              <div className="bg-slate-950/80 border border-teal-800/80 rounded-xl p-3 space-y-2">
                <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
                  <span className="text-xs font-bold text-teal-300 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-teal-400" />
                    <span>إعداد واعتماد: مسؤول الأمن والسلامة فقط</span>
                  </span>
                  <span className="text-[10px] bg-red-950/80 text-red-300 border border-red-800/60 px-2 py-0.5 rounded">
                    تم إلغاء خانة مدير المركز
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-0.5">اسم المفتش / المسؤول:</label>
                    <input
                      type="text"
                      required
                      value={inspectorName}
                      onChange={(e) => setInspectorName(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-0.5">المسمى الوظيفي:</label>
                    <input
                      type="text"
                      required
                      value={inspectorRole}
                      onChange={(e) => setInspectorRole(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 text-xs"
                    />
                  </div>
                </div>

                <div className="text-[10px] text-slate-500 flex items-center justify-between pt-1">
                  <span>التوقيع الإلكتروني: معتمد ومحفوظ بالبصمة الزمنية</span>
                  <span className="font-mono">{new Date().toLocaleDateString('ar-EG')}</span>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold transition"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold transition flex items-center gap-1.5 shadow-md shadow-red-950"
                >
                  <Save className="w-4 h-4" />
                  <span>حفظ واعتماد الفحص</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Success Notification Banner */}
      {successToast && (
        <div className="fixed bottom-5 left-5 right-5 sm:left-auto sm:right-5 sm:max-w-md z-50 bg-emerald-950 border border-emerald-600 text-emerald-100 px-4 py-3 rounded-2xl shadow-2xl flex items-center justify-between gap-3 animate-slide-up">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span className="text-xs font-bold">{successToast}</span>
          </div>
          <button
            type="button"
            onClick={() => setSuccessToast(null)}
            className="text-emerald-400 hover:text-white p-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* QR Code Scanner Camera Modal */}
      {showQrScanner && (
        <FireExtinguisherQrScannerModal
          extinguishers={extinguishers}
          onClose={() => setShowQrScanner(false)}
          onExtinguisherScanned={(ext) => {
            setShowQrScanner(false);
            setQuickInspectItem(ext);
          }}
        />
      )}

      {/* Quick Monthly Inspection Modal */}
      {quickInspectItem && (
        <FireExtinguisherQuickInspectionModal
          extinguisher={quickInspectItem}
          currentUser={currentUser}
          onClose={() => setQuickInspectItem(null)}
          onSave={(updated) => {
            onSaveExtinguisher(updated);
            setSuccessToast(`تم اعتماد وتحديث فحص الطفاية (${updated.serialNumber}) بنجاح ووسمها "مفحوصة ومطابقة".`);
          }}
          onLogAudit={onLogAudit}
        />
      )}

      {/* QR Labels Print & Generation Modal */}
      {showQrPrintModal && (
        <FireExtinguisherQrPrintModal
          extinguishers={extinguishers}
          onClose={() => setShowQrPrintModal(false)}
        />
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmItem && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-rose-800/80 rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl text-right animate-scale-in">
            <div className="flex items-center gap-3 border-b border-rose-900/40 pb-3">
              <div className="p-2.5 rounded-xl bg-rose-950/80 border border-rose-800 text-rose-400">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-black text-rose-300">تأكيد حذف طفاية حريق من السجل</h3>
                <p className="text-[11px] text-slate-400">إدارة الأمن والسلامة وإدارة المرافق (FMS)</p>
              </div>
            </div>

            <div className="p-3 bg-rose-950/30 border border-rose-900/50 rounded-xl space-y-2 text-xs">
              <p className="text-slate-200 font-bold">
                هل أنت متأكد من حذف هذا البند من السجل الرسمي؟
              </p>
              <div className="text-[11px] text-slate-300 space-y-1 bg-slate-950/60 p-2.5 rounded-lg border border-slate-800">
                <div><strong className="text-slate-400">رقم الطفاية:</strong> <span className="font-mono text-rose-400">{deleteConfirmItem.serialNumber}</span></div>
                <div><strong className="text-slate-400">الموقع:</strong> <span>{deleteConfirmItem.location}</span></div>
                <div><strong className="text-slate-400">النوع:</strong> <span>{deleteConfirmItem.typeAr}</span></div>
              </div>
              <p className="text-[11px] text-rose-400 font-medium">
                ⚠️ تنبيه: سيتم حذف هذا السجل نهائياً وتحديث إجمالي العدادات ومؤشرات الامتثال فوراً.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setDeleteConfirmItem(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold transition"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={() => {
                  if (deleteConfirmItem) {
                    onDeleteExtinguisher?.(deleteConfirmItem.id);
                    onLogAudit(
                      'FIRE_EXTINGUISHER_DELETED',
                      'حذف طفاية حريق من السجل الرسمي',
                      `تم حذف الطفاية رقم ${deleteConfirmItem.serialNumber} بموقع (${deleteConfirmItem.location}) من السجل الرسمي.`
                    );
                    setSuccessToast(`تم حذف الطفاية ${deleteConfirmItem.serialNumber} بنجاح.`);
                    setDeleteConfirmItem(null);
                  }
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-lg shadow-rose-950/50"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>تأكيد الحذف النهائي</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Official Printable Form (Visible when printing / Exporting PDF) */}
      <div id="print-extinguisher-form" className="hidden print:block text-black bg-white p-8 font-sans">
        <div className="flex items-center justify-between border-b-2 border-teal-800 pb-4 mb-4">
          <div className="text-right">
            <div className="text-xs font-bold text-gray-500">الجمهورية اليمنية</div>
            <h1 className="text-xl font-black text-teal-900">مستشفى آزال النموذجي - صنعاء</h1>
            <h2 className="text-xs font-bold text-gray-700">إدارة الأمن والسلامة وإدارة المرافق (FMS)</h2>
            <p className="text-[11px] text-gray-600 mt-0.5">استمارة فحص وتفتيش طفايات الحريق الميدانية الدورية</p>
          </div>
          <div className="text-center">
            <img src="/azal-logo.svg" alt="شعار مستشفى آزال النموذجي" className="max-h-16 w-auto object-contain mx-auto" />
          </div>
          <div className="text-left font-mono text-xs">
            <div className="inline-block bg-teal-50 border border-teal-700 text-teal-800 font-bold px-2 py-0.5 rounded text-[10px] mb-1">CBAHI ACCREDITED</div>
            <p>تاريخ التقرير: {new Date().toLocaleDateString('ar-EG')}</p>
            <p>إجمالي الطفايات: {extinguishers.length}</p>
            <p className="font-bold text-emerald-800">معتمدة ومطابقة لكود NFPA 10</p>
          </div>
        </div>

        <table className="w-full border-collapse border border-gray-400 text-right text-xs my-4">
          <thead>
            <tr className="bg-gray-100 border-b border-gray-400 font-bold">
              <th className="border border-gray-300 p-2">رقم الطفاية</th>
              <th className="border border-gray-300 p-2">الموقع المحدد</th>
              <th className="border border-gray-300 p-2">النوع</th>
              <th className="border border-gray-300 p-2">تاريخ الانتهاء</th>
              <th className="border border-gray-300 p-2">الوزن</th>
              <th className="border border-gray-300 p-2">الحالة الفنية</th>
              <th className="border border-gray-300 p-2">ملاحظات</th>
            </tr>
          </thead>
          <tbody>
            {extinguishers.map((item) => (
              <tr key={item.id} className="border-b border-gray-300">
                <td className="border border-gray-300 p-2 font-mono font-bold">{item.serialNumber}</td>
                <td className="border border-gray-300 p-2">{item.location}</td>
                <td className="border border-gray-300 p-2">{item.typeAr}</td>
                <td className="border border-gray-300 p-2 font-mono">{item.expiryDate}</td>
                <td className="border border-gray-300 p-2">{item.weight}</td>
                <td className="border border-gray-300 p-2">
                  {item.conditionStatus === 'valid' ? 'مطابقة وسليمة' : 'تحتاج صيانة'}
                </td>
                <td className="border border-gray-300 p-2">{item.notes}</td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Print Sign-off: STRICTLY SAFETY OFFICER ONLY */}
        <div className="mt-8 pt-4 border-t border-gray-300 flex justify-between items-end">
          <div className="text-right">
            <h3 className="text-xs font-bold text-gray-800">إعداد واعتماد الفحص:</h3>
            <p className="text-sm font-black mt-1">رئيس قسم الأمن والسلامة</p>
            <p className="text-xs mt-0.5">الاسم: م/ نجيب غازي</p>
            <p className="text-xs text-gray-600 font-mono mt-1">
              التوقيع الإلكتروني: [مُعتمد إلكترونياً • ختم إدارة السلامة - مستشفى آزال]
            </p>
          </div>

          <div className="text-left">
            <div className="w-28 h-16 border border-dashed border-gray-400 flex items-center justify-center text-[10px] text-gray-500">
              ختم إدارة الأمن والسلامة
            </div>
            <p className="text-[9px] text-gray-500 mt-1">نظام إدارة السلامة المعتمد</p>
          </div>
        </div>
      </div>
        </>
      )}
    </div>
  );
};
