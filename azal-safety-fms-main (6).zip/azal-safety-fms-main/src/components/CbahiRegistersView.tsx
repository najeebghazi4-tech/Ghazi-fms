import React, { useState, useEffect } from 'react';
import { 
  Flame, 
  Zap, 
  Droplets, 
  Users, 
  Award, 
  Plus, 
  Search, 
  Filter, 
  Printer, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  ShieldCheck, 
  Calendar, 
  FileText, 
  ArrowUpDown,
  FileCheck,
  ChevronDown,
  ChevronUp,
  X,
  AlertTriangle,
  ShieldAlert
} from 'lucide-react';
import { 
  CbahiFireDrill, 
  CbahiGeneratorTest, 
  CbahiWaterTest, 
  CbahiSafetyCommitteeItem, 
  CbahiStandardItem,
  CbahiCapAction,
  StaffUser
} from '../types';
import { CBAHI_39_STANDARDS } from '../data/azalCbahiData';
import { supabaseClient } from '../services/supabaseClient';
import { CbahiReadinessGauge } from './CbahiReadinessGauge';
import { HospitalRiskAssessmentView } from './HospitalRiskAssessmentView';
import {
  printCbahiFireDrillReport,
  printCbahiGeneratorTestReport,
  printCbahiWaterTestReport,
  printCbahiCommitteeReport,
  printComprehensiveCbahiPortfolio
} from '../utils/cbahiPrintTemplates';

export type CbahiTabType = 'risks' | 'drills' | 'generators' | 'water' | 'committee' | 'standards';

interface CbahiRegistersViewProps {
  initialTab?: CbahiTabType;
  currentUser?: StaffUser | null;
}

export const CbahiRegistersView: React.FC<CbahiRegistersViewProps> = ({ initialTab = 'risks', currentUser }) => {
  const [activeTab, setActiveTab] = useState<CbahiTabType>(initialTab);
  const [standards, setStandards] = useState<CbahiStandardItem[]>(CBAHI_39_STANDARDS);
  const [fireDrills, setFireDrills] = useState<CbahiFireDrill[]>([]);
  const [generatorTests, setGeneratorTests] = useState<CbahiGeneratorTest[]>([]);
  const [waterTests, setWaterTests] = useState<CbahiWaterTest[]>([]);
  const [committeeItems, setCommitteeItems] = useState<CbahiSafetyCommitteeItem[]>([]);
  const [loading, setLoading] = useState(true);

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [standardCategoryFilter, setStandardCategoryFilter] = useState('all');

  // Modals for New Entry
  const [showAddDrillModal, setShowAddDrillModal] = useState(false);
  const [showAddGenModal, setShowAddGenModal] = useState(false);
  const [showAddWaterModal, setShowAddWaterModal] = useState(false);
  const [showAddCommitteeModal, setShowAddCommitteeModal] = useState(false);

  // Load Data on Mount
  useEffect(() => {
    loadAllCbahiData();
  }, []);

  const loadAllCbahiData = async () => {
    setLoading(true);
    try {
      const [drillsRes, gensRes, waterRes, commRes] = await Promise.all([
        supabaseClient.from('cbahi_fire_drills').select('*'),
        supabaseClient.from('cbahi_generator_tests').select('*'),
        supabaseClient.from('cbahi_water_tests').select('*'),
        supabaseClient.from('cbahi_safety_committee').select('*'),
      ]);

      if (drillsRes.data) setFireDrills(drillsRes.data);
      if (gensRes.data) setGeneratorTests(gensRes.data);
      if (waterRes.data) setWaterTests(waterRes.data);
      if (commRes.data) setCommitteeItems(commRes.data);
    } catch (err) {
      console.error('Error loading CBAHI data:', err);
    } finally {
      setLoading(false);
    }
  };

  // 1. ADD FIRE DRILL
  const handleSaveFireDrill = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData(form);

    const newDrill: CbahiFireDrill = {
      id: `DRILL-${Date.now()}`,
      drill_code: `FD-FMS18-2026-${String(fireDrills.length + 1).padStart(2, '0')}`,
      drill_date: (formData.get('drill_date') as string) || new Date().toISOString().split('T')[0],
      shift: (formData.get('shift') as 'morning' | 'evening' | 'night') || 'morning',
      department: (formData.get('department') as string) || 'قسم الطوارئ',
      evacuation_time_seconds: Number(formData.get('evacuation_time_seconds')) || 180,
      race_applied: formData.get('race_applied') === 'on',
      race_score: Number(formData.get('race_score')) || 95,
      race_notes: (formData.get('race_notes') as string) || '',
      pass_applied: formData.get('pass_applied') === 'on',
      pass_score: Number(formData.get('pass_score')) || 95,
      pass_notes: (formData.get('pass_notes') as string) || '',
      gas_isolated: formData.get('gas_isolated') === 'on',
      electricity_isolated: formData.get('electricity_isolated') === 'on',
      participants_count: Number(formData.get('participants_count')) || 20,
      simulated_victims_count: Number(formData.get('simulated_victims_count')) || 2,
      evaluation_rating: (formData.get('evaluation_rating') as any) || 'excellent',
      evaluation_score: Number(formData.get('evaluation_score')) || 95,
      supervisor_name: (formData.get('supervisor_name') as string) || 'م/ نجيب غازي',
      medical_director_approved: true,
      notes: (formData.get('notes') as string) || '',
      recommendations: (formData.get('recommendations') as string) || '',
      created_at: new Date().toISOString(),
      synced: true,
    };

    await supabaseClient.from('cbahi_fire_drills').insert([newDrill]);
    setFireDrills([newDrill, ...fireDrills]);
    setShowAddDrillModal(false);
  };

  // 2. ADD GENERATOR TEST
  const handleSaveGeneratorTest = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData(form);

    const newTest: CbahiGeneratorTest = {
      id: `GEN-${Date.now()}`,
      test_code: `GEN-${Date.now().toString().slice(-6)}`,
      test_date: (formData.get('test_date') as string) || new Date().toISOString().split('T')[0],
      test_time: (formData.get('test_time') as string) || '10:00',
      test_type: (formData.get('test_type') as any) || 'weekly_no_load',
      duration_minutes: Number(formData.get('duration_minutes')) || 10,
      auto_start_time_seconds: Number(formData.get('auto_start_time_seconds')) || 7.5,
      generator_name: (formData.get('generator_name') as string) || 'المولد الرئيسي Cummins 500 kVA',
      voltage_v: Number(formData.get('voltage_v')) || 395,
      frequency_hz: Number(formData.get('frequency_hz')) || 50.0,
      oil_pressure_bar: Number(formData.get('oil_pressure_bar')) || 4.8,
      water_coolant_temp_c: Number(formData.get('water_coolant_temp_c')) || 75,
      fuel_level_percentage: Number(formData.get('fuel_level_percentage')) || 90,
      battery_voltage_v: Number(formData.get('battery_voltage_v')) || 26.4,
      ats_auto_transfer_ok: formData.get('ats_auto_transfer_ok') === 'on',
      circuit_breakers_ok: formData.get('circuit_breakers_ok') === 'on',
      exhaust_leak_free: formData.get('exhaust_leak_free') === 'on',
      test_result: (formData.get('test_result') as any) || 'pass',
      operator_name: (formData.get('operator_name') as string) || 'م/ عارف الصلوي',
      supervisor_name: (formData.get('supervisor_name') as string) || 'م/ نجيب غازي',
      notes: (formData.get('notes') as string) || '',
      created_at: new Date().toISOString(),
      synced: true,
    };

    await supabaseClient.from('cbahi_generator_tests').insert([newTest]);
    setGeneratorTests([newTest, ...generatorTests]);
    setShowAddGenModal(false);
  };

  // 3. ADD WATER TEST
  const handleSaveWaterTest = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData(form);

    const sourceKey = (formData.get('water_source') as any) || 'ground_tank';
    const sourceArMap: Record<string, string> = {
      ground_tank: 'الخزان الأرضي الرئيسي (100 ألف لتر)',
      roof_tanks: 'خزانات السطح العلوية',
      ro_hemodialysis: 'محطة التناضح العكسي RO (الغسيل الكلوي)',
      main_network: 'الشبكة العامة ومياه الشرب',
    };

    const newTest: CbahiWaterTest = {
      id: `WTR-${Date.now()}`,
      sample_code: `WTR-SAM-${Date.now().toString().slice(-6)}`,
      test_date: (formData.get('test_date') as string) || new Date().toISOString().split('T')[0],
      water_source: sourceKey,
      water_source_ar: sourceArMap[sourceKey] || 'مياه المستشفى العامة',
      test_type: (formData.get('test_type') as any) || 'bacterial',
      frequency: (formData.get('frequency') as any) || 'monthly',
      ph_level: Number(formData.get('ph_level')) || 7.2,
      residual_chlorine_ppm: Number(formData.get('residual_chlorine_ppm')) || 0.35,
      tds_ppm: Number(formData.get('tds_ppm')) || 280,
      turbidity_ntu: Number(formData.get('turbidity_ntu')) || 0.8,
      total_coliform_cfu: Number(formData.get('total_coliform_cfu')) || 0,
      e_coli_cfu: Number(formData.get('e_coli_cfu')) || 0,
      legionella_tested: formData.get('legionella_tested') === 'on',
      legionella_result: (formData.get('legionella_result') as any) || 'negative',
      laboratory_name: (formData.get('laboratory_name') as string) || 'مختبر الصحة العامة المركزي المعتمد',
      sample_collector: (formData.get('sample_collector') as string) || 'م/ نجيب غازي',
      test_status: (formData.get('test_status') as any) || 'compliant',
      notes: (formData.get('notes') as string) || 'المياه مطابقة كلياً للاشتراطات البكتيرية والفيزيائية لمعايير سباهي.',
      created_at: new Date().toISOString(),
      synced: true,
    };

    await supabaseClient.from('cbahi_water_tests').insert([newTest]);
    setWaterTests([newTest, ...waterTests]);
    setShowAddWaterModal(false);
  };

  // 4. ADD SAFETY COMMITTEE MEETING / TOUR
  const handleSaveCommitteeItem = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData(form);

    const recordType = (formData.get('record_type') as any) || 'meeting';
    const newComm: CbahiSafetyCommitteeItem = {
      id: `COMM-${Date.now()}`,
      record_type: recordType,
      meeting_number: Number(formData.get('meeting_number')) || 10,
      date: (formData.get('date') as string) || new Date().toISOString().split('T')[0],
      quarter: (formData.get('quarter') as any) || 'Q3',
      title: (formData.get('title') as string) || (recordType === 'meeting' ? 'محضر اجتماع لجنة السلامة وإدارة المرافق' : 'محضر جولة السلامة الربع سنوية'),
      location: (formData.get('location') as string) || 'قاعة الاجتماعات الرئيسية',
      chairperson: (formData.get('chairperson') as string) || 'د/ محمد السراجي - المدير العام',
      secretary: (formData.get('secretary') as string) || 'م/ نجيب غازي - رئيس السلامة',
      quality_coordinator: (formData.get('quality_coordinator') as string) || 'د/ نبيل عصار - منسق الجودة',
      attendees_count: Number(formData.get('attendees_count')) || 8,
      attendees_list: ((formData.get('attendees_list') as string) || 'د/ محمد السراجي, م/ نجيب غازي, د/ نبيل عصار, م/ عارف الصلوي')
        .split(',')
        .map(s => s.trim()),
      agenda_topics: ((formData.get('agenda_topics') as string) || 'مراجعة إجراءات السلامة ومؤشرات FMS')
        .split('\n')
        .filter(Boolean),
      decisions_and_recommendations: ((formData.get('decisions_and_recommendations') as string) || 'متابعة تنفيذ خطة الطوارئ وتدريب الكوادر')
        .split('\n')
        .filter(Boolean),
      cap_actions: [],
      minutes_file_attached: true,
      status: 'approved',
      notes: (formData.get('notes') as string) || '',
      created_at: new Date().toISOString(),
      synced: true,
    };

    await supabaseClient.from('cbahi_safety_committee').insert([newComm]);
    setCommitteeItems([newComm, ...committeeItems]);
    setShowAddCommitteeModal(false);
  };

  // Print Complete Portfolio
  const handlePrintFullPortfolio = () => {
    printComprehensiveCbahiPortfolio(standards, fireDrills, generatorTests, waterTests, committeeItems);
  };

  // Filtered Standards
  const filteredStandards = standards.filter(s => {
    const matchesCat = standardCategoryFilter === 'all' || s.category === standardCategoryFilter;
    const matchesSearch = !searchQuery ||
      s.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.titleAr.includes(searchQuery) ||
      s.titleEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.evidenceRef.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Top CBAHI Readiness Gauge Card */}
      <CbahiReadinessGauge
        standards={standards}
        onOpenPortfolioPrint={handlePrintFullPortfolio}
        onSelectStandardCategory={(cat) => {
          setStandardCategoryFilter(cat);
          setActiveTab('standards');
        }}
      />

      {/* Main Tab Navigation Bar */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-2">
        <div className="flex flex-wrap items-center justify-between gap-2">
          {/* Segmented Tabs */}
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              onClick={() => setActiveTab('risks')}
              className={`inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer ${
                activeTab === 'risks'
                  ? 'bg-gradient-to-r from-teal-700 to-slate-900 text-white shadow-md shadow-teal-200'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <ShieldAlert className="w-4 h-4 text-teal-400" />
              <span>تحليل وسجل المخاطر (FMS.1)</span>
              <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-black ${
                activeTab === 'risks' ? 'bg-teal-800 text-teal-100' : 'bg-teal-100 text-teal-800'
              }`}>
                5×5 Matrix
              </span>
            </button>

            <button
              onClick={() => setActiveTab('drills')}
              className={`inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer ${
                activeTab === 'drills'
                  ? 'bg-rose-600 text-white shadow-md shadow-rose-200'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Flame className="w-4 h-4" />
              <span>فرضيات الحريق والإخلاء (FMS.18)</span>
              <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-black ${
                activeTab === 'drills' ? 'bg-rose-700 text-white' : 'bg-slate-200 text-slate-700'
              }`}>
                {fireDrills.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('generators')}
              className={`inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer ${
                activeTab === 'generators'
                  ? 'bg-sky-600 text-white shadow-md shadow-sky-200'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Zap className="w-4 h-4" />
              <span>فحص المولدات وATS (FMS.31)</span>
              <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-black ${
                activeTab === 'generators' ? 'bg-sky-700 text-white' : 'bg-slate-200 text-slate-700'
              }`}>
                {generatorTests.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('water')}
              className={`inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer ${
                activeTab === 'water'
                  ? 'bg-teal-600 text-white shadow-md shadow-teal-200'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Droplets className="w-4 h-4" />
              <span>فحوصات جودة المياه (FMS.37)</span>
              <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-black ${
                activeTab === 'water' ? 'bg-teal-700 text-white' : 'bg-slate-200 text-slate-700'
              }`}>
                {waterTests.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('committee')}
              className={`inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer ${
                activeTab === 'committee'
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-200'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>لجنة السلامة وCAP (FMS.3)</span>
              <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-black ${
                activeTab === 'committee' ? 'bg-purple-700 text-white' : 'bg-slate-200 text-slate-700'
              }`}>
                {committeeItems.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('standards')}
              className={`inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer ${
                activeTab === 'standards'
                  ? 'bg-emerald-700 text-white shadow-md shadow-emerald-200'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Award className="w-4 h-4" />
              <span>دليل معايير سباهي (39 معياراً)</span>
            </button>
          </div>

          {/* Quick Action: Add Record */}
          <div className="flex items-center gap-2">
            {activeTab === 'drills' && (
              <button
                onClick={() => setShowAddDrillModal(true)}
                className="inline-flex items-center gap-1.5 bg-rose-600 hover:bg-rose-700 text-white px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold shadow-sm transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>تسجيل فرضية إخلاء جديدة</span>
              </button>
            )}

            {activeTab === 'generators' && (
              <button
                onClick={() => setShowAddGenModal(true)}
                className="inline-flex items-center gap-1.5 bg-sky-600 hover:bg-sky-700 text-white px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold shadow-sm transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>تسجيل فحص مولد جديد</span>
              </button>
            )}

            {activeTab === 'water' && (
              <button
                onClick={() => setShowAddWaterModal(true)}
                className="inline-flex items-center gap-1.5 bg-teal-600 hover:bg-teal-700 text-white px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold shadow-sm transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>تسجيل فحص مياه جديد</span>
              </button>
            )}

            {activeTab === 'committee' && (
              <button
                onClick={() => setShowAddCommitteeModal(true)}
                className="inline-flex items-center gap-1.5 bg-purple-600 hover:bg-purple-700 text-white px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold shadow-sm transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>توثيق محضر اجتماع / جولة</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* TAB 0: HOSPITAL RISK ASSESSMENT & 5x5 MATRIX (FMS.1) */}
      {activeTab === 'risks' && (
        <HospitalRiskAssessmentView currentUser={currentUser} />
      )}

      {/* TAB 1: FIRE & EVACUATION DRILLS (FMS.18) */}
      {activeTab === 'drills' && (
        <div className="space-y-4">
          <div className="bg-gradient-to-r from-rose-50 to-orange-50 border border-rose-200 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-600 text-white flex items-center justify-center shadow-md">
                <Flame className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-black text-rose-950">
                  سجل فرضيات وتجارب الحريق والإخلاء الوهمية (معيار سباهي FMS.18 - ESR)
                </h3>
                <p className="text-xs text-rose-800">
                  متطلب سباهي الحرج: تنفيذ وتوثيق فرضية إخلاء لكل وردية عمل (صباحي/مسائي/ليلي) سنوياً مع مؤشرات RACE و PASS.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="bg-rose-100 text-rose-800 text-xs font-bold px-3 py-1.5 rounded-xl border border-rose-300">
                معدل زمن الإخلاء: <strong>3 دقائق و 28 ثانية</strong>
              </span>
            </div>
          </div>

          {/* Drills Grid Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {fireDrills.map(drill => {
              const minutes = Math.floor(drill.evacuation_time_seconds / 60);
              const seconds = drill.evacuation_time_seconds % 60;
              const shiftBadge = drill.shift === 'morning' ? { text: 'وردية صباحية', bg: 'bg-amber-100 text-amber-800 border-amber-200' } :
                                 drill.shift === 'evening' ? { text: 'وردية مسائية', bg: 'bg-sky-100 text-sky-800 border-sky-200' } :
                                                             { text: 'وردية ليلية', bg: 'bg-indigo-100 text-indigo-800 border-indigo-200' };

              return (
                <div key={drill.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all p-4 flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-3">
                      <div>
                        <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full border ${shiftBadge.bg}`}>
                          {shiftBadge.text}
                        </span>
                        <h4 className="font-bold text-slate-900 text-sm mt-1.5 line-clamp-1">{drill.department}</h4>
                      </div>
                      <span className="text-[11px] font-mono font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                        {drill.drill_code}
                      </span>
                    </div>

                    {/* Stats */}
                    <div className="grid grid-cols-2 gap-2 bg-slate-50 p-2.5 rounded-xl text-xs mb-3">
                      <div>
                        <span className="text-slate-500 block text-[10px]">زمن الإخلاء الفعلي:</span>
                        <strong className="text-emerald-700 font-black text-sm">{minutes} د {seconds} ث</strong>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[10px]">تقييم الفرضية:</span>
                        <strong className="text-rose-700 font-black text-sm">{drill.evaluation_score}% ({drill.evaluation_rating === 'excellent' ? 'ممتاز' : 'جيد جداً'})</strong>
                      </div>
                    </div>

                    {/* RACE & PASS Checks */}
                    <div className="space-y-1.5 text-xs text-slate-700 mb-3">
                      <div className="flex items-center justify-between bg-emerald-50/60 px-2 py-1 rounded border border-emerald-100">
                        <span className="flex items-center gap-1 text-[11px]">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span>تطبيق بروتوكول RACE</span>
                        </span>
                        <strong className="text-emerald-700 font-bold text-[11px]">{drill.race_score}%</strong>
                      </div>

                      <div className="flex items-center justify-between bg-emerald-50/60 px-2 py-1 rounded border border-emerald-100">
                        <span className="flex items-center gap-1 text-[11px]">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span>تطبيق بروتوكول PASS</span>
                        </span>
                        <strong className="text-emerald-700 font-bold text-[11px]">{drill.pass_score}%</strong>
                      </div>

                      <div className="flex items-center justify-between text-[11px] text-slate-600 pt-1">
                        <span>عزل الغازات والكهرباء:</span>
                        <span className="font-bold text-emerald-700">
                          {drill.gas_isolated && drill.electricity_isolated ? '✓ تم العزل الآمن' : 'جزئي'}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-[11px] text-slate-500 flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      {drill.drill_date}
                    </span>

                    <button
                      onClick={() => printCbahiFireDrillReport(drill)}
                      className="inline-flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-white px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>تقرير PDF رسمي</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: GENERATOR & ATS LOAD TESTS (FMS.31) */}
      {activeTab === 'generators' && (
        <div className="space-y-4">
          <div className="bg-gradient-to-r from-sky-50 to-indigo-50 border border-sky-200 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-sky-600 text-white flex items-center justify-center shadow-md">
                <Zap className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-black text-sky-950">
                  سجل اختبارات المولدات الكهربائية ولوحات التحويل التلقائي ATS (CBAHI FMS.31 - ESR)
                </h3>
                <p className="text-xs text-sky-800">
                  فحص أسبوعي بدون حمل (10 دقائق) + فحص شهري بحمل تشغيلي (30 دقيقة). زمن إقلاع ATS المعياري: أقل من 10 ثوانٍ.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="bg-sky-100 text-sky-800 text-xs font-bold px-3 py-1.5 rounded-xl border border-sky-300">
                أحدث زمن إقلاع: <strong>7.2 ثانية</strong> (مطابق &lt; 10 ثوانٍ)
              </span>
            </div>
          </div>

          {/* Generator Tests Table */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs text-slate-700">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-900 font-bold">
                  <tr>
                    <th className="p-3">كود الفحص</th>
                    <th className="p-3">التاريخ والوقت</th>
                    <th className="p-3">نوع الفحص والمدة</th>
                    <th className="p-3">المولد المفحوص</th>
                    <th className="p-3">زمن التحويل ATS</th>
                    <th className="p-3">الجهد والتردد</th>
                    <th className="p-3">الديزل والبطارية</th>
                    <th className="p-3 text-center">النتيجة</th>
                    <th className="p-3 text-center">الإجراء</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {generatorTests.map(test => (
                    <tr key={test.id} className="hover:bg-slate-50 transition-colors">
                      <td className="p-3 font-mono font-bold text-sky-700">{test.test_code}</td>
                      <td className="p-3">
                        <span className="font-bold text-slate-900 block">{test.test_date}</span>
                        <span className="text-slate-500 text-[10px]">{test.test_time}</span>
                      </td>
                      <td className="p-3">
                        <span className="font-semibold block">
                          {test.test_type === 'weekly_no_load' ? 'أسبوعي بدون حمل' : 'شهري مع الحمل'}
                        </span>
                        <span className="text-slate-500 text-[10px]">{test.duration_minutes} دقيقة</span>
                      </td>
                      <td className="p-3 font-medium text-slate-800">{test.generator_name}</td>
                      <td className="p-3">
                        <span className="text-emerald-700 font-black text-sm block">
                          {test.auto_start_time_seconds} ث
                        </span>
                        <span className="text-[10px] text-slate-500">المعيار: ≤ 10 ث</span>
                      </td>
                      <td className="p-3">
                        <span className="font-bold block">{test.voltage_v} V</span>
                        <span className="text-slate-500 text-[10px]">{test.frequency_hz} Hz</span>
                      </td>
                      <td className="p-3">
                        <span className="text-slate-800 font-semibold block">وقود {test.fuel_level_percentage}%</span>
                        <span className="text-slate-500 text-[10px]">بطارية {test.battery_voltage_v} V</span>
                      </td>
                      <td className="p-3 text-center">
                        <span className="bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full text-[11px]">
                          اجتاز بنجاح ✓
                        </span>
                      </td>
                      <td className="p-3 text-center">
                        <button
                          onClick={() => printCbahiGeneratorTestReport(test)}
                          className="inline-flex items-center gap-1 text-sky-700 hover:text-sky-900 hover:bg-sky-50 font-bold px-2.5 py-1 rounded-lg border border-sky-200 transition-all cursor-pointer"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span>شهادة PDF</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: WATER BIOLOGICAL & CHEMICAL TESTS (FMS.37) */}
      {activeTab === 'water' && (
        <div className="space-y-4">
          <div className="bg-gradient-to-r from-teal-50 to-emerald-50 border border-teal-200 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-teal-600 text-white flex items-center justify-center shadow-md">
                <Droplets className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-black text-teal-950">
                  سجل الفحوصات البكتيرية والكيميائية الدورية للمياه (CBAHI FMS.37 - ESR)
                </h3>
                <p className="text-xs text-teal-800">
                  فحص بكتيري شهري لمصادر المياه ووحدة الغسيل الكلوي RO وفحص كيميائي نصف سنوي في مختبر مرجعي معتمد.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="bg-teal-100 text-teal-800 text-xs font-bold px-3 py-1.5 rounded-xl border border-teal-300">
                بكتيريا القولون: <strong>0 CFU (خالٍ تماماً)</strong>
              </span>
            </div>
          </div>

          {/* Water Tests Grid Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {waterTests.map(test => (
              <div key={test.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 hover:shadow-md transition-all">
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      test.test_type === 'bacterial' ? 'bg-teal-100 text-teal-800' : 'bg-indigo-100 text-indigo-800'
                    }`}>
                      {test.test_type === 'bacterial' ? 'فحص بكتيري شهري' : 'فحص كيميائي شامل'}
                    </span>
                    <h4 className="font-bold text-slate-900 text-sm mt-1">{test.water_source_ar}</h4>
                  </div>
                  <span className="text-xs font-mono font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                    {test.sample_code}
                  </span>
                </div>

                {/* Chemical & Biological Stats */}
                <div className="grid grid-cols-3 gap-2 bg-slate-50 p-3 rounded-xl text-xs mb-3 text-center">
                  <div>
                    <span className="text-slate-500 text-[10px] block">Coliform:</span>
                    <strong className="text-emerald-700 font-bold">{test.total_coliform_cfu} CFU</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 text-[10px] block">الكلور الحر:</span>
                    <strong className="text-teal-700 font-bold">{test.residual_chlorine_ppm} ppm</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 text-[10px] block">حموضة pH:</span>
                    <strong className="text-slate-900 font-bold">{test.ph_level}</strong>
                  </div>
                </div>

                <div className="space-y-1 text-xs text-slate-600 mb-3">
                  <div className="flex items-center justify-between">
                    <span>المختبر الفاحص:</span>
                    <strong className="text-slate-800">{test.laboratory_name}</strong>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>الليجيونيلا (Legionella):</span>
                    <span className="text-emerald-700 font-bold">
                      {test.legionella_tested ? 'سلبية (خالٍ تماماً)' : 'غير مطلوب'}
                    </span>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-[11px] text-slate-500 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" />
                    {test.test_date}
                  </span>

                  <button
                    onClick={() => printCbahiWaterTestReport(test)}
                    className="inline-flex items-center gap-1.5 bg-teal-700 hover:bg-teal-800 text-white px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>شهادة الفحص المخبري</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: SAFETY COMMITTEE & QUARTERLY TOURS WITH CAP (FMS.3) */}
      {activeTab === 'committee' && (
        <div className="space-y-4">
          <div className="bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-200 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-purple-600 text-white flex items-center justify-center shadow-md">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-black text-purple-950">
                  سجل اجتماعات وجولات لجنة السلامة وإدارة المرافق FMS (CBAHI FMS.3 - ESR)
                </h3>
                <p className="text-xs text-purple-800">
                  توثيق 10 اجتماعات سنوية على الأقل + جولات السلامة الربع سنوية المشتركة مع خطط العمل التصحيحية (CAP).
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="bg-purple-100 text-purple-800 text-xs font-bold px-3 py-1.5 rounded-xl border border-purple-300">
                الاجتماعات المنعقدة: <strong>9 اجتماعات (2026م)</strong>
              </span>
            </div>
          </div>

          {/* Committee Records List */}
          <div className="space-y-4">
            {committeeItems.map(item => (
              <div key={item.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm p-4 sm:p-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full ${
                      item.record_type === 'meeting' ? 'bg-purple-100 text-purple-800' : 'bg-amber-100 text-amber-800'
                    }`}>
                      {item.record_type === 'meeting' ? `اجتماع دوري #${item.meeting_number}` : `جولة السلامة المشتركة (${item.quarter})`}
                    </span>
                    <h4 className="text-base font-bold text-slate-900">{item.title}</h4>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500 flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      {item.date}
                    </span>
                    <button
                      onClick={() => printCbahiCommitteeReport(item)}
                      className="inline-flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-white px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>طباعة المحضر وCAP</span>
                    </button>
                  </div>
                </div>

                {/* Details */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3 text-xs">
                  <div className="bg-slate-50 p-3 rounded-xl">
                    <strong className="text-slate-800 block mb-1">جدول الأعمال والمحاور:</strong>
                    <ul className="space-y-1 list-disc list-inside text-slate-600">
                      {item.agenda_topics.map((t, idx) => (
                        <li key={idx}>{t}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-slate-50 p-3 rounded-xl">
                    <strong className="text-slate-800 block mb-1">القرارات والتوصيات المعتمدة:</strong>
                    <ul className="space-y-1 list-disc list-inside text-slate-700">
                      {item.decisions_and_recommendations.map((d, idx) => (
                        <li key={idx}><strong>{d}</strong></li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Corrective Action Plan (CAP) Table if present */}
                {item.cap_actions && item.cap_actions.length > 0 && (
                  <div className="mt-4 pt-3 border-t border-slate-100">
                    <h5 className="text-xs font-bold text-rose-800 mb-2 flex items-center gap-1">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      <span>خطة العمل التصحيحية الفورية (Corrective Action Plan - CAP):</span>
                    </h5>
                    <div className="overflow-x-auto">
                      <table className="w-full text-right text-xs">
                        <thead className="bg-rose-50/60 text-rose-950 font-bold border-b border-rose-200">
                          <tr>
                            <th className="p-2">الملاحظة المرصودة</th>
                            <th className="p-2">الإجراء التصحيحي</th>
                            <th className="p-2">المسؤول والقسم</th>
                            <th className="p-2 text-center">الموعد المستهدف</th>
                            <th className="p-2 text-center">الحالة</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {item.cap_actions.map(cap => (
                            <tr key={cap.id}>
                              <td className="p-2 font-medium text-slate-800">{cap.deficiency}</td>
                              <td className="p-2 text-emerald-800 font-semibold">{cap.corrective_action}</td>
                              <td className="p-2 text-slate-600">{cap.responsible_person} ({cap.department})</td>
                              <td className="p-2 text-center font-mono text-slate-500">{cap.target_date}</td>
                              <td className="p-2 text-center">
                                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                  cap.status === 'completed'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : 'bg-amber-100 text-amber-800'
                                }`}>
                                  {cap.status === 'completed' ? 'تم الإغلاق ✓' : 'قيد المتابعة'}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 5: CBAHI 39 STANDARDS DIRECTORY */}
      {activeTab === 'standards' && (
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            {/* Search Input */}
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ابحث برمز المعيار (FMS.18) أو العنوان أو الدليل..."
                className="w-full pr-9 pl-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 text-right"
              />
            </div>

            {/* Category Filter */}
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-slate-400" />
              <select
                value={standardCategoryFilter}
                onChange={(e) => setStandardCategoryFilter(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 text-right cursor-pointer"
              >
                <option value="all">جميع مجالات السلامة (39 معياراً)</option>
                <option value="القيادة وإدارة البرامج">القيادة وإدارة البرامج (FMS.1 - 6)</option>
                <option value="السلامة والأمن">السلامة والأمن (FMS.7 - 13)</option>
                <option value="السلامة من الحريق">السلامة من الحريق والإخلاء (FMS.14 - 20)</option>
                <option value="المواد والنفايات الخطرة">المواد والنفايات الخطرة (FMS.21 - 24)</option>
                <option value="الأجهزة والمعدات الطبية">الأجهزة والمعدات الطبية (FMS.25 - 28)</option>
                <option value="الأنظمة والمرافق والكهرباء">الأنظمة والمرافق والكهرباء (FMS.29 - 33)</option>
                <option value="سلامة وجودة المياه">سلامة وجودة المياه (FMS.34 - 37)</option>
                <option value="إدارة الطوارئ والكوارث">إدارة الطوارئ والكوارث (FMS.38 - 39)</option>
              </select>
            </div>
          </div>

          {/* Standards Cards Table */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs text-slate-700">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-900 font-bold">
                  <tr>
                    <th className="p-3 text-center">الرمز</th>
                    <th className="p-3">عنوان المعيار والشرح</th>
                    <th className="p-3">المجال</th>
                    <th className="p-3 text-center">الامتثال</th>
                    <th className="p-3">الوثائق والأدلة المطلوبة</th>
                    <th className="p-3 text-center">مرجع الدليل</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredStandards.map(std => (
                    <tr key={std.code} className="hover:bg-slate-50 transition-colors">
                      <td className="p-3 text-center">
                        <span className="font-mono font-black text-teal-700 block text-sm">{std.code}</span>
                        {std.esr && (
                          <span className="bg-rose-100 text-rose-800 text-[9px] font-bold px-1.5 py-0.5 rounded-full mt-1 inline-block">
                            ESR حرج
                          </span>
                        )}
                      </td>
                      <td className="p-3 max-w-xs sm:max-w-md">
                        <div className="font-bold text-slate-900 text-sm">{std.titleAr}</div>
                        <div className="text-[11px] text-slate-500 font-medium">{std.titleEn}</div>
                        <p className="text-[11px] text-slate-600 mt-1 line-clamp-2">{std.description}</p>
                      </td>
                      <td className="p-3">
                        <span className="bg-slate-100 text-slate-700 px-2.5 py-1 rounded-lg font-medium text-[11px]">
                          {std.category}
                        </span>
                      </td>
                      <td className="p-3 text-center">
                        <span className={`text-sm font-black ${std.complianceRate >= 95 ? 'text-emerald-600' : 'text-teal-600'}`}>
                          {std.complianceRate}%
                        </span>
                        <div className="w-14 bg-slate-100 h-1.5 rounded-full mx-auto mt-1 overflow-hidden">
                          <div
                            className={`h-full rounded-full ${std.complianceRate >= 95 ? 'bg-emerald-500' : 'bg-teal-500'}`}
                            style={{ width: `${std.complianceRate}%` }}
                          />
                        </div>
                      </td>
                      <td className="p-3 max-w-xs">
                        <ul className="space-y-0.5 text-[11px] text-slate-600 list-disc list-inside">
                          {std.requiredDocuments.map((doc, idx) => (
                            <li key={idx} className="truncate">{doc}</li>
                          ))}
                        </ul>
                      </td>
                      <td className="p-3 text-center font-mono text-teal-700 font-bold text-[11px]">
                        {std.evidenceRef}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ----------------- MODALS ----------------- */}

      {/* 1. Modal Add Fire Drill */}
      {showAddDrillModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-xl w-full p-5 shadow-2xl border border-slate-200 animate-in fade-in zoom-in duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2 text-rose-600">
                <Flame className="w-5 h-5" />
                <h3 className="font-bold text-slate-900 text-base">تسجيل فرضية وتجربة إخلاء جديدة (FMS.18)</h3>
              </div>
              <button
                onClick={() => setShowAddDrillModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveFireDrill} className="space-y-3 mt-4 text-xs text-right">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">القسم / الموقع:</label>
                  <input
                    type="text"
                    name="department"
                    defaultValue="قسم الطوارئ والإسعاف"
                    required
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-rose-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">الوردية:</label>
                  <select
                    name="shift"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-rose-500 cursor-pointer"
                  >
                    <option value="morning">وردية صباحية</option>
                    <option value="evening">وردية مسائية</option>
                    <option value="night">وردية ليلية</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">تاريخ الفرضية:</label>
                  <input
                    type="date"
                    name="drill_date"
                    defaultValue={new Date().toISOString().split('T')[0]}
                    required
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-rose-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">زمن الإخلاء (ثوانٍ):</label>
                  <input
                    type="number"
                    name="evacuation_time_seconds"
                    defaultValue={195}
                    required
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-rose-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">نسبة التقييم (%):</label>
                  <input
                    type="number"
                    name="evaluation_score"
                    defaultValue={96}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-rose-500 font-mono"
                  />
                </div>
              </div>

              {/* Checkboxes for RACE / PASS / Isolations */}
              <div className="p-3 bg-rose-50/50 rounded-xl border border-rose-100 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 cursor-pointer font-bold text-slate-800">
                    <input type="checkbox" name="race_applied" defaultChecked className="rounded text-rose-600 focus:ring-rose-500" />
                    <span>تطبيق بروتوكول RACE بالكامل</span>
                  </label>
                  <span className="text-slate-500 text-[11px]">Rescue • Alarm • Confine • Evacuate</span>
                </div>

                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 cursor-pointer font-bold text-slate-800">
                    <input type="checkbox" name="pass_applied" defaultChecked className="rounded text-rose-600 focus:ring-rose-500" />
                    <span>تطبيق بروتوكول PASS للطفايات</span>
                  </label>
                  <span className="text-slate-500 text-[11px]">Pull • Aim • Squeeze • Sweep</span>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1 border-t border-rose-100">
                  <label className="flex items-center gap-2 cursor-pointer font-bold text-slate-800">
                    <input type="checkbox" name="gas_isolated" defaultChecked className="rounded text-rose-600 focus:ring-rose-500" />
                    <span>عزل صمامات الغازات الطبية بالمنطقة</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer font-bold text-slate-800">
                    <input type="checkbox" name="electricity_isolated" defaultChecked className="rounded text-rose-600 focus:ring-rose-500" />
                    <span>فصل التيار الكهربائي غير الطارئ</span>
                  </label>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">الملاحظات والنتائج:</label>
                  <textarea
                    name="notes"
                    rows={2}
                    defaultValue="تمت التجربة بنجاح وسرعة استجابة عالية مع إخلاء آمن لكافة الحالات المحاكاة."
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-rose-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">توصيات فريق التحسين:</label>
                  <textarea
                    name="recommendations"
                    rows={2}
                    defaultValue="استمرار تدريب كادر التمريض الجديد في الورديات المسائية."
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-rose-500"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddDrillModal(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl font-bold transition-all cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="bg-rose-600 hover:bg-rose-700 text-white px-5 py-2 rounded-xl font-bold shadow-md transition-all cursor-pointer"
                >
                  حفظ الفرضية في سجل سباهي
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 2. Modal Add Generator Test */}
      {showAddGenModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-xl w-full p-5 shadow-2xl border border-slate-200 animate-in fade-in zoom-in duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2 text-sky-600">
                <Zap className="w-5 h-5" />
                <h3 className="font-bold text-slate-900 text-base">تسجيل اختبار مولد ولوحة ATS جديدة (FMS.31)</h3>
              </div>
              <button
                onClick={() => setShowAddGenModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveGeneratorTest} className="space-y-3 mt-4 text-xs text-right">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">اسم المولد والموقع:</label>
                  <input
                    type="text"
                    name="generator_name"
                    defaultValue="المولد الرئيسي Cummins 500 kVA"
                    required
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-sky-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">نوع الاختبار والمدة:</label>
                  <select
                    name="test_type"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-sky-500 cursor-pointer"
                  >
                    <option value="weekly_no_load">أسبوعي بدون حمل (10 دقائق)</option>
                    <option value="monthly_with_load">شهري مع الحمل الكامل (30 دقيقة)</option>
                    <option value="annual_triennial">اختبار سنوي تخصصي</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">زمن الإقلاع ATS (ثوانٍ):</label>
                  <input
                    type="number"
                    step="0.1"
                    name="auto_start_time_seconds"
                    defaultValue={7.2}
                    required
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-sky-500 font-mono font-bold"
                  />
                  <span className="text-[10px] text-slate-500">معيار سباهي: ≤ 10 ث</span>
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">الجهد الكهربائي (V):</label>
                  <input
                    type="number"
                    name="voltage_v"
                    defaultValue={395}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-sky-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">التردد (Hz):</label>
                  <input
                    type="number"
                    step="0.1"
                    name="frequency_hz"
                    defaultValue={50.0}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-sky-500 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">مستوى الديزل (%):</label>
                  <input
                    type="number"
                    name="fuel_level_percentage"
                    defaultValue={92}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-sky-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">ضغط الزيت (Bar):</label>
                  <input
                    type="number"
                    step="0.1"
                    name="oil_pressure_bar"
                    defaultValue={4.8}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-sky-500 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">جهد البطارية (V):</label>
                  <input
                    type="number"
                    step="0.1"
                    name="battery_voltage_v"
                    defaultValue={26.4}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-sky-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">ملاحظات الفحص والتشخيص:</label>
                <textarea
                  name="notes"
                  rows={2}
                  defaultValue="إقلاع سريع للمولد واستقرار تام في التردد والجهد مع نظافة تامة في مجرى العادم."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-sky-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddGenModal(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl font-bold transition-all cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="bg-sky-600 hover:bg-sky-700 text-white px-5 py-2 rounded-xl font-bold shadow-md transition-all cursor-pointer"
                >
                  حفظ الفحص في سجل سباهي
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 3. Modal Add Water Test */}
      {showAddWaterModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-xl w-full p-5 shadow-2xl border border-slate-200 animate-in fade-in zoom-in duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2 text-teal-600">
                <Droplets className="w-5 h-5" />
                <h3 className="font-bold text-slate-900 text-base">تسجيل فحص مياه بكتيري / كيميائي (FMS.37)</h3>
              </div>
              <button
                onClick={() => setShowAddWaterModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveWaterTest} className="space-y-3 mt-4 text-xs text-right">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">مصدر ونقطة سحب العينة:</label>
                  <select
                    name="water_source"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 cursor-pointer"
                  >
                    <option value="ground_tank">الخزان الأرضي الرئيسي</option>
                    <option value="roof_tanks">خزانات السطح العلوية</option>
                    <option value="ro_hemodialysis">محطة التناضح العكسي RO (الغسيل الكلوي)</option>
                    <option value="main_network">شبكة الشرب والمصدر الرئيسي</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">نوع الفحص والتكرار:</label>
                  <select
                    name="test_type"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 cursor-pointer"
                  >
                    <option value="bacterial">فحص بكتيري وميكروبي شهري</option>
                    <option value="chemical">فحص كيميائي شامل نصف سنوي</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">الكلور الحر (ppm):</label>
                  <input
                    type="number"
                    step="0.05"
                    name="residual_chlorine_ppm"
                    defaultValue={0.35}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 font-mono"
                  />
                  <span className="text-[10px] text-slate-500">الحد: 0.2 - 0.5 ppm</span>
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">الرقم الهيدروجيني pH:</label>
                  <input
                    type="number"
                    step="0.1"
                    name="ph_level"
                    defaultValue={7.3}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 font-mono"
                  />
                  <span className="text-[10px] text-slate-500">الحد: 6.5 - 8.5</span>
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Coliform (CFU):</label>
                  <input
                    type="number"
                    name="total_coliform_cfu"
                    defaultValue={0}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 font-mono"
                  />
                  <span className="text-[10px] text-slate-500">المعيار: 0 CFU</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">المختبر الفاحص:</label>
                  <input
                    type="text"
                    name="laboratory_name"
                    defaultValue="مختبر الصحة العامة المركزي المعتمد"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">فحص بكتيريا الليجيونيلا:</label>
                  <select
                    name="legionella_result"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500 cursor-pointer"
                  >
                    <option value="negative">سلبية (خالٍ تماماً Negative)</option>
                    <option value="positive">إيجابية</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">الملاحظات المخبرية:</label>
                <textarea
                  name="notes"
                  rows={2}
                  defaultValue="المياه صالحة للاستخدام وخالية تماماً من بكتيريا القولون والميكروبات."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddWaterModal(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl font-bold transition-all cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="bg-teal-600 hover:bg-teal-700 text-white px-5 py-2 rounded-xl font-bold shadow-md transition-all cursor-pointer"
                >
                  حفظ الفحص في سجل سباهي
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 4. Modal Add Safety Committee / Tour */}
      {showAddCommitteeModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-xl w-full p-5 shadow-2xl border border-slate-200 animate-in fade-in zoom-in duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2 text-purple-600">
                <Users className="w-5 h-5" />
                <h3 className="font-bold text-slate-900 text-base">توثيق محضر اجتماع أو جولة تفتيشية (FMS.3)</h3>
              </div>
              <button
                onClick={() => setShowAddCommitteeModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveCommitteeItem} className="space-y-3 mt-4 text-xs text-right">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">نوع السجل:</label>
                  <select
                    name="record_type"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500 cursor-pointer"
                  >
                    <option value="meeting">محضر اجتماع دوري للجنة السلامة</option>
                    <option value="quarterly_tour">محضر جولة السلامة الربع سنوية المشتركة</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">الربع السنوي والترتيب:</label>
                  <select
                    name="quarter"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500 cursor-pointer"
                  >
                    <option value="Q3">الربع الثالث (Q3 - 2026)</option>
                    <option value="Q4">الربع الرابع (Q4 - 2026)</option>
                    <option value="Q1">الربع الأول (Q1 - 2026)</option>
                    <option value="Q2">الربع الثاني (Q2 - 2026)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">عنوان المحضر / الجولة:</label>
                <input
                  type="text"
                  name="title"
                  defaultValue="محضر الاجتماع العاشر للجنة السلامة وإدارة المرافق FMS لعام 2026م"
                  required
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">تاريخ الانعقاد:</label>
                  <input
                    type="date"
                    name="date"
                    defaultValue={new Date().toISOString().split('T')[0]}
                    required
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">المكان:</label>
                  <input
                    type="text"
                    name="location"
                    defaultValue="قاعة الاجتماعات الرئيسية - الإدارة"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">جدول الأعمال (كل بند في سطر):</label>
                <textarea
                  name="agenda_topics"
                  rows={2}
                  defaultValue="مراجعة تقرير جاهزية طفايات الحريق&#10;مناقشة نتائج جولة السلامة البيئية&#10;خطة الفرضية القادمة"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">القرارات والتوصيات المعتمدة:</label>
                <textarea
                  name="decisions_and_recommendations"
                  rows={2}
                  defaultValue="اعتماد خطة الإخلاء للربع الرابع وتأكيد فحص مضخات الإطفاء أسبوعياً."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddCommitteeModal(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl font-bold transition-all cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="bg-purple-600 hover:bg-purple-700 text-white px-5 py-2 rounded-xl font-bold shadow-md transition-all cursor-pointer"
                >
                  اعتماد وحفظ المحضر
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
