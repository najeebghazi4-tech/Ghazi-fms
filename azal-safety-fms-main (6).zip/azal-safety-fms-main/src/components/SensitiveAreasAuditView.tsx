import React, { useState, useEffect } from 'react';
import { 
  Building2, 
  ShieldCheck, 
  Lock, 
  FileSpreadsheet, 
  Users, 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  Plus, 
  Printer, 
  Search, 
  Filter, 
  Trash2,
  Calendar,
  Layers
} from 'lucide-react';
import { SensitiveAreaAuditItem, StaffUser } from '../types';
import { offlineStorage } from '../services/offlineStorage';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';
import { executeSmartPrint } from '../utils/printUtils';

interface SensitiveAreasAuditViewProps {
  currentUser: StaffUser;
  onLogAudit: (action: string, actionAr: string, details: string) => void;
}

const INITIAL_SENSITIVE_AUDITS: SensitiveAreaAuditItem[] = [
  {
    id: 'sens-001',
    area: 'pharmacy',
    auditDate: new Date().toISOString().split('T')[0],
    accessControlSecured: true,
    fireProtectionReady: true,
    surveillanceCCTVOperational: true,
    confidentialityOrNarcoticsLocked: true,
    emergencyExitClear: true,
    scorePercentage: 100,
    status: 'passed',
    inspectorName: 'م/ نجيب غازي',
    notes: 'خزنة الأدوية المخدرة مقفلة بقفلين مزدوجين، كاميرات الصيدلية تغطي المداخل بالكامل، طفاية CO2 صالحة.',
    createdAt: Date.now() - 1000 * 60 * 60 * 6
  },
  {
    id: 'sens-002',
    area: 'medical_records',
    auditDate: new Date().toISOString().split('T')[0],
    accessControlSecured: true,
    fireProtectionReady: true,
    surveillanceCCTVOperational: true,
    confidentialityOrNarcoticsLocked: true,
    emergencyExitClear: true,
    scorePercentage: 95,
    status: 'passed',
    inspectorName: 'مشرف السلامة الميداني',
    notes: 'الأرشيف مغلق، منع دخول المرافقين والزوار، حساسات الدخان فعالة وممرات الملفات خالية من العوائق.',
    createdAt: Date.now() - 1000 * 60 * 60 * 24
  },
  {
    id: 'sens-003',
    area: 'hr_files',
    auditDate: new Date().toISOString().split('T')[0],
    accessControlSecured: true,
    fireProtectionReady: true,
    surveillanceCCTVOperational: true,
    confidentialityOrNarcoticsLocked: true,
    emergencyExitClear: true,
    scorePercentage: 90,
    status: 'passed',
    inspectorName: 'م/ نجيب غازي',
    notes: 'ملفات الموظفين والوثائق الرسمية داخل دواليب حديدية مقفلة، والتزام كامل بسياسة الخصوصية.',
    createdAt: Date.now() - 1000 * 60 * 60 * 48
  },
  {
    id: 'sens-004',
    area: 'cssd',
    auditDate: new Date().toISOString().split('T')[0],
    accessControlSecured: true,
    fireProtectionReady: true,
    surveillanceCCTVOperational: true,
    confidentialityOrNarcoticsLocked: true,
    emergencyExitClear: true,
    scorePercentage: 100,
    status: 'passed',
    inspectorName: 'مشرف السلامة والتعقيم',
    notes: 'الفصل الصارم بين خط التعقيم المتسخ والنظيف، الباكيتات معزولة على أرفف مرتفعة 25 سم عن الأرض.',
    createdAt: Date.now() - 1000 * 60 * 60 * 72
  }
];

export const SensitiveAreasAuditView: React.FC<SensitiveAreasAuditViewProps> = ({
  currentUser,
  onLogAudit
}) => {
  const [audits, setAudits] = useState<SensitiveAreaAuditItem[]>([]);
  const [selectedAreaFilter, setSelectedAreaFilter] = useState<string>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // Form states
  const [area, setArea] = useState<'pharmacy' | 'medical_records' | 'hr_files' | 'cssd'>('pharmacy');
  const [accessControlSecured, setAccessControlSecured] = useState(true);
  const [fireProtectionReady, setFireProtectionReady] = useState(true);
  const [surveillanceCCTVOperational, setSurveillanceCCTVOperational] = useState(true);
  const [confidentialityOrNarcoticsLocked, setConfidentialityOrNarcoticsLocked] = useState(true);
  const [emergencyExitClear, setEmergencyExitClear] = useState(true);
  const [notes, setNotes] = useState('');

  useEffect(() => {
    loadAudits();
  }, []);

  const loadAudits = async () => {
    try {
      const stored = await offlineStorage.getSensitiveAreaAudits();
      if (stored && stored.length > 0) {
        setAudits(stored);
      } else {
        setAudits(INITIAL_SENSITIVE_AUDITS);
        for (const item of INITIAL_SENSITIVE_AUDITS) {
          await offlineStorage.saveSensitiveAreaAudit(item);
        }
      }
    } catch {
      setAudits(INITIAL_SENSITIVE_AUDITS);
    }
  };

  const handleCreateAudit = async (e: React.FormEvent) => {
    e.preventDefault();

    const checkArray = [
      accessControlSecured,
      fireProtectionReady,
      surveillanceCCTVOperational,
      confidentialityOrNarcoticsLocked,
      emergencyExitClear
    ];
    const passedChecks = checkArray.filter(Boolean).length;
    const score = Math.round((passedChecks / 5) * 100);

    const status: 'passed' | 'conditional' | 'failed' = 
      score >= 80 ? 'passed' : score >= 60 ? 'conditional' : 'failed';

    const newAudit: SensitiveAreaAuditItem = {
      id: `sens-audit-${Date.now()}`,
      area,
      auditDate: new Date().toISOString().split('T')[0],
      accessControlSecured,
      fireProtectionReady,
      surveillanceCCTVOperational,
      confidentialityOrNarcoticsLocked,
      emergencyExitClear,
      scorePercentage: score,
      status,
      inspectorName: currentUser.name,
      notes: notes.trim() || 'تم إجراء التدقيق الأمني والوقائي الشامل للمنطقة الحساسة.',
      createdAt: Date.now()
    };

    const updated = [newAudit, ...audits];
    setAudits(updated);
    await offlineStorage.saveSensitiveAreaAudit(newAudit);

    // Auditory and haptic feedback
    triggerSuccessFeedback();

    const areaName = 
      area === 'pharmacy' ? 'الصيدلية الرئيسية' :
      area === 'medical_records' ? 'السجلات الطبية والأرشيف' :
      area === 'hr_files' ? 'ملفات شؤون الموظفين' : 'وحدة التعقيم المركزي CSSD';

    onLogAudit(
      'SENSITIVE_AREA_AUDIT_LOGGED',
      'تدقيق أمني للمناطق الحساسة',
      `تم إتمام التدقيق لمنطقة (${areaName}) بنسبة مطابقة ${score}% - الحالة: ${status}`
    );

    setShowAddModal(false);
    setNotes('');
  };

  const handlePrint = () => {
    const tableRows = filtered.map((a, idx) => {
      const meta = getAreaMeta(a.area);
      return `
        <tr>
          <td style="font-weight:bold; font-family:monospace;">${idx + 1}</td>
          <td><strong>${meta.title}</strong></td>
          <td style="font-family:monospace; font-size:11px;">${meta.cbahiRef}</td>
          <td>${a.auditDate}</td>
          <td>${a.accessControlSecured ? '<span class="badge-success">محكم ومقفل ✔</span>' : '<span class="badge-danger">غير محكم ✖</span>'}</td>
          <td>${a.fireProtectionReady ? '<span class="badge-success">جاهز وسليم ✔</span>' : '<span class="badge-danger">خلل ✖</span>'}</td>
          <td>${a.surveillanceCCTVOperational ? '<span class="badge-success">تغطية نشطة ✔</span>' : '<span class="badge-danger">معطل ✖</span>'}</td>
          <td>${a.emergencyExitClear ? '<span class="badge-success">سليم وسالك ✔</span>' : '<span class="badge-danger">معاق ✖</span>'}</td>
          <td style="font-weight:bold; font-size:13px;">${a.scorePercentage}%</td>
          <td>${a.status === 'passed' ? '<span class="badge-success">اجتياز ممتاز</span>' : a.status === 'conditional' ? '<span class="badge-warning">مشروط بتصحيح</span>' : '<span class="badge-danger">فشل التدقيق</span>'}</td>
          <td>${a.inspectorName}</td>
          <td>${a.notes || '-'}</td>
        </tr>
      `;
    }).join('');

    const bodyHtml = `
      <div class="summary-grid">
        <div class="summary-card"><div class="val">${audits.length}</div><div class="lbl">إجمالي تقارير التدقيق</div></div>
        <div class="summary-card"><div class="val" style="color:#047857;">${audits.filter(a => a.status === 'passed').length}</div><div class="lbl">اجتياز كامل (مطابق)</div></div>
        <div class="summary-card"><div class="val" style="color:#b45309;">${audits.filter(a => a.status === 'conditional').length}</div><div class="lbl">مشروط بإجراء تصحيحي</div></div>
        <div class="summary-card"><div class="val" style="color:#b91c1c;">${audits.filter(a => a.status === 'failed').length}</div><div class="lbl">غير مطابق (حرج)</div></div>
      </div>
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>المنطقة الحساسة</th>
            <th>معيار CBAHI</th>
            <th>التاريخ</th>
            <th>التحكم بالدخول</th>
            <th>مكافحة الحريق</th>
            <th>كاميرات CCTV</th>
            <th>مخارج الطوارئ</th>
            <th>النسبة</th>
            <th>الحالة</th>
            <th>المفتش</th>
            <th>الملاحظات والتوصيف</th>
          </tr>
        </thead>
        <tbody>
          ${tableRows || '<tr><td colspan="12" style="text-align:center; padding:12px;">لا توجد سجلات تدقيق</td></tr>'}
        </tbody>
      </table>
    `;

    executeSmartPrint(bodyHtml, {
      title: 'سجل تدقيق أمن وسلامة المناطق الحساسة الأربع (CBAHI Audit)',
      subtitle: 'الصيدلية الرئيسية • السجلات الطبية • ملفات الموظفين • وحدة التعقيم المركزي (CSSD)',
      refNumber: 'AZAL-SENSITIVE-AREAS-2026'
    });
  };

  const handleDelete = async (id: string) => {
    if (confirm('هل أنت متأكد من حذف تقرير التدقيق هذا؟')) {
      const updated = audits.filter(a => a.id !== id);
      setAudits(updated);
      await offlineStorage.deleteSensitiveAreaAudit(id);
    }
  };

  const getAreaMeta = (areaKey?: string) => {
    switch (areaKey) {
      case 'pharmacy':
        return {
          title: 'الصيدلية ومستودع الأدوية',
          icon: <Sparkles className="w-4 h-4 text-emerald-400" />,
          cbahiRef: 'CBAHI MMU / FMS.3'
        };
      case 'medical_records':
        return {
          title: 'السجلات الطبية والأرشيف',
          icon: <FileSpreadsheet className="w-4 h-4 text-blue-400" />,
          cbahiRef: 'CBAHI MOI / FMS.5'
        };
      case 'hr_files':
        return {
          title: 'ملفات الموارد البشرية وشؤون الموظفين',
          icon: <Users className="w-4 h-4 text-purple-400" />,
          cbahiRef: 'CBAHI HR / SEC.2'
        };
      case 'cssd':
        return {
          title: 'وحدة التعقيم المركزي (CSSD)',
          icon: <ShieldCheck className="w-4 h-4 text-teal-400" />,
          cbahiRef: 'CBAHI IPC.7 / FMS'
        };
      default:
        return {
          title: areaKey || 'منطقة حساسة',
          icon: <Building2 className="w-4 h-4 text-slate-400" />,
          cbahiRef: 'CBAHI FMS'
        };
    }
  };

  const filtered = audits.filter(a => {
    const matchArea = selectedAreaFilter === 'all' || a.area === selectedAreaFilter;
    const matchSearch = a.inspectorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        (a.notes && a.notes.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchArea && matchSearch;
  });

  return (
    <div id="sensitive-areas-audit-view" className="space-y-4 text-right">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-purple-950/70 border border-slate-800 rounded-3xl p-5 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-purple-950 border border-purple-800 text-purple-400">
            <Lock className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-slate-100">
                تدقيق أمن وسلامة المناطق الحساسة الأربع (CBAHI Sensitive Areas Audit)
              </h2>
              <span className="text-[10px] bg-purple-950 text-purple-300 border border-purple-800 font-bold px-2 py-0.5 rounded-lg">
                معيار الحماية القصوى
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              متابعة دورية مستمرة لـ (الصيدلية، السجلات الطبية، ملفات الموظفين، وحدة التعقيم CSSD) لحماية الأصول والسرية ومكافحة الحريق.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-md flex items-center gap-2 transition"
          >
            <Plus className="w-4 h-4" />
            <span>تسجيل تدقيق أمني جديد</span>
          </button>

          <button
            type="button"
            onClick={handlePrint}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold flex items-center gap-1.5 transition"
          >
            <Printer className="w-4 h-4" />
            <span>طباعة التدقيق (Print / PDF)</span>
          </button>
        </div>
      </div>

      {/* 4 Dedicated Cards for the 4 Sensitive Areas */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {(['pharmacy', 'medical_records', 'hr_files', 'cssd'] as const).map((areaKey) => {
          const areaAudits = audits.filter(a => a.area === areaKey);
          const latest = areaAudits[0];
          const meta = getAreaMeta(areaKey);

          return (
            <div
              key={areaKey}
              onClick={() => setSelectedAreaFilter(selectedAreaFilter === areaKey ? 'all' : areaKey)}
              className={`p-4 rounded-3xl border transition cursor-pointer ${
                selectedAreaFilter === areaKey
                  ? 'bg-slate-800 border-purple-500 shadow-md ring-1 ring-purple-500/50'
                  : 'bg-slate-900 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="p-2 rounded-xl bg-slate-950 border border-slate-800">
                  {meta.icon}
                </div>
                <span className="text-[10px] font-mono text-slate-400 bg-slate-950 px-2 py-0.5 rounded-lg border border-slate-800">
                  {meta.cbahiRef}
                </span>
              </div>
              <h3 className="font-bold text-slate-100 text-xs mt-2.5">{meta.title}</h3>
              <div className="flex items-center justify-between mt-3 pt-3 border-t border-slate-800/80 text-[11px]">
                <span className="text-slate-400">آخر تدقيق:</span>
                <span className="font-bold text-slate-200">{latest ? latest.auditDate : 'لم يسجل'}</span>
              </div>
              <div className="flex items-center justify-between mt-1 text-[11px]">
                <span className="text-slate-400">نسبة الالتزام:</span>
                <span className={`font-black ${latest?.scorePercentage && latest.scorePercentage >= 90 ? 'text-emerald-400' : 'text-amber-400'}`}>
                  {latest ? `${latest.scorePercentage}%` : '--'}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Filter and Search */}
      <div className="bg-slate-900/80 border border-slate-800 p-3 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex-1 min-w-[200px] relative">
          <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="بحث باسم المفتش أو الملاحظات..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-9 pl-3 py-2 text-slate-200"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={selectedAreaFilter}
            onChange={(e) => setSelectedAreaFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200"
          >
            <option value="all">كافة المناطق الحساسة (الأربع)</option>
            <option value="pharmacy">الصيدلية ومستودع الأدوية</option>
            <option value="medical_records">السجلات الطبية والأرشيف</option>
            <option value="hr_files">ملفات شؤون الموظفين</option>
            <option value="cssd">وحدة التعقيم المركزي (CSSD)</option>
          </select>
        </div>
      </div>

      {/* Audits Records Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-950 border-b border-slate-800 text-slate-400 font-bold">
              <tr>
                <th className="p-3.5">المنطقة الحساسة</th>
                <th className="p-3.5">تاريخ التدقيق</th>
                <th className="p-3.5 text-center">التحكم بالدخول</th>
                <th className="p-3.5 text-center">الوقاية من الحريق</th>
                <th className="p-3.5 text-center">كاميرات المراقبة</th>
                <th className="p-3.5 text-center">قفل الخزائن والسرية</th>
                <th className="p-3.5 text-center">مخارج الطوارئ</th>
                <th className="p-3.5 text-center">التقييم</th>
                <th className="p-3.5">المفتش والملاحظات</th>
                <th className="p-3.5 text-center">إجراء</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={10} className="p-8 text-center text-slate-400">
                    لا توجد سجلات تدقيق مطابقة
                  </td>
                </tr>
              ) : (
                filtered.map((item) => {
                  const meta = getAreaMeta(item.area);
                  return (
                    <tr key={item.id} className="hover:bg-slate-800/30 transition">
                      <td className="p-3.5">
                        <div className="flex items-center gap-2">
                          {meta.icon}
                          <span className="font-bold text-slate-100">{meta.title}</span>
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono mt-0.5">{meta.cbahiRef}</div>
                      </td>
                      <td className="p-3.5 text-slate-300 font-mono">
                        {item.auditDate}
                      </td>
                      <td className="p-3.5 text-center">
                        {item.accessControlSecured ? (
                          <span className="text-emerald-400 font-bold">✓ محكم</span>
                        ) : (
                          <span className="text-rose-400 font-bold">✕ مفتوح</span>
                        )}
                      </td>
                      <td className="p-3.5 text-center">
                        {item.fireProtectionReady ? (
                          <span className="text-emerald-400 font-bold">✓ جاهز</span>
                        ) : (
                          <span className="text-rose-400 font-bold">✕ غير جاهز</span>
                        )}
                      </td>
                      <td className="p-3.5 text-center">
                        {item.surveillanceCCTVOperational ? (
                          <span className="text-emerald-400 font-bold">✓ تعمل</span>
                        ) : (
                          <span className="text-amber-400 font-bold">✕ متوقفة</span>
                        )}
                      </td>
                      <td className="p-3.5 text-center">
                        {item.confidentialityOrNarcoticsLocked ? (
                          <span className="text-emerald-400 font-bold">✓ مقفلة</span>
                        ) : (
                          <span className="text-rose-400 font-bold">✕ غير مقفلة</span>
                        )}
                      </td>
                      <td className="p-3.5 text-center">
                        {item.emergencyExitClear ? (
                          <span className="text-emerald-400 font-bold">✓ سالكة</span>
                        ) : (
                          <span className="text-amber-400 font-bold">✕ بها عوائق</span>
                        )}
                      </td>
                      <td className="p-3.5 text-center">
                        <span className={`px-2.5 py-1 rounded-xl text-[11px] font-black ${
                          item.scorePercentage >= 90
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                            : item.scorePercentage >= 70
                            ? 'bg-amber-950 text-amber-300 border border-amber-800'
                            : 'bg-rose-950 text-rose-300 border border-rose-800'
                        }`}>
                          {item.scorePercentage}%
                        </span>
                      </td>
                      <td className="p-3.5">
                        <div className="text-slate-200 font-semibold">{item.inspectorName}</div>
                        <div className="text-[11px] text-slate-400 line-clamp-1">{item.notes}</div>
                      </td>
                      <td className="p-3.5 text-center">
                        <button
                          type="button"
                          onClick={() => handleDelete(item.id)}
                          className="p-1.5 rounded-lg bg-slate-800 text-rose-400 hover:bg-rose-950 hover:text-rose-300 transition"
                          title="حذف"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* New Sensitive Area Audit Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-purple-600/60 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
            <div className="bg-slate-950 px-5 py-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-purple-950 text-purple-400 border border-purple-800">
                  <Lock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-100">
                    تدقيق أمني لموقع حساس (CBAHI)
                  </h3>
                  <p className="text-[11px] text-slate-400">مستشفى آزال النموذجي • إدارة الأمن والسلامة</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="p-1 rounded-lg bg-slate-800 text-slate-400 hover:text-slate-100"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateAudit} className="p-5 space-y-4 overflow-y-auto text-xs">
              <div>
                <label className="text-slate-300 block mb-1 font-semibold">اختر المنطقة الحساسة:</label>
                <select
                  value={area}
                  onChange={(e) => setArea(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 font-bold"
                >
                  <option value="pharmacy">💊 1. الصيدلية ومستودع الأدوية المخدرة (Pharmacy)</option>
                  <option value="medical_records">📁 2. السجلات الطبية والأرشيف (Medical Records)</option>
                  <option value="hr_files">👥 3. ملفات الموارد البشرية وشؤون الموظفين (HR Files)</option>
                  <option value="cssd">🧼 4. وحدة التعقيم المركزي (CSSD)</option>
                </select>
              </div>

              {/* 5 Core Verification Checkpoints */}
              <div className="bg-slate-950/70 border border-purple-900/60 rounded-2xl p-3.5 space-y-2.5">
                <div className="text-purple-300 font-bold text-xs flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4" />
                  <span>معايير التفتيش الإلزامية للموقع:</span>
                </div>

                <label className="flex items-center justify-between p-2 rounded-xl bg-slate-900 border border-slate-800 cursor-pointer">
                  <span className="text-slate-200">التحكم بالدخول والأبواب مقفلة للكادر المصرح فقط:</span>
                  <input
                    type="checkbox"
                    checked={accessControlSecured}
                    onChange={(e) => setAccessControlSecured(e.target.checked)}
                    className="w-4 h-4 accent-purple-500 rounded"
                  />
                </label>

                <label className="flex items-center justify-between p-2 rounded-xl bg-slate-900 border border-slate-800 cursor-pointer">
                  <span className="text-slate-200">جاهزية منظومة إنذار وإطفاء الحريق وتوفر الطفاية المناسبة:</span>
                  <input
                    type="checkbox"
                    checked={fireProtectionReady}
                    onChange={(e) => setFireProtectionReady(e.target.checked)}
                    className="w-4 h-4 accent-purple-500 rounded"
                  />
                </label>

                <label className="flex items-center justify-between p-2 rounded-xl bg-slate-900 border border-slate-800 cursor-pointer">
                  <span className="text-slate-200">كاميرات المراقبة (CCTV) تغطي المداخل وتعمل بدقة:</span>
                  <input
                    type="checkbox"
                    checked={surveillanceCCTVOperational}
                    onChange={(e) => setSurveillanceCCTVOperational(e.target.checked)}
                    className="w-4 h-4 accent-purple-500 rounded"
                  />
                </label>

                <label className="flex items-center justify-between p-2 rounded-xl bg-slate-900 border border-slate-800 cursor-pointer">
                  <span className="text-slate-200">
                    {area === 'pharmacy' ? 'خزنة المخدرات مقفلة بقفل مزدوج' : 'الملفات والوثائق السرية محفوظة داخل خزائن مقفلة'}:
                  </span>
                  <input
                    type="checkbox"
                    checked={confidentialityOrNarcoticsLocked}
                    onChange={(e) => setConfidentialityOrNarcoticsLocked(e.target.checked)}
                    className="w-4 h-4 accent-purple-500 rounded"
                  />
                </label>

                <label className="flex items-center justify-between p-2 rounded-xl bg-slate-900 border border-slate-800 cursor-pointer">
                  <span className="text-slate-200">مخارج الطوارئ ومسارات الحركة سالكة وخالية من الكراتين:</span>
                  <input
                    type="checkbox"
                    checked={emergencyExitClear}
                    onChange={(e) => setEmergencyExitClear(e.target.checked)}
                    className="w-4 h-4 accent-purple-500 rounded"
                  />
                </label>
              </div>

              <div>
                <label className="text-slate-300 block mb-1 font-semibold">ملاحظات التدقيق وتوصيات السلامة:</label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="سجل أي ملاحظات أو نقاط تحتاج لمتابعة أمنية..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 text-xs"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>اعتماد وحفظ التدقيق</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
