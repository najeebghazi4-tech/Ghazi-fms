import React, { useState } from 'react';
import { 
  Database, 
  CheckCircle2, 
  Wifi, 
  WifiOff, 
  RefreshCw, 
  Layers, 
  HardDrive, 
  Server, 
  ShieldCheck, 
  X,
  Play,
  ArrowDownCircle
} from 'lucide-react';
import { DbMigration } from '../types';

interface DatabaseMigrationsModalProps {
  migrations: DbMigration[];
  isOnline: boolean;
  onApplyMigrations: () => void;
  onSyncNow: () => void;
  onClose: () => void;
}

export const DatabaseMigrationsModal: React.FC<DatabaseMigrationsModalProps> = ({
  migrations,
  isOnline,
  onApplyMigrations,
  onSyncNow,
  onClose,
}) => {
  const [applying, setApplying] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [syncCount, setSyncCount] = useState<number>(0);

  const handleApply = async () => {
    setApplying(true);
    await onApplyMigrations();
    setTimeout(() => {
      setApplying(false);
    }, 600);
  };

  const handleManualSync = async () => {
    setSyncing(true);
    await onSyncNow();
    setTimeout(() => {
      setSyncing(false);
    }, 800);
  };

  const appliedCount = migrations.filter((m) => m.status === 'applied').length;
  const pendingCount = migrations.filter((m) => m.status !== 'applied').length;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-3 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl my-auto animate-in fade-in zoom-in-95 duration-200 text-right">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-slate-900 p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-blue-950 border border-blue-700 text-blue-400">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100">
                إدارة قاعدة بيانات PostgreSQL ومزامنة IndexedDB
              </h3>
              <p className="text-xs text-slate-400">
                مستشفى آزال النموذجي • المعمارية الهجينة دون اتصال (Offline-First)
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-4 text-xs">
          {/* Online & Storage Status */}
          <div className="grid grid-cols-2 gap-2.5">
            <div className={`p-3 rounded-xl border flex items-center gap-2.5 ${
              isOnline
                ? 'bg-emerald-950/40 border-emerald-900 text-emerald-300'
                : 'bg-amber-950/40 border-amber-900 text-amber-300'
            }`}>
              {isOnline ? <Wifi className="w-5 h-5 text-emerald-400" /> : <WifiOff className="w-5 h-5 text-amber-400" />}
              <div>
                <span className="text-[10px] text-slate-400 block font-normal">حالة الشبكة الحالية</span>
                <strong className="text-xs font-bold block">
                  {isOnline ? 'متصل بالإنترنت (Online)' : 'يعمل دون إنترنت (Offline)'}
                </strong>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-2.5 text-teal-300">
              <HardDrive className="w-5 h-5 text-teal-400" />
              <div>
                <span className="text-[10px] text-slate-400 block font-normal">التخزين المحلي الآمن</span>
                <strong className="text-xs font-bold block text-slate-200">
                  IndexedDB مُفعّل ⚡
                </strong>
              </div>
            </div>
          </div>

          {/* Migrations Status Card */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-3.5 space-y-2.5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2">
                <Server className="w-4 h-4 text-blue-400" />
                <span className="font-bold text-slate-200">ترحيلات مخطط PostgreSQL (Migrations):</span>
              </div>
              <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-800">
                {appliedCount} / {migrations.length} معتمد
              </span>
            </div>

            <div className="space-y-2">
              {migrations.map((m) => (
                <div
                  key={m.id}
                  className="flex items-center justify-between p-2 rounded-lg bg-slate-900/80 border border-slate-800"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-blue-400 font-bold text-[11px]">{m.name}</span>
                      <span className="text-slate-400 text-[10px] font-mono">({m.version})</span>
                    </div>
                    <p className="text-[10px] text-slate-300 leading-relaxed">{m.details}</p>
                    <p className="text-[9px] text-slate-500 font-mono">{m.appliedAt}</p>
                  </div>
                  <div className="text-left shrink-0 mr-2">
                    {m.status === 'applied' ? (
                      <span className="inline-flex items-center gap-1 text-[10px] text-emerald-400 font-bold bg-emerald-950/80 border border-emerald-800 px-2 py-0.5 rounded">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>معتمد ومطبّق</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[10px] text-amber-400 font-bold bg-amber-950/80 border border-amber-800 px-2 py-0.5 rounded animate-pulse">
                        <span>معلق (Pending)</span>
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Apply migrations button if pending */}
            <div className="pt-2 flex items-center justify-between">
              <span className="text-[10px] text-slate-500">
                تم دمج الجداول: safety_tours, violations, fire_extinguishers
              </span>

              <button
                type="button"
                onClick={handleApply}
                disabled={applying}
                className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1.5 transition disabled:opacity-50"
              >
                <Play className="w-3.5 h-3.5" />
                <span>{applying ? 'جارِ التطبيق...' : 'تطبيق واعتماد الترحيلات فوراً'}</span>
              </button>
            </div>
          </div>

          {/* Auto-Sync and Offline Engine Info */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-3.5 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-200 flex items-center gap-1.5">
                <RefreshCw className={`w-4 h-4 text-teal-400 ${syncing ? 'animate-spin' : ''}`} />
                <span>محرك المزامنة التلقائية (Auto-Sync):</span>
              </span>
              <button
                type="button"
                onClick={handleManualSync}
                disabled={syncing}
                className="text-xs text-teal-400 hover:text-teal-300 font-bold flex items-center gap-1"
              >
                <span>مزامنة فورية الآن</span>
              </button>
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed">
              يقوم النظام بتخزين كافة الجولات وطفايات الحريق والمخالفات في قاعدة بيانات <strong>IndexedDB</strong> بالمتصفح تلقائياً عند انقطاع الاتصال، وتمريرها في رتل المزامنة (Sync Queue) فور عودة الاتصال دون فقدان أي سجل.
            </p>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold transition text-xs"
            >
              إغلاق النافذة
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
