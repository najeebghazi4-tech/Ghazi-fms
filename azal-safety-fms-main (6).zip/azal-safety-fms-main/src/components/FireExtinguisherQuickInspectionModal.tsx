import React, { useState } from 'react';
import { 
  X, 
  Flame, 
  CheckCircle2, 
  AlertTriangle, 
  Gauge, 
  ShieldCheck, 
  Check, 
  Save, 
  Calendar, 
  MapPin, 
  Scale, 
  FileText,
  BadgeAlert
} from 'lucide-react';
import { FireExtinguisherItem, StaffUser } from '../types';
import { VoiceDictationButton } from './VoiceDictationButton';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';
import { sanitizeInput } from '../utils/securityUtils';

interface FireExtinguisherQuickInspectionModalProps {
  extinguisher: FireExtinguisherItem;
  currentUser: StaffUser;
  onClose: () => void;
  onSave: (updatedItem: FireExtinguisherItem) => void;
  onLogAudit: (action: string, actionAr: string, details: string) => void;
}

export const FireExtinguisherQuickInspectionModal: React.FC<FireExtinguisherQuickInspectionModalProps> = ({
  extinguisher,
  currentUser,
  onClose,
  onSave,
  onLogAudit,
}) => {
  // 4 Core Monthly Checkpoints (CBAHI FMS.7 & Civil Defense)
  const [gaugeGreen, setGaugeGreen] = useState(true); // مؤشر الضغط في الأخضر
  const [safetyPinIntact, setSafetyPinIntact] = useState(true); // مسمار وقفل الأمان سليم
  const [hoseIntact, setHoseIntact] = useState(true); // سلامة الخرطوم والقاذف
  const [pathClear, setPathClear] = useState(true); // خلو الممر وسهولة الوصول
  const [cylinderBodyIntact, setCylinderBodyIntact] = useState(true); // سلامة جسم الأسطوانة والطلاء

  // Inspector details (Safety Officer)
  const [inspectorName, setInspectorName] = useState(
    currentUser.role === 'safety_head' || currentUser.name.includes('نجيب')
      ? currentUser.name
      : 'م/ نجيب غازي'
  );
  const [notes, setNotes] = useState(
    'فحص دوري شهري عبر قارئ كود QR: مؤشر الضغط في النطاق الأخضر، مسمار الأمان والترصيص سليم، الخرطوم سالك، والممر خالي من أي عوائق.'
  );

  const isAllPassed = gaugeGreen && safetyPinIntact && hoseIntact && pathClear && cylinderBodyIntact;

  const handleSaveInspection = (e: React.FormEvent) => {
    e.preventDefault();

    const now = new Date();
    const dateStr = now.toLocaleDateString('ar-YE', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    });
    const timeStr = now.toLocaleTimeString('ar-YE', {
      hour: '2-digit',
      minute: '2-digit',
    });
    const fullDateTimestamp = `${dateStr} ${timeStr}`;

    // Next inspection due in 30 days
    const nextDate = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
    const nextDueStr = nextDate.toISOString().split('T')[0];

    const cleanNotes = sanitizeInput(notes);
    const cleanInspector = sanitizeInput(inspectorName) || 'م/ نجيب غازي';

    const updatedItem: FireExtinguisherItem = {
      ...extinguisher,
      gaugeStatus: gaugeGreen ? 'normal' : 'low',
      conditionStatus: isAllPassed ? 'valid' : 'needs_maintenance',
      lastInspectedAt: fullDateTimestamp,
      lastInspectionDate: dateStr,
      lastInspectedDate: dateStr,
      nextInspectionDue: nextDueStr,
      notes: cleanNotes,
      inspectorName: cleanInspector,
      inspectorRole: 'رئيس قسم الأمن والسلامة',
      signatureProof: `اعتماد فحص QR دوري • ${cleanInspector} (${fullDateTimestamp})`,
      synced: true,
    };

    onSave(updatedItem);
    triggerSuccessFeedback();

    onLogAudit(
      'FIRE_EXTINGUISHER_QR_INSPECTED',
      'فحص شهري لطفاية حريق عبر QR Code',
      `تم استكمال الفحص الميداني لطفاية (${updatedItem.serialNumber}) بموقع (${updatedItem.location}) بنجاح. النتيجة: ${
        isAllPassed ? 'مطابقة ومفحوصة 🟢' : 'تحتاج صيانة 🟡'
      }. المفتش: ${cleanInspector}`
    );

    onClose();
  };

  return (
    <div
      id="fire-extinguisher-quick-inspection-modal"
      className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 text-right animate-fade-in"
      dir="rtl"
    >
      <div className="bg-slate-900 border border-teal-600/60 rounded-3xl w-full max-w-xl overflow-hidden shadow-2xl flex flex-col max-h-[94vh]">
        {/* Header */}
        <div className="bg-slate-950 px-5 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-teal-950 border border-teal-700 text-teal-400 shadow-md">
              <Flame className="w-6 h-6 text-red-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-100">
                  استمارة الفحص الدوري لطفاية الحريق
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                  مسح QR معتمد
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                فحص فوري ميداني مطابق لاشتراطات سباهي CBAHI FMS.7 والدفاع المدني
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <form onSubmit={handleSaveInspection} className="p-5 space-y-4 overflow-y-auto">
          {/* Extinguisher Profile Card */}
          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-2.5">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 rounded-lg bg-red-950 text-red-300 border border-red-800 font-mono font-bold text-sm">
                  {extinguisher.serialNumber}
                </span>
                <span className="text-xs font-bold text-slate-200">
                  {extinguisher.typeAr || 'طفاية حريق'}
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <span className="text-slate-400">السعة / الوزن:</span>
                <strong className="text-teal-300 font-mono">
                  {extinguisher.capacity || extinguisher.weight || '6 كجم'}
                </strong>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
              <div className="flex items-start gap-2 text-slate-300">
                <MapPin className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-slate-400 block text-[11px]">الموقع الميداني الدقيق:</span>
                  <span className="font-medium text-slate-200">{extinguisher.location}</span>
                </div>
              </div>

              <div className="flex items-start gap-2 text-slate-300">
                <Calendar className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-slate-400 block text-[11px]">تاريخ آخر فحص سابق:</span>
                  <span className="font-mono text-slate-200">
                    {extinguisher.lastInspectionDate || extinguisher.lastInspectedAt || 'لم يتم تسجيل فحص'}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Core Monthly Checklist (4 Requirements) */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold text-slate-200 flex items-center justify-between">
              <span>بنود الفحص الشهري الميداني (4 بنود فنية):</span>
              <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                isAllPassed 
                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' 
                  : 'bg-amber-950 text-amber-300 border border-amber-800'
              }`}>
                {isAllPassed ? 'مفحوصة ومطابقة 🟢' : 'تتطلب معالجة 🟡'}
              </span>
            </h4>

            {/* Check 1: Pressure Gauge */}
            <div className={`p-3 rounded-2xl border transition flex items-center justify-between gap-3 ${
              gaugeGreen 
                ? 'bg-slate-950 border-emerald-900/60' 
                : 'bg-amber-950/30 border-amber-800/80'
            }`}>
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-xl ${gaugeGreen ? 'bg-emerald-950 text-emerald-400' : 'bg-rose-950 text-rose-400'}`}>
                  <Gauge className="w-5 h-5" />
                </div>
                <div>
                  <strong className="text-xs text-slate-200 block">1. مؤشر الضغط في النطاق الأخضر (Normal Gauge)</strong>
                  <span className="text-[11px] text-slate-400">
                    التأكد من أن عقرب مقياس الضغط يستقر تماماً في المنطقة الخضراء السليمة
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => setGaugeGreen(true)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 ${
                    gaugeGreen 
                      ? 'bg-emerald-600 text-white shadow-md' 
                      : 'bg-slate-800 text-slate-400 hover:bg-slate-750'
                  }`}
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>في الأخضر ✔</span>
                </button>
                <button
                  type="button"
                  onClick={() => setGaugeGreen(false)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 ${
                    !gaugeGreen 
                      ? 'bg-rose-600 text-white shadow-md' 
                      : 'bg-slate-800 text-slate-400 hover:bg-slate-750'
                  }`}
                >
                  <span>منخفض ✖</span>
                </button>
              </div>
            </div>

            {/* Check 2: Safety Pin & Seal */}
            <div className={`p-3 rounded-2xl border transition flex items-center justify-between gap-3 ${
              safetyPinIntact 
                ? 'bg-slate-950 border-emerald-900/60' 
                : 'bg-amber-950/30 border-amber-800/80'
            }`}>
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-xl ${safetyPinIntact ? 'bg-emerald-950 text-emerald-400' : 'bg-rose-950 text-rose-400'}`}>
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <strong className="text-xs text-slate-200 block">2. سلامة مسمار الأمان والترصيص (Safety Pin)</strong>
                  <span className="text-[11px] text-slate-400">
                    وجود مسمار الأمان المعدني وقفل الحماية البلاستيكي دون أي عبث أو كسر
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => setSafetyPinIntact(true)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 ${
                    safetyPinIntact 
                      ? 'bg-emerald-600 text-white shadow-md' 
                      : 'bg-slate-800 text-slate-400 hover:bg-slate-750'
                  }`}
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>سليم ومؤمّن ✔</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSafetyPinIntact(false)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 ${
                    !safetyPinIntact 
                      ? 'bg-rose-600 text-white shadow-md' 
                      : 'bg-slate-800 text-slate-400 hover:bg-slate-750'
                  }`}
                >
                  <span>مفقود / مكسور ✖</span>
                </button>
              </div>
            </div>

            {/* Check 3: Hose & Nozzle */}
            <div className={`p-3 rounded-2xl border transition flex items-center justify-between gap-3 ${
              hoseIntact 
                ? 'bg-slate-950 border-emerald-900/60' 
                : 'bg-amber-950/30 border-amber-800/80'
            }`}>
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-xl ${hoseIntact ? 'bg-emerald-950 text-emerald-400' : 'bg-rose-950 text-rose-400'}`}>
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <div>
                  <strong className="text-xs text-slate-200 block">3. سلامة الخرطوم والقاذف (Hose & Nozzle)</strong>
                  <span className="text-[11px] text-slate-400">
                    خلو خرطوم وبوق التفريغ من أي شقوق أو تشققات أو انسداد بالأتربة
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => setHoseIntact(true)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 ${
                    hoseIntact 
                      ? 'bg-emerald-600 text-white shadow-md' 
                      : 'bg-slate-800 text-slate-400 hover:bg-slate-750'
                  }`}
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>سليم وسالك ✔</span>
                </button>
                <button
                  type="button"
                  onClick={() => setHoseIntact(false)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 ${
                    !hoseIntact 
                      ? 'bg-rose-600 text-white shadow-md' 
                      : 'bg-slate-800 text-slate-400 hover:bg-slate-750'
                  }`}
                >
                  <span>مشقوق / مسدود ✖</span>
                </button>
              </div>
            </div>

            {/* Check 4: Clear Path & Access */}
            <div className={`p-3 rounded-2xl border transition flex items-center justify-between gap-3 ${
              pathClear 
                ? 'bg-slate-950 border-emerald-900/60' 
                : 'bg-amber-950/30 border-amber-800/80'
            }`}>
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-xl ${pathClear ? 'bg-emerald-950 text-emerald-400' : 'bg-rose-950 text-rose-400'}`}>
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <strong className="text-xs text-slate-200 block">4. خلو الممر وسهولة الوصول (Clear Access)</strong>
                  <span className="text-[11px] text-slate-400">
                    لا توجد عوائق أو صناديق أو أسرّة تحجب الطفاية ومثبتة بالارتفاع النظامي
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => setPathClear(true)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 ${
                    pathClear 
                      ? 'bg-emerald-600 text-white shadow-md' 
                      : 'bg-slate-800 text-slate-400 hover:bg-slate-750'
                  }`}
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>سالك ومتاح ✔</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPathClear(false)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 ${
                    !pathClear 
                      ? 'bg-rose-600 text-white shadow-md' 
                      : 'bg-slate-800 text-slate-400 hover:bg-slate-750'
                  }`}
                >
                  <span>يوجد عوائق ✖</span>
                </button>
              </div>
            </div>

            {/* Check 5: Cylinder Body & Paint */}
            <div className={`p-3 rounded-2xl border transition flex items-center justify-between gap-3 ${
              cylinderBodyIntact 
                ? 'bg-slate-950 border-emerald-900/60' 
                : 'bg-amber-950/30 border-amber-800/80'
            }`}>
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-xl ${cylinderBodyIntact ? 'bg-emerald-950 text-emerald-400' : 'bg-rose-950 text-rose-400'}`}>
                  <Scale className="w-5 h-5" />
                </div>
                <div>
                  <strong className="text-xs text-slate-200 block">5. سلامة جسم الأسطوانة والطلاء (Cylinder Body)</strong>
                  <span className="text-[11px] text-slate-400">
                    خلو الأسطوانة من أي صدأ أو تآكل أو ضربات ميكانيكية والقاعدة سليمة
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  type="button"
                  onClick={() => setCylinderBodyIntact(true)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 ${
                    cylinderBodyIntact 
                      ? 'bg-emerald-600 text-white shadow-md' 
                      : 'bg-slate-800 text-slate-400 hover:bg-slate-750'
                  }`}
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>سليم ونظيف ✔</span>
                </button>
                <button
                  type="button"
                  onClick={() => setCylinderBodyIntact(false)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 ${
                    !cylinderBodyIntact 
                      ? 'bg-rose-600 text-white shadow-md' 
                      : 'bg-slate-800 text-slate-400 hover:bg-slate-750'
                  }`}
                >
                  <span>به صدأ / تآكل ✖</span>
                </button>
              </div>
            </div>
          </div>

          {/* Inspection Notes & Voice Dictation */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-300 flex items-center gap-1">
                <FileText className="w-3.5 h-3.5 text-teal-400" />
                <span>ملاحظات الفحص الشهري الميداني:</span>
              </label>
              <VoiceDictationButton
                value={notes}
                onChange={setNotes}
                title="إملاء صوتي لملاحظات فحص الطفاية"
              />
            </div>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-teal-500"
              placeholder="اكتب أي ملاحظات فنية أو إملاء صوتي..."
            />
          </div>

          {/* Inspector Sign-off Details */}
          <div className="p-3 bg-slate-950 border border-slate-800 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
            <div>
              <span className="text-slate-400 block text-[11px]">المفتش المعتمد (رئيس قسم السلامة):</span>
              <strong className="text-slate-200">{inspectorName}</strong>
            </div>
            <div className="text-[11px] text-teal-400 flex items-center gap-1 font-mono">
              <ShieldCheck className="w-4 h-4" />
              <span>اعتماد إلكتروني فوري • CBAHI OSH-FMS</span>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-lg shadow-emerald-950 flex items-center gap-2 transition"
            >
              <Save className="w-4 h-4" />
              <span>حفظ الفحص وتحديث السجل فوراً</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
