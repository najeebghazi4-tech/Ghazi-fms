import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Mic, MicOff } from 'lucide-react';

export interface VoiceDictationButtonProps {
  value?: string;
  onChange?: (val: string) => void;
  onTranscript?: (spokenText: string) => void;
  className?: string;
  size?: 'xs' | 'sm' | 'md';
  title?: string;
  lang?: 'ar-YE' | 'ar-SA';
  showLabel?: boolean;
}

interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList;
  resultIndex: number;
}

interface SpeechRecognitionErrorEvent extends Event {
  error: string;
  message?: string;
}

export const VoiceDictationButton: React.FC<VoiceDictationButtonProps> = ({
  value = '',
  onChange,
  onTranscript,
  className = '',
  size = 'sm',
  title = 'إملاء صوتي باللغة العربية (اضغط وتحدث مباشرة)',
  lang = 'ar-YE',
  showLabel = false,
}) => {
  const [isListening, setIsListening] = useState(false);
  const [isSupported, setIsSupported] = useState(true);
  const [showFeedback, setShowFeedback] = useState(false);
  const recognitionRef = useRef<any>(null);
  const valueRef = useRef(value);

  useEffect(() => {
    valueRef.current = value;
  }, [value]);

  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setIsSupported(false);
    }

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch {}
      }
    };
  }, []);

  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {}
    }
    setIsListening(false);
    setShowFeedback(false);
  }, []);

  const handleResult = useCallback(
    (spokenText: string) => {
      const trimmed = spokenText.trim();
      if (!trimmed) return;

      if (onTranscript) {
        onTranscript(trimmed);
      }

      if (onChange) {
        const currentVal = valueRef.current;
        if (currentVal && currentVal.trim()) {
          onChange(`${currentVal.trim()} ${trimmed}`);
        } else {
          onChange(trimmed);
        }
      }
    },
    [onChange, onTranscript]
  );

  const startListening = useCallback(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert('المتصفح لا يدعم ميزة الإملاء الصوتي المباشر. يُرجى استخدام متصفح Google Chrome أو Microsoft Edge حديث.');
      return;
    }

    try {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch {}
      }

      const recognition = new SpeechRecognition();
      recognition.lang = lang;
      recognition.continuous = true;
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;

      recognition.onstart = () => {
        setIsListening(true);
        setShowFeedback(true);
      };

      recognition.onresult = (event: SpeechRecognitionEvent) => {
        let finalTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          }
        }
        if (finalTranscript.trim()) {
          handleResult(finalTranscript);
        }
      };

      recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
        console.warn('Speech recognition error:', event.error);
        if (event.error === 'not-allowed') {
          alert('يرجى منح إذن استخدام الميكروفون في المتصفح لتفعيل ميزة الإملاء الصوتي الذاتي.');
        } else if (event.error === 'language-not-supported' && lang === 'ar-YE') {
          // Fallback to Saudi Arabic dialect
          try {
            recognition.lang = 'ar-SA';
            recognition.start();
            return;
          } catch {}
        }
        stopListening();
      };

      recognition.onend = () => {
        setIsListening(false);
        setShowFeedback(false);
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err) {
      console.error('Failed to start speech recognition:', err);
      setIsListening(false);
      setShowFeedback(false);
    }
  }, [handleResult, lang, stopListening]);

  const toggleListening = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };

  const sizeClasses = {
    xs: 'px-1.5 py-0.5 text-[10px] min-h-[24px]',
    sm: 'px-2 py-1 text-xs min-h-[28px]',
    md: 'px-2.5 py-1.5 text-xs min-h-[34px]',
  }[size];

  const iconSizes = {
    xs: 'w-3 h-3',
    sm: 'w-3.5 h-3.5',
    md: 'w-4 h-4',
  }[size];

  if (!isSupported) {
    return (
      <button
        type="button"
        disabled
        title="ميزة التعرف الصوتي غير مدعومة على هذا المتصفح"
        className={`rounded-lg bg-slate-800/40 text-slate-600 cursor-not-allowed inline-flex items-center justify-center gap-1 ${sizeClasses} ${className}`}
      >
        <MicOff className={iconSizes} />
        {showLabel && <span>إملاء صوتي</span>}
      </button>
    );
  }

  return (
    <div className="relative inline-flex items-center">
      <button
        type="button"
        onClick={toggleListening}
        title={isListening ? 'جارِ الاستماع... اضغط للإيقاف' : title}
        aria-label={isListening ? 'إيقاف الإملاء الصوتي' : 'بدء الإملاء الصوتي'}
        className={`rounded-xl transition-all duration-200 inline-flex items-center justify-center gap-1.5 shadow-sm select-none ${sizeClasses} ${
          isListening
            ? 'bg-rose-600 text-white animate-pulse ring-2 ring-rose-400 shadow-rose-900/50'
            : 'bg-slate-800/90 text-slate-300 hover:text-teal-300 hover:bg-slate-700 border border-slate-700/80 active:scale-95'
        } ${className}`}
      >
        <Mic className={`${iconSizes} ${isListening ? 'scale-110 text-white animate-bounce' : ''}`} />
        {showLabel && (
          <span className="font-bold">
            {isListening ? 'جارِ الاستماع...' : 'إملاء صوتي 🎙️'}
          </span>
        )}
      </button>

      {/* Visual listening indicator floating pill */}
      {showFeedback && (
        <span className="absolute -top-7 right-0 whitespace-nowrap bg-rose-950 text-rose-200 border border-rose-600/80 text-[10px] font-bold px-2 py-0.5 rounded-full shadow-xl animate-bounce z-50 flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-ping" />
          تحدث الآن بالعربية...
        </span>
      )}
    </div>
  );
};
