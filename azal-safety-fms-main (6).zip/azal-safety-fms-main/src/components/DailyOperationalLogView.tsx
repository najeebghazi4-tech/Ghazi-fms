import React, { useState, useEffect, useMemo } from 'react';
import { 
  ClipboardList, 
  Plus, 
  Calendar, 
  Clock, 
  Tag, 
  FileText, 
  Image as ImageIcon, 
  Upload, 
  Trash2, 
  AlertTriangle, 
  Search, 
  Filter, 
  Printer, 
  RefreshCw, 
  X, 
  CheckCircle2, 
  Eye, 
  Send, 
  Share2, 
  Flame, 
  ShieldAlert, 
  Sparkles,
  ExternalLink,
  ChevronDown,
  Layers
} from 'lucide-react';
import { supabase } from '../services/supabaseClient';
import { DailySafetyAction, StaffUser } from '../types';
import { executeSmartPrint } from '../utils/printUtils';

interface DailyOperationalLogViewProps {
  currentUser?: StaffUser;
  onLogAudit?: (action: string, actionAr: string, details: string) => void;
  onOpenResolvePortal?: (violationId: string) => void;
}

const COMMON_CATEGORIES = [
  'تولبكس (Toolbox Talk)',
  'إدارة النفايات الطبية',
  'جولة تفتيش ميدانية',
  'مخالفة أسطوانات الغاز',
  'متابعة بلاغ ومخاطر',
  'صيانة وتأهيل مرافق',
  'تدريب وتوعية ميدانية',
  'فحص أنظمة الإطفاء والإنذار',
  'مراقبة عمال مقاولين',
  'أخرى (تصنيف حر)'
];

const HOSPITAL_DEPARTMENTS = [
  'قسم الطوارئ والحوادث',
  'قسم العناية المركزة (ICU)',
  'قسم العمليات الجراحية',
  'محطة الغازات الطبية المركزية',
  'قسم الأشعة والتصوير الطبي',
  'قسم المختبر المركزي وبنك الدم',
  'أقسام الرقود - الدور الثاني',
  'أقسام الرقود - الدور الثالث',
  'قسم الحضانات وحديثي الولادة (NICU)',
  'المطبخ المركزي والتغذية',
  'المغسلة والمستودعات المركزية',
  'غرفة المولدات ومحطة الكهرباء',
  'المحرقة ومنطقة التخلص من النفايات',
];

const GAS_VIOLATION_TYPES = [
  'أسطوانات أكسجين غير مثبتة بسلاسل جدارية ومعرضة للسقوط',
  'تخزين أسطوانات فارغة مجهدة مع أسطوانات ممتلئة في نفس الموقع',
  'عدم وجود أغطية حماية للصمامات (Protective Valve Caps)',
  'رصد تسريب محتمل أو تلف في منظم الأسطوانة والخرطوم',
  'وضع أسطوانات غاز قابلة للاشتعال قرب مصدر حرارة أو لوحة كهرباء',
  'إعاقة ممر الهروب أو مسار عربات الطوارئ بأسطوانات غاز',
  'عدم تمييز وتصنيف أسطوانات الغاز الصناعي عن الغاز الطبي',
];

export const DailyOperationalLogView: React.FC<DailyOperationalLogViewProps> = ({
  currentUser,
  onLogAudit,
  onOpenResolvePortal,
}) => {
  const [actions, setActions] = useState<DailySafetyAction[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [dateFilter, setDateFilter] = useState<'all' | 'today' | 'week'>('all');
  
  // Modals
  const [showAddModal, setShowAddModal] = useState(false);
  const [showGasViolationModal, setShowGasViolationModal] = useState(false);
  const [selectedImagePreview, setSelectedImagePreview] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // General Action Form State
  const [formData, setFormData] = useState({
    title: '',
    category: COMMON_CATEGORIES[0],
    customCategory: '',
    action_date: new Date().toISOString().split('T')[0],
    action_time: new Date().toTimeString().slice(0, 5),
    details: '',
    image_url: '',
    logged_by: currentUser?.name || 'م. نجيب غازي (رئيس السلامة FMS)',
  });

  // Dedicated Gas Cylinder Violation Quick Form State
  const [gasFormData, setGasFormData] = useState({
    department: HOSPITAL_DEPARTMENTS[0],
    violationType: GAS_VIOLATION_TYPES[0],
    customViolation: '',
    severity: 'high' as 'low' | 'medium' | 'high' | 'critical',
    locationDetail: '',
    details: '',
    image_url: '',
    timeLimit: '24 ساعة (عاجل)',
    sendWhatsApp: true,
  });

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => {
      setNotification(null);
    }, 4000);
  };

  // Load from Supabase
  const loadActions = async () => {
    try {
      setRefreshing(true);
      const { data, error } = await supabase
        .from('daily_safety_actions')
        .select('*')
        .order('action_date', { ascending: false });

      if (error) {
        console.error('[Supabase] Error fetching daily_safety_actions:', error);
        showNotification('error', 'تعذر جلب السجل من Supabase، تم الاعتماد على البيانات المحلية');
      } else if (data) {
        setActions(data as DailySafetyAction[]);
      }
    } catch (err) {
      console.error('[Supabase] Fetch error:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadActions();
  }, []);

  // Image Upload Handler
  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>, isGas: boolean = false) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 8 * 1024 * 1024) {
      showNotification('error', 'حجم الصورة كبير جداً، الحد الأقصى المسموح 8 ميغابايت');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      if (isGas) {
        setGasFormData(prev => ({ ...prev, image_url: base64String }));
      } else {
        setFormData(prev => ({ ...prev, image_url: base64String }));
      }
      showNotification('success', 'تم تحميل ومعاينة الصورة بنجاح');
    };
    reader.readAsDataURL(file);
  };

  // Submit General Daily Action
  const handleSubmitAction = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) {
      showNotification('error', 'يرجى إدخال عنوان العمل المنجز');
      return;
    }

    if (!formData.details.trim()) {
      showNotification('error', 'يرجى كتابة تفاصيل العمل الميداني');
      return;
    }

    setIsSubmitting(true);
    const finalCategory = formData.category === 'أخرى (تصنيف حر)' && formData.customCategory.trim() 
      ? formData.customCategory.trim() 
      : formData.category;

    const newRecord: Partial<DailySafetyAction> = {
      id: `dact-${Date.now()}`,
      title: formData.title.trim(),
      category: finalCategory,
      action_date: formData.action_date,
      action_time: formData.action_time,
      details: formData.details.trim(),
      image_url: formData.image_url || undefined,
      logged_by: formData.logged_by,
      is_gas_cylinder_violation: false,
      created_at: new Date().toISOString(),
    };

    try {
      const { error } = await supabase.from('daily_safety_actions').insert([newRecord]);
      if (error) {
        throw error;
      }

      showNotification('success', 'تم حفظ وتوثيق العمل المنجز بنجاح في سجل العمليات اليومية');
      setShowAddModal(false);
      
      // Reset form
      setFormData({
        title: '',
        category: COMMON_CATEGORIES[0],
        customCategory: '',
        action_date: new Date().toISOString().split('T')[0],
        action_time: new Date().toTimeString().slice(0, 5),
        details: '',
        image_url: '',
        logged_by: currentUser?.name || 'م. نجيب غازي (رئيس السلامة FMS)',
      });

      if (onLogAudit) {
        onLogAudit('ADD_DAILY_ACTION', 'إضافة عمل ميداني منجز', `تم تسجيل: ${newRecord.title}`);
      }

      loadActions();
    } catch (err: any) {
      console.error('[Supabase] Insert error:', err);
      showNotification('error', 'حدث خطأ أثناء حفظ السجل');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Submit Fast Gas Cylinder Violation
  const handleSubmitGasViolation = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const finalViolation = gasFormData.customViolation.trim() || gasFormData.violationType;
    const noticeRef = `AZAL-GAS-${Date.now().toString().slice(-4)}`;

    const fullDetails = `[مخالفة أسطوانات غاز فورية]\nالقسم: ${gasFormData.department}\nالموقع المحدد: ${gasFormData.locationDetail || 'داخل القسم'}\nنوع الخلل: ${finalViolation}\nمستوى الخطورة: ${gasFormData.severity === 'critical' ? 'حرجة جداً' : gasFormData.severity === 'high' ? 'عالية' : 'متوسطة'}\nالمهلة المحددة: ${gasFormData.timeLimit}\n\nملاحظات وتفاصيل إضافية: ${gasFormData.details || 'مطلوب الالتزام بربط الأسطوانات وتأمينها فوراً بموجب اشتراطات CBAHI FMS.'}`;

    const newRecord: Partial<DailySafetyAction> = {
      id: `dact-gas-${Date.now()}`,
      title: `⚠️ رصد مخالفة أسطوانات غاز: ${gasFormData.department}`,
      category: 'مخالفة أسطوانات الغاز',
      action_date: new Date().toISOString().split('T')[0],
      action_time: new Date().toTimeString().slice(0, 5),
      details: fullDetails,
      image_url: gasFormData.image_url || undefined,
      logged_by: currentUser?.name || 'م. نجيب غازي (رئيس السلامة FMS)',
      is_gas_cylinder_violation: true,
      gas_violation_department: gasFormData.department,
      gas_violation_severity: gasFormData.severity,
      gas_violation_notice_id: noticeRef,
      created_at: new Date().toISOString(),
    };

    try {
      const { error } = await supabase.from('daily_safety_actions').insert([newRecord]);
      if (error) throw error;

      showNotification('success', `تم رصد وقيد مخالفة أسطوانات الغاز برقم مرجعي (${noticeRef})`);
      setShowGasViolationModal(false);

      if (onLogAudit) {
        onLogAudit('GAS_CYLINDER_VIOLATION', 'رصد مخالفة أسطوانات غاز', `تم رصد مخالفة في: ${gasFormData.department}`);
      }

      // If user wanted to send WhatsApp
      if (gasFormData.sendWhatsApp) {
        sendGasWhatsAppNotification(noticeRef, gasFormData.department, finalViolation, gasFormData.timeLimit);
      }

      // Reset gas form
      setGasFormData({
        department: HOSPITAL_DEPARTMENTS[0],
        violationType: GAS_VIOLATION_TYPES[0],
        customViolation: '',
        severity: 'high',
        locationDetail: '',
        details: '',
        image_url: '',
        timeLimit: '24 ساعة (عاجل)',
        sendWhatsApp: true,
      });

      loadActions();
    } catch (err) {
      console.error('[Supabase] Gas violation save error:', err);
      showNotification('error', 'تعذر حفظ مخالفة أسطوانات الغاز');
    } finally {
      setIsSubmitting(false);
    }
  };

  // WhatsApp Notification Builder
  const sendGasWhatsAppNotification = (refNum: string, dept: string, issue: string, timeLimit: string) => {
    const message = `مستشفى آزال النموذجي
قسم الأمن والسلامة وإدارة المرافق (FMS)

إشعار معالجة مخاطر (مخالفة أسطوانات الغاز):
الرقم المرجعي: ${refNum}
الموقع: ${dept}
الخلل: ${issue}
المهلة الزمنية للإنجاز: ${timeLimit}

رابط إفادة الإنجاز والمعالجة:
https://azal-safety.netlify.app/#statement?ref=${refNum}`;

    const encodedMsg = encodeURIComponent(message);
    window.open(`https://wa.me/?text=${encodedMsg}`, '_blank');
  };

  // Delete Action
  const handleDeleteAction = async (id: string, title: string) => {
    if (!confirm(`هل أنت متأكد من حذف النشاط: "${title}"؟`)) return;

    try {
      const { error } = await supabase.from('daily_safety_actions').delete().eq('id', id);
      if (error) throw error;

      setActions(prev => prev.filter(a => a.id !== id));
      showNotification('success', 'تم حذف السجل بنجاح');

      if (onLogAudit) {
        onLogAudit('DELETE_DAILY_ACTION', 'حذف عمل منجز', `تم حذف: ${title}`);
      }
    } catch (err) {
      console.error('[Supabase] Delete error:', err);
      showNotification('error', 'تعذر حذف النشاط');
    }
  };

  // Filtering
  const filteredActions = useMemo(() => {
    const todayStr = new Date().toISOString().split('T')[0];
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    const sevenDaysStr = sevenDaysAgo.toISOString().split('T')[0];

    return actions.filter(item => {
      const matchesSearch = 
        item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.details.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.logged_by.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesCategory = 
        categoryFilter === 'all' ? true :
        categoryFilter === 'gas' ? item.is_gas_cylinder_violation :
        item.category === categoryFilter;

      const matchesDate = 
        dateFilter === 'all' ? true :
        dateFilter === 'today' ? item.action_date === todayStr :
        item.action_date >= sevenDaysStr;

      return matchesSearch && matchesCategory && matchesDate;
    });
  }, [actions, searchTerm, categoryFilter, dateFilter]);

  // Statistics
  const stats = useMemo(() => {
    const todayStr = new Date().toISOString().split('T')[0];
    const total = actions.length;
    const todayCount = actions.filter(a => a.action_date === todayStr).length;
    const withPhotos = actions.filter(a => !!a.image_url).length;
    const gasViolations = actions.filter(a => !!a.is_gas_cylinder_violation).length;

    return { total, todayCount, withPhotos, gasViolations };
  }, [actions]);

  // PDF Export
  const handlePrintDailyReport = () => {
    const reportHtml = `
      <div style="font-family: inherit; direction: rtl; text-align: right;">
        <div style="background-color: #f8fafc; border: 1px solid #cbd5e1; border-radius: 8px; padding: 12px; margin-bottom: 16px;">
          <h2 style="margin: 0 0 6px 0; font-size: 16px; color: #0f766e;">تقرير سجل الأعمال والإنجازات الميدانية اليومية (FMS)</h2>
          <p style="margin: 0; font-size: 11px; color: #475569;">
            توثيق الأنشطة اليومية، تفريغ النفايات، اجتماعات التولبكس، وجولات السلامة ومخالفات أسطوانات الغاز
          </p>
          <div style="display: flex; gap: 16px; margin-top: 10px; font-size: 11px; font-weight: bold; color: #1e293b;">
            <span>إجمالي الأعمال: ${stats.total}</span>
            <span>أعمال اليوم: ${stats.todayCount}</span>
            <span>الموثقة بصور: ${stats.withPhotos}</span>
            <span>مخالفات أسطوانات الغاز: ${stats.gasViolations}</span>
          </div>
        </div>

        <table style="width: 100%; border-collapse: collapse; font-size: 10.5px;">
          <thead>
            <tr style="background-color: #0f766e; color: #ffffff;">
              <th style="padding: 8px 6px; border: 1px solid #cbd5e1; text-align: center; width: 40px;">#</th>
              <th style="padding: 8px 6px; border: 1px solid #cbd5e1; text-align: right; width: 100px;">التاريخ والوقت</th>
              <th style="padding: 8px 6px; border: 1px solid #cbd5e1; text-align: right; width: 120px;">التصنيف</th>
              <th style="padding: 8px 6px; border: 1px solid #cbd5e1; text-align: right;">عنوان النشاط والتفاصيل الميدانية</th>
              <th style="padding: 8px 6px; border: 1px solid #cbd5e1; text-align: right; width: 110px;">المسؤول المنفذ</th>
              <th style="padding: 8px 6px; border: 1px solid #cbd5e1; text-align: center; width: 60px;">التوثيق</th>
            </tr>
          </thead>
          <tbody>
            ${filteredActions.map((item, idx) => `
              <tr style="background-color: ${idx % 2 === 0 ? '#ffffff' : '#f8fafc'};">
                <td style="padding: 6px; border: 1px solid #cbd5e1; text-align: center; font-weight: bold;">${idx + 1}</td>
                <td style="padding: 6px; border: 1px solid #cbd5e1;">${item.action_date}<br><span style="color: #64748b; font-size: 9.5px;">${item.action_time}</span></td>
                <td style="padding: 6px; border: 1px solid #cbd5e1;">
                  <span style="font-weight: bold; color: ${item.is_gas_cylinder_violation ? '#b91c1c' : '#0f766e'};">
                    ${item.category}
                  </span>
                </td>
                <td style="padding: 6px; border: 1px solid #cbd5e1;">
                  <strong style="color: #0f172a; font-size: 11px;">${item.title}</strong>
                  <p style="margin: 4px 0 0 0; color: #334155; font-size: 10px; white-space: pre-line;">${item.details}</p>
                  ${item.gas_violation_notice_id ? `<span style="display: inline-block; margin-top: 4px; font-size: 9px; background: #fee2e2; color: #991b1b; padding: 2px 6px; border-radius: 4px; font-weight: bold;">إشعار: ${item.gas_violation_notice_id}</span>` : ''}
                </td>
                <td style="padding: 6px; border: 1px solid #cbd5e1; font-weight: bold; color: #334155;">${item.logged_by}</td>
                <td style="padding: 6px; border: 1px solid #cbd5e1; text-align: center;">
                  ${item.image_url ? '📷 مرفقة' : '—'}
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;

    executeSmartPrint(reportHtml, {
      title: 'سجل الأعمال والإنجازات اليومية الميدانية (FMS)',
      subtitle: 'مستشفى آزال النموذجي • إدارة الأمن والسلامة وإدارة المرافق • معتمد لمعايير CBAHI',
      refNumber: `AZAL-DAILY-${Date.now().toString().slice(-6)}`,
      inspectorName: currentUser?.name || 'م. نجيب غازي',
      department: 'قسم الأمن والسلامة وإدارة المرافق (FMS)',
    });
  };

  return (
    <div className="space-y-5 animate-in fade-in duration-300">
      {/* Toast Notification */}
      {notification && (
        <div 
          className={`fixed bottom-6 left-6 z-50 px-4 py-3 rounded-xl shadow-2xl flex items-center gap-2.5 text-xs font-bold transition transform animate-in slide-in-from-bottom duration-200 ${
            notification.type === 'success' 
              ? 'bg-emerald-600 text-white border border-emerald-400' 
              : 'bg-rose-600 text-white border border-rose-400'
          }`}
        >
          {notification.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
          <span>{notification.message}</span>
        </div>
      )}

      {/* Header & Quick Action Floating Banner */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 text-white shadow-xl backdrop-blur relative overflow-hidden">
        <div className="absolute -top-12 -left-12 w-48 h-48 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-12 -right-12 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 relative z-10">
          <div className="flex items-start gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-teal-950/80 border border-teal-500/30 text-teal-400 flex items-center justify-center shrink-0 shadow-inner">
              <ClipboardList className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-black tracking-tight text-white">
                  سجل الأعمال والإنجازات اليومية (Daily Operational Log)
                </h1>
                <span className="bg-teal-900/80 text-teal-300 border border-teal-600/40 text-[10px] font-black px-2 py-0.5 rounded-full">
                  FMS Daily Ops
                </span>
              </div>
              <p className="text-slate-400 text-xs mt-1 leading-relaxed max-w-2xl">
                نموذج مرن ومفتوح تماماً لتوثيق كافة الأنشطة الميدانية: اجتماعات التولبكس الصباحية، مراقبة النفايات والمحرقة، جولات المرافق، وتوثيق الصور، مع زر سريع لرصد مخالفات أسطوانات الغاز.
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Dedicated Floating Gas Cylinder Violation Button */}
            <button
              type="button"
              id="quick-gas-violation-btn"
              onClick={() => setShowGasViolationModal(true)}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 via-orange-600 to-rose-600 hover:from-amber-500 hover:to-rose-500 text-white font-black text-xs shadow-lg shadow-amber-950 flex items-center gap-2 transition active:scale-95 animate-pulse border border-amber-400/40"
              title="رصد فوري ومباشر لمخالفة أسطوانات الغاز الطبية أو الصناعية"
            >
              <AlertTriangle className="w-4 h-4 text-white" />
              <span>⚠️ رصد مخالفة أسطوانات الغاز</span>
            </button>

            {/* Standard Log Entry Button */}
            <button
              type="button"
              id="add-daily-action-btn"
              onClick={() => setShowAddModal(true)}
              className="px-4 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs shadow-lg shadow-teal-950 flex items-center gap-1.5 transition active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span>تسجيل عمل ميداني جديد</span>
            </button>

            <button
              type="button"
              onClick={handlePrintDailyReport}
              className="px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs flex items-center gap-1.5 transition"
              title="تصدير السجل اليومي لملف PDF رسمي"
            >
              <Printer className="w-4 h-4 text-teal-400" />
              <span>طباعة السجل (PDF)</span>
            </button>

            <button
              type="button"
              onClick={loadActions}
              disabled={refreshing}
              className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
              title="تحديث البيانات"
            >
              <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin text-teal-400' : ''}`} />
            </button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5 pt-4 border-t border-slate-800">
          <div className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-3">
            <span className="text-[11px] text-slate-400 block font-medium">إجمالي الأعمال المسجلة</span>
            <span className="text-xl font-black text-white mt-1 block">{stats.total}</span>
          </div>
          <div className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-3">
            <span className="text-[11px] text-slate-400 block font-medium">أعمال منجزة اليوم</span>
            <span className="text-xl font-black text-teal-400 mt-1 block">{stats.todayCount}</span>
          </div>
          <div className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-3">
            <span className="text-[11px] text-slate-400 block font-medium">أعمال موثقة بصور ميدانية</span>
            <span className="text-xl font-black text-blue-400 mt-1 block">{stats.withPhotos}</span>
          </div>
          <div className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-3">
            <span className="text-[11px] text-amber-300 block font-medium">مخالفات أسطوانات الغاز</span>
            <span className="text-xl font-black text-amber-400 mt-1 block">{stats.gasViolations}</span>
          </div>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3.5 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 flex-1 min-w-[240px]">
          <div className="relative w-full max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="بحث في عنوان العمل، التفاصيل، أو اسم المسؤول..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl pr-9 pl-3 py-2 text-white placeholder:text-slate-500 text-xs focus:outline-none focus:border-teal-500 transition"
            />
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Category Filter */}
          <div className="flex items-center gap-1.5 bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-1.5">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="bg-transparent text-slate-200 text-xs focus:outline-none cursor-pointer"
            >
              <option value="all" className="bg-slate-900">جميع التصنيفات ({actions.length})</option>
              <option value="gas" className="bg-slate-900 text-amber-400">⚠️ مخالفات أسطوانات الغاز فقط</option>
              {COMMON_CATEGORIES.map(cat => (
                <option key={cat} value={cat} className="bg-slate-900">{cat}</option>
              ))}
            </select>
          </div>

          {/* Date Filter */}
          <div className="flex items-center bg-slate-950 border border-slate-700 rounded-xl p-1 gap-1">
            <button
              type="button"
              onClick={() => setDateFilter('all')}
              className={`px-2.5 py-1 rounded-lg font-bold transition text-[11px] ${
                dateFilter === 'all' ? 'bg-teal-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              الكل
            </button>
            <button
              type="button"
              onClick={() => setDateFilter('today')}
              className={`px-2.5 py-1 rounded-lg font-bold transition text-[11px] ${
                dateFilter === 'today' ? 'bg-teal-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              اليوم
            </button>
            <button
              type="button"
              onClick={() => setDateFilter('week')}
              className={`px-2.5 py-1 rounded-lg font-bold transition text-[11px] ${
                dateFilter === 'week' ? 'bg-teal-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              آخر 7 أيام
            </button>
          </div>
        </div>
      </div>

      {/* Actions Timeline & Cards */}
      {loading ? (
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-12 text-center text-slate-400">
          <RefreshCw className="w-8 h-8 animate-spin mx-auto text-teal-400 mb-3" />
          <p className="text-sm">جاري تحميل سجل الأعمال اليومية من قاعدة البيانات...</p>
        </div>
      ) : filteredActions.length === 0 ? (
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-12 text-center text-slate-400">
          <ClipboardList className="w-12 h-12 mx-auto text-slate-600 mb-3" />
          <h3 className="text-base font-bold text-white mb-1">لا توجد أعمال مسجلة مطابقة للبحث</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto mb-4">
            يمكنك تسجيل نشاط ميداني جديد أو الضغط على زر رصد مخالفة أسطوانات الغاز للتوثيق الفوري.
          </p>
          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold inline-flex items-center gap-1.5 shadow"
          >
            <Plus className="w-4 h-4" />
            <span>تسجيل أول نشاط</span>
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredActions.map((action) => (
            <div
              key={action.id}
              className={`border rounded-2xl p-4 transition duration-200 shadow-md ${
                action.is_gas_cylinder_violation
                  ? 'bg-gradient-to-r from-amber-950/40 via-slate-900 to-slate-900 border-amber-500/40 hover:border-amber-400'
                  : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-3">
                {/* Header Information */}
                <div className="flex items-start gap-3">
                  <div 
                    className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border ${
                      action.is_gas_cylinder_violation
                        ? 'bg-amber-900/80 border-amber-500/50 text-amber-300'
                        : 'bg-teal-950 border-teal-500/30 text-teal-400'
                    }`}
                  >
                    {action.is_gas_cylinder_violation ? (
                      <AlertTriangle className="w-5 h-5" />
                    ) : (
                      <CheckCircle2 className="w-5 h-5" />
                    )}
                  </div>

                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-sm font-black text-white">
                        {action.title}
                      </h3>

                      <span 
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                          action.is_gas_cylinder_violation
                            ? 'bg-rose-950 text-rose-300 border-rose-800'
                            : 'bg-teal-950 text-teal-300 border-teal-800'
                        }`}
                      >
                        {action.category}
                      </span>

                      {action.gas_violation_notice_id && (
                        <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-slate-800 text-amber-300 border border-slate-700">
                          {action.gas_violation_notice_id}
                        </span>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-400">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-slate-500" />
                        {action.action_date}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-slate-500" />
                        {action.action_time}
                      </span>
                      <span className="flex items-center gap-1 text-slate-300">
                        <Tag className="w-3.5 h-3.5 text-slate-500" />
                        القائم بالعمل: {action.logged_by}
                      </span>
                      {action.gas_violation_department && (
                        <span className="text-amber-400 font-bold">
                          القسم: {action.gas_violation_department}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Quick Actions */}
                <div className="flex items-center gap-2 shrink-0 self-end md:self-auto">
                  {action.is_gas_cylinder_violation && action.gas_violation_notice_id && (
                    <button
                      type="button"
                      onClick={() => {
                        sendGasWhatsAppNotification(
                          action.gas_violation_notice_id!,
                          action.gas_violation_department || 'قسم المستشفى',
                          action.title,
                          'عاجل (24 ساعة)'
                        );
                      }}
                      className="px-2.5 py-1.5 rounded-xl bg-emerald-950 hover:bg-emerald-900 border border-emerald-700 text-emerald-300 text-xs font-bold flex items-center gap-1 transition"
                      title="إرسال إشعار واتساب رسمي للقسم"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                      <span>واتساب</span>
                    </button>
                  )}

                  {action.gas_violation_notice_id && onOpenResolvePortal && (
                    <button
                      type="button"
                      onClick={() => onOpenResolvePortal(action.gas_violation_notice_id!)}
                      className="px-2.5 py-1.5 rounded-xl bg-teal-950 hover:bg-teal-900 border border-teal-700 text-teal-300 text-xs font-bold flex items-center gap-1 transition"
                      title="فتح رابط إفادة الإنجاز والمعالجة"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>إفادة الإنجاز</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => handleDeleteAction(action.id, action.title)}
                    className="p-1.5 rounded-xl text-slate-500 hover:text-rose-400 hover:bg-rose-950/30 transition"
                    title="حذف هذا النشاط"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Free-form Details Box */}
              <div className="mt-3 bg-slate-950/70 border border-slate-800/80 rounded-xl p-3 text-xs text-slate-300 leading-relaxed whitespace-pre-line font-sans">
                {action.details}
              </div>

              {/* Photo Thumbnail if exists */}
              {action.image_url && (
                <div className="mt-3 flex items-center gap-3">
                  <div 
                    onClick={() => setSelectedImagePreview(action.image_url!)}
                    className="relative group cursor-pointer overflow-hidden rounded-xl border border-slate-700 bg-slate-950 w-24 h-20 shrink-0 shadow"
                  >
                    <img 
                      src={action.image_url} 
                      alt="توثيق ميداني" 
                      className="w-full h-full object-cover group-hover:scale-105 transition duration-200"
                    />
                    <div className="absolute inset-0 bg-slate-950/40 group-hover:bg-slate-950/10 flex items-center justify-center transition">
                      <Eye className="w-5 h-5 text-white drop-shadow" />
                    </div>
                  </div>

                  <div className="text-[11px] text-slate-400">
                    <span className="font-bold text-slate-300 block">📷 توثيق صورة ميدانية مرفقة</span>
                    <span className="text-slate-500">انقر على الصورة لمعاينتها بالحجم الكامل</span>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Image Lightbox Modal */}
      {selectedImagePreview && (
        <div 
          className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4"
          onClick={() => setSelectedImagePreview(null)}
        >
          <div 
            className="relative max-w-3xl w-full bg-slate-900 border border-slate-700 rounded-2xl overflow-hidden shadow-2xl p-2"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between p-3 border-b border-slate-800">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <ImageIcon className="w-4 h-4 text-teal-400" />
                معاينة الصورة الميدانية الموثقة
              </span>
              <button
                type="button"
                onClick={() => setSelectedImagePreview(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-2 max-h-[75vh] overflow-auto flex items-center justify-center bg-black/40 rounded-xl m-1">
              <img 
                src={selectedImagePreview} 
                alt="معاينة" 
                className="max-h-[70vh] w-auto max-w-full object-contain rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      )}

      {/* Modal 1: Standard Daily Action Form */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden text-right my-8">
            <div className="bg-gradient-to-r from-teal-900 to-slate-900 p-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-teal-800/80 text-teal-200 flex items-center justify-center">
                  <Plus className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-black text-white">تسجيل عمل وإنجاز ميداني جديد</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="p-1 text-slate-400 hover:text-white rounded-lg transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitAction} className="p-5 space-y-4 text-xs">
              {/* Title (Free text) */}
              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  عنوان النشاط / العمل المنجز <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="مثال: اجتماع التولبكس الصباحي مع فريق الصيانة العامة..."
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white placeholder:text-slate-500 focus:outline-none focus:border-teal-500"
                />
              </div>

              {/* Category */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">التصنيف</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none focus:border-teal-500"
                  >
                    {COMMON_CATEGORIES.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>

                {formData.category === 'أخرى (تصنيف حر)' ? (
                  <div>
                    <label className="block text-slate-300 font-bold mb-1">حدد التصنيف المخصص</label>
                    <input
                      type="text"
                      placeholder="اكتب اسم التصنيف..."
                      value={formData.customCategory}
                      onChange={(e) => setFormData({ ...formData, customCategory: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none focus:border-teal-500"
                    />
                  </div>
                ) : (
                  <div>
                    <label className="block text-slate-300 font-bold mb-1">المسؤول المنفذ</label>
                    <input
                      type="text"
                      value={formData.logged_by}
                      onChange={(e) => setFormData({ ...formData, logged_by: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none focus:border-teal-500"
                    />
                  </div>
                )}
              </div>

              {/* Date & Time */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">التاريخ</label>
                  <input
                    type="date"
                    required
                    value={formData.action_date}
                    onChange={(e) => setFormData({ ...formData, action_date: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none focus:border-teal-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-bold mb-1">الوقت</label>
                  <input
                    type="time"
                    required
                    value={formData.action_time}
                    onChange={(e) => setFormData({ ...formData, action_time: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none focus:border-teal-500"
                  />
                </div>
              </div>

              {/* Free-form Details Textarea */}
              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  تفاصيل العمل الميداني والبنود المنجزة <span className="text-rose-400">*</span>
                </label>
                <textarea
                  required
                  rows={5}
                  placeholder="حقل تفاصيل مفتوح بحرية تامة: اكتب كافة الإجراءات المتخذة، أسماء المشاركين، الملاحظات الميدانية، والنتائج..."
                  value={formData.details}
                  onChange={(e) => setFormData({ ...formData, details: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white placeholder:text-slate-500 focus:outline-none focus:border-teal-500 leading-relaxed font-sans"
                />
              </div>

              {/* Image Upload */}
              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  توثيق صورة ميدانية (اختياري)
                </label>
                <div className="border-2 border-dashed border-slate-700 hover:border-teal-500/60 rounded-xl p-3 text-center transition bg-slate-950/50">
                  {formData.image_url ? (
                    <div className="flex items-center justify-between gap-3">
                      <img 
                        src={formData.image_url} 
                        alt="معاينة" 
                        className="w-16 h-14 object-cover rounded-lg border border-slate-700" 
                      />
                      <span className="text-[11px] text-teal-400 font-bold">تم إرفاق الصورة بنجاح</span>
                      <button
                        type="button"
                        onClick={() => setFormData({ ...formData, image_url: '' })}
                        className="p-1.5 rounded-lg bg-rose-950 text-rose-300 border border-rose-800 text-[11px] hover:bg-rose-900 transition"
                      >
                        إزالة الصورة
                      </button>
                    </div>
                  ) : (
                    <div>
                      <Upload className="w-5 h-5 text-slate-400 mx-auto mb-1" />
                      <label className="cursor-pointer text-teal-400 hover:text-teal-300 font-bold">
                        <span>انقر لاختيار صورة أو التقاطها بالكاميرا</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleImageFileChange(e, false)}
                          className="hidden"
                        />
                      </label>
                      <p className="text-[10px] text-slate-500 mt-0.5">يدعم JPG, PNG حتى 8MB</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold transition"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold transition shadow-lg shadow-teal-950 flex items-center gap-1.5"
                >
                  {isSubmitting ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>جاري الحفظ...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>حفظ العمل المنجز</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 2: Fast Gas Cylinder Violation Quick Form */}
      {showGasViolationModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="relative w-full max-w-xl bg-slate-900 border-2 border-amber-500/60 rounded-2xl shadow-2xl overflow-hidden text-right my-8">
            <div className="bg-gradient-to-r from-amber-950 via-orange-950 to-slate-900 p-4 border-b border-amber-500/40 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-600 text-white flex items-center justify-center font-black">
                  ⚠️
                </div>
                <div>
                  <h3 className="text-sm font-black text-white">رصد وتوثيق مخالفة أسطوانات الغاز الطبية</h3>
                  <span className="text-[10px] text-amber-300">إشعار فوري مباشر • قسم السلامة وإدارة المرافق (FMS)</span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowGasViolationModal(false)}
                className="p-1 text-slate-400 hover:text-white rounded-lg transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitGasViolation} className="p-5 space-y-4 text-xs">
              {/* Department */}
              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  القسم المخالف <span className="text-rose-400">*</span>
                </label>
                <select
                  value={gasFormData.department}
                  onChange={(e) => setGasFormData({ ...gasFormData, department: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500"
                >
                  {HOSPITAL_DEPARTMENTS.map(dept => (
                    <option key={dept} value={dept}>{dept}</option>
                  ))}
                </select>
              </div>

              {/* Exact Location */}
              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  الموقع الدقيق داخل القسم
                </label>
                <input
                  type="text"
                  placeholder="مثال: بجانب سرير الفرز رقم 2، أو بجوار باب مخزن الأدوية..."
                  value={gasFormData.locationDetail}
                  onChange={(e) => setGasFormData({ ...gasFormData, locationDetail: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Violation Type */}
              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  نوع الخلل في أسطوانات الغاز <span className="text-rose-400">*</span>
                </label>
                <select
                  value={gasFormData.violationType}
                  onChange={(e) => setGasFormData({ ...gasFormData, violationType: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500"
                >
                  {GAS_VIOLATION_TYPES.map(vt => (
                    <option key={vt} value={vt}>{vt}</option>
                  ))}
                  <option value="خلل مخصص">خلل آخر (كتابة حرة)...</option>
                </select>
              </div>

              {gasFormData.violationType === 'خلل مخصص' && (
                <div>
                  <label className="block text-slate-300 font-bold mb-1">وصف الخلل المخصص</label>
                  <input
                    type="text"
                    required
                    placeholder="اكتب وصف الخلل بدقة..."
                    value={gasFormData.customViolation}
                    onChange={(e) => setGasFormData({ ...gasFormData, customViolation: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              )}

              {/* Severity & Time Limit */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">درجة الخطورة</label>
                  <select
                    value={gasFormData.severity}
                    onChange={(e) => setGasFormData({ ...gasFormData, severity: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="high">عالية (High)</option>
                    <option value="critical">حرجة جداً (Critical)</option>
                    <option value="medium">متوسطة (Medium)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-300 font-bold mb-1">المهلة الزمنية للإنجاز</label>
                  <select
                    value={gasFormData.timeLimit}
                    onChange={(e) => setGasFormData({ ...gasFormData, timeLimit: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="فوري (خلال ساعتين)">فوري (خلال ساعتين)</option>
                    <option value="24 ساعة (عاجل)">24 ساعة (عاجل)</option>
                    <option value="48 ساعة">48 ساعة</option>
                  </select>
                </div>
              </div>

              {/* Photo Upload */}
              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  صورة توثيق المخالفة فورياً <span className="text-amber-400">* مستحسن</span>
                </label>
                <div className="border-2 border-dashed border-amber-500/40 hover:border-amber-500 rounded-xl p-3 text-center transition bg-slate-950/60">
                  {gasFormData.image_url ? (
                    <div className="flex items-center justify-between gap-3">
                      <img 
                        src={gasFormData.image_url} 
                        alt="معاينة مخالفة الغاز" 
                        className="w-16 h-14 object-cover rounded-lg border border-amber-500/50" 
                      />
                      <span className="text-[11px] text-amber-300 font-bold">تم التقاط/إرفاق صورة المخالفة</span>
                      <button
                        type="button"
                        onClick={() => setGasFormData({ ...gasFormData, image_url: '' })}
                        className="p-1.5 rounded-lg bg-rose-950 text-rose-300 border border-rose-800 text-[11px] hover:bg-rose-900 transition"
                      >
                        إزالة
                      </button>
                    </div>
                  ) : (
                    <div>
                      <Upload className="w-5 h-5 text-amber-400 mx-auto mb-1" />
                      <label className="cursor-pointer text-amber-400 hover:text-amber-300 font-bold">
                        <span>التقط صورة المخالفة أو اختر من الألبوم</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleImageFileChange(e, true)}
                          className="hidden"
                        />
                      </label>
                      <p className="text-[10px] text-slate-400 mt-0.5">توثيق بالصورة لإلزام المشرف بالمعالجة الفورية</p>
                    </div>
                  )}
                </div>
              </div>

              {/* WhatsApp Toggle */}
              <div className="bg-emerald-950/40 border border-emerald-800/60 rounded-xl p-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Share2 className="w-4 h-4 text-emerald-400" />
                  <div>
                    <span className="text-xs font-bold text-white block">إرسال إشعار فوري عبر WhatsApp</span>
                    <span className="text-[10px] text-emerald-300">يفتح نص الرسالة الرسمية المعتمدة تلقائياً مع رابط إفادة الإنجاز</span>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={gasFormData.sendWhatsApp}
                  onChange={(e) => setGasFormData({ ...gasFormData, sendWhatsApp: e.target.checked })}
                  className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                />
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowGasViolationModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold transition"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-rose-600 hover:from-amber-500 hover:to-rose-500 text-white font-bold transition shadow-lg shadow-amber-950 flex items-center gap-1.5"
                >
                  {isSubmitting ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>جاري القيد والتوجيه...</span>
                    </>
                  ) : (
                    <>
                      <AlertTriangle className="w-4 h-4" />
                      <span>قيد المخالفة وإصدار الإشعار</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
