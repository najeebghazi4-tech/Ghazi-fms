import React, { useState, useEffect } from 'react';
import {
  Shield,
  ShieldAlert,
  Plus,
  Printer,
  Search,
  CheckCircle2,
  AlertTriangle,
  Clock,
  DollarSign,
  Watch,
  UserCheck,
  Lock,
  Calendar,
  Building,
  User,
  Trash2,
  FileText
} from 'lucide-react';
import { LostAndFoundItemRecord, StaffUser } from '../types';
import { INITIAL_PATIENT_VALUABLES } from '../data/azalPatientValuablesData';
import { offlineStorage } from '../services/offlineStorage';
import { AZAL_HOSPITAL_LOCATIONS } from '../data/azalSecurityData';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';
import { executeSmartPrint } from '../utils/printUtils';

interface PatientValuablesTrackerViewProps {
  currentUser: StaffUser;
  onLogAudit: (action: string, actionAr: string, details: string) => void;
}

export const PatientValuablesTrackerView: React.FC<PatientValuablesTrackerViewProps> = ({
  currentUser,
  onLogAudit
}) => {
  const [items, setItems] = useState<LostAndFoundItemRecord[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'safekeeping' | 'returned_to_owner' | 'overdue_180'>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedHandoverItem, setSelectedHandoverItem] = useState<LostAndFoundItemRecord | null>(null);

  // New Valuables Form State
  const [patientName, setPatientName] = useState('');
  const [patientMrn, setPatientMrn] = useState('');
  const [department, setDepartment] = useState('العناية المركزة ICU');
  const [bedRoom, setBedRoom] = useState('');
  const [depositDate, setDepositDate] = useState(new Date().toISOString().split('T')[0]);
  const [cashYemen, setCashYemen] = useState<number | ''>('');
  const [cashSaudi, setCashSaudi] = useState<number | ''>('');
  const [cashDollar, setCashDollar] = useState<number | ''>('');
  const [goldJewelry, setGoldJewelry] = useState('');
  const [electronics, setElectronics] = useState('');
  const [securityBagSeal, setSecurityBagSeal] = useState(`SEAL-AZAL-${Math.floor(10000 + Math.random() * 90000)}`);
  const [custodyLocker, setCustodyLocker] = useState('خزنة أمانات مكتب الأمن رقم 1');
  const [witnessStaff, setWitnessStaff] = useState('');
  const [generalNotes, setGeneralNotes] = useState('');

  // Handover Form State
  const [recipientName, setRecipientName] = useState('');
  const [recipientId, setRecipientId] = useState('');
  const [recipientPhone, setRecipientPhone] = useState('');
  const [recipientRelation, setRecipientRelation] = useState<'patient_self' | 'first_degree_relative' | 'legal_power_of_attorney'>('patient_self');

  useEffect(() => {
    loadValuables();
  }, []);

  const loadValuables = async () => {
    try {
      const stored = await offlineStorage.getLostAndFoundItems();
      const patientItems = stored.filter(i => i.patientValuables || i.itemReference.startsWith('VAL-'));
      if (patientItems.length > 0) {
        setItems(patientItems);
      } else {
        setItems(INITIAL_PATIENT_VALUABLES);
        for (const item of INITIAL_PATIENT_VALUABLES) {
          await offlineStorage.saveLostAndFoundItem(item);
        }
      }
    } catch {
      setItems(INITIAL_PATIENT_VALUABLES);
    }
  };

  // Helper to calculate days remaining until 180-day holding deadline
  const calculateDeadlineInfo = (depDate: string) => {
    const depositTime = new Date(depDate).getTime();
    const deadlineTime = depositTime + 180 * 24 * 60 * 60 * 1000;
    const now = Date.now();
    const diffDays = Math.ceil((deadlineTime - now) / (1000 * 60 * 60 * 24));
    const deadlineDateStr = new Date(deadlineTime).toISOString().split('T')[0];
    const isExceeded = diffDays <= 0;
    return {
      diffDays,
      deadlineDateStr,
      isExceeded,
      isNearExpiry: diffDays > 0 && diffDays <= 30
    };
  };

  const handleCreateValuables = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientName.trim()) return;

    const currentYear = new Date().getFullYear();
    const count = items.length + 1;
    const itemReference = `VAL-${currentYear}-${String(count).padStart(3, '0')}`;
    const deadlineInfo = calculateDeadlineInfo(depositDate);

    // Build description summary
    const descParts = [];
    if (cashYemen || cashSaudi || cashDollar) {
      const cashList = [];
      if (cashYemen) cashList.push(`${cashYemen.toLocaleString()} ر.ي`);
      if (cashSaudi) cashList.push(`${cashSaudi.toLocaleString()} ر.س`);
      if (cashDollar) cashList.push(`${cashDollar.toLocaleString()} $`);
      descParts.push(`نقد (${cashList.join(' + ')})`);
    }
    if (goldJewelry) descParts.push(`مجوهرات (${goldJewelry})`);
    if (electronics) descParts.push(`أجهزة (${electronics})`);
    const finalDescription = descParts.length > 0 ? descParts.join(' • ') : 'أمانات ومقتنيات شخصية للمريض';

    const newItem: LostAndFoundItemRecord = {
      id: `pv-${Date.now()}`,
      itemReference,
      foundDate: depositDate,
      foundLocation: `${department} - ${bedRoom || 'سرير التنويم'}`,
      itemCategory: goldJewelry ? 'jewelry_watch' : (cashYemen || cashSaudi || cashDollar ? 'money' : 'electronics'),
      description: finalDescription,
      finderName: witnessStaff ? `${witnessStaff} (تمريض)` : 'طاقم التمريض والاستقبال',
      custodyLocation: custodyLocker,
      status: 'safekeeping',
      patientValuables: {
        patientName: patientName.trim(),
        patientMrn: patientMrn.trim() || `MRN-${Math.floor(10000 + Math.random() * 90000)}`,
        patientAdmissionDate: depositDate,
        holdingDeadlineDate: deadlineInfo.deadlineDateStr,
        is180DayHoldingExceeded: deadlineInfo.isExceeded,
        cashAmountYemen: cashYemen ? Number(cashYemen) : undefined,
        cashAmountSaudi: cashSaudi ? Number(cashSaudi) : undefined,
        cashAmountDollar: cashDollar ? Number(cashDollar) : undefined,
        goldOrJewelryDetails: goldJewelry.trim() || undefined,
        electronicsDetails: electronics.trim() || undefined,
        securityBagSealNumber: securityBagSeal.trim(),
        witnessStaffName: witnessStaff.trim() || currentUser.name
      },
      notes: generalNotes.trim() || `تم حرز الأمانات في الكيس الأمني رقم (${securityBagSeal}) بحضور الشاهد وتم التحقق من سلامتها. المهلة النظامية للحفظ حتى ${deadlineInfo.deadlineDateStr}.`,
      createdAt: Date.now()
    };

    const updated = [newItem, ...items];
    setItems(updated);
    await offlineStorage.saveLostAndFoundItem(newItem);
    triggerSuccessFeedback();

    onLogAudit(
      'PATIENT_VALUABLES_REGISTERED',
      'إيداع أمانات مريض جديدة',
      `تم إيداع أمانات المريض (${patientName}) كود ${itemReference} برقم كيس أمانات (${securityBagSeal}) مع تحديد مهلة الحفظ حتى (${deadlineInfo.deadlineDateStr}).`
    );

    setShowAddModal(false);
    // Reset Form
    setPatientName('');
    setPatientMrn('');
    setBedRoom('');
    setCashYemen('');
    setCashSaudi('');
    setCashDollar('');
    setGoldJewelry('');
    setElectronics('');
    setGeneralNotes('');
    setWitnessStaff('');
  };

  const handleHandoverSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedHandoverItem || !recipientName.trim() || !recipientId.trim()) return;

    const today = new Date().toISOString().split('T')[0];
    const relationAr = 
      recipientRelation === 'patient_self' ? 'المريض شخصياً' :
      recipientRelation === 'first_degree_relative' ? 'قريب درجة أولى بموجب تفويض رسمي' : 'وكيل شرعي بموجب وكالة قانونية';

    const updatedItem: LostAndFoundItemRecord = {
      ...selectedHandoverItem,
      status: 'returned_to_owner',
      claimedByName: `${recipientName.trim()} (${relationAr})`,
      claimedByIdNumber: recipientId.trim(),
      claimedByPhone: recipientPhone.trim() || undefined,
      handedOverDate: today,
      securityOfficerHandover: currentUser.name,
      notes: (selectedHandoverItem.notes ? selectedHandoverItem.notes + '\n' : '') +
             `[تم تسليم الأمانات رسميّاً لـ: ${recipientName} (${relationAr}) بموجب إثبات الهوية (${recipientId}) في ${today} بواسطة ضابط الأمن ${currentUser.name}]`
    };

    const updated = items.map(i => i.id === selectedHandoverItem.id ? updatedItem : i);
    setItems(updated);
    await offlineStorage.saveLostAndFoundItem(updatedItem);
    triggerSuccessFeedback();

    onLogAudit(
      'PATIENT_VALUABLES_HANDOVER',
      'تسليم أمانات مريض رسمياً',
      `تم تسليم أمانات المريض (${selectedHandoverItem.patientValuables?.patientName || selectedHandoverItem.description}) للمستلم (${recipientName}) بموجب الهوية (${recipientId}).`
    );

    setSelectedHandoverItem(null);
    setRecipientName('');
    setRecipientId('');
    setRecipientPhone('');
  };

  const handleDelete = async (id: string) => {
    if (confirm('هل أنت متأكد من حذف سجل أمانات المريض؟')) {
      const updated = items.filter(i => i.id !== id);
      setItems(updated);
      await offlineStorage.deleteLostAndFoundItem(id);
    }
  };

  // Print Patient Valuables Register & Official Vouchers
  const handlePrintRegister = () => {
    const tableRows = filteredItems.map((item, idx) => {
      const p = item.patientValuables;
      const deadlineInfo = calculateDeadlineInfo(p?.patientAdmissionDate || item.foundDate);
      const deadlineBadge = item.status === 'returned_to_owner'
        ? '<span style="color:#047857; font-weight:bold;">سُلّمت للمريض</span>'
        : deadlineInfo.isExceeded
        ? '<span style="color:#b91c1c; font-weight:bold; background:#fee2e2; padding:2px 6px; border-radius:4px;">تجاوزت 180 يوماً!</span>'
        : `<span style="color:#1d4ed8;">متبقي ${deadlineInfo.diffDays} يوماً (${deadlineInfo.deadlineDateStr})</span>`;

      return `
        <tr>
          <td style="font-weight:bold;">${idx + 1}</td>
          <td style="font-family:monospace; font-weight:bold;">${item.itemReference}</td>
          <td><strong>${p?.patientName || 'غير مسجل'}</strong><br><small style="color:#64748b;">${p?.patientMrn || ''}</small></td>
          <td>${item.foundLocation}</td>
          <td>${item.foundDate}</td>
          <td>${deadlineBadge}</td>
          <td><strong>${item.description}</strong></td>
          <td style="font-family:monospace; color:#4338ca;">${p?.securityBagSealNumber || '-'}</td>
          <td>${item.custodyLocation}</td>
          <td>${item.status === 'returned_to_owner' ? `تم التسليم: ${item.claimedByName}` : 'في الحفظ والأمانات'}</td>
        </tr>
      `;
    }).join('');

    const bodyHtml = `
      <div class="summary-grid">
        <div class="summary-card"><div class="val">${items.length}</div><div class="lbl">إجمالي أمانات المرضى المقيدة</div></div>
        <div class="summary-card"><div class="val" style="color:#0284c7;">${activeSafekeepingCount}</div><div class="lbl">أمانات جارية بالخزنة ضمن المهلة</div></div>
        <div class="summary-card"><div class="val" style="color:#b91c1c;">${exceeded180Count}</div><div class="lbl">تجاوزت المهلة (180 يوماً)</div></div>
        <div class="summary-card"><div class="val" style="color:#047857;">${returnedCount}</div><div class="lbl">سُلِّمت للمريض أو ذويه</div></div>
      </div>
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>الرقم المرجعي</th>
            <th>اسم المريض / MRN</th>
            <th>القسم والسرير</th>
            <th>تاريخ الإيداع</th>
            <th>المهلة النظامية (180 يوماً)</th>
            <th>المحتويات والمبالغ والمجوهرات</th>
            <th>رقم كيس الأمانات</th>
            <th>الخزنة</th>
            <th>الحالة وملاحظات التسليم</th>
          </tr>
        </thead>
        <tbody>
          ${tableRows || '<tr><td colspan="10" style="text-align:center; padding:12px;">لا توجد سجلات أمانات مقيدة</td></tr>'}
        </tbody>
      </table>
      <div style="margin-top:20px; font-size:11px; color:#475569; border-top:1px solid #cbd5e1; padding-top:10px;">
        * إشعار نظامي وفق معايير CBAHI FMS وأمن المستشفيات: يتم الاحتفاظ بأمانات المرضى والنزلاء بحد أقصى 180 يوماً من تاريخ الإيداع. عند انقضاء المهلة تُحال السجلات غير المستلمة للشؤون القانونية وإدارة المستشفى لاتخاذ الإجراءات النظامية الرسمية.
      </div>
    `;

    executeSmartPrint(bodyHtml, {
      title: 'سجل أمانات ومقتنيات المرضى والنزلاء (Patient Valuables & Belongings Log)',
      subtitle: 'مستشفى آزال النموذجي • إدارة الأمن والسلامة العامة • نظام حماية الممتلكات CBAHI FMS',
      refNumber: 'AZAL-PATIENT-VALUABLES-2026'
    });
  };

  // Print Single Valuables Receipt Voucher
  const handlePrintSingleVoucher = (item: LostAndFoundItemRecord) => {
    const p = item.patientValuables;
    const deadlineInfo = calculateDeadlineInfo(p?.patientAdmissionDate || item.foundDate);

    const bodyHtml = `
      <div style="border:2px solid #334155; border-radius:12px; padding:20px; margin-top:15px; background:#f8fafc;">
        <div style="text-align:center; border-bottom:2px solid #0284c7; padding-bottom:12px; margin-bottom:15px;">
          <h2 style="margin:0; font-size:18px; color:#0f172a;">سند رسمي لحفظ وإيداع أمانات مريض</h2>
          <div style="font-size:12px; color:#475569; margin-top:4px;">Patient Valuables Deposit & Safekeeping Official Voucher</div>
          <div style="display:inline-block; margin-top:8px; font-family:monospace; font-size:14px; background:#e0e7ff; color:#3730a3; padding:3px 12px; border-radius:6px; font-weight:bold;">
            الرقم المرجعي للسند: ${item.itemReference}
          </div>
        </div>

        <table style="width:100%; font-size:12px; margin-bottom:15px;">
          <tr>
            <td style="width:20%; font-weight:bold; color:#475569;">اسم المريض الرباعي:</td>
            <td style="width:30%; font-weight:bold; color:#0f172a;">${p?.patientName || '-'}</td>
            <td style="width:20%; font-weight:bold; color:#475569;">رقم الملف الطبي (MRN):</td>
            <td style="width:30%; font-family:monospace; font-weight:bold;">${p?.patientMrn || '-'}</td>
          </tr>
          <tr>
            <td style="font-weight:bold; color:#475569;">القسم والسرير:</td>
            <td>${item.foundLocation}</td>
            <td style="font-weight:bold; color:#475569;">تاريخ ووقت الإيداع:</td>
            <td>${item.foundDate}</td>
          </tr>
          <tr>
            <td style="font-weight:bold; color:#475569;">رقم كيس الأمانات المحكم:</td>
            <td style="font-family:monospace; font-weight:bold; color:#2563eb;">${p?.securityBagSealNumber || '-'}</td>
            <td style="font-weight:bold; color:#475569;">المهلة النظامية للحفظ (180 يوماً):</td>
            <td style="color:#b91c1c; font-weight:bold;">حتى تاريخ ${deadlineInfo.deadlineDateStr}</td>
          </tr>
          <tr>
            <td style="font-weight:bold; color:#475569;">موقع الحفظ بالخزنة:</td>
            <td>${item.custodyLocation}</td>
            <td style="font-weight:bold; color:#475569;">الموظف الشاهد / التمريض:</td>
            <td>${p?.witnessStaffName || '-'}</td>
          </tr>
        </table>

        <div style="background:#fff; border:1px solid #cbd5e1; border-radius:8px; padding:12px; margin-bottom:15px;">
          <div style="font-weight:bold; color:#0f172a; margin-bottom:6px; font-size:13px;">بيانات وتفاصيل المقتنيات والأمانات المحرزة:</div>
          <div style="font-size:12px; line-height:1.6;">${item.description}</div>
          ${p?.goldOrJewelryDetails ? `<div style="font-size:11px; color:#b45309; margin-top:4px;">• تفاصيل الذهب والمجوهرات: ${p.goldOrJewelryDetails}</div>` : ''}
          ${p?.electronicsDetails ? `<div style="font-size:11px; color:#1d4ed8; margin-top:4px;">• تفاصيل الإلكترونيات والهواتف: ${p.electronicsDetails}</div>` : ''}
          <div style="font-size:11px; color:#64748b; margin-top:6px;">ملاحظات الضبط: ${item.notes || '-'}</div>
        </div>

        ${item.status === 'returned_to_owner' ? `
          <div style="background:#ecfdf5; border:1px solid #6ee7b7; border-radius:8px; padding:12px; margin-bottom:15px;">
            <div style="font-weight:bold; color:#065f46; font-size:13px; margin-bottom:4px;">إفادة استلام الأمانة رسمياً:</div>
            <div style="font-size:12px; color:#047857;">
              تم تسليم الأمانات المذكورة بحالتها الكاملة للمستلم: <strong>${item.claimedByName}</strong> بموجب الهوية رقم <strong>${item.claimedByIdNumber}</strong> في تاريخ <strong>${item.handedOverDate}</strong> بواسطة ضابط أمن المستشفى: <strong>${item.securityOfficerHandover}</strong>.
            </div>
          </div>
        ` : ''}

        <div style="display:flex; justify-content:space-between; margin-top:30px; padding-top:15px; border-top:1px solid #cbd5e1; font-size:12px; text-align:center;">
          <div style="flex:1;">
            <div>توقيع المُودع / التمريض الشاهد</div>
            <div style="margin-top:30px; font-weight:bold;">${p?.witnessStaffName || '................................'}</div>
          </div>
          <div style="flex:1;">
            <div>توقيع ضابط أمن المستشفى المستلم</div>
            <div style="margin-top:30px; font-weight:bold;">${currentUser.name}</div>
          </div>
          <div style="flex:1;">
            <div>توقيع المريض أو المستلم الشرعي</div>
            <div style="margin-top:30px; font-weight:bold;">${item.claimedByName || '................................'}</div>
          </div>
        </div>
      </div>
    `;

    executeSmartPrint(bodyHtml, {
      title: `سند إيداع أمانات مريض - ${item.itemReference}`,
      subtitle: 'مستشفى آزال النموذجي • إدارة الأمن والسلامة العامة • مكتب الأمانات',
      refNumber: item.itemReference
    });
  };

  // Filter Logic
  const filteredItems = items.filter((item) => {
    const p = item.patientValuables;
    const deadlineInfo = calculateDeadlineInfo(p?.patientAdmissionDate || item.foundDate);

    if (statusFilter === 'safekeeping' && item.status !== 'safekeeping') return false;
    if (statusFilter === 'returned_to_owner' && item.status !== 'returned_to_owner') return false;
    if (statusFilter === 'overdue_180' && (!deadlineInfo.isExceeded || item.status === 'returned_to_owner')) return false;

    if (!searchTerm.trim()) return true;
    const term = searchTerm.toLowerCase();
    return (
      item.itemReference.toLowerCase().includes(term) ||
      (p?.patientName && p.patientName.toLowerCase().includes(term)) ||
      (p?.patientMrn && p.patientMrn.toLowerCase().includes(term)) ||
      item.foundLocation.toLowerCase().includes(term) ||
      item.description.toLowerCase().includes(term) ||
      (p?.securityBagSealNumber && p.securityBagSealNumber.toLowerCase().includes(term))
    );
  });

  const activeSafekeepingCount = items.filter(i => i.status === 'safekeeping').length;
  const returnedCount = items.filter(i => i.status === 'returned_to_owner').length;
  const exceeded180Count = items.filter(i => {
    if (i.status === 'returned_to_owner') return false;
    const d = calculateDeadlineInfo(i.patientValuables?.patientAdmissionDate || i.foundDate);
    return d.isExceeded;
  }).length;

  return (
    <div id="patient-valuables-tracker" className="space-y-4 text-right">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-teal-950/70 border border-slate-800 rounded-3xl p-5 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-teal-950 border border-teal-800 text-teal-400">
            <Shield className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-slate-100">
                سجل أمانات ومقتنيات المرضى والنزلاء (Patient Valuables & 180-Day Tracker)
              </h2>
              <span className="text-[10px] bg-teal-950 text-teal-300 border border-teal-800 font-bold px-2 py-0.5 rounded-lg">
                معيار CBAHI FMS-SEC
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              توثيق إيداع المقتنيات الثمينة والمبالغ النقدية للمرضى، وإدارة أكياس الأمانات المشمعة واحتساب المهلة النظامية لحفظ الأمانات (180 يوماً).
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs shadow-md flex items-center gap-2 transition"
          >
            <Plus className="w-4 h-4" />
            <span>إيداع أمانات مريض جديدة</span>
          </button>

          <button
            type="button"
            onClick={handlePrintRegister}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold flex items-center gap-1.5 transition"
          >
            <Printer className="w-4 h-4" />
            <span>طباعة السجل (PDF)</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
          <div className="text-xs text-slate-400">إجمالي الأمانات المقيدة</div>
          <div className="text-2xl font-black text-slate-100 mt-1">{items.length}</div>
          <div className="text-[10px] text-teal-400 mt-1">سجلات أمانات رسمية</div>
        </div>

        <div className="bg-slate-900 border border-teal-900/60 rounded-2xl p-4">
          <div className="text-xs text-slate-400">في الحفظ والأمانات (نشطة)</div>
          <div className="text-2xl font-black text-teal-400 mt-1">{activeSafekeepingCount}</div>
          <div className="text-[10px] text-teal-300 mt-1">محفوظة بالخزنة المعتمدة</div>
        </div>

        <div className={`bg-slate-900 border rounded-2xl p-4 ${exceeded180Count > 0 ? 'border-rose-600/80 bg-rose-950/20' : 'border-slate-800'}`}>
          <div className="text-xs text-slate-400">تجاوزت المهلة (180 يوماً)</div>
          <div className="text-2xl font-black text-rose-400 mt-1">{exceeded180Count}</div>
          <div className="text-[10px] text-rose-300 mt-1">تتطلب إحالة للشؤون القانونية</div>
        </div>

        <div className="bg-slate-900 border border-emerald-900/60 rounded-2xl p-4">
          <div className="text-xs text-slate-400">سُلِّمت للمريض أو ذويه</div>
          <div className="text-2xl font-black text-emerald-400 mt-1">{returnedCount}</div>
          <div className="text-[10px] text-emerald-300 mt-1">بمحضر استلام وتوقيع</div>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="bg-slate-900/80 border border-slate-800 p-3 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex-1 min-w-[220px] relative">
          <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="بحث باسم المريض، رقم الملف MRN، رقم الكيس، أو المحتويات..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-9 pl-3 py-2 text-slate-200"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200"
          >
            <option value="all">كافة الحالات</option>
            <option value="safekeeping">في الحفظ والأمانات</option>
            <option value="overdue_180">🚨 تجاوزت 180 يوماً</option>
            <option value="returned_to_owner">سُلّمت للمريض / ذويه</option>
          </select>
        </div>
      </div>

      {/* Valuables Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-950 border-b border-slate-800 text-slate-400 font-bold">
              <tr>
                <th className="p-3.5">المرجع / كيس الأمانات</th>
                <th className="p-3.5">بيانات المريض والملف الطبي</th>
                <th className="p-3.5">القسم والسرير</th>
                <th className="p-3.5">تاريخ الإيداع والمهلة (180 يوماً)</th>
                <th className="p-3.5">المحتويات والمبالغ والمجوهرات</th>
                <th className="p-3.5 text-center">الحالة</th>
                <th className="p-3.5 text-center">إجراءات وسندات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredItems.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-slate-400">
                    لا توجد سجلات أمانات مرضى مطابقة لمعايير البحث
                  </td>
                </tr>
              ) : (
                filteredItems.map((item) => {
                  const p = item.patientValuables;
                  const deadlineInfo = calculateDeadlineInfo(p?.patientAdmissionDate || item.foundDate);

                  return (
                    <tr key={item.id} className={`hover:bg-slate-800/30 transition ${deadlineInfo.isExceeded && item.status === 'safekeeping' ? 'bg-rose-950/15' : ''}`}>
                      <td className="p-3.5">
                        <span className="font-mono font-bold text-teal-300 bg-teal-950 px-2 py-0.5 rounded-lg border border-teal-800">
                          {item.itemReference}
                        </span>
                        {p?.securityBagSealNumber && (
                          <div className="text-[11px] font-mono text-indigo-400 mt-1 flex items-center gap-1">
                            <Lock className="w-3 h-3 text-indigo-400" />
                            <span>{p.securityBagSealNumber}</span>
                          </div>
                        )}
                      </td>

                      <td className="p-3.5">
                        <div className="font-bold text-slate-100 flex items-center gap-1.5">
                          <User className="w-3.5 h-3.5 text-teal-400" />
                          <span>{p?.patientName || 'غير مسجل'}</span>
                        </div>
                        <div className="text-[11px] font-mono text-slate-400 mt-0.5">
                          {p?.patientMrn || '-'}
                        </div>
                      </td>

                      <td className="p-3.5">
                        <div className="text-slate-200">{item.foundLocation}</div>
                        <div className="text-[10px] text-slate-400">{item.custodyLocation}</div>
                      </td>

                      <td className="p-3.5">
                        <div className="text-slate-300 font-mono text-[11px]">
                          إيداع: {item.foundDate}
                        </div>
                        {item.status === 'returned_to_owner' ? (
                          <div className="text-[11px] text-emerald-400 mt-1 font-semibold flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>سُلّمت في: {item.handedOverDate}</span>
                          </div>
                        ) : deadlineInfo.isExceeded ? (
                          <div className="text-[11px] text-rose-400 mt-1 font-bold flex items-center gap-1 bg-rose-950/80 px-2 py-0.5 rounded border border-rose-800 animate-pulse">
                            <AlertTriangle className="w-3 h-3 text-rose-400" />
                            <span>تجاوزت المهلة (180 يوماً)!</span>
                          </div>
                        ) : deadlineInfo.isNearExpiry ? (
                          <div className="text-[11px] text-amber-400 mt-1 font-semibold flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            <span>متبقي {deadlineInfo.diffDays} يوماً على المهلة</span>
                          </div>
                        ) : (
                          <div className="text-[11px] text-teal-400 mt-1 flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            <span>متبقي {deadlineInfo.diffDays} يوماً</span>
                          </div>
                        )}
                      </td>

                      <td className="p-3.5 max-w-xs">
                        <div className="font-bold text-slate-100 line-clamp-2">{item.description}</div>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {p?.cashAmountYemen && (
                            <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-1.5 py-0.5 rounded font-mono">
                              {p.cashAmountYemen.toLocaleString()} ر.ي
                            </span>
                          )}
                          {p?.cashAmountSaudi && (
                            <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-1.5 py-0.5 rounded font-mono">
                              {p.cashAmountSaudi.toLocaleString()} ر.س
                            </span>
                          )}
                          {p?.cashAmountDollar && (
                            <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-1.5 py-0.5 rounded font-mono">
                              ${p.cashAmountDollar.toLocaleString()}
                            </span>
                          )}
                          {p?.goldOrJewelryDetails && (
                            <span className="text-[10px] bg-amber-950 text-amber-300 border border-amber-800 px-1.5 py-0.5 rounded">
                              ✨ مصوغات
                            </span>
                          )}
                        </div>
                      </td>

                      <td className="p-3.5 text-center">
                        {item.status === 'returned_to_owner' ? (
                          <span className="inline-flex items-center gap-1 bg-emerald-950 text-emerald-300 border border-emerald-800 px-2.5 py-1 rounded-full text-[11px] font-bold">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>تم التسليم</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 bg-amber-950 text-amber-300 border border-amber-800 px-2.5 py-1 rounded-full text-[11px] font-bold">
                            <Lock className="w-3.5 h-3.5" />
                            <span>في الحفظ</span>
                          </span>
                        )}
                      </td>

                      <td className="p-3.5 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          {item.status === 'safekeeping' && (
                            <button
                              type="button"
                              onClick={() => setSelectedHandoverItem(item)}
                              className="px-2.5 py-1 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-bold text-[11px] flex items-center gap-1 transition shadow-sm"
                            >
                              <UserCheck className="w-3 h-3" />
                              <span>تسليم</span>
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => handlePrintSingleVoucher(item)}
                            title="طباعة سند الأمانات"
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDelete(item.id)}
                            title="حذف"
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-300 transition"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Handover Modal */}
      {selectedHandoverItem && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-teal-600/60 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl">
            <div className="bg-slate-950 px-5 py-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-teal-950 text-teal-400 border border-teal-800">
                  <UserCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-100">
                    محضر تسليم أمانات مريض رسمي
                  </h3>
                  <p className="text-[11px] text-slate-400">مرجع السند: {selectedHandoverItem.itemReference}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedHandoverItem(null)}
                className="p-1 rounded-lg bg-slate-800 text-slate-400 hover:text-slate-100"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleHandoverSubmit} className="p-5 space-y-3.5 text-xs">
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-1">
                <div className="text-slate-400">المريض صاحب الأمانات:</div>
                <div className="font-bold text-slate-100 text-sm">{selectedHandoverItem.patientValuables?.patientName}</div>
                <div className="text-slate-400 text-[11px]">كيس الأمانات: {selectedHandoverItem.patientValuables?.securityBagSealNumber}</div>
                <div className="text-teal-300 text-[11px] mt-1">{selectedHandoverItem.description}</div>
              </div>

              <div>
                <label className="text-slate-300 block mb-1 font-semibold">صفة المستلم:</label>
                <select
                  value={recipientRelation}
                  onChange={(e) => setRecipientRelation(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                >
                  <option value="patient_self">المريض شخصياً بعد الشفاء / الخروج</option>
                  <option value="first_degree_relative">قريب درجة أولى (أب / أم / زوج / ابن) بموجب تفويض رسمي</option>
                  <option value="legal_power_of_attorney">وكيل شرعي بموجب وكالة قانونية معتمدة</option>
                </select>
              </div>

              <div>
                <label className="text-slate-300 block mb-1 font-semibold">اسم المستلم الرباعي:</label>
                <input
                  type="text"
                  required
                  placeholder="الاسم مطابقاً للبطاقة الشخصية..."
                  value={recipientName}
                  onChange={(e) => setRecipientName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">رقم الهوية الوطنية / الإثبات:</label>
                  <input
                    type="text"
                    required
                    placeholder="رقم البطاقة الشخصية..."
                    value={recipientId}
                    onChange={(e) => setRecipientId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100 font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">رقم هاتف المستلم:</label>
                  <input
                    type="tel"
                    placeholder="77XXXXXXX"
                    value={recipientPhone}
                    onChange={(e) => setRecipientPhone(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100 font-mono"
                  />
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-teal-950/40 border border-teal-900/60 text-[11px] text-slate-300">
                يقر المستلم باستلامه كافة الأمانات المحرزة والمذكورة أعلاه سليمة وخالية من أي نقص، وبموجب هذا الإقرار يُخلى طرف إدارة أمن مستشفى آزال بالكامل.
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setSelectedHandoverItem(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 text-xs"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>تأكيد التسليم وتوقيع السند</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* New Patient Valuables Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-teal-600/60 rounded-3xl w-full max-w-xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
            <div className="bg-slate-950 px-5 py-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-teal-950 text-teal-400 border border-teal-800">
                  <Shield className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-100">
                    إيداع أمانات ومقتنيات مريض جديدة
                  </h3>
                  <p className="text-[11px] text-slate-400">مستشفى آزال النموذجي • إدارة الأمن وحماية ممتلكات النزلاء</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="p-1 rounded-lg bg-slate-800 text-slate-400 hover:text-slate-100"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateValuables} className="p-5 space-y-3.5 overflow-y-auto text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">اسم المريض الرباعي *:</label>
                  <input
                    type="text"
                    required
                    placeholder="اسم المريض المنوم أو المصاب..."
                    value={patientName}
                    onChange={(e) => setPatientName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                  />
                </div>
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">رقم الملف الطبي (MRN):</label>
                  <input
                    type="text"
                    placeholder="MRN-XXXXX"
                    value={patientMrn}
                    onChange={(e) => setPatientMrn(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">القسم / الجناح:</label>
                  <select
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                  >
                    <option value="العناية المركزة ICU">العناية المركزة ICU</option>
                    <option value="طوارئ الجراحة والحوادث">طوارئ الجراحة والحوادث</option>
                    <option value="العمليات الكبرى">العمليات الكبرى</option>
                    <option value="جناح التنويم الباطني">جناح التنويم الباطني</option>
                    <option value="جناح التنويم الجراحي">جناح التنويم الجراحي</option>
                    <option value="وحدة العناية القلبية CCU">وحدة العناية القلبية CCU</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">الغرفة / السرير:</label>
                  <input
                    type="text"
                    placeholder="سرير 4 / غرفة 302..."
                    value={bedRoom}
                    onChange={(e) => setBedRoom(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                  />
                </div>
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">تاريخ الإيداع:</label>
                  <input
                    type="date"
                    value={depositDate}
                    onChange={(e) => setDepositDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                  />
                </div>
              </div>

              {/* Notice Banner about 180-day holding deadline */}
              <div className="p-2.5 rounded-xl bg-teal-950/60 border border-teal-800 text-[11px] text-teal-300 flex items-center gap-2">
                <Clock className="w-4 h-4 text-teal-400 shrink-0" />
                <span>
                  المهلة النظامية المعتمدة لحفظ أمانات المرضى هي <strong>180 يوماً</strong> من تاريخ الإيداع (حتى {calculateDeadlineInfo(depositDate).deadlineDateStr}) بحسب لوائح حماية الممتلكات.
                </span>
              </div>

              {/* Cash Currency Section */}
              <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                <label className="text-emerald-400 font-bold flex items-center gap-1 text-xs">
                  <DollarSign className="w-3.5 h-3.5" />
                  <span>المبالغ النقدية المودعة (إن وجدت):</span>
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <div>
                    <label className="text-slate-400 text-[11px] block mb-0.5">ريال يمني (YER):</label>
                    <input
                      type="number"
                      placeholder="0"
                      value={cashYemen}
                      onChange={(e) => setCashYemen(e.target.value ? Number(e.target.value) : '')}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-slate-100 font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 text-[11px] block mb-0.5">ريال سعودي (SAR):</label>
                    <input
                      type="number"
                      placeholder="0"
                      value={cashSaudi}
                      onChange={(e) => setCashSaudi(e.target.value ? Number(e.target.value) : '')}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-slate-100 font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 text-[11px] block mb-0.5">دولار أمريكي (USD):</label>
                    <input
                      type="number"
                      placeholder="0"
                      value={cashDollar}
                      onChange={(e) => setCashDollar(e.target.value ? Number(e.target.value) : '')}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-slate-100 font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Gold & Electronics */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold flex items-center gap-1">
                    <Watch className="w-3.5 h-3.5 text-amber-400" />
                    <span>مجوهرات وذهب ومصوغات ثمينة:</span>
                  </label>
                  <textarea
                    rows={2}
                    placeholder="خاتم عيار 21، سلسلة، أساور، ساعة يد ثمينة..."
                    value={goldJewelry}
                    onChange={(e) => setGoldJewelry(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                  />
                </div>
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">هواتف وأجهزة إلكترونية:</label>
                  <textarea
                    rows={2}
                    placeholder="نوع الهاتف، اللون، كلمة مرور مقفل/مفتوح..."
                    value={electronics}
                    onChange={(e) => setElectronics(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                  />
                </div>
              </div>

              {/* Custody, Bag Seal, and Witness */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">رقم ختم كيس الأمانات *:</label>
                  <input
                    type="text"
                    required
                    value={securityBagSeal}
                    onChange={(e) => setSecurityBagSeal(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100 font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">موقع الخزنة:</label>
                  <input
                    type="text"
                    value={custodyLocker}
                    onChange={(e) => setCustodyLocker(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                  />
                </div>
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">الممرض / الشاهد الحاضر:</label>
                  <input
                    type="text"
                    placeholder="اسم التمريض الشاهد..."
                    value={witnessStaff}
                    onChange={(e) => setWitnessStaff(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 block mb-1 font-semibold">ملاحظات وحالة الأمانات عند الاستلام:</label>
                <input
                  type="text"
                  placeholder="حالة الأمانة، استلمت من مسعف / مرافق / مع المريض..."
                  value={generalNotes}
                  onChange={(e) => setGeneralNotes(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 text-xs"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>حفظ وإيداع أمانات المريض</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
