import React, { useState } from 'react';

interface AssetRecord {
  assetCode: string;
  assetName: string;
  department: string;
  serialNumber?: string;
}

export const AssetInventoryUpload: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [assets, setAssets] = useState<AssetRecord[]>([]);

  const handleProcessData = () => {
    if (!inputText.trim()) return;

    const rows = inputText.trim().split('\n');
    const parsedAssets: AssetRecord[] = [];

    rows.forEach(row => {
      const cols = row.split(/\t|,/);
      if (cols.length >= 2) {
        parsedAssets.push({
          assetCode: cols[0]?.trim() || '',
          assetName: cols[1]?.trim() || '',
          department: cols[2]?.trim() || 'عام',
          serialNumber: cols[3]?.trim() || '',
        });
      }
    });

    setAssets(parsedAssets);
  };

  return (
    <div className="p-6 bg-slate-50 min-h-screen text-right" dir="rtl">
      <div className="no-print bg-white p-6 rounded-xl shadow-sm border border-slate-200 mb-8 max-w-4xl mx-auto">
        <h2 className="text-xl font-bold text-slate-800 mb-2">لوحة جرد الأصول وطباعة الـ QR (قسم المالية)</h2>
        <p className="text-sm text-slate-500 mb-4">انسخ الأعمدة من ملف الإكسل (الكود، اسم الأصل، القسم، الرقم التسلسلي) والصقها هنا مباشرة:</p>

        <textarea
          rows={6}
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="مثال للصق من الإكسل:&#10;AST-101	مضخة محاليل	العناية المركزة	SN-8899&#10;AST-102	جهاز صدمات	الطوارئ	SN-4432"
          className="w-full p-3 border border-slate-300 rounded-lg text-sm font-mono focus:ring-2 focus:ring-blue-500 outline-none text-left dir-ltr"
        />

        <div className="flex gap-3 mt-4">
          <button
            onClick={handleProcessData}
            className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg font-bold text-sm"
          >
            توليد ملصقات الـ QR
          </button>

          {assets.length > 0 && (
            <button
              onClick={() => window.print()}
              className="bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2 rounded-lg font-bold text-sm"
            >
              طباعة كافة الملصقات ({assets.length})
            </button>
          )}
        </div>
      </div>

      {assets.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 max-w-6xl mx-auto">
          {assets.map((asset, index) => (
            <div
              key={index}
              className="bg-white p-3 rounded-lg border border-slate-300 shadow-sm flex flex-col justify-between"
            >
              <div className="border-b border-slate-200 pb-1 mb-2 text-center">
                <span className="text-xs font-bold text-slate-800 block">مستشفى آزال النموذجي</span>
                <span className="text-[10px] text-slate-500">إدارة السلامة والمرافق (FMS)</span>
              </div>

              <div className="flex items-center justify-between gap-2">
                <div className="flex-1 text-right">
                  <h4 className="font-bold text-xs text-slate-900 truncate">{asset.assetName}</h4>
                  <p className="text-[11px] text-blue-700 font-mono font-bold mt-1">{asset.assetCode}</p>
                  <p className="text-[10px] text-slate-600 mt-0.5">القسم: {asset.department}</p>
                  {asset.serialNumber && (
                    <p className="text-[9px] text-slate-400 font-mono">S/N: {asset.serialNumber}</p>
                  )}
                </div>

                <div className="bg-white p-1 rounded border border-slate-200">
                  <img
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=80x80&data=${encodeURIComponent(asset.assetCode)}`}
                    alt={asset.assetCode}
                    className="w-16 h-16"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
