import React, { useState, useRef } from 'react';
import { 
  X, 
  UploadCloud, 
  FileSpreadsheet, 
  FileText, 
  CheckCircle2, 
  AlertCircle, 
  Trash2, 
  Download,
  Sparkles,
  ArrowLeft
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { PpmAsset } from '../data/azalPpmAssetsData';
import { parseExcelOrCsvFile, parsePdfOrTextFile } from '../utils/assetFileParser';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';

interface AssetImportModalProps {
  onClose: () => void;
  onImportSuccess: (importedAssets: PpmAsset[]) => void;
}

export const AssetImportModal: React.FC<AssetImportModalProps> = ({
  onClose,
  onImportSuccess
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  
  const [isDragging, setIsDragging] = useState(false);
  const [isParsing, setIsParsing] = useState(false);
  const [parsedAssets, setParsedAssets] = useState<PpmAsset[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);

  const handleFileSelect = async (file: File) => {
    setIsParsing(true);
    setErrors([]);
    setUploadedFileName(file.name);

    try {
      const fileNameLower = file.name.toLowerCase();
      let result;

      if (fileNameLower.endsWith('.pdf') || fileNameLower.endsWith('.txt')) {
        result = await parsePdfOrTextFile(file);
      } else {
        result = await parseExcelOrCsvFile(file);
      }

      if (result.success && result.importedAssets.length > 0) {
        setParsedAssets(result.importedAssets);
        triggerSuccessFeedback();
      } else {
        setErrors(result.errors.length > 0 ? result.errors : ['لم يتم العثور على أصول صالحة في الملف المحدد']);
      }
    } catch (err: any) {
      setErrors([`حدث خطأ أثناء معالجة الملف: ${err?.message || ''}`]);
    } finally {
      setIsParsing(false);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileSelect(e.dataTransfer.files[0]);
    }
  };

  const handleRemoveItem = (index: number) => {
    setParsedAssets((prev) => prev.filter((_, i) => i !== index));
  };

  const handleConfirmSave = () => {
    if (parsedAssets.length === 0) return;
    triggerSuccessFeedback();
    onImportSuccess(parsedAssets);
    onClose();
  };

  const handleDownloadSampleExcel = () => {
    const sampleData = [
      {
        'كود الأصل': 'AZ-BIO-20',
        'اسم المعدة / النظام': 'جهاز تخطيط الدماغ EEG الرقمي',
        'القسم المسؤول': 'الصيانة الطبية',
        'دورية الفحص': 'كل 6 أشهر',
        'الموقع': 'وحدة تخطيط المخ والأعصاب',
        'الموديل': 'Nihon Kohden EEG-1200',
        'الرقم التسلسلي': 'NK-EEG-991',
        'الملاحظات': 'معايرة الحساسات وفحص عازلية التيارات'
      },
      {
        'كود الأصل': 'AZ-GEN-03',
        'اسم المعدة / النظام': 'مولد الطوارئ الإضافي للمبنى الجديد',
        'القسم المسؤول': 'قسم الصيانة العامة وخدمات المنافع',
        'دورية الفحص': 'أسبوعي',
        'الموقع': 'المبنى الجديد - السطح',
        'الموديل': 'Perkins 500kVA',
        'الرقم التسلسلي': 'PRK-2025-102',
        'الملاحظات': 'فحص مستوى الديزل ولوحة ATS'
      },
      {
        'كود الأصل': 'AZ-IT-05',
        'اسم المعدة / النظام': 'وحدة التخزين الشبكي للنسخ الاحتياطي SAN Storage',
        'القسم المسؤول': 'صيانة الـ IT والشبكات',
        'دورية الفحص': 'شهري',
        'الموقع': 'مركز البيانات الرئيسي (Data Center)',
        'الموديل': 'Synology Enterprise Rack',
        'الرقم التسلسلي': 'SYN-SAN-404',
        'الملاحظات': 'مراجعة سلامة أقراص الـ RAID'
      },
      {
        'كود الأصل': 'AZ-CCTV-05',
        'اسم المعدة / النظام': 'كاميرات التعرف على الوجوه وبوابات الدخول',
        'القسم المسؤول': 'كاميرات المراقبة والأنظمة الأمنية',
        'دورية الفحص': 'شهري',
        'الموقع': 'المدخل الرئيسي والمصاعد',
        'الموديل': 'Hikvision Face Terminal',
        'الرقم التسلسلي': 'HIK-FC-882',
        'الملاحظات': 'فحص سرعة استجابة التعرف على الوجوه'
      }
    ];

    const ws = XLSX.utils.json_to_sheet(sampleData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'الأصول والمعدات');
    XLSX.writeFile(wb, 'نموذج_حصر_أصول_مستشفى_آزال.xlsx');
  };

  return (
    <div 
      id="asset-import-modal"
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 text-right overflow-y-auto"
    >
      <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-4xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95">
        
        {/* Header */}
        <div className="bg-slate-950 p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <UploadCloud className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-white font-extrabold text-base sm:text-lg">
                استيراد حصر الأجهزة والأنظمة من ملف (Excel / CSV / PDF)
              </h3>
              <p className="text-xs text-slate-400">
                قراءة آلية للأعمدة وتوليد جدول الأصول المزمنة وربطها بالخطة الوقائية
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 p-2 rounded-xl transition-colors"
            title="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
          
          {/* File Upload Zone */}
          {parsedAssets.length === 0 ? (
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-3xl p-8 text-center cursor-pointer transition-all flex flex-col items-center justify-center ${
                isDragging
                  ? 'border-emerald-500 bg-emerald-950/30 shadow-lg scale-99'
                  : 'border-slate-700 bg-slate-950/40 hover:border-emerald-500/50 hover:bg-slate-950/70'
              }`}
            >
              <input
                type="file"
                ref={fileInputRef}
                onChange={(e) => {
                  if (e.target.files && e.target.files.length > 0) {
                    handleFileSelect(e.target.files[0]);
                  }
                }}
                accept=".xlsx,.xls,.csv,.tsv,.pdf,.txt"
                className="hidden"
              />

              <div className="w-16 h-16 rounded-3xl bg-slate-800 border border-slate-700 flex items-center justify-center text-emerald-400 mb-4 shadow-inner">
                {isParsing ? (
                  <Sparkles className="w-8 h-8 animate-spin text-emerald-400" />
                ) : (
                  <FileSpreadsheet className="w-8 h-8" />
                )}
              </div>

              <h4 className="text-white font-extrabold text-base mb-1">
                {isParsing ? 'جاري قراءة واستخراج بيانات الأصول...' : 'اسحب وأفلت ملف الأجهزة هنا أو انقر للاختيار'}
              </h4>
              
              <p className="text-slate-400 text-xs max-w-md leading-relaxed mb-4">
                يدعم ملفات إكسل (Excel .xlsx / .xls)، ملفات CSV، ومستندات الحصر والجداول بصيغة PDF. يقوم النظام آلياً بالتعرف على كود الأصل، اسم المعدة، القسم، والدورية.
              </p>

              <div className="flex flex-wrap items-center justify-center gap-2">
                <span className="bg-slate-800 text-slate-300 text-[11px] font-mono px-2.5 py-1 rounded-lg border border-slate-700">
                  .XLSX
                </span>
                <span className="bg-slate-800 text-slate-300 text-[11px] font-mono px-2.5 py-1 rounded-lg border border-slate-700">
                  .CSV
                </span>
                <span className="bg-slate-800 text-slate-300 text-[11px] font-mono px-2.5 py-1 rounded-lg border border-slate-700">
                  .PDF
                </span>
              </div>
            </div>
          ) : null}

          {/* Download Sample Template Option */}
          <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 text-slate-300">
              <FileSpreadsheet className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>هل تريد نموذج إكسل جاهز للتعبئة؟</span>
            </div>
            <button
              onClick={handleDownloadSampleExcel}
              className="bg-slate-800 hover:bg-slate-700 text-emerald-400 hover:text-emerald-300 px-3 py-1.5 rounded-xl font-bold border border-slate-700 flex items-center gap-1.5 transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>تحميل قالب إكسل فارغ (Sample Template)</span>
            </button>
          </div>

          {/* Errors Display */}
          {errors.length > 0 && (
            <div className="bg-rose-950/40 border border-rose-500/50 rounded-2xl p-4 text-rose-300 text-xs space-y-1">
              <div className="flex items-center gap-2 font-bold text-rose-200 mb-1">
                <AlertCircle className="w-4 h-4" />
                <span>تعذر استخراج بعض البيانات:</span>
              </div>
              {errors.map((err, i) => (
                <p key={i}>• {err}</p>
              ))}
            </div>
          )}

          {/* Parsed Assets Preview Table */}
          {parsedAssets.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  <span className="text-white font-extrabold text-sm">
                    تم استخراج ({parsedAssets.length}) أصل ومعدة بنجاح من ملف:
                  </span>
                  <span className="text-emerald-400 font-mono text-xs font-bold">
                    {uploadedFileName}
                  </span>
                </div>

                <button
                  onClick={() => setParsedAssets([])}
                  className="text-slate-400 hover:text-rose-400 text-xs flex items-center gap-1 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>إلغاء واختيار ملف آخر</span>
                </button>
              </div>

              <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-950">
                <div className="overflow-x-auto max-h-[360px]">
                  <table className="w-full text-right text-xs">
                    <thead className="bg-slate-900/90 text-slate-300 font-bold sticky top-0 border-b border-slate-800">
                      <tr>
                        <th className="p-3">#</th>
                        <th className="p-3">كود الأصل</th>
                        <th className="p-3">اسم المعدة / النظام</th>
                        <th className="p-3">القسم المعني</th>
                        <th className="p-3">دورية الفحص</th>
                        <th className="p-3">الموقع</th>
                        <th className="p-3 text-center">إجراء</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {parsedAssets.map((asset, idx) => (
                        <tr key={asset.id} className="hover:bg-slate-900/50 transition-colors">
                          <td className="p-3 text-slate-500 font-mono">{idx + 1}</td>
                          <td className="p-3 font-mono font-bold text-emerald-400">
                            {asset.asset_tag}
                          </td>
                          <td className="p-3 font-semibold text-white">
                            {asset.name}
                          </td>
                          <td className="p-3">
                            <span className="bg-slate-800 text-slate-300 px-2 py-0.5 rounded text-[11px] font-medium border border-slate-700">
                              {asset.categoryNameAr}
                            </span>
                          </td>
                          <td className="p-3">
                            <span className="bg-emerald-950/40 text-emerald-400 px-2 py-0.5 rounded text-[11px] font-bold border border-emerald-500/30">
                              {asset.frequency}
                            </span>
                          </td>
                          <td className="p-3 text-slate-400 truncate max-w-[160px]">
                            {asset.location}
                          </td>
                          <td className="p-3 text-center">
                            <button
                              onClick={() => handleRemoveItem(idx)}
                              className="text-slate-500 hover:text-rose-400 p-1 rounded transition-colors"
                              title="حذف هذا السطر"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-950 p-4 border-t border-slate-800 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl transition-colors"
          >
            إلغاء
          </button>

          {parsedAssets.length > 0 && (
            <button
              onClick={handleConfirmSave}
              className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs sm:text-sm font-bold px-5 py-2.5 rounded-xl shadow-lg shadow-emerald-900/30 flex items-center gap-2 transition-transform active:scale-95"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>اعتماد وحفظ الأصول في المنظومة ({parsedAssets.length})</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
