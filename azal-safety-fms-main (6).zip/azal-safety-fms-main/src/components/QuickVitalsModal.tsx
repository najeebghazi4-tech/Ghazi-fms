import React, { useState } from 'react';
import { X, Heart, Activity, Wind, Thermometer, Check } from 'lucide-react';
import { ISBARData, VitalSigns } from '../types';

interface QuickVitalsModalProps {
  patient: ISBARData;
  onClose: () => void;
  onSaveVitals: (patientId: string, updatedVitals: VitalSigns) => void;
}

export const QuickVitalsModal: React.FC<QuickVitalsModalProps> = ({
  patient,
  onClose,
  onSaveVitals,
}) => {
  const [vitals, setVitals] = useState<VitalSigns>({ ...patient.vitals });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveVitals(patient.patientId, {
      ...vitals,
      recordedAt: 'الآن (محدث بالسرير)',
    });
    onClose();
  };

  return (
    <div id="quick-vitals-modal" className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 text-right">
      <div className="bg-slate-900 border border-teal-600/60 rounded-2xl w-full max-w-sm overflow-hidden shadow-2xl">
        <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-teal-950 border border-teal-800 text-teal-400">
              <Activity className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-slate-100">تحديث العلامات الحيوية بجانب السرير</h3>
              <p className="text-[10px] text-slate-400">{patient.fullName} ({patient.bedNumber})</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg bg-slate-800 text-slate-400 hover:text-slate-100"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-3 text-xs">
          <div className="grid grid-cols-2 gap-2.5">
            <div className="bg-slate-950 p-2 rounded-xl border border-slate-800">
              <label className="text-slate-400 block mb-1 text-[11px]">الضغط الانقباضي SYS:</label>
              <input
                type="number"
                value={vitals.bpSystolic}
                onChange={(e) => setVitals({ ...vitals, bpSystolic: Number(e.target.value) })}
                className="w-full bg-slate-900 border border-slate-700 rounded p-1.5 text-center font-mono font-bold text-slate-100"
              />
            </div>

            <div className="bg-slate-950 p-2 rounded-xl border border-slate-800">
              <label className="text-slate-400 block mb-1 text-[11px]">الضغط الانبساطي DIA:</label>
              <input
                type="number"
                value={vitals.bpDiastolic}
                onChange={(e) => setVitals({ ...vitals, bpDiastolic: Number(e.target.value) })}
                className="w-full bg-slate-900 border border-slate-700 rounded p-1.5 text-center font-mono font-bold text-slate-100"
              />
            </div>

            <div className="bg-slate-950 p-2 rounded-xl border border-slate-800">
              <label className="text-slate-400 block mb-1 text-[11px]">معدل النبض HR (bpm):</label>
              <input
                type="number"
                value={vitals.heartRate}
                onChange={(e) => setVitals({ ...vitals, heartRate: Number(e.target.value) })}
                className="w-full bg-slate-900 border border-slate-700 rounded p-1.5 text-center font-mono font-bold text-slate-100"
              />
            </div>

            <div className="bg-slate-950 p-2 rounded-xl border border-slate-800">
              <label className="text-slate-400 block mb-1 text-[11px]">الأكسجين SpO2 (%):</label>
              <input
                type="number"
                value={vitals.oxygenSat}
                onChange={(e) => setVitals({ ...vitals, oxygenSat: Number(e.target.value) })}
                className="w-full bg-slate-900 border border-slate-700 rounded p-1.5 text-center font-mono font-bold text-slate-100"
              />
            </div>

            <div className="bg-slate-950 p-2 rounded-xl border border-slate-800">
              <label className="text-slate-400 block mb-1 text-[11px]">درجة الحرارة (°C):</label>
              <input
                type="number"
                step="0.1"
                value={vitals.temperature}
                onChange={(e) => setVitals({ ...vitals, temperature: Number(e.target.value) })}
                className="w-full bg-slate-900 border border-slate-700 rounded p-1.5 text-center font-mono font-bold text-slate-100"
              />
            </div>

            <div className="bg-slate-950 p-2 rounded-xl border border-slate-800">
              <label className="text-slate-400 block mb-1 text-[11px]">معدل التنفس RR (/min):</label>
              <input
                type="number"
                value={vitals.respRate}
                onChange={(e) => setVitals({ ...vitals, respRate: Number(e.target.value) })}
                className="w-full bg-slate-900 border border-slate-700 rounded p-1.5 text-center font-mono font-bold text-slate-100"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-400"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-bold"
            >
              تأكيد وحفظ
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
