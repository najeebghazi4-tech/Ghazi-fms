import React, { useState } from 'react';
import { 
  ShieldCheck, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  Search, 
  Filter, 
  Plus, 
  Printer, 
  Clock, 
  MapPin, 
  Check, 
  Building2,
  Flame,
  FileText,
  Database,
  QrCode,
  Send,
  Calendar,
  CalendarDays,
  Layers,
  ChevronLeft,
  Globe,
  HardHat,
  Wind,
  Lock,
  Zap,
  Truck,
  Package,
  Wrench,
  GraduationCap,
  Scale,
  ClipboardList,
  Users,
  Edit3,
  Trash2,
  X,
  Save,
  Megaphone,
  Target
} from 'lucide-react';
import { 
  SafetyInspectionItem, 
  SafetyTourRecord, 
  SafetyViolationNotice, 
  FireExtinguisherItem, 
  StaffUser,
  ContractorPermitNotice,
  IncineratorOperationNotice,
  NewHiresTrainingNotice,
  TrainingNominationNotice,
  SafetyIncidentReport
} from '../types';
import { INITIAL_MIGRATIONS } from '../data/azalSafetyUpgradeData';
import { AzalLogo } from './AzalLogo';
import { CbahiComplianceBanner } from './CbahiComplianceBanner';
import { FireExtinguisherView } from './FireExtinguisherView';
import { ViolationsManagementView } from './ViolationsManagementView';
import { SafetyTourModal } from './SafetyTourModal';
import { SafetyExecutiveReportsModal } from './SafetyExecutiveReportsModal';
import { GeneralManagerReportsView } from './GeneralManagerReportsView';
import { DatabaseMigrationsModal } from './DatabaseMigrationsModal';
import { DepartmentAuditView } from './DepartmentAuditView';
import { PublicPortalsManagementView } from './PublicPortalsManagementView';
import { MedicalGasInspectionView } from './MedicalGasInspectionView';
import { SensitiveAreasAuditView } from './SensitiveAreasAuditView';
import { GeneratorAndFacpInspectionView } from './GeneratorAndFacpInspectionView';
import { HospitalPropertyExitLogView } from './HospitalPropertyExitLogView';
import { LostAndFoundLogView } from './LostAndFoundLogView';
import { PreventiveMaintenanceView } from './PreventiveMaintenanceView';
import { SafetyTrainingScheduleView } from './SafetyTrainingScheduleView';
import { PenaltiesViolationsLogView } from './PenaltiesViolationsLogView';
import { DailyOperationalLogView } from './DailyOperationalLogView';
import { SafetyCommitteeHubView } from './SafetyCommitteeHubView';
import { FmsOperationalPlansView } from './FmsOperationalPlansView';
import { ServicesHubPromoPosterModal } from './ServicesHubPromoPosterModal';
import { CbahiFocusPdcaModal } from './CbahiFocusPdcaModal';

interface SafetyInspectionViewProps {
  inspections: SafetyInspectionItem[];
  tours: SafetyTourRecord[];
  violations: SafetyViolationNotice[];
  extinguishers: FireExtinguisherItem[];
  incidents?: SafetyIncidentReport[];
  contractorNotices?: ContractorPermitNotice[];
  incineratorNotices?: IncineratorOperationNotice[];
  newHiresNotices?: NewHiresTrainingNotice[];
  trainingNominations?: TrainingNominationNotice[];
  currentUser: StaffUser;
  isOnline: boolean;
  isReadOnly?: boolean;
  onUpdateInspection: (updatedList: SafetyInspectionItem[]) => void;
  onSaveTour: (tour: SafetyTourRecord, autoViolation?: SafetyViolationNotice) => void;
  onDeleteTour?: (id: string) => void;
  onSaveExtinguisher: (item: FireExtinguisherItem) => void;
  onDeleteExtinguisher?: (id: string) => void;
  onUpdateViolation: (updated: SafetyViolationNotice) => void;
  onDeleteViolation?: (id: string) => void;
  onOpenCbahiRegisters?: () => void;
  onOpenFocusPdcaModal?: () => void;
  onUpdateContractorNotice?: (updated: ContractorPermitNotice) => void;
  onUpdateIncineratorNotice?: (updated: IncineratorOperationNotice) => void;
  onUpdateNewHiresNotice?: (updated: NewHiresTrainingNotice) => void;
  onUpdateTrainingNomination?: (updated: TrainingNominationNotice) => void;
  onApplyMigrations: () => void;
  onSyncNow: () => void;
  onOpenPublicPortal: () => void;
  onLogAudit: (action: string, actionAr: string, details: string) => void;
  onOpenIncomingReportsModal?: () => void;
  onOpenResolvePortal?: (violationId: string) => void;
}

export type SafetySubTab = 
  | 'tours' 
  | 'fms_plans'
  | 'daily_log'
  | 'safety_committee'
  | 'safety_training'
  | 'penalties_log'
  | 'preventive_maintenance'
  | 'department_audits' 
  | 'medical_gas' 
  | 'sensitive_areas' 
  | 'generator_facp' 
  | 'property_exit' 
  | 'lost_found' 
  | 'public_portals' 
  | 'extinguishers' 
  | 'violations' 
  | 'reports' 
  | 'checkpoints';

export const SafetyInspectionView: React.FC<SafetyInspectionViewProps> = ({
  inspections,
  tours,
  violations,
  extinguishers,
  incidents = [],
  contractorNotices = [],
  incineratorNotices = [],
  newHiresNotices = [],
  trainingNominations = [],
  currentUser,
  isOnline,
  isReadOnly = false,
  onUpdateInspection,
  onSaveTour,
  onDeleteTour,
  onSaveExtinguisher,
  onDeleteExtinguisher,
  onUpdateViolation,
  onDeleteViolation,
  onOpenCbahiRegisters,
  onOpenFocusPdcaModal,
  onUpdateContractorNotice = () => {},
  onUpdateIncineratorNotice = () => {},
  onUpdateNewHiresNotice = () => {},
  onUpdateTrainingNomination = () => {},
  onApplyMigrations,
  onSyncNow,
  onOpenPublicPortal,
  onLogAudit,
  onOpenIncomingReportsModal,
  onOpenResolvePortal,
}) => {
  const isReadOnlyMode = isReadOnly || currentUser.role === 'general_director';
  const [subTab, setSubTab] = useState<SafetySubTab>(isReadOnlyMode ? 'reports' : 'tours');
  const [showTourModal, setShowTourModal] = useState(false);
  const [showReportsModal, setShowReportsModal] = useState(false);
  const [showMigrationsModal, setShowMigrationsModal] = useState(false);
  const [showPromoPosterModal, setShowPromoPosterModal] = useState(false);
  const [showFocusPdcaModal, setShowFocusPdcaModal] = useState(false);

  // CRUD state for tours and checkpoints
  const [editingTour, setEditingTour] = useState<SafetyTourRecord | null>(null);
  const [deleteConfirmTour, setDeleteConfirmTour] = useState<SafetyTourRecord | null>(null);
  const [editingCheckpoint, setEditingCheckpoint] = useState<SafetyInspectionItem | null>(null);
  const [deleteConfirmCheckpoint, setDeleteConfirmCheckpoint] = useState<SafetyInspectionItem | null>(null);

  // Checkpoints list filter state
  const [items, setItems] = useState<SafetyInspectionItem[]>([...inspections]);
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);

  // New checkpoint form state
  const [newTitle, setNewTitle] = useState('');
  const [newLocation, setNewLocation] = useState('');
  const [newCategory, setNewCategory] = useState<'fire' | 'medical_gas' | 'emergency_exits' | 'electrical' | 'cctv_access' | 'biohazard'>('fire');
  const [newNotes, setNewNotes] = useState('');

  const handleStatusChange = (id: string, newStatus: 'pass' | 'fail' | 'needs_attention') => {
    const updated = items.map((item) => {
      if (item.id === id) {
        return {
          ...item,
          status: newStatus,
          lastChecked: `اليوم ${new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}`,
          inspector: currentUser.name,
        };
      }
      return item;
    });
    setItems(updated);
    onUpdateInspection(updated);

    const changedItem = items.find((i) => i.id === id);
    onLogAudit(
      'SAFETY_INSPECTION_UPDATED',
      'تحديث جولة تفتيش السلامة',
      `تم تحديث حالة (${changedItem?.titleAr}) إلى: ${newStatus === 'pass' ? 'مطابق ومعتمد' : newStatus === 'fail' ? 'غير مطابق' : 'بحاجة لمتابعة'}.`
    );
  };

  const handleAddInspectionItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newLocation.trim()) return;

    const categoryNames: Record<string, string> = {
      fire: 'منظومة مكافحة الحريق',
      medical_gas: 'شبكة الأكسجين والغازات',
      emergency_exits: 'مخارج الطوارئ ومسارات الهروب',
      electrical: 'المولدات والطاقة الاحتياطية',
      cctv_access: 'كاميرات المراقبة وبوابات الدخول',
      biohazard: 'النفايات الطبية الخطرة',
    };

    const newItem: SafetyInspectionItem = {
      id: `insp-${Date.now()}`,
      category: newCategory,
      categoryAr: categoryNames[newCategory] || 'سلامة عامة',
      titleAr: newTitle.trim(),
      locationAr: newLocation.trim(),
      status: 'pass',
      lastChecked: `الآن (${currentUser.name})`,
      inspector: currentUser.name,
      notes: newNotes.trim() || 'تم الفحص والتأكد من مطابقة معايير السلامة.',
    };

    const updated = [newItem, ...items];
    setItems(updated);
    onUpdateInspection(updated);
    setShowAddForm(false);
    setNewTitle('');
    setNewLocation('');
    setNewNotes('');

    onLogAudit(
      'SAFETY_CHECKPOINT_ADDED',
      'إضافة نقطة فحص سلامة جديدة',
      `تمت إضافة نقطة الفحص: ${newItem.titleAr} بموقع ${newItem.locationAr}.`
    );
  };

  const filteredItems = items.filter((item) => {
    const matchesCat = categoryFilter === 'all' || item.category === categoryFilter;
    const matchesSearch =
      item.titleAr.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.locationAr.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.notes.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const passCount = items.filter((i) => i.status === 'pass').length;
  const attentionCount = items.filter((i) => i.status === 'needs_attention').length;
  const failCount = items.filter((i) => i.status === 'fail').length;
  const complianceRate = Math.round((passCount / (items.length || 1)) * 100);

  const pendingViolationsCount = violations.filter(v => v.status === 'pending' || v.status === 'overdue').length;

  const pendingPublicCount = 
    contractorNotices.filter(n => n.status === 'pending_review').length +
    incineratorNotices.filter(n => n.status === 'scheduled').length +
    newHiresNotices.filter(n => n.status === 'new_request').length +
    trainingNominations.filter(n => n.status === 'received').length;

  return (
    <div id="safety-inspection-view" className="space-y-4 pb-20 text-right">
      {/* Top Banner with Hospital Logo & Actions */}
      <div className="no-print bg-gradient-to-r from-teal-950 via-slate-900 to-slate-900 border border-teal-800/60 rounded-2xl p-4 shadow-lg flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <AzalLogo size="md" showText={false} />
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-slate-100">
                منظومة إدارة الأمن والسلامة
              </h2>
              <span className="text-[10px] bg-teal-950 text-teal-300 border border-teal-800 px-2 py-0.5 rounded font-mono font-bold">
                مستشفى آزال
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              جولات تفتيش دورية، استمارات طفايات الحريق، إشعارات الواتساب، والتقارير التنفيذية
            </p>
          </div>
        </div>

        {/* Quick Action Buttons Header */}
        <div className="flex flex-wrap items-center gap-2 self-start lg:self-auto">
          {!isReadOnlyMode && (
            <button
              type="button"
              onClick={() => setShowTourModal(true)}
              className="px-3.5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold shadow-lg shadow-teal-950 flex items-center gap-1.5 transition"
            >
              <Plus className="w-4 h-4" />
              <span>تسجيل جولة سلامة</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => setSubTab('safety_training')}
            className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition ${
              subTab === 'safety_training'
                ? 'bg-teal-600 text-white shadow-lg shadow-teal-950 ring-2 ring-teal-400/50'
                : 'bg-slate-800 hover:bg-slate-700 text-teal-300 border border-slate-700'
            }`}
            title="خطة وجدول التدريب على السلامة والمرافق (Supabase)"
          >
            <GraduationCap className="w-4 h-4 text-teal-400" />
            <span>جدول التدريب (FMS)</span>
          </button>

          <button
            type="button"
            onClick={() => setSubTab('penalties_log')}
            className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition ${
              subTab === 'penalties_log'
                ? 'bg-rose-600 text-white shadow-lg shadow-rose-950 ring-2 ring-rose-400/50'
                : 'bg-slate-800 hover:bg-slate-700 text-rose-300 border border-slate-700'
            }`}
            title="سجل العقوبات والجزاءات الإدارية (Supabase)"
          >
            <Scale className="w-4 h-4 text-rose-400" />
            <span>سجل الجزاءات (HR)</span>
          </button>

          <button
            type="button"
            onClick={() => setSubTab('reports')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition ${
              isReadOnlyMode 
                ? 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-lg shadow-emerald-950 ring-2 ring-emerald-400/50' 
                : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
            }`}
            title="عرض تقارير الإدارة العامة والطباعة الرسمية"
          >
            <Building2 className={`w-4 h-4 ${isReadOnlyMode ? 'text-white' : 'text-teal-400'}`} />
            <span>تقارير الإدارة ومؤشرات سباهي (CBAHI)</span>
          </button>

          {/* CBAHI FOCUS-PDCA Continuous Improvement & Quality KPIs Modal Trigger */}
          <button
            type="button"
            id="btn-open-focus-pdca-quick"
            onClick={() => {
              if (onOpenFocusPdcaModal) {
                onOpenFocusPdcaModal();
              } else {
                setShowFocusPdcaModal(true);
              }
            }}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-teal-600 via-indigo-600 to-purple-600 hover:from-teal-500 hover:to-indigo-500 text-white text-xs font-black shadow-lg shadow-teal-950/70 flex items-center gap-1.5 transition active:scale-95 cursor-pointer ring-1 ring-teal-300/50"
            title="عرض وتصدير تقرير منهجية التحسين المستمر FOCUS-PDCA ومؤشرات أداء الجودة سباهي"
          >
            <Target className="w-4 h-4 text-teal-200 animate-pulse" />
            <span>🎯 منهجية التحسين (FOCUS-PDCA)</span>
          </button>

          {/* Services Hub Promo Poster Generator Button */}
          <button
            type="button"
            onClick={() => setShowPromoPosterModal(true)}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 via-amber-600 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 text-xs font-black shadow-lg shadow-amber-950 flex items-center gap-1.5 transition active:scale-95 cursor-pointer ring-1 ring-amber-300/50"
            title="توليد بوستر إعلاني رسمي للبوابة A4 بهوية كحلية وذهبية فاخرة للطباعة والتحميل"
          >
            <Megaphone className="w-4 h-4 text-slate-950" />
            <span>📢 توليد بوستر إعلان البوابة</span>
          </button>

          <button
            type="button"
            onClick={() => setSubTab('public_portals')}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-600 to-teal-600 hover:from-amber-500 hover:to-teal-500 text-white text-xs font-bold shadow-md flex items-center gap-1.5 transition"
            title="إدارة البوابات العامة الأربع (مقاولين، محرقة، تدريب جدد، ترشيحات)"
          >
            <Globe className="w-4 h-4" />
            <span>بوابات الخدمات العامة (4)</span>
            {pendingPublicCount > 0 && (
              <span className="bg-rose-500 text-white text-[10px] font-mono px-1.5 py-0.2 rounded-full mr-0.5 animate-pulse">
                {pendingPublicCount}
              </span>
            )}
          </button>

          {!isReadOnlyMode && (
            <button
              type="button"
              onClick={() => setShowMigrationsModal(true)}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-blue-300 border border-slate-700 text-xs font-bold flex items-center gap-1.5 transition"
              title="إدارة قاعدة البيانات والمزامنة دون إنترنت"
            >
              <Database className="w-4 h-4 text-blue-400" />
              <span>قاعدة البيانات (Offline)</span>
            </button>
          )}

          <button
            type="button"
            onClick={onOpenPublicPortal}
            className="px-3 py-2 rounded-xl bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 text-xs font-bold flex items-center gap-1.5 transition"
            title="فتح بوابة البلاغات العامة للزوار برمز QR"
          >
            <QrCode className="w-4 h-4 text-emerald-400" />
            <span>بوابة البلاغات (QR)</span>
          </button>
        </div>
      </div>

      {/* Executive Read-Only Banner for General Director */}
      {isReadOnlyMode && (
        <div className="bg-gradient-to-r from-emerald-950 via-teal-950 to-slate-900 border-2 border-emerald-600/80 rounded-2xl p-4 text-xs text-white shadow-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 animate-in fade-in duration-300">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-emerald-900/90 border border-emerald-400 text-emerald-200 flex items-center justify-center font-black text-xl shrink-0 shadow-inner">
              🏛️
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-black text-white">
                  وضع الرقابة والمتابعة الإشرافية (المدير العام: {currentUser.name})
                </h3>
                <span className="text-[10px] bg-emerald-900 text-emerald-300 border border-emerald-500 px-2 py-0.5 rounded-full font-bold">
                  قراءة ورقابة فقط (Read-Only)
                </span>
              </div>
              <p className="text-slate-300 text-xs mt-1 leading-relaxed">
                تقتصر صلاحيات الإدارة العامة على استعراض مؤشرات الأداء، تقارير اللجان الدورية، ومحاضر سباهي (CBAHI FMS) دون إمكانية إدخال جولات أو تعديل البيانات لضمان النزاهة الرقابية.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setSubTab('reports')}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs shadow-lg shadow-emerald-950 flex items-center justify-center gap-1.5 shrink-0 transition active:scale-95"
          >
            <Building2 className="w-4 h-4" />
            <span>عرض التقارير ومحاضر سباهي 📊</span>
          </button>
        </div>
      )}

      {/* Live CBAHI Compliance Tracker Banner */}
      <CbahiComplianceBanner 
        onOpenCbahiRegisters={onOpenCbahiRegisters} 
        onOpenFocusPdcaModal={onOpenFocusPdcaModal || (() => setShowFocusPdcaModal(true))}
        onLogAudit={onLogAudit} 
      />

      {/* Sub-Tabs Switcher */}
      <div className="no-print bg-slate-900/90 border border-slate-800 p-1.5 rounded-2xl flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-1 overflow-x-auto py-0.5">
          <button
            type="button"
            onClick={() => setSubTab('tours')}
            className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 ${
              subTab === 'tours'
                ? 'bg-teal-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>جولات السلامة الميدانية ({tours.length})</span>
          </button>

          <button
            type="button"
            id="subtab-fms-plans"
            onClick={() => setSubTab('fms_plans')}
            className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 ${
              subTab === 'fms_plans'
                ? 'bg-gradient-to-r from-teal-600 to-emerald-600 text-white shadow-lg shadow-teal-950 font-black ring-2 ring-teal-400/50'
                : 'text-slate-400 hover:text-teal-300'
            }`}
          >
            <CalendarDays className="w-4 h-4 text-teal-400" />
            <span>خطط السلامة التشغيلية (FMS)</span>
          </button>

          <button
            type="button"
            id="subtab-daily-log"
            onClick={() => setSubTab('daily_log')}
            className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 ${
              subTab === 'daily_log'
                ? 'bg-teal-600 text-white shadow-md'
                : 'text-slate-400 hover:text-teal-300'
            }`}
          >
            <ClipboardList className="w-4 h-4 text-teal-400" />
            <span>سجل الأعمال اليومية (FMS)</span>
          </button>

          <button
            type="button"
            id="subtab-safety-committee"
            onClick={() => setSubTab('safety_committee')}
            className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 ${
              subTab === 'safety_committee'
                ? 'bg-amber-600 text-slate-950 font-black shadow-md'
                : 'text-slate-400 hover:text-amber-300'
            }`}
          >
            <Users className="w-4 h-4 text-amber-400" />
            <span>اجتماعات لجنة السلامة والمحاضر</span>
          </button>

          <button
            type="button"
            id="subtab-safety-training"
            onClick={() => setSubTab('safety_training')}
            className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 ${
              subTab === 'safety_training'
                ? 'bg-teal-600 text-white shadow-md'
                : 'text-slate-400 hover:text-teal-300'
            }`}
          >
            <GraduationCap className="w-4 h-4 text-teal-400" />
            <span>خطة وجدول التدريب (FMS)</span>
          </button>

          <button
            type="button"
            id="subtab-penalties-log"
            onClick={() => setSubTab('penalties_log')}
            className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 ${
              subTab === 'penalties_log'
                ? 'bg-rose-600 text-white shadow-md'
                : 'text-slate-400 hover:text-rose-300'
            }`}
          >
            <Scale className="w-4 h-4 text-rose-400" />
            <span>سجل العقوبات والجزاءات</span>
          </button>

          <button
            type="button"
            id="subtab-preventive-maintenance"
            onClick={() => setSubTab('preventive_maintenance')}
            className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 ${
              subTab === 'preventive_maintenance'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-400 hover:text-blue-300'
            }`}
          >
            <Wrench className="w-4 h-4 text-blue-400" />
            <span>الصيانة الوقائية (FMS)</span>
          </button>

          <button
            type="button"
            id="subtab-public-portals"
            onClick={() => setSubTab('public_portals')}
            className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 relative ${
              subTab === 'public_portals'
                ? 'bg-gradient-to-r from-teal-600 to-amber-600 text-white shadow-md'
                : 'text-slate-400 hover:text-amber-300'
            }`}
          >
            <Globe className="w-4 h-4 text-amber-400" />
            <span>بوابات الخدمات العامة (4)</span>
            {pendingPublicCount > 0 && (
              <span className="bg-rose-500 text-white text-[10px] font-mono px-1.5 py-0.2 rounded-full mr-1 animate-pulse">
                {pendingPublicCount}
              </span>
            )}
          </button>

          <button
            type="button"
            id="subtab-department-audits"
            onClick={() => setSubTab('department_audits')}
            className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 ${
              subTab === 'department_audits'
                ? 'bg-teal-700 text-white shadow-md'
                : 'text-slate-400 hover:text-teal-300'
            }`}
          >
            <Building2 className="w-4 h-4 text-teal-400" />
            <span>تدقيق الأقسام (CBAHI)</span>
          </button>

          <button
            type="button"
            onClick={() => setSubTab('medical_gas')}
            className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 ${
              subTab === 'medical_gas'
                ? 'bg-teal-600 text-white shadow-md'
                : 'text-slate-400 hover:text-teal-200'
            }`}
          >
            <Wind className="w-4 h-4 text-teal-300" />
            <span>أسطوانات الغازات</span>
          </button>

          <button
            type="button"
            onClick={() => setSubTab('sensitive_areas')}
            className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 ${
              subTab === 'sensitive_areas'
                ? 'bg-purple-600 text-white shadow-md'
                : 'text-slate-400 hover:text-purple-300'
            }`}
          >
            <Lock className="w-4 h-4 text-purple-400" />
            <span>المناطق الحساسة (4)</span>
          </button>

          <button
            type="button"
            onClick={() => setSubTab('generator_facp')}
            className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 ${
              subTab === 'generator_facp'
                ? 'bg-amber-600 text-slate-950 shadow-md font-black'
                : 'text-slate-400 hover:text-amber-300'
            }`}
          >
            <Zap className="w-4 h-4 text-amber-400" />
            <span>المولدات وإنذار FACP</span>
          </button>

          <button
            type="button"
            onClick={() => setSubTab('property_exit')}
            className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 ${
              subTab === 'property_exit'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-slate-400 hover:text-emerald-300'
            }`}
          >
            <Truck className="w-4 h-4 text-emerald-400" />
            <span>خروج الممتلكات</span>
          </button>

          <button
            type="button"
            onClick={() => setSubTab('lost_found')}
            className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 ${
              subTab === 'lost_found'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-indigo-300'
            }`}
          >
            <Package className="w-4 h-4 text-indigo-400" />
            <span>سجل المفقودات</span>
          </button>

          <button
            type="button"
            onClick={() => setSubTab('extinguishers')}
            className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 ${
              subTab === 'extinguishers'
                ? 'bg-red-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Flame className="w-4 h-4" />
            <span>فحص طفايات الحريق ({extinguishers.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setSubTab('violations')}
            className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 relative ${
              subTab === 'violations'
                ? 'bg-amber-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Send className="w-4 h-4" />
            <span>إشعارات المخالفات والواتساب</span>
            {pendingViolationsCount > 0 && (
              <span className="bg-rose-500 text-white text-[10px] font-mono px-1.5 py-0.2 rounded-full mr-1">
                {pendingViolationsCount}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={() => setSubTab('reports')}
            className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 ${
              subTab === 'reports'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileText className="w-4 h-4 text-teal-300" />
            <span>تقارير الإدارة العامة</span>
          </button>

          <button
            type="button"
            onClick={() => setSubTab('checkpoints')}
            className={`px-3.5 py-2 rounded-xl font-bold transition flex items-center gap-1.5 ${
              subTab === 'checkpoints'
                ? 'bg-slate-700 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>بنود الفحص الدورية ({items.length})</span>
          </button>
        </div>

        {/* Compliance indicator */}
        <div className="text-[11px] text-slate-400 flex items-center gap-2 pl-2">
          <span>نسبة المطابقة العامة:</span>
          <strong className="text-emerald-400 font-mono font-bold text-xs">{complianceRate}%</strong>
        </div>
      </div>

      {/* VIEW 1: Safety Tours */}
      {subTab === 'tours' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between bg-slate-900 border border-slate-800 p-3 rounded-xl">
            <div>
              <h3 className="text-xs font-bold text-slate-200">
                سجل جولات التفتيش الميدانية لضباط السلامة
              </h3>
              <p className="text-[11px] text-slate-400">
                جولات منتظمة مع قوائم مهام متعددة ورصد المخالفات الفورية
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowTourModal(true)}
              className="px-3 py-1.5 bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>تسجيل جولة جديدة</span>
            </button>
          </div>

          <div className="space-y-3">
            {tours.map((tour) => (
              <div
                key={tour.id}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-sm space-y-2.5 text-xs hover:border-slate-700 transition"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-teal-400">{tour.id}</span>
                    <strong className="text-slate-100 text-sm">{tour.department}</strong>
                    {tour.hasViolation ? (
                      <span className="px-2 py-0.5 rounded-full bg-rose-950 text-rose-300 border border-rose-800 text-[10px] font-bold">
                        ⚠️ رُصدت مخالفة ({tour.violationId})
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800 text-[10px] font-bold">
                        🟢 مطابقة تامة
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] text-slate-400 flex items-center gap-2">
                    <span>المفتش: <strong className="text-slate-200">{tour.inspectorName}</strong></span>
                    <span>•</span>
                    <span className="font-mono">{tour.tourDate}</span>

                    {!isReadOnlyMode && (
                      <div className="flex items-center gap-1 mr-2 border-r border-slate-800 pr-2">
                        <button
                          type="button"
                          onClick={() => setEditingTour(tour)}
                          className="p-1 px-2 rounded-lg bg-slate-800 hover:bg-teal-950 text-teal-300 border border-slate-700/60 text-[11px] font-bold transition flex items-center gap-1"
                          title="تعديل سجل الجولة"
                        >
                          <Edit3 className="w-3 h-3" />
                          <span>تعديل</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setDeleteConfirmTour(tour)}
                          className="p-1 px-2 rounded-lg bg-slate-800 hover:bg-rose-950 text-rose-400 hover:text-rose-300 border border-slate-700/60 text-[11px] font-bold transition flex items-center gap-1"
                          title="حذف الجولة من السجل الرسمي"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>حذف</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* Tasks checklist summary */}
                <div>
                  <span className="text-[11px] text-slate-400 block mb-1 font-semibold">
                    المهام المفحوصة في الجولة:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {tour.tasks.map((task, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-slate-300 text-[10px]"
                      >
                        ✓ {task}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="text-[11px] text-slate-300 bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80">
                  <span className="text-slate-400 font-bold ml-1">تقرير الجولة:</span>
                  <span>{tour.notes}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* VIEW: Preventive Maintenance (CBAHI FMS - USM & MEM) */}
      {subTab === 'preventive_maintenance' && (
        <PreventiveMaintenanceView />
      )}

      {/* VIEW 2: Fire Extinguishers Module */}
      {subTab === 'extinguishers' && (
        <FireExtinguisherView
          extinguishers={extinguishers}
          currentUser={currentUser}
          onSaveExtinguisher={onSaveExtinguisher}
          onDeleteExtinguisher={onDeleteExtinguisher}
          onLogAudit={onLogAudit}
        />
      )}

      {/* VIEW 3: Violations Management & WhatsApp Dispatch */}
      {subTab === 'violations' && (
        <ViolationsManagementView
          violations={violations}
          currentUser={currentUser}
          onUpdateViolation={onUpdateViolation}
          onDeleteViolation={onDeleteViolation}
          onLogAudit={onLogAudit}
          onOpenIncomingReportsModal={onOpenIncomingReportsModal}
          onOpenResolvePortal={onOpenResolvePortal}
        />
      )}

      {/* VIEW 4: Checkpoints (Existing granular inspections) */}
      {subTab === 'checkpoints' && (
        <div className="space-y-3">
          {/* Metrics Row */}
          <div className="grid grid-cols-3 gap-2.5">
            <div className="bg-emerald-950/40 border border-emerald-800/60 rounded-2xl p-3 text-right">
              <span className="text-[11px] text-emerald-300 block font-semibold">مطابق ومعتمد (Pass)</span>
              <span className="text-xl font-bold text-emerald-400 font-mono">{passCount}</span>
            </div>
            <div className="bg-amber-950/40 border border-amber-800/60 rounded-2xl p-3 text-right">
              <span className="text-[11px] text-amber-300 block font-semibold">بحاجة لمتابعة (Attention)</span>
              <span className="text-xl font-bold text-amber-400 font-mono">{attentionCount}</span>
            </div>
            <div className="bg-rose-950/40 border border-rose-800/60 rounded-2xl p-3 text-right">
              <span className="text-[11px] text-rose-300 block font-semibold">غير مطابق (Defect)</span>
              <span className="text-xl font-bold text-rose-400 font-mono">{failCount}</span>
            </div>
          </div>

          {/* Filter and Add Bar */}
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-500 absolute right-3 top-3" />
              <input
                type="text"
                placeholder="بحث بنقطة الفحص، الموقع، الملاحظات..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl pr-9 pl-3 py-2 text-xs text-slate-100 placeholder-slate-500"
              />
            </div>

            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200"
            >
              <option value="all">جميع قطاعات السلامة</option>
              <option value="fire">منظومة مكافحة الحريق</option>
              <option value="medical_gas">شبكة الأكسجين والغازات</option>
              <option value="emergency_exits">مخارج الطوارئ ومسارات الهروب</option>
              <option value="electrical">المولدات والطاقة الاحتياطية</option>
              <option value="cctv_access">كاميرات المراقبة وبوابات الدخول</option>
              <option value="biohazard">النفايات الطبية الخطرة</option>
            </select>

            <button
              type="button"
              onClick={() => setShowAddForm(!showAddForm)}
              className="px-4 py-2 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition shadow"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة نقطة فحص</span>
            </button>
          </div>

          {/* Add Form */}
          {showAddForm && (
            <form onSubmit={handleAddInspectionItem} className="bg-slate-900 border border-teal-700/60 rounded-2xl p-4 space-y-3 animate-fade-in text-xs">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <h4 className="font-bold text-teal-400">إضافة بند فحص دوري جديد لمنظومة السلامة</h4>
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="text-slate-400 hover:text-slate-200"
                >
                  إلغاء
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="text-slate-300 block mb-1">اسم بند / جهاز السلامة:</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: فحص مضخات رشاشات الحريق الآلية (Sprinklers)"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-slate-100"
                  />
                </div>

                <div>
                  <label className="text-slate-300 block mb-1">قطاع السلامة:</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-slate-100"
                  >
                    <option value="fire">منظومة مكافحة الحريق</option>
                    <option value="medical_gas">شبكة الأكسجين والغازات</option>
                    <option value="emergency_exits">مخارج الطوارئ ومسارات الهروب</option>
                    <option value="electrical">المولدات والطاقة الاحتياطية</option>
                    <option value="cctv_access">كاميرات المراقبة وبوابات الدخول</option>
                    <option value="biohazard">النفايات الطبية الخطرة</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-slate-300 block mb-1">الموقع المحدد داخل مستشفى أزال:</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: القبو الفني، جانب محطة الأكسجين المركزية"
                  value={newLocation}
                  onChange={(e) => setNewLocation(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-slate-100"
                />
              </div>

              <div>
                <label className="text-slate-300 block mb-1">الملاحظات ونتائج القياس:</label>
                <textarea
                  rows={2}
                  placeholder="مثال: الضغط مقاس بـ 7 بار، المؤشرات سليمة، لا توجد تسريبات..."
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-slate-100 placeholder-slate-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-3 py-1.5 bg-slate-800 text-slate-300 rounded-lg"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-teal-600 hover:bg-teal-500 text-white rounded-lg font-bold"
                >
                  حفظ النقطة وتثبيتها
                </button>
              </div>
            </form>
          )}

          {/* Checkpoints List */}
          <div className="space-y-3">
            {filteredItems.map((item) => (
              <div
                key={item.id}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-sm hover:border-slate-700 transition space-y-3 text-xs"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-2.5">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] px-2 py-0.5 rounded font-bold bg-teal-950/80 text-teal-300 border border-teal-800 font-mono">
                        {item.categoryAr}
                      </span>
                      <h3 className="font-bold text-slate-100 text-sm">{item.titleAr}</h3>
                    </div>
                    <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-400">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-teal-400" />
                        <span>{item.locationAr}</span>
                      </span>
                      <span>•</span>
                      <span>{item.lastChecked}</span>
                      <span>•</span>
                      <span>المفتش: {item.inspector}</span>
                    </div>
                  </div>

                  <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 gap-1 self-end sm:self-auto">
                    <button
                      type="button"
                      onClick={() => handleStatusChange(item.id, 'pass')}
                      className={`px-3 py-1 rounded-lg font-bold text-[11px] transition flex items-center gap-1 ${
                        item.status === 'pass'
                          ? 'bg-emerald-600 text-white shadow-sm'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>مطابق</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleStatusChange(item.id, 'needs_attention')}
                      className={`px-3 py-1 rounded-lg font-bold text-[11px] transition flex items-center gap-1 ${
                        item.status === 'needs_attention'
                          ? 'bg-amber-600 text-white shadow-sm'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <AlertTriangle className="w-3.5 h-3.5" />
                      <span>متابعة</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleStatusChange(item.id, 'fail')}
                      className={`px-3 py-1 rounded-lg font-bold text-[11px] transition flex items-center gap-1 ${
                        item.status === 'fail'
                          ? 'bg-rose-600 text-white shadow-sm'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      <span>غير مطابق</span>
                    </button>

                    {!isReadOnlyMode && (
                      <div className="flex items-center gap-1 mr-2 border-r border-slate-800 pr-2">
                        <button
                          type="button"
                          onClick={() => setEditingCheckpoint(item)}
                          className="p-1 px-2 rounded-lg bg-slate-800 hover:bg-teal-950 text-teal-300 border border-slate-700/60 text-[11px] font-bold transition flex items-center gap-1"
                          title="تعديل نقطة الفحص"
                        >
                          <Edit3 className="w-3 h-3" />
                          <span>تعديل</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setDeleteConfirmCheckpoint(item)}
                          className="p-1 px-2 rounded-lg bg-slate-800 hover:bg-rose-950 text-rose-400 hover:text-rose-300 border border-slate-700/60 text-[11px] font-bold transition flex items-center gap-1"
                          title="حذف هذا البند من السجل الرسمي"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>حذف</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                <div className="bg-slate-950/70 p-2.5 rounded-xl border border-slate-800/80 text-slate-300 leading-relaxed text-[11px]">
                  <strong className="text-slate-400 ml-1">الملاحظات والتقرير الميداني:</strong>
                  <span>{item.notes}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* VIEW: Public Portals Management Hub (4 Streams) */}
      {subTab === 'public_portals' && (
        <PublicPortalsManagementView
          currentUser={currentUser}
          contractorNotices={contractorNotices}
          incineratorNotices={incineratorNotices}
          newHiresNotices={newHiresNotices}
          trainingNominations={trainingNominations}
          onUpdateContractorNotice={onUpdateContractorNotice}
          onUpdateIncineratorNotice={onUpdateIncineratorNotice}
          onUpdateNewHiresNotice={onUpdateNewHiresNotice}
          onUpdateTrainingNomination={onUpdateTrainingNomination}
          onLogAudit={onLogAudit}
        />
      )}

      {/* VIEW: Daily Operational Log (Supabase: daily_safety_actions) */}
      {subTab === 'daily_log' && (
        <DailyOperationalLogView
          currentUser={currentUser}
          onLogAudit={onLogAudit}
          onOpenResolvePortal={onOpenResolvePortal}
        />
      )}

      {/* VIEW: FMS Operational Plans & Frequency Selector (CBAHI FMS) */}
      {subTab === 'fms_plans' && (
        <FmsOperationalPlansView
          currentUser={currentUser}
          isReadOnlyMode={isReadOnlyMode}
        />
      )}

      {/* VIEW: Safety Committee Hub (Supabase: safety_committee_meetings) */}
      {subTab === 'safety_committee' && (
        <SafetyCommitteeHubView
          currentUser={currentUser}
          onLogAudit={onLogAudit}
        />
      )}

      {/* VIEW: Safety Training Schedule (Supabase: safety_trainings) */}
      {subTab === 'safety_training' && (
        <SafetyTrainingScheduleView
          currentUser={currentUser}
          onLogAudit={onLogAudit}
        />
      )}

      {/* VIEW: Penalties & Violations Log (Supabase: penalties_log) */}
      {subTab === 'penalties_log' && (
        <PenaltiesViolationsLogView
          currentUser={currentUser}
          onLogAudit={onLogAudit}
        />
      )}

      {/* VIEW: Department Audit (CBAHI / JCI Offline-First) */}
      {subTab === 'department_audits' && (
        <DepartmentAuditView
          currentUser={currentUser}
          onLogAudit={onLogAudit}
        />
      )}

      {/* VIEW: Medical Gas Cylinder Inspection (CBAHI FMS.4) */}
      {subTab === 'medical_gas' && (
        <MedicalGasInspectionView
          currentUser={currentUser}
          onLogAudit={onLogAudit}
        />
      )}

      {/* VIEW: Sensitive Areas 4-Point Audit (CBAHI FMS) */}
      {subTab === 'sensitive_areas' && (
        <SensitiveAreasAuditView
          currentUser={currentUser}
          onLogAudit={onLogAudit}
        />
      )}

      {/* VIEW: Generator Routine Tests & FACP Readiness Audit */}
      {subTab === 'generator_facp' && (
        <GeneratorAndFacpInspectionView
          currentUser={currentUser}
          onLogAudit={onLogAudit}
        />
      )}

      {/* VIEW: Hospital Property Exit Gate Pass Log */}
      {subTab === 'property_exit' && (
        <HospitalPropertyExitLogView
          currentUser={currentUser}
          onLogAudit={onLogAudit}
        />
      )}

      {/* VIEW: Lost & Found Log */}
      {subTab === 'lost_found' && (
        <LostAndFoundLogView
          currentUser={currentUser}
          onLogAudit={onLogAudit}
        />
      )}

      {/* VIEW: General Manager Official Executive Reports */}
      {subTab === 'reports' && (
        <GeneralManagerReportsView
          tours={tours}
          violations={violations}
          extinguishers={extinguishers}
          incidents={incidents}
          currentUser={currentUser}
        />
      )}

      {/* Modals */}
      {showTourModal && (
        <SafetyTourModal
          currentUser={currentUser}
          onClose={() => setShowTourModal(false)}
          onSaveTour={onSaveTour}
        />
      )}

      {showReportsModal && (
        <SafetyExecutiveReportsModal
          tours={tours}
          violations={violations}
          extinguishers={extinguishers}
          currentUser={currentUser}
          onClose={() => setShowReportsModal(false)}
        />
      )}

      {showMigrationsModal && (
        <DatabaseMigrationsModal
          migrations={INITIAL_MIGRATIONS}
          isOnline={isOnline}
          onApplyMigrations={onApplyMigrations}
          onSyncNow={onSyncNow}
          onClose={() => setShowMigrationsModal(false)}
        />
      )}

      {/* Edit Safety Tour Modal */}
      {editingTour && (
        <SafetyTourModal
          currentUser={currentUser}
          initialTour={editingTour}
          onClose={() => setEditingTour(null)}
          onSaveTour={(updatedTour) => {
            onSaveTour(updatedTour);
            onLogAudit(
              'SAFETY_TOUR_EDITED',
              'تعديل جولة تفتيش سلامة',
              `تم تعديل بيانات جولة السلامة (${updatedTour.id}) لقسم ${updatedTour.department} بواسطة ${currentUser.name}.`
            );
            setEditingTour(null);
          }}
        />
      )}

      {/* Delete Tour Confirmation Modal */}
      {deleteConfirmTour && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-3">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-5 text-right space-y-4 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 text-rose-400">
              <div className="p-2.5 rounded-xl bg-rose-950/80 border border-rose-800">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-100">تأكيد حذف جولة السلامة</h3>
                <span className="text-[11px] text-slate-400 font-mono">{deleteConfirmTour.id} • {deleteConfirmTour.department}</span>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              هل أنت متأكد من حذف هذا البند من السجل الرسمي؟
              <span className="block text-rose-300 font-semibold mt-1">
                ⚠️ تنبيه: سيتم حذف هذا السجل نهائياً وتحديث إجمالي العدادات ومؤشرات الامتثال فوراً.
              </span>
            </p>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setDeleteConfirmTour(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition"
              >
                إلغاء التراجع
              </button>
              <button
                type="button"
                onClick={() => {
                  if (onDeleteTour) {
                    onDeleteTour(deleteConfirmTour.id);
                  }
                  onLogAudit(
                    'SAFETY_TOUR_DELETED',
                    'حذف جولة سلامة ميدانية',
                    `تم حذف جولة السلامة (${deleteConfirmTour.id}) الخاصة بقسم ${deleteConfirmTour.department} بواسطة ${currentUser.name}.`
                  );
                  setDeleteConfirmTour(null);
                }}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-lg shadow-rose-950"
              >
                <Trash2 className="w-4 h-4" />
                <span>تأكيد الحذف النهائي</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Checkpoint Modal */}
      {editingCheckpoint && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-3 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg p-5 text-right space-y-4 shadow-2xl animate-in fade-in zoom-in-95 my-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5 text-teal-400">
                <div className="p-2 rounded-xl bg-teal-950 border border-teal-800">
                  <Edit3 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-100">تعديل نقطة فحص السلامة</h3>
                  <span className="text-[11px] text-slate-400 font-mono">{editingCheckpoint.id}</span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEditingCheckpoint(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                const updated = items.map(item => item.id === editingCheckpoint.id ? editingCheckpoint : item);
                setItems(updated);
                onUpdateInspection(updated);
                onLogAudit(
                  'SAFETY_CHECKPOINT_EDITED',
                  'تعديل نقطة فحص سلامة',
                  `تم تعديل بيانات نقطة الفحص (${editingCheckpoint.titleAr}) بموقع (${editingCheckpoint.locationAr}) بواسطة ${currentUser.name}.`
                );
                setEditingCheckpoint(null);
              }}
              className="space-y-3 text-xs"
            >
              <div>
                <label className="block text-slate-300 font-semibold mb-1">اسم / عنوان نقطة الفحص</label>
                <input
                  type="text"
                  required
                  value={editingCheckpoint.titleAr}
                  onChange={(e) => setEditingCheckpoint({ ...editingCheckpoint, titleAr: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-slate-100 focus:border-teal-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">الموقع الدقيق</label>
                <input
                  type="text"
                  required
                  value={editingCheckpoint.locationAr}
                  onChange={(e) => setEditingCheckpoint({ ...editingCheckpoint, locationAr: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-slate-100 focus:border-teal-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">الملاحظات والتعليمات</label>
                <textarea
                  rows={3}
                  value={editingCheckpoint.notes}
                  onChange={(e) => setEditingCheckpoint({ ...editingCheckpoint, notes: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-slate-100 focus:border-teal-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingCheckpoint(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold flex items-center gap-1.5 shadow-lg shadow-teal-950"
                >
                  <Save className="w-4 h-4" />
                  <span>حفظ التعديلات</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Services Hub Promo Poster Modal (A4 Portrait) */}
      <ServicesHubPromoPosterModal
        isOpen={showPromoPosterModal}
        onClose={() => setShowPromoPosterModal(false)}
      />

      {/* Delete Checkpoint Confirmation Modal */}
      {deleteConfirmCheckpoint && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-3">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-5 text-right space-y-4 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 text-rose-400">
              <div className="p-2.5 rounded-xl bg-rose-950/80 border border-rose-800">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-100">تأكيد حذف نقطة الفحص</h3>
                <span className="text-[11px] text-slate-400 font-mono">{deleteConfirmCheckpoint.titleAr}</span>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              هل أنت متأكد من حذف هذا البند من السجل الرسمي؟
              <span className="block text-rose-300 font-semibold mt-1">
                ⚠️ تنبيه: سيتم حذف هذا السجل نهائياً وتحديث إجمالي العدادات ومؤشرات الامتثال فوراً.
              </span>
            </p>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setDeleteConfirmCheckpoint(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition"
              >
                إلغاء التراجع
              </button>
              <button
                type="button"
                onClick={() => {
                  const updated = items.filter(i => i.id !== deleteConfirmCheckpoint.id);
                  setItems(updated);
                  onUpdateInspection(updated);
                  onLogAudit(
                    'SAFETY_CHECKPOINT_DELETED',
                    'حذف نقطة فحص سلامة',
                    `تم حذف نقطة الفحص (${deleteConfirmCheckpoint.titleAr}) بموقع ${deleteConfirmCheckpoint.locationAr} بواسطة ${currentUser.name}.`
                  );
                  setDeleteConfirmCheckpoint(null);
                }}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-lg shadow-rose-950"
              >
                <Trash2 className="w-4 h-4" />
                <span>تأكيد الحذف النهائي</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CBAHI FOCUS-PDCA Continuous Quality Improvement Modal */}
      {showFocusPdcaModal && (
        <CbahiFocusPdcaModal
          incidents={incidents}
          tours={tours}
          violations={violations}
          extinguishers={extinguishers}
          currentUser={currentUser}
          onClose={() => setShowFocusPdcaModal(false)}
        />
      )}
    </div>
  );
};

// Default export if needed
export default SafetyInspectionView;
