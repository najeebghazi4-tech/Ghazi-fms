import React, { useState, useEffect } from 'react';
import { 
  Zap, 
  Flame, 
  ShieldAlert, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  Plus, 
  Printer, 
  Search, 
  Filter, 
  Clock, 
  BatteryCharging, 
  Fuel, 
  Gauge, 
  Trash2,
  Bell,
  Activity,
  Edit3
} from 'lucide-react';
import { GeneratorFacpInspectionRecord, StaffUser } from '../types';
import { offlineStorage } from '../services/offlineStorage';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';
import { executeSmartPrint } from '../utils/printUtils';

interface GeneratorAndFacpInspectionViewProps {
  currentUser: StaffUser;
  onLogAudit: (action: string, actionAr: string, details: string) => void;
}

const INITIAL_GEN_FACP_RECORDS: GeneratorFacpInspectionRecord[] = [
  {
    id: 'gen-facp-001',
    inspectionDate: new Date().toISOString().split('T')[0],
    inspectionType: 'generator_weekly_no_load',
    targetEquipment: 'generator_1',
    testDurationMinutes: 10,
    fuelLevelPercentage: 90,
    batteryVoltage: 26.4,
    atsAutomaticTransferOk: true,
    oilPressureAndCoolantTempOk: true,
    facpStatus: 'normal',
    facpSmokeDetectorsTested: true,
    facpAudioVisualAlertsOk: true,
    inspectorName: 'م/ نجيب غازي',
    status: 'pass',
    notes: 'تم تشغيل المولد الاحتياطي رقم (1) لمدة 10 دقائق بدون حمل، المحرك يعمل بسلاسة والبطاريات مشحونة بالكامل.',
    createdAt: Date.now() - 1000 * 60 * 60 * 12
  },
  {
    id: 'gen-facp-002',
    inspectionDate: new Date().toISOString().split('T')[0],
    inspectionType: 'facp_readiness_audit',
    targetEquipment: 'facp_main_panel',
    testDurationMinutes: 20,
    fuelLevelPercentage: 0,
    batteryVoltage: 27.2,
    atsAutomaticTransferOk: true,
    oilPressureAndCoolantTempOk: true,
    facpStatus: 'normal',
    facpSmokeDetectorsTested: true,
    facpAudioVisualAlertsOk: true,
    inspectorName: 'مشرف السلامة والإنذار',
    notes: 'تدقيق لوحة إنذار الحريق المركزية (FACP) بالدور الأرضي، جميع الزونات خالية من إشارات الـ Trouble والبطاريات جاهزة.',
    createdAt: Date.now() - 1000 * 60 * 60 * 36
  },
  {
    id: 'gen-facp-003',
    inspectionDate: new Date(Date.now() - 1000 * 60 * 60 * 24 * 7).toISOString().split('T')[0],
    inspectionType: 'generator_monthly_with_load',
    targetEquipment: 'generator_2',
    testDurationMinutes: 30,
    fuelLevelPercentage: 85,
    batteryVoltage: 26.1,
    atsAutomaticTransferOk: true,
    oilPressureAndCoolantTempOk: true,
    facpStatus: 'normal',
    facpSmokeDetectorsTested: true,
    facpAudioVisualAlertsOk: true,
    inspectorName: 'م/ نجيب غازي',
    status: 'pass',
    notes: 'فحص المولد الكهربائي رقم (2) بحمل المستشفى الكامل لمدة 30 دقيقة، مفتاح ATS حول الحمل خلال 4.2 ثوانٍ.',
    createdAt: Date.now() - 1000 * 60 * 60 * 24 * 7
  }
];

export const GeneratorAndFacpInspectionView: React.FC<GeneratorAndFacpInspectionViewProps> = ({
  currentUser,
  onLogAudit
}) => {
  const [records, setRecords] = useState<GeneratorFacpInspectionRecord[]>([]);
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingRecord, setEditingRecord] = useState<GeneratorFacpInspectionRecord | null>(null);
  const [deleteConfirmRecord, setDeleteConfirmRecord] = useState<GeneratorFacpInspectionRecord | null>(null);

  // Form State
  const [inspectionType, setInspectionType] = useState<'generator_weekly_no_load' | 'generator_monthly_with_load' | 'facp_readiness_audit'>('generator_weekly_no_load');
  const [targetEquipment, setTargetEquipment] = useState<'generator_1' | 'generator_2' | 'facp_main_panel'>('generator_1');
  const [testDurationMinutes, setTestDurationMinutes] = useState(10);
  const [fuelLevelPercentage, setFuelLevelPercentage] = useState(90);
  const [batteryVoltage, setBatteryVoltage] = useState(26.4);
  const [atsAutomaticTransferOk, setAtsAutomaticTransferOk] = useState(true);
  const [oilPressureAndCoolantTempOk, setOilPressureAndCoolantTempOk] = useState(true);
  const [facpStatus, setFacpStatus] = useState<'normal' | 'trouble' | 'alarm'>('normal');
  const [facpSmokeDetectorsTested, setFacpSmokeDetectorsTested] = useState(true);
  const [facpAudioVisualAlertsOk, setFacpAudioVisualAlertsOk] = useState(true);
  const [notes, setNotes] = useState('');

  useEffect(() => {
    loadRecords();
  }, []);

  const loadRecords = async () => {
    try {
      const stored = await offlineStorage.getGeneratorFacpRecords();
      if (stored && stored.length > 0) {
        setRecords(stored);
      } else {
        setRecords(INITIAL_GEN_FACP_RECORDS);
        for (const item of INITIAL_GEN_FACP_RECORDS) {
          await offlineStorage.saveGeneratorFacpRecord(item);
        }
      }
    } catch {
      setRecords(INITIAL_GEN_FACP_RECORDS);
    }
  };

  const handleOpenAdd = () => {
    setEditingRecord(null);
    setInspectionType('generator_weekly_no_load');
    setTargetEquipment('generator_1');
    setTestDurationMinutes(10);
    setFuelLevelPercentage(90);
    setBatteryVoltage(26.4);
    setAtsAutomaticTransferOk(true);
    setOilPressureAndCoolantTempOk(true);
    setFacpStatus('normal');
    setFacpSmokeDetectorsTested(true);
    setFacpAudioVisualAlertsOk(true);
    setNotes('');
    setShowAddModal(true);
  };

  const handleOpenEdit = (record: GeneratorFacpInspectionRecord) => {
    setEditingRecord(record);
    setInspectionType((record.inspectionType as any) || 'generator_weekly_no_load');
    setTargetEquipment((record.targetEquipment as any) || 'generator_1');
    setTestDurationMinutes(record.testDurationMinutes || 10);
    setFuelLevelPercentage(record.fuelLevelPercentage ?? 90);
    setBatteryVoltage(record.batteryVoltage ?? 26.4);
    setAtsAutomaticTransferOk(record.atsAutomaticTransferOk ?? true);
    setOilPressureAndCoolantTempOk(record.oilPressureAndCoolantTempOk ?? true);
    setFacpStatus((record.facpStatus as any) || 'normal');
    setFacpSmokeDetectorsTested(record.facpSmokeDetectorsTested ?? true);
    setFacpAudioVisualAlertsOk(record.facpAudioVisualAlertsOk ?? true);
    setNotes(record.notes || '');
    setShowAddModal(true);
  };

  const handleCreateRecord = async (e: React.FormEvent) => {
    e.preventDefault();

    const isGenTest = inspectionType.includes('generator');
    const isPass = isGenTest 
      ? (fuelLevelPercentage >= 50 && atsAutomaticTransferOk && oilPressureAndCoolantTempOk)
      : (facpStatus === 'normal' && facpAudioVisualAlertsOk);

    const status: 'pass' | 'needs_attention' | 'fail' = 
      isPass ? 'pass' : (isGenTest && fuelLevelPercentage < 30) || (!isGenTest && facpStatus === 'trouble') ? 'fail' : 'needs_attention';

    if (editingRecord) {
      const updatedRecord: GeneratorFacpInspectionRecord = {
        ...editingRecord,
        inspectionType,
        targetEquipment,
        testDurationMinutes,
        fuelLevelPercentage: isGenTest ? fuelLevelPercentage : 0,
        batteryVoltage,
        atsAutomaticTransferOk,
        oilPressureAndCoolantTempOk,
        facpStatus,
        facpSmokeDetectorsTested,
        facpAudioVisualAlertsOk,
        status,
        notes: notes.trim() || 'تم تعديل وتحديث بيانات الفحص الفني واعتماد جاهزية المنظومة.',
      };

      const updatedList = records.map(r => r.id === editingRecord.id ? updatedRecord : r);
      setRecords(updatedList);
      await offlineStorage.saveGeneratorFacpRecord(updatedRecord);
      triggerSuccessFeedback();

      onLogAudit(
        'GENERATOR_FACP_INSPECTION_UPDATED',
        'تعديل فحص المولدات ولوحة الإنذار',
        `تم تعديل سجل الفحص (${updatedRecord.id}) - المعدة: ${targetEquipment} - النتيجة: ${status}`
      );
    } else {
      const newRecord: GeneratorFacpInspectionRecord = {
        id: `gen-facp-${Date.now()}`,
        inspectionDate: new Date().toISOString().split('T')[0],
        inspectionType,
        targetEquipment,
        testDurationMinutes,
        fuelLevelPercentage: isGenTest ? fuelLevelPercentage : 0,
        batteryVoltage,
        atsAutomaticTransferOk,
        oilPressureAndCoolantTempOk,
        facpStatus,
        facpSmokeDetectorsTested,
        facpAudioVisualAlertsOk,
        inspectorName: currentUser.name,
        status,
        notes: notes.trim() || 'تم تنفيذ الفحص الفني واعتماد جاهزية المنظومة وفق معايير السلامة FMS.',
        createdAt: Date.now()
      };

      const updated = [newRecord, ...records];
      setRecords(updated);
      await offlineStorage.saveGeneratorFacpRecord(newRecord);
      triggerSuccessFeedback();

      const typeAr = 
        inspectionType === 'generator_weekly_no_load' ? 'فحص المولد أسبوعياً 10 دقائق بدون حمل' :
        inspectionType === 'generator_monthly_with_load' ? 'فحص المولد شهرياً 30 دقيقة بحمل' : 'تدقيق جاهزية لوحة إنذار الحريق FACP';

      onLogAudit(
        'GENERATOR_FACP_INSPECTION_LOGGED',
        'فحص روتيني للمولدات ولوحة الإنذار',
        `تم توثيق (${typeAr}) - المعدة: ${targetEquipment} - النتيجة: ${status}`
      );
    }

    setShowAddModal(false);
    setEditingRecord(null);
    setNotes('');
  };

  const handleDeleteConfirmed = async () => {
    if (!deleteConfirmRecord) return;
    const id = deleteConfirmRecord.id;
    const updated = records.filter(r => r.id !== id);
    setRecords(updated);
    await offlineStorage.deleteGeneratorFacpRecord(id);
    onLogAudit(
      'GENERATOR_FACP_INSPECTION_DELETED',
      'حذف سجل فحص مولدات / إنذار من السجل الرسمي',
      `تم حذف سجل الفحص رقم (${id}) للمعدة (${deleteConfirmRecord.targetEquipment}) نهائياً من السجل.`
    );
    setDeleteConfirmRecord(null);
  };

  const handlePrint = () => {
    const tableRows = filtered.map((r, idx) => {
      const typeAr = 
        r.inspectionType === 'generator_weekly_no_load' ? 'فحص أسبوعي بدون حمل (10m)' :
        r.inspectionType === 'generator_monthly_with_load' ? 'فحص شهري بحمل (30m)' : 'جاهزية لوحة FACP';
      
      const statusBadge = r.status === 'pass' 
        ? '<span class="badge-success">مطابق وسليم ✔</span>' 
        : r.status === 'needs_attention' 
          ? '<span class="badge-warning">ملاحظات فنية ⚠</span>' 
          : '<span class="badge-danger">غير مطابق ✖</span>';

      return `
        <tr>
          <td style="font-weight:bold;">${idx + 1}</td>
          <td>${r.inspectionDate}</td>
          <td><strong>${typeAr}</strong></td>
          <td>${r.targetEquipment === 'generator_1' ? 'المولد الرئيسي #1' : r.targetEquipment === 'generator_2' ? 'المولد الاحتياطي #2' : 'لوحة الإنذار FACP'}</td>
          <td>${r.inspectionType.includes('generator') ? `${r.fuelLevelPercentage}%` : '-'}</td>
          <td>${r.inspectionType.includes('generator') ? `${r.batteryVoltage}V` : '-'}</td>
          <td>${r.atsAutomaticTransferOk ? 'سليم ✔' : 'غير سليم'}</td>
          <td>${r.facpStatus === 'normal' ? 'Normal' : r.facpStatus}</td>
          <td>${r.inspectorName}</td>
          <td>${statusBadge}</td>
          <td>${r.notes || '-'}</td>
        </tr>
      `;
    }).join('');

    const bodyHtml = `
      <div class="summary-grid">
        <div class="summary-card"><div class="val">${records.length}</div><div class="lbl">إجمالي الفحوصات المسجلة</div></div>
        <div class="summary-card"><div class="val" style="color:#047857;">${records.filter(r => r.status === 'pass').length}</div><div class="lbl">فحوصات مطابقة 100%</div></div>
        <div class="summary-card"><div class="val" style="color:#b45309;">${records.filter(r => r.status !== 'pass').length}</div><div class="lbl">سجلات تتطلب متابعة فنية</div></div>
      </div>
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>تاريخ الفحص</th>
            <th>نوع الفحص التشغيلي</th>
            <th>المعدة المستهدفة</th>
            <th>مستوى الديزل</th>
            <th>فولتية البطاريات</th>
            <th>مفتاح التحويل ATS</th>
            <th>حالة FACP</th>
            <th>المهندس الفاحص</th>
            <th>النتيجة</th>
            <th>ملاحظات الفحص</th>
          </tr>
        </thead>
        <tbody>
          ${tableRows || '<tr><td colspan="11" style="text-align:center; padding:12px;">لا توجد سجلات مطابقة</td></tr>'}
        </tbody>
      </table>
    `;

    executeSmartPrint(bodyHtml, {
      title: 'سجل الفحص التشغيلي للمولدات الكهربائية ولوحة إنذار الحريق FACP',
      subtitle: 'مستشفى آزال النموذجي • إدارة السلامة وإدارة المرافق FMS • قسم الصيانة والتشغيل',
      refNumber: 'AZAL-GEN-FACP-LOG-2026'
    });
  };

  const filtered = records.filter(r => {
    const matchType = typeFilter === 'all' || r.inspectionType === typeFilter;
    const matchSearch = r.inspectorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        r.targetEquipment.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        (r.notes && r.notes.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchType && matchSearch;
  });

  return (
    <div id="generator-facp-inspection-view" className="space-y-4 text-right">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-amber-950/70 border border-slate-800 rounded-3xl p-5 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-amber-950 border border-amber-800 text-amber-400">
            <Zap className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-slate-100">
                سجل فحص المولدات ولوحة إنذار الحريق (Generator & FACP Readiness)
              </h2>
              <span className="text-[10px] bg-amber-950 text-amber-300 border border-amber-800 font-bold px-2 py-0.5 rounded-lg">
                معايير سباهي FMS.6 & FMS.7
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              جدولة واختبارات التشغيل الإلزامية: 10 دقائق أسبوعياً بدون حمل / 30 دقيقة شهرياً بحمل كامل، وفحص لوحة إنذار الحريق المركزية.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleOpenAdd}
            className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs shadow-md flex items-center gap-2 transition"
          >
            <Plus className="w-4 h-4" />
            <span>تسجيل فحص تشغيل دوري</span>
          </button>

          <button
            type="button"
            onClick={handlePrint}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold flex items-center gap-1.5 transition"
          >
            <Printer className="w-4 h-4" />
            <span>طباعة السجل (Print / PDF)</span>
          </button>
        </div>
      </div>

      {/* 3 Overview Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-slate-900 border border-amber-900/40 rounded-2xl p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400">فحص أسبوعي بدون حمل (10m)</span>
            <Clock className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-black text-amber-400 mt-1">
            {records.filter(r => r.inspectionType === 'generator_weekly_no_load').length}
          </div>
          <div className="text-[10px] text-slate-400 mt-1">فحوصات مجدولة أسبوعياً بنجاح</div>
        </div>

        <div className="bg-slate-900 border border-teal-900/40 rounded-2xl p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400">فحص شهري بحمل كامل (30m)</span>
            <Gauge className="w-4 h-4 text-teal-400" />
          </div>
          <div className="text-2xl font-black text-teal-400 mt-1">
            {records.filter(r => r.inspectionType === 'generator_monthly_with_load').length}
          </div>
          <div className="text-[10px] text-slate-400 mt-1">اختبارات ATS ونقل الحمل الكامل</div>
        </div>

        <div className="bg-slate-900 border border-rose-900/40 rounded-2xl p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400">جاهزية لوحة إنذار الحريق FACP</span>
            <Bell className="w-4 h-4 text-rose-400" />
          </div>
          <div className="text-2xl font-black text-slate-100 mt-1">
            {records.filter(r => r.facpStatus === 'normal').length} / {records.length || 1}
          </div>
          <div className="text-[10px] text-emerald-400 mt-1">حالة اللوحة: طبيعية (Normal)</div>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="bg-slate-900/80 border border-slate-800 p-3 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex-1 min-w-[200px] relative">
          <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="بحث بالمعدة أو اسم المفتش..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-9 pl-3 py-2 text-slate-200"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200"
          >
            <option value="all">كافة أنواع الفحوصات</option>
            <option value="generator_weekly_no_load">10 دقائق أسبوعياً بدون حمل (No-Load)</option>
            <option value="generator_monthly_with_load">30 دقيقة شهرياً بحمل (With-Load)</option>
            <option value="facp_readiness_audit">تدقيق لوحة إنذار الحريق (FACP)</option>
          </select>
        </div>
      </div>

      {/* Table of Records */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-950 border-b border-slate-800 text-slate-400 font-bold">
              <tr>
                <th className="p-3.5">نوع الفحص والمعدة</th>
                <th className="p-3.5">التاريخ والمدة</th>
                <th className="p-3.5 text-center">الوقود %</th>
                <th className="p-3.5 text-center">فولتية البطارية</th>
                <th className="p-3.5 text-center">مفتاح ATS</th>
                <th className="p-3.5 text-center">الضغط والحرارة</th>
                <th className="p-3.5 text-center">حالة لوحة FACP</th>
                <th className="p-3.5">المفتش والملاحظات</th>
                <th className="p-3.5 text-center">النتيجة</th>
                <th className="p-3.5 text-center">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={10} className="p-8 text-center text-slate-400">
                    لا توجد سجلات فحص تطابق معايير البحث
                  </td>
                </tr>
              ) : (
                filtered.map((r) => {
                  const typeLabel = 
                    r.inspectionType === 'generator_weekly_no_load' ? '10 دقائق أسبوعياً (بدون حمل)' :
                    r.inspectionType === 'generator_monthly_with_load' ? '30 دقيقة شهرياً (بحمل)' : 'تدقيق جاهزية FACP';
                  const equipLabel = 
                    r.targetEquipment === 'generator_1' ? 'المولد الرئيسي #1' :
                    r.targetEquipment === 'generator_2' ? 'المولد الاحتياطي #2' : 'لوحة FACP الرئيسية';

                  return (
                    <tr key={r.id} className="hover:bg-slate-800/30 transition">
                      <td className="p-3.5">
                        <div className="font-bold text-slate-100">{equipLabel}</div>
                        <div className="text-[11px] text-amber-400 mt-0.5">{typeLabel}</div>
                      </td>
                      <td className="p-3.5 text-slate-300 font-mono">
                        <div>{r.inspectionDate}</div>
                        <div className="text-[10px] text-slate-400">{r.testDurationMinutes} دقيقة</div>
                      </td>
                      <td className="p-3.5 text-center">
                        {r.fuelLevelPercentage > 0 ? (
                          <span className={`font-bold font-mono text-xs ${
                            r.fuelLevelPercentage >= 70 ? 'text-emerald-400' : r.fuelLevelPercentage >= 40 ? 'text-amber-400' : 'text-rose-400'
                          }`}>
                            {r.fuelLevelPercentage}%
                          </span>
                        ) : (
                          <span className="text-slate-500">--</span>
                        )}
                      </td>
                      <td className="p-3.5 text-center font-mono text-slate-200">
                        {r.batteryVoltage} V
                      </td>
                      <td className="p-3.5 text-center">
                        {r.atsAutomaticTransferOk ? (
                          <span className="text-emerald-400 font-bold">✓ سليم</span>
                        ) : (
                          <span className="text-rose-400 font-bold">✕ عطل</span>
                        )}
                      </td>
                      <td className="p-3.5 text-center">
                        {r.oilPressureAndCoolantTempOk ? (
                          <span className="text-emerald-400 font-bold">✓ طبيعي</span>
                        ) : (
                          <span className="text-amber-400 font-bold">✕ غير طبيعي</span>
                        )}
                      </td>
                      <td className="p-3.5 text-center">
                        <span className={`px-2 py-0.5 rounded-lg font-bold text-[10px] ${
                          r.facpStatus === 'normal' 
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' 
                            : r.facpStatus === 'trouble' 
                            ? 'bg-amber-950 text-amber-300 border border-amber-800' 
                            : 'bg-rose-950 text-rose-300 border border-rose-800'
                        }`}>
                          {r.facpStatus === 'normal' ? 'عادي (Normal)' : r.facpStatus === 'trouble' ? 'عطل (Trouble)' : 'إنذار (Alarm)'}
                        </span>
                      </td>
                      <td className="p-3.5">
                        <div className="text-slate-200 font-semibold">{r.inspectorName}</div>
                        <div className="text-[11px] text-slate-400 line-clamp-1">{r.notes}</div>
                      </td>
                      <td className="p-3.5 text-center">
                        <span className={`px-2 py-0.5 rounded-lg font-bold text-[10px] ${
                          r.status === 'pass' 
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' 
                            : 'bg-rose-950 text-rose-300 border border-rose-800'
                        }`}>
                          {r.status === 'pass' ? 'معتمد ومطابق' : 'بحاجة لمتابعة'}
                        </span>
                      </td>
                      <td className="p-3.5 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleOpenEdit(r)}
                            className="p-1.5 rounded-lg bg-slate-800 text-teal-400 hover:bg-teal-950 hover:text-teal-300 transition border border-slate-700/60"
                            title="تعديل هذا الفحص"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setDeleteConfirmRecord(r)}
                            className="p-1.5 rounded-lg bg-slate-800 text-rose-400 hover:bg-rose-950 hover:text-rose-300 transition border border-slate-700/60"
                            title="حذف هذا البند من السجل الرسمي"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* New Record Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-amber-600/60 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
            <div className="bg-slate-950 px-5 py-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-amber-950 text-amber-400 border border-amber-800">
                  <Zap className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-100">
                    {editingRecord ? 'تعديل سجل فحص المولد أو لوحة الإنذار (FMS)' : 'تسجيل فحص تشغيلي للمولد أو لوحة الإنذار (FMS)'}
                  </h3>
                  <p className="text-[11px] text-slate-400">مستشفى آزال النموذجي • السلامة الهندسية والمرافق</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setShowAddModal(false);
                  setEditingRecord(null);
                }}
                className="p-1 rounded-lg bg-slate-800 text-slate-400 hover:text-slate-100"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateRecord} className="p-5 space-y-4 overflow-y-auto text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">نوع الفحص المجدول:</label>
                  <select
                    value={inspectionType}
                    onChange={(e) => {
                      const val = e.target.value as any;
                      setInspectionType(val);
                      if (val === 'generator_weekly_no_load') {
                        setTestDurationMinutes(10);
                        setTargetEquipment('generator_1');
                      } else if (val === 'generator_monthly_with_load') {
                        setTestDurationMinutes(30);
                        setTargetEquipment('generator_1');
                      } else {
                        setTestDurationMinutes(15);
                        setTargetEquipment('facp_main_panel');
                      }
                    }}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                  >
                    <option value="generator_weekly_no_load">10 دقائق أسبوعياً بدون حمل (Weekly No-Load)</option>
                    <option value="generator_monthly_with_load">30 دقيقة شهرياً بحمل (Monthly With-Load)</option>
                    <option value="facp_readiness_audit">تدقيق لوحة إنذار الحريق المركزية (FACP Readiness)</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">المعدة المستهدفة:</label>
                  <select
                    value={targetEquipment}
                    onChange={(e) => setTargetEquipment(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                  >
                    <option value="generator_1">مولد الطوارئ الرئيسي #1 (Caterpillar 500kVA)</option>
                    <option value="generator_2">مولد الطوارئ الاحتياطي #2 (Cummins 350kVA)</option>
                    <option value="facp_main_panel">لوحة إنذار الحريق المركزية FACP (Simplex Addressable)</option>
                  </select>
                </div>
              </div>

              {/* Generator Specific Controls */}
              {inspectionType.includes('generator') && (
                <div className="bg-slate-950/70 border border-amber-900/60 rounded-2xl p-3.5 space-y-3">
                  <div className="text-amber-300 font-bold text-xs flex items-center gap-1.5">
                    <Gauge className="w-4 h-4" />
                    <span>مؤشرات المولد والتشغيل الفني:</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-slate-300 block mb-1">مستوى الديزل في الخزان (%):</label>
                      <input
                        type="number"
                        min="0"
                        max="100"
                        value={fuelLevelPercentage}
                        onChange={(e) => setFuelLevelPercentage(Number(e.target.value))}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100 font-bold"
                      />
                    </div>
                    <div>
                      <label className="text-slate-300 block mb-1">فولتية بطاريات بدء الحركة (V):</label>
                      <input
                        type="number"
                        step="0.1"
                        value={batteryVoltage}
                        onChange={(e) => setBatteryVoltage(Number(e.target.value))}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100 font-bold"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="flex items-center justify-between p-2 rounded-xl bg-slate-900 border border-slate-800 cursor-pointer">
                      <span className="text-slate-200">سلامة مفتاح التحويل الأوتوماتيكي (ATS Transfer):</span>
                      <input
                        type="checkbox"
                        checked={atsAutomaticTransferOk}
                        onChange={(e) => setAtsAutomaticTransferOk(e.target.checked)}
                        className="w-4 h-4 accent-amber-500 rounded"
                      />
                    </label>

                    <label className="flex items-center justify-between p-2 rounded-xl bg-slate-900 border border-slate-800 cursor-pointer">
                      <span className="text-slate-200">ضغط الزيت وحرارة سائل التبريد ضمن الحدود الطبيعية:</span>
                      <input
                        type="checkbox"
                        checked={oilPressureAndCoolantTempOk}
                        onChange={(e) => setOilPressureAndCoolantTempOk(e.target.checked)}
                        className="w-4 h-4 accent-amber-500 rounded"
                      />
                    </label>
                  </div>
                </div>
              )}

              {/* FACP Specific Controls */}
              {inspectionType === 'facp_readiness_audit' && (
                <div className="bg-slate-950/70 border border-rose-900/60 rounded-2xl p-3.5 space-y-3">
                  <div className="text-rose-300 font-bold text-xs flex items-center gap-1.5">
                    <Bell className="w-4 h-4" />
                    <span>مؤشرات لوحة إنذار الحريق FACP:</span>
                  </div>

                  <div>
                    <label className="text-slate-300 block mb-1">حالة اللوحة الحالية:</label>
                    <select
                      value={facpStatus}
                      onChange={(e) => setFacpStatus(e.target.value as any)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100 font-bold"
                    >
                      <option value="normal">طبيعية وجاهزة (Normal - All LEDs Green)</option>
                      <option value="trouble">يوجد عطل في أحد المسارات (Trouble / Fault Signal)</option>
                      <option value="alarm">إنذار حريق مفعل (Fire Alarm Triggered)</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="flex items-center justify-between p-2 rounded-xl bg-slate-900 border border-slate-800 cursor-pointer">
                      <span className="text-slate-200">فحص عينة من كواشف الدخان والحرارة وأزرار الكسر (MCP):</span>
                      <input
                        type="checkbox"
                        checked={facpSmokeDetectorsTested}
                        onChange={(e) => setFacpSmokeDetectorsTested(e.target.checked)}
                        className="w-4 h-4 accent-rose-500 rounded"
                      />
                    </label>

                    <label className="flex items-center justify-between p-2 rounded-xl bg-slate-900 border border-slate-800 cursor-pointer">
                      <span className="text-slate-200">جاهزية الأجراس والفلاشات التحذيرية المسموعة والمرئية:</span>
                      <input
                        type="checkbox"
                        checked={facpAudioVisualAlertsOk}
                        onChange={(e) => setFacpAudioVisualAlertsOk(e.target.checked)}
                        className="w-4 h-4 accent-rose-500 rounded"
                      />
                    </label>
                  </div>
                </div>
              )}

              <div>
                <label className="text-slate-300 block mb-1 font-semibold">ملاحظات الفحص والبيان الفني:</label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="سجل أي قراءات أو أعمال صيانة تمت..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddModal(false);
                    setEditingRecord(null);
                  }}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 text-xs"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold text-xs flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{editingRecord ? 'اعتماد وحفظ التعديلات' : 'اعتماد وحفظ الفحص الفني'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmRecord && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-rose-800/80 rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl text-right animate-scale-in">
            <div className="flex items-center gap-3 border-b border-rose-900/40 pb-3">
              <div className="p-2.5 rounded-xl bg-rose-950/80 border border-rose-800 text-rose-400">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-black text-rose-300">تأكيد حذف فحص المولدات / لوحة الإنذار</h3>
                <p className="text-[11px] text-slate-400">إدارة الأمن والسلامة وإدارة المرافق (FMS)</p>
              </div>
            </div>

            <div className="p-3 bg-rose-950/30 border border-rose-900/50 rounded-xl space-y-2 text-xs">
              <p className="text-slate-200 font-bold">
                هل أنت متأكد من حذف هذا البند من السجل الرسمي؟
              </p>
              <div className="text-[11px] text-slate-300 space-y-1 bg-slate-950/60 p-2.5 rounded-lg border border-slate-800">
                <div><strong className="text-slate-400">المعدة المستهدفة:</strong> <span className="text-amber-400 font-bold">{deleteConfirmRecord.targetEquipment === 'generator_1' ? 'المولد الرئيسي #1' : deleteConfirmRecord.targetEquipment === 'generator_2' ? 'المولد الاحتياطي #2' : 'لوحة الإنذار FACP'}</span></div>
                <div><strong className="text-slate-400">تاريخ الفحص:</strong> <span className="font-mono text-slate-200">{deleteConfirmRecord.inspectionDate}</span></div>
                <div><strong className="text-slate-400">القائم بالفحص:</strong> <span>{deleteConfirmRecord.inspectorName}</span></div>
              </div>
              <p className="text-[11px] text-rose-400 font-medium">
                ⚠️ تنبيه: سيتم حذف هذا السجل نهائياً وتحديث إجمالي العدادات ومؤشرات الامتثال فوراً.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setDeleteConfirmRecord(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold transition"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={handleDeleteConfirmed}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-lg shadow-rose-950/50"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>تأكيد الحذف النهائي</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
