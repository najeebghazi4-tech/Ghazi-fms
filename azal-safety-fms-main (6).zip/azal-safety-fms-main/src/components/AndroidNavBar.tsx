import React from 'react';
import { 
  ShieldCheck, 
  AlertOctagon, 
  Key, 
  Users, 
  FileText, 
  ShieldAlert, 
  BellRing,
  QrCode,
  ClipboardCheck,
  Award,
  Wrench
} from 'lucide-react';

export type NavTab = 'safety' | 'ppm' | 'department_audit' | 'cbahi_registers' | 'incidents' | 'sec_handover' | 'audit';

interface AndroidNavBarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  onOpenEmergencyModal: () => void;
  activeAlertsCount: number;
  openIncidentsCount: number;
  overdueViolationsCount?: number;
}

export const AndroidNavBar: React.FC<AndroidNavBarProps> = ({
  currentTab,
  onSelectTab,
  onOpenEmergencyModal,
  activeAlertsCount,
  openIncidentsCount,
  overdueViolationsCount = 0,
}) => {
  const triggerHaptic = () => {
    if (typeof window !== 'undefined' && window.navigator && window.navigator.vibrate) {
      try {
        window.navigator.vibrate(25);
      } catch (e) {
        // ignore
      }
    }
  };

  const handleTabClick = (tab: NavTab) => {
    triggerHaptic();
    onSelectTab(tab);
  };

  return (
    <nav
      id="android-bottom-nav"
      className="fixed bottom-0 left-0 right-0 z-30 bg-slate-900 border-t border-slate-800 p-2 flex justify-center items-center shadow-lg"
    >
      <button
        type="button"
        onClick={() => {
          if (typeof window !== 'undefined') {
            window.location.href = '/';
          }
        }}
        className="flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 px-6 py-2 rounded-xl text-sm font-bold border border-slate-700 transition-all active:scale-95 shadow"
      >
        <span>↩️</span>
        <span>رجوع إلى صفحة البلاغات</span>
      </button>
    </nav>
  );
};
