import React, { useState, useEffect, useMemo } from 'react';
import {
  Calendar,
  BarChart3,
  CalendarDays,
  Clock,
  Plus,
  Printer,
  FileDown,
  CheckCircle2,
  Clock3,
  AlertTriangle,
  Flame,
  Wrench,
  ShieldCheck,
  Building2,
  Users,
  Activity,
  Zap,
  Eye,
  Trash2,
  ChevronRight,
  TrendingUp,
  Target,
  Sparkles,
  ClipboardList,
  Filter,
  Check,
  X,
  FileSpreadsheet,
  Layers,
  ArrowUpRight,
  Droplets,
  AlertOctagon,
  RefreshCw,
} from 'lucide-react';
import { 
  PlanFrequency, 
  PlanQuarter, 
  FmsOperationalPlan, 
  FmsPlanTask, 
  PlanTaskStatus,
  StaffUser 
} from '../types';
import { supabase } from '../services/supabaseClient';
import { DEFAULT_FMS_OPERATIONAL_PLANS } from '../data/azalFmsPlansData';
import { executeSmartPrint } from '../utils/printUtils';
import { AzalLogo } from './AzalLogo';

interface FmsOperationalPlansViewProps {
  currentUser?: StaffUser;
  isReadOnlyMode?: boolean;
}

export const FmsOperationalPlansView: React.FC<FmsOperationalPlansViewProps> = ({
  currentUser,
  isReadOnlyMode = false,
}) => {
  // 1. Segmented frequency filter state
  const [selectedFrequency, setSelectedFrequency] = useState<PlanFrequency>('annual');

  // Secondary sub-filters
  const [selectedQuarter, setSelectedQuarter] = useState<PlanQuarter>('Q3');
  const [selectedMonth, setSelectedMonth] = useState<number>(9); // September 2026
  const [selectedWeek, setSelectedWeek] = useState<number>(3); // Week 3

  // Plans data state
  const [plans, setPlans] = useState<FmsOperationalPlan[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [activePlanId, setActivePlanId] = useState<string | null>(null);

  // Modal state
  const [showCreateModal, setShowCreateModal] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Print feedback state
  const [isPrinting, setIsPrinting] = useState<boolean>(false);

  // Form state for creating new plan
  const [newPlan, setNewPlan] = useState<{
    frequency: PlanFrequency;
    year: number;
    quarter: PlanQuarter;
    month: number;
    weekNumber: number;
    title: string;
    description: string;
    strategicObjective: string;
    standardCategory: string;
    startDate: string;
    endDate: string;
    targetKpi: string;
    tasks: {
      title: string;
      category: string;
      standardRef: string;
      assignedTo: string;
      assignedDept: string;
      dueDate: string;
      priority: 'low' | 'medium' | 'high' | 'critical';
      kpiIndicator: string;
    }[];
  }>({
    frequency: 'monthly',
    year: 2026,
    quarter: 'Q3',
    month: 9,
    weekNumber: 3,
    title: '',
    description: '',
    strategicObjective: '',
    standardCategory: 'CBAHI FMS.1',
    startDate: '2026-09-01',
    endDate: '2026-09-30',
    targetKpi: 'نسبة إنجاز ≥ 95%',
    tasks: [
      {
        title: '',
        category: 'صيانة وقائية',
        standardRef: 'CBAHI FMS',
        assignedTo: 'م. نجيب غازي',
        assignedDept: 'الأمن والسلامة',
        dueDate: '2026-09-30',
        priority: 'high',
        kpiIndicator: 'إتمام الفحص والتوثيق',
      },
    ],
  });

  // Load plans from Supabase / LocalStorage
  const loadPlans = async () => {
    setIsLoading(true);
    try {
      const res = await supabase.from('fms_operational_plans').select('*');
      if (res.data && res.data.length > 0) {
        setPlans(res.data);
      } else {
        setPlans(DEFAULT_FMS_OPERATIONAL_PLANS);
      }
    } catch (e) {
      console.warn('[FMS Plans] Failed to load, using default data:', e);
      setPlans(DEFAULT_FMS_OPERATIONAL_PLANS);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadPlans();
  }, []);

  // Filter plans according to selected frequency and sub-filter
  const filteredPlans = useMemo(() => {
    return plans.filter((plan) => {
      if (plan.frequency !== selectedFrequency) return false;
      if (selectedFrequency === 'quarterly' && plan.quarter !== selectedQuarter) return false;
      if (selectedFrequency === 'monthly' && plan.month !== selectedMonth) return false;
      if (selectedFrequency === 'weekly' && plan.weekNumber !== selectedWeek) return false;
      return true;
    });
  }, [plans, selectedFrequency, selectedQuarter, selectedMonth, selectedWeek]);

  // Active selected plan
  const currentPlan = useMemo(() => {
    if (activePlanId) {
      const found = filteredPlans.find((p) => p.id === activePlanId);
      if (found) return found;
    }
    return filteredPlans[0] || null;
  }, [filteredPlans, activePlanId]);

  // Overall compliance & completion statistics for the active frequency
  const stats = useMemo(() => {
    const list = filteredPlans;
    if (list.length === 0) return { totalTasks: 0, completedTasks: 0, inProgressTasks: 0, pendingTasks: 0, rate: 0 };
    let total = 0;
    let completed = 0;
    let inProgress = 0;
    let pending = 0;

    list.forEach((p) => {
      (p.tasks || []).forEach((t) => {
        total++;
        if (t.status === 'completed') completed++;
        else if (t.status === 'in_progress') inProgress++;
        else pending++;
      });
    });

    const rate = total > 0 ? Math.round((completed / total) * 100) : 0;
    return { totalTasks: total, completedTasks: completed, inProgressTasks: inProgress, pendingTasks: pending, rate };
  }, [filteredPlans]);

  // Toggle task status
  const handleToggleTaskStatus = async (planId: string, taskId: string) => {
    if (isReadOnlyMode) return;
    const plan = plans.find((p) => p.id === planId);
    if (!plan) return;

    const updatedTasks: FmsPlanTask[] = (plan.tasks || []).map((t) => {
      if (t.id === taskId) {
        const nextStatus: PlanTaskStatus = 
          t.status === 'pending' ? 'in_progress' : 
          t.status === 'in_progress' ? 'completed' : 'pending';
        const completionPercentage = nextStatus === 'completed' ? 100 : nextStatus === 'in_progress' ? 50 : 0;
        return { ...t, status: nextStatus, completionPercentage };
      }
      return t;
    });

    const completedCount = updatedTasks.filter((t) => t.status === 'completed').length;
    const overallProgress = updatedTasks.length > 0 ? Math.round((completedCount / updatedTasks.length) * 100) : 0;

    const updatedPlan: FmsOperationalPlan = {
      ...plan,
      tasks: updatedTasks,
      overallProgress,
      updated_at: new Date().toISOString(),
    };

    // Update local state immediately
    setPlans((prev) => prev.map((p) => (p.id === planId ? updatedPlan : p)));

    // Persist via Supabase/Local proxy
    try {
      await supabase.from('fms_operational_plans').update(updatedPlan).eq('id', planId);
    } catch (err) {
      console.warn('[FMS Plans] Failed to update task status:', err);
    }
  };

  // Add task field to new plan form
  const handleAddTaskField = () => {
    setNewPlan((prev) => ({
      ...prev,
      tasks: [
        ...prev.tasks,
        {
          title: '',
          category: 'صيانة وقائية',
          standardRef: 'CBAHI FMS',
          assignedTo: 'عارف الصلوي',
          assignedDept: 'الصيانة والخدمات',
          dueDate: prev.endDate,
          priority: 'medium',
          kpiIndicator: 'فحص دوري',
        },
      ],
    }));
  };

  // Remove task field from new plan form
  const handleRemoveTaskField = (index: number) => {
    setNewPlan((prev) => ({
      ...prev,
      tasks: prev.tasks.filter((_, i) => i !== index),
    }));
  };

  // Submit new plan
  const handleCreatePlan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPlan.title.trim()) return;

    setIsSubmitting(true);
    try {
      const planId = `fms-plan-${newPlan.frequency}-${Date.now()}`;
      const builtTasks: FmsPlanTask[] = newPlan.tasks
        .filter((t) => t.title.trim().length > 0)
        .map((t, idx) => ({
          id: `task-${Date.now()}-${idx}`,
          title: t.title,
          category: t.category,
          standardRef: t.standardRef || 'CBAHI FMS',
          assignedTo: t.assignedTo || 'م. نجيب غازي',
          assignedDept: t.assignedDept || 'الأمن والسلامة',
          dueDate: t.dueDate || newPlan.endDate,
          status: 'pending',
          priority: t.priority,
          kpiIndicator: t.kpiIndicator || 'إتمام المهمة وفق المعايير',
          completionPercentage: 0,
        }));

      const planRecord: FmsOperationalPlan = {
        id: planId,
        frequency: newPlan.frequency,
        year: newPlan.year,
        quarter: newPlan.frequency === 'quarterly' ? newPlan.quarter : undefined,
        month: newPlan.frequency === 'monthly' ? newPlan.month : undefined,
        monthNameAr: newPlan.frequency === 'monthly' ? `شهر ${newPlan.month} - ${newPlan.year}م` : undefined,
        weekNumber: newPlan.frequency === 'weekly' ? newPlan.weekNumber : undefined,
        title: newPlan.title,
        description: newPlan.description,
        strategicObjective: newPlan.strategicObjective,
        standardCategory: newPlan.standardCategory,
        startDate: newPlan.startDate,
        endDate: newPlan.endDate,
        targetKpi: newPlan.targetKpi,
        achievedKpi: 'مجدولة للبدء',
        status: 'active',
        preparedBy: currentUser?.name || 'م. نجيب غازي (رئيس السلامة)',
        reviewedBy: 'عارف الصلوي (ممثل الصيانة)',
        approvedBy: 'د. نبيل عصار (منسق الجودة) / المدير العام',
        tasks: builtTasks,
        overallProgress: 0,
        created_at: new Date().toISOString(),
      };

      await supabase.from('fms_operational_plans').insert([planRecord]);

      setPlans((prev) => [planRecord, ...prev]);
      setSelectedFrequency(newPlan.frequency);
      if (newPlan.frequency === 'quarterly') setSelectedQuarter(newPlan.quarter);
      if (newPlan.frequency === 'monthly') setSelectedMonth(newPlan.month);
      if (newPlan.frequency === 'weekly') setSelectedWeek(newPlan.weekNumber);

      setShowCreateModal(false);
      // Reset form
      setNewPlan({
        frequency: 'monthly',
        year: 2026,
        quarter: 'Q3',
        month: 9,
        weekNumber: 3,
        title: '',
        description: '',
        strategicObjective: '',
        standardCategory: 'CBAHI FMS.1',
        startDate: '2026-09-01',
        endDate: '2026-09-30',
        targetKpi: 'نسبة إنجاز ≥ 95%',
        tasks: [
          {
            title: '',
            category: 'صيانة وقائية',
            standardRef: 'CBAHI FMS',
            assignedTo: 'م. نجيب غازي',
            assignedDept: 'الأمن والسلامة',
            dueDate: '2026-09-30',
            priority: 'high',
            kpiIndicator: 'إتمام الفحص والتوثيق',
          },
        ],
      });
    } catch (err) {
      console.error('[FMS Plans] Failed to create new plan:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Official PDF & Print Export
  const handlePrintPlan = (plan: FmsOperationalPlan) => {
    setIsPrinting(true);
    const frequencyLabel =
      plan.frequency === 'annual'
        ? `خطة سنوية لعام ${plan.year}م`
        : plan.frequency === 'quarterly'
        ? `خطة فصلية (${plan.quarter}) لعام ${plan.year}م`
        : plan.frequency === 'monthly'
        ? `خطة شهرية (${plan.monthNameAr || `شهر ${plan.month}`})`
        : `خطة أسبوعية (الأسبوع ${plan.weekNumber})`;

    const contentHtml = `
      <div style="font-family: inherit; direction: rtl; text-align: right; color: #0f172a;">
        <div style="background-color: #f0fdfa; border: 1.5px solid #0f766e; border-radius: 8px; padding: 14px 18px; margin-bottom: 18px;">
          <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px dashed #99f6e4; padding-bottom: 8px; margin-bottom: 8px;">
            <div>
              <span style="font-size: 11px; background-color: #0f766e; color: #ffffff; padding: 2px 8px; border-radius: 4px; font-weight: bold;">
                ${frequencyLabel}
              </span>
              <span style="font-size: 11px; color: #0f766e; margin-right: 8px; font-weight: bold;">
                المعيار: ${plan.standardCategory}
              </span>
            </div>
            <div style="font-size: 11px; font-weight: bold; color: #334155;">
              نسبة الإنجاز الإجمالية: <span style="font-size: 14px; color: #0f766e;">${plan.overallProgress}%</span>
            </div>
          </div>
          <h2 style="font-size: 16px; font-weight: 900; color: #042f2e; margin: 4px 0 8px 0;">
            ${plan.title}
          </h2>
          <p style="font-size: 12px; color: #334155; margin: 0 0 6px 0; line-height: 1.6;">
            <strong>الوصف والملخص التنفيذي:</strong> ${plan.description}
          </p>
          ${
            plan.strategicObjective
              ? `<p style="font-size: 11.5px; color: #0f766e; margin: 0; line-height: 1.5;">
                  <strong>الهدف الاستراتيجي:</strong> ${plan.strategicObjective}
                </p>`
              : ''
          }
          <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-top: 12px; padding-top: 8px; border-top: 1px dashed #99f6e4; font-size: 11px; color: #475569;">
            <div><strong>فترة الخطة:</strong> من ${plan.startDate} إلى ${plan.endDate}</div>
            <div><strong>المؤشر المستهدف:</strong> ${plan.targetKpi}</div>
            <div><strong>المؤشر المحقق:</strong> ${plan.achievedKpi || 'قيد المتابعة'}</div>
          </div>
        </div>

        <h3 style="font-size: 13px; font-weight: bold; color: #0f172a; margin-bottom: 8px; border-bottom: 2px solid #0f766e; padding-bottom: 4px;">
          جدول المهام التشغيلية والبرامج التنفيذية (${plan.tasks?.length || 0} مهمة معتمدة)
        </h3>

        <table style="width: 100%; border-collapse: collapse; font-size: 11px; margin-bottom: 20px;">
          <thead>
            <tr style="background-color: #0f766e; color: #ffffff;">
              <th style="border: 1px solid #0f766e; padding: 6px 8px; text-align: center; width: 35px;">#</th>
              <th style="border: 1px solid #0f766e; padding: 6px 8px; text-align: right;">المهمة والبرنامج التنفيذي</th>
              <th style="border: 1px solid #0f766e; padding: 6px 8px; text-align: center; width: 90px;">التصنيف</th>
              <th style="border: 1px solid #0f766e; padding: 6px 8px; text-align: center; width: 110px;">المسؤول / القسم</th>
              <th style="border: 1px solid #0f766e; padding: 6px 8px; text-align: center; width: 75px;">الاستحقاق</th>
              <th style="border: 1px solid #0f766e; padding: 6px 8px; text-align: center; width: 75px;">الأولوية</th>
              <th style="border: 1px solid #0f766e; padding: 6px 8px; text-align: center; width: 80px;">الحالة</th>
            </tr>
          </thead>
          <tbody>
            ${(plan.tasks || [])
              .map(
                (task, idx) => `
              <tr style="background-color: ${idx % 2 === 0 ? '#ffffff' : '#f8fafc'};">
                <td style="border: 1px solid #cbd5e1; padding: 6px 8px; text-align: center; font-weight: bold;">${idx + 1}</td>
                <td style="border: 1px solid #cbd5e1; padding: 6px 8px;">
                  <div style="font-weight: bold; color: #0f172a;">${task.title}</div>
                  ${task.kpiIndicator ? `<div style="font-size: 9.5px; color: #64748b; margin-top: 2px;">مؤشر القياس: ${task.kpiIndicator}</div>` : ''}
                </td>
                <td style="border: 1px solid #cbd5e1; padding: 6px 8px; text-align: center; font-size: 10px; color: #334155;">${task.category}</td>
                <td style="border: 1px solid #cbd5e1; padding: 6px 8px; text-align: center; font-size: 10px; color: #334155;">
                  <div>${task.assignedTo}</div>
                  ${task.assignedDept ? `<div style="font-size: 9px; color: #64748b;">(${task.assignedDept})</div>` : ''}
                </td>
                <td style="border: 1px solid #cbd5e1; padding: 6px 8px; text-align: center; font-size: 10px;">${task.dueDate}</td>
                <td style="border: 1px solid #cbd5e1; padding: 6px 8px; text-align: center; font-size: 10px; font-weight: bold; color: ${task.priority === 'critical' ? '#dc2626' : task.priority === 'high' ? '#d97706' : '#2563eb'};">
                  ${task.priority === 'critical' ? 'حرج جداً' : task.priority === 'high' ? 'أولوية عالية' : 'عادي'}
                </td>
                <td style="border: 1px solid #cbd5e1; padding: 6px 8px; text-align: center; font-size: 10px; font-weight: bold;">
                  <span style="color: ${task.status === 'completed' ? '#059669' : task.status === 'in_progress' ? '#d97706' : '#64748b'};">
                    ${task.status === 'completed' ? '✔ تم الإنجاز' : task.status === 'in_progress' ? '⏳ قيد التنفيذ' : '📅 مجدول'}
                  </span>
                </td>
              </tr>
            `
              )
              .join('')}
          </tbody>
        </table>

        <!-- Triple Institutional Signatures Block -->
        <div style="border-top: 2px solid #0f766e; padding-top: 14px; margin-top: 24px; display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; text-align: center; font-size: 10px;">
          <div style="border: 1px solid #cbd5e1; padding: 8px 4px; border-radius: 6px; background-color: #f8fafc;">
            <div style="font-weight: bold; color: #475569; margin-bottom: 4px;">إعداد / رئيس قسم السلامة (FMS)</div>
            <div style="font-size: 11px; font-weight: 900; color: #0f172a; margin-bottom: 6px;">${plan.preparedBy}</div>
            <div style="font-size: 9px; color: #059669; font-weight: bold;">[ مُعتمد إلكترونياً ✔ ]</div>
          </div>
          <div style="border: 1px solid #cbd5e1; padding: 8px 4px; border-radius: 6px; background-color: #f8fafc;">
            <div style="font-weight: bold; color: #475569; margin-bottom: 4px;">مراجعة / ممثل الصيانة والمرافق</div>
            <div style="font-size: 11px; font-weight: 900; color: #0f172a; margin-bottom: 6px;">${plan.reviewedBy}</div>
            <div style="font-size: 9px; color: #059669; font-weight: bold;">[ مُوقّع إلكترونياً ✔ ]</div>
          </div>
          <div style="border: 1px solid #cbd5e1; padding: 8px 4px; border-radius: 6px; background-color: #f8fafc;">
            <div style="font-weight: bold; color: #475569; margin-bottom: 4px;">منسق الجودة والاعتماد (CBAHI)</div>
            <div style="font-size: 11px; font-weight: 900; color: #0f172a; margin-bottom: 6px;">د. نبيل عصار</div>
            <div style="font-size: 9px; color: #059669; font-weight: bold;">[ مُطابق للمعايير ✔ ]</div>
          </div>
          <div style="border: 1px solid #cbd5e1; padding: 8px 4px; border-radius: 6px; background-color: #f8fafc;">
            <div style="font-weight: bold; color: #475569; margin-bottom: 4px;">اعتماد / المدير العام للمستشفى</div>
            <div style="font-size: 11px; font-weight: 900; color: #0f172a; margin-bottom: 6px;">د. محمد السراجي</div>
            <div style="font-size: 9px; color: #059669; font-weight: bold;">[ مصادق بالختم الرسمي ]</div>
          </div>
        </div>
      </div>
    `;

    executeSmartPrint(contentHtml, {
      title: `${plan.title} - ${frequencyLabel}`,
      subtitle: `خطة السلامة وإدارة المرافق FMS • مستشفى آزال النموذجي • ${plan.standardCategory}`,
      refNumber: `AZAL-FMS-PLAN-${plan.id}`,
      department: 'إدارة الأمن والسلامة وإدارة المرافق (FMS)',
      inspectorName: plan.preparedBy,
    });

    setTimeout(() => setIsPrinting(false), 1000);
  };

  return (
    <div className="space-y-4 font-sans select-none" dir="rtl">
      {/* ========================================================= */}
      {/* 1. TOP HEADER & SEGMENTED CONTROL / PILLS                 */}
      {/* ========================================================= */}
      <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-2xl shadow-xl space-y-3.5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-500/20 to-teal-800/40 border border-teal-500/40 flex items-center justify-center text-teal-400 shadow-inner">
              <CalendarDays className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white">
                  خطط السلامة وإدارة المرافق التشغيلية (CBAHI FMS)
                </h2>
                <span className="text-[10px] bg-teal-950 text-teal-300 border border-teal-700 px-2 py-0.5 rounded font-mono font-bold">
                  2026م
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                تصفية وإدارة الخطط الزمنية، مؤشرات الأداء للجان، الصيانة الوقائية، وجولات التفتيش
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto">
            {!isReadOnlyMode && (
              <button
                type="button"
                onClick={() => setShowCreateModal(true)}
                className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white text-xs font-bold shadow-lg shadow-teal-950 flex items-center gap-1.5 transition active:scale-95"
              >
                <Plus className="w-4 h-4" />
                <span>➕ إنشاء خطة تشغيلية جديدة</span>
              </button>
            )}

            {currentPlan && (
              <button
                type="button"
                onClick={() => handlePrintPlan(currentPlan)}
                disabled={isPrinting}
                className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-teal-300 text-xs font-bold flex items-center gap-1.5 transition active:scale-95 disabled:opacity-50"
                title="طباعة وتصدير الخطة كتقرير PDF رسمي معتمد"
              >
                <Printer className="w-4 h-4" />
                <span>{isPrinting ? 'جاري التجهيز...' : 'طباعة الخطة (PDF)'}</span>
              </button>
            )}
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* 4 INTERACTIVE SEGMENTED BUTTONS (PILLS)                       */}
        {/* ------------------------------------------------------------- */}
        <div className="pt-1">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 bg-slate-950/80 p-1.5 rounded-2xl border border-slate-800/90 shadow-inner">
            {/* 1. Annual Plan Button */}
            <button
              type="button"
              id="plan-freq-annual"
              onClick={() => setSelectedFrequency('annual')}
              className={`px-3 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 relative ${
                selectedFrequency === 'annual'
                  ? 'bg-gradient-to-r from-teal-600 to-teal-700 text-white shadow-lg shadow-teal-950 ring-2 ring-teal-400/60 font-black'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <Calendar className={`w-4 h-4 ${selectedFrequency === 'annual' ? 'text-white' : 'text-teal-400'}`} />
              <span>📅 خطة سنوية (Annual)</span>
              {selectedFrequency === 'annual' && (
                <span className="w-1.5 h-1.5 rounded-full bg-white absolute top-1.5 right-2" />
              )}
            </button>

            {/* 2. Quarterly Plan Button */}
            <button
              type="button"
              id="plan-freq-quarterly"
              onClick={() => setSelectedFrequency('quarterly')}
              className={`px-3 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 relative ${
                selectedFrequency === 'quarterly'
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg shadow-blue-950 ring-2 ring-blue-400/60 font-black'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <BarChart3 className={`w-4 h-4 ${selectedFrequency === 'quarterly' ? 'text-white' : 'text-blue-400'}`} />
              <span>📊 خطة فصلية (Quarterly)</span>
              {selectedFrequency === 'quarterly' && (
                <span className="w-1.5 h-1.5 rounded-full bg-white absolute top-1.5 right-2" />
              )}
            </button>

            {/* 3. Monthly Plan Button */}
            <button
              type="button"
              id="plan-freq-monthly"
              onClick={() => setSelectedFrequency('monthly')}
              className={`px-3 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 relative ${
                selectedFrequency === 'monthly'
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg shadow-emerald-950 ring-2 ring-emerald-400/60 font-black'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <CalendarDays className={`w-4 h-4 ${selectedFrequency === 'monthly' ? 'text-white' : 'text-emerald-400'}`} />
              <span>🗓️ خطة شهرية (Monthly)</span>
              {selectedFrequency === 'monthly' && (
                <span className="w-1.5 h-1.5 rounded-full bg-white absolute top-1.5 right-2" />
              )}
            </button>

            {/* 4. Weekly Plan Button */}
            <button
              type="button"
              id="plan-freq-weekly"
              onClick={() => setSelectedFrequency('weekly')}
              className={`px-3 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 relative ${
                selectedFrequency === 'weekly'
                  ? 'bg-gradient-to-r from-amber-600 to-orange-600 text-slate-950 shadow-lg shadow-amber-950 ring-2 ring-amber-400/60 font-black'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
            >
              <Clock className={`w-4 h-4 ${selectedFrequency === 'weekly' ? 'text-slate-950' : 'text-amber-400'}`} />
              <span>⏱️ خطة أسبوعية (Weekly)</span>
              {selectedFrequency === 'weekly' && (
                <span className="w-1.5 h-1.5 rounded-full bg-slate-950 absolute top-1.5 right-2" />
              )}
            </button>
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* SUB-SELECTOR BASED ON CHOSEN FREQUENCY                        */}
        {/* ------------------------------------------------------------- */}
        {selectedFrequency === 'quarterly' && (
          <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-800/80">
            <span className="text-xs text-slate-400 font-bold flex items-center gap-1">
              <Filter className="w-3.5 h-3.5 text-blue-400" />
              اختيار الربع السنوي:
            </span>
            <div className="flex items-center gap-1.5 overflow-x-auto">
              {(['Q1', 'Q2', 'Q3', 'Q4'] as PlanQuarter[]).map((q) => {
                const label =
                  q === 'Q1' ? 'الربع الأول (يناير - مارس)' :
                  q === 'Q2' ? 'الربع الثاني (أبريل - يونيو)' :
                  q === 'Q3' ? 'الربع الثالث (يوليو - سبتمبر) • الحالي' :
                  'الربع الرابع (أكتوبر - ديسمبر)';
                const isActive = selectedQuarter === q;
                return (
                  <button
                    key={q}
                    type="button"
                    onClick={() => setSelectedQuarter(q)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                      isActive
                        ? 'bg-blue-600 text-white shadow-md shadow-blue-950 ring-1 ring-blue-400'
                        : 'bg-slate-800/80 hover:bg-slate-800 text-slate-300 border border-slate-700/60'
                    }`}
                  >
                    {label}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {selectedFrequency === 'monthly' && (
          <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-800/80">
            <span className="text-xs text-slate-400 font-bold flex items-center gap-1">
              <Filter className="w-3.5 h-3.5 text-emerald-400" />
              تصفية الشهر المستهدف:
            </span>
            <div className="flex items-center gap-1.5 overflow-x-auto py-0.5">
              {[
                { m: 8, name: 'أغسطس 2026م' },
                { m: 9, name: 'سبتمبر 2026م (الشهر الحالي)' },
                { m: 10, name: 'أكتوبر 2026م' },
              ].map((item) => {
                const isActive = selectedMonth === item.m;
                return (
                  <button
                    key={item.m}
                    type="button"
                    onClick={() => setSelectedMonth(item.m)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                      isActive
                        ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950 ring-1 ring-emerald-400'
                        : 'bg-slate-800/80 hover:bg-slate-800 text-slate-300 border border-slate-700/60'
                    }`}
                  >
                    {item.name}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {selectedFrequency === 'weekly' && (
          <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-800/80">
            <span className="text-xs text-slate-400 font-bold flex items-center gap-1">
              <Filter className="w-3.5 h-3.5 text-amber-400" />
              اختيار الأسبوع التنفيذي:
            </span>
            <div className="flex items-center gap-1.5 overflow-x-auto py-0.5">
              {[
                { w: 1, name: 'الأسبوع 1 (1 - 7 سبتمبر)' },
                { w: 2, name: 'الأسبوع 2 (8 - 14 سبتمبر)' },
                { w: 3, name: 'الأسبوع 3 (15 - 21 سبتمبر) • النشط حالياً' },
                { w: 4, name: 'الأسبوع 4 (22 - 28 سبتمبر)' },
              ].map((item) => {
                const isActive = selectedWeek === item.w;
                return (
                  <button
                    key={item.w}
                    type="button"
                    onClick={() => setSelectedWeek(item.w)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                      isActive
                        ? 'bg-amber-600 text-slate-950 font-black shadow-md shadow-amber-950 ring-1 ring-amber-400'
                        : 'bg-slate-800/80 hover:bg-slate-800 text-slate-300 border border-slate-700/60'
                    }`}
                  >
                    {item.name}
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* ========================================================= */}
      {/* 2. FREQUENCY-SPECIFIC OVERVIEW CARDS & BEHAVIOR           */}
      {/* ========================================================= */}

      {/* A) BEHAVIOR FOR ANNUAL PLAN: Strategic Goals, Maintenance, Drills */}
      {selectedFrequency === 'annual' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="bg-gradient-to-br from-teal-950/80 via-slate-900 to-slate-900 border border-teal-800/60 p-4 rounded-2xl shadow-lg">
            <div className="flex items-center gap-2 text-teal-300 mb-2">
              <Target className="w-5 h-5" />
              <h3 className="text-xs font-bold">الأهداف الاستراتيجية لعام 2026م</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              تحقيق نسبة امتثال 95% لمعايير سباهي (CBAHI FMS) والربط الشامل لكافة أنظمة السلامة وتصفير حوادث الفئة الحرجة (Sentinel Events).
            </p>
            <div className="mt-3 pt-2.5 border-t border-teal-900/60 flex items-center justify-between text-[11px]">
              <span className="text-slate-400">الهدف المرجعي:</span>
              <span className="text-teal-300 font-bold font-mono">CBAHI FMS.1 - 34</span>
            </div>
          </div>

          <div className="bg-gradient-to-br from-blue-950/80 via-slate-900 to-slate-900 border border-blue-800/60 p-4 rounded-2xl shadow-lg">
            <div className="flex items-center gap-2 text-blue-300 mb-2">
              <Wrench className="w-5 h-5" />
              <h3 className="text-xs font-bold">برامج الصيانة الشاملة (USM & MEM)</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              عمرات الصيانة السنوية للمولدات، محطة الأكسجين المركزية، تبديل فلاتر HEPA لغرف العمليات، ومعايرة أجهزة العناية المركزة.
            </p>
            <div className="mt-3 pt-2.5 border-t border-blue-900/60 flex items-center justify-between text-[11px]">
              <span className="text-slate-400">جاهزية المرافق:</span>
              <span className="text-blue-300 font-bold font-mono">98.5% (مستقر)</span>
            </div>
          </div>

          <div className="bg-gradient-to-br from-amber-950/80 via-slate-900 to-slate-900 border border-amber-800/60 p-4 rounded-2xl shadow-lg">
            <div className="flex items-center gap-2 text-amber-300 mb-2">
              <Flame className="w-5 h-5" />
              <h3 className="text-xs font-bold">مواعيد تدريبات الإخلاء لعام 2026م</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              4 تجارب إخلاء فرضية سنوية: العيادات الخارجية (Q1)، العمليات والعناية (Q2)، الرقود و NICU (Q3)، والمناورة الكبرى مع الدفاع المدني (Q4).
            </p>
            <div className="mt-3 pt-2.5 border-t border-amber-900/60 flex items-center justify-between text-[11px]">
              <span className="text-slate-400">التجارب المنجزة:</span>
              <span className="text-amber-300 font-bold font-mono">3 من 4 (75%)</span>
            </div>
          </div>
        </div>
      )}

      {/* B) BEHAVIOR FOR QUARTERLY PLAN: KPI Performance & Evaluation */}
      {selectedFrequency === 'quarterly' && (
        <div className="bg-gradient-to-r from-blue-950/70 via-slate-900 to-indigo-950/70 border border-blue-800/60 p-4 rounded-2xl shadow-lg">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3 pb-3 border-b border-blue-900/50">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-blue-900/50 text-blue-300 border border-blue-700">
                <BarChart3 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">
                  مؤشرات الأداء والتقييم الربعي للجان (FMS Committee KPI Performance) • {selectedQuarter} 2026م
                </h3>
                <p className="text-xs text-slate-300">
                  تقييم استجابة اللجان، إغلاق خطط CAP، وجولات السلامة الفصلية المعتمدة
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400">مؤشر كفاءة الربع:</span>
              <span className="text-sm font-black text-emerald-400 font-mono bg-emerald-950 px-2.5 py-1 rounded-lg border border-emerald-800">
                {selectedQuarter === 'Q1' ? '100%' : selectedQuarter === 'Q2' ? '96.5%' : selectedQuarter === 'Q3' ? '94.2%' : '15%'}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center text-xs">
            <div className="bg-slate-900/90 border border-slate-800 p-2.5 rounded-xl">
              <div className="text-slate-400 text-[11px]">اجتماعات اللجنة</div>
              <div className="text-blue-400 font-bold text-sm mt-0.5">معتمدة بمحاضر رسمية</div>
            </div>
            <div className="bg-slate-900/90 border border-slate-800 p-2.5 rounded-xl">
              <div className="text-slate-400 text-[11px]">فحص الطفايات الدوري</div>
              <div className="text-emerald-400 font-bold text-sm mt-0.5">210 / 210 طفاية</div>
            </div>
            <div className="bg-slate-900/90 border border-slate-800 p-2.5 rounded-xl">
              <div className="text-slate-400 text-[11px]">إغلاق مخالفات CAP</div>
              <div className="text-teal-400 font-bold text-sm mt-0.5">92% مكتملة</div>
            </div>
            <div className="bg-slate-900/90 border border-slate-800 p-2.5 rounded-xl">
              <div className="text-slate-400 text-[11px]">تجربة الإخلاء الفرضي</div>
              <div className="text-amber-400 font-bold text-sm mt-0.5">
                {selectedQuarter === 'Q4' ? 'مجدولة في نوفمبر' : 'تمت بنجاح'}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* C) BEHAVIOR FOR MONTHLY PLAN: Monthly Department Audits Filter */}
      {selectedFrequency === 'monthly' && (
        <div className="bg-gradient-to-r from-emerald-950/70 via-slate-900 to-teal-950/70 border border-emerald-800/60 p-4 rounded-2xl shadow-lg">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3 pb-3 border-b border-emerald-900/50">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-emerald-900/50 text-emerald-300 border border-emerald-700">
                <Building2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">
                  جولات التفتيش والتدقيق الشهري للأقسام الـ 19 • {selectedMonth === 9 ? 'سبتمبر 2026م' : selectedMonth === 8 ? 'أغسطس 2026م' : 'أكتوبر 2026م'}
                </h3>
                <p className="text-xs text-slate-300">
                  تغطية الأقسام الخدمية والطبية، محطة الغازات، غرف المولدات، والمناطق الحساسة
                </p>
              </div>
            </div>

            <div className="text-xs bg-teal-950 text-teal-300 px-3 py-1.5 rounded-xl border border-teal-800 font-bold flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-teal-400" />
              <span>تغطية الأقسام: 19 / 19 قسماً</span>
            </div>
          </div>

          <div className="flex flex-wrap gap-1.5 text-[11px]">
            {[
              'المغسلة المركزية (LAUNDRY)',
              'قسم الأشعة (RADIOLOGY)',
              'التعقيم المركزي (CSSD)',
              'الصيدلية (PHARMACY)',
              'وحدة الأورام (ONCOLOGY)',
              'غرفة النفايات (WASTE_STORE)',
              'محطة الغازات (GAS_MANIFOLD)',
              'غرفة المولدات (GENERATORS)',
              'السيرفرات IT (IT_SERVERS)',
              'العمليات الجراحية (OR)',
              'العناية المركزة (ICU)',
              'الطوارئ (ER)',
              'المختبر وبنك الدم (LAB)',
              'حضانة الأطفال (NICU)',
              'المطبخ المركزي (KITCHEN)',
            ].map((dept, i) => (
              <span
                key={i}
                className="bg-slate-900/90 text-slate-300 border border-slate-700/80 px-2 py-0.5 rounded-lg flex items-center gap-1"
              >
                <Check className="w-3 h-3 text-emerald-400" />
                {dept}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* D) BEHAVIOR FOR WEEKLY PLAN: Routine Maintenance, Eyewash, Generators, Waste */}
      {selectedFrequency === 'weekly' && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="bg-slate-900/90 border border-amber-800/50 p-3.5 rounded-2xl shadow-md">
            <div className="flex items-center gap-2 text-amber-300 mb-1.5">
              <Eye className="w-4 h-4" />
              <h4 className="text-xs font-bold">محطات غسيل العيون ودش الطوارئ</h4>
            </div>
            <p className="text-[11.5px] text-slate-300 leading-relaxed">
              فحص تدفق المياه أسبوعياً في المختبر، التعقيم CSSD، الصيدلية، وغرفة النفايات لمنع الرواسب وضمان سرعة الاستجابة.
            </p>
            <div className="mt-2 text-[10.5px] font-bold text-emerald-400 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              تم الفحص والتدفق بنجاح
            </div>
          </div>

          <div className="bg-slate-900/90 border border-blue-800/50 p-3.5 rounded-2xl shadow-md">
            <div className="flex items-center gap-2 text-blue-300 mb-1.5">
              <Zap className="w-4 h-4" />
              <h4 className="text-xs font-bold">اختبار تشغيل المولدات ولوحة ATS</h4>
            </div>
            <p className="text-[11.5px] text-slate-300 leading-relaxed">
              تشغيل أسبوعي بدون حمل وتحت الحمل لتفريغ الرواسب والتأكد من سرعة التحويل التلقائي للطاقة خلال أقل من 10 ثوانٍ.
            </p>
            <div className="mt-2 text-[10.5px] font-bold text-emerald-400 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              زمن التحويل: 7.2 ثانية (مطابق)
            </div>
          </div>

          <div className="bg-slate-900/90 border border-rose-800/50 p-3.5 rounded-2xl shadow-md">
            <div className="flex items-center gap-2 text-rose-300 mb-1.5">
              <Trash2 className="w-4 h-4" />
              <h4 className="text-xs font-bold">التخلص الدوري من النفايات والمحرقة</h4>
            </div>
            <p className="text-[11.5px] text-slate-300 leading-relaxed">
              نقل النفايات الحادة والمعدية بحاويات صفراء محكمة للمحرقة، وزن الشحنات وتوثيق درجات حرارة الحرق (850°C - 1100°C).
            </p>
            <div className="mt-2 text-[10.5px] font-bold text-emerald-400 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              ترحيل الشحنة الأسبوعية (340 كجم)
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* 3. PLANS LIST & DETAILED TASKS VIEW                       */}
      {/* ========================================================= */}
      <div className="space-y-4">
        {filteredPlans.length === 0 ? (
          <div className="bg-slate-900/80 border border-slate-800 p-8 rounded-2xl text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-slate-800 text-slate-400 flex items-center justify-center mx-auto text-xl">
              📋
            </div>
            <h4 className="text-sm font-bold text-slate-200">لا توجد خطة مسجلة لهذه الفترة الزمنية المحددة</h4>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              يمكنك النقر على زر "إنشاء خطة تشغيلية جديدة" لإضافة خطة معتمدة وجدولة المهام والبرامج التنفيذية.
            </p>
            {!isReadOnlyMode && (
              <button
                type="button"
                onClick={() => setShowCreateModal(true)}
                className="px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold rounded-xl shadow transition"
              >
                ➕ إضافة خطة الآن
              </button>
            )}
          </div>
        ) : (
          filteredPlans.map((plan) => (
            <div
              key={plan.id}
              className="bg-slate-900 border border-slate-800 hover:border-slate-700/80 rounded-2xl shadow-xl overflow-hidden transition"
            >
              {/* Plan Header Card */}
              <div className="p-4 sm:p-5 border-b border-slate-800/90 bg-gradient-to-r from-slate-950/90 via-slate-900 to-slate-900 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div className="space-y-1.5 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-[10px] bg-teal-950 text-teal-300 border border-teal-800 px-2.5 py-0.5 rounded-full font-bold">
                      {plan.frequency === 'annual' ? '📅 خطة سنوية' :
                       plan.frequency === 'quarterly' ? `📊 خطة فصلية (${plan.quarter})` :
                       plan.frequency === 'monthly' ? `🗓️ خطة شهرية (${plan.monthNameAr || `شهر ${plan.month}`})` :
                       `⏱️ خطة أسبوعية (الأسبوع ${plan.weekNumber})`}
                    </span>
                    <span className="text-[10px] bg-slate-800 text-slate-300 border border-slate-700 px-2 py-0.5 rounded-md font-mono">
                      {plan.standardCategory}
                    </span>
                    <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded-md font-bold">
                      {plan.status === 'active' ? 'نشطة ومعتمدة ✔' : plan.status === 'completed' ? 'مكتملة بالكامل' : 'مسودة'}
                    </span>
                  </div>

                  <h3 className="text-sm sm:text-base font-bold text-white">
                    {plan.title}
                  </h3>

                  <p className="text-xs text-slate-300 leading-relaxed">
                    {plan.description}
                  </p>

                  {plan.strategicObjective && (
                    <p className="text-xs text-teal-400/90 leading-relaxed font-medium">
                      🎯 <span className="font-bold">الهدف الاستراتيجي:</span> {plan.strategicObjective}
                    </p>
                  )}
                </div>

                {/* Progress Circle & Quick Actions */}
                <div className="flex items-center gap-4 self-end lg:self-auto shrink-0">
                  <div className="text-center">
                    <div className="text-[10px] text-slate-400 mb-1">نسبة الإنجاز</div>
                    <div className="flex items-center gap-2">
                      <div className="w-24 bg-slate-950 rounded-full h-2.5 border border-slate-800 overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-teal-500 to-emerald-400 rounded-full transition-all duration-500"
                          style={{ width: `${plan.overallProgress}%` }}
                        />
                      </div>
                      <span className="text-xs font-mono font-black text-emerald-400">
                        {plan.overallProgress}%
                      </span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handlePrintPlan(plan)}
                    className="p-2 bg-slate-800 hover:bg-slate-700 text-teal-300 rounded-xl border border-slate-700 transition"
                    title="طباعة الخطة وتصديرها بصيغة PDF"
                  >
                    <Printer className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Tasks List Table */}
              <div className="p-4 sm:p-5 space-y-3">
                <div className="flex items-center justify-between text-xs text-slate-400 border-b border-slate-800 pb-2">
                  <div className="flex items-center gap-1.5 font-bold text-slate-200">
                    <ClipboardList className="w-4 h-4 text-teal-400" />
                    <span>المهام والبرامج التنفيذية المجدولة ({plan.tasks?.length || 0})</span>
                  </div>
                  {!isReadOnlyMode && (
                    <span className="text-[11px] text-slate-400">
                      اضغط على حالة المهمة لتغييرها [ قيد التنفيذ ⏳ / مكتملة ✔ ]
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-1 gap-2.5">
                  {(plan.tasks || []).map((task, idx) => {
                    const isCompleted = task.status === 'completed';
                    const isInProgress = task.status === 'in_progress';

                    return (
                      <div
                        key={task.id}
                        className={`p-3 rounded-xl border transition flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                          isCompleted
                            ? 'bg-slate-950/70 border-emerald-900/60 text-slate-300'
                            : isInProgress
                            ? 'bg-slate-950/90 border-amber-900/60 text-slate-100 shadow-sm'
                            : 'bg-slate-950/50 border-slate-800 text-slate-400'
                        }`}
                      >
                        <div className="flex items-start gap-3 flex-1">
                          <button
                            type="button"
                            disabled={isReadOnlyMode}
                            onClick={() => handleToggleTaskStatus(plan.id, task.id)}
                            className={`mt-0.5 w-5 h-5 rounded-lg border flex items-center justify-center shrink-0 transition ${
                              isCompleted
                                ? 'bg-emerald-600 border-emerald-400 text-white'
                                : isInProgress
                                ? 'bg-amber-600/30 border-amber-500 text-amber-300'
                                : 'bg-slate-900 border-slate-700 text-transparent hover:border-slate-500'
                            }`}
                            title="تغيير حالة المهمة"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>

                          <div className="space-y-1">
                            <div className="flex flex-wrap items-center gap-2">
                              <span className={`text-xs font-bold ${isCompleted ? 'line-through text-slate-400' : 'text-slate-100'}`}>
                                {task.title}
                              </span>

                              <span className={`text-[9.5px] px-2 py-0.5 rounded font-bold ${
                                task.priority === 'critical'
                                  ? 'bg-rose-950 text-rose-300 border border-rose-800'
                                  : task.priority === 'high'
                                  ? 'bg-amber-950 text-amber-300 border border-amber-800'
                                  : 'bg-slate-800 text-slate-300 border border-slate-700'
                              }`}>
                                {task.priority === 'critical' ? 'حرج جداً' : task.priority === 'high' ? 'أولوية عالية' : 'عادي'}
                              </span>

                              <span className="text-[9.5px] bg-slate-900 text-teal-300 border border-slate-800 px-1.5 py-0.5 rounded">
                                {task.category}
                              </span>
                            </div>

                            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-slate-400">
                              <span>المسؤول: <strong className="text-slate-300">{task.assignedTo}</strong></span>
                              {task.assignedDept && (
                                <span>القسم: <strong className="text-slate-300">{task.assignedDept}</strong></span>
                              )}
                              <span>الاستحقاق: <strong className="text-slate-300 font-mono">{task.dueDate}</strong></span>
                              {task.kpiIndicator && (
                                <span className="text-teal-400/90 font-mono">المؤشر: {task.kpiIndicator}</span>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Status button */}
                        <button
                          type="button"
                          disabled={isReadOnlyMode}
                          onClick={() => handleToggleTaskStatus(plan.id, task.id)}
                          className={`self-end sm:self-auto px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition ${
                            isCompleted
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 hover:bg-emerald-900'
                              : isInProgress
                              ? 'bg-amber-950 text-amber-300 border border-amber-800 hover:bg-amber-900'
                              : 'bg-slate-800 text-slate-300 border border-slate-700 hover:bg-slate-700'
                          }`}
                        >
                          {isCompleted ? (
                            <>
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                              <span>مكتملة ✔</span>
                            </>
                          ) : isInProgress ? (
                            <>
                              <Clock3 className="w-3.5 h-3.5 text-amber-400" />
                              <span>قيد التنفيذ ⏳</span>
                            </>
                          ) : (
                            <>
                              <Calendar className="w-3.5 h-3.5 text-slate-400" />
                              <span>مجدولة 📅</span>
                            </>
                          )}
                        </button>
                      </div>
                    );
                  })}
                </div>

                {/* Plan Signatures Badge Footer */}
                <div className="pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
                  <div className="flex items-center gap-3">
                    <span>إعداد: <strong className="text-slate-200">{plan.preparedBy}</strong></span>
                    <span>•</span>
                    <span>مراجعة: <strong className="text-slate-200">{plan.reviewedBy}</strong></span>
                    <span>•</span>
                    <span>اعتماد: <strong className="text-slate-200">{plan.approvedBy}</strong></span>
                  </div>

                  <div className="text-[10px] text-teal-400/80 font-mono">
                    جدول البيانات: fms_operational_plans
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* ========================================================= */}
      {/* 4. MODAL: CREATE NEW OPERATIONAL PLAN                     */}
      {/* ========================================================= */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-2xl w-full p-5 sm:p-6 shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto animate-in fade-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-teal-950 text-teal-400 border border-teal-800">
                  <Plus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-white">
                    إنشاء خطة تشغيلية جديدة لسلامة وإدارة المرافق (FMS)
                  </h3>
                  <p className="text-xs text-slate-400">
                    جدولة المهام التنفيذية، المعايير، وتحديد المسؤوليات لعام 2026م
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreatePlan} className="space-y-4">
              {/* Frequency Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  نوع الخطة والفترة الزمنية *
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { val: 'annual', label: '📅 سنوية' },
                    { val: 'quarterly', label: '📊 فصلية (ربع سنوية)' },
                    { val: 'monthly', label: '🗓️ شهرية' },
                    { val: 'weekly', label: '⏱️ أسبوعية' },
                  ].map((freq) => (
                    <button
                      key={freq.val}
                      type="button"
                      onClick={() => setNewPlan((prev) => ({ ...prev, frequency: freq.val as PlanFrequency }))}
                      className={`py-2 px-3 rounded-xl text-xs font-bold border transition ${
                        newPlan.frequency === freq.val
                          ? 'bg-teal-600 text-white border-teal-400 shadow-md'
                          : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-750'
                      }`}
                    >
                      {freq.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Sub-period controls */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    السنة
                  </label>
                  <input
                    type="number"
                    value={newPlan.year}
                    onChange={(e) => setNewPlan({ ...newPlan, year: parseInt(e.target.value) || 2026 })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>

                {newPlan.frequency === 'quarterly' && (
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">
                      الربع السنوي
                    </label>
                    <select
                      value={newPlan.quarter}
                      onChange={(e) => setNewPlan({ ...newPlan, quarter: e.target.value as PlanQuarter })}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                    >
                      <option value="Q1">الربع الأول Q1 (يناير - مارس)</option>
                      <option value="Q2">الربع الثاني Q2 (أبريل - يونيو)</option>
                      <option value="Q3">الربع الثالث Q3 (يوليو - سبتمبر)</option>
                      <option value="Q4">الربع الرابع Q4 (أكتوبر - ديسمبر)</option>
                    </select>
                  </div>
                )}

                {newPlan.frequency === 'monthly' && (
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">
                      الشهر
                    </label>
                    <select
                      value={newPlan.month}
                      onChange={(e) => setNewPlan({ ...newPlan, month: parseInt(e.target.value) || 9 })}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                    >
                      {Array.from({ length: 12 }, (_, i) => i + 1).map((m) => (
                        <option key={m} value={m}>
                          شهر {m} - 2026م
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                {newPlan.frequency === 'weekly' && (
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1">
                      الأسبوع
                    </label>
                    <select
                      value={newPlan.weekNumber}
                      onChange={(e) => setNewPlan({ ...newPlan, weekNumber: parseInt(e.target.value) || 1 })}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                    >
                      <option value="1">الأسبوع 1</option>
                      <option value="2">الأسبوع 2</option>
                      <option value="3">الأسبوع 3</option>
                      <option value="4">الأسبوع 4</option>
                    </select>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    المعيار المرجعي
                  </label>
                  <input
                    type="text"
                    value={newPlan.standardCategory}
                    onChange={(e) => setNewPlan({ ...newPlan, standardCategory: e.target.value })}
                    placeholder="مثال: CBAHI FMS.1 / JCI"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>
              </div>

              {/* Title & Description */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  عنوان الخطة التشغيلية *
                </label>
                <input
                  type="text"
                  required
                  value={newPlan.title}
                  onChange={(e) => setNewPlan({ ...newPlan, title: e.target.value })}
                  placeholder="مثال: خطة فحص واختبار محطات غسيل العيون والمولدات - الأسبوع 3..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  ملخص الخطة والهدف الاستراتيجي
                </label>
                <textarea
                  rows={2}
                  value={newPlan.description}
                  onChange={(e) => setNewPlan({ ...newPlan, description: e.target.value })}
                  placeholder="تفاصيل الخطة وأهدافها التنفيذية..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white resize-none"
                />
              </div>

              {/* Date range & target KPI */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    تاريخ البداية
                  </label>
                  <input
                    type="date"
                    value={newPlan.startDate}
                    onChange={(e) => setNewPlan({ ...newPlan, startDate: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    تاريخ النهاية
                  </label>
                  <input
                    type="date"
                    value={newPlan.endDate}
                    onChange={(e) => setNewPlan({ ...newPlan, endDate: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    المؤشر المستهدف (Target KPI)
                  </label>
                  <input
                    type="text"
                    value={newPlan.targetKpi}
                    onChange={(e) => setNewPlan({ ...newPlan, targetKpi: e.target.value })}
                    placeholder="مثال: نسبة الإنجاز ≥ 95%"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                  />
                </div>
              </div>

              {/* Tasks Builder */}
              <div className="space-y-2 pt-2 border-t border-slate-800">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-200 flex items-center gap-1">
                    <ClipboardList className="w-4 h-4 text-teal-400" />
                    المهام التنفيذية المسندة ({newPlan.tasks.length})
                  </label>
                  <button
                    type="button"
                    onClick={handleAddTaskField}
                    className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-teal-300 text-[11px] font-bold rounded-lg flex items-center gap-1 border border-slate-700 transition"
                  >
                    <Plus className="w-3 h-3" />
                    <span>إضافة مهمة</span>
                  </button>
                </div>

                <div className="space-y-2.5 max-h-48 overflow-y-auto p-1">
                  {newPlan.tasks.map((task, idx) => (
                    <div key={idx} className="bg-slate-950 border border-slate-800 p-2.5 rounded-xl space-y-2 relative">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] text-teal-400 font-bold font-mono">مهمة #{idx + 1}</span>
                        {newPlan.tasks.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleRemoveTaskField(idx)}
                            className="text-rose-400 hover:text-rose-300 text-xs p-1"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>

                      <input
                        type="text"
                        required
                        value={task.title}
                        onChange={(e) => {
                          const updated = [...newPlan.tasks];
                          updated[idx].title = e.target.value;
                          setNewPlan({ ...newPlan, tasks: updated });
                        }}
                        placeholder="عنوان المهمة التنفيذية..."
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white"
                      />

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                        <input
                          type="text"
                          value={task.assignedTo}
                          onChange={(e) => {
                            const updated = [...newPlan.tasks];
                            updated[idx].assignedTo = e.target.value;
                            setNewPlan({ ...newPlan, tasks: updated });
                          }}
                          placeholder="المسؤول (م. نجيب / عارف الصلوي)..."
                          className="bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white"
                        />
                        <input
                          type="text"
                          value={task.assignedDept}
                          onChange={(e) => {
                            const updated = [...newPlan.tasks];
                            updated[idx].assignedDept = e.target.value;
                            setNewPlan({ ...newPlan, tasks: updated });
                          }}
                          placeholder="القسم المعني..."
                          className="bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white"
                        />
                        <select
                          value={task.priority}
                          onChange={(e) => {
                            const updated = [...newPlan.tasks];
                            updated[idx].priority = e.target.value as any;
                            setNewPlan({ ...newPlan, tasks: updated });
                          }}
                          className="bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white"
                        >
                          <option value="low">أولوية منخفضة</option>
                          <option value="medium">أولوية متوسطة</option>
                          <option value="high">أولوية عالية</option>
                          <option value="critical">أولوية حرجة جداً</option>
                        </select>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Form Actions */}
              <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl transition"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white text-xs font-bold rounded-xl shadow-lg transition active:scale-95 disabled:opacity-50"
                >
                  {isSubmitting ? 'جاري الحفظ في جدول fms_operational_plans...' : 'حفظ واعتماد الخطة التشغيلية'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
