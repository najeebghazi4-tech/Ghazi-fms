import React, { useState, useEffect, useMemo } from 'react';
import { 
  GraduationCap, 
  Plus, 
  Calendar, 
  Clock, 
  Users, 
  MapPin, 
  UserCheck, 
  CheckCircle2, 
  Clock3, 
  AlertCircle, 
  Printer, 
  RefreshCw, 
  Search, 
  Filter, 
  Trash2, 
  Edit3,
  FileSpreadsheet, 
  Sparkles,
  BookOpen,
  ChevronDown,
  Award,
  FileCheck,
  X
} from 'lucide-react';
import { supabase } from '../services/supabaseClient';
import { SafetyTraining, TrainingStatus, StaffUser } from '../types';
import { executeSmartPrint } from '../utils/printUtils';
import { TrainingCertificatesRegistryView } from './TrainingCertificatesRegistryView';

interface SafetyTrainingScheduleViewProps {
  currentUser?: StaffUser;
  onLogAudit?: (action: string, actionAr: string, details: string) => void;
}

const COMMON_TRAINING_COURSES = [
  'التدريب العملي على خطة الإخلاء ومكافحة الحرائق (Code Red)',
  'إدارة وتداول المواد الكيميائية الخطرة وصحائف السلامة (MSDS & Hazmat)',
  'سلامة الغازات الطبية وصمامات العزل في الطوارئ والعمليات',
  'إجراءات السلامة للمتعاقدين وأعمال الصيانة الساخنة (Hot Work Permit)',
  'الإنعاش القلبي الرئوي الأساسي (BLS & CPR) لكوادر المستشفى',
  'التعامل مع انسكابات الدم والمخاطر البيولوجية (Biohazard Spill Kit)',
  'السلامة المهنية والوقاية من مخاطر وخز الإبر ومهمات PPE',
  'خطة الطوارئ والكوارث الخارجية (Code Yellow & External Disaster)',
];

const AUDIENCE_OPTIONS = [
  'جميع كوادر المستشفى الطبية والإدارية',
  'الكادر التمريضي والفني',
  'الأطباء وأخصائيو التخدير والعناية',
  'قسم الصيانة العامة والمرافق (FMS & USM)',
  'قسم الهندسة الطبية الحيوية (MEM)',
  'قسم النظافة والنفايات والمحرقة',
  'حراس الأمن والسلامة المهنية',
  'قسم المختبر المركزي وبنك الدم',
  'قسم الصيدلية والتموين الطبي',
];

const LOCATION_OPTIONS = [
  'قاعة التدريب الكبرى - الدور الرابع',
  'قاعة الاجتماعات الرئيسية - الإدارة العامة',
  'معمل المحاكاة والمهارات السريرية',
  'ميداني - قسم الصيانة وغرفة المولدات',
  'ميداني - محطة الغازات الطبية المركزية',
  'ميداني - قسم الطوارئ والحوادث',
];

const DAYS_OF_WEEK = ['السبت', 'الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس'];

export const SafetyTrainingScheduleView: React.FC<SafetyTrainingScheduleViewProps> = ({
  currentUser,
  onLogAudit,
}) => {
  const [trainings, setTrainings] = useState<SafetyTraining[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingTraining, setEditingTraining] = useState<SafetyTraining | null>(null);
  const [deleteConfirmTraining, setDeleteConfirmTraining] = useState<SafetyTraining | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [editingAttendeesId, setEditingAttendeesId] = useState<string | number | null>(null);
  const [tempAttendeesCount, setTempAttendeesCount] = useState<number>(0);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [activeSubTab, setActiveSubTab] = useState<'schedule' | 'certificates'>('schedule');

  // New Training Form State
  const [formData, setFormData] = useState({
    course_name: '',
    target_audience: AUDIENCE_OPTIONS[0],
    training_day: 'الأحد',
    training_date: new Date().toISOString().split('T')[0],
    training_time: '10:00',
    duration_hours: 2,
    trainer_name: currentUser?.name || 'م. نجيب غازي (رئيس السلامة FMS)',
    location: LOCATION_OPTIONS[0],
    status: 'مجدول' as TrainingStatus,
    attendees_count: 0,
    notes: '',
  });

  const handleOpenAddTraining = () => {
    setEditingTraining(null);
    setFormData({
      course_name: '',
      target_audience: AUDIENCE_OPTIONS[0],
      training_day: 'الأحد',
      training_date: new Date().toISOString().split('T')[0],
      training_time: '10:00',
      duration_hours: 2,
      trainer_name: currentUser?.name || 'م. نجيب غازي (رئيس السلامة FMS)',
      location: LOCATION_OPTIONS[0],
      status: 'مجدول',
      attendees_count: 0,
      notes: '',
    });
    setShowAddModal(true);
  };

  const handleOpenEditTraining = (trn: SafetyTraining) => {
    setEditingTraining(trn);
    setFormData({
      course_name: trn.course_name,
      target_audience: trn.target_audience,
      training_day: trn.training_day,
      training_date: trn.training_date,
      training_time: trn.training_time,
      duration_hours: trn.duration_hours,
      trainer_name: trn.trainer_name,
      location: trn.location,
      status: trn.status,
      attendees_count: trn.attendees_count || 0,
      notes: trn.notes || '',
    });
    setShowAddModal(true);
  };

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => {
      setNotification(null);
    }, 4000);
  };

  // Load trainings from Supabase
  const loadTrainings = async () => {
    try {
      setRefreshing(true);
      const { data, error } = await supabase
        .from('safety_trainings')
        .select('*')
        .order('training_date', { ascending: true });

      if (error) {
        console.error('[Supabase] Error fetching safety_trainings:', error);
        showNotification('error', 'تعذر جلب البيانات من Supabase، تم الاعتماد على النسخة المحلية');
      } else if (data) {
        setTrainings(data as SafetyTraining[]);
      }
    } catch (err) {
      console.error('[Supabase] Fetch error:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadTrainings();
  }, []);

  // Submit new or updated training course to Supabase
  const handleCreateOrUpdateTraining = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.course_name.trim()) {
      showNotification('error', 'يرجى إدخال اسم الدورة التدريبية');
      return;
    }

    setIsSubmitting(true);
    const payload: Partial<SafetyTraining> = {
      course_name: formData.course_name.trim(),
      target_audience: formData.target_audience,
      training_day: formData.training_day,
      training_date: formData.training_date,
      training_time: formData.training_time,
      duration_hours: Number(formData.duration_hours) || 1,
      trainer_name: formData.trainer_name.trim() || 'مدرب السلامة المعتمد',
      location: formData.location,
      status: formData.status,
      attendees_count: Number(formData.attendees_count) || 0,
      notes: formData.notes.trim(),
    };

    try {
      if (editingTraining) {
        setTrainings(prev => prev.map(t => t.id === editingTraining.id ? { ...t, ...payload } : t));
        const { error } = await supabase
          .from('safety_trainings')
          .update(payload)
          .eq('id', editingTraining.id);

        if (error) {
          console.warn('[Supabase Update Error]:', error);
        }
        showNotification('success', 'تم تعديل بيانات الدورة التدريبية بنجاح');
        if (onLogAudit) {
          onLogAudit(
            'UPDATE_TRAINING_SCHEDULE',
            'تعديل دورة تدريبية',
            `تم تعديل بيانات دورة (${payload.course_name}) بواسطة ${currentUser?.name || 'مسؤول السلامة'}.`
          );
        }
      } else {
        payload.created_at = new Date().toISOString();
        const { error } = await supabase
          .from('safety_trainings')
          .insert([payload]);

        if (error) {
          console.warn('[Supabase Insert Error]:', error);
        }
        showNotification('success', 'تم حفظ الدورة التدريبية بنجاح ومزامنتها مع قاعدة البيانات Supabase');
        if (onLogAudit) {
          onLogAudit(
            'CREATE_TRAINING_SCHEDULE',
            'جدولة دورة تدريبية',
            `تمت جدولة دورة (${payload.course_name}) بتاريخ ${payload.training_date} عبر Supabase.`
          );
        }
      }

      setShowAddModal(false);
      setEditingTraining(null);
      await loadTrainings();
    } catch (err) {
      console.error('Save error:', err);
      showNotification('error', 'حدث خطأ أثناء حفظ الدورة');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Update training status in Supabase
  const handleUpdateStatus = async (trainingId: string | number, newStatus: TrainingStatus) => {
    try {
      // Optimistic local update
      setTrainings(prev =>
        prev.map(t => (t.id === trainingId ? { ...t, status: newStatus } : t))
      );

      const { error } = await supabase
        .from('safety_trainings')
        .update({ status: newStatus })
        .eq('id', trainingId);

      if (error) {
        console.warn('[Supabase Update Error]:', error);
      } else {
        showNotification('success', `تم تحديث حالة الدورة إلى: [${newStatus}]`);
      }

      if (onLogAudit) {
        onLogAudit(
          'UPDATE_TRAINING_STATUS',
          'تحديث حالة دورة تدريبية',
          `تم تحديث حالة الدورة كود #${trainingId} إلى ${newStatus}.`
        );
      }
    } catch (err) {
      console.error('Status update failed:', err);
      showNotification('error', 'تعذر تحديث الحالة في قاعدة البيانات');
    }
  };

  // Update attendees count in Supabase
  const handleSaveAttendees = async (trainingId: string | number) => {
    try {
      setTrainings(prev =>
        prev.map(t => (t.id === trainingId ? { ...t, attendees_count: tempAttendeesCount } : t))
      );
      setEditingAttendeesId(null);

      const { error } = await supabase
        .from('safety_trainings')
        .update({ attendees_count: tempAttendeesCount })
        .eq('id', trainingId);

      if (error) {
        console.warn('[Supabase Attendees Update Error]:', error);
      } else {
        showNotification('success', `تم تسجيل عدد الحضور (${tempAttendeesCount} متدرب)`);
      }
    } catch (err) {
      console.error('Failed to update attendees:', err);
    }
  };

  // Delete training course via in-app confirmation modal
  const handleConfirmDeleteTraining = async () => {
    if (!deleteConfirmTraining) return;
    const trainingId = deleteConfirmTraining.id;
    const courseName = deleteConfirmTraining.course_name;

    try {
      setTrainings(prev => prev.filter(t => t.id !== trainingId));
      const { error } = await supabase
        .from('safety_trainings')
        .delete()
        .eq('id', trainingId);

      if (error) {
        console.warn('[Supabase Delete Error]:', error);
      }
      showNotification('success', 'تم حذف الدورة من جدول التدريب وتحديث المؤشرات');

      if (onLogAudit) {
        onLogAudit('DELETE_TRAINING', 'حذف دورة تدريبية', `تم حذف دورة (${courseName}) من الجدول.`);
      }
    } catch (err) {
      console.error('Delete error:', err);
    } finally {
      setDeleteConfirmTraining(null);
    }
  };

  // Filtered trainings
  const filteredTrainings = useMemo(() => {
    return trainings.filter(t => {
      const matchSearch =
        searchTerm.trim() === '' ||
        t.course_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.target_audience.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.trainer_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.location.toLowerCase().includes(searchTerm.toLowerCase());

      const matchStatus = statusFilter === 'all' || t.status === statusFilter;
      return matchSearch && matchStatus;
    });
  }, [trainings, searchTerm, statusFilter]);

  // Statistics
  const totalCourses = trainings.length;
  const completedCourses = trainings.filter(t => t.status === 'مكتمل').length;
  const scheduledCourses = trainings.filter(t => t.status === 'مجدول').length;
  const postponedCourses = trainings.filter(t => t.status === 'مؤجل').length;
  const totalAttendees = trainings.reduce((acc, curr) => acc + (curr.attendees_count || 0), 0);
  const completionRate = totalCourses > 0 ? Math.round((completedCourses / totalCourses) * 100) : 0;

  // Export to PDF via executeSmartPrint
  const handleExportPdf = () => {
    const tableRowsHtml = filteredTrainings
      .map(
        (t, idx) => `
        <tr style="border-bottom: 1px solid #e2e8f0; font-size: 11px;">
          <td style="padding: 8px; text-align: center; font-weight: bold; background-color: #f8fafc;">${idx + 1}</td>
          <td style="padding: 8px; font-weight: bold; color: #0f172a;">${t.course_name}</td>
          <td style="padding: 8px; color: #334155;">${t.target_audience}</td>
          <td style="padding: 8px; text-align: center;">${t.training_day}<br/><span style="color: #64748b; font-size: 10px;">${t.training_date}</span></td>
          <td style="padding: 8px; text-align: center;">${t.training_time} (${t.duration_hours} س)</td>
          <td style="padding: 8px; color: #1e293b;">${t.trainer_name}</td>
          <td style="padding: 8px; color: #475569;">${t.location}</td>
          <td style="padding: 8px; text-align: center; font-weight: bold; font-size: 12px; color: #0f766e;">${t.attendees_count || 0}</td>
          <td style="padding: 8px; text-align: center;">
            <span style="display: inline-block; padding: 3px 8px; border-radius: 9999px; font-size: 10px; font-weight: bold; ${
              t.status === 'مكتمل'
                ? 'background-color: #d1fae5; color: #065f46;'
                : t.status === 'مؤجل'
                ? 'background-color: #fee2e2; color: #991b1b;'
                : 'background-color: #e0f2fe; color: #0369a1;'
            }">
              ${t.status}
            </span>
          </td>
        </tr>
      `
      )
      .join('');

    const contentHtml = `
      <div style="font-family: 'Segoe UI', Tahoma, sans-serif; direction: rtl; text-align: right; color: #0f172a;">
        <!-- Executive KPI Banner -->
        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 20px;">
          <div style="background-color: #f0fdf4; border: 1px solid #bbf7d0; padding: 10px; border-radius: 8px; text-align: center;">
            <div style="font-size: 11px; color: #166534; font-weight: bold;">إجمالي الدورات</div>
            <div style="font-size: 20px; font-weight: 900; color: #15803d; margin-top: 4px;">${totalCourses}</div>
          </div>
          <div style="background-color: #ecfdf5; border: 1px solid #a7f3d0; padding: 10px; border-radius: 8px; text-align: center;">
            <div style="font-size: 11px; color: #065f46; font-weight: bold;">الدورات المنفذة</div>
            <div style="font-size: 20px; font-weight: 900; color: #047857; margin-top: 4px;">${completedCourses}</div>
          </div>
          <div style="background-color: #f0f9ff; border: 1px solid #bae6fd; padding: 10px; border-radius: 8px; text-align: center;">
            <div style="font-size: 11px; color: #0369a1; font-weight: bold;">المجدولة القادمة</div>
            <div style="font-size: 20px; font-weight: 900; color: #0284c7; margin-top: 4px;">${scheduledCourses}</div>
          </div>
          <div style="background-color: #fef3c7; border: 1px solid #fde68a; padding: 10px; border-radius: 8px; text-align: center;">
            <div style="font-size: 11px; color: #92400e; font-weight: bold;">إجمالي المتدربين الحضور</div>
            <div style="font-size: 20px; font-weight: 900; color: #b45309; margin-top: 4px;">${totalAttendees} كادر</div>
          </div>
        </div>

        <div style="margin-bottom: 12px; font-size: 12px; color: #475569; font-weight: bold;">
          جدول الدورات وورش العمل المعتمدة لبرنامج السلامة وإدارة المرافق (FMS):
        </div>

        <table style="width: 100%; border-collapse: collapse; border: 1px solid #cbd5e1; border-radius: 6px; overflow: hidden;">
          <thead>
            <tr style="background-color: #0f766e; color: #ffffff; font-size: 11px; font-weight: bold;">
              <th style="padding: 10px 6px; text-align: center; width: 35px;">#</th>
              <th style="padding: 10px 8px; text-align: right;">اسم الدورة والبرنامج التدريبي</th>
              <th style="padding: 10px 8px; text-align: right;">الفئة المستهدفة</th>
              <th style="padding: 10px 8px; text-align: center;">اليوم والتاريخ</th>
              <th style="padding: 10px 8px; text-align: center;">الوقت والمدة</th>
              <th style="padding: 10px 8px; text-align: right;">المدرب المعتمد</th>
              <th style="padding: 10px 8px; text-align: right;">مكان الانعقاد</th>
              <th style="padding: 10px 6px; text-align: center;">الحضور</th>
              <th style="padding: 10px 8px; text-align: center;">حالة التنفيذ</th>
            </tr>
          </thead>
          <tbody>
            ${tableRowsHtml || '<tr><td colspan="9" style="text-align: center; padding: 20px; color: #64748b;">لا توجد دورات مسجلة</td></tr>'}
          </tbody>
        </table>

        <!-- Signatures and Endorsement Block -->
        <div style="margin-top: 30px; display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; border-top: 2px solid #e2e8f0; padding-top: 15px;">
          <div style="text-align: center; font-size: 11px;">
            <p style="font-weight: bold; margin-bottom: 3px; color: #0f172a;">إعداد: منسق التدريب والسلامة</p>
            <p style="color: #64748b; margin-bottom: 25px;">م. نجيب غازي</p>
            <div style="border-top: 1px dashed #94a3b8; width: 70%; margin: 0 auto; padding-top: 4px; color: #475569;">التوقيع: .....................</div>
          </div>
          <div style="text-align: center; font-size: 11px;">
            <p style="font-weight: bold; margin-bottom: 3px; color: #0f172a;">مراجعة: إدارة الجودة والاعتماد (CBAHI)</p>
            <p style="color: #64748b; margin-bottom: 25px;">د. منسق الجودة</p>
            <div style="border-top: 1px dashed #94a3b8; width: 70%; margin: 0 auto; padding-top: 4px; color: #475569;">التوقيع: .....................</div>
          </div>
          <div style="text-align: center; font-size: 11px;">
            <p style="font-weight: bold; margin-bottom: 3px; color: #0f172a;">اعتماد: مدير عام مستشفى آزال النموذجي</p>
            <p style="color: #64748b; margin-bottom: 25px;">د. محمد السراجي</p>
            <div style="border-top: 1px dashed #94a3b8; width: 70%; margin: 0 auto; padding-top: 4px; color: #475569;">الختم الرسمي والتوقيع</div>
          </div>
        </div>
      </div>
    `;

    executeSmartPrint(contentHtml, {
      title: 'خطة وجدول التدريب السنوي على السلامة وإدارة المرافق (FMS)',
      subtitle: 'مستشفى آزال النموذجي • معتمد لمتطلبات المركز السعودي لاعتماد المنشآت الصحية (CBAHI)',
      refNumber: `AZAL-TRN-${new Date().getFullYear()}-${Date.now().toString().slice(-4)}`,
      date: new Date().toLocaleDateString('ar-YE', { year: 'numeric', month: 'long', day: 'numeric' }),
    });
  };

  return (
    <div className="space-y-4 pb-20 animate-in fade-in duration-200">
      {/* Toast Notification */}
      {notification && (
        <div
          className={`fixed top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-2xl shadow-2xl text-xs font-bold border flex items-center gap-2 transition-all ${
            notification.type === 'success'
              ? 'bg-emerald-950/95 text-emerald-200 border-emerald-500'
              : 'bg-rose-950/95 text-rose-200 border-rose-500'
          }`}
        >
          {notification.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          )}
          <span>{notification.message}</span>
        </div>
      )}

      {/* Screen Header & Top Controls */}
      <div className="bg-gradient-to-r from-slate-900 via-teal-950/60 to-slate-900 border border-teal-800/40 rounded-3xl p-4 sm:p-5 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-teal-600/20 border border-teal-500/40 text-teal-400 flex items-center justify-center shrink-0 shadow-inner">
            <GraduationCap className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-black text-white">
                خطة وجدول التدريب على السلامة والمرافق (FMS)
              </h2>
              <span className="text-[10px] bg-teal-950 text-teal-300 border border-teal-600/50 px-2 py-0.5 rounded-full font-bold">
                Supabase: safety_trainings
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              إدارة وتوثيق الدورات التدريبية المجدولة للكوادر الطبية والفنية وفق معايير CBAHI FMS.1 وخطط مكافحة الحرائق والإخلاء.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveSubTab('certificates')}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition active:scale-95 border ${
              activeSubTab === 'certificates'
                ? 'bg-amber-600 text-white border-amber-500 shadow-lg shadow-amber-950'
                : 'bg-slate-800 text-amber-300 border-amber-700/50 hover:bg-slate-700'
            }`}
            title="فتح سجل المتدربين وطباعة الشهادات الرسمية"
          >
            <Award className="w-4 h-4 text-amber-300" />
            <span>سجل الشهادات الرسمية</span>
          </button>

          <button
            type="button"
            onClick={handleOpenAddTraining}
            className="px-3.5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-teal-950 transition active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>إضافة دورة جديدة</span>
          </button>

          <button
            type="button"
            onClick={handleExportPdf}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold flex items-center gap-1.5 transition active:scale-95"
            title="تصدير الخطة إلى PDF رسمي معتمد"
          >
            <Printer className="w-4 h-4 text-teal-400" />
            <span>تصدير PDF</span>
          </button>

          <button
            type="button"
            onClick={loadTrainings}
            disabled={refreshing}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition active:scale-95"
            title="تحديث البيانات من Supabase"
          >
            <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin text-teal-400' : ''}`} />
          </button>
        </div>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="flex items-center gap-2 p-1.5 bg-slate-900/90 border border-slate-800 rounded-2xl">
        <button
          type="button"
          onClick={() => setActiveSubTab('schedule')}
          className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-black flex items-center justify-center gap-2 transition ${
            activeSubTab === 'schedule'
              ? 'bg-teal-600 text-white shadow-lg shadow-teal-950'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>جدول وخطة الدورات التدريبية المعتمدة</span>
          <span
            className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
              activeSubTab === 'schedule'
                ? 'bg-teal-800 text-teal-100'
                : 'bg-slate-800 text-slate-400'
            }`}
          >
            {trainings.length} دورة
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveSubTab('certificates')}
          className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-black flex items-center justify-center gap-2 transition ${
            activeSubTab === 'certificates'
              ? 'bg-gradient-to-r from-amber-600 to-amber-700 text-white shadow-lg shadow-amber-950'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <Award className="w-4 h-4 text-amber-300" />
          <span>سجل المتدربين وإصدار الشهادات الرسمية (A4 Landscape)</span>
          <span
            className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
              activeSubTab === 'certificates'
                ? 'bg-amber-900 text-amber-100'
                : 'bg-slate-800 text-amber-400'
            }`}
          >
            طباعة واعتماد ✓
          </span>
        </button>
      </div>

      {activeSubTab === 'certificates' ? (
        <TrainingCertificatesRegistryView
          trainingsList={trainings}
          currentUser={currentUser}
          onLogAudit={onLogAudit}
        />
      ) : (
        <>

      {/* KPI Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3">
        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-2xl flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 text-blue-400 flex items-center justify-center shrink-0">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 block font-medium">إجمالي البرامج</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl font-black text-white">{totalCourses}</span>
              <span className="text-[10px] text-blue-400">برنامج</span>
            </div>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-2xl flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 block font-medium">المنفذة والمكتملة</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl font-black text-emerald-400">{completedCourses}</span>
              <span className="text-[10px] text-slate-500 font-mono">({completionRate}%)</span>
            </div>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-2xl flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center shrink-0">
            <Clock3 className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 block font-medium">مجدولة قادمة</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl font-black text-amber-400">{scheduledCourses}</span>
              <span className="text-[10px] text-slate-500">قيد التنفيذ</span>
            </div>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-2xl flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-teal-500/10 border border-teal-500/30 text-teal-400 flex items-center justify-center shrink-0">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[11px] text-slate-400 block font-medium">المتدربون الحضور</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl font-black text-teal-300">{totalAttendees}</span>
              <span className="text-[10px] text-teal-500">كادر</span>
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-2xl flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 text-xs">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-500 absolute right-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="بحث باسم الدورة، الفئة المستهدفة، المدرب، أو المكان..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-9 pl-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-teal-500 transition"
          />
          {searchTerm && (
            <button
              type="button"
              onClick={() => setSearchTerm('')}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
            >
              ✕
            </button>
          )}
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          <span className="text-slate-500 text-[11px] flex items-center gap-1 shrink-0 ml-1">
            <Filter className="w-3.5 h-3.5" />
            <span>الحالة:</span>
          </span>
          {(['all', 'مجدول', 'مكتمل', 'مؤجل'] as const).map(st => (
            <button
              key={st}
              type="button"
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 rounded-xl font-bold transition shrink-0 ${
                statusFilter === st
                  ? 'bg-teal-600 text-white shadow'
                  : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {st === 'all' ? 'كافة الدورات' : st}
            </button>
          ))}
        </div>
      </div>

      {/* Main Interactive Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-400 text-[11px] select-none">
                <th className="py-3 px-3 text-center w-10">#</th>
                <th className="py-3 px-3">اسم الدورة التدريبية</th>
                <th className="py-3 px-3">الفئة المستهدفة</th>
                <th className="py-3 px-3">الموعد والتاريخ</th>
                <th className="py-3 px-3">المدرب والمكان</th>
                <th className="py-3 px-3 text-center">عدد الحضور</th>
                <th className="py-3 px-3 text-center">الحالة</th>
                <th className="py-3 px-3 text-center">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {loading ? (
                <tr>
                  <td colSpan={8} className="text-center py-12 text-slate-400">
                    <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-teal-400" />
                    <span>جاري تحميل جدول التدريب من Supabase...</span>
                  </td>
                </tr>
              ) : filteredTrainings.length === 0 ? (
                <tr>
                  <td colSpan={8} className="text-center py-12 text-slate-500">
                    <BookOpen className="w-8 h-8 mx-auto mb-2 opacity-30" />
                    <p className="font-bold text-sm">لا توجد دورات تدريبية مطابقة</p>
                    <p className="text-[11px] mt-1">يمكنك إضافة دورة جديدة باستخدام زر "إضافة دورة جديدة"</p>
                  </td>
                </tr>
              ) : (
                filteredTrainings.map((trn, idx) => (
                  <tr
                    key={trn.id}
                    className="hover:bg-slate-800/40 transition-colors group"
                  >
                    <td className="py-3 px-3 text-center text-slate-500 font-mono text-[11px]">
                      {idx + 1}
                    </td>

                    {/* Course Name */}
                    <td className="py-3 px-3">
                      <div className="font-bold text-white text-xs leading-snug">
                        {trn.course_name}
                      </div>
                      {trn.notes && (
                        <div className="text-[10px] text-slate-400 mt-0.5 line-clamp-1">
                          {trn.notes}
                        </div>
                      )}
                    </td>

                    {/* Target Audience */}
                    <td className="py-3 px-3">
                      <span className="inline-block bg-slate-950 border border-slate-800 text-slate-300 text-[11px] px-2.5 py-1 rounded-xl">
                        {trn.target_audience}
                      </span>
                    </td>

                    {/* Schedule Day & Time */}
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-1.5 text-slate-200 font-medium">
                        <Calendar className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                        <span>{trn.training_day}</span>
                        <span className="text-slate-500 text-[10px] font-mono">({trn.training_date})</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-slate-400 text-[10px] mt-0.5">
                        <Clock className="w-3 h-3 text-slate-500 shrink-0" />
                        <span>{trn.training_time}</span>
                        <span className="text-slate-500">• {trn.duration_hours} ساعات</span>
                      </div>
                    </td>

                    {/* Trainer & Location */}
                    <td className="py-3 px-3">
                      <div className="text-slate-200 font-medium text-xs">
                        {trn.trainer_name}
                      </div>
                      <div className="flex items-center gap-1 text-slate-400 text-[10px] mt-0.5">
                        <MapPin className="w-3 h-3 text-teal-500 shrink-0" />
                        <span>{trn.location}</span>
                      </div>
                    </td>

                    {/* Attendees Count with inline edit */}
                    <td className="py-3 px-3 text-center">
                      {editingAttendeesId === trn.id ? (
                        <div className="flex items-center justify-center gap-1 bg-slate-950 border border-teal-500 p-1 rounded-xl">
                          <input
                            type="number"
                            min="0"
                            value={tempAttendeesCount}
                            onChange={e => setTempAttendeesCount(Number(e.target.value))}
                            className="w-14 bg-slate-900 border border-slate-700 rounded text-center text-xs font-bold text-white py-0.5 focus:outline-none"
                            autoFocus
                          />
                          <button
                            type="button"
                            onClick={() => handleSaveAttendees(trn.id)}
                            className="px-2 py-0.5 bg-teal-600 hover:bg-teal-500 text-white rounded text-[10px] font-bold"
                          >
                            حفظ
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingAttendeesId(null)}
                            className="text-slate-500 hover:text-slate-300 text-xs px-1"
                          >
                            ✕
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => {
                            setEditingAttendeesId(trn.id);
                            setTempAttendeesCount(trn.attendees_count || 0);
                          }}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-teal-950/60 border border-teal-800/60 text-teal-300 font-bold hover:bg-teal-900/80 transition"
                          title="انقر لتعديل عدد الحضور"
                        >
                          <Users className="w-3.5 h-3.5 text-teal-400" />
                          <span className="font-mono text-xs">{trn.attendees_count || 0}</span>
                        </button>
                      )}
                    </td>

                    {/* Status with Quick Toggle Dropdown */}
                    <td className="py-3 px-3 text-center">
                      <div className="relative inline-block text-right">
                        <select
                          value={trn.status}
                          onChange={e => handleUpdateStatus(trn.id, e.target.value as TrainingStatus)}
                          className={`text-[11px] font-bold px-2.5 py-1 rounded-xl border focus:outline-none cursor-pointer transition ${
                            trn.status === 'مكتمل'
                              ? 'bg-emerald-950/80 text-emerald-300 border-emerald-700/60'
                              : trn.status === 'مؤجل'
                              ? 'bg-rose-950/80 text-rose-300 border-rose-700/60'
                              : 'bg-sky-950/80 text-sky-300 border-sky-700/60'
                          }`}
                        >
                          <option value="مجدول" className="bg-slate-900 text-sky-300">مجدول</option>
                          <option value="مكتمل" className="bg-slate-900 text-emerald-300">مكتمل</option>
                          <option value="مؤجل" className="bg-slate-900 text-rose-300">مؤجل</option>
                        </select>
                      </div>
                    </td>

                    {/* Actions */}
                    <td className="py-3 px-3 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          type="button"
                          onClick={() => setActiveSubTab('certificates')}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-amber-300 hover:bg-amber-950/40 transition"
                          title="عرض وإصدار شهادات المتدربين لهذه الدورة"
                        >
                          <Award className="w-4 h-4 text-amber-400" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleOpenEditTraining(trn)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-teal-300 hover:bg-teal-950/40 transition"
                          title="تعديل بيانات الدورة"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setDeleteConfirmTraining(trn)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-950/30 transition"
                          title="حذف الدورة"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Training Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 w-full max-w-2xl rounded-3xl p-5 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-teal-600/20 text-teal-400 flex items-center justify-center">
                  <GraduationCap className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">
                    {editingTraining ? 'تعديل بيانات الدورة التدريبية' : 'إضافة دورة تدريبية جديدة'}
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    {editingTraining ? `تعديل السجل #${editingTraining.id} في جدول safety_trainings` : 'حفظ مباشر في جدول safety_trainings بقاعدة بيانات Supabase'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setShowAddModal(false);
                  setEditingTraining(null);
                }}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateOrUpdateTraining} className="space-y-3.5 mt-4 text-xs">
              {/* Course Name with auto suggestions */}
              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  اسم الدورة التدريبية <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formData.course_name}
                  onChange={e => setFormData({ ...formData, course_name: e.target.value })}
                  placeholder="مثال: التدريب العملي على خطة الإخلاء ومكافحة الحرائق Code Red"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-teal-500"
                />
                {/* Suggestions Pills */}
                <div className="mt-1.5 flex flex-wrap gap-1">
                  {COMMON_TRAINING_COURSES.slice(0, 3).map(c => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setFormData({ ...formData, course_name: c })}
                      className="text-[10px] bg-slate-950 hover:bg-slate-800 text-slate-400 border border-slate-800 px-2 py-0.5 rounded-lg transition text-right truncate max-w-xs"
                    >
                      + {c}
                    </button>
                  ))}
                </div>
              </div>

              {/* Target Audience */}
              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  الفئة المستهدفة <span className="text-rose-400">*</span>
                </label>
                <select
                  value={formData.target_audience}
                  onChange={e => setFormData({ ...formData, target_audience: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-white focus:outline-none focus:border-teal-500"
                >
                  {AUDIENCE_OPTIONS.map(aud => (
                    <option key={aud} value={aud}>{aud}</option>
                  ))}
                </select>
              </div>

              {/* Day, Date, Time & Duration Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">اليوم</label>
                  <select
                    value={formData.training_day}
                    onChange={e => setFormData({ ...formData, training_day: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-2 text-white focus:outline-none"
                  >
                    {DAYS_OF_WEEK.map(d => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">التاريخ</label>
                  <input
                    type="date"
                    required
                    value={formData.training_date}
                    onChange={e => setFormData({ ...formData, training_date: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-2 text-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">الوقت</label>
                  <input
                    type="time"
                    required
                    value={formData.training_time}
                    onChange={e => setFormData({ ...formData, training_time: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-2 text-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">المدة (ساعات)</label>
                  <input
                    type="number"
                    step="0.5"
                    min="0.5"
                    max="12"
                    required
                    value={formData.duration_hours}
                    onChange={e => setFormData({ ...formData, duration_hours: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-2 text-white focus:outline-none"
                  />
                </div>
              </div>

              {/* Trainer & Location */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    اسم المدرب <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.trainer_name}
                    onChange={e => setFormData({ ...formData, trainer_name: e.target.value })}
                    placeholder="م. نجيب غازي (مسؤول السلامة)"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">
                    مكان الانعقاد <span className="text-rose-400">*</span>
                  </label>
                  <select
                    value={formData.location}
                    onChange={e => setFormData({ ...formData, location: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none"
                  >
                    {LOCATION_OPTIONS.map(loc => (
                      <option key={loc} value={loc}>{loc}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Status & Initial Attendees */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">الحالة المبدئية</label>
                  <select
                    value={formData.status}
                    onChange={e => setFormData({ ...formData, status: e.target.value as TrainingStatus })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none"
                  >
                    <option value="مجدول">مجدول</option>
                    <option value="مكتمل">مكتمل</option>
                    <option value="مؤجل">مؤجل</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-bold mb-1">عدد الحضور المتوقع/الفعلي</label>
                  <input
                    type="number"
                    min="0"
                    value={formData.attendees_count}
                    onChange={e => setFormData({ ...formData, attendees_count: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none"
                  />
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-slate-300 font-bold mb-1">ملاحظات ومحاور البرنامج</label>
                <textarea
                  rows={2}
                  value={formData.notes}
                  onChange={e => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="ملاحظات حول متطلبات الورشة، المواد، أو التقييم العملي..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold flex items-center gap-1.5 shadow-lg shadow-teal-950 disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <CheckCircle2 className="w-4 h-4" />
                  )}
                  <span>{editingTraining ? 'حفظ التعديلات في Supabase' : 'حفظ الدورة في Supabase'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* In-App Delete Confirmation Modal */}
      {deleteConfirmTraining && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-3">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-5 text-right space-y-4 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 text-rose-400">
              <div className="p-2.5 rounded-xl bg-rose-950/80 border border-rose-800">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-100">تأكيد حذف الدورة التدريبية</h3>
                <span className="text-[11px] text-slate-400 font-mono">{deleteConfirmTraining.course_name}</span>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              هل أنت متأكد من حذف هذه الدورة من جدول التدريب الرسمي؟
              <span className="block text-rose-300 font-semibold mt-1">
                ⚠️ تنبيه: سيتم حذف الدورة التدريبية وتحديث إحصائيات المتدربين والامتثال فوراً.
              </span>
            </p>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setDeleteConfirmTraining(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteTraining}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-lg shadow-rose-950"
              >
                <Trash2 className="w-4 h-4" />
                <span>تأكيد الحذف النهائي</span>
              </button>
            </div>
          </div>
        </div>
      )}
        </>
      )}
    </div>
  );
};

export default SafetyTrainingScheduleView;
