import React, { useState, useEffect } from 'react';
import { 
  X, 
  CheckCircle2, 
  AlertTriangle, 
  ExternalLink, 
  Copy, 
  Check, 
  FileText, 
  RefreshCw, 
  ShieldCheck, 
  BellRing,
  Link2,
  MessageSquareText,
  UserCheck
} from 'lucide-react';
import { SafetyViolationNotice, SafetyIncidentReport } from '../types';
import { HospitalNotificationItem } from '../services/cloudSyncService';
import { getPublicResolveUrl } from '../utils/phoneUtils';
import { CompletedActionResponseModal, CompletedAction } from './CompletedActionResponseModal';
import { supabase } from '../services/supabaseClient';

interface IncomingReportsAndStatementsModalProps {
  isOpen: boolean;
  onClose: () => void;
  violations: SafetyViolationNotice[];
  incidents: SafetyIncidentReport[];
  notifications: HospitalNotificationItem[];
  onRefreshData?: () => void;
  onOpenResolvePortal?: (violationId: string) => void;
}

export const IncomingReportsAndStatementsModal: React.FC<IncomingReportsAndStatementsModalProps> = ({
  isOpen,
  onClose,
  violations,
  incidents,
  notifications,
  onRefreshData,
  onOpenResolvePortal,
}) => {
  const [activeTab, setActiveTab] = useState<'statements' | 'incidents' | 'notifications'>('statements');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // 1. عزل النوافذ المنبثقة: فصل حالة الرد على الإفادات تماماً باسم closureModalNotice
  const [closureModalNotice, setClosureModalNotice] = useState<CompletedAction | null>(null);

  // Remediation notices loaded from Supabase
  const [remediationNotices, setRemediationNotices] = useState<any[]>([]);

  const loadRemediationNotices = async () => {
    try {
      const { data, error } = await supabase
        .from('safety_remediation_notices')
        .select('*');
      if (!error && Array.isArray(data)) {
        setRemediationNotices(data);
      } else {
        const raw = localStorage.getItem('azal_remediation_notices');
        if (raw) setRemediationNotices(JSON.parse(raw));
      }
    } catch {
      try {
        const raw = localStorage.getItem('azal_remediation_notices');
        if (raw) setRemediationNotices(JSON.parse(raw));
      } catch {}
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadRemediationNotices();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Filter ONLY truly responded/resolved violations that have an actual resolution note or responded status
  const respondedViolations = violations.filter(
    (v) => (v.status === 'responded' || v.status === 'resolved') && Boolean(v.resolutionNote)
  );

  // Also read any locally stored submitted statements
  let localStatements: Array<{
    id: string;
    referenceId: string;
    department: string;
    resolvedBy: string;
    note: string;
    afterPhotoUrl?: string;
    submittedAt: string;
    timestamp: number;
    status?: string;
    verified_by?: string;
  }> = [];

  try {
    const raw = localStorage.getItem('azal_incoming_statements');
    if (raw) {
      localStatements = JSON.parse(raw);
    }
  } catch {
    localStatements = [];
  }

  const handleCopy = async (id: string, text: string, e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2500);
    } catch {
      // ignore
    }
  };

  const totalStatementsCount = respondedViolations.length + localStatements.length + remediationNotices.length;

  return (
    <>
      <div 
        className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 text-right animate-in fade-in duration-200" 
        dir="rtl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="bg-slate-900 border border-emerald-500/50 rounded-3xl w-full max-w-3xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
          {/* Header */}
          <div className="p-4 sm:p-5 bg-gradient-to-r from-emerald-950/90 via-slate-900 to-slate-900 border-b border-slate-800 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-2xl bg-emerald-950 border border-emerald-500/60 text-emerald-400 shadow-md">
                <ShieldCheck className="w-6 h-6 text-emerald-400" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base sm:text-lg font-bold text-white">
                    مركز البلاغات والإفادات والردود الميدانية
                  </h2>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-900/80 text-emerald-300 text-[10px] font-bold border border-emerald-700">
                    سحابي ومباشر 🟢
                  </span>
                </div>
                <p className="text-xs text-slate-400">
                  توثيق واعتماد الردود والإفادات الفعلية الواردة من الأقسام الميدانية
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {onRefreshData && (
                <button
                  type="button"
                  onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    loadRemediationNotices();
                    onRefreshData();
                  }}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer"
                  title="تحديث البيانات من السحابة"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
              )}
              <button
                type="button"
                onClick={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  onClose();
                }}
                className="p-2 rounded-xl bg-slate-800 hover:bg-rose-900/60 text-slate-400 hover:text-white transition cursor-pointer"
                title="إغلاق النافذة"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="flex items-center gap-1.5 px-4 pt-3 pb-2 border-b border-slate-800 bg-slate-950/50 overflow-x-auto text-xs font-bold">
            <button
              type="button"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setActiveTab('statements');
              }}
              className={`px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                activeTab === 'statements'
                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-700 shadow-md'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>إفادات الإنجاز المعتمدة ({totalStatementsCount})</span>
            </button>

            <button
              type="button"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setActiveTab('incidents');
              }}
              className={`px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                activeTab === 'incidents'
                  ? 'bg-amber-950 text-amber-300 border border-amber-700 shadow-md'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
              <span>البلاغات الميدانية ({incidents.length})</span>
            </button>

            <button
              type="button"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setActiveTab('notifications');
              }}
              className={`px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                activeTab === 'notifications'
                  ? 'bg-blue-950 text-blue-300 border border-blue-700 shadow-md'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <BellRing className="w-3.5 h-3.5 text-blue-400" />
              <span>سجل الإشعارات السحابية ({notifications.length})</span>
            </button>
          </div>

          {/* Modal Body */}
          <div className="p-4 sm:p-5 overflow-y-auto flex-1 space-y-4">
            {/* TAB 1: ALL STATEMENTS & RESPONSES */}
            {activeTab === 'statements' && (
              <div className="space-y-3">
                {totalStatementsCount === 0 ? (
                  <div className="p-10 text-center bg-slate-950 rounded-2xl border border-slate-800 text-slate-400 text-xs space-y-2">
                    <div className="w-12 h-12 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center mx-auto text-slate-500">
                      <FileText className="w-6 h-6" />
                    </div>
                    <p className="font-bold text-slate-300">
                      لا توجد إفادات أو بلاغات جديدة حالياً. في انتظار الردود الميدانية الفعلية.
                    </p>
                    <span className="text-[11px] text-slate-500 block">
                      يمكن للمسؤولين الميدانيين استخدام رابط الإفادة الفوري لتقديم وتوثيق المعالجة بدون تسجيل دخول.
                    </span>
                  </div>
                ) : (
                  <>
                    {/* Supabase Remediation Notices */}
                    {remediationNotices.map((rn) => (
                      <div
                        key={`rn-${rn.id}`}
                        className="bg-slate-950 border border-emerald-700/70 rounded-2xl p-4 space-y-2.5 transition shadow-sm"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-xs font-bold text-emerald-400">{rn.notice_number || `AZAL-NOT-${rn.id}`}</span>
                            <span className="text-xs font-bold text-white">{rn.department_name || rn.department}</span>
                            <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold border ${
                              rn.status === 'مغلق ومعتمد نهائياً'
                                ? 'bg-emerald-950 text-emerald-300 border-emerald-700'
                                : rn.status === 'معاد للمراجعة والتعديل'
                                ? 'bg-amber-950 text-amber-300 border-amber-700'
                                : 'bg-blue-950 text-blue-300 border-blue-700'
                            }`}>
                              {rn.status || 'قيد المراجعة'}
                            </span>
                          </div>
                          <span className="text-[11px] text-slate-400 font-mono">
                            {rn.completed_at || rn.created_at || 'الآن'}
                          </span>
                        </div>

                        {rn.hazard_description && (
                          <p className="text-xs text-slate-300 leading-relaxed font-semibold">
                            {rn.hazard_description}
                          </p>
                        )}

                        <div className="p-3 rounded-xl bg-slate-900 border border-emerald-900/60 text-xs text-slate-200 space-y-1.5">
                          <span className="text-emerald-400 font-bold block">
                            الإجراء المنجز المرفوع من القسم:
                          </span>
                          <p className="leading-relaxed font-medium">"{rn.action_taken || rn.note || 'تمت المعالجة'}"</p>
                          <div className="pt-2 mt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                            <span>القائم بالإنجاز: <strong className="text-teal-300">{rn.completed_by || 'مسؤول القسم'}</strong></span>
                            {rn.verified_by && (
                              <span>المعتمد: <strong className="text-emerald-400">{rn.verified_by}</strong></span>
                            )}
                          </div>
                          {rn.safety_closure_notes && (
                            <div className="pt-1.5 mt-1.5 border-t border-slate-800/60 text-[11px] text-emerald-300">
                              <span className="font-bold text-slate-300">ملاحظات الاعتماد: </span>
                              {rn.safety_closure_notes}
                            </div>
                          )}
                        </div>

                        {/* Action Buttons */}
                        <div className="flex flex-wrap items-center justify-end gap-2 pt-1">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              setClosureModalNotice({
                                id: rn.id,
                                notice_number: rn.notice_number || `AZAL-NOT-${rn.id}`,
                                department_name: rn.department_name || rn.department || 'القسم المعني',
                                hazard_description: rn.hazard_description || 'إشعار معالجة سلامة',
                                action_taken: rn.action_taken || rn.note || 'تم إنجاز المعالجة المطلوبة',
                                completed_by: rn.completed_by || 'المسؤول الميداني',
                                completed_at: rn.completed_at || rn.created_at || new Date().toISOString(),
                                status: rn.status || 'قيد المراجعة'
                              });
                            }}
                            className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shadow-md"
                          >
                            <UserCheck className="w-3.5 h-3.5" />
                            <span>الرد على الإفادة</span>
                          </button>
                        </div>
                      </div>
                    ))}

                    {/* Local Statements */}
                    {localStatements.map((stmt) => (
                      <div
                        key={stmt.id}
                        className="bg-slate-950 border border-teal-800/80 rounded-2xl p-4 space-y-2.5 transition shadow-sm"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-xs font-bold text-teal-400">{stmt.referenceId}</span>
                            <span className="text-xs font-bold text-white">{stmt.department}</span>
                            <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold border ${
                              stmt.status === 'مغلق ومعتمد نهائياً'
                                ? 'bg-emerald-950 text-emerald-300 border-emerald-700'
                                : 'bg-teal-950 text-teal-300 border-teal-800'
                            }`}>
                              {stmt.status || '🟢 إفادة مباشرة واردة'}
                            </span>
                          </div>
                          <span className="text-[11px] text-slate-400 font-mono">
                            {stmt.submittedAt}
                          </span>
                        </div>

                        <div className="p-3 rounded-xl bg-slate-900 border border-emerald-900/60 text-xs text-slate-200 space-y-1.5">
                          <span className="text-emerald-400 font-bold block">
                            نص الإفادة المعتمدة:
                          </span>
                          <p className="leading-relaxed font-medium">"{stmt.note}"</p>
                          <div className="pt-2 mt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                            <span>المسؤول المنفذ: <strong className="text-teal-300">{stmt.resolvedBy}</strong></span>
                            <span>الموقع: {stmt.department}</span>
                          </div>
                        </div>

                        {stmt.afterPhotoUrl && (
                          <div className="pt-1">
                            <span className="text-[11px] text-slate-400 block mb-1">صورة التوثيق بعد المعالجة:</span>
                            <img
                              src={stmt.afterPhotoUrl}
                              alt="توثيق المعالجة"
                              className="w-24 h-24 object-cover rounded-xl border border-emerald-700 shadow-sm"
                            />
                          </div>
                        )}

                        {/* Action Buttons */}
                        <div className="flex flex-wrap items-center justify-end gap-2 pt-1">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              setClosureModalNotice({
                                id: stmt.id,
                                notice_number: stmt.referenceId,
                                department_name: stmt.department,
                                hazard_description: stmt.note,
                                action_taken: stmt.note,
                                completed_by: stmt.resolvedBy,
                                completed_at: stmt.submittedAt,
                                status: stmt.status || 'قيد المراجعة'
                              });
                            }}
                            className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shadow-md"
                          >
                            <UserCheck className="w-3.5 h-3.5" />
                            <span>الرد على الإفادة</span>
                          </button>
                        </div>
                      </div>
                    ))}

                    {/* Responded Violations from database */}
                    {respondedViolations.map((v) => {
                      const resolveUrl = getPublicResolveUrl(v);
                      return (
                        <div
                          key={v.id}
                          className="bg-slate-950 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 space-y-2.5 transition shadow-sm"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2">
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-xs font-bold text-amber-400">{v.id}</span>
                              <span className="text-xs font-bold text-white">{v.department}</span>
                              <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold border ${
                                v.status === 'resolved'
                                  ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                                  : 'bg-amber-950 text-amber-300 border-amber-800'
                              }`}>
                                {v.status === 'resolved' ? 'معتمد ومغلق 🟢' : 'تم الرد بالرابط 🟡'}
                              </span>
                            </div>
                            <span className="text-[11px] text-slate-400 font-mono">
                              {v.resolvedAt || v.createdAt}
                            </span>
                          </div>

                          <p className="text-xs text-slate-300 font-semibold leading-relaxed">
                            {v.description}
                          </p>

                          <div className="p-3 rounded-xl bg-slate-900 border border-emerald-900/60 text-xs text-slate-200">
                            <span className="text-emerald-400 font-bold block mb-1">
                              إفادة الإنجاز المسجلة:
                            </span>
                            <p className="leading-relaxed">"{v.resolutionNote}"</p>
                            <div className="pt-2 mt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                              <span>المسؤول المعتمد: <strong className="text-teal-300">{v.resolvedBy || v.assignedToCustom || v.assignedTo}</strong></span>
                              <span>الموقع: {v.locationDetail}</span>
                            </div>
                          </div>

                          <div className="flex flex-wrap items-center justify-end gap-2 pt-1">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                setClosureModalNotice({
                                  id: v.id,
                                  notice_number: v.id,
                                  department_name: v.department,
                                  hazard_description: v.description,
                                  action_taken: v.resolutionNote || 'تمت المعالجة والإنجاز',
                                  completed_by: v.resolvedBy || v.assignedToCustom || v.assignedTo || 'المسؤول الميداني',
                                  completed_at: v.resolvedAt || v.createdAt,
                                  status: v.status === 'resolved' ? 'مغلق ومعتمد نهائياً' : 'تم الرد'
                                });
                              }}
                              className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shadow-md"
                            >
                              <UserCheck className="w-3.5 h-3.5" />
                              <span>الرد على الإفادة</span>
                            </button>

                            <button
                              type="button"
                              onClick={(e) => handleCopy(`url-${v.id}`, resolveUrl, e)}
                              className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
                              title="نسخ الرابط المباشر للإفادة"
                            >
                              {copiedId === `url-${v.id}` ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Link2 className="w-3.5 h-3.5" />}
                              <span>{copiedId === `url-${v.id}` ? 'تم نسخ الرابط' : 'نسخ الرابط'}</span>
                            </button>

                            <button
                              type="button"
                              onClick={(e) => handleCopy(v.id, `${v.department}: ${v.resolutionNote} (${v.resolvedBy || ''})`, e)}
                              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
                            >
                              {copiedId === v.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                              <span>{copiedId === v.id ? 'تم النسخ' : 'نسخ الإفادة'}</span>
                            </button>

                            <button
                              type="button"
                              onClick={(e) => {
                                e.preventDefault();
                                e.stopPropagation();
                                if (onOpenResolvePortal) {
                                  onClose();
                                  onOpenResolvePortal(v.id);
                                } else {
                                  window.location.hash = `#resolve?id=${v.id}`;
                                  onClose();
                                }
                              }}
                              className="px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
                            >
                              <ExternalLink className="w-3.5 h-3.5" />
                              <span>استعراض الإفادة بالرابط</span>
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </>
                )}
              </div>
            )}

            {/* TAB 2: FIELD INCIDENTS */}
            {activeTab === 'incidents' && (
              <div className="space-y-3">
                {incidents.length === 0 ? (
                  <div className="p-8 text-center bg-slate-950 rounded-2xl border border-slate-800 text-slate-400 text-xs">
                    لا توجد بلاغات ميدانية مسجلة حالياً.
                  </div>
                ) : (
                  incidents.map((inc) => (
                    <div
                      key={inc.id}
                      className="bg-slate-950 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 space-y-2.5 transition"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold text-teal-400">
                            {inc.codeNumber || `AZAL-INC-${inc.id}`}
                          </span>
                          <span className="text-xs font-bold text-white">{inc.department}</span>
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                            {inc.categoryAr || 'حادث سلامة'}
                          </span>
                          <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                            inc.status === 'resolved' 
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                              : 'bg-amber-950 text-amber-300 border border-amber-800'
                          }`}>
                            {inc.status === 'resolved' ? 'معالج 🟢' : 'قيد المتابعة 🟡'}
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-400 font-mono">
                          {inc.reportedAt}
                        </span>
                      </div>

                      <p className="text-xs text-slate-200 font-semibold leading-relaxed">
                        {inc.description}
                      </p>

                      <div className="text-[11px] text-slate-400 flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-800/80">
                        <span>الموقع: {inc.locationDetail}</span>
                        <span>المسؤول: {inc.assignedOfficer || inc.reportedBy}</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* TAB 3: CLOUD NOTIFICATIONS */}
            {activeTab === 'notifications' && (
              <div className="space-y-3">
                {notifications.length === 0 ? (
                  <div className="p-8 text-center bg-slate-950 rounded-2xl border border-slate-800 text-slate-400 text-xs">
                    لا توجد إشعارات سحابية حالياً.
                  </div>
                ) : (
                  notifications.map((notif) => (
                    <div
                      key={notif.id}
                      className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 hover:border-slate-700 space-y-1.5 transition"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <BellRing className="w-3.5 h-3.5 text-teal-400" />
                          <strong className="text-xs text-white">{notif.title}</strong>
                        </div>
                        <span className="text-[10px] text-slate-500 font-mono">
                          {notif.createdAt || 'الآن'}
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 leading-relaxed pr-5">
                        {notif.body}
                      </p>
                    </div>
                  ))
                )}
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="p-3 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400 px-4">
            <span>إدارة الأمن والسلامة • مستشفى آزال النموذجي</span>
            <button
              type="button"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                onClose();
              }}
              className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold text-xs transition cursor-pointer"
            >
              إغلاق
            </button>
          </div>
        </div>
      </div>

      {/* 2. نافذة الرد على الإفادات المنجزة المعزولة كلياً بمكون CompletedActionResponseModal */}
      {closureModalNotice && (
        <CompletedActionResponseModal
          isOpen={Boolean(closureModalNotice)}
          action={closureModalNotice}
          onClose={() => {
            setClosureModalNotice(null);
          }}
          onSuccess={() => {
            setClosureModalNotice(null);
            loadRemediationNotices();
            if (onRefreshData) onRefreshData();
          }}
        />
      )}
    </>
  );
};
export default IncomingReportsAndStatementsModal;
