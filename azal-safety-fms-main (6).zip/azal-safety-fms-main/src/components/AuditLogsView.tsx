import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Search, 
  Filter, 
  CheckCircle2, 
  AlertTriangle, 
  FileText, 
  Printer, 
  Download, 
  Clock, 
  UserCheck 
} from 'lucide-react';
import { AuditLog, HandoverRecord } from '../types';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';
import { executeSmartPrint } from '../utils/printUtils';

interface AuditLogsViewProps {
  auditLogs: AuditLog[];
  handoverRecords: HandoverRecord[];
}

export const AuditLogsView: React.FC<AuditLogsViewProps> = ({
  auditLogs,
  handoverRecords,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [severityFilter, setSeverityFilter] = useState<'all' | 'info' | 'warning' | 'critical'>('all');
  const [activeSubTab, setActiveSubTab] = useState<'audit' | 'handovers'>('audit');

  const filteredLogs = auditLogs.filter((log) => {
    const matchesSearch =
      log.actionAr.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.actorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.details.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (log.patientMrn && log.patientMrn.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesSeverity = severityFilter === 'all' || log.securitySeverity === severityFilter;

    return matchesSearch && matchesSeverity;
  });

  const handlePrintLogs = () => {
    triggerSuccessFeedback();
    
    if (activeSubTab === 'audit') {
      const tableRows = filteredLogs.map((log, idx) => {
        const sevBadge = 
          log.securitySeverity === 'critical' ? '<span class="badge-danger">حرج / عالي الخطورة ✖</span>' :
          log.securitySeverity === 'warning' ? '<span class="badge-warning">تنبيه / تحذير ⚠</span>' :
          '<span class="badge-info">إجراء قياسي ✔</span>';

        return `
          <tr>
            <td style="font-weight:bold;">${idx + 1}</td>
            <td>${log.timestamp}</td>
            <td><strong>${log.actionAr}</strong><br><span style="font-size:10px; color:#64748b;">${log.action}</span></td>
            <td>${log.actorName} (${log.actorRole})</td>
            <td>${sevBadge}</td>
            <td>${log.patientMrn || '-'}</td>
            <td>${log.details}</td>
          </tr>
        `;
      }).join('');

      const bodyHtml = `
        <div class="summary-grid">
          <div class="summary-card"><div class="val">${auditLogs.length}</div><div class="lbl">إجمالي الحركات الموثقة</div></div>
          <div class="summary-card"><div class="val" style="color:#047857;">${auditLogs.filter(l => l.securitySeverity === 'info').length}</div><div class="lbl">حركات نظام قياسية</div></div>
          <div class="summary-card"><div class="val" style="color:#b91c1c;">${auditLogs.filter(l => l.securitySeverity === 'critical').length}</div><div class="lbl">تنبيهات أمنية حرجة</div></div>
        </div>
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>التوقيت والزمن</th>
              <th>الإجراء المنفذ</th>
              <th>المنفذ / الدور</th>
              <th>مستوى الأهمية</th>
              <th>رقم الملف MRN</th>
              <th>تفاصيل الحركة</th>
            </tr>
          </thead>
          <tbody>
            ${tableRows || '<tr><td colspan="7" style="text-align:center; padding:12px;">لا توجد سجلات تدقيق مطابقة</td></tr>'}
          </tbody>
        </table>
      `;

      executeSmartPrint(bodyHtml, {
        title: 'سجل التدقيق والأمان السريري والتتبّع غير القابل للتعديل',
        subtitle: 'مستشفى آزال النموذجي • إدارة الجودة والاعتماد CBAHI • التدقيق الأمني الشامل',
        refNumber: 'AZAL-AUDIT-TRAIL-2026'
      });
    } else {
      const tableRows = handoverRecords.map((h, idx) => `
        <tr>
          <td style="font-weight:bold;">${idx + 1}</td>
          <td>${h.shiftDate || (h as any).timestamp || '-'}</td>
          <td>${h.patientId || (h as any).patientMrn || '-'}</td>
          <td>${(h as any).department || 'الأقسام السريرية'}</td>
          <td>${h.outgoingStaff?.name || (h as any).outgoingNurseName || '-'}</td>
          <td>${h.incomingStaff?.name || (h as any).incomingNurseName || '-'}</td>
          <td>${(h as any).controlledMedicationsHanded ? 'تمت المطابقة ✔' : 'تم التسليم'}</td>
          <td>${h.clinicalSummary || (h as any).situation || '-'}</td>
        </tr>
      `).join('');

      const bodyHtml = `
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th>التوقيت</th>
              <th>رقم الملف MRN</th>
              <th>القسم السريري</th>
              <th>الممرض المُسَلِّم</th>
              <th>الممرض المُسْتَلِم</th>
              <th>الأدوية المراقبة</th>
              <th>الحالة السريرية ISBAR</th>
            </tr>
          </thead>
          <tbody>
            ${tableRows || '<tr><td colspan="8" style="text-align:center; padding:12px;">لا توجد سجلات تسليم تمريضي</td></tr>'}
          </tbody>
        </table>
      `;

      executeSmartPrint(bodyHtml, {
        title: 'سجل تدقيق استلام وتسليم الحالات السريرية التمريضية (ISBAR)',
        subtitle: 'مستشفى آزال النموذجي • هيئة التمريض والجودة السريرية',
        refNumber: 'AZAL-ISBAR-AUDIT-2026'
      });
    }
  };

  return (
    <div id="audit-logs-view" className="space-y-4 pb-20 text-right">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-teal-950/70 border border-slate-800 rounded-2xl p-4 shadow-lg flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-950 border border-teal-800 text-teal-400">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-100">
              سجل التدقيق والأمان السريري (Audit Trail & Security Logs)
            </h2>
            <p className="text-xs text-slate-400">
              سجل غير قابل للتعديل يوثق كافة إجراءات التسليم، الدخول، والأدوية المراقبة وفق معايير الاعتماد
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handlePrintLogs}
          className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition"
        >
          <Printer className="w-4 h-4" />
          <span>طباعة تقرير الرقابة</span>
        </button>
      </div>

      {/* Sub Tabs: All Audit Logs vs Formal Handover Records */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          type="button"
          onClick={() => setActiveSubTab('audit')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeSubTab === 'audit'
              ? 'bg-teal-600 text-white shadow-md'
              : 'bg-slate-900 text-slate-400 hover:text-slate-200'
          }`}
        >
          سجل الأحداث الأمنية ({auditLogs.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveSubTab('handovers')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeSubTab === 'handovers'
              ? 'bg-teal-600 text-white shadow-md'
              : 'bg-slate-900 text-slate-400 hover:text-slate-200'
          }`}
        >
          محاضر التسليم المعتمدة بالبصمة ({handoverRecords.length})
        </button>
      </div>

      {activeSubTab === 'audit' ? (
        <div className="space-y-3">
          {/* Search and Filters */}
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-500 absolute right-3 top-3" />
              <input
                type="text"
                placeholder="بحث باسم الممارس، رقم الملف، الإجراء..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl pr-9 pl-3 py-2 text-xs text-slate-100 placeholder-slate-500"
              />
            </div>

            <select
              value={severityFilter}
              onChange={(e) => setSeverityFilter(e.target.value as any)}
              className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200"
            >
              <option value="all">جميع مستويات الأمان</option>
              <option value="info">عمليات قياسية (Info)</option>
              <option value="warning">أدوية وعمليات حرجة (Warning)</option>
              <option value="critical">تنبيهات أمنية طارئة (Critical)</option>
            </select>
          </div>

          {/* Audit Log Entries List */}
          <div className="space-y-2">
            {filteredLogs.length === 0 ? (
              <div className="text-center py-10 bg-slate-900/50 rounded-2xl border border-slate-800 text-slate-400 text-xs">
                لا توجد سجلات مطابقة لمعايير البحث
              </div>
            ) : (
              filteredLogs.map((log) => (
                <div
                  key={log.id}
                  className="bg-slate-900/90 border border-slate-800 rounded-xl p-3 hover:border-slate-700 transition"
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] px-2 py-0.5 rounded font-mono font-bold ${
                        log.securitySeverity === 'critical'
                          ? 'bg-rose-950 text-rose-300 border border-rose-800'
                          : log.securitySeverity === 'warning'
                          ? 'bg-amber-950 text-amber-300 border border-amber-800'
                          : 'bg-teal-950 text-teal-300 border border-teal-800'
                      }`}>
                        {log.action}
                      </span>
                      <span className="text-xs font-bold text-slate-200">{log.actionAr}</span>
                    </div>

                    <span className="text-[11px] font-mono text-slate-400 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-500" />
                      <span>{log.timestamp}</span>
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed mb-2">{log.details}</p>

                  <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1.5 border-t border-slate-800/80">
                    <div className="flex items-center gap-1.5">
                      <span className="text-slate-500">الممارس:</span>
                      <span className="text-slate-200 font-semibold">{log.actorName}</span>
                      <span className="text-slate-500">({log.actorRole})</span>
                    </div>

                    {log.patientMrn && (
                      <span className="font-mono text-teal-400 bg-teal-950/60 px-2 py-0.5 rounded border border-teal-900">
                        {log.patientMrn}
                      </span>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      ) : (
        /* Formal Handover Records (محاضر الاستلام والتسليم المعتمدة) */
        <div className="space-y-3">
          {handoverRecords.map((rec) => (
            <div
              key={rec.id}
              className="bg-slate-900 border border-teal-800/70 rounded-2xl p-4 shadow-md space-y-3"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div className="flex items-center gap-2">
                  <span className="bg-emerald-950 text-emerald-300 border border-emerald-800 px-2.5 py-0.5 rounded-full text-xs font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>معتمد بالبصمة الرقمية</span>
                  </span>
                  <span className="text-xs font-bold text-slate-200">
                    وردية {rec.shiftType === 'morning' ? 'الصباح' : rec.shiftType === 'evening' ? 'المساء' : 'الليل'} • {rec.shiftDate}
                  </span>
                </div>
                <span className="font-mono text-[10px] text-teal-400 select-all">
                  {rec.verificationHash.slice(0, 24)}...
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-400 block mb-1">الطرف المُسلِّم:</span>
                  <span className="font-bold text-slate-100">{rec.outgoingStaff.name}</span>
                  <span className="text-[11px] text-slate-500 block">{rec.outgoingStaff.role} ({rec.outgoingStaff.signedAt})</span>
                </div>

                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-slate-400 block mb-1">الطرف المُستلِم:</span>
                  <span className="font-bold text-emerald-300">{rec.incomingStaff.name}</span>
                  <span className="text-[11px] text-slate-500 block">{rec.incomingStaff.role} ({rec.incomingStaff.signedAt})</span>
                </div>
              </div>

              <div className="bg-slate-950/70 p-2.5 rounded-xl border border-slate-800 text-xs">
                <span className="text-slate-400 block mb-1 font-semibold">ملخص التسليم السريري:</span>
                <p className="text-slate-200 leading-relaxed">{rec.clinicalSummary}</p>
                {rec.specialInstructions && (
                  <p className="text-amber-300 text-[11px] mt-1.5 font-medium">
                    تعليمات خاصة: {rec.specialInstructions}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
