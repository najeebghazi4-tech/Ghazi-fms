import React, { useState } from 'react';
import { 
  AlertOctagon, 
  Plus, 
  Search, 
  Filter, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  ShieldAlert, 
  FileText, 
  Printer, 
  Send,
  MessageSquare,
  Smartphone,
  User,
  X,
  Copy,
  Check,
  ExternalLink,
  QrCode,
  MessageCircle,
  Trash2,
  FlaskConical,
  Shield,
  HeartPulse
} from 'lucide-react';
import { SafetyIncidentReport, StaffUser, ChemicalMsdsItem } from '../types';
import { INITIAL_MSDS_DATABASE, AZAL_SAFETY_EMERGENCY_PHONE } from '../data/azalMsdsData';
import { VoiceDictationButton } from './VoiceDictationButton';
import { AZAL_HOSPITAL_LOCATIONS } from '../data/azalSecurityData';
import { AzalLogo } from './AzalLogo';
import { 
  cleanYemeniPhoneNumber, 
  pickContactPhoneNumber, 
  generateIncidentSMSText,
  generateIncidentWhatsAppText,
  getIncidentSMSUri,
  getIncidentWhatsAppUrl,
  openIncidentSMS,
  openIncidentWhatsApp,
  generateIncidentAlertSMSText, 
  openNativeSMSDirect,
  getNativeSMSUri,
  getPublicAppBaseUrl,
  AZAL_SAFETY_OFFICIAL_PHONE
} from '../utils/phoneUtils';
import { offlineStorage } from '../services/offlineStorage';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';
import { executeSmartPrint } from '../utils/printUtils';

interface IncidentReportingViewProps {
  incidents: SafetyIncidentReport[];
  currentUser: StaffUser;
  onSubmitIncident: (newIncident: SafetyIncidentReport) => void;
  onUpdateStatus: (id: string, status: 'open' | 'investigating' | 'resolved') => void;
  onDeleteIncident?: (id: string) => void;
  onClearAllIncidents?: () => void;
  onLogAudit: (action: string, actionAr: string, details: string) => void;
}

export const IncidentReportingView: React.FC<IncidentReportingViewProps> = ({
  incidents,
  currentUser,
  onSubmitIncident,
  onUpdateStatus,
  onDeleteIncident,
  onClearAllIncidents,
  onLogAudit,
}) => {
  const [showModal, setShowModal] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Dispatch Modal State (SMS & WhatsApp)
  const [selectedIncidentForDispatch, setSelectedIncidentForDispatch] = useState<{
    incident: SafetyIncidentReport;
    channel: 'sms' | 'whatsapp';
  } | null>(null);
  const [dispatchRecipientPhone, setDispatchRecipientPhone] = useState('967');
  const [copiedNotice, setCopiedNotice] = useState(false);
  const [submittedIncidentForConfirm, setSubmittedIncidentForConfirm] = useState<SafetyIncidentReport | null>(null);
  const [showConfirmationModal, setShowConfirmationModal] = useState(false);

  // Public Portal QR Code & Link Sharing Modal (Unified Services Hub / Public Portal)
  const getPublicServicesUrl = () => {
    if (typeof window !== 'undefined' && window.location.origin) {
      return `${window.location.origin}/#services`;
    }
    return `${getPublicAppBaseUrl()}/#services`;
  };
  const portalUrl = getPublicServicesUrl();
  const [showPublicPortalQrModal, setShowPublicPortalQrModal] = useState(false);
  const [copiedPortalLink, setCopiedPortalLink] = useState(false);

  const handleCopyPortalLink = async () => {
    const targetUrl = getPublicServicesUrl();
    try {
      if (navigator?.clipboard?.writeText) {
        await navigator.clipboard.writeText(targetUrl);
      } else {
        const textarea = document.createElement('textarea');
        textarea.value = targetUrl;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
      }
      setCopiedPortalLink(true);
      setTimeout(() => setCopiedPortalLink(false), 2500);
    } catch {
      setCopiedPortalLink(true);
      setTimeout(() => setCopiedPortalLink(false), 2500);
    }
  };

  const handleSharePortalWhatsApp = () => {
    const text = `السلام عليكم ورحمة الله وبركاته،\nرابط البوابة العامة المباشرة للإبلاغ عن مخاطر وملاحظات السلامة بمستشفى آزال النموذجي (بدون تسجيل دخول):\n${portalUrl}\nنرحب بملاحظاتكم دائماً لضمان سلامة الجميع.`;
    const shareUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`;
    window.open(shareUrl, '_blank', 'noopener,noreferrer');
  };

  const handleSharePortalSMS = () => {
    const text = `بوابة بلاغات السلامة العامة - مستشفى آزال النموذجي (مباشر بدون تسجيل دخول):\n${portalUrl}`;
    const isIOS = typeof navigator !== 'undefined' && /iPad|iPhone|iPod/.test(navigator.userAgent);
    const smsUri = isIOS ? `sms:;?body=${encodeURIComponent(text)}` : `sms:?body=${encodeURIComponent(text)}`;
    window.location.href = smsUri;
  };

  // New incident form fields
  const [department, setDepartment] = useState('قسم الطوارئ والإسعاف');
  const [locationDetail, setLocationDetail] = useState(AZAL_HOSPITAL_LOCATIONS[0]);
  const [categoryAr, setCategoryAr] = useState('النداء البرتقالي - Code Orange للانسكابات');
  const [severity, setSeverity] = useState<'low' | 'medium' | 'high' | 'critical'>('high');
  const [description, setDescription] = useState('');
  const [immediateAction, setImmediateAction] = useState('');

  // CBAHI & FMS Enhanced Fields
  const [isCodeOrange, setIsCodeOrange] = useState(false);
  const [codeOrangeSpillType, setCodeOrangeSpillType] = useState<'chemical' | 'biological'>('chemical');
  const [codeOrangeSpillSize, setCodeOrangeSpillSize] = useState<'minor' | 'major'>('minor');
  const [codeOrangeSpillKit, setCodeOrangeSpillKit] = useState<'needed_immediately' | 'already_used' | 'not_needed'>('needed_immediately');
  
  // MSDS Chemical Integration for Code Orange (FMS-APP-070EA)
  const [selectedChemicalId, setSelectedChemicalId] = useState<string>('glutaraldehyde-cidex-2');
  const [customChemicalName, setCustomChemicalName] = useState<string>('');
  const [showMsdsQuickModal, setShowMsdsQuickModal] = useState<boolean>(false);

  const currentSelectedChemical: ChemicalMsdsItem | undefined = INITIAL_MSDS_DATABASE.find(
    c => c.id === selectedChemicalId
  );

  // Medical Device fields
  const [medicalDeviceName, setMedicalDeviceName] = useState('');
  const [medicalDeviceAssetCode, setMedicalDeviceAssetCode] = useState('');
  const [medicalDeviceFailureType, setMedicalDeviceFailureType] = useState<'malfunction' | 'misuse' | 'power_failure' | 'needs_calibration'>('malfunction');

  // Smoking Violation fields
  const [smokingViolatorType, setSmokingViolatorType] = useState<'visitor' | 'patient_companion' | 'patient' | 'staff' | 'contractor'>('visitor');
  const [smokingAction, setSmokingAction] = useState<'verbal_warning' | 'confiscated' | 'security_escort' | 'fine_applied'>('verbal_warning');

  // Suspect Description fields
  const [suspectGender, setSuspectGender] = useState<'male' | 'female' | 'unknown'>('male');
  const [suspectHeight, setSuspectHeight] = useState('');
  const [suspectClothing, setSuspectClothing] = useState('');
  const [suspectLastLocation, setSuspectLastLocation] = useState('');

  const openSendModal = (incident: SafetyIncidentReport, channel: 'sms' | 'whatsapp') => {
    setSelectedIncidentForDispatch({ incident, channel });
    setDispatchRecipientPhone('967');
    setCopiedNotice(false);
  };

  const handlePickContact = async () => {
    const contact = await pickContactPhoneNumber();
    if (contact && contact.phone) {
      setDispatchRecipientPhone(contact.phone);
    }
  };

  const handleCopyText = async (text: string) => {
    try {
      if (navigator?.clipboard?.writeText) {
        await navigator.clipboard.writeText(text);
      } else {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
      }
      setCopiedNotice(true);
      setTimeout(() => setCopiedNotice(false), 2500);
    } catch {
      setCopiedNotice(true);
      setTimeout(() => setCopiedNotice(false), 2500);
    }
  };

  const handleExecuteDispatch = () => {
    if (!selectedIncidentForDispatch) return;
    const { incident, channel } = selectedIncidentForDispatch;
    const cleaned = cleanYemeniPhoneNumber(dispatchRecipientPhone);
    const targetPhone = cleaned && cleaned.length >= 9 ? cleaned : undefined;
    const nowTimestamp = new Date().toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' });

    if (channel === 'sms') {
      const text = generateIncidentSMSText(incident);
      onLogAudit(
        'INCIDENT_SMS_ALERT_SENT',
        'إرسال إشعار سلامة عبر SMS',
        `تم إرسال إشعار SMS للحادث رقم ${incident.id} (${incident.codeNumber}) بموقع ${incident.locationDetail}${targetPhone ? ` للرقم ${targetPhone}` : ''} في: ${nowTimestamp}.`
      );
      openIncidentSMS(targetPhone, text);
    } else {
      const text = generateIncidentWhatsAppText(incident);
      onLogAudit(
        'INCIDENT_WHATSAPP_ALERT_SENT',
        'إرسال إشعار سلامة عبر واتساب',
        `تم إرسال إشعار مخالفة للسلامة للحادث رقم ${incident.id} (${incident.codeNumber}) بموقع ${incident.locationDetail}${targetPhone ? ` للرقم ${targetPhone}` : ''} في: ${nowTimestamp}.`
      );
      openIncidentWhatsApp(targetPhone, text);
    }

    setSelectedIncidentForDispatch(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) return;

    // 1. Auto-Numbering for All Incidents: Auto-incremented integer ID
    const numericIds = incidents.map((i) => {
      const num = parseInt(String(i.id).replace(/\D/g, ''), 10);
      return isNaN(num) ? 0 : num;
    });
    const nextIntId = (numericIds.length > 0 ? Math.max(...numericIds, 0) : 0) + 1;
    const newIncId = String(nextIntId);

    const isOrange = isCodeOrange || categoryAr.includes('Code Orange') || categoryAr.includes('البرتقالي');
    const isMedDevice = categoryAr.includes('الأجهزة الطبية');
    const isSmoking = categoryAr.includes('التدخين');
    const isSuspect = categoryAr.includes('المشتبه بهم') || categoryAr.includes('سرقة');

    let extraDetailsText = '';
    if (isOrange) {
      const typeAr = codeOrangeSpillType === 'chemical' ? 'كيميائي' : 'بيولوجي';
      const sizeAr = codeOrangeSpillSize === 'minor' ? 'بسيط (<50ml)' : 'كبير (>50ml)';
      const kitAr = codeOrangeSpillKit === 'needed_immediately' ? 'مطلوبة فوراً للموقع' : codeOrangeSpillKit === 'already_used' ? 'تم استخدام عدة الموقع' : 'غير مطلوبة';
      extraDetailsText += `\n[🚨 النداء البرتقالي - انسكاب خطير: نوع: ${typeAr} | الحجم: ${sizeAr} | عدة الانسكاب Spill Kit: ${kitAr}]`;
    }
    if (isMedDevice && medicalDeviceName) {
      const failAr = medicalDeviceFailureType === 'malfunction' ? 'عطل فني' : medicalDeviceFailureType === 'misuse' ? 'سوء استخدام' : medicalDeviceFailureType === 'power_failure' ? 'انقطاع طاقة' : 'معايرة';
      extraDetailsText += `\n[🩺 جهاز طبي: ${medicalDeviceName} | الكود: ${medicalDeviceAssetCode || 'غير محدد'} | الحالة: ${failAr}]`;
    }
    if (isSmoking) {
      const violatorAr = smokingViolatorType === 'visitor' ? 'زائر' : smokingViolatorType === 'patient_companion' ? 'مرافق مريض' : smokingViolatorType === 'patient' ? 'مريض' : smokingViolatorType === 'staff' ? 'كادر تمريض/طبي' : 'مقاول';
      const actionAr = smokingAction === 'verbal_warning' ? 'إنذار شفهي' : smokingAction === 'confiscated' ? 'مصادرة الولاعة/السجائر' : smokingAction === 'security_escort' ? 'استدعاء الأمن' : 'تطبيق غرامة';
      extraDetailsText += `\n[🚭 مخالفة تدخين: صفة المخالف: ${violatorAr} | الإجراء: ${actionAr}]`;
    }
    if (isSuspect && (suspectClothing || suspectHeight || suspectLastLocation)) {
      const genderAr = suspectGender === 'male' ? 'ذكر' : suspectGender === 'female' ? 'أنثى' : 'غير محدد';
      extraDetailsText += `\n[👤 مواصفات المشتبه به: الجنس: ${genderAr} | الطول: ${suspectHeight || 'متوسط'} | الملابس: ${suspectClothing || 'غير محدد'} | آخر موقع: ${suspectLastLocation || locationDetail}]`;
    }

    const newInc: SafetyIncidentReport = {
      id: newIncId,
      codeNumber: `AZAL-OVR-${new Date().getFullYear()}-${String(nextIntId).padStart(3, '0')}`,
      reportedAt: `اليوم ${new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}`,
      reportedBy: `${currentUser.name} (${currentUser.roleTitleAr})`,
      department,
      locationDetail,
      categoryAr: isOrange ? 'النداء البرتقالي - Code Orange للانسكابات' : categoryAr,
      severity: isOrange && codeOrangeSpillSize === 'major' ? 'critical' : severity,
      description: description.trim() + extraDetailsText,
      immediateAction: immediateAction.trim() || 'تم إخطار مشرف الأمن والسلامة بالموقع.',
      status: 'open',
      assignedOfficer: 'رئيس قسم السلامة وإدارة المرافق FMS: م/ نجيب قاسم غازي',
      codeOrange: isOrange ? {
        isCodeOrange: true,
        spillType: codeOrangeSpillType,
        spillSize: codeOrangeSpillSize,
        spillKitStatus: codeOrangeSpillKit,
      } : undefined,
      medicalDeviceDetails: isMedDevice ? {
        deviceName: medicalDeviceName || 'جهاز طبي عام',
        assetOrSerialCode: medicalDeviceAssetCode || undefined,
        failureType: medicalDeviceFailureType,
      } : undefined,
      smokingDetails: isSmoking ? {
        violatorType: smokingViolatorType,
        immediateIntervention: smokingAction,
      } : undefined,
      suspectDetails: isSuspect ? {
        gender: suspectGender,
        approxHeight: suspectHeight || 'متوسط',
        clothing: suspectClothing || 'عادي',
        lastSeenLocation: suspectLastLocation || locationDetail,
      } : undefined,
    };

    onSubmitIncident(newInc);
    setSubmittedIncidentForConfirm(newInc);
    setShowConfirmationModal(true);
    setShowModal(false);
    setDescription('');
    setImmediateAction('');

    // Save to IndexedDB sync queue
    offlineStorage.enqueueSync('violation', newInc).catch(() => {});

    // Audio and haptic vibration feedback
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate([100, 50, 200]);
      } catch {}
    }
    triggerSuccessFeedback();

    // Auto open WhatsApp directly to safety emergency number (96777738138)
    try {
      const waMsg = 
        `*🚨 بلاغ حادث وواقعة أمن وسلامة (OVR) - مستشفى آزال النموذجي*\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `🆔 *رقم البلاغ:* ${newInc.codeNumber} (#${newInc.id})\n` +
        `📍 *الموقع:* ${newInc.locationDetail} (${newInc.department})\n` +
        `⚠️ *التصنيف:* ${newInc.categoryAr}\n` +
        `🚨 *درجة الخطورة:* ${newInc.severity === 'critical' ? 'حرج جداً ✖' : newInc.severity === 'high' ? 'مرتفع ⚠' : 'متوسط'}\n` +
        `📝 *الوصف:* ${newInc.description}\n` +
        `⚡ *الإجراء الفوري:* ${newInc.immediateAction}\n` +
        `👤 *المُبلّغ:* ${newInc.reportedBy}\n` +
        `🕒 *الوقت:* ${newInc.reportedAt}\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `🚨 طوارئ السلامة المعتمدة: 96777738138`;
      const waUrl = `https://api.whatsapp.com/send?phone=96777738138&text=${encodeURIComponent(waMsg)}`;
      window.open(waUrl, '_blank', 'noopener,noreferrer');
    } catch {}

    onLogAudit(
      'INCIDENT_OVR_REPORTED',
      'تسجيل بلاغ حادث أمن وسلامة جديد (OVR)',
      `تم تسجيل البلاغ رقم ${newInc.id} (${newInc.codeNumber} - ${newInc.categoryAr}) في ${newInc.locationDetail}.`
    );
  };

  const handlePrintIncidentsLog = () => {
    triggerSuccessFeedback();
    const tableRows = filteredIncidents.map((inc, idx) => {
      const sevBadge = 
        inc.severity === 'critical' ? '<span class="badge-danger">حرج / مرتفع جداً ✖</span>' :
        inc.severity === 'high' ? '<span class="badge-warning">مرتفع ⚠</span>' :
        inc.severity === 'medium' ? '<span class="badge-info">متوسط</span>' :
        '<span class="badge-success">منخفض</span>';

      const statusBadge = 
        inc.status === 'resolved' ? '<span class="badge-success">تم الحل والإغلاق ✔</span>' :
        inc.status === 'investigating' ? '<span class="badge-warning">قيد التحقيق 🔍</span>' :
        '<span class="badge-danger">مفتوح / جاري المتابعة</span>';

      return `
        <tr>
          <td style="font-weight:bold;">${idx + 1}</td>
          <td style="font-family:monospace; font-weight:bold;">${inc.codeNumber}</td>
          <td>${inc.timestamp}</td>
          <td><strong>${inc.categoryAr}</strong></td>
          <td>${inc.locationDetail} (${inc.department})</td>
          <td>${sevBadge}</td>
          <td>${statusBadge}</td>
          <td>${inc.reportedBy}</td>
          <td>${inc.description}</td>
          <td>${inc.immediateAction}</td>
        </tr>
      `;
    }).join('');

    const bodyHtml = `
      <div class="summary-grid">
        <div class="summary-card"><div class="val">${incidents.length}</div><div class="lbl">إجمالي البلاغات المسجلة</div></div>
        <div class="summary-card"><div class="val" style="color:#047857;">${incidents.filter(i => i.status === 'resolved').length}</div><div class="lbl">بلاغات تمت معالجتها</div></div>
        <div class="summary-card"><div class="val" style="color:#b45309;">${incidents.filter(i => i.status === 'investigating').length}</div><div class="lbl">بلاغات قيد التحقيق</div></div>
        <div class="summary-card"><div class="val" style="color:#b91c1c;">${incidents.filter(i => i.status === 'open').length}</div><div class="lbl">بلاغات مفتوحة</div></div>
      </div>
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>كود البلاغ</th>
            <th>التوقيت</th>
            <th>نوع الحادث / التصنيف</th>
            <th>الموقع والقسم</th>
            <th>الخطورة</th>
            <th>الحالة الراهنة</th>
            <th>المُبلِّغ</th>
            <th>وصف الحادث</th>
            <th>الإجراء الفوري المتخذ</th>
          </tr>
        </thead>
        <tbody>
          ${tableRows || '<tr><td colspan="10" style="text-align:center; padding:12px;">لا توجد بلاغات مسجلة</td></tr>'}
        </tbody>
      </table>
    `;

    executeSmartPrint(bodyHtml, {
      title: 'سجل رصد وبلاغات حوادث السلامة والأمان السريري (Incident Reports & OVR)',
      subtitle: 'مستشفى آزال النموذجي • إدارة السلامة وإدارة المرافق FMS • لجنة الحوادث والأخطار',
      refNumber: 'AZAL-INCIDENT-LOG-2026'
    });
  };

  const handlePrintQrPoster = () => {
    triggerSuccessFeedback();
    const posterHtml = `
      <div style="text-align:center; padding:20px; max-width:600px; margin:0 auto; border:2px dashed #0d9488; border-radius:16px;">
        <div style="font-size:24px; font-weight:900; color:#0f172a; margin-bottom:4px;">بوابة الإبلاغ الفوري عن حوادث السلامة</div>
        <div style="font-size:14px; color:#0d9488; font-weight:bold; margin-bottom:16px;">مستشفى آزال النموذجي • إدارة الأمن والسلامة وإدارة المرافق FMS</div>
        
        <p style="font-size:13px; color:#475569; line-height:1.6; margin-bottom:20px;">
          حرصاً على سلامتكم وسلامة المرضى والزوار، يرجى مسح الرمز أدناه بكاميرا الهاتف للإبلاغ المباشر والسري عن أي خطر أو عطل أو حادث سلامة دون الحاجة لتسجيل دخول.
        </p>

        <div style="display:inline-block; padding:16px; background:#fff; border:2px solid #cbd5e1; border-radius:16px; box-shadow:0 4px 12px rgba(0,0,0,0.08); margin-bottom:20px;">
          <img 
            src="https://api.qrserver.com/v1/create-qr-code/?size=300x300&margin=4&data=${encodeURIComponent(portalUrl)}" 
            alt="QR Code" 
            style="width:240px; height:240px; display:block;"
          />
        </div>

        <div style="background:#f0fdfa; border:1px solid #99f6e4; border-radius:12px; padding:12px; margin-bottom:16px; font-size:12px; color:#115e59;">
          <strong>📞 رقم عمليات الطوارئ والسلامة المباشر (24/7):</strong> <span dir="ltr" style="font-weight:bold; font-size:15px; color:#0d9488;">777738138</span>
        </div>

        <div style="font-size:11px; color:#94a3b8;">
          نظام آزال للأمن والسلامة • معتمد ومطابق لمعايير المركز السعودي لاعتماد المنشآت الصحية (CBAHI)
        </div>
      </div>
    `;

    executeSmartPrint(posterHtml, {
      title: 'ملصق رمز QR لبوابة بلاغات السلامة العامة - مستشفى آزال النموذجي',
      subtitle: 'ملصق معتمد للتعليق في الممرات والأقسام والاستقبال',
      refNumber: 'AZAL-POSTER-QR-OVR'
    });
  };

  const filteredIncidents = incidents.filter((inc) => {
    const matchesSearch =
      inc.id.toString().includes(searchTerm.toLowerCase()) ||
      inc.codeNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inc.categoryAr.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inc.locationDetail.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inc.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSeverity = severityFilter === 'all' || inc.severity === severityFilter;
    const matchesStatus = statusFilter === 'all' || inc.status === statusFilter;
    return matchesSearch && matchesSeverity && matchesStatus;
  });

  return (
    <div id="incident-reporting-view" className="space-y-4 pb-20 text-right">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-rose-950/60 border border-slate-800 rounded-2xl p-4 shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-rose-950/80 border border-rose-800 text-rose-400">
            <AlertOctagon className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-100">
              سجل بلاغات وحوادث السلامة والأمان (Incident & OVR Log)
            </h2>
            <p className="text-xs text-slate-400">
              نظام الرصد الفوري لكافة المخاطر، الانسكابات، الاعتداءات، أو الأعطال بمستشفى أزال
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
          {onClearAllIncidents && incidents.length > 0 && (
            <button
              type="button"
              onClick={() => {
                if (window.confirm('هل أنت متأكد من رغبتك في مسح كافة بلاغات وحوادث السلامة المسجلة نهائياً؟')) {
                  onClearAllIncidents();
                }
              }}
              className="px-3 py-2 rounded-xl bg-slate-950 hover:bg-rose-950 text-slate-300 hover:text-rose-300 border border-slate-800 hover:border-rose-800 text-xs font-bold transition flex items-center justify-center gap-1.5 active:scale-95"
              title="مسح وتفريغ كافة البلاغات"
            >
              <Trash2 className="w-3.5 h-3.5 text-rose-400" />
              <span>مسح كافة البلاغات</span>
            </button>
          )}

          <button
            type="button"
            onClick={handlePrintIncidentsLog}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 flex items-center justify-center gap-1.5 transition active:scale-95"
            title="طباعة سجل البلاغات كاملاً وتصديره كـ PDF"
          >
            <Printer className="w-4 h-4 text-teal-400" />
            <span>طباعة السجل (Print / PDF)</span>
          </button>

          <button
            type="button"
            onClick={() => setShowPublicPortalQrModal(true)}
            className="px-3.5 py-2 rounded-xl bg-teal-700 hover:bg-teal-600 text-white text-xs font-bold shadow-md shadow-teal-950 flex items-center justify-center gap-1.5 transition active:scale-95"
            title="عرض ومشاركة رمز QR ورابط بوابة الخدمات والتصاريح الموحدة (#services)"
          >
            <QrCode className="w-4 h-4 text-amber-300" />
            <span>بوابة الخدمات والتصاريح (QR)</span>
          </button>

          <button
            type="button"
            onClick={() => setShowModal(true)}
            className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-lg shadow-rose-950 flex items-center justify-center gap-1.5 transition active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>تسجيل بلاغ حادث جديد (OVR)</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-2 text-xs">
        <div className="relative flex-1 flex items-center">
          <Search className="w-4 h-4 text-slate-500 absolute right-3 top-2.5 pointer-events-none" />
          <input
            type="text"
            placeholder="بحث برقم البلاغ، النوع، الموقع، الوصف..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pr-9 pl-11 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-rose-500"
          />
          <div className="absolute left-1.5 top-1.5">
            <VoiceDictationButton
              value={searchTerm}
              onChange={setSearchTerm}
              title="بحث صوتي في البلاغات"
            />
          </div>
        </div>

        <select
          value={severityFilter}
          onChange={(e) => setSeverityFilter(e.target.value)}
          className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-200"
        >
          <option value="all">كافة مستويات الخطورة</option>
          <option value="low">منخفض (Low)</option>
          <option value="medium">متوسط (Medium)</option>
          <option value="high">مرتفع (High)</option>
          <option value="critical">حرج جداً (Critical)</option>
        </select>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-200"
        >
          <option value="all">كافة الحالات</option>
          <option value="open">مفتوح وقيد الانتظار</option>
          <option value="investigating">قيد التحقيق والمعالجة</option>
          <option value="resolved">مغلق ومحلول نهائياً</option>
        </select>
      </div>

      {/* Incidents List */}
      <div className="space-y-3">
        {filteredIncidents.length === 0 ? (
          <div className="text-center py-10 bg-slate-900/50 rounded-2xl border border-slate-800 text-slate-400 text-xs">
            لا توجد بلاغات تطابق شروط البحث الحالية
          </div>
        ) : (
          filteredIncidents.map((inc) => (
            <div
              key={inc.id}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-sm hover:border-slate-700 transition space-y-3 text-xs"
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    {/* 1. Auto-Numbering for All Incidents: رقم الإشعار: 1, 2, 3... */}
                    <span className="text-xs font-mono font-black text-teal-300 bg-teal-950/90 border border-teal-700/80 px-2.5 py-0.5 rounded-lg shadow-sm">
                      رقم الإشعار: {inc.id}
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">
                      ({inc.codeNumber})
                    </span>
                    <h3 className="font-bold text-slate-100 text-sm">{inc.categoryAr}</h3>
                    <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                      inc.severity === 'critical'
                        ? 'bg-rose-950 text-rose-300 border border-rose-800'
                        : inc.severity === 'high'
                        ? 'bg-orange-950 text-orange-300 border border-orange-800'
                        : inc.severity === 'medium'
                        ? 'bg-amber-950 text-amber-300 border border-amber-800'
                        : 'bg-slate-800 text-slate-300'
                    }`}>
                      {inc.severity === 'critical' ? 'خطورة قصوى' : inc.severity === 'high' ? 'عالي' : inc.severity === 'medium' ? 'متوسط' : 'بسيط'}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-400 flex-wrap">
                    <span>الموقع: <strong className="text-slate-200">{inc.locationDetail}</strong></span>
                    <span>•</span>
                    <span>القسم: <strong className="text-slate-200">{inc.department}</strong></span>
                    <span>•</span>
                    <span>{inc.reportedAt}</span>
                    <span>•</span>
                    <span>المُبلّغ: {inc.reportedBy}</span>
                  </div>

                  {/* FMS Indicator Badges */}
                  <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                    {(inc.codeOrange?.isCodeOrange || inc.categoryAr.includes('Code Orange') || inc.categoryAr.includes('البرتقالي')) && (
                      <span className="text-[10px] font-bold bg-orange-950 text-orange-300 border border-orange-700 px-2 py-0.5 rounded-lg flex items-center gap-1">
                        <span>☣️</span>
                        <span>النداء البرتقالي: {inc.codeOrange?.spillType === 'biological' ? 'بيولوجي' : 'كيميائي'} ({inc.codeOrange?.spillSize === 'major' ? 'كبير >50ml' : 'بسيط'})</span>
                      </span>
                    )}
                    {inc.medicalDeviceDetails && (
                      <span className="text-[10px] font-bold bg-sky-950 text-sky-300 border border-sky-700 px-2 py-0.5 rounded-lg flex items-center gap-1">
                        <span>🩺</span>
                        <span>جهاز طبي: {inc.medicalDeviceDetails.deviceName}</span>
                      </span>
                    )}
                    {inc.smokingDetails && (
                      <span className="text-[10px] font-bold bg-amber-950 text-amber-300 border border-amber-700 px-2 py-0.5 rounded-lg flex items-center gap-1">
                        <span>🚭</span>
                        <span>مخالفة تدخين ({inc.smokingDetails.violatorType})</span>
                      </span>
                    )}
                    {inc.suspectDetails && (
                      <span className="text-[10px] font-bold bg-purple-950 text-purple-300 border border-purple-700 px-2 py-0.5 rounded-lg flex items-center gap-1">
                        <span>👤</span>
                        <span>مشتبه به: {inc.suspectDetails.clothing}</span>
                      </span>
                    )}
                  </div>
                </div>

                {/* 2. Side-by-Side Action Buttons & Status Switcher */}
                <div className="flex flex-wrap items-center gap-2 self-end lg:self-auto">
                  <div className="flex items-center gap-2">
                    {/* [ 💬 إرسال SMS ] */}
                    <button
                      type="button"
                      onClick={() => openSendModal(inc, 'sms')}
                      className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md shadow-blue-950/40 flex items-center justify-center gap-1.5 transition active:scale-95 whitespace-nowrap"
                      title="إرسال إشعار سلامة عبر SMS من شريحة الهاتف مباشرة"
                    >
                      <span>💬</span>
                      <span>إرسال SMS</span>
                    </button>

                    {/* [ 🟢 إرسال واتساب ] */}
                    <button
                      type="button"
                      onClick={() => openSendModal(inc, 'whatsapp')}
                      className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md shadow-emerald-950/40 flex items-center justify-center gap-1.5 transition active:scale-95 whitespace-nowrap"
                      title="إرسال إشعار وضع مخالف للسلامة تفصيلي عبر واتساب مباشرة"
                    >
                      <span>🟢</span>
                      <span>إرسال واتساب</span>
                    </button>
                  </div>

                  <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800">
                    <button
                      type="button"
                      onClick={() => onUpdateStatus(inc.id, 'open')}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition ${
                        inc.status === 'open'
                          ? 'bg-rose-600 text-white'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      مفتوح
                    </button>
                    <button
                      type="button"
                      onClick={() => onUpdateStatus(inc.id, 'investigating')}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition ${
                        inc.status === 'investigating'
                          ? 'bg-amber-600 text-white'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      قيد المعالجة
                    </button>
                    <button
                      type="button"
                      onClick={() => onUpdateStatus(inc.id, 'resolved')}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition ${
                        inc.status === 'resolved'
                          ? 'bg-emerald-600 text-white'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      محلول ✓
                    </button>

                    {onDeleteIncident && (
                      <button
                        type="button"
                        onClick={() => {
                          if (window.confirm(`هل أنت متأكد من حذف البلاغ رقم ${inc.id} (${inc.codeNumber}) بشكل نهائي؟`)) {
                            onDeleteIncident(inc.id);
                          }
                        }}
                        className="px-2 py-1 rounded-lg text-[10px] font-bold text-slate-400 hover:text-rose-400 hover:bg-rose-950/40 transition flex items-center gap-1"
                        title="حذف هذا البلاغ نهائياً"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                        <span className="hidden sm:inline">حذف</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Description & Immediate Action */}
              <div className="space-y-1.5 text-slate-300 leading-relaxed text-[11px]">
                <p>
                  <strong className="text-slate-400 ml-1">تفاصيل الواقعة:</strong>
                  {inc.description}
                </p>
                <div className="bg-slate-950/80 p-2.5 rounded-xl border border-slate-800/80 text-teal-300">
                  <strong className="text-slate-400 ml-1">الإجراء الفوري المتخذ:</strong>
                  <span>{inc.immediateAction}</span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* New Incident Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 text-right overflow-y-auto">
          <div className="bg-slate-900 border border-rose-600/60 rounded-3xl w-full max-w-xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
            <div className="bg-slate-950 px-5 py-3.5 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-rose-950 text-rose-400 border border-rose-800">
                  <AlertOctagon className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-100">تسجيل بلاغ حادث / خطر أمني جديد (OVR)</h3>
                  <p className="text-[11px] text-slate-400">مستشفى أزال النموذجي • إدارة الأمن والسلامة</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowModal(false)}
                className="p-1 rounded-lg bg-slate-800 text-slate-400 hover:text-slate-100"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-5 space-y-3.5 overflow-y-auto text-xs">
              {/* Fast Emergency Code Orange Banner */}
              <div className={`p-3 rounded-2xl border transition-all ${
                isCodeOrange 
                  ? 'bg-orange-950/80 border-orange-500 shadow-md' 
                  : 'bg-slate-950/60 border-slate-800'
              }`}>
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="p-1.5 rounded-lg bg-orange-600 text-white font-bold text-xs">
                      ☣️ Code Orange
                    </span>
                    <div>
                      <h4 className="font-bold text-orange-300">النداء البرتقالي (انسكابات كيميائية أو بيولوجية)</h4>
                      <p className="text-[10px] text-slate-400">تفعيل فوري لبروتوكول احتواء المواد الخطرة وعدة الانسكاب</p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setIsCodeOrange(!isCodeOrange);
                      if (!isCodeOrange) {
                        setCategoryAr('النداء البرتقالي - Code Orange للانسكابات');
                        setSeverity('high');
                      } else {
                        setCategoryAr('انسكاب سوائل وتعثر');
                        setSeverity('medium');
                      }
                    }}
                    className={`px-3 py-1 rounded-xl text-xs font-bold transition ${
                      isCodeOrange ? 'bg-orange-600 text-white' : 'bg-slate-800 text-orange-300 border border-orange-700/50'
                    }`}
                  >
                    {isCodeOrange ? '✓ مفعل' : 'تفعيل النداء'}
                  </button>
                </div>

                {isCodeOrange && (
                  <div className="mt-2.5 pt-2.5 border-t border-orange-800/40 space-y-2.5">
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <div>
                        <label className="block text-[10px] text-orange-200 font-bold mb-0.5">نوع الانسكاب:</label>
                        <select
                          value={codeOrangeSpillType}
                          onChange={(e) => setCodeOrangeSpillType(e.target.value as any)}
                          className="w-full bg-slate-950 border border-orange-700 rounded-lg p-1.5 text-orange-100 text-xs"
                        >
                          <option value="chemical">🧪 كيميائي (أحماض/مطهرات/سيدكس)</option>
                          <option value="biological">🩸 بيولوجي (دم/سوائل معدية)</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-[10px] text-orange-200 font-bold mb-0.5">حجم الانسكاب:</label>
                        <select
                          value={codeOrangeSpillSize}
                          onChange={(e) => {
                            const sz = e.target.value as any;
                            setCodeOrangeSpillSize(sz);
                            if (sz === 'major') setSeverity('critical');
                          }}
                          className="w-full bg-slate-950 border border-orange-700 rounded-lg p-1.5 text-orange-100 text-xs"
                        >
                          <option value="minor">بسيط (&lt; 50ml)</option>
                          <option value="major">كبير (&gt; 50ml - تطويق)</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-[10px] text-orange-200 font-bold mb-0.5">عدة الانسكاب (Spill Kit):</label>
                        <select
                          value={codeOrangeSpillKit}
                          onChange={(e) => setCodeOrangeSpillKit(e.target.value as any)}
                          className="w-full bg-slate-950 border border-orange-700 rounded-lg p-1.5 text-orange-100 text-xs"
                        >
                          <option value="needed_immediately">⚠️ مطلوب إرسال عدة فوراً</option>
                          <option value="already_used">✓ تم استخدام عدة الموقع</option>
                          <option value="not_needed">غير مطلوب / تم الاحتواء</option>
                        </select>
                      </div>
                    </div>

                    {/* Chemical Specific MSDS Selection & Quick Safety Button */}
                    {codeOrangeSpillType === 'chemical' && (
                      <div className="bg-slate-950/80 border border-orange-700/60 rounded-xl p-2.5 space-y-2">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                          <div className="flex-1">
                            <label className="block text-[10px] text-orange-300 font-bold mb-1 flex items-center gap-1">
                              <FlaskConical className="w-3.5 h-3.5 text-teal-400" />
                              <span>تحديد المادة الكيميائية المنسكبة (قاعدة بيانات MSDS):</span>
                            </label>
                            <select
                              value={selectedChemicalId}
                              onChange={(e) => setSelectedChemicalId(e.target.value)}
                              className="w-full bg-slate-900 border border-slate-700 focus:border-teal-500 rounded-lg p-1.5 text-slate-100 text-xs font-semibold"
                            >
                              {INITIAL_MSDS_DATABASE.map(chem => (
                                <option key={chem.id} value={chem.id}>
                                  {chem.nameAr} ({chem.nameEn}) - {chem.casNumber}
                                </option>
                              ))}
                              <option value="other">مادة كيميائية أخرى غير مدرجة...</option>
                            </select>
                          </div>

                          {/* Trigger Quick MSDS Safety Modal */}
                          <div className="sm:self-end">
                            <button
                              type="button"
                              onClick={() => setShowMsdsQuickModal(true)}
                              className="w-full sm:w-auto px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-teal-950 transition active:scale-95 cursor-pointer"
                              title="الاطلاع على تدابير الاحتواء والـ PPE والإسعاف قبل التدخل"
                            >
                              <FlaskConical className="w-4 h-4 text-teal-200" />
                              <span>عرض تعليمات الأمان الفورية (MSDS)</span>
                            </button>
                          </div>
                        </div>

                        {selectedChemicalId === 'other' && (
                          <div>
                            <label className="block text-[10px] text-slate-300 font-bold mb-0.5">اسم المادة الكيميائية البديلة:</label>
                            <input
                              type="text"
                              value={customChemicalName}
                              onChange={(e) => setCustomChemicalName(e.target.value)}
                              placeholder="اكتب اسم المادة أو الوصف التجاري..."
                              className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-xs text-slate-100"
                            />
                          </div>
                        )}

                        {/* Fast inline reminder of PPE & Neutralizer */}
                        {currentSelectedChemical && (
                          <div className="bg-slate-900/90 border border-teal-900/50 rounded-lg p-2 text-[10.5px] text-slate-300 flex flex-col sm:flex-row sm:items-center justify-between gap-1.5">
                            <div>
                              <strong className="text-teal-400">🛡️ الوقاية الإلزامية: </strong>
                              <span>{currentSelectedChemical.requiredPpe.gloves} • {currentSelectedChemical.requiredPpe.eyeFace}</span>
                            </div>
                            <div className="text-amber-300 whitespace-nowrap">
                              <strong>المحايدة: </strong>
                              <span>{currentSelectedChemical.spillResponse.neutralizer.slice(0, 40)}...</span>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">تصنيف نوع الحادث (OVR Category):</label>
                  <select
                    value={categoryAr}
                    onChange={(e) => {
                      const val = e.target.value;
                      setCategoryAr(val);
                      if (val.includes('Code Orange') || val.includes('البرتقالي')) {
                        setIsCodeOrange(true);
                      } else {
                        setIsCodeOrange(false);
                      }
                    }}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                  >
                    <option value="النداء البرتقالي - Code Orange للانسكابات">☣️ النداء البرتقالي - Code Orange للانسكابات</option>
                    <option value="أعطال الأجهزة الطبية وسوء الاستخدام">🩺 أعطال الأجهزة الطبية وسوء الاستخدام (Medical Devices)</option>
                    <option value="مخالفات التدخين وحظر التبغ">🚭 مخالفات التدخين وحظر التبغ (Smoking Violation)</option>
                    <option value="اشتباه سرقة أو مواصفات المشتبه بهم">👤 اشتباه سرقة ومواصفات المشتبه بهم (Suspect Profile)</option>
                    <option value="انسكاب سوائل وتعثر">انسكاب سوائل وتعثر</option>
                    <option value="تسرب غاز أو مواد كيميائية">تسرب غاز أو مواد كيميائية (HAZMAT)</option>
                    <option value="شغب أو اعتداء أمني">شغب أو اعتداء أمني على الكادر</option>
                    <option value="عطل في منظومة الإنذار أو الإطفاء">عطل في منظومة الإنذار أو الإطفاء</option>
                    <option value="تماس كهربائي أو انبعاث حرارة">تماس كهربائي أو انبعاث حرارة</option>
                    <option value="خلل في بوابات ومسارات الإسعاف">خلل في بوابات ومسارات الإسعاف</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">مستوى الخطورة المقدر:</label>
                  <select
                    value={severity}
                    onChange={(e) => setSeverity(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100 font-bold"
                  >
                    <option value="low">بسيط (Low Risk)</option>
                    <option value="medium">متوسط (Medium Risk)</option>
                    <option value="high">مرتفع (High Risk)</option>
                    <option value="critical">حرج جداً (Critical Emergency)</option>
                  </select>
                </div>
              </div>

              {/* Sub-panel 1: Medical Device */}
              {categoryAr.includes('الأجهزة الطبية') && (
                <div className="bg-sky-950/40 border border-sky-800/60 rounded-xl p-2.5 space-y-2">
                  <div className="text-sky-300 text-xs font-bold">🩺 بيانات عطل الجهاز الطبي (FMS):</div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <div>
                      <label className="block text-[10px] text-slate-300 mb-0.5">اسم الجهاز الطبي:</label>
                      <input
                        type="text"
                        placeholder="جهاز تنفس، مراقبة..."
                        value={medicalDeviceName}
                        onChange={(e) => setMedicalDeviceName(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-lg p-1.5 text-slate-100"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-300 mb-0.5">كود الأصل / السيريال:</label>
                      <input
                        type="text"
                        placeholder="BME-001..."
                        value={medicalDeviceAssetCode}
                        onChange={(e) => setMedicalDeviceAssetCode(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-lg p-1.5 text-slate-100"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-300 mb-0.5">نوع العطل:</label>
                      <select
                        value={medicalDeviceFailureType}
                        onChange={(e) => setMedicalDeviceFailureType(e.target.value as any)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-lg p-1.5 text-slate-100"
                      >
                        <option value="malfunction">عطل فني مفاجئ</option>
                        <option value="misuse">سوء استخدام أو كسر</option>
                        <option value="power_failure">انقطاع كهرباء</option>
                        <option value="needs_calibration">بحاجة لمعايرة</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* Sub-panel 2: Smoking Violation */}
              {categoryAr.includes('التدخين') && (
                <div className="bg-amber-950/40 border border-amber-800/60 rounded-xl p-2.5 space-y-2">
                  <div className="text-amber-300 text-xs font-bold">🚭 تفاصيل مخالفة التدخين:</div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[10px] text-slate-300 mb-0.5">صفة المخالف:</label>
                      <select
                        value={smokingViolatorType}
                        onChange={(e) => setSmokingViolatorType(e.target.value as any)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-lg p-1.5 text-slate-100"
                      >
                        <option value="visitor">زائر</option>
                        <option value="patient_companion">مرافق مريض</option>
                        <option value="patient">مريض</option>
                        <option value="staff">كادر / موظف</option>
                        <option value="contractor">مقاول صيانة</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-300 mb-0.5">الإجراء المتخذ:</label>
                      <select
                        value={smokingAction}
                        onChange={(e) => setSmokingAction(e.target.value as any)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-lg p-1.5 text-slate-100"
                      >
                        <option value="verbal_warning">إنذار شفهي وإطفاء السيجارة</option>
                        <option value="confiscated">مصادرة الولاعة والسجائر</option>
                        <option value="security_escort">استدعاء الأمن وإخراج المخالف</option>
                        <option value="fine_applied">تطبيق الغرامة النظامية</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* Sub-panel 3: Suspect Profile */}
              {(categoryAr.includes('المشتبه بهم') || categoryAr.includes('سرقة')) && (
                <div className="bg-purple-950/40 border border-purple-800/60 rounded-xl p-2.5 space-y-2">
                  <div className="text-purple-300 text-xs font-bold">👤 مواصفات المشتبه به:</div>
                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
                    <div>
                      <label className="block text-[10px] text-slate-300 mb-0.5">الجنس:</label>
                      <select
                        value={suspectGender}
                        onChange={(e) => setSuspectGender(e.target.value as any)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-lg p-1.5 text-slate-100"
                      >
                        <option value="male">ذكر</option>
                        <option value="female">أنثى</option>
                        <option value="unknown">غير محدد</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-300 mb-0.5">الطول المقدر:</label>
                      <input
                        type="text"
                        placeholder="متوسط 170 سم..."
                        value={suspectHeight}
                        onChange={(e) => setSuspectHeight(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-lg p-1.5 text-slate-100"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-300 mb-0.5">الملابس والمظهر:</label>
                      <input
                        type="text"
                        placeholder="جاكيت، قميص، كاب..."
                        value={suspectClothing}
                        onChange={(e) => setSuspectClothing(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-lg p-1.5 text-slate-100"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-slate-300 mb-0.5">آخر موقع شوهد فيه:</label>
                      <input
                        type="text"
                        placeholder="سلم الطوارئ..."
                        value={suspectLastLocation}
                        onChange={(e) => setSuspectLastLocation(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-lg p-1.5 text-slate-100"
                      />
                    </div>
                  </div>
                </div>
              )}

              <div>
                <label className="text-slate-300 block mb-1 font-semibold">الموقع الدقيق داخل مستشفى أزال:</label>
                <select
                  value={locationDetail}
                  onChange={(e) => setLocationDetail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                >
                  {AZAL_HOSPITAL_LOCATIONS.map((loc, idx) => (
                    <option key={idx} value={loc}>
                      {loc}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-slate-300 font-semibold">وصف وتفاصيل الحادث الميداني:</label>
                  <VoiceDictationButton
                    value={description}
                    onChange={setDescription}
                    showLabel
                    title="إملاء صوتي لتفاصيل الحادث"
                  />
                </div>
                <textarea
                  rows={3}
                  required
                  placeholder="اشرح بدقة ما حدث، الوقت، والأشخاص أو الأجهزة المتأثرة... (يمكنك الإملاء بالصوت)"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 placeholder-slate-500 text-xs focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-slate-300 font-semibold">الإجراء الفوري المتخذ باللحظة:</label>
                  <VoiceDictationButton
                    value={immediateAction}
                    onChange={setImmediateAction}
                    title="إملاء صوتي للإجراء الفوري المتخذ"
                  />
                </div>
                <input
                  type="text"
                  placeholder="مثال: تم إخلاء الغرفة، استدعاء فريق الصيانة، وفصل القاطع الكهربائي..."
                  value={immediateAction}
                  onChange={(e) => setImmediateAction(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-slate-100 text-xs focus:outline-none focus:border-rose-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-lg flex items-center gap-1.5 transition"
                >
                  <Send className="w-4 h-4" />
                  <span>إرسال وتعميم البلاغ</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Safety Incident Notification Modal (Side-by-Side SMS & WhatsApp Support) */}
      {selectedIncidentForDispatch && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 text-right overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl flex flex-col my-auto animate-in fade-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className={`px-5 py-4 border-b flex items-center justify-between ${
              selectedIncidentForDispatch.channel === 'sms'
                ? 'bg-gradient-to-r from-blue-950 via-slate-900 to-slate-900 border-blue-800'
                : 'bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-900 border-emerald-800'
            }`}>
              <div className="flex items-center gap-2.5">
                <div className={`p-2.5 rounded-2xl text-white shadow-lg ${
                  selectedIncidentForDispatch.channel === 'sms'
                    ? 'bg-blue-600 shadow-blue-950'
                    : 'bg-emerald-600 shadow-emerald-950'
                }`}>
                  {selectedIncidentForDispatch.channel === 'sms' ? (
                    <MessageSquare className="w-5 h-5" />
                  ) : (
                    <Send className="w-5 h-5" />
                  )}
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-100 flex items-center gap-1.5">
                    <span>
                      {selectedIncidentForDispatch.channel === 'sms'
                        ? '💬 إرسال إشعار سلامة عبر SMS (شريحة الهاتف)'
                        : '🟢 إرسال إشعار وضع مخالف للسلامة عبر واتساب'}
                    </span>
                  </h3>
                  <p className="text-[11px] text-slate-300">
                    رقم الإشعار: <strong className="text-teal-300 font-mono font-bold">{selectedIncidentForDispatch.incident.id}</strong> • {selectedIncidentForDispatch.incident.codeNumber}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedIncidentForDispatch(null)}
                className="p-1.5 rounded-xl bg-slate-800/80 text-slate-400 hover:text-slate-100 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              {/* Channel Selector Tabs */}
              <div className="grid grid-cols-2 gap-2 bg-slate-950 p-1 rounded-2xl border border-slate-800">
                <button
                  type="button"
                  onClick={() => setSelectedIncidentForDispatch(prev => prev ? { ...prev, channel: 'sms' } : null)}
                  className={`py-2 rounded-xl font-bold flex items-center justify-center gap-2 transition ${
                    selectedIncidentForDispatch.channel === 'sms'
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-950'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <span>💬</span>
                  <span>رسالة SMS موجزة</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedIncidentForDispatch(prev => prev ? { ...prev, channel: 'whatsapp' } : null)}
                  className={`py-2 rounded-xl font-bold flex items-center justify-center gap-2 transition ${
                    selectedIncidentForDispatch.channel === 'whatsapp'
                      ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <span>🟢</span>
                  <span>واتساب تفصيلي</span>
                </button>
              </div>

              {/* Phone Input & Contact Picker */}
              <div>
                <label className="block text-slate-200 font-bold mb-1.5">
                  رقم هاتف المستلم (المسؤول / المشرف المناوب):
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="tel"
                    dir="ltr"
                    value={dispatchRecipientPhone}
                    onChange={(e) => setDispatchRecipientPhone(e.target.value)}
                    placeholder="9677XXXXXXXX (اختياري للإطلاق المباشر)"
                    className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-slate-100 font-mono text-sm focus:outline-none focus:border-teal-500"
                  />
                  <button
                    type="button"
                    onClick={handlePickContact}
                    className="px-3 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 font-bold border border-slate-700 flex items-center gap-1.5 transition shrink-0"
                    title="سحب الرقم تلقائياً من دفتر جهات اتصال الهاتف"
                  >
                    <User className="w-4 h-4" />
                    <span>جهات الاتصال</span>
                  </button>
                </div>
                <span className="text-[10px] text-slate-400 mt-1 block">
                  يمكن ترك الرقم فارغاً لاختيار المستلم مباشرة من داخل التطبيق، أو كتابة الرقم لإرساله له مباشرة.
                </span>
              </div>

              {/* Formatted Message Preview */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-slate-300 font-bold flex items-center gap-1.5">
                    <span>
                      {selectedIncidentForDispatch.channel === 'sms'
                        ? '3. نص رسالة SMS (موجز وتحت حد الأحرف):'
                        : '4. نص رسالة واتساب المنسقة (تفصيلي وشامل):'}
                    </span>
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      const text = selectedIncidentForDispatch.channel === 'sms'
                        ? generateIncidentSMSText(selectedIncidentForDispatch.incident)
                        : generateIncidentWhatsAppText(selectedIncidentForDispatch.incident);
                      handleCopyText(text);
                    }}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-teal-300 text-[11px] font-bold flex items-center gap-1 transition"
                  >
                    {copiedNotice ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedNotice ? 'تم النسخ بنجاح!' : 'نسخ النص'}</span>
                  </button>
                </div>

                <div className="bg-slate-950 border border-slate-800 rounded-xl p-3.5 space-y-1 font-mono text-[11px] text-slate-200 whitespace-pre-wrap leading-relaxed max-h-48 overflow-y-auto select-text dir-rtl">
                  {selectedIncidentForDispatch.channel === 'sms'
                    ? generateIncidentSMSText(selectedIncidentForDispatch.incident)
                    : generateIncidentWhatsAppText(selectedIncidentForDispatch.incident)}
                </div>
              </div>

              {/* Direct Link Protocol & Encoding Details */}
              <div className={`rounded-xl p-3 text-[11px] border flex items-start gap-2.5 ${
                selectedIncidentForDispatch.channel === 'sms'
                  ? 'bg-blue-950/30 border-blue-800/60 text-blue-200'
                  : 'bg-emerald-950/30 border-emerald-800/60 text-emerald-200'
              }`}>
                <Smartphone className="w-4 h-4 shrink-0 mt-0.5" />
                <div className="space-y-1.5 w-full">
                  <div className="flex items-center justify-between">
                    <p className="font-bold">
                      {selectedIncidentForDispatch.channel === 'sms'
                        ? 'الرابط المباشر لشريحة الهاتف (Native SMS with encodeURIComponent):'
                        : 'رابط واتساب المباشر (wa.me with encodeURIComponent):'}
                    </p>
                    <a
                      href={selectedIncidentForDispatch.channel === 'sms'
                        ? getIncidentSMSUri(
                            dispatchRecipientPhone,
                            generateIncidentSMSText(selectedIncidentForDispatch.incident)
                          )
                        : getIncidentWhatsAppUrl(
                            dispatchRecipientPhone,
                            generateIncidentWhatsAppText(selectedIncidentForDispatch.incident)
                          )
                      }
                      target={selectedIncidentForDispatch.channel === 'whatsapp' ? '_blank' : undefined}
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 font-bold underline hover:opacity-80 text-[10px]"
                    >
                      <ExternalLink className="w-3 h-3" />
                      <span>فتح الرابط مباشرة</span>
                    </a>
                  </div>

                  <div className="bg-slate-950/90 p-2 rounded text-[10px] font-mono dir-ltr text-left break-all text-slate-300 border border-slate-800 select-all">
                    {selectedIncidentForDispatch.channel === 'sms'
                      ? getIncidentSMSUri(
                          dispatchRecipientPhone,
                          generateIncidentSMSText(selectedIncidentForDispatch.incident)
                        )
                      : getIncidentWhatsAppUrl(
                          dispatchRecipientPhone,
                          generateIncidentWhatsAppText(selectedIncidentForDispatch.incident)
                        )}
                  </div>
                </div>
              </div>

              {/* Modal Actions */}
              <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setSelectedIncidentForDispatch(null)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold transition"
                >
                  إلغاء
                </button>
                <button
                  type="button"
                  onClick={handleExecuteDispatch}
                  className={`px-5 py-2.5 rounded-xl font-bold flex items-center gap-2 shadow-lg transition active:scale-95 text-white ${
                    selectedIncidentForDispatch.channel === 'sms'
                      ? 'bg-blue-600 hover:bg-blue-500 shadow-blue-950'
                      : 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-950'
                  }`}
                >
                  {selectedIncidentForDispatch.channel === 'sms' ? (
                    <>
                      <MessageSquare className="w-4 h-4" />
                      <span>إرسال SMS عبر شريحة الهاتف</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>إرسال عبر واتساب (wa.me)</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Public Incident Portal QR Code & Sharing Modal */}
      {showPublicPortalQrModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-teal-600/50 rounded-3xl max-w-sm w-full p-5 sm:p-6 text-center space-y-4 shadow-2xl animate-in zoom-in-95">
            {/* Real scannable QR Code */}
            <div className="bg-white p-3 rounded-2xl inline-block shadow-lg mx-auto border-2 border-teal-200">
              <img
                src={`https://api.qrserver.com/v1/create-qr-code/?size=320x320&margin=4&data=${encodeURIComponent(portalUrl)}`}
                alt="رمز QR بوابة الخدمات والتصاريح الموحدة - مستشفى آزال"
                className="w-48 h-48 sm:w-52 sm:h-52 mx-auto object-contain block"
                loading="eager"
              />
            </div>

            <div>
              <h3 className="text-sm font-bold text-teal-300 flex items-center justify-center gap-1.5">
                <QrCode className="w-4 h-4 text-amber-400" />
                <span>رمز QR بوابة الخدمات والتصاريح الموحدة</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                رمز حقيقي معتمد قابل للمسح بأي هاتف ذكي لفتح بوابة الخدمات والتصاريح والبلاغات الفورية (#services).
              </p>
            </div>

            {/* Direct Link Field & Sharing */}
            <div className="space-y-2.5 text-right">
              <div>
                <label className="text-[11px] font-bold text-slate-300 block mb-1">
                  الرابط الهدف المباشر (Target URL):
                </label>
                <div className="bg-slate-950 border border-teal-800 rounded-xl p-2 focus-within:border-teal-500 shadow-inner">
                  <input
                    type="text"
                    readOnly
                    value={portalUrl}
                    onClick={(e) => (e.target as HTMLInputElement).select()}
                    dir="ltr"
                    className="w-full bg-transparent text-teal-300 font-mono text-xs px-1 py-0.5 outline-none select-all font-semibold"
                  />
                </div>
                <span className="text-[10px] text-slate-400 mt-1 block">
                  ⚡ الرابط المعتمد لمسح الـ QR والفتح الفوري لبوابة الخدمات والتصاريح الموحدة (#services).
                </span>
              </div>

              {/* Prominent Copy Button */}
              <button
                type="button"
                onClick={handleCopyPortalLink}
                className={`w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition active:scale-95 ${
                  copiedPortalLink
                    ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/40'
                    : 'bg-teal-600 hover:bg-teal-500 text-white shadow-md shadow-teal-900/30'
                }`}
              >
                {copiedPortalLink ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-100" />
                    <span>تم نسخ الرابط بنجاح!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    <span>📋 نسخ رابط البوابة</span>
                  </>
                )}
              </button>

              {/* Side-by-Side Share Buttons: WhatsApp & SMS */}
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={handleSharePortalWhatsApp}
                  className="py-2.5 px-3 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition shadow-md shadow-emerald-950/40 active:scale-95"
                >
                  <MessageCircle className="w-4 h-4 text-emerald-200" />
                  <span>🟢 مشاركة واتساب</span>
                </button>

                <button
                  type="button"
                  onClick={handleSharePortalSMS}
                  className="py-2.5 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition shadow-md shadow-blue-950/40 active:scale-95"
                >
                  <Smartphone className="w-4 h-4 text-blue-200" />
                  <span>💬 إرسال SMS</span>
                </button>
              </div>

              {/* Direct Open in New Window Link */}
              <a
                href={portalUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2 rounded-xl bg-slate-950 hover:bg-slate-800 text-slate-300 hover:text-white font-bold text-[11px] border border-slate-700 flex items-center justify-center gap-1.5 transition"
              >
                <ExternalLink className="w-3.5 h-3.5 text-teal-400" />
                <span>تجربة وفتح الرابط في نافذة جديدة مباشرة</span>
              </a>
            </div>

            {/* Print & Close */}
            <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={handlePrintQrPoster}
                className="flex-1 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center gap-1.5 transition border border-slate-700"
              >
                <Printer className="w-4 h-4 text-teal-400" />
                <span>طباعة الملصق (A4 Poster / PDF)</span>
              </button>
              <button
                type="button"
                onClick={() => setShowPublicPortalQrModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 font-bold text-xs transition"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Quick MSDS Containment Instructions Modal for Code Orange */}
      {showMsdsQuickModal && currentSelectedChemical && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/80 backdrop-blur-md overflow-y-auto animate-fadeIn">
          <div className="bg-slate-900 border border-teal-700 rounded-2xl max-w-2xl w-full p-4 sm:p-5 shadow-2xl space-y-3.5 my-6 max-h-[92vh] flex flex-col">
            {/* Modal Header */}
            <div className="flex items-start justify-between border-b border-slate-800 pb-2.5">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-teal-950 border border-teal-700 text-teal-300">
                  <FlaskConical className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-base sm:text-lg font-black text-white">
                      تعليمات السلامة الفورية (MSDS) - {currentSelectedChemical.nameAr}
                    </h3>
                    <span className="bg-teal-500/20 text-teal-300 border border-teal-500/40 text-[9px] font-bold px-2 py-0.5 rounded">
                      FMS-APP-070EA
                    </span>
                  </div>
                  <p className="text-xs text-teal-400 font-mono">
                    {currentSelectedChemical.nameEn} • CAS: {currentSelectedChemical.casNumber}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowMsdsQuickModal(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable Modal Content */}
            <div className="overflow-y-auto space-y-3 pr-1 text-xs scrollbar-thin">
              {/* Alert Warning */}
              <div className="bg-orange-950/40 border border-orange-700/60 rounded-xl p-3 flex items-start gap-2.5">
                <AlertTriangle className="w-5 h-5 text-orange-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-orange-300 text-xs mb-0.5">
                    تنبيه أمان قبل التدخل الميداني:
                  </h4>
                  <p className="text-[11px] text-orange-200/90 leading-relaxed">
                    يمنع منعاً باتاً مباشرة تنظيف أي انسكاب كيميائي دون ارتداء كامل مهمات الوقاية الشخصية المحددة أدناه وتوفير مادة المحايدة.
                  </p>
                </div>
              </div>

              {/* Mandatory PPE */}
              <div className="bg-slate-950 border border-teal-800/60 rounded-xl p-3 space-y-2">
                <div className="text-xs font-bold text-teal-300 flex items-center gap-1.5">
                  <Shield className="w-4 h-4 text-teal-400" />
                  <span>مهمات الوقاية الشخصية الإلزامية (PPE):</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                  <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                    <strong className="text-teal-400 block mb-0.5">🧤 حماية اليدين (القفازات):</strong>
                    <span className="text-slate-200">{currentSelectedChemical.requiredPpe.gloves}</span>
                  </div>
                  <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                    <strong className="text-teal-400 block mb-0.5">👁️ العين والوجه:</strong>
                    <span className="text-slate-200">{currentSelectedChemical.requiredPpe.eyeFace}</span>
                  </div>
                  <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                    <strong className="text-teal-400 block mb-0.5">🫁 الحماية التنفسية:</strong>
                    <span className="text-slate-200">{currentSelectedChemical.requiredPpe.respiratory}</span>
                  </div>
                  <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                    <strong className="text-teal-400 block mb-0.5">🦺 رداء الجسم:</strong>
                    <span className="text-slate-200">{currentSelectedChemical.requiredPpe.body}</span>
                  </div>
                </div>
              </div>

              {/* Spill Containment & Neutralizer */}
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 space-y-2 text-[11px]">
                <div className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                  <span>☣️</span>
                  <span>إجراءات الاحتواء والمحايدة المعتمدة:</span>
                </div>
                <div className="space-y-1.5 text-slate-200">
                  <p>
                    <strong className="text-teal-300">مادة المحايدة / التثبيت:</strong> {currentSelectedChemical.spillResponse.neutralizer}
                  </p>
                  <p>
                    <strong className="text-teal-300">الانسكاب البسيط:</strong> {currentSelectedChemical.spillResponse.minorSpill}
                  </p>
                  <p>
                    <strong className="text-orange-400">الانسكاب الكبير:</strong> {currentSelectedChemical.spillResponse.majorSpill}
                  </p>
                  <p>
                    <strong className="text-teal-300">عدة الانسكاب المطلوبة:</strong> {currentSelectedChemical.spillResponse.spillKitRequired}
                  </p>
                </div>
              </div>

              {/* First Aid */}
              <div className="bg-rose-950/20 border border-rose-900/60 rounded-xl p-3 space-y-1.5 text-[11px]">
                <div className="text-xs font-bold text-rose-300 flex items-center gap-1.5">
                  <HeartPulse className="w-4 h-4 text-rose-400" />
                  <span>الإسعاف الأولي الطارئ في حال التعرض:</span>
                </div>
                <p className="text-slate-200">
                  <strong className="text-rose-400">ملامسة العينين:</strong> {currentSelectedChemical.firstAid.eyeContact}
                </p>
                <p className="text-slate-200">
                  <strong className="text-rose-400">ملامسة الجلد:</strong> {currentSelectedChemical.firstAid.skinContact}
                </p>
                <p className="text-slate-200">
                  <strong className="text-rose-400">الاستنشاق:</strong> {currentSelectedChemical.firstAid.inhalation}
                </p>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="pt-2.5 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-2">
              <div className="text-slate-400 text-[11px]">
                طوارئ السلامة: <strong className="text-white font-mono">{AZAL_SAFETY_EMERGENCY_PHONE}</strong>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                <button
                  type="button"
                  onClick={() => {
                    const containmentText = `[تدابير MSDS]: تم ارتداء (${currentSelectedChemical.requiredPpe.gloves})، واستخدام مادة المحايدة (${currentSelectedChemical.spillResponse.neutralizer}).`;
                    setImmediateAction(prev => prev ? `${prev} - ${containmentText}` : containmentText);
                    triggerSuccessFeedback();
                    setShowMsdsQuickModal(false);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs transition shadow cursor-pointer"
                >
                  ✓ تضمين التدابير في الإجراء الفوري
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setShowMsdsQuickModal(false);
                    if (typeof window !== 'undefined') {
                      window.location.hash = `#msds?id=${currentSelectedChemical.id}`;
                    }
                  }}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 font-bold text-xs border border-teal-800 transition cursor-pointer"
                >
                  فتح بطاقة الـ MSDS الكاملة ↗
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Prominent Incident Confirmation Modal (نافذة تأكيد بارزة تحوي زري واتساب + SMS احتياطي) */}
      {showConfirmationModal && submittedIncidentForConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200" dir="rtl">
          <div className="bg-slate-900 border-2 border-emerald-500 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4 text-center">
            <div className="w-16 h-16 rounded-full bg-emerald-950 border-2 border-emerald-500 text-emerald-400 flex items-center justify-center mx-auto shadow-lg shadow-emerald-900/50">
              <CheckCircle2 className="w-9 h-9" />
            </div>

            <div className="space-y-1">
              <h3 className="text-lg font-black text-white">
                تم توثيق وحفظ بلاغ الحادث (OVR) بنجاح
              </h3>
              <p className="text-xs text-emerald-300 font-medium">
                تم الحفظ الفوري في قاعدة البيانات مع دعم التخزين المحلي (IndexedDB)
              </p>
            </div>

            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-3.5 text-right text-xs space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">رقم البلاغ المرمز:</span>
                <span className="font-mono font-black text-emerald-400 text-sm bg-emerald-950 px-2.5 py-0.5 rounded-lg border border-emerald-800">
                  {submittedIncidentForConfirm.codeNumber}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">الموقع والقسم:</span>
                <span className="font-bold text-slate-200">
                  {submittedIncidentForConfirm.locationDetail} ({submittedIncidentForConfirm.department})
                </span>
              </div>
              <div className="flex justify-between items-center text-[11px]">
                <span className="text-slate-400">رقم طوارئ السلامة المعتمد:</span>
                <span className="font-mono font-bold text-amber-300 text-xs">96777738138</span>
              </div>
            </div>

            <div className="space-y-2 pt-2">
              <a
                href={`https://api.whatsapp.com/send?phone=96777738138&text=${encodeURIComponent(
                  `*🚨 بلاغ حادث وواقعة أمن وسلامة (OVR) - مستشفى آزال النموذجي*\n` +
                  `━━━━━━━━━━━━━━━━━━━━\n` +
                  `🆔 *رقم البلاغ:* ${submittedIncidentForConfirm.codeNumber} (#${submittedIncidentForConfirm.id})\n` +
                  `📍 *الموقع:* ${submittedIncidentForConfirm.locationDetail} (${submittedIncidentForConfirm.department})\n` +
                  `⚠️ *التصنيف:* ${submittedIncidentForConfirm.categoryAr}\n` +
                  `🚨 *درجة الخطورة:* ${submittedIncidentForConfirm.severity === 'critical' ? 'حرج جداً ✖' : submittedIncidentForConfirm.severity === 'high' ? 'مرتفع ⚠' : 'متوسط'}\n` +
                  `📝 *الوصف:* ${submittedIncidentForConfirm.description}\n` +
                  `⚡ *الإجراء الفوري:* ${submittedIncidentForConfirm.immediateAction}\n` +
                  `👤 *المُبلّغ:* ${submittedIncidentForConfirm.reportedBy}\n` +
                  `🕒 *الوقت:* ${submittedIncidentForConfirm.reportedAt}\n` +
                  `━━━━━━━━━━━━━━━━━━━━\n` +
                  `🚨 طوارئ السلامة المعتمدة: 96777738138`
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-950 flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <MessageCircle className="w-4 h-4" />
                <span>إرسال عبر الواتساب مباشرة (96777738138)</span>
              </a>

              <a
                href={`sms:96777738138?body=${encodeURIComponent(
                  `بلاغ حادث سلامة مستشفى آزال (${submittedIncidentForConfirm.codeNumber}) - الموقع: ${submittedIncidentForConfirm.locationDetail} - ${submittedIncidentForConfirm.description.slice(0, 70)}`
                )}`}
                className="w-full py-3 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center gap-2 border border-slate-700 transition"
              >
                <Smartphone className="w-4 h-4 text-amber-400" />
                <span>إرسال رسالة SMS احتياطية (777738138)</span>
              </a>

              <button
                type="button"
                onClick={() => {
                  setShowConfirmationModal(false);
                  setSubmittedIncidentForConfirm(null);
                }}
                className="w-full py-2.5 rounded-2xl bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white text-xs font-semibold transition cursor-pointer"
              >
                إغلاق والعودة للسجلات
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
