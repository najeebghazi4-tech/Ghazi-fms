import React, { useState, useEffect } from 'react';
import { 
  X, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldCheck, 
  Printer, 
  Save, 
  Clock, 
  User, 
  Building2, 
  Lock, 
  Unlock,
  Key, 
  Activity, 
  Wrench, 
  Calendar,
  Layers,
  FileText
} from 'lucide-react';
import { PpmAsset } from '../data/azalPpmAssetsData';
import { AntiFraudScanProof, computeNextDueDate } from '../utils/ppmDueEngine';
import { executeSmartPrint } from '../utils/printUtils';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';
import { supabase, verifyDepartmentPin } from '../services/supabaseClient';
import { getStoredDepartmentSession, saveDepartmentSession } from './DepartmentPinLogin';

interface SecurePpmLiveInspectionModalProps {
  asset: PpmAsset;
  scanProof?: AntiFraudScanProof | null;
  technicianName?: string;
  onClose: () => void;
  onSaveSuccess: (updatedAsset: PpmAsset, auditRecord: any) => void;
}

export const SecurePpmLiveInspectionModal: React.FC<SecurePpmLiveInspectionModalProps> = ({
  asset,
  scanProof,
  technicianName = '',
  onClose,
  onSaveSuccess,
}) => {
  // 1. Identification & PIN Security State
  const [engineerName, setEngineerName] = useState(technicianName || '');
  const [securityPin, setSecurityPin] = useState('');
  const [isVerifyingPin, setIsVerifyingPin] = useState(false);
  const [isPinVerified, setIsPinVerified] = useState(false);
  const [pinError, setPinError] = useState<string | null>(null);
  const [verifiedDepartmentName, setVerifiedDepartmentName] = useState<string>('');

  // Auto-verify if already authenticated for this department in sessionStorage
  useEffect(() => {
    const session = getStoredDepartmentSession();
    if (session) {
      if (!engineerName && session.engineerName) {
        setEngineerName(session.engineerName);
      }
      if (session.departmentId === asset.category) {
        setIsPinVerified(true);
        setVerifiedDepartmentName(session.departmentNameAr || asset.categoryNameAr);
      }
    }
  }, [asset.category]);

  // 2. Inspection State
  const [deviceStatus, setDeviceStatus] = useState<'يعمل بكفاءة' | 'يحتاج إصلاح'>('يعمل بكفاءة');
  const [technicalReadings, setTechnicalReadings] = useState('');
  const [notesAndObservations, setNotesAndObservations] = useState('');

  // 3. Supplemental checklist steps
  const [checklistValues, setChecklistValues] = useState<Record<number, { status: 'pass' | 'fail' | 'na'; reading: string }>>(() => {
    const initial: Record<number, { status: 'pass' | 'fail' | 'na'; reading: string }> = {};
    asset.checklist_steps?.forEach((step) => {
      initial[step.id] = { status: 'pass', reading: step.expected_value || 'سليم ومطابق' };
    });
    return initial;
  });

  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccessNotice, setSaveSuccessNotice] = useState(false);

  // Automatic timestamping
  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];
  const timeStr = now.toLocaleTimeString('ar-YE', { hour: '2-digit', minute: '2-digit', hour12: true });
  const fullDateTimeDisplay = `${todayStr} • الساعة ${timeStr}`;

  // Auto-calculated next due date
  const computedNextDue = computeNextDueDate(todayStr, asset.frequency);

  // Live PIN Verification logic against department_access_pins in Supabase
  const handleVerifyPin = async (pinToVerify?: string) => {
    const pin = (pinToVerify !== undefined ? pinToVerify : securityPin).trim();
    if (!pin) {
      setPinError('يرجى إدخال رمز المرور السري (PIN) الخاص بالقسم.');
      setIsPinVerified(false);
      return false;
    }

    setIsVerifyingPin(true);
    setPinError(null);

    try {
      const result = await verifyDepartmentPin(asset.category, pin);
      if (result.valid) {
        setIsPinVerified(true);
        setPinError(null);
        setVerifiedDepartmentName(result.departmentName || asset.categoryNameAr);
        // Persist session in sessionStorage
        if (engineerName.trim()) {
          saveDepartmentSession({
            engineerName: engineerName.trim(),
            departmentId: asset.category,
            departmentCode: asset.category,
            departmentNameAr: result.departmentName || asset.categoryNameAr,
            departmentNameEn: asset.category,
            token: `PIN-SEC-${Date.now()}`,
            loginTime: new Date().toISOString()
          });
        }
        return true;
      } else {
        setIsPinVerified(false);
        setPinError(result.message || 'عفواً، رمز المرور غير صحيح أو لا ينتمي لهذا القسم');
        return false;
      }
    } catch (err) {
      setIsPinVerified(false);
      setPinError('حدث خطأ أثناء التحقق من الرمز في خادم Supabase. يرجى المحاولة ثانية.');
      return false;
    } finally {
      setIsVerifyingPin(false);
    }
  };

  // Quick helper for step checklist
  const handleStepStatusChange = (stepId: number, status: 'pass' | 'fail' | 'na') => {
    setChecklistValues((prev) => ({
      ...prev,
      [stepId]: { ...prev[stepId], status }
    }));
  };

  // Handle Save
  const handleSaveInspection = async (e: React.FormEvent) => {
    e.preventDefault();
    setPinError(null);

    if (!isPinVerified) {
      const isValid = await handleVerifyPin();
      if (!isValid) {
        return;
      }
    }

    if (!engineerName.trim()) {
      setPinError('يرجى كتابة اسم المهندس أو الفني المسؤول عن الفحص.');
      return;
    }

    setIsSaving(true);

    try {
      // 1. Prepare updated asset record
      const updatedAsset: PpmAsset = {
        ...asset,
        last_pm_date: todayStr,
        next_pm_due: computedNextDue,
        notes: notesAndObservations || asset.notes,
      };

      // 2. Prepare official audit record
      const auditRecord = {
        id: `ppm-audit-${Date.now()}`,
        asset_id: asset.id,
        asset_tag: asset.asset_tag,
        asset_name: asset.name,
        department: asset.categoryNameAr,
        department_id: asset.category,
        inspection_date: todayStr,
        inspection_time: timeStr,
        full_timestamp: new Date().toISOString(),
        engineer_name: engineerName.trim(),
        security_pin_verified: true,
        device_status: deviceStatus,
        technical_readings: technicalReadings.trim() || 'القراءات الفنية ضمن الحدود المعيارية الطبيعية',
        notes_observations: notesAndObservations.trim() || 'تم الفحص والمعايرة وتثبيت لاصق الصيانة المعتمد',
        next_pm_due: computedNextDue,
        frequency: asset.frequency,
        location: asset.location,
        scan_proof_token: scanProof?.token || `LIVE-CAM-${Date.now()}`,
        integrity_hash: scanProof?.integrityHash || 'VERIFIED-LIVE-MEDIASENSOR',
        created_at: new Date().toISOString()
      };

      // 3. Save to Supabase (and local storage fallback)
      try {
        await supabase.from('pm_audit_records').insert([auditRecord]);
      } catch (err) {
        console.warn('Supabase audit record insert warning:', err);
      }

      try {
        await supabase.from('ppm_assets').update({
          last_pm_date: todayStr,
          next_pm_due: computedNextDue,
          last_status: deviceStatus,
          last_engineer: engineerName.trim(),
          notes: notesAndObservations || asset.notes,
        }).eq('id', asset.id);
      } catch (err) {
        console.warn('Supabase ppm_assets update warning:', err);
      }

      // Also mirror to equipment_inventory if present
      try {
        await supabase.from('equipment_inventory').update({
          last_pm_date: todayStr,
          next_pm_due: computedNextDue,
          status: deviceStatus === 'يعمل بكفاءة' ? 'operational' : 'needs_maintenance'
        }).eq('asset_tag', asset.asset_tag);
      } catch (err) {
        // non-blocking
      }

      triggerSuccessFeedback();
      setSaveSuccessNotice(true);

      setTimeout(() => {
        onSaveSuccess(updatedAsset, auditRecord);
      }, 700);

    } catch (err) {
      console.error('Save inspection error:', err);
      setPinError('حدث خطأ أثناء حفظ الفحص في قاعدة البيانات. يرجى المحاولة مجدداً.');
    } finally {
      setIsSaving(false);
    }
  };

  // Print Official Inspection Form
  const handlePrintAuditForm = () => {
    const htmlContent = `
      <div style="font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif; direction: rtl; padding: 25px; color: #1e293b; max-width: 800px; margin: 0 auto; border: 2px solid #0284c7; border-radius: 12px;">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #0284c7; padding-bottom: 12px; margin-bottom: 20px;">
          <div>
            <h1 style="margin: 0; font-size: 20px; color: #0f172a;">مستشفى آزال النموذجي - الإدارة العامة للسلامة والصيانة</h1>
            <p style="margin: 3px 0 0; font-size: 13px; color: #64748b;">استمارة فحص الصيانة الوقائية الدورية الميدانية (PPM Inspection Record)</p>
          </div>
          <div style="text-align: left; font-size: 12px; color: #475569;">
            <div><strong>كود التوثيق:</strong> ${asset.asset_tag}</div>
            <div><strong>التاريخ:</strong> ${todayStr}</div>
          </div>
        </div>

        <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 15px; margin-bottom: 20px;">
          <h3 style="margin-top: 0; font-size: 14px; color: #0369a1; border-bottom: 1px solid #cbd5e1; padding-bottom: 6px;">1. بيانات الجهاز والموقع الهندسي:</h3>
          <table style="width: 100%; font-size: 13px; line-height: 1.8;">
            <tr>
              <td style="width: 25%;"><strong>اسم الجهاز:</strong></td>
              <td style="width: 25%;">${asset.name}</td>
              <td style="width: 25%;"><strong>رقم الباركود (Tag):</strong></td>
              <td style="width: 25%; font-family: monospace;">${asset.asset_tag}</td>
            </tr>
            <tr>
              <td><strong>القسم الهندسي:</strong></td>
              <td>${asset.categoryNameAr}</td>
              <td><strong>الموقع والمبنى:</strong></td>
              <td>${asset.location}</td>
            </tr>
            <tr>
              <td><strong>دورية الفحص:</strong></td>
              <td>${asset.frequency}</td>
              <td><strong>الطراز / السيريال:</strong></td>
              <td>${asset.model || '-'} / ${asset.serial_number || '-'}</td>
            </tr>
          </table>
        </div>

        <div style="background-color: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 15px; margin-bottom: 20px;">
          <h3 style="margin-top: 0; font-size: 14px; color: #166534; border-bottom: 1px solid #86efac; padding-bottom: 6px;">2. نتائج الفحص الهندسي والتشغيلي:</h3>
          <table style="width: 100%; font-size: 13px; line-height: 1.8;">
            <tr>
              <td style="width: 30%;"><strong>حالة الجهاز بعد الفحص:</strong></td>
              <td style="color: ${deviceStatus === 'يعمل بكفاءة' ? '#16a34a' : '#dc2626'}; font-weight: bold;">
                ${deviceStatus === 'يعمل بكفاءة' ? '✓ يعمل بكفاءة ومطابق للمعايير' : '⚠ يحتاج تدخل وإصلاح عاجل'}
              </td>
            </tr>
            <tr>
              <td><strong>القراءات والقياسات الفنية:</strong></td>
              <td>${technicalReadings || 'القراءات الفنية ضمن الحدود المعيارية الطبيعية'}</td>
            </tr>
            <tr>
              <td><strong>الملاحظات والتوصيات:</strong></td>
              <td>${notesAndObservations || 'تم الفحص والمعايرة وتثبيت لاصق الصيانة المعتمد'}</td>
            </tr>
            <tr>
              <td><strong>تاريخ الفحص القادم المجدول:</strong></td>
              <td style="font-weight: bold; color: #0284c7;">${computedNextDue}</td>
            </tr>
          </table>
        </div>

        <div style="border: 1px dashed #94a3b8; border-radius: 8px; padding: 12px; margin-bottom: 20px; font-size: 11px; color: #475569; background: #fff;">
          <strong>شهادة التحقق الحي الميداني (Live Camera Verified):</strong>
          <div style="font-family: monospace; font-size: 10px; margin-top: 4px; color: #059669;">
            رمز التوثيق الرقمي: ${scanProof?.token || 'LIVE-SCAN-AUTHORIZED'} | البصمة: ${scanProof?.integrityHash || 'SHA256-MEDIASENSOR-VERIFIED'}
          </div>
        </div>

        <div style="display: flex; justify-content: space-between; margin-top: 30px; padding-top: 15px; border-top: 1px solid #cbd5e1;">
          <div style="text-align: center; width: 45%;">
            <p style="margin: 0; font-size: 12px; color: #64748b;">اسم وتوقيع المهندس / الفني القائم بالفحص</p>
            <p style="margin: 15px 0 0; font-size: 14px; font-weight: bold; color: #0f172a;">${engineerName || 'م. فني الصيانة الوقائية'}</p>
          </div>
          <div style="text-align: center; width: 45%;">
            <p style="margin: 0; font-size: 12px; color: #64748b;">اعتماد رئيس قسم السلامة والصيانة العامة</p>
            <p style="margin: 15px 0 0; font-size: 14px; font-weight: bold; color: #0f172a;">م. نجيب غازي / د. محمد السراجي</p>
          </div>
        </div>
      </div>
    `;
    executeSmartPrint(htmlContent, {
      title: `استمارة فحص الصيانة الوقائية (${asset.asset_tag})`,
      subtitle: `فحص دوري معتمد لقسم ${asset.categoryNameAr}`,
      refNumber: asset.asset_tag,
      department: asset.categoryNameAr,
      inspectorName: engineerName || 'م. فني الصيانة الوقائية'
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-sm overflow-y-auto" dir="rtl">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl shadow-black/80 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-teal-500/15 border border-teal-500/30 flex items-center justify-center text-teal-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold text-white">
                  استمارة فحص الصيانة الوقائية (PPM)
                </h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-500/20 text-teal-300 border border-teal-500/40">
                  ميداني مباشر
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-teal-400" />
                <span>التاريخ والوقت: {fullDateTimeDisplay}</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition"
            title="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <form onSubmit={handleSaveInspection} className="p-5 space-y-5 overflow-y-auto flex-1 custom-scrollbar">
          
          {/* 1. Asset Details Summary & Automatically Detected Department */}
          <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-2.5">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-cyan-400" />
                <h4 className="text-xs sm:text-sm font-bold text-white">
                  بيانات الجهاز والجهة التابع لها (تم التعرف تلقائياً من الباركود):
                </h4>
              </div>
              <span className="px-2.5 py-1 rounded-xl bg-cyan-950/70 border border-cyan-700/60 text-cyan-300 text-xs font-mono font-bold">
                {asset.asset_tag}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                <span className="text-slate-400 block text-[11px]">اسم الجهاز والمعدة:</span>
                <strong className="text-white text-sm block mt-0.5">{asset.name}</strong>
              </div>

              {/* Highlighted Detected Department */}
              <div className="bg-cyan-950/40 p-2.5 rounded-xl border border-cyan-800/60">
                <span className="text-cyan-300 font-semibold block text-[11px] flex items-center gap-1">
                  <Building2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>القسم التابع له الجهاز (تلقائي):</span>
                </span>
                <strong className="text-amber-300 text-sm block mt-0.5 font-bold">
                  {asset.categoryNameAr}
                </strong>
              </div>

              <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                <span className="text-slate-400 block text-[11px]">الموقع والمبنى:</span>
                <strong className="text-slate-200 text-sm block mt-0.5">{asset.location}</strong>
              </div>

              <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                <span className="text-slate-400 block text-[11px]">دورية الفحص المعتمدة:</span>
                <span className="text-teal-300 font-bold block mt-0.5">{asset.frequency}</span>
              </div>
            </div>
          </div>

          {/* 2. Department PIN Authentication (Mandatory Security Requirement) */}
          <div className={`rounded-2xl p-4 space-y-3.5 transition border ${
            isPinVerified 
              ? 'bg-emerald-950/30 border-emerald-600/60 shadow-lg shadow-emerald-950/30' 
              : 'bg-slate-950/80 border-amber-500/40 shadow-lg shadow-amber-950/20'
          }`}>
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
              <div className="flex items-center gap-2">
                <Key className={`w-4 h-4 ${isPinVerified ? 'text-emerald-400' : 'text-amber-400'}`} />
                <h4 className="text-xs sm:text-sm font-bold text-white">
                  التحقق من هوية القسم ورمز المرور السري (Department Access PIN):
                </h4>
              </div>
              {isPinVerified ? (
                <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/50 text-xs font-bold flex items-center gap-1.5">
                  <Unlock className="w-3.5 h-3.5" />
                  <span>الاستمارة مفتوحة ومصرح بها ✓</span>
                </span>
              ) : (
                <span className="px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-bold flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5" />
                  <span>مقفلة بانتظار الرمز</span>
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Engineer Name */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-teal-400" />
                  <span>اسم المهندس / الفني الفاحص:</span>
                  <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={engineerName}
                  onChange={(e) => setEngineerName(e.target.value)}
                  placeholder="اكتب اسم المهندس الفاحص..."
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-teal-500 transition"
                  required
                />
              </div>

              {/* Department Access PIN */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5 text-amber-400" />
                    <span className="text-amber-300 font-bold">
                      أدخل رمز المرور السري (PIN) الخاص بقسم {asset.categoryNameAr}:
                    </span>
                    <span className="text-rose-400">*</span>
                  </span>
                </label>
                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <input
                      type="password"
                      inputMode="numeric"
                      maxLength={10}
                      value={securityPin}
                      onChange={(e) => {
                        const val = e.target.value;
                        setSecurityPin(val);
                        if (pinError) setPinError(null);
                        if (isPinVerified) setIsPinVerified(false);
                      }}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleVerifyPin();
                        }
                      }}
                      placeholder={`أدخل رمز PIN لقسم ${asset.categoryNameAr}`}
                      className={`w-full bg-slate-900 border rounded-xl px-3.5 py-2.5 text-sm text-white font-mono tracking-widest focus:outline-none transition ${
                        isPinVerified 
                          ? 'border-emerald-500/80 bg-emerald-950/20 text-emerald-300' 
                          : pinError 
                            ? 'border-rose-500 bg-rose-950/20' 
                            : 'border-slate-700 focus:border-amber-400'
                      }`}
                      required
                    />
                    {isPinVerified && (
                      <span className="absolute left-3 top-2.5 text-emerald-400 text-xs font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>معتمد</span>
                      </span>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={() => handleVerifyPin()}
                    disabled={isVerifyingPin || !securityPin.trim()}
                    className={`px-3.5 py-2.5 rounded-xl font-bold text-xs shrink-0 transition flex items-center gap-1.5 ${
                      isPinVerified
                        ? 'bg-emerald-600/30 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-600/40'
                        : 'bg-amber-600 hover:bg-amber-500 text-white shadow-md active:scale-95'
                    }`}
                  >
                    {isVerifyingPin ? (
                      <div className="w-3.5 h-3.5 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                    ) : isPinVerified ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>تم التحقق</span>
                      </>
                    ) : (
                      <>
                        <Key className="w-3.5 h-3.5" />
                        <span>تحقق وفتح</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* Error Message (Red Alert) */}
            {pinError && (
              <div className="p-3 rounded-xl bg-rose-950/90 border border-rose-600 text-rose-200 text-xs font-bold flex items-center gap-2.5">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                <span>{pinError}</span>
              </div>
            )}

            {/* Success Message (Green Banner) */}
            {isPinVerified && (
              <div className="p-2.5 rounded-xl bg-emerald-950/80 border border-emerald-600/60 text-emerald-300 text-xs font-bold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  تم التحقق بنجاح من رمز المرور الخاص بـ ({verifiedDepartmentName || asset.categoryNameAr}) - تم فتح استمارة تسجيل الفحص.
                </span>
              </div>
            )}
          </div>

          {/* 3. Inspection Form: Locked until PIN is verified */}
          <div className={`relative transition-all duration-300 rounded-2xl ${
            isPinVerified ? 'opacity-100' : 'opacity-40 pointer-events-none select-none'
          }`}>
            {!isPinVerified && (
              <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-slate-950/80 backdrop-blur-[2px] rounded-2xl p-6 text-center border border-dashed border-amber-500/40">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 mb-3 shadow-lg">
                  <Lock className="w-6 h-6" />
                </div>
                <h5 className="text-sm font-bold text-white mb-1">
                  استمارة الفحص مقفلة برمز الأمان
                </h5>
                <p className="text-xs text-slate-300 max-w-sm">
                  يرجى كتابة اسم المهندس وإدخال رمز المرور السري (PIN) الخاص بـ ({asset.categoryNameAr}) في الحقل أعلاه لفتح الاستمارة واعتماد الفحص.
                </p>
              </div>
            )}

            <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-4 space-y-4">
              <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
                <Activity className="w-4 h-4 text-emerald-400" />
                <h4 className="text-xs sm:text-sm font-bold text-white">
                  نتائج الفحص الهندسي والتشغيلي:
                </h4>
              </div>

              {/* A. Device Status (يعمل بكفاءة / يحتاج إصلاح) */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">
                  حالة الجهاز التشغيلية (اختر حالة الجهاز بدقة):
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setDeviceStatus('يعمل بكفاءة')}
                    className={`p-3.5 rounded-2xl border font-bold text-xs sm:text-sm flex items-center justify-center gap-2.5 transition active:scale-98 ${
                      deviceStatus === 'يعمل بكفاءة'
                        ? 'bg-emerald-600 text-white border-emerald-400 shadow-lg shadow-emerald-950'
                        : 'bg-slate-900 border-slate-700 text-slate-300 hover:border-emerald-500/50'
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>يعمل بكفاءة ومطابق للمواصفات</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setDeviceStatus('يحتاج إصلاح')}
                    className={`p-3.5 rounded-2xl border font-bold text-xs sm:text-sm flex items-center justify-center gap-2.5 transition active:scale-98 ${
                      deviceStatus === 'يحتاج إصلاح'
                        ? 'bg-rose-600 text-white border-rose-400 shadow-lg shadow-rose-950'
                        : 'bg-slate-900 border-slate-700 text-slate-300 hover:border-rose-500/50'
                    }`}
                  >
                    <AlertTriangle className="w-4 h-4" />
                    <span>يحتاج إصلاح / تدخل فني</span>
                  </button>
                </div>
              </div>

              {/* B. Technical Readings */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Wrench className="w-3.5 h-3.5 text-cyan-400" />
                    <span>القراءات والقياسات الفنية (إن وجدت):</span>
                  </span>
                  <span className="text-[11px] text-slate-400">
                    (فولتية، ضغط، حرارة، سرعة، تدفق...)
                  </span>
                </label>
                <textarea
                  rows={2}
                  value={technicalReadings}
                  onChange={(e) => setTechnicalReadings(e.target.value)}
                  placeholder="مثال: الجهد الكهربائي 220V مستقر - ضغط الغاز 4.2 Bar - درجة الحرارة +4°C ضمن الحدود المعيارية."
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 text-xs sm:text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-500 transition"
                />
              </div>

              {/* C. Notes & Observations */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-amber-400" />
                  <span>الملاحظات الفنية والتوصيات الميدانية:</span>
                </label>
                <textarea
                  rows={2}
                  value={notesAndObservations}
                  onChange={(e) => setNotesAndObservations(e.target.value)}
                  placeholder="أدخل أي ملاحظات حول نظافة الفلاتر، التشحيم، سلامة الكابلات، وتثبيت لاصق الفحص..."
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 text-xs sm:text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-500 transition"
                />
              </div>

              {/* D. Next Due Date Auto-Calculation Preview */}
              <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3 flex items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-teal-400 shrink-0" />
                  <div>
                    <span className="text-slate-400 block text-[11px]">موعد الفحص الدوري القادم (جدولة تلقائية):</span>
                    <strong className="text-teal-300 text-sm">{computedNextDue}</strong>
                  </div>
                </div>
                <span className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 text-[11px] font-mono">
                  وفق الدورية: {asset.frequency}
                </span>
              </div>

              {/* Quick Step Checklist if defined on the asset */}
              {asset.checklist_steps && asset.checklist_steps.length > 0 && (
                <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-4 space-y-2.5">
                  <span className="text-xs font-bold text-slate-300 block">
                    بنود التحقق السريع لخطوات الصيانة:
                  </span>
                  <div className="space-y-2">
                    {asset.checklist_steps.map((step, idx) => {
                      const val = checklistValues[step.id] || { status: 'pass', reading: 'سليم' };
                      return (
                        <div key={step.id} className="flex items-center justify-between gap-2 p-2 rounded-xl bg-slate-900/70 border border-slate-800 text-xs">
                          <div className="flex items-center gap-2">
                            <span className="w-5 h-5 rounded-full bg-slate-800 text-slate-400 font-mono text-[10px] flex items-center justify-center shrink-0">
                              {idx + 1}
                            </span>
                            <span className="text-slate-200">{step.step_text}</span>
                          </div>
                          <div className="flex items-center gap-1.5 shrink-0">
                            <button
                              type="button"
                              onClick={() => handleStepStatusChange(step.id, 'pass')}
                              className={`px-2 py-1 rounded-lg text-[11px] font-bold transition ${
                                val.status === 'pass' ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-400'
                              }`}
                            >
                              مطابق ✓
                            </button>
                            <button
                              type="button"
                              onClick={() => handleStepStatusChange(step.id, 'fail')}
                              className={`px-2 py-1 rounded-lg text-[11px] font-bold transition ${
                                val.status === 'fail' ? 'bg-rose-600 text-white' : 'bg-slate-800 text-slate-400'
                              }`}
                            >
                              غير مطابق ✕
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Action Buttons Bar */}
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-slate-800 shrink-0">
            <button
              type="button"
              onClick={handlePrintAuditForm}
              className="w-full sm:w-auto px-4 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition"
            >
              <Printer className="w-4 h-4 text-emerald-400" />
              <span>طباعة استمارة الفحص A4</span>
            </button>

            <div className="flex items-center gap-2.5 w-full sm:w-auto">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 sm:flex-initial px-4 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs sm:text-sm font-bold transition"
              >
                إلغاء
              </button>

              <button
                type="submit"
                disabled={isSaving || saveSuccessNotice || !isPinVerified}
                className={`flex-1 sm:flex-initial px-5 py-2.5 rounded-2xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition shadow-lg ${
                  !isPinVerified
                    ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                    : saveSuccessNotice
                    ? 'bg-emerald-500 text-white shadow-emerald-950'
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-950 active:scale-95'
                }`}
              >
                {isSaving ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>جاري التحديث والحفظ في Supabase...</span>
                  </>
                ) : saveSuccessNotice ? (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>تم الحفظ والجدولة بنجاح!</span>
                  </>
                ) : !isPinVerified ? (
                  <>
                    <Lock className="w-4 h-4 text-slate-500" />
                    <span>أدخل الرمز لفتح الحفظ</span>
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    <span>حفظ واعتماد الفحص وجدولة الموعد القادم</span>
                  </>
                )}
              </button>
            </div>
          </div>

        </form>
      </div>
    </div>
  );
};
