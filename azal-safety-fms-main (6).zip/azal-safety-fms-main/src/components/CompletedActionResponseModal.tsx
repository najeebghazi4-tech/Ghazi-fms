import React, { useState } from 'react';
import { supabase } from '../services/supabaseClient';

export interface CompletedAction {
  id: number | string;
  notice_number: string;
  department_name: string;
  hazard_description: string;
  action_taken: string;
  completed_by: string;
  completed_at: string;
  status: string;
}

export interface ActionResponseModalProps {
  action: CompletedAction | null;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const CompletedActionResponseModal: React.FC<ActionResponseModalProps> = ({
  action,
  isOpen,
  onClose,
  onSuccess,
}) => {
  const [reviewDecision, setReviewDecision] = useState<'approved' | 'rejected'>('approved');
  const [reviewerNotes, setReviewerNotes] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');

  if (!isOpen || !action) return null;

  const handleSubmitResponse = async (e: React.FormEvent) => {
    // منع تسرب الحدث نهائياً لعدم تشغيل أي نوافذ أخرى في الخلفية
    e.preventDefault();
    e.stopPropagation();
    setErrorMsg('');
    setIsSubmitting(true);

    try {
      const isApproved = reviewDecision === 'approved';
      const newStatus = isApproved ? 'مغلق ومعتمد نهائياً' : 'معاد للمراجعة والتعديل';

      // تحديث سجل الإفادة/الإشعار في قاعدة البيانات
      const { error } = await supabase
        .from('safety_remediation_notices')
        .update({
          status: newStatus,
          review_decision: newStatus,
          safety_closure_notes: reviewerNotes.trim(),
          verified_by: 'م/ نجيب غازي',
          closed_at: new Date().toISOString(),
        })
        .eq('id', action.id);

      if (error) {
        console.warn('Supabase update returned error, attempting fallback updates:', error);
      }

      // أيضاً تحديث سجل المخالفات إن وجد لضمان مزامنة حالة المعالجة
      try {
        await supabase
          .from('safety_violations')
          .update({
            status: isApproved ? 'resolved' : 'pending',
            verifiedBy: 'م/ نجيب غازي',
            verificationNotes: reviewerNotes.trim(),
            verifiedAt: new Date().toISOString(),
          })
          .eq('id', action.id);
      } catch {}

      // تحديث التخزين المحلي للإفادات
      try {
        const raw = localStorage.getItem('azal_incoming_statements');
        if (raw) {
          const list = JSON.parse(raw);
          const updatedList = list.map((item: any) =>
            String(item.id) === String(action.id) || String(item.referenceId) === String(action.notice_number)
              ? { ...item, status: newStatus, verified_by: 'م/ نجيب غازي', safety_closure_notes: reviewerNotes.trim() }
              : item
          );
          localStorage.setItem('azal_incoming_statements', JSON.stringify(updatedList));
        }
      } catch {}

      onSuccess();
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'حدث خطأ أثناء حفظ الرد على الإفادة');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div 
      className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 rtl" 
      dir="rtl"
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
      }}
    >
      <div 
        className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-lg w-full overflow-hidden animate-fadeIn"
        onClick={(e) => {
          e.stopPropagation();
        }}
      >
        
        {/* الترويسة */}
        <div className="bg-slate-900 text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="p-2 bg-emerald-600 rounded-lg text-white font-bold text-xs">
              اعتماد إفادة
            </span>
            <h3 className="text-sm font-bold">
              الرد على إفادة الإنجاز رقم ({action.notice_number})
            </h3>
          </div>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onClose();
            }}
            className="text-slate-400 hover:text-white p-1 rounded-md text-lg leading-none"
          >
            ✕
          </button>
        </div>

        {/* نموذج المراجعة والاعتماد */}
        <form onSubmit={handleSubmitResponse} className="p-5 space-y-4">
          {errorMsg && (
            <div className="p-2.5 bg-red-50 border border-red-200 text-red-700 text-xs rounded-lg text-center">
              {errorMsg}
            </div>
          )}

          {/* ملخص ما تم تنفيذه في الإفادة */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs space-y-1.5">
            <div className="flex justify-between text-slate-500">
              <span>القسم المنفذ: <strong className="text-slate-800">{action.department_name}</strong></span>
              <span>القائم بالإنجاز: <strong className="text-slate-800">{action.completed_by}</strong></span>
            </div>
            <p className="text-slate-700 pt-1 border-t border-slate-200">
              <span className="font-bold text-slate-900">بيان الإجراء المنجز: </span>
              {action.action_taken}
            </p>
          </div>

          {/* تحديد القرار */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-2">
              قرار مسؤول السلامة (FMS Verification) <span className="text-red-500">*</span>
            </label>
            <div className="grid grid-cols-2 gap-3">
              <label 
                className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-xs font-bold cursor-pointer transition-all ${
                  reviewDecision === 'approved'
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-700 shadow-sm'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <input
                  type="radio"
                  name="decision"
                  value="approved"
                  checked={reviewDecision === 'approved'}
                  onChange={() => setReviewDecision('approved')}
                  className="hidden"
                />
                <span>✓ اعتماد الإنجاز وإغلاق الطلب</span>
              </label>

              <label 
                className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-xs font-bold cursor-pointer transition-all ${
                  reviewDecision === 'rejected'
                    ? 'bg-amber-50 border-amber-500 text-amber-700 shadow-sm'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <input
                  type="radio"
                  name="decision"
                  value="rejected"
                  checked={reviewDecision === 'rejected'}
                  onChange={() => setReviewDecision('rejected')}
                  className="hidden"
                />
                <span>✕ إعادة الملاحظة للمنفذ</span>
              </label>
            </div>
          </div>

          {/* الملاحظات والتوجيهات */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              ملاحظات وتوجيهات المعتمد <span className="text-slate-400 font-normal">(اختياري)</span>
            </label>
            <textarea
              rows={3}
              placeholder="اكتب أي توجيهات أو ملاحظات إضافية حول جودة الإنجاز الميداني..."
              value={reviewerNotes}
              onChange={(e) => setReviewerNotes(e.target.value)}
              className="w-full p-2.5 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-slate-800 outline-none"
            />
          </div>

          {/* أزرار الإجراء */}
          <div className="flex gap-2 pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onClose();
              }}
              className="w-1/3 py-2.5 border border-slate-300 text-slate-600 rounded-xl text-xs font-bold hover:bg-slate-100 transition-all"
            >
              إلغاء
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className={`w-2/3 py-2.5 text-white rounded-xl text-xs font-bold transition-all shadow-md ${
                reviewDecision === 'approved'
                  ? 'bg-emerald-600 hover:bg-emerald-700'
                  : 'bg-amber-600 hover:bg-amber-700'
              } ${isSubmitting ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              {isSubmitting ? 'جاري الحفظ والاعتماد...' : 'تأكيد وحفظ القرار'}
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
export default CompletedActionResponseModal;
