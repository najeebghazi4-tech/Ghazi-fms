import React, { useState, useEffect } from 'react';
import { 
  Truck, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  Plus, 
  Printer, 
  Search, 
  Filter, 
  FileText, 
  UserCheck, 
  ShieldCheck, 
  Clock, 
  Trash2,
  Building,
  ArrowRightLeft
} from 'lucide-react';
import { HospitalPropertyGatePass, StaffUser } from '../types';
import { offlineStorage } from '../services/offlineStorage';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';
import { executeSmartPrint } from '../utils/printUtils';

interface HospitalPropertyExitLogViewProps {
  currentUser: StaffUser;
  onLogAudit: (action: string, actionAr: string, details: string) => void;
}

const INITIAL_GATE_PASSES: HospitalPropertyGatePass[] = [
  {
    id: 'pass-001',
    gatePassNumber: 'GP-2026-041',
    exitDate: new Date().toISOString().split('T')[0],
    itemDescription: 'جهاز تخطيط قلب متنقل (ECG Machine - GE Healthcare)',
    assetOrSerialTag: 'BME-ECG-089',
    department: 'قسم الطوارئ والإسعاف',
    exitPurpose: 'maintenance',
    destination: 'وكالة الأجهزة الطبية المتخصصة - صنعاء',
    recipientName: 'المهندس / أحمد الشرعبي',
    recipientPhone: '777738138',
    approvingManager: 'د/ محمد السراجي (مدير عام المستشفى)',
    securityOfficerOnGate: 'م/ نجيب غازي (رئيس السلامة FMS)',
    expectedReturnDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 3).toISOString().split('T')[0],
    actualReturnedDate: undefined,
    status: 'exited',
    notes: 'تم فحص الملحقات وكيبل الطاقة وحقيبة النقل عند بوابة الطوارئ الرئيسية.',
    createdAt: Date.now() - 1000 * 60 * 60 * 5
  },
  {
    id: 'pass-002',
    gatePassNumber: 'GP-2026-040',
    exitDate: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2).toISOString().split('T')[0],
    itemDescription: 'سيرفر تخزين مركزي للنسخ الاحتياطي (Dell PowerEdge R740)',
    assetOrSerialTag: 'IT-SRV-014',
    department: 'إدارة تكنولوجيا المعلومات IT',
    exitPurpose: 'calibration',
    destination: 'مركز الصيانة المعتمد للشبكات',
    recipientName: 'م/ صادق الشامي',
    recipientPhone: '777654321',
    approvingManager: 'د/ محمد السراجي (مدير عام المستشفى)',
    securityOfficerOnGate: 'مشرف الأمن المناوب',
    expectedReturnDate: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString().split('T')[0],
    actualReturnedDate: new Date().toISOString().split('T')[0],
    status: 'returned',
    notes: 'تمت إعادة السيرفر بحالة سليمة والتأكد من مطابقة السيريال نمبر عند البوابة.',
    createdAt: Date.now() - 1000 * 60 * 60 * 48
  }
];

export const HospitalPropertyExitLogView: React.FC<HospitalPropertyExitLogViewProps> = ({
  currentUser,
  onLogAudit
}) => {
  const [passes, setPasses] = useState<HospitalPropertyGatePass[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);

  // Form State
  const [itemDescription, setItemDescription] = useState('');
  const [assetOrSerialTag, setAssetOrSerialTag] = useState('');
  const [department, setDepartment] = useState('قسم الطوارئ والإسعاف');
  const [exitPurpose, setExitPurpose] = useState<'maintenance' | 'loan' | 'calibration' | 'disposal' | 'transfer'>('maintenance');
  const [destination, setDestination] = useState('');
  const [recipientName, setRecipientName] = useState('');
  const [recipientPhone, setRecipientPhone] = useState('');
  const [approvingManager, setApprovingManager] = useState('');
  const [expectedReturnDate, setExpectedReturnDate] = useState(
    new Date(Date.now() + 1000 * 60 * 60 * 24 * 7).toISOString().split('T')[0]
  );
  const [notes, setNotes] = useState('');

  useEffect(() => {
    loadPasses();
  }, []);

  const loadPasses = async () => {
    try {
      const stored = await offlineStorage.getPropertyGatePasses();
      if (stored && stored.length > 0) {
        setPasses(stored);
      } else {
        setPasses(INITIAL_GATE_PASSES);
        for (const item of INITIAL_GATE_PASSES) {
          await offlineStorage.savePropertyGatePass(item);
        }
      }
    } catch {
      setPasses(INITIAL_GATE_PASSES);
    }
  };

  const handleCreatePass = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemDescription.trim() || !recipientName.trim() || !destination.trim()) return;

    const currentYear = new Date().getFullYear();
    const count = passes.length + 1;
    const gatePassNumber = `GP-${currentYear}-${String(count).padStart(3, '0')}`;

    const newPass: HospitalPropertyGatePass = {
      id: `pass-${Date.now()}`,
      gatePassNumber,
      exitDate: new Date().toISOString().split('T')[0],
      itemDescription: itemDescription.trim(),
      assetOrSerialTag: assetOrSerialTag.trim() || 'بدون سيريال',
      department,
      exitPurpose,
      destination: destination.trim(),
      recipientName: recipientName.trim(),
      recipientPhone: recipientPhone.trim() || undefined,
      approvingManager: approvingManager.trim() || 'مدير إدارة الخدمات المساندة',
      securityOfficerOnGate: currentUser.name,
      expectedReturnDate,
      status: 'exited',
      notes: notes.trim() || 'تمت المصادقة والتفتيش الميداني عند بوابة المستشفى.',
      createdAt: Date.now()
    };

    const updated = [newPass, ...passes];
    setPasses(updated);
    await offlineStorage.savePropertyGatePass(newPass);

    // Audio and haptic feedback
    triggerSuccessFeedback();

    onLogAudit(
      'PROPERTY_EXIT_LOGGED',
      'إصدار تصريح خروج ممتلكات (Gate Pass)',
      `تم تسجيل خروج (${newPass.itemDescription}) برقم تصريح (${newPass.gatePassNumber}) للمستلم: ${newPass.recipientName}`
    );

    setShowAddModal(false);
    setItemDescription('');
    setAssetOrSerialTag('');
    setDestination('');
    setRecipientName('');
    setRecipientPhone('');
    setNotes('');
  };

  const handleMarkReturned = async (pass: HospitalPropertyGatePass) => {
    const today = new Date().toISOString().split('T')[0];
    const updatedPass: HospitalPropertyGatePass = {
      ...pass,
      status: 'returned',
      actualReturnedDate: today,
      notes: (pass.notes ? pass.notes + '\n' : '') + `[تمت الإعادة والتأكد من سلامة الأصل عند البوابة بتاريخ ${today} بواسطة ${currentUser.name}]`
    };

    const updated = passes.map(p => p.id === pass.id ? updatedPass : p);
    setPasses(updated);
    await offlineStorage.savePropertyGatePass(updatedPass);

    // Audio and haptic feedback
    triggerSuccessFeedback();

    onLogAudit(
      'PROPERTY_RETURN_CONFIRMED',
      'تأكيد استرجاع ممتلكات المستشفى',
      `تم تأكيد إعادة الأصل (${pass.itemDescription}) تصريح رقم (${pass.gatePassNumber})`
    );
  };

  const handleDelete = async (id: string) => {
    if (confirm('هل أنت متأكد من حذف هذا التصريح؟')) {
      const updated = passes.filter(p => p.id !== id);
      setPasses(updated);
      await offlineStorage.deletePropertyGatePass(id);
    }
  };

  const handlePrint = () => {
    const tableRows = filtered.map((p, idx) => `
      <tr>
        <td style="font-weight:bold; font-family:monospace;">${idx + 1}</td>
        <td style="font-family:monospace; font-weight:bold;">${p.gatePassNumber}</td>
        <td><strong>${p.itemDescription}</strong></td>
        <td style="font-family:monospace; font-size:11px;">${p.assetOrSerialTag || '-'}</td>
        <td>${p.department}</td>
        <td>${p.destination}</td>
        <td>${p.recipientName} (${p.recipientPhone || 'بدون هاتف'})</td>
        <td>${p.approvingManager}</td>
        <td>${p.securityOfficerOnGate}</td>
        <td>${p.exitDate}</td>
        <td>${p.status === 'returned' ? '<span class="badge-success">تمت الإعادة ✔</span>' : '<span class="badge-warning">خارج المستشفى</span>'}</td>
        <td>${p.notes || '-'}</td>
      </tr>
    `).join('');

    const bodyHtml = `
      <div class="summary-grid">
        <div class="summary-card"><div class="val">${passes.length}</div><div class="lbl">إجمالي تصاريح الخروج</div></div>
        <div class="summary-card"><div class="val" style="color:#b45309;">${activeExitedCount}</div><div class="lbl">أصول خارج المستشفى حالياً</div></div>
        <div class="summary-card"><div class="val" style="color:#047857;">${returnedCount}</div><div class="lbl">أصول تمت إعادتها سالمة</div></div>
      </div>
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>رقم التصريح</th>
            <th>وصف الأصل والمعدّة</th>
            <th>الرقم التسلسلي</th>
            <th>القسم المصرح</th>
            <th>الجهة / الوجهة</th>
            <th>المستلم</th>
            <th>المسؤول المصادق</th>
            <th>مسؤول البوابة</th>
            <th>تاريخ الخروج</th>
            <th>الحالة</th>
            <th>ملاحظات البوابة</th>
          </tr>
        </thead>
        <tbody>
          ${tableRows || '<tr><td colspan="12" style="text-align:center; padding:12px;">لا توجد تصاريح مسجلة</td></tr>'}
        </tbody>
      </table>
    `;

    executeSmartPrint(bodyHtml, {
      title: 'سجل تصاريح خروج ممتلكات وأصول المستشفى (Gate Pass Log)',
      subtitle: 'إدارة الأمن والسلامة وإدارة المرافق FMS • حراسات البوابات الرئيسية',
      refNumber: 'AZAL-GATEPASS-LOG-2026'
    });
  };

  const filtered = passes.filter(p => {
    const matchStatus = statusFilter === 'all' || p.status === statusFilter;
    const matchSearch = p.gatePassNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        p.itemDescription.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        p.recipientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        p.destination.toLowerCase().includes(searchTerm.toLowerCase());
    return matchStatus && matchSearch;
  });

  const activeExitedCount = passes.filter(p => p.status === 'exited').length;
  const returnedCount = passes.filter(p => p.status === 'returned').length;

  return (
    <div id="hospital-property-exit-log-view" className="space-y-4 text-right">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-emerald-950/70 border border-slate-800 rounded-3xl p-5 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-emerald-950 border border-emerald-800 text-emerald-400">
            <Truck className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-slate-100">
                سجل خروج ممتلكات وأجهزة المستشفى (Property Exit Gate Pass Log)
              </h2>
              <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold px-2 py-0.5 rounded-lg">
                معايير الحراسات الأمنية FMS
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              تسجيل الأجهزة والعهد المصرح بخروجها، رقم التصريح، وجهة الخروج، واسم المستلم ومسؤول الأمن المصادق وتتبع إعادتها.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md flex items-center gap-2 transition"
          >
            <Plus className="w-4 h-4" />
            <span>إصدار تصريح خروج ممتلكات</span>
          </button>

          <button
            type="button"
            onClick={handlePrint}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold flex items-center gap-1.5 transition"
          >
            <Printer className="w-4 h-4" />
            <span>طباعة السجل (Print / PDF)</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
          <div className="text-xs text-slate-400">إجمالي تصاريح الخروج المسجلة</div>
          <div className="text-2xl font-black text-slate-100 mt-1">{passes.length}</div>
          <div className="text-[10px] text-teal-400 mt-1">سجلات رسمية موثقة</div>
        </div>

        <div className="bg-slate-900 border border-amber-900/60 rounded-2xl p-4">
          <div className="text-xs text-slate-400">ممتلكات خارج المستشفى حالياً (قيد المتابعة)</div>
          <div className="text-2xl font-black text-amber-400 mt-1">{activeExitedCount}</div>
          <div className="text-[10px] text-amber-300 mt-1">في الصيانة / المعايرة / الإعارة</div>
        </div>

        <div className="bg-slate-900 border border-emerald-900/60 rounded-2xl p-4">
          <div className="text-xs text-slate-400">أجهزة وممتلكات تم استرجاعها بنجاح</div>
          <div className="text-2xl font-black text-emerald-400 mt-1">{returnedCount}</div>
          <div className="text-[10px] text-emerald-300 mt-1">مطابقة السيريال عند بوابة الأمن</div>
        </div>
      </div>

      {/* Filter and Search */}
      <div className="bg-slate-900/80 border border-slate-800 p-3 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex-1 min-w-[200px] relative">
          <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="بحث برقم التصريح، اسم الأصل، المستلم، أو الوجهة..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-9 pl-3 py-2 text-slate-200"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200"
          >
            <option value="all">كافة الحالات</option>
            <option value="exited">خارج المستشفى (قيد المتابعة)</option>
            <option value="returned">تمت إعادته واستلامه</option>
            <option value="overdue">تأخر عن موعد الإرجاع</option>
          </select>
        </div>
      </div>

      {/* Pass Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-950 border-b border-slate-800 text-slate-400 font-bold">
              <tr>
                <th className="p-3.5">رقم التصريح والأصل</th>
                <th className="p-3.5">القسم والسبب</th>
                <th className="p-3.5">المستلم والوجهة</th>
                <th className="p-3.5 text-center">تاريخ الخروج</th>
                <th className="p-3.5 text-center">العودة المتوقعة</th>
                <th className="p-3.5">المصادق ورجل الأمن</th>
                <th className="p-3.5 text-center">الحالة</th>
                <th className="p-3.5 text-center">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-400">
                    لا توجد تصاريح خروج مطابقة لمعايير البحث
                  </td>
                </tr>
              ) : (
                filtered.map((p) => {
                  const purposeLabel = 
                    p.exitPurpose === 'maintenance' ? 'صيانة وإصلاح' :
                    p.exitPurpose === 'calibration' ? 'معايرة وفحص فني' :
                    p.exitPurpose === 'loan' ? 'إعارة مؤقتة' :
                    p.exitPurpose === 'disposal' ? 'إتلاف وإسقاط عهدة' : 'نقل لموقع آخر';

                  return (
                    <tr key={p.id} className="hover:bg-slate-800/30 transition">
                      <td className="p-3.5">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded-lg border border-emerald-800">
                            {p.gatePassNumber}
                          </span>
                        </div>
                        <div className="font-bold text-slate-100 mt-1">{p.itemDescription}</div>
                        <div className="text-[10px] text-slate-400 font-mono">الكود: {p.assetOrSerialTag}</div>
                      </td>
                      <td className="p-3.5">
                        <div className="text-slate-200">{p.department}</div>
                        <div className="text-[10px] text-amber-400">{purposeLabel}</div>
                      </td>
                      <td className="p-3.5">
                        <div className="font-semibold text-slate-200">{p.recipientName}</div>
                        <div className="text-[11px] text-slate-400">{p.destination}</div>
                        {p.recipientPhone && (
                          <div className="text-[10px] font-mono text-slate-500">{p.recipientPhone}</div>
                        )}
                      </td>
                      <td className="p-3.5 text-center font-mono text-slate-300">
                        {p.exitDate}
                      </td>
                      <td className="p-3.5 text-center font-mono text-slate-300">
                        {p.expectedReturnDate || 'دائم'}
                      </td>
                      <td className="p-3.5">
                        <div className="text-[11px] text-slate-300">المصادق: <span className="font-semibold">{p.approvingManager}</span></div>
                        <div className="text-[10px] text-slate-400">بوابة الأمن: {p.securityOfficerOnGate}</div>
                      </td>
                      <td className="p-3.5 text-center">
                        <span className={`px-2.5 py-1 rounded-xl text-[10px] font-bold ${
                          p.status === 'returned'
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                            : p.status === 'exited'
                            ? 'bg-amber-950 text-amber-300 border border-amber-800'
                            : 'bg-rose-950 text-rose-300 border border-rose-800'
                        }`}>
                          {p.status === 'returned' ? '✓ تم الاسترجاع' : p.status === 'exited' ? 'خارج المستشفى' : 'متأخر'}
                        </span>
                      </td>
                      <td className="p-3.5 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          {p.status === 'exited' && (
                            <button
                              type="button"
                              onClick={() => handleMarkReturned(p)}
                              className="px-2.5 py-1 rounded-lg bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 text-[10px] font-bold transition flex items-center gap-1"
                              title="تأكيد عودة الأصل واستلامه عند البوابة"
                            >
                              <ArrowRightLeft className="w-3 h-3" />
                              <span>تأكيد العودة</span>
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => handleDelete(p.id)}
                            className="p-1.5 rounded-lg bg-slate-800 text-rose-400 hover:bg-rose-950 hover:text-rose-300 transition"
                            title="حذف"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* New Gate Pass Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-emerald-600/60 rounded-3xl w-full max-w-xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
            <div className="bg-slate-950 px-5 py-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-emerald-950 text-emerald-400 border border-emerald-800">
                  <Truck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-100">
                    إصدار تصريح خروج ممتلكات (Gate Pass)
                  </h3>
                  <p className="text-[11px] text-slate-400">مستشفى آزال النموذجي • إدارة الأمن والحراسات</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="p-1 rounded-lg bg-slate-800 text-slate-400 hover:text-slate-100"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreatePass} className="p-5 space-y-3.5 overflow-y-auto text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">وصف الأصل أو الجهاز المصرح بخروجه:</label>
                  <input
                    type="text"
                    required
                    placeholder="جهاز صدمات قلب، لابتوب..."
                    value={itemDescription}
                    onChange={(e) => setItemDescription(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                  />
                </div>
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">رقم الأصل أو السيريال (Serial / Tag):</label>
                  <input
                    type="text"
                    placeholder="BME-0912 / SN: 99482..."
                    value={assetOrSerialTag}
                    onChange={(e) => setAssetOrSerialTag(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">القسم المالك للأصل:</label>
                  <select
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                  >
                    <option value="قسم الطوارئ والإسعاف">قسم الطوارئ والإسعاف</option>
                    <option value="غرف العمليات الكبرى">غرف العمليات الكبرى</option>
                    <option value="العناية المركزة ICU">العناية المركزة ICU</option>
                    <option value="إدارة تكنولوجيا المعلومات IT">إدارة تكنولوجيا المعلومات IT</option>
                    <option value="الهندسة الطبية الحيوية BME">الهندسة الطبية الحيوية BME</option>
                    <option value="الخدمات المساندة والصيانة">الخدمات المساندة والصيانة</option>
                    <option value="المختبر وبنك الدم">المختبر وبنك الدم</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">الغرض من الخروج:</label>
                  <select
                    value={exitPurpose}
                    onChange={(e) => setExitPurpose(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                  >
                    <option value="maintenance">صيانة وإصلاح خارجي (Maintenance)</option>
                    <option value="calibration">معايرة فنية واختبار (Calibration)</option>
                    <option value="loan">إعارة مؤقتة (Temporary Loan)</option>
                    <option value="transfer">نقل إلى فرع أو مبنى آخر</option>
                    <option value="disposal">إتلاف وإسقاط رسمي (Disposal)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">اسم المستلم أو السائق:</label>
                  <input
                    type="text"
                    required
                    placeholder="فلان بن فلان..."
                    value={recipientName}
                    onChange={(e) => setRecipientName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                  />
                </div>
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">رقم هاتف المستلم:</label>
                  <input
                    type="tel"
                    placeholder="77XXXXXXX"
                    value={recipientPhone}
                    onChange={(e) => setRecipientPhone(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">جهة الخروج المقصودة (Destination):</label>
                  <input
                    type="text"
                    required
                    placeholder="شركة الرواد للأجهزة، ورشة الصيانة..."
                    value={destination}
                    onChange={(e) => setDestination(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                  />
                </div>
                <div>
                  <label className="text-slate-300 block mb-1 font-semibold">التاريخ المتوقع للعودة:</label>
                  <input
                    type="date"
                    value={expectedReturnDate}
                    onChange={(e) => setExpectedReturnDate(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 block mb-1 font-semibold">المسؤول المصادق على الإذن:</label>
                <input
                  type="text"
                  placeholder="مدير الإدارة الطبية / رئيس القسم..."
                  value={approvingManager}
                  onChange={(e) => setApprovingManager(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                />
              </div>

              <div>
                <label className="text-slate-300 block mb-1 font-semibold">ملاحظات البوابة وحالة الجهاز:</label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="الملحقات المرفقة، حالة الجهاز الخارجية..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2 text-slate-100"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 text-xs"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>اعتماد وإصدار التصريح</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
