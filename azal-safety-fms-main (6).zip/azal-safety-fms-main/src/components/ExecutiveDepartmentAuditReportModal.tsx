import React, { useState, useId } from 'react';
import {
  FileText,
  Printer,
  Copy,
  Check,
  X,
  Building2,
  AlertTriangle,
  Clock,
  ShieldCheck,
  AlertOctagon,
  Mail,
  Send,
  Calendar,
  Layers,
  ArrowRight,
} from 'lucide-react';
import { SafetyViolationNotice, StaffUser } from '../types';
import { analyzeViolationDeadline } from '../utils/violationUtils';
import { printExistingElementById } from '../utils/printUtils';

interface ExecutiveDepartmentAuditReportModalProps {
  selectedDepartment: string;
  violations: SafetyViolationNotice[];
  currentUser: StaffUser;
  onClose: () => void;
  onLogAudit?: (action: string, title: string, details: string) => void;
  allDepartments?: { id: string; label: string }[];
}

export const ExecutiveDepartmentAuditReportModal: React.FC<ExecutiveDepartmentAuditReportModalProps> = ({
  selectedDepartment: initialDepartment,
  violations,
  currentUser,
  onClose,
  onLogAudit,
  allDepartments = [],
}) => {
  const [currentDept, setCurrentDept] = useState<string>(
    initialDepartment === 'all' ? 'كافة الأقسام والمرافق' : initialDepartment
  );
  const [copied, setCopied] = useState(false);
  const reportContainerId = `executive-audit-report-sheet-${useId().replace(/:/g, '')}`;

  // Filter violations for the active department
  const deptViolations = violations.filter((v) => {
    if (currentDept === 'all' || currentDept === 'كافة الأقسام والمرافق') return true;
    return v.department.toLowerCase().includes(currentDept.toLowerCase());
  });

  // Calculate department KPIs
  const totalViolations = deptViolations.length;
  const resolvedViolations = deptViolations.filter(
    (v) => v.status === 'resolved' || v.status === 'responded'
  );
  const resolvedCount = resolvedViolations.length;
  const completionRate = totalViolations > 0 ? Math.round((resolvedCount / totalViolations) * 100) : 100;

  // Overdue and pending breakdown
  const overdueViolations = deptViolations.filter((v) => analyzeViolationDeadline(v).isOverdue);
  const overdueCount = overdueViolations.length;
  const pendingCount = totalViolations - resolvedCount - overdueCount;

  // Total follow-up messages dispatched to this department
  const totalFollowUpsSent = deptViolations.reduce((acc, v) => acc + (v.followUpCount || 0), 0);

  // Reference Code and Dates
  const today = new Date();
  const dateFormattedAr = today.toLocaleDateString('ar-EG', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  const timeFormattedAr = today.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
  const refCode = `AZAL-FMS-ACC-${today.getFullYear()}${String(today.getMonth() + 1).padStart(2, '0')}-${String(
    today.getDate()
  ).padStart(2, '0')}/${Math.floor(100 + Math.random() * 900)}`;

  // Handle Print Action
  const handlePrint = () => {
    if (onLogAudit) {
      onLogAudit(
        'EXECUTIVE_REPORT_PRINTED',
        'طباعة تقرير المدير العام للمحاسبة الإدارية',
        `تم إصدار وطباعة التقرير الرقابي الرسمي لقسم (${currentDept}) برقم مرجعي (${refCode}) موجه للمدير العام.`
      );
    }
    printExistingElementById(reportContainerId, {
      title: `تقرير رقابي تنفيذي للمدير العام للمحاسبة الإدارية - قسم ${currentDept}`,
      subtitle: 'Executive Accountability & Safety Non-Compliance Report',
      department: currentDept,
      refNumber: refCode,
      date: today.toISOString().split('T')[0],
      inspectorName: 'م/ نجيب قاسم غازي',
    });
  };

  // Handle Copy as Text Memo
  const handleCopyText = () => {
    const textMemo = `
=========================================
الجمهورية اليمنية
مستشفى آزال النموذجي - صنعاء
إدارة الأمن والسلامة وإدارة المرافق (FMS)
=========================================
تقرير رقابي تنفيذي عاجل موجه للأخ / المدير العام
الرقم المرجعي: ${refCode}
التاريخ: ${dateFormattedAr} - ${timeFormattedAr}
القسم المعني بالتقرير: ${currentDept}

الموضوع: تقرير الرقابة والمتابعة الميدانية للمخالفات المتأخرة والمهملة للمحاسبة الإدارية

1. الملخص الرقابي للقسم:
- إجمالي المخالفات المسجلة: ${totalViolations}
- المخالفات المنجزة والمعالجة: ${resolvedCount} (نسبة الإنجاز: ${completionRate}%)
- المخالفات قيد المتابعة ضمن المهلة: ${pendingCount}
- المخالفات المهملة والمتأخرة: ${overdueCount}
- إجمالي رسائل ومذكرات المتابعة المرسلة للقسم: ${totalFollowUpsSent}

2. تفاصيل المخالفات المتأخرة والمهملة:
${
  overdueViolations.length === 0
    ? 'لا توجد مخالفات متأخرة حالياً - كافة الملاحظات منجزة ضمن المهلة المحددة.'
    : overdueViolations
        .map(
          (v, i) =>
            `${i + 1}) [${v.id}] - ${v.description} | الموقع: ${v.locationDetail} | المكلف: ${
              v.assignedToCustom || v.assignedTo
            } | تاريخ الإشعار الأول: ${v.firstSentAt || 'مسجل'} | المهلة: ${v.deadlineAt} | مذكرات المتابعة المرسلة: ${
              v.followUpCount || 0
            } | مدة التأخير: ${analyzeViolationDeadline(v).overdueDaysText}`
        )
        .join('\n')
}

3. التوصية الإدارية المسندة لمعايير الجودة وسباهي (CBAHI):
استناداً لمعايير الاعتماد الوطني والدولي (CBAHI - FMS Standards)، فإن استمرار هذه المخالفات دون معالجة وتجاوز المهلة المحددة يمثل تهديداً لسلامة المرضى والمنشأة. نوصي باتخاذ الإجراءات الإدارية والمحاسبية الرادعة بحق المتسببين والإلزام الفوري بالإنجاز.

مُعِد التقرير:
رئيس قسم الأمن والسلامة وإدارة المرافق
م / نجيب قاسم غازي
=========================================
    `.trim();

    navigator.clipboard.writeText(textMemo).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
      if (onLogAudit) {
        onLogAudit(
          'EXECUTIVE_REPORT_COPIED',
          'نسخ نص التقرير الرقابي للمدير العام',
          `تم نسخ مذكرة التقرير الرقابي للقسم (${currentDept}) للمحاسبة الإدارية.`
        );
      }
    });
  };

  return (
    <div
      id="executive-audit-report-modal"
      className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 overflow-y-auto"
    >
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-5xl my-auto shadow-2xl overflow-hidden flex flex-col max-h-[96vh]">
        {/* Top Control Bar (Non-printing Toolbar) */}
        <div className="p-3.5 bg-slate-950 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-amber-950 text-amber-400 border border-amber-800/80">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-black text-slate-100 flex items-center gap-2">
                <span>تقرير المدير العام للمحاسبة الإدارية (قالب رسمي A4)</span>
                <span className="px-2 py-0.5 rounded-full bg-amber-900/60 text-amber-300 text-[10px] font-mono border border-amber-600/60">
                  CBAHI - FMS
                </span>
              </h2>
              <p className="text-[11px] text-slate-400">
                مستند رسمي معتمد لرفع المخالفات المتأخرة والمهملة للمدير العام لاتخاذ القرارات الإدارية
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* Department Switcher */}
            <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-700/80 rounded-xl px-2.5 py-1.5">
              <Building2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span className="text-slate-300 font-bold text-[11px] whitespace-nowrap">القسم:</span>
              <select
                value={currentDept}
                onChange={(e) => setCurrentDept(e.target.value)}
                className="bg-transparent text-slate-100 font-bold text-xs focus:outline-none cursor-pointer"
              >
                <option value="كافة الأقسام والمرافق" className="bg-slate-900 text-slate-100">
                  [عرض كافة الأقسام]
                </option>
                <option value="الطوارئ" className="bg-slate-900 text-slate-100">
                  🚨 قسم الطوارئ والإسعاف
                </option>
                <option value="الصيانة العامة" className="bg-slate-900 text-slate-100">
                  🔧 قسم الصيانة العامة والهندسية
                </option>
                <option value="الأجهزة الطبية" className="bg-slate-900 text-slate-100">
                  🩺 قسم الأجهزة الطبية والهندسة
                </option>
                <option value="العمليات" className="bg-slate-900 text-slate-100">
                  🔪 العمليات الجراحية الكبرى
                </option>
                <option value="المغسلة" className="bg-slate-900 text-slate-100">
                  🧺 المغسلة المركزية ومستودع البياضات
                </option>
                <option value="الأشعة" className="bg-slate-900 text-slate-100">
                  🩻 قسم الأشعة التشخيصية
                </option>
                {allDepartments
                  .filter(
                    (d) =>
                      d.id !== 'all' &&
                      !['الطوارئ', 'الصيانة العامة', 'الأجهزة الطبية', 'العمليات', 'المغسلة', 'الأشعة'].includes(
                        d.id
                      )
                  )
                  .map((d) => (
                    <option key={d.id} value={d.id} className="bg-slate-900 text-slate-100">
                      {d.label}
                    </option>
                  ))}
              </select>
            </div>

            {/* Copy Button */}
            <button
              type="button"
              onClick={handleCopyText}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center gap-1.5 transition active:scale-95 border border-slate-700"
              title="نسخ نص التقرير بالكامل لإرساله عبر البريد أو المذكرة"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-300" />}
              <span>{copied ? 'تم النسخ بنجاح' : 'نسخ المذكرة'}</span>
            </button>

            {/* Print Button */}
            <button
              type="button"
              onClick={handlePrint}
              className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white font-black text-xs flex items-center gap-1.5 shadow-lg shadow-amber-950/60 transition active:scale-95"
              title="طباعة التقرير مباشرة بقياس A4 مع الترويسة والتوقيعات الرسمية"
            >
              <Printer className="w-4 h-4" />
              <span>🖨️ طباعة التقرير الرسمي A4</span>
            </button>

            {/* Close Button */}
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
              title="إغلاق التقرير"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Report Content Container (Scrollable Preview) */}
        <div className="p-4 sm:p-6 overflow-y-auto bg-slate-950/50 flex justify-center items-start flex-1">
          {/* A4 Paper Canvas */}
          <div
            id={reportContainerId}
            className="w-full max-w-4xl bg-white text-slate-900 p-6 sm:p-10 shadow-2xl rounded-sm border border-slate-300 text-right font-sans text-xs leading-relaxed"
            style={{ minHeight: '297mm' }}
          >
            {/* 1. Official Institutional Header (No Ministry of Health branding as requested) */}
            <div className="border-b-2 border-slate-800 pb-4 mb-5">
              <div className="flex items-center justify-between gap-4">
                {/* Right Column: Institutional Identity */}
                <div className="text-right space-y-0.5 w-1/3">
                  <div className="font-extrabold text-sm text-slate-900">الجمهورية اليمنية</div>
                  <div className="font-black text-base text-slate-900 tracking-tight">مستشفى آزال النموذجي - صنعاء</div>
                  <div className="font-bold text-xs text-amber-800">إدارة الأمن والسلامة وإدارة المرافق (FMS)</div>
                  <div className="text-[10px] text-slate-600 font-semibold">قسم الرقابة والمطابقة والمعايير المهنية</div>
                </div>

                {/* Center Column: Official Logo */}
                <div className="flex flex-col items-center justify-center text-center w-1/3">
                  <img
                    src="/azal-logo.svg"
                    alt="شعار مستشفى آزال النموذجي"
                    className="max-h-16 w-auto object-contain drop-shadow-xs"
                    referrerPolicy="no-referrer"
                  />
                  <span className="text-[10px] font-bold text-emerald-800 mt-1">الرعاية الكاملة • معتمد سباهي CBAHI</span>
                </div>

                {/* Left Column: Reference & Date */}
                <div className="text-left space-y-1 w-1/3 dir-ltr">
                  <div className="inline-block bg-slate-100 border border-slate-300 px-2 py-0.5 rounded text-[10px] font-mono font-bold text-slate-800">
                    CBAHI FMS COMPLIANT
                  </div>
                  <div className="text-[11px] font-mono text-slate-700">
                    <strong className="text-slate-900">الرقم المرجعي:</strong> {refCode}
                  </div>
                  <div className="text-[11px] text-slate-700">
                    <strong className="text-slate-900">التاريخ:</strong> {today.toISOString().split('T')[0]}
                  </div>
                  <div className="text-[10px] text-rose-700 font-bold bg-rose-50 border border-rose-200 px-1.5 py-0.5 rounded inline-block">
                    درجة الأهمية: عاجل وسري للغاية
                  </div>
                </div>
              </div>

              {/* Title Banner */}
              <div className="mt-4 pt-3 border-t border-slate-300 flex flex-col sm:flex-row items-center justify-between gap-2 bg-slate-100/90 p-3 rounded-xl border">
                <div>
                  <h1 className="text-base sm:text-lg font-black text-slate-900">
                    تقرير رقابي تنفيذي - متابعة ملاحظات ومخالفات السلامة للمحاسبة الإدارية
                  </h1>
                  <span className="text-xs text-slate-600 font-semibold block mt-0.5">
                    Executive Accountability & Safety Compliance Report • مخصص للإدارة العليا
                  </span>
                </div>
                <div className="px-3 py-1.5 rounded-lg bg-amber-100 border border-amber-400 text-amber-900 font-bold text-xs shrink-0">
                  القسم الخاضع للمراجعة: <strong className="text-slate-900">{currentDept}</strong>
                </div>
              </div>
            </div>

            {/* 2. Formal Addressee (موجه للأخ / المدير العام) */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 mb-5 space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <div>
                  <span className="font-bold text-slate-700">إلى الأخ / </span>
                  <strong className="text-slate-900 text-sm font-black">مدير عام مستشفى آزال النموذجي المحترم</strong>
                </div>
                <span className="text-[11px] font-bold text-slate-500">حفظه الله تعالى</span>
              </div>
              <div className="text-xs font-bold text-slate-800">تحية طيبة وبعد ،،،</div>
              <p className="text-xs text-slate-700 leading-relaxed font-medium pt-1">
                <strong>الموضوع: </strong>
                رفع نتائج التفتيش الرقابي الميداني وقائمة المخالفات والملاحظات الحرجة المتأخرة والمهملة بقسم (
                <strong className="text-amber-900 underline">{currentDept}</strong>
                ) التي انقضت مهلتها المحددة ولم يتم تقديم إفادة معالجة أو إغلاقها حتى تاريخه، لغرض اتخاذ الإجراءات
                والمحاسبة الإدارية اللازمة:
              </p>
            </div>

            {/* 3. Executive KPI Summary (الملخص الرقابي للقسم) */}
            <div className="mb-5">
              <h3 className="text-xs font-black text-slate-900 mb-2 flex items-center gap-1.5 border-b border-slate-300 pb-1">
                <span className="w-2 h-2 rounded-full bg-amber-600 inline-block" />
                <span>أولاً: الملخص الرقابي والمؤشرات التشغيلية للقسم المعني:</span>
              </h3>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-center">
                <div className="p-2.5 rounded-xl border border-slate-200 bg-slate-50">
                  <span className="text-[10px] text-slate-600 block font-bold">إجمالي المخالفات المسجلة</span>
                  <span className="text-lg font-black text-slate-900 font-mono mt-0.5 block">{totalViolations}</span>
                </div>
                <div className="p-2.5 rounded-xl border border-emerald-200 bg-emerald-50/70">
                  <span className="text-[10px] text-emerald-800 block font-bold">المعالجة والمنجزة</span>
                  <span className="text-lg font-black text-emerald-700 font-mono mt-0.5 block">{resolvedCount}</span>
                </div>
                <div className="p-2.5 rounded-xl border border-amber-200 bg-amber-50/70">
                  <span className="text-[10px] text-amber-800 block font-bold">ضمن المهلة قيد الإجراء</span>
                  <span className="text-lg font-black text-amber-700 font-mono mt-0.5 block">{pendingCount}</span>
                </div>
                <div className="p-2.5 rounded-xl border border-rose-300 bg-rose-50">
                  <span className="text-[10px] text-rose-800 block font-black">المتأخرة والمهملة ⚠️</span>
                  <span className="text-lg font-black text-rose-600 font-mono mt-0.5 block animate-pulse">
                    {overdueCount}
                  </span>
                </div>
                <div className="p-2.5 rounded-xl border border-blue-200 bg-blue-50/70">
                  <span className="text-[10px] text-blue-800 block font-bold">مذكرات المتابعة الصادرة</span>
                  <span className="text-lg font-black text-blue-700 font-mono mt-0.5 block">{totalFollowUpsSent}</span>
                </div>
              </div>

              <div className="mt-2 flex items-center justify-between text-[11px] bg-slate-100 p-2 rounded-lg border border-slate-200">
                <span>
                  معدل التزام وإنجاز القسم للسلامة: <strong>{completionRate}%</strong>
                </span>
                <span className="font-mono text-[10px] text-slate-600">
                  تاريخ استخراج البيانات: {dateFormattedAr} ({timeFormattedAr})
                </span>
              </div>
            </div>

            {/* 4. Table of Overdue Violations (جدول المخالفات المتأخرة والمهملة) */}
            <div className="mb-5">
              <h3 className="text-xs font-black text-slate-900 mb-2 flex items-center justify-between border-b border-slate-300 pb-1">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-rose-600 inline-block" />
                  <span>ثانياً: جدول المخالفات المتأخرة والمهملة الخاضعة للمحاسبة الإدارية:</span>
                </div>
                <span className="text-[10px] font-bold text-rose-700 bg-rose-100 px-2 py-0.5 rounded">
                  العدد: {overdueCount} مخالفة متأخرة
                </span>
              </h3>

              {overdueViolations.length === 0 ? (
                <div className="p-5 text-center bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-bold space-y-1">
                  <Check className="w-6 h-6 text-emerald-600 mx-auto" />
                  <p>يفيد قسم الأمن والسلامة بعدم وجود أي مخالفات أو ملاحظات متأخرة على هذا القسم حالياً.</p>
                  <p className="text-[11px] text-emerald-700 font-normal">
                    تم إنجاز كافة بنود السلامة ضمن المهل المحددة بنسبة امتثال 100%.
                  </p>
                </div>
              ) : (
                <div className="border border-slate-300 rounded-xl overflow-hidden">
                  <table className="w-full text-right text-[11px] border-collapse">
                    <thead className="bg-slate-200 text-slate-900 font-black border-b border-slate-300">
                      <tr>
                        <th className="p-2 border-l border-slate-300 whitespace-nowrap text-center">رقم البند</th>
                        <th className="p-2 border-l border-slate-300">وصف المخالفة / الخطر والموقع</th>
                        <th className="p-2 border-l border-slate-300 whitespace-nowrap">تاريخ الإشعار الأول</th>
                        <th className="p-2 border-l border-slate-300 whitespace-nowrap">المهلة الممنوحة</th>
                        <th className="p-2 border-l border-slate-300 whitespace-nowrap text-center">
                          مذكرات المتابعة المرسلة
                        </th>
                        <th className="p-2 whitespace-nowrap text-center">حالة الإهمال ومدة التأخير</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {overdueViolations.map((v, idx) => {
                        const deadlineInfo = analyzeViolationDeadline(v);
                        const party = v.assignedToCustom || v.assignedTo;

                        return (
                          <tr key={v.id} className={idx % 2 === 0 ? 'bg-white' : 'bg-rose-50/30'}>
                            {/* Item ID */}
                            <td className="p-2 border-l border-slate-200 font-mono font-bold text-center text-slate-900 whitespace-nowrap">
                              {v.id}
                              <span className="block text-[9px] text-slate-500 font-sans">
                                {v.severity === 'critical' ? '🔴 حرج' : v.severity === 'high' ? '🟠 مرتفع' : '🟡 متوسط'}
                              </span>
                            </td>

                            {/* Description & Hazard */}
                            <td className="p-2 border-l border-slate-200">
                              <span className="font-bold text-slate-900 block leading-snug">{v.description}</span>
                              <div className="text-[10px] text-slate-600 mt-0.5 space-y-0.5">
                                <span>📍 الموقع: {v.locationDetail}</span>
                                <span className="block">👷‍♂️ المكلف بالإنجاز: <strong className="text-slate-800">{party}</strong></span>
                              </div>
                            </td>

                            {/* First Notice Date */}
                            <td className="p-2 border-l border-slate-200 whitespace-nowrap font-mono text-slate-700">
                              {v.firstSentAt || v.createdAt || 'مسجل بالنظام'}
                            </td>

                            {/* Deadline */}
                            <td className="p-2 border-l border-slate-200 whitespace-nowrap">
                              <span className="font-mono font-bold text-slate-900 block">{v.deadlineAt}</span>
                              <span className="text-[10px] text-slate-500 block">
                                المهلة الأصلية: {v.deadlineHours || 24} ساعة
                              </span>
                            </td>

                            {/* Follow-up count */}
                            <td className="p-2 border-l border-slate-200 whitespace-nowrap text-center">
                              <span className="inline-block px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 font-mono font-black border border-amber-300">
                                {v.followUpCount || 0} مذكرات
                              </span>
                              {v.lastFollowUpAt && (
                                <span className="block text-[9px] text-slate-500 font-mono mt-0.5">
                                  آخر متابعة: {v.lastFollowUpAt}
                                </span>
                              )}
                            </td>

                            {/* Current Neglect Status & Overdue duration */}
                            <td className="p-2 whitespace-nowrap text-center">
                              <span className="inline-block px-2 py-0.5 rounded bg-rose-100 border border-rose-400 text-rose-900 font-black text-[10px] mb-0.5">
                                ⚠️ متأخر عن التنفيذ
                              </span>
                              <span className="block text-[10px] font-bold text-rose-700 font-mono">
                                متأخر: {deadlineInfo.overdueDays} يوم ({deadlineInfo.overdueDaysText})
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* 5. CBAHI & Quality Recommendation Paragraph */}
            <div className="mb-5 bg-amber-50/80 border-2 border-amber-400/80 rounded-xl p-3.5 space-y-1.5">
              <h4 className="text-xs font-black text-amber-950 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-amber-800 shrink-0" />
                <span>ثالثاً: التوصية الإدارية المسندة لمتطلبات الجودة والاعتماد وسباهي (CBAHI):</span>
              </h4>
              <p className="text-xs text-slate-800 leading-relaxed font-medium">
                استناداً إلى معايير المركز السعودي لاعتماد المنشآت الصحية (CBAHI - FMS Standards) ومعايير إدارة وسلامة
                المرافق الطبية، وحيث أن عدم تصحيح المخالفات المذكورة أعلاه ضمن المهلة الزمنية المحددة رغم إرسال مذكرات
                المتابعة المتتالية يُشكل خطراً داهماً يمس سلامة المرضى والكوادر الطبية وسلامة المنشأة، فضلاً عن تعريض
                المستشفى لمخاطر عدم المطابقة في الجولات التفتيشية الرسمية؛
              </p>
              <p className="text-xs text-slate-900 font-bold leading-relaxed pt-0.5">
                وعليه؛ ترفع إدارة السلامة العامة والمرافق (FMS) لسعادتكم التوصية باتخاذ الإجراءات الإدارية والمحاسبية
                الرادعة بحق المتسببين في التأخير، وإلزام القسم بسرعة استكمال المعالجة فوراً وتقديم إفادة إنجاز موثقة
                خلال 24 ساعة، مع تطبيق بنود اللائحة الجزائية المعتمدة بحق المقصرين.
              </p>
            </div>

            {/* 6. Official Signatures and General Director Decision Box */}
            <div className="border-t-2 border-slate-800 pt-4 mt-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Column A: Safety Head Signature */}
                <div className="border border-slate-300 rounded-xl p-3.5 bg-slate-50 space-y-3">
                  <div className="border-b border-slate-200 pb-1">
                    <span className="text-[10px] text-slate-500 font-bold block">مُعِد ورافع التقرير الرقابي:</span>
                    <strong className="text-xs font-black text-slate-900 block">
                      رئيس قسم الأمن والسلامة وإدارة المرافق (FMS)
                    </strong>
                  </div>
                  <div className="space-y-1.5 text-xs text-slate-800">
                    <div>
                      <span>المهندس المسؤول: </span>
                      <strong className="text-sm font-black text-slate-900">م / نجيب قاسم غازي</strong>
                    </div>
                    <div className="flex items-center justify-between pt-1">
                      <span>التوقيع: .......................................</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>الختم الرسمي: [ ختم قسم السلامة FMS ]</span>
                    </div>
                    <div className="text-[10px] text-slate-600 font-mono pt-1">
                      التاريخ: {dateFormattedAr}
                    </div>
                  </div>
                </div>

                {/* Column B: General Director Decision & Action Box */}
                <div className="border-2 border-slate-700 rounded-xl p-3.5 bg-white space-y-2">
                  <div className="border-b border-slate-300 pb-1 flex items-center justify-between">
                    <strong className="text-xs font-black text-slate-900">
                      قرار وتوجيه الأخ / المدير العام للمستشفى:
                    </strong>
                    <span className="text-[10px] font-bold text-slate-500">حفظه الله</span>
                  </div>

                  <div className="space-y-1.5 text-[11px] text-slate-800 font-medium">
                    <div className="flex items-start gap-1.5">
                      <span className="w-3.5 h-3.5 border border-slate-500 rounded inline-block mt-0.5 shrink-0" />
                      <span>يُلزم رئيس القسم والمكلف بالمعالجة الفورية خلال 24 ساعة تحت طائلة الإيقاف والخصم.</span>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <span className="w-3.5 h-3.5 border border-slate-500 rounded inline-block mt-0.5 shrink-0" />
                      <span>يُحال الموضوع للشؤون القانونية والموارد البشرية للتحقيق والمحاسبة الإدارية للإهمال.</span>
                    </div>
                    <div className="flex items-start gap-1.5">
                      <span className="w-3.5 h-3.5 border border-slate-500 rounded inline-block mt-0.5 shrink-0" />
                      <span>توجيه لفت نظر وإنذار نهائي للقسم لمخالفة معايير الجودة وسلامة المنشأة (CBAHI).</span>
                    </div>
                    <div className="pt-1">
                      <span>ملاحظات / توجيهات إدارية أخرى: ................................................................</span>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-xs text-slate-800">
                    <span>توقيع المدير العام: .............................</span>
                    <span>التاريخ: ...... / ...... / 2026م</span>
                  </div>
                </div>
              </div>

              {/* Watermark and Audit Verification */}
              <div className="mt-4 pt-2 text-center text-[10px] text-slate-500 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-1">
                <span>مستشفى آزال النموذجي - صنعاء • الرعاية الكاملة • هاتف طوارئ السلامة المعتمد: 96777738138</span>
                <span className="font-mono text-[9px] text-slate-400">
                  REF: {refCode} • System Timestamp: {today.toISOString()}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
