import React, { useState, useId } from 'react';
import {
  Printer,
  Copy,
  Check,
  X,
  Award,
  ShieldCheck,
  QrCode,
  Calendar,
  Building2,
  Clock,
  User,
  Download,
  CheckCircle2,
} from 'lucide-react';
import { TrainingCertificateRecord } from '../types';
import { printHtmlViaIframe } from '../utils/printUtils';

interface TrainingCertificatePrintModalProps {
  certificate: TrainingCertificateRecord;
  onClose: () => void;
  onLogAudit?: (action: string, actionAr: string, details: string) => void;
}

export const TrainingCertificatePrintModal: React.FC<TrainingCertificatePrintModalProps> = ({
  certificate,
  onClose,
  onLogAudit,
}) => {
  const [copied, setCopied] = useState(false);
  const containerId = `cert-canvas-${useId().replace(/:/g, '')}`;

  const certYear = certificate.training_date
    ? new Date(certificate.training_date).getFullYear()
    : 2026;

  // Format dates for display
  const formatDateAr = (dateStr: string) => {
    try {
      const d = new Date(dateStr);
      return d.toLocaleDateString('ar-YE', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      });
    } catch {
      return dateStr;
    }
  };

  const trainingDateAr = formatDateAr(certificate.training_date);
  const issueDateAr = formatDateAr(certificate.issue_date || certificate.training_date);

  // Generate printable HTML for Landscape A4 printing
  const generateCertificatePrintHtml = () => {
    return `<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="utf-8">
  <title>شهادة اجتياز وتأهيل تدريبي - ${certificate.trainee_name} - ${certificate.certificate_serial}</title>
  <style>
    @page {
      size: A4 landscape;
      margin: 0;
    }
    @media print {
      html, body {
        width: 297mm;
        height: 210mm;
        margin: 0;
        padding: 0;
        background: #ffffff !important;
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
      }
      .no-print {
        display: none !important;
      }
      .cert-page {
        page-break-after: avoid;
        break-after: avoid;
      }
    }
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    body {
      font-family: 'Segoe UI', Tahoma, Arial, sans-serif;
      background: #ffffff;
      color: #0f172a;
      direction: rtl;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      padding: 0;
    }
    .cert-page {
      width: 297mm;
      height: 210mm;
      padding: 8mm;
      background: #ffffff;
      position: relative;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }
    /* Luxury Geometric Borders */
    .outer-frame {
      width: 100%;
      height: 100%;
      border: 4px double #1e3a8a;
      outline: 1.5px solid #d97706;
      outline-offset: -6px;
      padding: 6mm 10mm;
      position: relative;
      background: linear-gradient(135deg, #ffffff 0%, #fbfbfb 50%, #ffffff 100%);
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }
    .inner-border {
      position: absolute;
      top: 10px;
      left: 10px;
      right: 10px;
      bottom: 10px;
      border: 1px dashed #b45309;
      pointer-events: none;
    }
    /* Corner Ornaments */
    .corner {
      position: absolute;
      width: 22px;
      height: 22px;
      border-color: #d97706;
      border-style: solid;
    }
    .corner-tr { top: 4px; right: 4px; border-width: 3px 3px 0 0; }
    .corner-tl { top: 4px; left: 4px; border-width: 3px 0 0 3px; }
    .corner-br { bottom: 4px; right: 4px; border-width: 0 3px 3px 0; }
    .corner-bl { bottom: 4px; left: 4px; border-width: 0 0 3px 3px; }

    /* Header */
    .cert-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      border-bottom: 2px solid #1e3a8a;
      padding-bottom: 6px;
    }
    .header-col-right {
      text-align: right;
      width: 33%;
    }
    .header-col-right h4 {
      font-size: 11pt;
      font-weight: bold;
      color: #0f172a;
    }
    .header-col-right h3 {
      font-size: 13pt;
      font-weight: 900;
      color: #1e3a8a;
      margin: 1px 0;
    }
    .header-col-right p {
      font-size: 9.5pt;
      font-weight: bold;
      color: #b45309;
    }
    .header-col-center {
      text-align: center;
      width: 36%;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
    }
    .logo-img {
      max-height: 48px;
      width: auto;
      max-width: 170px;
      object-fit: contain;
    }
    .header-col-center span {
      font-size: 8.5pt;
      font-weight: bold;
      color: #047857;
      margin-top: 2px;
    }
    .header-col-left {
      text-align: left;
      width: 33%;
      direction: ltr;
      font-size: 9pt;
      color: #334155;
    }
    .badge-serial {
      display: inline-block;
      background: #f1f5f9;
      border: 1px solid #cbd5e1;
      padding: 3px 8px;
      border-radius: 4px;
      font-weight: 900;
      font-family: monospace;
      color: #1e3a8a;
      margin-bottom: 3px;
    }

    /* Certificate Title Banner */
    .title-banner {
      text-align: center;
      margin: 10px 0 6px 0;
    }
    .main-title {
      font-size: 24pt;
      font-weight: 900;
      color: #1e3a8a;
      letter-spacing: -0.5px;
      text-shadow: 1px 1px 0px #e2e8f0;
    }
    .sub-title {
      font-size: 12pt;
      font-weight: 700;
      color: #b45309;
      letter-spacing: 2px;
      text-transform: uppercase;
      font-family: 'Times New Roman', serif;
    }
    .ribbon-divider {
      width: 140px;
      height: 3px;
      background: linear-gradient(to right, transparent, #d97706, transparent);
      margin: 4px auto;
    }

    /* Certificate Body Text */
    .cert-body {
      text-align: center;
      padding: 6px 15px;
      line-height: 1.8;
    }
    .intro-text {
      font-size: 12pt;
      color: #334155;
      font-weight: 600;
    }
    .trainee-name-box {
      margin: 6px auto;
      display: inline-block;
      padding: 3px 30px;
      border-bottom: 2px solid #d97706;
    }
    .trainee-name {
      font-size: 20pt;
      font-weight: 900;
      color: #0f172a;
    }
    .trainee-dept {
      font-size: 11pt;
      font-weight: bold;
      color: #1e3a8a;
    }
    .statement-text {
      font-size: 12pt;
      color: #1e293b;
      margin-top: 4px;
    }
    .course-name-box {
      background: #eff6ff;
      border: 1px solid #bfdbfe;
      border-radius: 8px;
      padding: 6px 16px;
      margin: 6px auto;
      display: inline-block;
      max-width: 90%;
    }
    .course-name {
      font-size: 14pt;
      font-weight: 900;
      color: #1e3a8a;
    }
    .details-text {
      font-size: 11pt;
      color: #334155;
      margin-top: 3px;
    }
    .details-text strong {
      color: #0f172a;
    }

    /* Three-Party Signatures */
    .signatures-section {
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
      margin-top: 8px;
      padding-top: 8px;
      border-top: 1.5px solid #cbd5e1;
    }
    .sig-col {
      width: 31%;
      text-align: center;
      font-size: 9.5pt;
      position: relative;
    }
    .sig-title {
      font-weight: bold;
      color: #1e3a8a;
      margin-bottom: 2px;
    }
    .sig-name {
      font-size: 11pt;
      font-weight: 900;
      color: #0f172a;
      margin-bottom: 20px;
    }
    .sig-line {
      border-top: 1px dashed #94a3b8;
      width: 80%;
      margin: 0 auto;
      padding-top: 3px;
      color: #475569;
      font-size: 8.5pt;
    }
    .stamp-box {
      width: 65px;
      height: 65px;
      border: 2px dashed #dc2626;
      border-radius: 50%;
      margin: 0 auto 5px auto;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #dc2626;
      font-size: 7.5pt;
      font-weight: bold;
      text-align: center;
      line-height: 1.1;
      transform: rotate(-10deg);
      background: rgba(254, 242, 242, 0.4);
    }

    /* QR Corner Badge */
    .qr-corner {
      position: absolute;
      bottom: 8px;
      left: 12px;
      display: flex;
      align-items: center;
      gap: 6px;
      background: #ffffff;
      border: 1px solid #cbd5e1;
      padding: 3px 6px;
      border-radius: 6px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.05);
      z-index: 10;
    }
    .qr-code-img {
      width: 44px;
      height: 44px;
    }
    .qr-meta {
      font-size: 7.5pt;
      color: #475569;
      line-height: 1.2;
      text-align: right;
    }
    .qr-meta strong {
      color: #1e3a8a;
      font-family: monospace;
      font-size: 8pt;
      display: block;
    }
  </style>
</head>
<body>
  <div class="cert-page">
    <div class="outer-frame">
      <div class="inner-border"></div>
      <div class="corner corner-tr"></div>
      <div class="corner corner-tl"></div>
      <div class="corner corner-br"></div>
      <div class="corner corner-bl"></div>

      <!-- 1. Official Header (No Ministry of Health) -->
      <div class="cert-header">
        <div class="header-col-right">
          <h4>الجمهورية اليمنية</h4>
          <h3>مستشفى آزال النموذجي - صنعاء</h3>
          <p>إدارة الأمن والسلامة وإدارة المرافق (FMS)</p>
        </div>

        <div class="header-col-center">
          <img src="/azal-logo.svg" alt="شعار مستشفى آزال النموذجي" class="logo-img" />
          <span>برنامج التأهيل والسلامة المهنية • معتمد سباهي CBAHI</span>
        </div>

        <div class="header-col-left">
          <div class="badge-serial">REF: ${certificate.certificate_serial}</div>
          <div><strong>تاريخ الإصدار:</strong> ${certificate.issue_date || certificate.training_date}</div>
          <div><strong>كود الاعتماد:</strong> CBAHI-FMS-${certYear}</div>
        </div>
      </div>

      <!-- 2. Prominent Title -->
      <div class="title-banner">
        <div class="sub-title">Republic of Yemen • Azal Model Hospital</div>
        <h1 class="main-title">شهادة اجتياز وتأهيل تدريبي</h1>
        <div class="sub-title">Certificate of Training Completion</div>
        <div class="ribbon-divider"></div>
      </div>

      <!-- 3. Official Certificate Text -->
      <div class="cert-body">
        <p class="intro-text">
          تشهد إدارة الأمن والسلامة وإدارة المرافق بمستشفى آزال النموذجي بأن الأخ / الأخت:
        </p>

        <div class="trainee-name-box">
          <div class="trainee-name">${certificate.trainee_name}</div>
          <div class="trainee-dept">من قسم: ${certificate.department} ${certificate.job_title ? `(${certificate.job_title})` : ''}</div>
        </div>

        <p class="statement-text">
          قد اجتاز/ت بنجاح واقتدار البرنامج التدريبي والتأهيلي المعتمد بعنوان:
        </p>

        <div class="course-name-box">
          <div class="course-name">${certificate.course_name}</div>
        </div>

        <p class="details-text">
          بواقع <strong>(${certificate.duration_hours}) ساعات تدريبية</strong> وتطبيق ميداني محاكي، 
          بتاريخ: <strong>${trainingDateAr}</strong>، وبتقدير: <strong>${certificate.grade_or_evaluation || 'اجتياز بنجاح وتفوق'}</strong>.
        </p>
      </div>

      <!-- 4. Three-Party Signatures -->
      <div class="signatures-section">
        <!-- Right: Trainer -->
        <div class="sig-col">
          <div class="sig-title">مدرب الدورة / المشرف الميداني</div>
          <div class="sig-name">${certificate.trainer_name || 'م. مدرب السلامة المعتمد'}</div>
          <div class="sig-line">التوقيع: .......................................</div>
        </div>

        <!-- Center: Head of Safety & FMS -->
        <div class="sig-col">
          <div class="sig-title">رئيس قسم الأمن والسلامة وإدارة المرافق</div>
          <div class="sig-name">م / نجيب قاسم غازي</div>
          <div class="sig-line">الختم والتوقيع: .......................................</div>
        </div>

        <!-- Left: General Director with Hospital Seal -->
        <div class="sig-col">
          <div class="stamp-box">
            الختم الرسمي<br/>لمستشفى آزال<br/>النموذجي
          </div>
          <div class="sig-title">المدير العام للمستشفى</div>
          <div class="sig-name">${certificate.general_manager_name || 'د / محمد السراجي'}</div>
          <div class="sig-line">الاعتماد والتوقيع: .......................................</div>
        </div>
      </div>

      <!-- 5. Verification QR Badge in Corner -->
      <div class="qr-corner">
        <!-- SVG Generated QR Code Pattern -->
        <svg class="qr-code-img" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect width="100" height="100" fill="#ffffff" rx="4" />
          <!-- QR Finders -->
          <rect x="6" y="6" width="28" height="28" fill="#1e3a8a" rx="3" />
          <rect x="10" y="10" width="20" height="20" fill="#ffffff" rx="2" />
          <rect x="14" y="14" width="12" height="12" fill="#1e3a8a" rx="1" />

          <rect x="66" y="6" width="28" height="28" fill="#1e3a8a" rx="3" />
          <rect x="70" y="10" width="20" height="20" fill="#ffffff" rx="2" />
          <rect x="74" y="14" width="12" height="12" fill="#1e3a8a" rx="1" />

          <rect x="6" y="66" width="28" height="28" fill="#1e3a8a" rx="3" />
          <rect x="10" y="70" width="20" height="20" fill="#ffffff" rx="2" />
          <rect x="14" y="74" width="12" height="12" fill="#1e3a8a" rx="1" />

          <!-- QR Data Dots -->
          <rect x="40" y="10" width="6" height="6" fill="#b45309" />
          <rect x="50" y="10" width="6" height="6" fill="#1e3a8a" />
          <rect x="40" y="22" width="6" height="6" fill="#1e3a8a" />
          <rect x="52" y="24" width="6" height="6" fill="#b45309" />
          <rect x="12" y="42" width="6" height="6" fill="#1e3a8a" />
          <rect x="24" y="42" width="6" height="6" fill="#1e3a8a" />
          <rect x="36" y="42" width="6" height="6" fill="#b45309" />
          <rect x="48" y="42" width="6" height="6" fill="#1e3a8a" />
          <rect x="60" y="42" width="6" height="6" fill="#1e3a8a" />
          <rect x="72" y="42" width="6" height="6" fill="#b45309" />
          <rect x="84" y="42" width="6" height="6" fill="#1e3a8a" />
          <rect x="42" y="54" width="6" height="6" fill="#1e3a8a" />
          <rect x="54" y="54" width="6" height="6" fill="#b45309" />
          <rect x="66" y="54" width="6" height="6" fill="#1e3a8a" />
          <rect x="42" y="66" width="6" height="6" fill="#b45309" />
          <rect x="54" y="66" width="6" height="6" fill="#1e3a8a" />
          <rect x="66" y="66" width="6" height="6" fill="#1e3a8a" />
          <rect x="42" y="78" width="6" height="6" fill="#1e3a8a" />
          <rect x="54" y="78" width="6" height="6" fill="#1e3a8a" />
          <rect x="66" y="78" width="6" height="6" fill="#b45309" />
          <rect x="78" y="78" width="6" height="6" fill="#1e3a8a" />
        </svg>
        <div class="qr-meta">
          <strong>${certificate.certificate_serial}</strong>
          <span>تحقق فوري من الاعتماد</span>
        </div>
      </div>
    </div>
  </div>
</body>
</html>`;
  };

  // Handle direct high-quality A4 Landscape printing
  const handlePrint = () => {
    const fullHtml = generateCertificatePrintHtml();
    printHtmlViaIframe(fullHtml, `شهادة تدريب - ${certificate.trainee_name} - ${certificate.certificate_serial}`);

    if (onLogAudit) {
      onLogAudit(
        'PRINT_TRAINING_CERTIFICATE',
        'طباعة شهادة تدريب رسمية',
        `تمت طباعة شهادة الاجتياز الرسمية للمتدرب (${certificate.trainee_name}) برقم تسلسلي (${certificate.certificate_serial}) لدورة (${certificate.course_name}).`
      );
    }
  };

  // Handle Copy text memo
  const handleCopyText = () => {
    const textMemo = `
==============================================
الجمهورية اليمنية - مستشفى آزال النموذجي - صنعاء
إدارة الأمن والسلامة وإدارة المرافق (FMS)
==============================================
شهادة اجتياز وتأهيل تدريبي (Certificate of Completion)
الرقم التسلسلي: ${certificate.certificate_serial}
تاريخ الإصدار: ${certificate.issue_date || certificate.training_date}

تشهد إدارة الأمن والسلامة وإدارة المرافق بمستشفى آزال النموذجي بأن الأخ/الأخت:
[ ${certificate.trainee_name} ] - من قسم [ ${certificate.department} ]
قد اجتاز/ت بنجاح البرنامج التدريبي بعنوان:
"${certificate.course_name}"
بواقع (${certificate.duration_hours}) ساعات تدريبية وتطبيق ميداني، بتاريخ: ${trainingDateAr}.

الاعتماد الثلاثي:
- مدرب الدورة: ${certificate.trainer_name}
- رئيس قسم الأمن والسلامة FMS: م/ نجيب قاسم غازي
- المدير العام للمستشفى: ${certificate.general_manager_name || 'د/ محمد السراجي'}
==============================================
    `.trim();

    navigator.clipboard.writeText(textMemo).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    });
  };

  return (
    <div
      id="training-certificate-modal"
      className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto"
    >
      <div className="bg-slate-900 border border-slate-700/90 rounded-3xl w-full max-w-6xl my-auto shadow-2xl overflow-hidden flex flex-col max-h-[96vh]">
        {/* Top Floating Control Bar */}
        <div className="p-3.5 bg-slate-950 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-2xl bg-amber-500/10 text-amber-400 border border-amber-500/30">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-black text-white">
                  معاينة شهادة الاجتياز والتأهيل الرسمي (A4 Landscape)
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-blue-950 text-blue-300 border border-blue-700 font-mono text-[10px] font-bold">
                  {certificate.certificate_serial}
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                المتدرب: <strong className="text-slate-200">{certificate.trainee_name}</strong> • القسم: {certificate.department}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Copy Button */}
            <button
              type="button"
              onClick={handleCopyText}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center gap-1.5 transition active:scale-95 border border-slate-700"
              title="نسخ بيانات الشهادة كنص"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-300" />}
              <span>{copied ? 'تم النسخ' : 'نسخ البيانات'}</span>
            </button>

            {/* Print Button (A4 Landscape) */}
            <button
              type="button"
              id="btn-print-certificate-landscape"
              onClick={handlePrint}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-600 via-amber-700 to-blue-900 hover:from-amber-500 hover:to-blue-800 text-white font-black text-xs flex items-center gap-2 shadow-lg shadow-amber-950/60 transition active:scale-95 border border-amber-500/40"
              title="طباعة الشهادة الرسمية أو تصديرها كملف PDF بقياس A4 أفقي"
            >
              <Printer className="w-4 h-4 text-amber-200" />
              <span>🖨️ طباعة الشهادة / حفظ PDF</span>
            </button>

            {/* Close Button */}
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
              title="إغلاق المعاينة"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Live Landscape Certificate Preview Canvas */}
        <div className="p-4 sm:p-8 overflow-y-auto overflow-x-auto bg-slate-950/70 flex justify-center items-center flex-1">
          {/* Certificate Sheet - Rendered with exact A4 Landscape aspect ratio */}
          <div
            id={containerId}
            className="w-full max-w-4xl bg-white text-slate-900 p-6 sm:p-10 shadow-2xl rounded-sm border-4 border-slate-900 relative font-sans text-right select-text"
            style={{
              aspectRatio: '297 / 210',
              backgroundImage: 'radial-gradient(#f8fafc 15%, transparent 16%)',
              backgroundSize: '16px 16px',
            }}
          >
            {/* Outer Geometric Gold & Navy Frame */}
            <div className="w-full h-full border-2 border-amber-600 outline outline-2 outline-slate-900 outline-offset-4 p-5 sm:p-7 relative flex flex-col justify-between bg-white/95">
              {/* Corner Ornaments */}
              <div className="absolute top-1 right-1 w-5 h-5 border-t-2 border-r-2 border-amber-600" />
              <div className="absolute top-1 left-1 w-5 h-5 border-t-2 border-l-2 border-amber-600" />
              <div className="absolute bottom-1 right-1 w-5 h-5 border-b-2 border-r-2 border-amber-600" />
              <div className="absolute bottom-1 left-1 w-5 h-5 border-b-2 border-l-2 border-amber-600" />

              {/* 1. Official Institutional Header */}
              <div className="border-b-2 border-slate-900 pb-3 flex items-center justify-between gap-2">
                {/* Right: Country & Hospital */}
                <div className="w-1/3 text-right">
                  <div className="text-[11px] font-bold text-slate-700">الجمهورية اليمنية</div>
                  <div className="text-base font-black text-slate-900">مستشفى آزال النموذجي - صنعاء</div>
                  <div className="text-xs font-bold text-amber-700">إدارة الأمن والسلامة وإدارة المرافق (FMS)</div>
                </div>

                {/* Center: Official Logo */}
                <div className="w-1/3 flex flex-col items-center justify-center text-center">
                  <div className="max-h-14 py-1 flex items-center justify-center mb-0.5">
                    <img
                      src="/azal-logo.svg"
                      alt="شعار مستشفى آزال النموذجي"
                      className="max-h-12 w-auto object-contain"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <span className="text-[10px] font-black text-emerald-800">برنامج التأهيل والسلامة المهنية • CBAHI</span>
                </div>

                {/* Left: Serial Code & Date */}
                <div className="w-1/3 text-left dir-ltr space-y-0.5 text-xs text-slate-700 font-mono">
                  <div className="inline-block bg-slate-100 border border-slate-300 px-2 py-0.5 rounded font-black text-blue-900 text-[11px]">
                    REF: {certificate.certificate_serial}
                  </div>
                  <div className="text-[10px]">
                    <strong>Issue Date:</strong> {certificate.issue_date || certificate.training_date}
                  </div>
                  <div className="text-[10px] text-amber-800 font-bold">
                    CBAHI-FMS Standard Compliant
                  </div>
                </div>
              </div>

              {/* 2. Prominent Certificate Title Banner */}
              <div className="text-center my-3 sm:my-4">
                <div className="text-[10px] sm:text-xs font-serif tracking-widest text-amber-700 uppercase font-bold">
                  Republic of Yemen • Azal Model Hospital
                </div>
                <h1 className="text-2xl sm:text-3xl font-black text-slate-950 tracking-tight mt-1">
                  شهادة اجتياز وتأهيل تدريبي
                </h1>
                <div className="text-xs sm:text-sm font-serif tracking-widest text-slate-600 font-bold uppercase mt-0.5">
                  Certificate of Training Completion
                </div>
                <div className="w-32 h-1 bg-gradient-to-r from-transparent via-amber-500 to-transparent mx-auto mt-2" />
              </div>

              {/* 3. Official Certificate Body Text */}
              <div className="text-center px-4 space-y-2 text-xs sm:text-sm leading-relaxed">
                <p className="text-slate-700 font-semibold">
                  تشهد إدارة الأمن والسلامة وإدارة المرافق بمستشفى آزال النموذجي بأن الأخ / الأخت:
                </p>

                <div className="inline-block border-b-2 border-amber-600 px-8 py-1 my-1">
                  <span className="text-xl sm:text-2xl font-black text-slate-900 block">
                    {certificate.trainee_name}
                  </span>
                  <span className="text-xs font-bold text-blue-900">
                    من قسم: {certificate.department} {certificate.job_title ? `(${certificate.job_title})` : ''}
                  </span>
                </div>

                <p className="text-slate-800 font-medium">
                  قد اجتاز/ت بنجاح واقتدار البرنامج التدريبي والتأهيلي المعتمد بعنوان:
                </p>

                <div className="inline-block bg-blue-50/80 border border-blue-200 rounded-xl px-5 py-2 my-1 max-w-xl">
                  <span className="text-sm sm:text-base font-black text-blue-950">
                    {certificate.course_name}
                  </span>
                </div>

                <p className="text-slate-700 font-medium text-xs sm:text-sm">
                  بواقع <strong>({certificate.duration_hours}) ساعات تدريبية</strong> وتطبيق ميداني محاكي، 
                  بتاريخ: <strong>{trainingDateAr}</strong>، وبتقدير: <strong className="text-emerald-800">{certificate.grade_or_evaluation || 'اجتياز بنجاح وتفوق'}</strong>.
                </p>
              </div>

              {/* 4. Three-Party Signatures and QR Code */}
              <div className="mt-4 pt-3 border-t-2 border-slate-300 flex items-end justify-between gap-4 text-xs">
                {/* Column 1: Trainer */}
                <div className="w-1/3 text-center space-y-1">
                  <span className="text-[11px] font-bold text-blue-950 block">
                    مدرب الدورة / المشرف الميداني
                  </span>
                  <strong className="text-xs sm:text-sm font-black text-slate-900 block mb-6">
                    {certificate.trainer_name || 'م. مدرب السلامة المعتمد'}
                  </strong>
                  <div className="text-[11px] text-slate-600 border-t border-dashed border-slate-400 pt-1 w-3/4 mx-auto">
                    التوقيع: .....................
                  </div>
                </div>

                {/* Column 2: Head of Safety & FMS */}
                <div className="w-1/3 text-center space-y-1">
                  <span className="text-[11px] font-bold text-blue-950 block">
                    رئيس قسم الأمن والسلامة وإدارة المرافق
                  </span>
                  <strong className="text-xs sm:text-sm font-black text-slate-900 block mb-6">
                    م / نجيب قاسم غازي
                  </strong>
                  <div className="text-[11px] text-slate-600 border-t border-dashed border-slate-400 pt-1 w-3/4 mx-auto">
                    الختم والتوقيع: .....................
                  </div>
                </div>

                {/* Column 3: General Director with Stamp Area */}
                <div className="w-1/3 text-center space-y-1 relative">
                  <div className="w-14 h-14 rounded-full border-2 border-dashed border-rose-600 mx-auto mb-1 flex items-center justify-center text-rose-700 text-[9px] font-black -rotate-12 bg-rose-50/40">
                    الختم الرسمي<br />لمستشفى آزال
                  </div>
                  <span className="text-[11px] font-bold text-blue-950 block">
                    المدير العام للمستشفى
                  </span>
                  <strong className="text-xs sm:text-sm font-black text-slate-900 block mb-3">
                    {certificate.general_manager_name || 'د / محمد السراجي'}
                  </strong>
                  <div className="text-[11px] text-slate-600 border-t border-dashed border-slate-400 pt-1 w-3/4 mx-auto">
                    الاعتماد والتوقيع: .....................
                  </div>
                </div>
              </div>

              {/* QR Code corner block */}
              <div className="absolute bottom-3 left-4 flex items-center gap-2 bg-slate-50 border border-slate-200 p-1.5 rounded-lg shadow-sm">
                <QrCode className="w-8 h-8 text-blue-900" />
                <div className="text-[9px] font-mono text-slate-700 text-left">
                  <div className="font-bold text-blue-950">{certificate.certificate_serial}</div>
                  <div className="text-emerald-700 font-sans font-bold">معتمد رسمياً ✓</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
