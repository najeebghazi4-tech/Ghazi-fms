import React from 'react';
import { 
  ShieldAlert, 
  AlertTriangle, 
  Flame, 
  BellRing, 
  CheckCircle2, 
  Radio, 
  Building2, 
  Sparkles,
  Download,
  Image as ImageIcon,
  FlaskConical,
  Lock,
  Wrench,
  Award,
  Target
} from 'lucide-react';
import { AzalLogo } from './AzalLogo';
import { ActiveEmergencyAlert, StaffUser } from '../types';
import { AZAL_EMERGENCY_CODES } from '../data/azalSecurityData';

interface AzalHeaderProps {
  activeAlerts: ActiveEmergencyAlert[];
  currentUser?: StaffUser;
  isReadOnly?: boolean;
  onOpenEmergencyModal: () => void;
  onOpenLogoModal: () => void;
  onResolveAlert: (alertId: string) => void;
  onOpenInstallModal?: () => void;
  onOpenIncomingReportsModal?: () => void;
  onOpenMsdsModal?: () => void;
  onOpenFireDrillModal?: () => void;
  onOpenPmModal?: () => void;
  onOpenCbahiRegisters?: () => void;
  onOpenFocusPdcaModal?: () => void;
  onOpenGuidelinesModal?: () => void;
  onLogout?: () => void;
  incomingReportsCount?: number;
  overdueViolationsCount?: number;
}

export const AzalHeader: React.FC<AzalHeaderProps> = ({
  activeAlerts,
  currentUser,
  isReadOnly = false,
  onOpenEmergencyModal,
  onOpenLogoModal,
  onResolveAlert,
  onOpenInstallModal,
  onOpenIncomingReportsModal,
  onOpenMsdsModal,
  onOpenFireDrillModal,
  onOpenPmModal,
  onOpenCbahiRegisters,
  onOpenFocusPdcaModal,
  onOpenGuidelinesModal,
  onLogout,
  incomingReportsCount = 4,
  overdueViolationsCount = 0,
}) => {
  const isDirector = currentUser?.role === 'general_director' || isReadOnly;
  const activeAlert = activeAlerts.find((a) => a.status === 'active');
  const alertDef = activeAlert
    ? AZAL_EMERGENCY_CODES.find((c) => c.type === activeAlert.codeType)
    : null;

  return (
    <header className="bg-slate-900/95 border-b border-slate-800 backdrop-blur-md sticky top-7 z-30 shadow-xl text-right">
      {/* Active Emergency Alert Ribbon (إذا كان هناك كود طوارئ نشط) */}
      {activeAlert && alertDef && (
        <div className={`${alertDef.bgClass} border-b ${alertDef.borderClass} px-3 sm:px-4 py-2 text-xs flex flex-wrap items-center justify-between gap-2 animate-pulse`}>
          <div className="flex items-center gap-2">
            <div className="p-1 rounded-lg bg-black/40 text-white shadow">
              <BellRing className="w-4 h-4 animate-bounce" />
            </div>
            <div>
              <span className={`font-black ${alertDef.colorClass} text-sm ml-2`}>
                تنبيه طارئ نشط: {alertDef.nameAr}
              </span>
              <span className="text-slate-200 text-xs">
                الموقع: <strong>{activeAlert.location}</strong> ({activeAlert.activatedAt})
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] text-slate-300 hidden md:inline">
              {activeAlert.notes}
            </span>
            <button
              type="button"
              onClick={() => onResolveAlert(activeAlert.id)}
              className="px-3 py-1 bg-black/60 hover:bg-black/80 text-white rounded-lg text-xs font-bold border border-white/20 transition"
            >
              إنهاء وتأكيد سلامة الموقع ✓
            </button>
          </div>
        </div>
      )}

      {/* Main Brand Bar */}
      <div className="w-full max-w-5xl mx-auto px-3 sm:px-4 py-2.5 flex items-center justify-between gap-2">
        {/* Azal Official Logo & Hospital Identity */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onOpenLogoModal}
            className="flex items-center text-right group focus:outline-none cursor-pointer"
            title="عرض الهوية البصرية وشعار مستشفى آزال - الرعاية الكاملة"
          >
            <AzalLogo size="md" showText={true} />
          </button>
        </div>

        {/* Action Buttons: Hospital Logo view + Mobile Install + Emergency Codes Trigger */}
        <div className="flex items-center gap-2">
          {/* Incoming Statements & Field Reports Trigger Button */}
          {onOpenIncomingReportsModal && (
            <button
              type="button"
              onClick={onOpenIncomingReportsModal}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-800 to-teal-800 hover:from-emerald-700 hover:to-teal-700 text-emerald-100 text-xs font-bold border border-emerald-500/50 shadow-md shadow-emerald-950/50 transition active:scale-95"
              title="عرض مركز الإفادات المعتمدة وكافة البلاغات الميدانية الواردة"
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping shrink-0" />
              <span>📋 مركز الإفادات والبلاغات</span>
              <span className="px-1.5 py-0.2 rounded-full bg-emerald-950 text-emerald-300 text-[10px] font-mono border border-emerald-600">
                {incomingReportsCount}
              </span>
            </button>
          )}

          {/* Mobile PWA Install Button */}
          {onOpenInstallModal && (
            <button
              type="button"
              onClick={onOpenInstallModal}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white text-xs font-bold shadow-md shadow-teal-950 transition active:scale-95"
              title="تثبيت نظام مستشفى آزال كتطبيق مستقل على هاتفك (PWA)"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">تثبيت على الهاتف</span>
              <span className="sm:hidden">تثبيت</span>
            </button>
          )}

          {/* MSDS Chemical Safety Library Trigger */}
          {onOpenMsdsModal && (
            <button
              type="button"
              onClick={onOpenMsdsModal}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 hover:text-white border border-teal-600/40 text-xs font-bold transition shadow-sm cursor-pointer active:scale-95"
              title="مكتبة صحائف بيانات سلامة المواد الكيميائية (MSDS) وفق السياسة FMS-APP-070EA"
            >
              <FlaskConical className="w-3.5 h-3.5 text-teal-400" />
              <span className="hidden sm:inline">مكتبة MSDS</span>
              <span className="sm:hidden">MSDS</span>
            </button>
          )}

          {/* Fire Drill Evaluation Trigger */}
          {onOpenFireDrillModal && (
            <button
              type="button"
              onClick={onOpenFireDrillModal}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-rose-300 hover:text-white border border-rose-600/40 text-xs font-bold transition shadow-sm cursor-pointer active:scale-95"
              title="وحدة تقييم تجارب الحريق والإخلاء الفرضية وفق السياسات FMS-PLAN-008EA و FMS-PLAN-0011EA"
            >
              <Flame className="w-3.5 h-3.5 text-rose-400" />
              <span className="hidden sm:inline">تجارب الإخلاء</span>
              <span className="sm:hidden">فرضيات</span>
            </button>
          )}

          {/* Preventive Maintenance (CBAHI FMS) Trigger */}
          {onOpenPmModal && (
            <button
              type="button"
              onClick={onOpenPmModal}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-blue-300 hover:text-white border border-blue-600/40 text-xs font-bold transition shadow-sm cursor-pointer active:scale-95"
              title="الصيانة الوقائية وإدارة المرافق (CBAHI FMS) - صيانة خدمات المرافق USM والأجهزة الطبية MEM"
            >
              <Wrench className="w-3.5 h-3.5 text-blue-400" />
              <span className="hidden sm:inline">الصيانة الوقائية</span>
              <span className="sm:hidden">صيانة</span>
            </button>
          )}

          {/* CBAHI Central Registers Trigger */}
          {onOpenCbahiRegisters && (
            <button
              type="button"
              onClick={onOpenCbahiRegisters}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-950/70 hover:bg-amber-900/80 text-amber-300 hover:text-white border border-amber-500/50 text-xs font-bold transition shadow-sm cursor-pointer active:scale-95"
              title="سجلات وبوابات الامتثال الكاملة لمعايير سباهي (CBAHI Comprehensive Compliance System)"
            >
              <Award className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">سجلات سباهي</span>
              <span className="sm:hidden">سباهي</span>
            </button>
          )}

          {/* CBAHI Quality & Continuous Improvement (FOCUS-PDCA) Trigger */}
          {onOpenFocusPdcaModal && (
            <button
              type="button"
              id="header-focus-pdca-btn"
              onClick={onOpenFocusPdcaModal}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-teal-900 via-indigo-950 to-purple-950 hover:from-teal-800 hover:to-indigo-900 text-teal-200 hover:text-white border border-teal-400/50 text-xs font-black transition shadow-sm cursor-pointer active:scale-95 ring-1 ring-teal-400/30"
              title="تقرير مؤشرات أداء الجودة ومنهجية التحسين المستمر (CBAHI FOCUS-PDCA KPI Report)"
            >
              <Target className="w-3.5 h-3.5 text-teal-300 animate-pulse" />
              <span className="hidden sm:inline">منهجية FOCUS-PDCA</span>
              <span className="sm:hidden">PDCA</span>
            </button>
          )}

          {/* Safety Guidelines & Hazard Alerts Center Trigger */}
          {onOpenGuidelinesModal && (
            <button
              type="button"
              onClick={onOpenGuidelinesModal}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-600 via-orange-600 to-rose-600 hover:from-amber-500 hover:to-rose-500 text-white border border-amber-400/60 text-xs font-black transition shadow-md cursor-pointer active:scale-95"
              title="مركز التعليمات والإرشادات والتحذيرات (Safety Guidelines & Hazard Alerts) - معايير سباهي CBAHI FMS"
            >
              <AlertTriangle className="w-3.5 h-3.5 text-amber-200 animate-pulse" />
              <span className="hidden sm:inline">إرشادات وتحذيرات السلامة ⚠️</span>
              <span className="sm:hidden">إرشادات السلامة ⚠️</span>
            </button>
          )}

          {/* Logo Showcase Button */}
          <button
            type="button"
            onClick={onOpenLogoModal}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-emerald-500/30 text-xs font-bold transition shadow-sm"
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>شعار أزال</span>
          </button>

          {/* Emergency Code Trigger Button with Overdue Badge (Replaced with Read-Only Badge for General Director) */}
          {isDirector ? (
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-950/80 border border-emerald-750 text-emerald-300 text-xs font-bold shadow-sm">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>رقابة إشرافية (قراءة فقط)</span>
            </div>
          ) : (
            <button
              type="button"
              onClick={onOpenEmergencyModal}
              className="relative flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-rose-700 to-red-600 hover:from-rose-600 hover:to-red-500 text-white text-xs font-black shadow-lg shadow-rose-950/60 border border-rose-500/40 transition active:scale-95"
              title={overdueViolationsCount > 0 ? `تنبيه: توجد (${overdueViolationsCount}) مخالفات متجاوزة للمهلة المحددة` : 'أكواد الطوارئ'}
            >
              <ShieldAlert className="w-4 h-4 text-rose-200 animate-pulse" />
              <span>أكواد الطوارئ</span>
              {overdueViolationsCount > 0 && (
                <span className="absolute -top-2 -left-1.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-rose-600 px-1 text-[10px] font-black text-white shadow-lg shadow-rose-950 ring-2 ring-slate-900 animate-bounce">
                  {overdueViolationsCount}
                </span>
              )}
            </button>
          )}

          {/* Quick Lock / Logout Button */}
          {onLogout && (
            <button
              type="button"
              onClick={onLogout}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-rose-950/80 text-slate-300 hover:text-rose-300 border border-slate-700 hover:border-rose-700/50 text-xs font-bold transition shadow-sm cursor-pointer active:scale-95"
              title="قفل المنظومة وتسجيل الخروج الفوري"
            >
              <Lock className="w-3.5 h-3.5 text-rose-400" />
              <span className="hidden md:inline">قفل / خروج</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
