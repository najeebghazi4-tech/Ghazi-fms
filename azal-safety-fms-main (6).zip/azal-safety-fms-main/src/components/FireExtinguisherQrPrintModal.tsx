import React, { useState, useEffect } from 'react';
import { 
  X, 
  Printer, 
  Flame, 
  QrCode, 
  Search, 
  Filter, 
  CheckSquare, 
  Square, 
  Download, 
  Layers, 
  MapPin, 
  Sparkles 
} from 'lucide-react';
import { FireExtinguisherItem } from '../types';
import { AZAL_MASTER_FIRE_EXTINGUISHERS } from '../data/azalHospitalSafetyRegistry';
import { generateExtinguisherQrDataUrl } from '../utils/fireExtinguisherQrUtils';
import { executeSmartPrint } from '../utils/printUtils';

interface FireExtinguisherQrPrintModalProps {
  extinguishers: FireExtinguisherItem[];
  onClose: () => void;
}

export const FireExtinguisherQrPrintModal: React.FC<FireExtinguisherQrPrintModalProps> = ({
  extinguishers,
  onClose,
}) => {
  const [qrMap, setQrMap] = useState<Record<string, string>>({});
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFloor, setSelectedFloor] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [isGenerating, setIsGenerating] = useState(true);

  const activeExtinguishers = extinguishers.length > 0 ? extinguishers : AZAL_MASTER_FIRE_EXTINGUISHERS;

  // Generate QR code data URLs for all extinguishers
  useEffect(() => {
    let isMounted = true;
    const generateAllQrs = async () => {
      setIsGenerating(true);
      const map: Record<string, string> = {};

      for (const ext of activeExtinguishers) {
        try {
          const dataUrl = await generateExtinguisherQrDataUrl(ext.serialNumber);
          map[ext.id] = dataUrl;
        } catch (e) {
          console.error('Failed to generate QR for', ext.serialNumber, e);
        }
      }

      if (isMounted) {
        setQrMap(map);
        setSelectedIds(activeExtinguishers.map((e) => e.id));
        setIsGenerating(false);
      }
    };

    generateAllQrs();

    return () => {
      isMounted = false;
    };
  }, [activeExtinguishers]);

  // Unique floors and types for filtering
  const floors = Array.from(new Set(activeExtinguishers.map((e) => e.floor || 'غير محدد'))).filter(Boolean);
  const types = Array.from(new Set(activeExtinguishers.map((e) => e.typeAr || e.type))).filter(Boolean);

  const filteredItems = activeExtinguishers.filter((item) => {
    const matchesSearch =
      item.serialNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.zone && item.zone.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesFloor = selectedFloor === 'all' || item.floor === selectedFloor;
    const matchesType = selectedType === 'all' || item.typeAr === selectedType || item.type === selectedType;
    return matchesSearch && matchesFloor && matchesType;
  });

  const toggleSelectAll = () => {
    if (selectedIds.length === filteredItems.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredItems.map((e) => e.id));
    }
  };

  const toggleSelectItem = (id: string) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter((item) => item !== id));
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  const handlePrintLabels = () => {
    const itemsToPrint = activeExtinguishers.filter((e) => selectedIds.includes(e.id));
    if (itemsToPrint.length === 0) {
      alert('يرجى اختيار طفاية واحدة على الأقل لطباعة ملصقاتها.');
      return;
    }

    const labelsHtml = itemsToPrint
      .map((item) => {
        const qrUrl = qrMap[item.id] || '';
        return `
          <div class="ext-label-card">
            <div class="ext-header">
              <div class="ext-brand">
                <strong>مستشفى آزال النموذجي</strong>
                <span>إدارة السلامة ومكافحة الحريق • OSH-FMS</span>
              </div>
              <div class="ext-badge">CBAHI FMS.7</div>
            </div>

            <div class="ext-body">
              <div class="ext-qr-box">
                <img src="${qrUrl}" alt="${item.serialNumber}" class="ext-qr-img" />
                <div class="ext-qr-caption">امسح لتسجيل الفحص الشهري</div>
              </div>

              <div class="ext-info">
                <div class="ext-serial">${item.serialNumber}</div>
                <div class="ext-type-weight">
                  <strong>${item.typeAr || item.type}</strong>
                  <span>السعة: ${item.capacity || item.weight || '6 كجم'}</span>
                </div>
                <div class="ext-location">
                  <span class="loc-lbl">الموقع:</span>
                  <span class="loc-val">${item.location}</span>
                </div>
                <div class="ext-meta">
                  <span>الصلاحية: ${item.expiryDate}</span>
                  <span>المعيار: NFPA 10</span>
                </div>
              </div>
            </div>

            <div class="ext-footer">
              <span>مسؤول السلامة: م/ نجيب غازي</span>
              <span>رقم الطوارئ: 222</span>
            </div>
          </div>
        `;
      })
      .join('');

    const customContent = `
      <style>
        .labels-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 12mm;
          padding: 4mm;
        }
        @media print {
          .labels-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 8mm;
            page-break-inside: auto;
          }
          .ext-label-card {
            page-break-inside: avoid;
          }
        }
        .ext-label-card {
          border: 2px dashed #94a3b8;
          border-radius: 12px;
          padding: 10px;
          background: #ffffff;
          box-sizing: border-box;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          font-family: inherit;
        }
        .ext-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          border-bottom: 1.5px solid #dc2626;
          padding-bottom: 6px;
          margin-bottom: 8px;
        }
        .ext-brand strong {
          display: block;
          font-size: 13px;
          color: #0f172a;
        }
        .ext-brand span {
          display: block;
          font-size: 9px;
          color: #64748b;
        }
        .ext-badge {
          background: #fef2f2;
          border: 1px solid #f87171;
          color: #dc2626;
          font-size: 9px;
          font-weight: bold;
          padding: 2px 6px;
          border-radius: 4px;
        }
        .ext-body {
          display: flex;
          gap: 10px;
          align-items: center;
        }
        .ext-qr-box {
          text-align: center;
          flex-shrink: 0;
        }
        .ext-qr-img {
          width: 95px;
          height: 95px;
          display: block;
          margin: 0 auto;
          border: 1px solid #cbd5e1;
          border-radius: 6px;
          padding: 2px;
        }
        .ext-qr-caption {
          font-size: 8px;
          color: #475569;
          margin-top: 3px;
          font-weight: bold;
        }
        .ext-info {
          flex: 1;
        }
        .ext-serial {
          font-family: monospace;
          font-size: 15px;
          font-weight: 800;
          color: #b91c1c;
          letter-spacing: 0.5px;
          margin-bottom: 4px;
        }
        .ext-type-weight {
          font-size: 11px;
          color: #1e293b;
          margin-bottom: 4px;
        }
        .ext-type-weight strong {
          display: block;
        }
        .ext-type-weight span {
          font-size: 10px;
          color: #0d9488;
          font-weight: bold;
        }
        .ext-location {
          font-size: 10px;
          line-height: 1.3;
          color: #334155;
          margin-bottom: 4px;
          background: #f8fafc;
          padding: 3px 5px;
          border-radius: 4px;
        }
        .loc-lbl {
          font-weight: bold;
          color: #475569;
        }
        .ext-meta {
          display: flex;
          justify-content: space-between;
          font-size: 8.5px;
          color: #64748b;
          border-top: 1px dotted #e2e8f0;
          padding-top: 3px;
        }
        .ext-footer {
          border-top: 1px solid #e2e8f0;
          padding-top: 4px;
          margin-top: 6px;
          display: flex;
          justify-content: space-between;
          font-size: 8.5px;
          color: #64748b;
        }
      </style>

      <div class="labels-grid">
        ${labelsHtml}
      </div>
    `;

    executeSmartPrint(customContent, {
      title: `ملصقات باركود QR لطفاية الحريق (${itemsToPrint.length} ملصق)`,
      subtitle: 'مستشفى آزال النموذجي • إدارة الأمن والسلامة ومكافحة الحريق • نماذج اللصق على الأسطوانات',
      refNumber: `AZAL-EXT-QR-${Date.now().toString().slice(-6)}`,
    });
  };

  const handleDownloadSingleQr = (item: FireExtinguisherItem) => {
    const dataUrl = qrMap[item.id];
    if (!dataUrl) return;
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = `QR-${item.serialNumber}.png`;
    a.click();
  };

  return (
    <div
      id="fire-extinguisher-qr-print-modal"
      className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 text-right animate-fade-in"
      dir="rtl"
    >
      <div className="bg-slate-900 border border-teal-600/60 rounded-3xl w-full max-w-4xl overflow-hidden shadow-2xl flex flex-col max-h-[94vh]">
        {/* Header */}
        <div className="bg-slate-950 px-5 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-teal-950 border border-teal-700 text-teal-400 shadow-md">
              <QrCode className="w-6 h-6 text-teal-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-100">
                  شاشة توليد وطباعة ملصقات كود QR لطفايات الحريق (28 طفاية)
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-red-950 text-red-300 border border-red-800">
                  جاهزة للصق
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                توليد ملصقات احترافية بدقة عالية للطباعة المباشرة على ورق لاصق ولصقها على أسطوانات الحريق
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter and Selection Controls */}
        <div className="bg-slate-950/80 px-5 py-3 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex flex-wrap items-center gap-2 flex-1">
            {/* Search */}
            <div className="relative min-w-[200px] flex-1">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute right-2.5 top-2.5" />
              <input
                type="text"
                placeholder="بحث بالرقم (EXT-01) أو الموقع..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl pr-8 pl-3 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-teal-500"
              />
            </div>

            {/* Floor filter */}
            <select
              value={selectedFloor}
              onChange={(e) => setSelectedFloor(e.target.value)}
              className="bg-slate-900 border border-slate-800 rounded-xl px-2.5 py-1.5 text-slate-200 text-xs focus:outline-none focus:border-teal-500"
            >
              <option value="all">كافة الأدوار والمباني</option>
              {floors.map((floor) => (
                <option key={floor} value={floor}>
                  {floor}
                </option>
              ))}
            </select>

            {/* Type filter */}
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="bg-slate-900 border border-slate-800 rounded-xl px-2.5 py-1.5 text-slate-200 text-xs focus:outline-none focus:border-teal-500"
            >
              <option value="all">كافة أنواع المواد</option>
              {types.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={toggleSelectAll}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 transition"
            >
              {selectedIds.length === filteredItems.length ? (
                <>
                  <CheckSquare className="w-4 h-4 text-teal-400" />
                  <span>إلغاء التحديد</span>
                </>
              ) : (
                <>
                  <Square className="w-4 h-4 text-slate-400" />
                  <span>تحديد الكل ({filteredItems.length})</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={handlePrintLabels}
              disabled={isGenerating || selectedIds.length === 0}
              className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white text-xs font-bold shadow-lg shadow-red-950 flex items-center gap-1.5 transition disabled:opacity-50"
            >
              <Printer className="w-4 h-4" />
              <span>طباعة الملصقات المختارة ({selectedIds.length})</span>
            </button>
          </div>
        </div>

        {/* Labels Preview Grid */}
        <div className="p-5 overflow-y-auto space-y-4">
          {isGenerating ? (
            <div className="py-16 text-center text-slate-400 text-xs space-y-2">
              <div className="w-8 h-8 border-2 border-teal-500 border-t-transparent rounded-full animate-spin mx-auto" />
              <p>جاري توليد ملصقات ورموز QR لكافة الطفايات الـ 28...</p>
            </div>
          ) : filteredItems.length === 0 ? (
            <div className="py-16 text-center text-slate-500 text-xs">
              لا توجد طفايات حريق تطابق معايير الفلترة المحددة.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredItems.map((item) => {
                const isSelected = selectedIds.includes(item.id);
                const qrUrl = qrMap[item.id];

                return (
                  <div
                    key={item.id}
                    onClick={() => toggleSelectItem(item.id)}
                    className={`relative rounded-2xl border-2 p-3.5 transition cursor-pointer flex flex-col justify-between ${
                      isSelected
                        ? 'bg-slate-950/90 border-teal-500/80 shadow-lg shadow-teal-950/40'
                        : 'bg-slate-950/50 border-slate-800 opacity-60 hover:opacity-100'
                    }`}
                  >
                    {/* Top row */}
                    <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-2">
                      <div className="flex items-center gap-2">
                        <div
                          className={`w-4 h-4 rounded flex items-center justify-center ${
                            isSelected ? 'bg-teal-600 text-white' : 'border border-slate-700 bg-slate-900'
                          }`}
                        >
                          {isSelected && <CheckSquare className="w-3.5 h-3.5" />}
                        </div>
                        <span className="font-mono font-bold text-teal-400 text-sm">
                          {item.serialNumber}
                        </span>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-red-950/80 text-red-300 border border-red-800">
                          {item.typeAr || item.type}
                        </span>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDownloadSingleQr(item);
                          }}
                          className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] transition"
                          title="تنزيل صورة الرمز"
                        >
                          <Download className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Middle: QR & Details */}
                    <div className="flex items-center gap-3">
                      {/* QR Image Box */}
                      <div className="p-1.5 bg-white rounded-xl shadow-sm shrink-0 border border-slate-300 text-center">
                        {qrUrl ? (
                          <img
                            src={qrUrl}
                            alt={item.serialNumber}
                            className="w-24 h-24 sm:w-28 sm:h-28 object-contain"
                          />
                        ) : (
                          <div className="w-24 h-24 flex items-center justify-center text-slate-400 text-[10px]">
                            جاري التحميل...
                          </div>
                        )}
                        <span className="text-[9px] text-slate-700 font-bold block mt-0.5 font-mono">
                          {item.serialNumber}
                        </span>
                      </div>

                      {/* Info details */}
                      <div className="space-y-1.5 text-xs flex-1">
                        <div>
                          <span className="text-[11px] text-slate-400 block">الموقع:</span>
                          <span className="text-slate-200 font-medium line-clamp-2">
                            {item.location}
                          </span>
                        </div>

                        <div className="grid grid-cols-2 gap-1 text-[11px]">
                          <div>
                            <span className="text-slate-400 block text-[10px]">السعة / الوزن:</span>
                            <span className="text-teal-300 font-bold font-mono">
                              {item.capacity || item.weight || '6 كجم'}
                            </span>
                          </div>
                          <div>
                            <span className="text-slate-400 block text-[10px]">الصلاحية:</span>
                            <span className="text-slate-300 font-mono">
                              {item.expiryDate}
                            </span>
                          </div>
                        </div>

                        <div className="pt-1 text-[10px] text-slate-400 border-t border-slate-850 flex items-center justify-between">
                          <span>المعيار: NFPA 10</span>
                          <span>مفتش: م/ نجيب غازي</span>
                        </div>
                      </div>
                    </div>

                    {/* Bottom Instructions Badge */}
                    <div className="mt-2.5 pt-2 border-t border-slate-850/80 flex items-center justify-between text-[10px] text-slate-400">
                      <span className="text-teal-400 flex items-center gap-1 font-medium">
                        <Sparkles className="w-3 h-3" />
                        امسح بالكاميرا لتسجيل الفحص الشهري الفوري
                      </span>
                      <span className="text-slate-500">طفاية رقم #{item.id.replace(/\D/g, '') || item.serialNumber}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="bg-slate-950 px-5 py-3.5 border-t border-slate-800 flex items-center justify-between text-xs">
          <span className="text-slate-400">
            تم تحديد <strong className="text-teal-400 font-mono">{selectedIds.length}</strong> من إجمالي{' '}
            <strong className="text-slate-200 font-mono">{activeExtinguishers.length}</strong> طفاية حريق
          </span>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold transition"
            >
              إغلاق
            </button>
            <button
              type="button"
              onClick={handlePrintLabels}
              disabled={isGenerating || selectedIds.length === 0}
              className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold shadow-lg shadow-red-950 flex items-center gap-2 transition disabled:opacity-50"
            >
              <Printer className="w-4 h-4" />
              <span>طباعة ملصقات الطفايات (A4 Sticker Sheet)</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
