import React from 'react';

export interface AzalLogoProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  showText?: boolean;
  className?: string;
  variant?: 'badge' | 'horizontal' | 'icon';
  transparent?: boolean;
  subtitle?: string;
}

export const AzalLogo: React.FC<AzalLogoProps> = ({
  size = 'md',
  showText = true,
  className = '',
  variant = 'badge',
  transparent = false,
  subtitle,
}) => {
  const sizeMap = {
    xs: { img: 'w-7 h-7', horizontal: 'h-7 sm:h-8', title: 'text-[11px]', sub: 'text-[8px]' },
    sm: { img: 'w-9 h-9', horizontal: 'h-8 sm:h-9', title: 'text-xs', sub: 'text-[9px]' },
    md: { img: 'w-11 h-11', horizontal: 'h-10 sm:h-12', title: 'text-sm font-extrabold', sub: 'text-[10px]' },
    lg: { img: 'w-16 h-16', horizontal: 'h-13 sm:h-16', title: 'text-base font-black', sub: 'text-xs' },
    xl: { img: 'w-24 h-24', horizontal: 'h-18 sm:h-20', title: 'text-xl font-black', sub: 'text-sm' },
    '2xl': { img: 'w-32 h-32', horizontal: 'h-24 sm:h-28', title: 'text-2xl font-black', sub: 'text-base' },
  };

  const current = (size && sizeMap[size as keyof typeof sizeMap]) || sizeMap.md;

  if (variant === 'horizontal') {
    if (transparent) {
      return (
        <div className={`inline-flex items-center justify-center ${className}`}>
          <img
            src="/azal-logo.svg"
            alt="شعار مستشفى آزال - الرعاية الكاملة"
            className={`${current.horizontal} w-auto max-w-full object-contain filter drop-shadow-sm`}
            referrerPolicy="no-referrer"
          />
        </div>
      );
    }

    return (
      <div className={`inline-flex items-center ${className}`}>
        <div className="bg-white/95 backdrop-blur-sm px-3.5 py-1.5 rounded-2xl border border-slate-200/90 shadow-md hover:shadow-lg transition-all flex items-center justify-center">
          <img
            src="/azal-logo.svg"
            alt="شعار مستشفى آزال - الرعاية الكاملة"
            className={`${current.horizontal} w-auto max-w-full object-contain`}
            referrerPolicy="no-referrer"
          />
        </div>
      </div>
    );
  }

  if (variant === 'icon') {
    return (
      <div className={`relative ${current.img} shrink-0 rounded-2xl ${transparent ? 'bg-transparent' : 'bg-white p-1 border border-slate-200 shadow-md shadow-black/10'} overflow-hidden flex items-center justify-center ${className}`}>
        <img
          src="/icon.svg"
          alt="شعار مستشفى آزال - الرعاية الكاملة"
          className="w-full h-full object-contain filter drop-shadow-sm"
          referrerPolicy="no-referrer"
        />
      </div>
    );
  }

  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      {/* Official Logo Emblem Badge on crisp white card */}
      <div className={`relative ${current.img} shrink-0 rounded-2xl ${transparent ? 'bg-transparent' : 'bg-white p-1 border border-slate-200 shadow-md shadow-black/20'} overflow-hidden flex items-center justify-center group hover:scale-105 transition-transform`}>
        <img
          src="/icon.svg"
          alt="شعار مستشفى آزال الرسمي"
          className="w-full h-full object-contain filter drop-shadow-sm"
          referrerPolicy="no-referrer"
        />
      </div>

      {showText && (
        <div className="text-right flex flex-col justify-center leading-tight">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className={`text-slate-100 ${current.title} tracking-tight font-sans`}>
              مستشفى آزال
            </span>
            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-600/80 shadow-xs">
              الرعاية الكاملة
            </span>
          </div>
          <span className={`text-teal-400 font-semibold ${current.sub} tracking-wide mt-0.5`}>
            {subtitle || 'إدارة الأمن والسلامة وإدارة المرافق (FMS)'}
          </span>
        </div>
      )}
    </div>
  );
};
