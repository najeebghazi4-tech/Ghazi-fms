import React, { useState } from 'react';
import { X, Award, CheckCircle2, User, Building2, BookOpen, Calendar, Clock, Sparkles } from 'lucide-react';
import { TrainingCertificateRecord, SafetyTraining } from '../types';
import { generateNextCertificateSerial } from '../data/trainingCertificatesData';

interface AddCertificateModalProps {
  existingCertificates: TrainingCertificateRecord[];
  trainingsList?: SafetyTraining[];
  onSave: (cert: TrainingCertificateRecord) => void;
  onClose: () => void;
}

const COMMON_DEPARTMENTS = [
  'قسم الطوارئ والإسعاف',
  'قسم الصيانة العامة والهندسية',
  'العمليات الجراحية الكبرى',
  'قسم الأجهزة الطبية والهندسة الحيوية',
  'قسم المختبر المركزي وبنك الدم',
  'المغسلة المركزية والخدمات العامة',
  'قسم الأشعة والتصوير الطبي',
  'العناية المركزة (ICU)',
  'التعقيم المركزي (CSSD)',
  'الصيدلية المركزية',
  'إدارة الخدمات الفندقية والنظافة',
];

const COMMON_COURSES = [
  'التدريب العملي على خطة الإخلاء ومكافحة الحرائق (Code Red)',
  'السلامة المهنية وإجراءات تصاريح العمل الساخن (Hot Work Permit)',
  'سلامة الغازات الطبية وصمامات العزل في الطوارئ والعمليات',
  'إدارة وتداول المواد الكيميائية الخطرة وصحائف السلامة (MSDS & Hazmat)',
  'توجيه الموظفين الجدد لمعايير السلامة المهنية ومهمات الوقاية (Orientation)',
  'السلامة من الإشعاع والوقاية في أقسام الأشعة والمختبر',
  'خطة الاستجابة للكوارث والأزمات الخارجية (Code Yellow)',
  'إجراءات مكافحة العدوى والتعامل مع النفايات الطبية الحادة',
];

export const AddCertificateModal: React.FC<AddCertificateModalProps> = ({
  existingCertificates,
  trainingsList = [],
  onSave,
  onClose,
}) => {
  const autoSerial = generateNextCertificateSerial(existingCertificates);
  const todayStr = new Date().toISOString().split('T')[0];

  const [traineeName, setTraineeName] = useState('');
  const [department, setDepartment] = useState(COMMON_DEPARTMENTS[0]);
  const [customDept, setCustomDept] = useState('');
  const [jobTitle, setJobTitle] = useState('');
  const [courseName, setCourseName] = useState(COMMON_COURSES[0]);
  const [customCourse, setCustomCourse] = useState('');
  const [trainingDate, setTrainingDate] = useState(todayStr);
  const [durationHours, setDurationHours] = useState(4);
  const [trainerName, setTrainerName] = useState('م/ نجيب قاسم غازي');
  const [grade, setGrade] = useState('ممتاز (Excellent)');
  const [serialNumber, setSerialNumber] = useState(autoSerial);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!traineeName.trim()) return;

    const finalDept = department === 'أخرى' ? customDept : department;
    const finalCourse = courseName === 'أخرى' ? customCourse : courseName;

    const newCert: TrainingCertificateRecord = {
      id: `cert-${Date.now()}`,
      certificate_serial: serialNumber.trim() || autoSerial,
      trainee_name: traineeName.trim(),
      department: finalDept.trim() || 'قسم غير محدد',
      job_title: jobTitle.trim() || undefined,
      course_name: finalCourse.trim() || 'دورة تدريبية في السلامة والمرافق',
      training_date: trainingDate,
      duration_hours: Number(durationHours) || 4,
      trainer_name: trainerName.trim() || 'م/ نجيب قاسم غازي',
      safety_head_name: 'م/ نجيب قاسم غازي',
      general_manager_name: 'د/ محمد السراجي',
      issue_date: todayStr,
      grade_or_evaluation: grade,
      qr_code_payload: `${serialNumber}|${traineeName}|${finalDept}|${finalCourse}|${trainingDate}|معتمد`,
      created_at: new Date().toISOString(),
    };

    onSave(newCert);
  };

  return (
    <div
      id="add-certificate-modal"
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 overflow-y-auto"
    >
      <div className="bg-slate-900 border border-slate-700/80 w-full max-w-2xl rounded-3xl p-5 shadow-2xl animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/30 text-amber-400 flex items-center justify-center">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <span>إصدار شهادة اجتياز وتأهيل تدريبي جديدة</span>
                <span className="text-[10px] bg-amber-950 text-amber-300 border border-amber-600/50 px-2 py-0.5 rounded-full font-bold">
                  اعتماد FMS
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                تسجيل المتدرب وتوليد الرقم التسلسلي الرسمي تلقائياً لطباعة الشهادة الرسمية
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 mt-4 text-xs">
          {/* Serial Number (Auto-Generated) */}
          <div className="p-3 bg-slate-950 border border-slate-800 rounded-2xl flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <div>
                <span className="text-[11px] text-slate-400 block">الرقم التسلسلي للشهادة (كود فريد معتمد):</span>
                <input
                  type="text"
                  value={serialNumber}
                  onChange={(e) => setSerialNumber(e.target.value)}
                  className="bg-transparent font-mono font-black text-amber-400 text-sm focus:outline-none focus:underline"
                />
              </div>
            </div>
            <span className="text-[10px] px-2.5 py-1 rounded-xl bg-slate-900 border border-slate-700 text-slate-300">
              توليد آلي
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Trainee Name */}
            <div>
              <label className="block text-slate-300 font-bold mb-1">
                اسم المتدرب الرباعي <span className="text-rose-400">*</span>
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-500 absolute right-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  value={traineeName}
                  onChange={(e) => setTraineeName(e.target.value)}
                  placeholder="مثال: د. محمد علي الأهدل أو فني خالد الصبري"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-9 pl-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            {/* Job Title */}
            <div>
              <label className="block text-slate-300 font-bold mb-1">المسمى الوظيفي</label>
              <input
                type="text"
                value={jobTitle}
                onChange={(e) => setJobTitle(e.target.value)}
                placeholder="مثال: أخصائي تمريض / فني أجهزة / مشرف مغسلة"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Department */}
            <div>
              <label className="block text-slate-300 font-bold mb-1">
                القسم / الإدارة التابع لها <span className="text-rose-400">*</span>
              </label>
              <select
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
              >
                {COMMON_DEPARTMENTS.map((dept) => (
                  <option key={dept} value={dept} className="bg-slate-900 text-white">
                    {dept}
                  </option>
                ))}
                <option value="أخرى" className="bg-slate-900 text-amber-400">
                  + قسم آخر (إدخال يدوي)
                </option>
              </select>
              {department === 'أخرى' && (
                <input
                  type="text"
                  required
                  value={customDept}
                  onChange={(e) => setCustomDept(e.target.value)}
                  placeholder="اكتب اسم القسم هنا..."
                  className="w-full mt-2 bg-slate-950 border border-amber-600/50 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none"
                />
              )}
            </div>

            {/* Training Course */}
            <div>
              <label className="block text-slate-300 font-bold mb-1">
                اسم الدورة التدريبية <span className="text-rose-400">*</span>
              </label>
              <select
                value={courseName}
                onChange={(e) => setCourseName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
              >
                {COMMON_COURSES.map((c) => (
                  <option key={c} value={c} className="bg-slate-900 text-white">
                    {c}
                  </option>
                ))}
                {trainingsList
                  .filter((t) => !COMMON_COURSES.includes(t.course_name))
                  .map((t) => (
                    <option key={t.id} value={t.course_name} className="bg-slate-900 text-teal-300">
                      {t.course_name}
                    </option>
                  ))}
                <option value="أخرى" className="bg-slate-900 text-amber-400">
                  + دورة أخرى (إدخال يدوي)
                </option>
              </select>
              {courseName === 'أخرى' && (
                <input
                  type="text"
                  required
                  value={customCourse}
                  onChange={(e) => setCustomCourse(e.target.value)}
                  placeholder="اكتب اسم الدورة التدريبية..."
                  className="w-full mt-2 bg-slate-950 border border-amber-600/50 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none"
                />
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Training Date */}
            <div>
              <label className="block text-slate-300 font-bold mb-1">
                تاريخ الانعقاد <span className="text-rose-400">*</span>
              </label>
              <input
                type="date"
                required
                value={trainingDate}
                onChange={(e) => setTrainingDate(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            {/* Duration Hours */}
            <div>
              <label className="block text-slate-300 font-bold mb-1">عدد الساعات التدريبية</label>
              <input
                type="number"
                min="1"
                max="40"
                value={durationHours}
                onChange={(e) => setDurationHours(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            {/* Grade / Evaluation */}
            <div>
              <label className="block text-slate-300 font-bold mb-1">التقدير والتقييم</label>
              <select
                value={grade}
                onChange={(e) => setGrade(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
              >
                <option value="ممتاز (Excellent)">ممتاز (Excellent)</option>
                <option value="اجتياز بتفوق">اجتياز بتفوق</option>
                <option value="اجتياز بنجاح">اجتياز بنجاح</option>
                <option value="جيد جداً (Very Good)">جيد جداً (Very Good)</option>
              </select>
            </div>
          </div>

          {/* Trainer Name */}
          <div>
            <label className="block text-slate-300 font-bold mb-1">اسم مدرب الدورة / المشرف الميداني</label>
            <input
              type="text"
              value={trainerName}
              onChange={(e) => setTrainerName(e.target.value)}
              placeholder="م/ نجيب قاسم غازي"
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-black flex items-center gap-1.5 shadow-lg shadow-amber-950 transition active:scale-95"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>إصدار الشهادة وحفظها</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
