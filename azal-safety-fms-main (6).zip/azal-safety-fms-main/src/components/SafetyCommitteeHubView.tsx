import React, { useState, useEffect, useMemo } from 'react';
import { 
  Users, 
  Plus, 
  Calendar, 
  Clock, 
  MapPin, 
  FileText, 
  Upload, 
  CheckCircle2, 
  AlertCircle, 
  Clock3, 
  Printer, 
  RefreshCw, 
  Search, 
  Filter, 
  Trash2, 
  Image as ImageIcon, 
  Eye, 
  X, 
  Building2, 
  Sparkles,
  ShieldCheck,
  ChevronDown,
  Bell,
  Check,
  Award
} from 'lucide-react';
import { supabase } from '../services/supabaseClient';
import { SafetyCommitteeMeeting, CommitteeMeetingStatus, StaffUser } from '../types';
import { executeSmartPrint } from '../utils/printUtils';

interface SafetyCommitteeHubViewProps {
  currentUser?: StaffUser;
  onLogAudit?: (action: string, actionAr: string, details: string) => void;
}

const COMMON_LOCATIONS = [
  'قاعة المؤتمرات الكبرى - الدور الرابع',
  'قاعة الاجتماعات الرئيسية - الإدارة العامة',
  'مكتب مدير عام المستشفى',
  'قاعة إدارة الجودة والاعتماد',
  'قاعة التعليم المستمر والتدريب',
];

const DEFAULT_COMMITTEE_MEMBERS = [
  'د. محمد السراجي (رئيس اللجنة / مدير عام المستشفى)',
  'م. نجيب غازي (مقرر اللجنة / رئيس السلامة FMS)',
  'د. ابتسام الريمي (المدير الطبي)',
  'أ. خالد الوادعي (إدارة التمريض)',
  'م. أحمد الحداد (مسؤول الصيانة والمرافق)',
  'أ. نبيل قاسم (مسؤول مكافحة العدوى)',
  'د. هاني المخلافي (مسؤول الصيدلية والتموين الطبي)',
];

export const SafetyCommitteeHubView: React.FC<SafetyCommitteeHubViewProps> = ({
  currentUser,
  onLogAudit,
}) => {
  const [meetings, setMeetings] = useState<SafetyCommitteeMeeting[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'scheduled' | 'completed' | 'postponed'>('all');
  
  // Modals & State
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [showMinutesModal, setShowMinutesModal] = useState(false);
  const [selectedMeetingForMinutes, setSelectedMeetingForMinutes] = useState<SafetyCommitteeMeeting | null>(null);
  const [selectedImagePreview, setSelectedImagePreview] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // New Meeting Form
  const [formData, setFormData] = useState({
    title: '',
    meeting_date: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 2 days ahead by default!
    meeting_time: '10:30',
    location: COMMON_LOCATIONS[0],
    agenda: '1. مراجعة تقارير جولات السلامة والتفتيش الميداني.\n2. مناقشة متطلبات الاعتماد الوطني (CBAHI FMS).\n3. تدقيق سجلات صيانة الغازات الطبية ومحطة الأكسجين.\n4. استعراض خطط الطوارئ والإخلاء والتدريب.',
    attendees: DEFAULT_COMMITTEE_MEMBERS.join('، '),
    status: 'scheduled' as CommitteeMeetingStatus,
  });

  // Minutes Form for Selected Meeting
  const [minutesData, setMinutesData] = useState({
    decisions_recommendations: '',
    minutes_image_url: '',
  });

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 4000);
  };

  // Load meetings from Supabase
  const loadMeetings = async () => {
    try {
      setRefreshing(true);
      const { data, error } = await supabase
        .from('safety_committee_meetings')
        .select('*')
        .order('meeting_date', { ascending: false });

      if (error) {
        console.error('[Supabase] Error loading committee meetings:', error);
        showNotification('error', 'تعذر جلب سجل الاجتماعات من Supabase، تم الاعتماد على النسخة المحلية');
      } else if (data) {
        setMeetings(data as SafetyCommitteeMeeting[]);
      }
    } catch (err) {
      console.error('[Supabase] Error:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadMeetings();
  }, []);

  // Smart Countdown / Alert Detection (2 days before or less)
  const upcomingNotice = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const scheduledMeetings = meetings
      .filter(m => m.status === 'scheduled')
      .map(m => {
        const mDate = new Date(m.meeting_date);
        mDate.setHours(0, 0, 0, 0);
        const diffDays = Math.round((mDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
        return { meeting: m, diffDays };
      })
      .filter(item => item.diffDays >= 0 && item.diffDays <= 2) // exactly within 2 days (0, 1, 2)
      .sort((a, b) => a.diffDays - b.diffDays);

    return scheduledMeetings.length > 0 ? scheduledMeetings[0] : null;
  }, [meetings]);

  // Handle Image Upload for Minutes
  const handleMinutesImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 8 * 1024 * 1024) {
      showNotification('error', 'حجم الصورة كبير، الحد الأقصى 8 ميغابايت');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      setMinutesData(prev => ({ ...prev, minutes_image_url: reader.result as string }));
      showNotification('success', 'تم تحميل صورة محضر الاجتماع بنجاح');
    };
    reader.readAsDataURL(file);
  };

  // Create New Meeting
  const handleScheduleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) {
      showNotification('error', 'يرجى كتابة عنوان الاجتماع');
      return;
    }

    setIsSubmitting(true);
    const newMeeting: Partial<SafetyCommitteeMeeting> = {
      id: `scm-${Date.now()}`,
      title: formData.title.trim(),
      meeting_date: formData.meeting_date,
      meeting_time: formData.meeting_time,
      location: formData.location,
      agenda: formData.agenda.trim(),
      attendees: formData.attendees.trim(),
      status: 'scheduled',
      decisions_recommendations: '',
      minutes_image_url: '',
      recorded_by: currentUser?.name || 'م. نجيب غازي',
      created_at: new Date().toISOString(),
    };

    try {
      const { error } = await supabase.from('safety_committee_meetings').insert([newMeeting]);
      if (error) throw error;

      showNotification('success', 'تم جدولة اجتماع لجنة السلامة بنجاح');
      setShowScheduleModal(false);

      if (onLogAudit) {
        onLogAudit('SCHEDULE_COMMITTEE_MEETING', 'جدولة اجتماع لجنة السلامة', `تم تحديد موعد: ${newMeeting.title}`);
      }

      // Reset
      setFormData({
        title: '',
        meeting_date: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        meeting_time: '10:30',
        location: COMMON_LOCATIONS[0],
        agenda: '1. مراجعة تقارير جولات السلامة والتفتيش الميداني.\n2. مناقشة متطلبات الاعتماد الوطني (CBAHI FMS).\n3. تدقيق سجلات صيانة الغازات الطبية ومحطة الأكسجين.\n4. استعراض خطط الطوارئ والإخلاء والتدريب.',
        attendees: DEFAULT_COMMITTEE_MEMBERS.join('، '),
        status: 'scheduled',
      });

      loadMeetings();
    } catch (err) {
      console.error('[Supabase] Insert meeting error:', err);
      showNotification('error', 'تعذر حفظ بيانات الاجتماع');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Open Minutes Modal
  const handleOpenMinutesModal = (meeting: SafetyCommitteeMeeting) => {
    setSelectedMeetingForMinutes(meeting);
    setMinutesData({
      decisions_recommendations: meeting.decisions_recommendations || '',
      minutes_image_url: meeting.minutes_image_url || '',
    });
    setShowMinutesModal(true);
  };

  // Save Minutes & Decisions
  const handleSaveMinutes = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMeetingForMinutes) return;

    setIsSubmitting(true);
    const updatedFields: Partial<SafetyCommitteeMeeting> = {
      decisions_recommendations: minutesData.decisions_recommendations.trim(),
      minutes_image_url: minutesData.minutes_image_url || undefined,
      status: 'completed', // Mark as completed when official minutes are attached
    };

    try {
      const { error } = await supabase
        .from('safety_committee_meetings')
        .update(updatedFields)
        .eq('id', selectedMeetingForMinutes.id);

      if (error) throw error;

      showNotification('success', 'تم حفظ محضر الاجتماع وقرارات اللجنة واعتماد حالته كمكتمل');
      setShowMinutesModal(false);

      if (onLogAudit) {
        onLogAudit('UPDATE_COMMITTEE_MINUTES', 'توثيق محضر اجتماع اللجنة', `تم توثيق محضر: ${selectedMeetingForMinutes.title}`);
      }

      loadMeetings();
    } catch (err) {
      console.error('[Supabase] Update minutes error:', err);
      showNotification('error', 'تعذر حفظ محضر الاجتماع');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Quick Status Toggle
  const handleStatusChange = async (meeting: SafetyCommitteeMeeting, newStatus: CommitteeMeetingStatus) => {
    try {
      const { error } = await supabase
        .from('safety_committee_meetings')
        .update({ status: newStatus })
        .eq('id', meeting.id);

      if (error) throw error;

      setMeetings(prev => prev.map(m => m.id === meeting.id ? { ...m, status: newStatus } : m));
      showNotification('success', `تم تغيير حالة الاجتماع إلى: ${newStatus === 'completed' ? 'مكتمل' : newStatus === 'postponed' ? 'مؤجل' : 'مجدول'}`);

      if (onLogAudit) {
        onLogAudit('UPDATE_MEETING_STATUS', 'تحديث حالة الاجتماع', `تم تغيير حالة ${meeting.title} إلى ${newStatus}`);
      }
    } catch (err) {
      console.error('[Supabase] Status error:', err);
      showNotification('error', 'تعذر تحديث الحالة');
    }
  };

  // Delete Meeting
  const handleDeleteMeeting = async (id: string, title: string) => {
    if (!confirm(`هل أنت متأكد من حذف الاجتماع: "${title}"؟`)) return;

    try {
      const { error } = await supabase.from('safety_committee_meetings').delete().eq('id', id);
      if (error) throw error;

      setMeetings(prev => prev.filter(m => m.id !== id));
      showNotification('success', 'تم حذف الاجتماع بنجاح');

      if (onLogAudit) {
        onLogAudit('DELETE_COMMITTEE_MEETING', 'حذف اجتماع لجنة السلامة', `تم حذف: ${title}`);
      }
    } catch (err) {
      console.error('[Supabase] Delete error:', err);
      showNotification('error', 'تعذر حذف الاجتماع');
    }
  };

  // Print Official Minutes (CBAHI Approved Format)
  const handlePrintOfficialMinutes = (meeting: SafetyCommitteeMeeting) => {
    const minutesHtml = `
      <div style="font-family: inherit; direction: rtl; text-align: right;">
        <!-- Header Banner -->
        <div style="background-color: #f8fafc; border: 1.5px solid #0f766e; border-radius: 8px; padding: 14px; margin-bottom: 18px;">
          <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #cbd5e1; padding-bottom: 8px; margin-bottom: 10px;">
            <h2 style="margin: 0; font-size: 16px; color: #0f766e; font-weight: 900;">
              محضر اجتماع لجنة السلامة وإدارة المرافق (FMS Committee Meeting Minutes)
            </h2>
            <span style="font-size: 11px; font-weight: bold; background: #e0f2fe; color: #0369a1; padding: 3px 8px; border-radius: 6px;">
              معتمد لمعايير CBAHI & FMS
            </span>
          </div>

          <table style="width: 100%; font-size: 11px; border-collapse: collapse;">
            <tr>
              <td style="padding: 4px 0; width: 50%;"><strong>عنوان الاجتماع:</strong> ${meeting.title}</td>
              <td style="padding: 4px 0; width: 50%;"><strong>تاريخ الانعقاد:</strong> ${meeting.meeting_date} (${meeting.meeting_time})</td>
            </tr>
            <tr>
              <td style="padding: 4px 0;"><strong>مكان الانعقاد:</strong> ${meeting.location}</td>
              <td style="padding: 4px 0;"><strong>حالة الاجتماع:</strong> ${meeting.status === 'completed' ? 'منعقد ومكتمل' : meeting.status === 'postponed' ? 'مؤجل' : 'مجدول'}</td>
            </tr>
            <tr>
              <td colspan="2" style="padding: 6px 0 2px 0;">
                <strong>أعضاء اللجنة الحاضرون:</strong> ${meeting.attendees}
              </td>
            </tr>
          </table>
        </div>

        <!-- Section 1: Agenda -->
        <div style="margin-bottom: 16px;">
          <h3 style="margin: 0 0 6px 0; font-size: 13px; color: #0f172a; border-bottom: 1px solid #cbd5e1; padding-bottom: 4px;">
            أولاً: جدول الأعمال ومحاور النقاش (Agenda)
          </h3>
          <div style="background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 6px; padding: 10px; font-size: 11px; color: #334155; white-space: pre-line; line-height: 1.6;">
            ${meeting.agenda}
          </div>
        </div>

        <!-- Section 2: Decisions & Recommendations -->
        <div style="margin-bottom: 16px;">
          <h3 style="margin: 0 0 6px 0; font-size: 13px; color: #0f172a; border-bottom: 1px solid #cbd5e1; padding-bottom: 4px;">
            ثانياً: القرارات والتوصيات الصادرة عن اللجنة (Decisions & Recommendations)
          </h3>
          <div style="background-color: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 6px; padding: 12px; font-size: 11.5px; color: #14532d; white-space: pre-line; line-height: 1.7; font-weight: 500;">
            ${meeting.decisions_recommendations || 'لم يتم تسجيل قرارات تفصيلية لهذا الاجتماع.'}
          </div>
        </div>

        <!-- Section 3: Official Signed Minutes Photo if exists -->
        ${meeting.minutes_image_url ? `
          <div style="margin-bottom: 16px; page-break-inside: avoid;">
            <h3 style="margin: 0 0 6px 0; font-size: 13px; color: #0f172a; border-bottom: 1px solid #cbd5e1; padding-bottom: 4px;">
              ثالثاً: صورة وثيقة المحضر الرسمي الموقع والمعتمد
            </h3>
            <div style="text-align: center; border: 1px dashed #94a3b8; border-radius: 8px; padding: 8px; background-color: #f8fafc;">
              <img src="${meeting.minutes_image_url}" style="max-width: 100%; max-height: 420px; object-contain: fit; border-radius: 4px;" alt="محضر موقع" />
              <p style="margin: 6px 0 0 0; font-size: 10px; color: #64748b;">صورة أرشيفية رسمية للمحضر المعتمد بتوقيعات أعضاء اللجنة</p>
            </div>
          </div>
        ` : ''}

        <!-- Institutional Signatures Footer -->
        <div style="margin-top: 24px; border-top: 1.5px solid #0f766e; padding-top: 12px; display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; text-align: center; page-break-inside: avoid;">
          <div style="border: 1px dashed #cbd5e1; padding: 8px; border-radius: 6px;">
            <div style="font-size: 10px; color: #64748b; font-weight: bold; margin-bottom: 4px;">مقرر اللجنة / رئيس السلامة FMS</div>
            <div style="font-size: 12px; font-weight: 900; color: #0f172a; margin-bottom: 16px;">م/ نجيب غازي</div>
            <div style="font-size: 9px; color: #94a3b8;">التوقيع: .....................</div>
          </div>

          <div style="border: 1px dashed #cbd5e1; padding: 8px; border-radius: 6px;">
            <div style="font-size: 10px; color: #64748b; font-weight: bold; margin-bottom: 4px;">المدير الطبي وعضو اللجنة</div>
            <div style="font-size: 12px; font-weight: 900; color: #0f172a; margin-bottom: 16px;">د/ ابتسام الريمي</div>
            <div style="font-size: 9px; color: #94a3b8;">التوقيع: .....................</div>
          </div>

          <div style="border: 1px dashed #cbd5e1; padding: 8px; border-radius: 6px;">
            <div style="font-size: 10px; color: #64748b; font-weight: bold; margin-bottom: 4px;">رئيس اللجنة / مدير عام المستشفى</div>
            <div style="font-size: 12px; font-weight: 900; color: #0f172a; margin-bottom: 16px;">د/ محمد السراجي</div>
            <div style="font-size: 9px; color: #94a3b8;">التوقيع والاعتماد: .....................</div>
          </div>
        </div>
      </div>
    `;

    executeSmartPrint(minutesHtml, {
      title: `محضر ${meeting.title}`,
      subtitle: 'مستشفى آزال النموذجي • إدارة السلامة وإدارة المرافق FMS • سباهي CBAHI',
      refNumber: `AZAL-FMS-MIN-${meeting.id}`,
      inspectorName: meeting.recorded_by || 'م. نجيب غازي',
      department: 'لجنة الأمن والسلامة وإدارة المرافق (FMS)',
    });
  };

  // Filtered Meetings
  const filteredMeetings = useMemo(() => {
    return meetings.filter(m => {
      const matchesSearch = 
        m.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        m.agenda.toLowerCase().includes(searchTerm.toLowerCase()) ||
        m.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
        m.attendees.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (m.decisions_recommendations || '').toLowerCase().includes(searchTerm.toLowerCase());

      const matchesStatus = statusFilter === 'all' || m.status === statusFilter;

      return matchesSearch && matchesStatus;
    });
  }, [meetings, searchTerm, statusFilter]);

  return (
    <div className="space-y-5 animate-in fade-in duration-300">
      {/* Toast Notification */}
      {notification && (
        <div 
          className={`fixed bottom-6 left-6 z-50 px-4 py-3 rounded-xl shadow-2xl flex items-center gap-2.5 text-xs font-bold transition transform animate-in slide-in-from-bottom duration-200 ${
            notification.type === 'success' 
              ? 'bg-emerald-600 text-white border border-emerald-400' 
              : 'bg-rose-600 text-white border border-rose-400'
          }`}
        >
          {notification.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
          <span>{notification.message}</span>
        </div>
      )}

      {/* Prominent Orange Alert Banner (Smart Countdown 2 days before meeting) */}
      {upcomingNotice && (
        <div 
          id="safety-committee-countdown-alert"
          className="bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-slate-950 p-4 sm:p-5 rounded-2xl shadow-xl shadow-amber-950/30 border-2 border-amber-300 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 animate-in slide-in-from-top duration-300"
        >
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-black/15 border border-black/20 flex items-center justify-center shrink-0 text-2xl font-black shadow-inner animate-bounce">
              🔔
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="bg-black text-amber-300 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
                  تنبيه ذكي رسمي (FMS Smart Alert)
                </span>
                <span className="text-xs font-black bg-white/40 px-2 py-0.5 rounded-full text-slate-950">
                  {upcomingNotice.diffDays === 0 
                    ? 'الموعد: اليوم!' 
                    : upcomingNotice.diffDays === 1 
                    ? 'متبقي يوم واحد فقط!' 
                    : 'متبقي يومان (48 ساعة)'}
                </span>
              </div>
              <h3 className="text-base font-black text-slate-950 mt-1">
                تنبيه: {upcomingNotice.diffDays === 0 ? 'موعد اجتماع لجنة السلامة اليوم' : `متبقي ${upcomingNotice.diffDays === 1 ? 'يوم واحد' : 'يومان'} على موعد اجتماع لجنة السلامة وإدارة المرافق`}
              </h3>
              <p className="text-xs text-slate-900 font-semibold mt-0.5">
                {upcomingNotice.meeting.title} • التاريخ: {upcomingNotice.meeting.meeting_date} (الساعة {upcomingNotice.meeting.meeting_time}) • المكان: {upcomingNotice.meeting.location}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => handleOpenMinutesModal(upcomingNotice.meeting)}
            className="px-4 py-2.5 rounded-xl bg-slate-950 hover:bg-black text-amber-300 font-black text-xs shadow-lg flex items-center gap-1.5 shrink-0 transition active:scale-95"
          >
            <FileText className="w-4 h-4 text-amber-400" />
            <span>عرض المحضر وتوثيق القرارات</span>
          </button>
        </div>
      )}

      {/* Main Header Card */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 text-white shadow-xl backdrop-blur relative overflow-hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-amber-950/80 border border-amber-500/30 text-amber-400 flex items-center justify-center shrink-0 shadow-inner">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-black tracking-tight text-white">
                  اجتماعات لجنة السلامة والمحاضر (Safety Committee Hub)
                </h1>
                <span className="bg-amber-900/80 text-amber-300 border border-amber-600/40 text-[10px] font-black px-2 py-0.5 rounded-full">
                  FMS Committee CBAHI
                </span>
              </div>
              <p className="text-slate-400 text-xs mt-1 leading-relaxed max-w-2xl">
                إدارة وجدولة اجتماعات لجنة السلامة وإدارة المرافق (FMS)، نظام التذكير الذكي قبل الموعد بيومين، وتوثيق القرارات والتوصيات، وأرشفة صورة المحضر الرسمي الموقع، والطباعة الرسمية المعتمدة.
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              id="schedule-meeting-btn"
              onClick={() => setShowScheduleModal(true)}
              className="px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-slate-950 font-black text-xs shadow-lg shadow-amber-950 flex items-center gap-1.5 transition active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span>جدولة موعد اجتماع جديد</span>
            </button>

            <button
              type="button"
              onClick={loadMeetings}
              disabled={refreshing}
              className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
              title="تحديث البيانات"
            >
              <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin text-amber-400' : ''}`} />
            </button>
          </div>
        </div>

        {/* Quick Summary Row */}
        <div className="grid grid-cols-3 gap-3 mt-5 pt-4 border-t border-slate-800 text-center">
          <div className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-3">
            <span className="text-[11px] text-slate-400 block font-medium">إجمالي الاجتماعات</span>
            <span className="text-xl font-black text-white mt-1 block">{meetings.length}</span>
          </div>
          <div className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-3">
            <span className="text-[11px] text-amber-400 block font-medium">اجتماعات مجدولة قادمة</span>
            <span className="text-xl font-black text-amber-400 mt-1 block">
              {meetings.filter(m => m.status === 'scheduled').length}
            </span>
          </div>
          <div className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-3">
            <span className="text-[11px] text-emerald-400 block font-medium">محاضر معتمدة ومكتملة</span>
            <span className="text-xl font-black text-emerald-400 mt-1 block">
              {meetings.filter(m => m.status === 'completed').length}
            </span>
          </div>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3.5 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 flex-1 min-w-[240px]">
          <div className="relative w-full max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="بحث في عنوان الاجتماع، جدول الأعمال، أو الأعضاء..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl pr-9 pl-3 py-2 text-white placeholder:text-slate-500 text-xs focus:outline-none focus:border-amber-500 transition"
            />
          </div>
        </div>

        {/* Status Filter */}
        <div className="flex items-center bg-slate-950 border border-slate-700 rounded-xl p-1 gap-1">
          <button
            type="button"
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1 rounded-lg font-bold transition text-[11px] ${
              statusFilter === 'all' ? 'bg-amber-600 text-slate-950' : 'text-slate-400 hover:text-white'
            }`}
          >
            الكل ({meetings.length})
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('scheduled')}
            className={`px-3 py-1 rounded-lg font-bold transition text-[11px] ${
              statusFilter === 'scheduled' ? 'bg-amber-600 text-slate-950' : 'text-slate-400 hover:text-white'
            }`}
          >
            المجدولة
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('completed')}
            className={`px-3 py-1 rounded-lg font-bold transition text-[11px] ${
              statusFilter === 'completed' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            المكتملة
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('postponed')}
            className={`px-3 py-1 rounded-lg font-bold transition text-[11px] ${
              statusFilter === 'postponed' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            المؤجلة
          </button>
        </div>
      </div>

      {/* Meetings List */}
      {loading ? (
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-12 text-center text-slate-400">
          <RefreshCw className="w-8 h-8 animate-spin mx-auto text-amber-400 mb-3" />
          <p className="text-sm">جاري تحميل سجل اجتماعات لجنة السلامة...</p>
        </div>
      ) : filteredMeetings.length === 0 ? (
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-12 text-center text-slate-400">
          <Users className="w-12 h-12 mx-auto text-slate-600 mb-3" />
          <h3 className="text-base font-bold text-white mb-1">لا توجد اجتماعات مسجلة</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto mb-4">
            قم بجدولة موعد اجتماع لجنة السلامة وإدارة المرافق (FMS) القادم وتحديد جدول الأعمال.
          </p>
          <button
            type="button"
            onClick={() => setShowScheduleModal(true)}
            className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-slate-950 text-xs font-black inline-flex items-center gap-1.5 shadow"
          >
            <Plus className="w-4 h-4" />
            <span>جدولة أول اجتماع</span>
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredMeetings.map((meeting) => {
            const isCompleted = meeting.status === 'completed';
            const isScheduled = meeting.status === 'scheduled';
            const isPostponed = meeting.status === 'postponed';

            return (
              <div
                key={meeting.id}
                className="bg-slate-900/80 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 sm:p-5 transition shadow-lg space-y-4"
              >
                {/* Header Information */}
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-800 pb-3">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-base font-black text-white">
                        {meeting.title}
                      </h3>

                      <span 
                        className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${
                          isCompleted
                            ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                            : isPostponed
                            ? 'bg-rose-950 text-rose-300 border-rose-800'
                            : 'bg-amber-950 text-amber-300 border-amber-800'
                        }`}
                      >
                        {isCompleted ? '✓ مكتمل ومعتمد' : isPostponed ? 'مؤجل' : '⏳ مجدول'}
                      </span>

                      {meeting.minutes_image_url && (
                        <span className="text-[10px] bg-teal-950 text-teal-300 border border-teal-700 px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                          <ImageIcon className="w-3 h-3" />
                          <span>المحضر الموقع مرفق</span>
                        </span>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 pt-1">
                      <span className="flex items-center gap-1 text-slate-300 font-semibold">
                        <Calendar className="w-3.5 h-3.5 text-amber-400" />
                        {meeting.meeting_date}
                      </span>
                      <span className="flex items-center gap-1 text-slate-300 font-semibold">
                        <Clock className="w-3.5 h-3.5 text-amber-400" />
                        {meeting.meeting_time}
                      </span>
                      <span className="flex items-center gap-1 text-slate-300">
                        <MapPin className="w-3.5 h-3.5 text-slate-500" />
                        {meeting.location}
                      </span>
                    </div>
                  </div>

                  {/* Actions for this meeting */}
                  <div className="flex flex-wrap items-center gap-2">
                    {/* Official Minutes & Decisions Button */}
                    <button
                      type="button"
                      onClick={() => handleOpenMinutesModal(meeting)}
                      className="px-3.5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs shadow flex items-center gap-1.5 transition active:scale-95"
                      title="توثيق القرارات ورفع صورة المحضر الرسمي الموقع"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span>{meeting.decisions_recommendations || meeting.minutes_image_url ? 'تعديل المحضر والقرارات' : 'توثيق المحضر والقرارات'}</span>
                    </button>

                    {/* Print Official Minutes */}
                    <button
                      type="button"
                      onClick={() => handlePrintOfficialMinutes(meeting)}
                      className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs flex items-center gap-1.5 transition"
                      title="طباعة محضر الاجتماع الرسمي المعتمد لسباهي والإدارة العامة"
                    >
                      <Printer className="w-3.5 h-3.5 text-amber-400" />
                      <span>طباعة المحضر (PDF)</span>
                    </button>

                    {/* Status Dropdown */}
                    <select
                      value={meeting.status}
                      onChange={(e) => handleStatusChange(meeting, e.target.value as CommitteeMeetingStatus)}
                      className="bg-slate-950 text-slate-300 border border-slate-700 rounded-xl px-2.5 py-2 text-xs focus:outline-none cursor-pointer"
                    >
                      <option value="scheduled">مجدول</option>
                      <option value="completed">مكتمل</option>
                      <option value="postponed">مؤجل</option>
                    </select>

                    <button
                      type="button"
                      onClick={() => handleDeleteMeeting(meeting.id, meeting.title)}
                      className="p-2 rounded-xl text-slate-500 hover:text-rose-400 hover:bg-rose-950/30 transition"
                      title="حذف الاجتماع"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Content Grid: Agenda & Decisions */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  {/* Agenda */}
                  <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 space-y-2">
                    <span className="font-bold text-slate-300 flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5 text-amber-400" />
                      <span>جدول الأعمال ومحاور الاجتماع (Agenda):</span>
                    </span>
                    <p className="text-slate-400 whitespace-pre-line leading-relaxed font-sans">
                      {meeting.agenda}
                    </p>
                  </div>

                  {/* Decisions & Recommendations */}
                  <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3.5 space-y-2">
                    <span className="font-bold text-slate-300 flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>القرارات والتوصيات الصادرة:</span>
                    </span>
                    {meeting.decisions_recommendations ? (
                      <p className="text-emerald-300/90 whitespace-pre-line leading-relaxed font-sans bg-emerald-950/30 p-2.5 rounded-lg border border-emerald-800/40">
                        {meeting.decisions_recommendations}
                      </p>
                    ) : (
                      <div className="text-slate-500 italic py-2">
                        لم يتم توثيق القرارات والتوصيات بعد. انقر على زر "توثيق المحضر والقرارات" لإدخالها.
                      </div>
                    )}
                  </div>
                </div>

                {/* Attendees and Signed Minutes Preview */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs bg-slate-950/40 p-3 rounded-xl border border-slate-800/60">
                  <div className="text-slate-400">
                    <strong className="text-slate-300">أعضاء اللجنة المشاركون:</strong> {meeting.attendees}
                  </div>

                  {meeting.minutes_image_url && (
                    <div className="flex items-center gap-2 shrink-0">
                      <div 
                        onClick={() => setSelectedImagePreview(meeting.minutes_image_url!)}
                        className="relative group cursor-pointer overflow-hidden rounded-lg border border-teal-700 bg-slate-950 w-16 h-12 shrink-0 shadow"
                      >
                        <img 
                          src={meeting.minutes_image_url} 
                          alt="المحضر الموقع" 
                          className="w-full h-full object-cover group-hover:scale-105 transition"
                        />
                        <div className="absolute inset-0 bg-slate-950/40 flex items-center justify-center">
                          <Eye className="w-4 h-4 text-teal-300" />
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setSelectedImagePreview(meeting.minutes_image_url!)}
                        className="text-[11px] text-teal-400 hover:underline font-bold"
                      >
                        معاينة صورة المحضر الموقع
                      </button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Image Lightbox Modal */}
      {selectedImagePreview && (
        <div 
          className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4"
          onClick={() => setSelectedImagePreview(null)}
        >
          <div 
            className="relative max-w-3xl w-full bg-slate-900 border border-slate-700 rounded-2xl overflow-hidden shadow-2xl p-2"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between p-3 border-b border-slate-800">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <ImageIcon className="w-4 h-4 text-amber-400" />
                معاينة صورة محضر اجتماع لجنة السلامة الرسمي الموقع
              </span>
              <button
                type="button"
                onClick={() => setSelectedImagePreview(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-2 max-h-[75vh] overflow-auto flex items-center justify-center bg-black/40 rounded-xl m-1">
              <img 
                src={selectedImagePreview} 
                alt="محضر الاجتماع" 
                className="max-h-[70vh] w-auto max-w-full object-contain rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      )}

      {/* Modal 1: Schedule New Meeting */}
      {showScheduleModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="relative w-full max-w-xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden text-right my-8">
            <div className="bg-gradient-to-r from-amber-900 to-slate-900 p-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-600 text-slate-950 font-black flex items-center justify-center">
                  <Calendar className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white">جدولة موعد اجتماع جديد للجنة السلامة (FMS)</h3>
                  <span className="text-[10px] text-amber-300">يتم إطلاق تنبيه ذكي برتقالي تلقائياً قبل الموعد بيومين</span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowScheduleModal(false)}
                className="p-1 text-slate-400 hover:text-white rounded-lg transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleScheduleSubmit} className="p-5 space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  عنوان الاجتماع <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="مثال: اجتماع لجنة السلامة وإدارة المرافق (FMS) الدوري - الربع الثالث 2026..."
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">تاريخ الاجتماع</label>
                  <input
                    type="date"
                    required
                    value={formData.meeting_date}
                    onChange={(e) => setFormData({ ...formData, meeting_date: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-bold mb-1">وقت الاجتماع</label>
                  <input
                    type="time"
                    required
                    value={formData.meeting_time}
                    onChange={(e) => setFormData({ ...formData, meeting_time: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">مكان الانعقاد</label>
                <select
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500"
                >
                  {COMMON_LOCATIONS.map(loc => (
                    <option key={loc} value={loc}>{loc}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  جدول الأعمال وأبرز محاور النقاش <span className="text-rose-400">*</span>
                </label>
                <textarea
                  required
                  rows={4}
                  value={formData.agenda}
                  onChange={(e) => setFormData({ ...formData, agenda: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500 leading-relaxed font-sans"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">الأعضاء الحاضرون / المدعوون</label>
                <textarea
                  rows={2}
                  value={formData.attendees}
                  onChange={(e) => setFormData({ ...formData, attendees: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white focus:outline-none focus:border-amber-500 leading-relaxed font-sans"
                />
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowScheduleModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold transition"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-slate-950 font-black transition shadow-lg shadow-amber-950 flex items-center gap-1.5"
                >
                  {isSubmitting ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>جاري الجدولة...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>تأكيد جدولة الاجتماع</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 2: Minutes Documentation & Signed Photo Upload */}
      {showMinutesModal && selectedMeetingForMinutes && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden text-right my-8">
            <div className="bg-gradient-to-r from-teal-900 via-slate-900 to-slate-900 p-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-teal-800/80 text-teal-200 flex items-center justify-center">
                  <FileText className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white">توثيق محضر الاجتماع والقرارات الرسمية</h3>
                  <span className="text-[10px] text-teal-300">{selectedMeetingForMinutes.title}</span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowMinutesModal(false)}
                className="p-1 text-slate-400 hover:text-white rounded-lg transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveMinutes} className="p-5 space-y-4 text-xs">
              {/* Decisions & Recommendations Textarea */}
              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  القرارات والتوصيات الصادرة عن اللجنة <span className="text-rose-400">*</span>
                </label>
                <textarea
                  required
                  rows={6}
                  placeholder="اكتب التوصيات والقرارات المعتمدة: 
1. إلزام كافة الأقسام بتحديث لوحات الطوارئ...
2. التنسيق مع إدارة الصيانة لإنجاز إصلاحات أنظمة الإنذار...
3. تحديد موعد تنفيذ تمرين الإخلاء الوهمي..."
                  value={minutesData.decisions_recommendations}
                  onChange={(e) => setMinutesData({ ...minutesData, decisions_recommendations: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white placeholder:text-slate-500 focus:outline-none focus:border-teal-500 leading-relaxed font-sans"
                />
              </div>

              {/* Upload Minutes Image */}
              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  رفع صورة محضر الاجتماع الرسمي الموقع (Upload Minutes Image)
                </label>
                <div className="border-2 border-dashed border-teal-500/40 hover:border-teal-500 rounded-xl p-4 text-center transition bg-slate-950/60">
                  {minutesData.minutes_image_url ? (
                    <div className="flex items-center justify-between gap-3">
                      <img 
                        src={minutesData.minutes_image_url} 
                        alt="محضر موقع" 
                        className="w-20 h-16 object-cover rounded-lg border border-teal-500/50" 
                      />
                      <div className="text-right flex-1 pr-2">
                        <span className="text-xs text-teal-300 font-bold block">✓ تم إرفاق وثيقة المحضر الموقع بنجاح</span>
                        <span className="text-[10px] text-slate-400">يمكن معاينة الوثيقة وطباعتها ضمن تقرير الاجتماع الرسمي</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setMinutesData({ ...minutesData, minutes_image_url: '' })}
                        className="p-2 rounded-lg bg-rose-950 text-rose-300 border border-rose-800 text-[11px] hover:bg-rose-900 transition"
                      >
                        إزالة الصورة
                      </button>
                    </div>
                  ) : (
                    <div>
                      <Upload className="w-6 h-6 text-teal-400 mx-auto mb-1" />
                      <label className="cursor-pointer text-teal-400 hover:text-teal-300 font-bold">
                        <span>انقر لرفع صورة المحضر الرسمي الموقع من الألبوم أو الكاميرا</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleMinutesImageChange}
                          className="hidden"
                        />
                      </label>
                      <p className="text-[10px] text-slate-400 mt-1">يدعم JPG, PNG بجودة عالية لأرشفة توقيعات أعضاء اللجنة</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowMinutesModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold transition"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold transition shadow-lg shadow-teal-950 flex items-center gap-1.5"
                >
                  {isSubmitting ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>جاري حفظ المحضر...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>حفظ واعتماد المحضر الرسمي</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
