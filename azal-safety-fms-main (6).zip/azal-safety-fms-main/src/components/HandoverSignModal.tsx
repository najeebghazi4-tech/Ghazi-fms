import React, { useState } from 'react';
import { 
  X, 
  CheckCircle2, 
  ShieldCheck, 
  KeyRound, 
  AlertTriangle, 
  Lock, 
  Fingerprint, 
  FileSignature, 
  Clock, 
  UserCheck 
} from 'lucide-react';
import { ISBARData, StaffUser, HandoverRecord } from '../types';

interface HandoverSignModalProps {
  patient: ISBARData;
  staffList: StaffUser[];
  currentUser: StaffUser;
  onClose: () => void;
  onCompleteHandover: (record: HandoverRecord) => void;
}

export const HandoverSignModal: React.FC<HandoverSignModalProps> = ({
  patient,
  staffList,
  currentUser,
  onClose,
  onCompleteHandover,
}) => {
  // Outgoing staff
  const [outgoingStaffId, setOutgoingStaffId] = useState(currentUser.id);
  const [outgoingPin, setOutgoingPin] = useState('');
  const [outgoingVerified, setOutgoingVerified] = useState(false);

  // Incoming staff
  const [incomingStaffId, setIncomingStaffId] = useState(
    staffList.find((s) => s.id !== currentUser.id)?.id || staffList[0].id
  );
  const [incomingPin, setIncomingPin] = useState('');
  const [incomingVerified, setIncomingVerified] = useState(false);

  const [shiftType, setShiftType] = useState<'morning' | 'evening' | 'night'>('evening');
  const [clinicalSummary, setClinicalSummary] = useState(
    `تم تسليم واستلام المريض بجانب السرير (Bedside Handoff)، مراجعة العلامات الحيوية، سلامة القساطر، والتأكيد على التحسس والمهام المعلقة.`
  );
  const [specialInstructions, setSpecialInstructions] = useState(patient.criticalAlertNotes || '');

  // Patient safety checklist
  const [checklist, setChecklist] = useState({
    wristbandChecked: true,
    ivPumpsChecked: true,
    allergiesConfirmed: true,
    pendingLabsConfirmed: true,
  });

  const [errorMsg, setErrorMsg] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);
  const [generatedHash, setGeneratedHash] = useState('');

  const outgoingStaff = staffList.find((s) => s.id === outgoingStaffId) || staffList[0];
  const incomingStaff = staffList.find((s) => s.id === incomingStaffId) || staffList[0];

  const handleVerifyOutgoing = () => {
    if (outgoingPin === outgoingStaff.pin) {
      setOutgoingVerified(true);
      setErrorMsg('');
    } else {
      setErrorMsg(`رمز PIN غير صحيح للمسلم (${outgoingStaff.name})`);
    }
  };

  const handleVerifyIncoming = () => {
    if (incomingPin === incomingStaff.pin) {
      setIncomingVerified(true);
      setErrorMsg('');
    } else {
      setErrorMsg(`رمز PIN غير صحيح للمستلم (${incomingStaff.name})`);
    }
  };

  const handleSubmitHandover = (e: React.FormEvent) => {
    e.preventDefault();
    if (!outgoingVerified) {
      setErrorMsg('يجب إدخال وتأكيد الرمز السري للطرف المسلم أولاً');
      return;
    }
    if (!incomingVerified) {
      setErrorMsg('يجب إدخال وتأكيد الرمز السري للطرف المستلم أولاً');
      return;
    }
    if (!checklist.wristbandChecked || !checklist.ivPumpsChecked || !checklist.allergiesConfirmed) {
      setErrorMsg('يجب استيفاء جميع بنود الأمان السريري ومطابقة سوار المعصم بجانب السرير');
      return;
    }

    // Generate cryptographic-style unique verification hash
    const pseudoHash = `SHA256:${Math.random().toString(36).substring(2, 10)}${Date.now().toString(36)}${Math.random().toString(36).substring(2, 10)}`.toUpperCase();
    setGeneratedHash(pseudoHash);

    const newRecord: HandoverRecord = {
      id: `handover-${Date.now()}`,
      patientId: patient.patientId,
      shiftType,
      shiftDate: new Date().toISOString().split('T')[0],
      outgoingStaff: {
        id: outgoingStaff.id,
        name: outgoingStaff.name,
        role: outgoingStaff.roleTitleAr,
        signedAt: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
      },
      incomingStaff: {
        id: incomingStaff.id,
        name: incomingStaff.name,
        role: incomingStaff.roleTitleAr,
        signedAt: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
      },
      clinicalSummary,
      specialInstructions,
      verificationHash: pseudoHash,
      status: 'completed',
    };

    setIsSuccess(true);
    setTimeout(() => {
      onCompleteHandover(newRecord);
    }, 1800);
  };

  return (
    <div id="handover-sign-modal-overlay" className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-teal-600/60 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl text-right">
        {/* Header */}
        <div className="bg-slate-950 p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-teal-950 border border-teal-800 text-teal-400">
              <FileSignature className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-100">
                محضر اعتماد التسليم والاستلام السريري المزدوج
              </h2>
              <p className="text-xs text-slate-400">
                المريض: <span className="text-teal-300 font-bold">{patient.fullName}</span> ({patient.bedNumber})
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-100"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Success Splash */}
        {isSuccess ? (
          <div className="p-8 text-center space-y-4 animate-fade-in">
            <div className="w-16 h-16 rounded-full bg-emerald-950 border-2 border-emerald-500 text-emerald-400 mx-auto flex items-center justify-center shadow-lg shadow-emerald-950">
              <CheckCircle2 className="w-10 h-10 animate-bounce" />
            </div>
            <h3 className="text-lg font-bold text-slate-100">
              تم توثيق واعتماد الاستلام والتسليم بنجاح
            </h3>
            <p className="text-xs text-slate-300 max-w-md mx-auto leading-relaxed">
              تم إغلاق مسؤولية الوردية الصادرة وتثبيت مسؤولية الوردية القادمة مع ختم التحقق المشفر في سجل الأمان الطبي المركزي.
            </p>
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 font-mono text-[11px] text-teal-400 select-all max-w-md mx-auto">
              بصمة التحقق الرقمي: {generatedHash}
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmitHandover} className="p-4 space-y-4 max-h-[80vh] overflow-y-auto">
            {/* Shift & Safety Confirmation */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="text-slate-400 block mb-1 font-semibold">نوع الوردية:</label>
                <select
                  value={shiftType}
                  onChange={(e) => setShiftType(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-slate-100"
                >
                  <option value="morning">الوردية الصباحية (Morning Shift)</option>
                  <option value="evening">الوردية المسائية (Evening Shift)</option>
                  <option value="night">الوردية الليلية (Night Shift)</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1 font-semibold">مكان التسليم:</label>
                <div className="bg-slate-950 border border-slate-700 rounded-lg p-2 text-teal-300 font-bold flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-teal-400" />
                  <span>بجانب سرير المريض المباشر (Bedside)</span>
                </div>
              </div>
            </div>

            {/* Checklist items */}
            <div className="bg-slate-950/70 p-3 rounded-xl border border-slate-800 space-y-2 text-xs">
              <span className="font-bold text-teal-400 block mb-1">
                معايير الأمان الإلزامية لتسليم المريض (Joint Commission / CBAHI):
              </span>
              <label className="flex items-center gap-2 cursor-pointer text-slate-200">
                <input
                  type="checkbox"
                  checked={checklist.wristbandChecked}
                  onChange={(e) => setChecklist({ ...checklist, wristbandChecked: e.target.checked })}
                  className="h-4 w-4 rounded bg-slate-900 border-slate-700 text-teal-500"
                />
                <span>تم مطابقة هوية المريض الثنائية بسوار المعصم (الاسم + رقم الملف MRN)</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer text-slate-200">
                <input
                  type="checkbox"
                  checked={checklist.ivPumpsChecked}
                  onChange={(e) => setChecklist({ ...checklist, ivPumpsChecked: e.target.checked })}
                  className="h-4 w-4 rounded bg-slate-900 border-slate-700 text-teal-500"
                />
                <span>تمت معاينة خطوط الوريد ومضخات الحقن النشطة ومعدلات التسريب عيانياً</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer text-slate-200">
                <input
                  type="checkbox"
                  checked={checklist.allergiesConfirmed}
                  onChange={(e) => setChecklist({ ...checklist, allergiesConfirmed: e.target.checked })}
                  className="h-4 w-4 rounded bg-slate-900 border-slate-700 text-teal-500"
                />
                <span>تم تنبيه الممرض/الطبيب المستلم لقائمة الحساسيات الشديدة للمريض</span>
              </label>
            </div>

            {/* Side by Side Dual Electronic Signatures */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {/* Box 1: Outgoing Staff */}
              <div className={`p-3 rounded-xl border space-y-2.5 ${outgoingVerified ? 'bg-emerald-950/20 border-emerald-700/60' : 'bg-slate-950 border-slate-800'}`}>
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-200 flex items-center gap-1">
                    <UserCheck className="w-3.5 h-3.5 text-teal-400" />
                    <span>الطرف المُسلِّم (الوردية المغادرة)</span>
                  </span>
                  {outgoingVerified && (
                    <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded font-bold">
                      تم التوثيق بالرمز
                    </span>
                  )}
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">اسم الممارس المسلِّم:</label>
                  <select
                    value={outgoingStaffId}
                    disabled={outgoingVerified}
                    onChange={(e) => {
                      setOutgoingStaffId(e.target.value);
                      setOutgoingVerified(false);
                    }}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-xs text-slate-100"
                  >
                    {staffList.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.badgeNumber})
                      </option>
                    ))}
                  </select>
                </div>

                {!outgoingVerified ? (
                  <div className="flex gap-2">
                    <input
                      type="password"
                      maxLength={4}
                      placeholder="رمز PIN المسلم (4 أرقام)"
                      value={outgoingPin}
                      onChange={(e) => setOutgoingPin(e.target.value)}
                      className="flex-1 bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-xs text-center font-mono tracking-widest text-slate-100"
                    />
                    <button
                      type="button"
                      onClick={handleVerifyOutgoing}
                      className="px-3 py-1.5 rounded-lg bg-teal-700 hover:bg-teal-600 text-white text-xs font-bold"
                    >
                      توقيع المسلِّم
                    </button>
                  </div>
                ) : (
                  <div className="text-[11px] text-emerald-400 font-medium">
                    ✓ تم توقيع واعتماد المسلِّم إلكترونياً
                  </div>
                )}
              </div>

              {/* Box 2: Incoming Staff */}
              <div className={`p-3 rounded-xl border space-y-2.5 ${incomingVerified ? 'bg-emerald-950/20 border-emerald-700/60' : 'bg-slate-950 border-slate-800'}`}>
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-200 flex items-center gap-1">
                    <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span>الطرف المُستلِم (الوردية القادمة)</span>
                  </span>
                  {incomingVerified && (
                    <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded font-bold">
                      تم التوثيق بالرمز
                    </span>
                  )}
                </div>

                <div>
                  <label className="text-[11px] text-slate-400 block mb-1">اسم الممارس المستلِم:</label>
                  <select
                    value={incomingStaffId}
                    disabled={incomingVerified}
                    onChange={(e) => {
                      setIncomingStaffId(e.target.value);
                      setIncomingVerified(false);
                    }}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-xs text-slate-100"
                  >
                    {staffList.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name} ({s.badgeNumber})
                      </option>
                    ))}
                  </select>
                </div>

                {!incomingVerified ? (
                  <div className="flex gap-2">
                    <input
                      type="password"
                      maxLength={4}
                      placeholder="رمز PIN المستلم (4 أرقام)"
                      value={incomingPin}
                      onChange={(e) => setIncomingPin(e.target.value)}
                      className="flex-1 bg-slate-900 border border-slate-700 rounded-lg p-1.5 text-xs text-center font-mono tracking-widest text-slate-100"
                    />
                    <button
                      type="button"
                      onClick={handleVerifyIncoming}
                      className="px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold"
                    >
                      توقيع المستلِم
                    </button>
                  </div>
                ) : (
                  <div className="text-[11px] text-emerald-400 font-medium">
                    ✓ تم توقيع واستلام المسؤولية السريرية
                  </div>
                )}
              </div>
            </div>

            {errorMsg && (
              <div className="p-2.5 rounded-xl bg-rose-950/80 border border-rose-800 text-rose-300 text-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Bottom Actions */}
            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-slate-200 bg-slate-800"
              >
                إلغاء
              </button>
              <button
                type="submit"
                disabled={!outgoingVerified || !incomingVerified}
                className={`px-5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition shadow-lg ${
                  outgoingVerified && incomingVerified
                    ? 'bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white cursor-pointer'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                <ShieldCheck className="w-4 h-4" />
                <span>اعتماد التسليم وتوليد الختم المشفر</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
