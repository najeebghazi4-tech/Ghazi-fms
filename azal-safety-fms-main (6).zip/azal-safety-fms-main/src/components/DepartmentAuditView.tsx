import React, { useState, useEffect, useMemo } from 'react';
import { 
  Building2, 
  CheckCircle2, 
  XCircle, 
  MinusCircle, 
  Camera, 
  Wifi, 
  WifiOff, 
  RefreshCw, 
  Printer, 
  FileCheck, 
  AlertTriangle, 
  Plus, 
  Trash2, 
  Search, 
  ChevronDown, 
  Calendar, 
  UserCheck, 
  Sparkles,
  ClipboardList,
  Eye,
  ArrowRight,
  Shield,
  Layers,
  Award,
  Loader2,
  FileText
} from 'lucide-react';
import { 
  DepartmentAuditRecord, 
  AuditCheckItem, 
  AuditCheckItemStatus, 
  CorrectiveActionItem,
  StaffUser 
} from '../types';
import { AUDIT_DEPARTMENTS, DepartmentAuditTemplate, normalizeDepartmentId } from '../data/azalDepartmentAuditData';
import { offlineStorage } from '../services/offlineStorage';
import { supabase } from '../services/supabaseClient';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';
import { printExistingElementById } from '../utils/printUtils';

interface DepartmentAuditViewProps {
  currentUser: StaffUser;
  onAuditSaved?: (audit: DepartmentAuditRecord) => void;
  onNavigateHome?: () => void;
  onLogAudit?: (action: string, category: string, details: string) => void;
  onAddViolationNotice?: (notice: any) => void;
}

export const DepartmentAuditView: React.FC<DepartmentAuditViewProps> = ({
  currentUser,
  onAuditSaved,
  onNavigateHome,
  onLogAudit,
  onAddViolationNotice
}) => {
  // Offline status tracking
  const [isOnline, setIsOnline] = useState<boolean>(typeof navigator !== 'undefined' ? navigator.onLine : true);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [isLoadingItems, setIsLoadingItems] = useState<boolean>(false);
  const [savedAlert, setSavedAlert] = useState<{ show: boolean; message: string; type: 'offline' | 'online' } | null>(null);

  // Audits list & Active audit
  const [auditsList, setAuditsList] = useState<DepartmentAuditRecord[]>([]);
  const [selectedAudit, setSelectedAudit] = useState<DepartmentAuditRecord | null>(null);
  const [isCreatingNew, setIsCreatingNew] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'audit_form' | 'cap_plan' | 'audit_history' | 'print_preview'>('audit_form');

  // New Audit creation state
  const [selectedDeptTemplate, setSelectedDeptTemplate] = useState<DepartmentAuditTemplate>(AUDIT_DEPARTMENTS[0]);
  const [auditDate, setAuditDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [currentItems, setCurrentItems] = useState<AuditCheckItem[]>([]);
  const [capPlanNotes, setCapPlanNotes] = useState<string>('');
  const [activeDepartmentFilter, setActiveDepartmentFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Triple Signature State
  // 1. Nursing Authority Head: د/ نبيل عصار
  const [supervisorName, setSupervisorName] = useState<string>('د/ نبيل عصار');
  const [supervisorTitle, setSupervisorTitle] = useState<string>('رئيس هيئة التمريض ومشرف الأقسام');
  const [supervisorSigned, setSupervisorSigned] = useState<boolean>(true);
  const [supervisorSignTime, setSupervisorSignTime] = useState<string>(new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }));

  // 2. Maintenance Representative: عارف الصلوي
  const [maintenanceName, setMaintenanceName] = useState<string>('عارف الصلوي');
  const [maintenanceTitle, setMaintenanceTitle] = useState<string>('ممثل الصيانة المعتمد');
  const [maintenanceSigned, setMaintenanceSigned] = useState<boolean>(true);
  const [maintenanceSignTime, setMaintenanceSignTime] = useState<string>(new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }));

  // 3. Fixed Safety Head as requested: م/ نجيب غازي
  const safetyHeadName = 'م/ نجيب غازي';
  const safetyHeadTitle = 'رئيس قسم الأمن والسلامة وإدارة المرافق FMS';
  const [safetySigned, setSafetySigned] = useState<boolean>(true);
  const [safetySignTime, setSafetySignTime] = useState<string>(new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }));

  // Load initial audits from offline storage
  useEffect(() => {
    const handleOnlineStatus = () => setIsOnline(navigator.onLine);
    window.addEventListener('online', handleOnlineStatus);
    window.addEventListener('offline', handleOnlineStatus);

    const loadAudits = async () => {
      const records = await offlineStorage.getDepartmentAudits();
      setAuditsList(records);
      if (records.length > 0 && !selectedAudit) {
        loadAuditIntoState(records[0]);
      } else if (records.length === 0) {
        startNewAudit(AUDIT_DEPARTMENTS[0]);
      }
    };

    loadAudits();

    const unsubscribe = offlineStorage.subscribe(() => {
      offlineStorage.getDepartmentAudits().then(setAuditsList);
    });

    return () => {
      window.removeEventListener('online', handleOnlineStatus);
      window.removeEventListener('offline', handleOnlineStatus);
      unsubscribe();
    };
  }, []);

  // Initialize a new audit from template or database table monthly_audit_items
  const startNewAudit = async (template: DepartmentAuditTemplate) => {
    setSelectedDeptTemplate(template);
    setIsCreatingNew(true);
    setSelectedAudit(null);
    setAuditDate(new Date().toISOString().split('T')[0]);
    setIsLoadingItems(true);

    try {
      // Auto-load items from database table monthly_audit_items
      const { data: dbItems } = await supabase
        .from('monthly_audit_items')
        .select('*')
        .eq('department_id', template.departmentId);

      if (dbItems && dbItems.length > 0) {
        const items: AuditCheckItem[] = dbItems.map((item: any, idx: number) => ({
          id: `item-${template.departmentId}-${idx}-${Date.now()}`,
          code: item.code,
          standardRef: item.standard_ref || 'CBAHI',
          category: item.category || 'معايير السلامة والجودة',
          clauseText: item.clause_text || '',
          status: 'compliant' as AuditCheckItemStatus,
          defectDescription: '',
          severity: 'medium',
          assignedAction: '',
        }));
        setCurrentItems(items);
      } else {
        // Fallback to template defaultItems
        const items: AuditCheckItem[] = template.defaultItems.map((item, idx) => ({
          ...item,
          id: `item-${template.departmentId}-${idx}-${Date.now()}`,
          status: 'compliant' as AuditCheckItemStatus,
          defectDescription: '',
          severity: 'medium',
          assignedAction: '',
        }));
        setCurrentItems(items);
      }
    } catch (err) {
      console.warn('Fallback to local template items:', err);
      const items: AuditCheckItem[] = template.defaultItems.map((item, idx) => ({
        ...item,
        id: `item-${template.departmentId}-${idx}-${Date.now()}`,
        status: 'compliant' as AuditCheckItemStatus,
        defectDescription: '',
        severity: 'medium',
        assignedAction: '',
      }));
      setCurrentItems(items);
    } finally {
      setIsLoadingItems(false);
    }

    setCapPlanNotes('');
    setSupervisorName('د/ نبيل عصار');
    setSupervisorTitle('رئيس هيئة التمريض ومشرف الأقسام');
    setSupervisorSigned(true);
    setSupervisorSignTime(new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }));
    
    setMaintenanceName('عارف الصلوي');
    setMaintenanceTitle('ممثل الصيانة المعتمد');
    setMaintenanceSigned(true);
    setMaintenanceSignTime(new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }));

    setSafetySigned(true);
    setSafetySignTime(new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }));
    setActiveTab('audit_form');
  };

  // Department Dropdown Select Handler
  const handleDepartmentDropdownChange = (deptId: string) => {
    const canonicalId = normalizeDepartmentId(deptId);
    const template = AUDIT_DEPARTMENTS.find(d => normalizeDepartmentId(d.departmentId) === canonicalId) || AUDIT_DEPARTMENTS[0];
    startNewAudit(template);
  };

  // Load existing audit into working state
  const loadAuditIntoState = (record: DepartmentAuditRecord) => {
    setSelectedAudit(record);
    setIsCreatingNew(false);
    const template = AUDIT_DEPARTMENTS.find(d => normalizeDepartmentId(d.departmentId) === normalizeDepartmentId(record.departmentId)) || AUDIT_DEPARTMENTS[0];
    setSelectedDeptTemplate(template);
    setAuditDate(record.auditDate);
    setCurrentItems(record.items);
    setCapPlanNotes(record.capPlan || '');

    setSupervisorName(record.signatures.deptSupervisor.name || 'د/ نبيل عصار');
    setSupervisorTitle(record.signatures.deptSupervisor.title || 'رئيس هيئة التمريض');
    setSupervisorSigned(record.signatures.deptSupervisor.signed);
    setSupervisorSignTime(record.signatures.deptSupervisor.signedAt || '');

    setMaintenanceName(record.signatures.maintenanceRep.name || 'عارف الصلوي');
    setMaintenanceTitle(record.signatures.maintenanceRep.title || 'ممثل الصيانة');
    setMaintenanceSigned(record.signatures.maintenanceRep.signed);
    setMaintenanceSignTime(record.signatures.maintenanceRep.signedAt || '');

    setSafetySigned(record.signatures.safetyHead.signed);
    setSafetySignTime(record.signatures.safetyHead.signedAt || '');
  };

  // Status toggle handler
  const handleItemStatusChange = (itemId: string, newStatus: AuditCheckItemStatus) => {
    setCurrentItems(prev => prev.map(item => {
      if (item.id !== itemId) return item;
      return {
        ...item,
        status: newStatus,
        defectDescription: newStatus === 'non_compliant' && !item.defectDescription 
          ? 'لوحظ عدم الامتثال الكامل للبند أثناء المعاينة الميدانية ويستلزم تصحيحاً فورياً.'
          : item.defectDescription
      };
    }));
  };

  // Field change handler for non-compliant items
  const handleItemFieldChange = (itemId: string, field: keyof AuditCheckItem, value: any) => {
    setCurrentItems(prev => prev.map(item => {
      if (item.id !== itemId) return item;
      return { ...item, [field]: value };
    }));
  };

  // Add custom check item
  const handleAddCustomItem = () => {
    const newItem: AuditCheckItem = {
      id: `item-custom-${Date.now()}`,
      code: `${selectedDeptTemplate.codePrefix}-${String(currentItems.length + 1).padStart(2, '0')}`,
      standardRef: 'CBAHI',
      category: 'معايير إضافية خاصة بالقسم',
      clauseText: 'ملاحظة تدقيق ميدانية إضافية وفق اشتراطات السلامة والجودة.',
      status: 'compliant',
      defectDescription: '',
      severity: 'medium',
      assignedAction: ''
    };
    setCurrentItems(prev => [...prev, newItem]);
  };

  // Image upload simulation / preview for non-compliant items
  const handlePhotoUpload = (itemId: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        handleItemFieldChange(itemId, 'photoUrl', reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Real-time Compliance Percentage Calculation (% Compliance)
  const complianceStats = useMemo(() => {
    const total = currentItems.length;
    const compliant = currentItems.filter(i => i.status === 'compliant').length;
    const nonCompliant = currentItems.filter(i => i.status === 'non_compliant').length;
    const notApplicable = currentItems.filter(i => i.status === 'not_applicable').length;
    const evaluated = total - notApplicable;
    const percentage = evaluated > 0 ? Math.round((compliant / evaluated) * 100) : 100;

    return {
      total,
      compliant,
      nonCompliant,
      notApplicable,
      percentage,
      isHigh: percentage >= 85,
      isMedium: percentage >= 70 && percentage < 85,
      isCritical: percentage < 70
    };
  }, [currentItems]);

  // Generate automated Corrective Actions (CAP) from non-compliant items
  const correctiveActions: CorrectiveActionItem[] = useMemo(() => {
    return currentItems
      .filter(i => i.status === 'non_compliant')
      .map((item) => ({
        id: `cap-${item.id}`,
        itemId: item.id,
        clauseCode: item.code,
        defectDescription: item.defectDescription || 'ملاحظة غير مطابقة رصدت في التدقيق الميداني.',
        actionRequired: item.assignedAction || `معالجة الخلل فورياً وتصحيح وضع (${item.clauseText}) وفق المعايير المعتمدة.`,
        assignedDepartment: selectedDeptTemplate.departmentNameAr,
        targetDeadline: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        riskLevel: item.severity || 'high',
        status: 'open'
      }));
  }, [currentItems, selectedDeptTemplate]);

  // Save Audit (Dual Persistence: Offline-First IndexedDB + Supabase Client)
  const handleSaveAudit = async () => {
    const now = Date.now();
    const isOnlineNow = typeof navigator !== 'undefined' ? navigator.onLine : false;

    const auditRecord: DepartmentAuditRecord = {
      id: selectedAudit && !isCreatingNew ? selectedAudit.id : `AZAL-AUDIT-${selectedDeptTemplate.departmentId}-${Date.now()}`,
      departmentId: selectedDeptTemplate.departmentId,
      departmentNameAr: selectedDeptTemplate.departmentNameAr,
      departmentCategoryAr: selectedDeptTemplate.departmentCategoryAr,
      auditDate,
      timestamp: now,
      compliancePercentage: complianceStats.percentage,
      totalItems: complianceStats.total,
      compliantCount: complianceStats.compliant,
      nonCompliantCount: complianceStats.nonCompliant,
      notApplicableCount: complianceStats.notApplicable,
      items: currentItems,
      capPlan: capPlanNotes || undefined,
      signatures: {
        deptSupervisor: {
          name: supervisorName || 'د/ نبيل عصار',
          title: supervisorTitle || 'رئيس هيئة التمريض',
          signed: supervisorSigned,
          signedAt: supervisorSigned ? (supervisorSignTime || new Date().toLocaleString('ar-EG')) : undefined
        },
        maintenanceRep: {
          name: maintenanceName || 'عارف الصلوي',
          title: maintenanceTitle || 'ممثل قسم الصيانة',
          signed: maintenanceSigned,
          signedAt: maintenanceSigned ? (maintenanceSignTime || new Date().toLocaleString('ar-EG')) : undefined
        },
        safetyHead: {
          name: safetyHeadName,
          title: safetyHeadTitle,
          signed: safetySigned,
          signedAt: safetySigned ? (safetySignTime || new Date().toLocaleString('ar-EG')) : undefined
        }
      },
      correctiveActions,
      savedLocally: true,
      synced: isOnlineNow,
      lastModified: now
    };

    // 1. Save to local IndexedDB store (department_audits)
    await offlineStorage.saveDepartmentAudit(auditRecord);

    // 2. Sync to Supabase monthly_dept_inspections table
    try {
      await supabase.from('monthly_dept_inspections').insert([{
        id: auditRecord.id,
        department_id: auditRecord.departmentId,
        department_name: auditRecord.departmentNameAr,
        audit_date: auditRecord.auditDate,
        compliance_percentage: auditRecord.compliancePercentage,
        total_items: auditRecord.totalItems,
        compliant_count: auditRecord.compliantCount,
        non_compliant_count: auditRecord.nonCompliantCount,
        not_applicable_count: auditRecord.notApplicableCount,
        items_data: auditRecord.items,
        cap_plan: capPlanNotes,
        corrective_actions: auditRecord.correctiveActions,
        safety_engineer_signature: {
          name: safetyHeadName,
          title: safetyHeadTitle,
          signed: safetySigned,
          signed_at: safetySigned ? (safetySignTime || new Date().toLocaleString('ar-EG')) : undefined
        },
        maintenance_rep_signature: {
          name: maintenanceName || 'عارف الصلوي',
          title: maintenanceTitle || 'ممثل الصيانة',
          signed: maintenanceSigned,
          signed_at: maintenanceSigned ? (maintenanceSignTime || new Date().toLocaleString('ar-EG')) : undefined
        },
        dept_supervisor_signature: {
          name: supervisorName || 'د/ نبيل عصار',
          title: supervisorTitle || 'رئيس هيئة التمريض',
          signed: supervisorSigned,
          signed_at: supervisorSigned ? (supervisorSignTime || new Date().toLocaleString('ar-EG')) : undefined
        },
        created_at: new Date(now).toISOString()
      }]);
    } catch (e) {
      console.warn('Supabase remote insert fallback:', e);
    }

    setSelectedAudit(auditRecord);
    setIsCreatingNew(false);

    if (onAuditSaved) {
      onAuditSaved(auditRecord);
    }

    if (onLogAudit) {
      onLogAudit(
        'DEPARTMENT_AUDIT_SAVED',
        'تدقيق ميداني شامل للقسم',
        `تم حفظ تدقيق ${auditRecord.departmentNameAr} بنسبة امتثال ${auditRecord.compliancePercentage}% (${auditRecord.nonCompliantCount} مخالفات).`
      );
    }

    // Trigger auditory and haptic feedback
    triggerSuccessFeedback();

    // Display required notification banner
    if (!isOnlineNow) {
      setSavedAlert({
        show: true,
        message: 'تم الحفظ محلياً بنجاح في IndexedDB وجدول department_audits • بانتظار الاتصال للرفع السحابي الفوري.',
        type: 'offline'
      });
    } else {
      setSavedAlert({
        show: true,
        message: 'تم الحفظ والمزامنة السحابية والمحلية بنجاح في جدول department_audits ومستودع المستشفى المركزي.',
        type: 'online'
      });
    }

    setTimeout(() => {
      setSavedAlert(null), 6000;
    });
  };

  // Trigger manual sync
  const handleTriggerManualSync = async () => {
    setIsSyncing(true);
    try {
      const res = await offlineStorage.forceSyncAllPendingRecords();
      triggerSuccessFeedback();
      setIsSyncing(false);
      setSavedAlert({
        show: true,
        message: res.message,
        type: 'online'
      });
    } catch {
      setIsSyncing(false);
      setSavedAlert({
        show: true,
        message: 'حدث خطأ أثناء محاولة المزامنة، يرجى إعادة المحاولة.',
        type: 'offline'
      });
    }
    setTimeout(() => setSavedAlert(null), 5000);
  };

  // Convert non-compliant items directly to Safety Violation Notice
  const handlePushToViolations = (item: AuditCheckItem) => {
    if (!onAddViolationNotice) return;
    const newViolation = {
      id: `AZAL-AUDIT-VIO-${Date.now().toString().slice(-4)}`,
      violationNumber: `AZAL-VIO-2026-${String(Math.floor(100 + Math.random() * 900))}`,
      department: selectedDeptTemplate.departmentNameAr,
      location: selectedDeptTemplate.floorLocation,
      recipientName: supervisorName || 'د/ نبيل عصار',
      recipientRole: supervisorTitle || 'رئيس هيئة التمريض',
      description: item.defectDescription || item.clauseText,
      dangerLevel: item.severity === 'critical' ? 'critical' : item.severity === 'high' ? 'high' : 'medium',
      correctiveActions: item.assignedAction || `تصحيح البند المعياري (${item.code}) فوراً.`,
      deadlineToFix: new Date(Date.now() + 48 * 60 * 60 * 1000).toISOString().split('T')[0],
      noticeDate: auditDate,
      issuedBy: 'رئيس قسم الأمن والسلامة: م/ نجيب غازي',
      supervisorSignature: 'مُعتمد إلكترونياً - رئيس قسم السلامة',
      status: 'pending',
      photoUrl: item.photoUrl
    };
    onAddViolationNotice(newViolation);
    setSavedAlert({
      show: true,
      message: `تم تحويل البند (${item.code}) بنجاح إلى إشعار مخالفة رسمي في سجل المخاطر وسيرسل إشعار WhatsApp للمشرف.`,
      type: 'online'
    });
    setTimeout(() => setSavedAlert(null), 5000);
  };

  // Filtered departments
  const filteredTemplates = useMemo(() => {
    return AUDIT_DEPARTMENTS.filter(d => {
      const matchSearch = d.departmentNameAr.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          d.departmentCategoryAr.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          d.codePrefix.toLowerCase().includes(searchTerm.toLowerCase());
      if (activeDepartmentFilter === 'all') return matchSearch;
      return matchSearch && d.departmentCategoryAr === activeDepartmentFilter;
    });
  }, [searchTerm, activeDepartmentFilter]);

  return (
    <div className="space-y-4 text-right" id="department-audit-main-container">
      {/* 1. Offline-First Live Alert Banner */}
      {savedAlert?.show && (
        <div 
          id="audit-save-alert"
          className={`p-4 rounded-2xl border text-sm font-bold flex items-center justify-between shadow-lg transition-all animate-in fade-in slide-in-from-top-3 ${
            savedAlert.type === 'offline' 
              ? 'bg-amber-950/90 border-amber-600 text-amber-200' 
              : 'bg-emerald-950/90 border-emerald-600 text-emerald-200'
          }`}
        >
          <div className="flex items-center gap-3">
            {savedAlert.type === 'offline' ? (
              <WifiOff className="w-5 h-5 text-amber-400 shrink-0" />
            ) : (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            )}
            <span>{savedAlert.message}</span>
          </div>
          <button 
            type="button"
            onClick={() => setSavedAlert(null)}
            className="text-xs px-2 py-1 bg-black/30 hover:bg-black/50 rounded-lg text-white"
          >
            إغلاق
          </button>
        </div>
      )}

      {/* 2. Top Header & Network Sync Bar */}
      <div className="bg-slate-900 border border-teal-800/60 rounded-2xl p-4 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-950 border border-teal-700 text-teal-400 shadow-sm">
            <ClipboardList className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-black text-slate-100">وحدة التفتيش والتدقيق الشهري للأقسام</h1>
              <span className="text-[10px] bg-teal-950 text-teal-300 px-2.5 py-0.5 rounded-full border border-teal-700 font-mono">
                CBAHI / JCI / FMS
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              مستشفى آزال النموذجي • نظام التفتيش الشهري الشامل Offline-First • التوقيع الثلاثي المعتمد
            </p>
          </div>
        </div>

        {/* Sync & Connectivity Status */}
        <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto justify-between md:justify-end">
          <div className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-bold border ${
            isOnline 
              ? 'bg-emerald-950/60 border-emerald-700 text-emerald-300' 
              : 'bg-amber-950/60 border-amber-700 text-amber-300'
          }`}>
            {isOnline ? (
              <>
                <Wifi className="w-4 h-4 text-emerald-400" />
                <span>متصل بالشبكة</span>
              </>
            ) : (
              <>
                <WifiOff className="w-4 h-4 text-amber-400" />
                <span>وضع عدم الاتصال (Offline)</span>
              </>
            )}
          </div>

          <button
            type="button"
            onClick={handleTriggerManualSync}
            disabled={isSyncing}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-teal-400' : ''}`} />
            <span>مزامنة الآن</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('print_preview')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-800 hover:bg-teal-700 text-white text-xs font-bold transition shadow-sm"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>معاينة الطباعة / PDF</span>
          </button>
        </div>
      </div>

      {/* 3. PRIMARY DEPARTMENT SELECTOR DROPDOWN (Requirement 1 & 2) */}
      <div className="bg-slate-900 border border-teal-700/70 rounded-2xl p-4 sm:p-5 shadow-xl space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-teal-400" />
            <div>
              <label htmlFor="department-select-dropdown" className="text-sm font-bold text-slate-100 block">
                اختر القسم المستهدف للتفتيش الشهري:
              </label>
              <span className="text-[11px] text-slate-400">
                يشمل الأقسام الطبية والخدمية والبنية التحتية المضافة حديثاً مع تحميل تلقائي للبنود
              </span>
            </div>
          </div>

          {isLoadingItems && (
            <div className="flex items-center gap-1.5 text-xs text-teal-400 bg-teal-950/60 px-3 py-1.5 rounded-xl border border-teal-800 animate-pulse">
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
              <span>جاري تحميل بنود القسم من قاعدة البيانات...</span>
            </div>
          )}
        </div>

        {/* Dropdown Menu (Requirement 1) */}
        <div className="relative">
          <select
            id="department-select-dropdown"
            value={selectedDeptTemplate.departmentId}
            onChange={(e) => handleDepartmentDropdownChange(e.target.value)}
            className="w-full bg-slate-950 border-2 border-teal-600/80 text-teal-100 font-bold text-sm sm:text-base rounded-2xl px-4 py-3 appearance-none focus:outline-none focus:border-teal-400 shadow-inner cursor-pointer"
          >
            <optgroup label="── الأقسام والبنية التحتية والخدمات ──" className="bg-slate-900 text-slate-300">
              <option value="LAUNDRY">المغسلة المركزية للمستشفى (LAUNDRY)</option>
              <option value="RADIOLOGY">قسم الأشعة والتصوير الطبي (RADIOLOGY)</option>
              <option value="CSSD">قسم التعقيم المركزي (CSSD)</option>
              <option value="PHARMACY">الصيدلية المركزية ومستودع الأدوية (PHARMACY)</option>
              <option value="ONCOLOGY">وحدة الأورام والعلاج الكيماوي (ONCOLOGY)</option>
              <option value="WASTE_STORE">غرفة تجميع النفايات الطبية الخطرة (WASTE_STORE)</option>
              <option value="GAS_MANIFOLD">محطة الغازات الطبية المركزية (GAS_MANIFOLD)</option>
              <option value="GENERATORS">غرف المولدات والمحولات الكهربائية (GENERATORS)</option>
              <option value="IT_SERVERS">غرفة السيرفرات وتقنية المعلومات IT (IT_SERVERS)</option>
            </optgroup>
            <optgroup label="── الأقسام السريرية والحرجة والضيافة ──" className="bg-slate-900 text-slate-300">
              <option value="INPATIENT">أقسام الرقود وتنويم المرضى (INPATIENT)</option>
              <option value="EMERGENCY">قسم الطوارئ والإسعاف (EMERGENCY)</option>
              <option value="OR">قسم العمليات الجراحية (OR)</option>
              <option value="ICU">وحدة العناية المركزة (ICU)</option>
              <option value="OBSTETRICS">قسم التوليد وأمراض النساء (OBSTETRICS)</option>
              <option value="CAFETERIA">كافتيريا وبوفية المستشفى (CAFETERIA)</option>
              <option value="LABORATORY">المختبرات المركزية وبنك الدم (LABORATORY)</option>
              <option value="RESTAURANT">المطعم والمطبخ بالدور السادس (RESTAURANT)</option>
              <option value="NICU">العناية المركزة لحديثي الولادة (NICU)</option>
              <option value="GENERAL_FMS">الاستمارة العامة لإدارة المرافق والسلامة (GENERAL_FMS)</option>
            </optgroup>
          </select>
          <div className="absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none text-teal-400">
            <ChevronDown className="w-5 h-5" />
          </div>
        </div>

        {/* Selected Department Location & Category Badge */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-slate-400">الموقع الميداني:</span>
            <span className="font-bold text-slate-200">{selectedDeptTemplate.floorLocation}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-slate-400">التصنيف:</span>
            <span className="px-2.5 py-0.5 rounded-full bg-teal-950 border border-teal-800 text-teal-300 font-bold text-[11px]">
              {selectedDeptTemplate.departmentCategoryAr}
            </span>
          </div>
        </div>
      </div>

      {/* 4. Automated Compliance Score Indicator (Requirement 3: احتساب فوري لنسبة الامتثال) */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-teal-950 border border-teal-800/80 rounded-2xl p-4 sm:p-5 shadow-xl">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          {/* Main Percentage Gauge */}
          <div className="md:col-span-4 flex items-center gap-4 border-b md:border-b-0 md:border-l border-slate-800 pb-3 md:pb-0 md:pl-4">
            <div className={`w-20 h-20 rounded-2xl border-2 flex flex-col items-center justify-center shrink-0 shadow-inner ${
              complianceStats.isHigh 
                ? 'bg-emerald-950/80 border-emerald-500 text-emerald-300' 
                : complianceStats.isMedium 
                ? 'bg-amber-950/80 border-amber-500 text-amber-300' 
                : 'bg-rose-950/80 border-rose-500 text-rose-300'
            }`}>
              <span className="text-2xl font-black font-mono leading-none">{complianceStats.percentage}%</span>
              <span className="text-[10px] mt-1 font-bold">نسبة الامتثال</span>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-slate-100">
                  {selectedDeptTemplate.departmentNameAr}
                </h3>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                الموقع: {selectedDeptTemplate.floorLocation}
              </p>
              <div className="mt-1 flex items-center gap-2">
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold border ${
                  complianceStats.isHigh 
                    ? 'bg-emerald-900/60 border-emerald-600 text-emerald-300' 
                    : complianceStats.isMedium 
                    ? 'bg-amber-900/60 border-amber-600 text-amber-300' 
                    : 'bg-rose-900/60 border-rose-600 text-rose-300'
                }`}>
                  {complianceStats.isHigh ? 'امتثال عالي ممتاز (معتمد)' : complianceStats.isMedium ? 'امتثال متوسط (إجراءات تصحيحية)' : 'حرج - غير مطابق للسلامة'}
                </span>
              </div>
            </div>
          </div>

          {/* Breakdown Badges */}
          <div className="md:col-span-5 grid grid-cols-4 gap-2 text-center">
            <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">إجمالي البنود</span>
              <strong className="text-base font-black text-slate-200 font-mono">{complianceStats.total}</strong>
            </div>
            <div className="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-800/80">
              <span className="text-[10px] text-emerald-400 block">مطابق ✔</span>
              <strong className="text-base font-black text-emerald-300 font-mono">{complianceStats.compliant}</strong>
            </div>
            <div className="p-2.5 rounded-xl bg-rose-950/40 border border-rose-800/80">
              <span className="text-[10px] text-rose-400 block">غير مطابق ✖</span>
              <strong className="text-base font-black text-rose-300 font-mono">{complianceStats.nonCompliant}</strong>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800">
              <span className="text-[10px] text-slate-400 block">غير منطبق -</span>
              <strong className="text-base font-black text-slate-400 font-mono">{complianceStats.notApplicable}</strong>
            </div>
          </div>

          {/* Quick Actions / Save Audit button (Requirement 5) */}
          <div className="md:col-span-3 flex flex-col gap-2">
            <button
              type="button"
              id="btn-save-department-audit"
              onClick={handleSaveAudit}
              className="w-full py-2.5 px-4 bg-teal-600 hover:bg-teal-500 text-white font-black rounded-xl text-xs shadow-lg transition flex items-center justify-center gap-2 active:scale-95 cursor-pointer"
            >
              <FileCheck className="w-4 h-4" />
              <span>حفظ الاستمارة (department_audits)</span>
            </button>

            <div className="flex items-center justify-between text-[11px] text-slate-400 px-1">
              <span>تاريخ التفتيش:</span>
              <input 
                type="date" 
                value={auditDate}
                onChange={(e) => setAuditDate(e.target.value)}
                className="bg-slate-950 border border-slate-700 rounded-lg px-2 py-0.5 text-[11px] text-slate-200"
              />
            </div>
          </div>
        </div>
      </div>

      {/* 5. Sub-Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveTab('audit_form')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap ${
            activeTab === 'audit_form'
              ? 'bg-teal-600 text-white shadow-md'
              : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>استمارة بنود التفتيش الشهري</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-black/30 font-mono">
            {currentItems.length}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('cap_plan')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap ${
            activeTab === 'cap_plan'
              ? 'bg-amber-600 text-white shadow-md'
              : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          <AlertTriangle className="w-4 h-4" />
          <span>خطة الإجراء التصحيحي (CAP)</span>
          {correctiveActions.length > 0 && (
            <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-rose-900 text-rose-200 font-mono">
              {correctiveActions.length}
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('audit_history')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap ${
            activeTab === 'audit_history'
              ? 'bg-teal-600 text-white shadow-md'
              : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          <ClipboardList className="w-4 h-4" />
          <span>سجل التفتيشات المحفوظة</span>
          <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-black/30 font-mono">
            {auditsList.length}
          </span>
        </button>
      </div>

      {/* 6. TAB CONTENT: 1. AUDIT FORM (Requirement 2, 3, 4) */}
      {activeTab === 'audit_form' && (
        <div className="space-y-4">
          {/* General Corrective Action Plan (CAP) Overarching Text Field (Requirement 4) */}
          <div className="bg-slate-900 border border-amber-900/60 rounded-2xl p-4 space-y-2">
            <div className="flex items-center justify-between">
              <label htmlFor="general-cap-plan-notes" className="text-xs font-bold text-amber-400 flex items-center gap-2">
                <FileText className="w-4 h-4" />
                <span>خطة الإجراء التصحيحي العامة للقسم (Corrective Action Plan - CAP Summary):</span>
              </label>
              <span className="text-[11px] text-slate-400">حقل مفتوح لتدوين الإجراءات والموجهات الإلزامية</span>
            </div>
            <textarea
              id="general-cap-plan-notes"
              rows={2}
              value={capPlanNotes}
              onChange={(e) => setCapPlanNotes(e.target.value)}
              placeholder="اكتب التوجيهات العامة وخطة الإجراءات التصحيحية المعتمدة لمعالجة ثغرات السلامة المرصودة في هذا القسم..."
              className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-500"
            />
          </div>

          {/* Checklist Items List */}
          <div className="space-y-3">
            <div className="flex items-center justify-between px-1">
              <h3 className="text-xs font-bold text-slate-300 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-teal-400" />
                <span>بنود التفتيش والتحقق المعيارية المحملة تلقائياً ({currentItems.length} بند):</span>
              </h3>

              <button
                type="button"
                onClick={handleAddCustomItem}
                className="flex items-center gap-1 text-xs text-teal-400 hover:text-teal-300 bg-slate-900 border border-teal-800/80 px-3 py-1.5 rounded-xl font-bold transition"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>إضافة بند فحص مخصص</span>
              </button>
            </div>

            {currentItems.map((item) => {
              const isNonCompliant = item.status === 'non_compliant';
              return (
                <div 
                  key={item.id}
                  className={`border rounded-2xl p-4 transition-all ${
                    isNonCompliant 
                      ? 'bg-rose-950/30 border-rose-800/80 shadow-md' 
                      : item.status === 'compliant'
                      ? 'bg-slate-900/90 border-slate-800'
                      : 'bg-slate-950/60 border-slate-800/60 opacity-80'
                  }`}
                >
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                    {/* Item Text & Standard */}
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded-md bg-slate-800 border border-slate-700 text-[10px] font-mono font-bold text-teal-300">
                          {item.code}
                        </span>
                        <span className="px-2 py-0.5 rounded-md bg-teal-950 border border-teal-800 text-[10px] font-mono text-teal-400">
                          {item.standardRef}
                        </span>
                        <span className="text-[11px] text-slate-400">
                          {item.category}
                        </span>
                      </div>
                      <p className="text-xs sm:text-sm font-semibold text-slate-100 leading-relaxed">
                        {item.clauseText}
                      </p>
                    </div>

                    {/* 3-State Radio Buttons as Requested: [مطابق ✔] [غير مطابق ✖] [غير منطبق -] */}
                    <div className="flex items-center gap-1.5 shrink-0 bg-slate-950 p-1 rounded-xl border border-slate-800">
                      {/* Compliant */}
                      <button
                        type="button"
                        onClick={() => handleItemStatusChange(item.id, 'compliant')}
                        className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                          item.status === 'compliant'
                            ? 'bg-emerald-600 text-white shadow-sm'
                            : 'text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>مطابق ✔</span>
                      </button>

                      {/* Non-Compliant */}
                      <button
                        type="button"
                        onClick={() => handleItemStatusChange(item.id, 'non_compliant')}
                        className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                          item.status === 'non_compliant'
                            ? 'bg-rose-600 text-white shadow-sm animate-pulse'
                            : 'text-slate-400 hover:text-rose-400'
                        }`}
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        <span>غير مطابق ✖</span>
                      </button>

                      {/* Not Applicable */}
                      <button
                        type="button"
                        onClick={() => handleItemStatusChange(item.id, 'not_applicable')}
                        className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                          item.status === 'not_applicable'
                            ? 'bg-slate-700 text-slate-200'
                            : 'text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        <MinusCircle className="w-3.5 h-3.5" />
                        <span>غير منطبق -</span>
                      </button>
                    </div>
                  </div>

                  {/* CONDITIONAL EXPANSION WHEN NON-COMPLIANT (Requirement 4: حقل لتوصيف الخلل وخطة CAP) */}
                  {isNonCompliant && (
                    <div className="mt-4 pt-4 border-t border-rose-900/60 bg-rose-950/40 p-3.5 rounded-xl space-y-3 animate-in fade-in slide-in-from-top-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-rose-300 flex items-center gap-1.5">
                          <AlertTriangle className="w-4 h-4 text-rose-400" />
                          <span>توصيف الخلل الميداني وخطة الإجراء التصحيحي (CAP):</span>
                        </span>
                        
                        <div className="flex items-center gap-2">
                          <span className="text-[11px] text-slate-300 font-bold">درجة الخطورة:</span>
                          <select
                            value={item.severity || 'high'}
                            onChange={(e) => handleItemFieldChange(item.id, 'severity', e.target.value)}
                            className="bg-slate-900 border border-rose-700 text-rose-200 text-xs rounded-lg px-2 py-1 font-bold"
                          >
                            <option value="low">منخفضة (Low)</option>
                            <option value="medium">متوسطة (Medium)</option>
                            <option value="high">عالية (High)</option>
                            <option value="critical">حرجة (Critical)</option>
                          </select>
                        </div>
                      </div>

                      {/* Defect Description Field (Requirement 4) */}
                      <div>
                        <label className="text-[11px] text-slate-300 block mb-1 font-bold">
                          توصيف الخلل والملاحظة الميدانية المرصودة:
                        </label>
                        <textarea
                          rows={2}
                          value={item.defectDescription || ''}
                          onChange={(e) => handleItemFieldChange(item.id, 'defectDescription', e.target.value)}
                          placeholder="اكتب التوصيف الدقيق للخلل أو العائق أو الملاحظة الميدانية..."
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-rose-500"
                        />
                      </div>

                      {/* Action Required / CAP Field (Requirement 4) */}
                      <div>
                        <label className="text-[11px] text-slate-300 block mb-1 font-bold">
                          خطة الإجراء التصحيحي الفوري المطلوب (Corrective Action Plan):
                        </label>
                        <input
                          type="text"
                          value={item.assignedAction || ''}
                          onChange={(e) => handleItemFieldChange(item.id, 'assignedAction', e.target.value)}
                          placeholder="مثال: تصحيح وضع التخزين فوراً واستبدال الصمام خلال 48 ساعة وإبلاغ رئيس القسم..."
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-rose-500"
                        />
                      </div>

                      {/* Image Capture & Fast Push to Violations */}
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
                        <div className="flex items-center gap-3">
                          <label className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold cursor-pointer transition">
                            <Camera className="w-4 h-4 text-rose-400" />
                            <span>التقاط صورة توثيق الخلل</span>
                            <input
                              type="file"
                              accept="image/*"
                              capture="environment"
                              className="hidden"
                              onChange={(e) => handlePhotoUpload(item.id, e)}
                            />
                          </label>

                          {item.photoUrl && (
                            <div className="flex items-center gap-2">
                              <img 
                                src={item.photoUrl} 
                                alt="معاينة الخلل" 
                                className="w-8 h-8 rounded-lg object-cover border border-rose-500"
                              />
                              <span className="text-[10px] text-emerald-400 font-bold">تم إرفاق الصورة</span>
                            </div>
                          )}
                        </div>

                        {onAddViolationNotice && (
                          <button
                            type="button"
                            onClick={() => handlePushToViolations(item)}
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-800 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition shadow-sm"
                          >
                            <AlertTriangle className="w-3.5 h-3.5" />
                            <span>تحويل رسمي لإشعار مخالفة وسجل المخاطر</span>
                          </button>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* TRIPLE SIGNATURE WORKFLOW (Requirement 6: التوقيع الثلاثي) */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4 mt-6">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <UserCheck className="w-5 h-5 text-teal-400" />
                <h3 className="text-sm font-bold text-slate-100">
                  منظومة التوقيع والاعتماد الرقمي الثلاثي (Triple Signature)
                </h3>
              </div>
              <span className="text-[11px] text-slate-400 font-mono">
                رئيس السلامة • ممثل الصيانة • مشرف القسم
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* 1. Department Supervisor */}
              <div className={`p-4 rounded-2xl border space-y-3 transition ${
                supervisorSigned ? 'bg-emerald-950/30 border-emerald-700' : 'bg-slate-950 border-slate-800'
              }`}>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-300">1. مشرف القسم / رئيس التمريض</span>
                  {supervisorSigned && (
                    <span className="text-[10px] bg-emerald-900 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-600 font-bold">
                      مُوقّع ✔
                    </span>
                  )}
                </div>

                <div className="space-y-2">
                  <input
                    type="text"
                    value={supervisorName}
                    onChange={(e) => setSupervisorName(e.target.value)}
                    placeholder="اسم مشرف القسم / رئيس التمريض..."
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-teal-500"
                  />
                  <input
                    type="text"
                    value={supervisorTitle}
                    onChange={(e) => setSupervisorTitle(e.target.value)}
                    placeholder="الصفة / المسمى الوظيفي..."
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-slate-400"
                  />
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setSupervisorSigned(true);
                    setSupervisorSignTime(new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }));
                  }}
                  className={`w-full py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                    supervisorSigned
                      ? 'bg-emerald-800/60 text-emerald-200 border border-emerald-600'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                  }`}
                >
                  <UserCheck className="w-3.5 h-3.5" />
                  <span>{supervisorSigned ? `موقع إلكترونياً (${supervisorSignTime})` : 'توقيع واعتماد مشرف القسم'}</span>
                </button>
              </div>

              {/* 2. Maintenance Representative: عارف الصلوي */}
              <div className={`p-4 rounded-2xl border space-y-3 transition ${
                maintenanceSigned ? 'bg-emerald-950/30 border-emerald-700' : 'bg-slate-950 border-slate-800'
              }`}>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-300">2. ممثل الصيانة</span>
                  {maintenanceSigned && (
                    <span className="text-[10px] bg-emerald-900 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-600 font-bold">
                      مُوقّع ✔
                    </span>
                  )}
                </div>

                <div className="space-y-2">
                  <input
                    type="text"
                    value={maintenanceName}
                    onChange={(e) => setMaintenanceName(e.target.value)}
                    placeholder="اسم ممثل الصيانة..."
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-teal-500"
                  />
                  <input
                    type="text"
                    value={maintenanceTitle}
                    onChange={(e) => setMaintenanceTitle(e.target.value)}
                    placeholder="الصفة / المسمى..."
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-slate-400"
                  />
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setMaintenanceSigned(true);
                    setMaintenanceSignTime(new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }));
                  }}
                  className={`w-full py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                    maintenanceSigned
                      ? 'bg-emerald-800/60 text-emerald-200 border border-emerald-600'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                  }`}
                >
                  <UserCheck className="w-3.5 h-3.5" />
                  <span>{maintenanceSigned ? `موقع إلكترونياً (${maintenanceSignTime})` : 'توقيع واعتماد ممثل الصيانة'}</span>
                </button>
              </div>

              {/* 3. Safety Head (Strictly Fixed: م/ نجيب غازي) */}
              <div className="p-4 rounded-2xl border bg-teal-950/40 border-teal-700 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-teal-300">3. رئيس قسم الأمن والسلامة</span>
                  <span className="text-[10px] bg-teal-900 text-teal-300 px-2 py-0.5 rounded-full border border-teal-600 font-bold">
                    معتمد رسمياً ✔
                  </span>
                </div>

                <div className="space-y-1 text-xs">
                  <div className="text-teal-300 font-bold text-sm">
                    {safetyHeadName}
                  </div>
                  <div className="text-slate-400 text-xs">
                    {safetyHeadTitle}
                  </div>
                  <div className="text-[11px] text-slate-400 font-mono">
                    ختم الاعتماد الرقمي • AZAL-OSH-LEAD
                  </div>
                </div>

                <div className="p-2.5 rounded-xl bg-teal-900/60 border border-teal-600/80 text-center text-xs font-bold text-teal-200">
                  مُعتمد وموقع رقمياً ({safetySignTime})
                </div>
              </div>
            </div>

            {/* Bottom Save bar */}
            <div className="pt-3 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="text-xs text-slate-400">
                سيتم حفظ التفتيش والتوقيعات الثلاثية في جدول department_audits وتوليد الخطة التصحيحية تلقائياً.
              </div>
              <button
                type="button"
                onClick={handleSaveAudit}
                className="w-full sm:w-auto px-6 py-2.5 bg-teal-600 hover:bg-teal-500 text-white font-bold rounded-xl text-xs shadow-lg transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <FileCheck className="w-4 h-4" />
                <span>حفظ واعتماد التقرير الميداني للقسم</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 7. TAB CONTENT: 2. CORRECTIVE ACTION PLAN (CAP) */}
      {activeTab === 'cap_plan' && (
        <div className="space-y-4">
          <div className="bg-slate-900 border border-amber-800/60 rounded-2xl p-4 sm:p-5 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-bold text-amber-400 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  <span>الخطة التصحيحية للملاحظات غير المطابقة (Corrective Action Plan - CAP)</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  تم تحويل بنود عدم المطابقة تلقائياً إلى مهام تصحيحية مرتبطة بالأقسام المعنية
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-300 font-bold">
                  إجمالي الإجراءات المطلوبة: <strong className="text-amber-400 font-mono text-sm">{correctiveActions.length}</strong>
                </span>
              </div>
            </div>

            {/* General Plan summary notes */}
            {capPlanNotes && (
              <div className="bg-slate-950 p-3.5 rounded-xl border border-amber-800/40 text-xs space-y-1">
                <span className="text-amber-300 font-bold block">ملاحظات وخطة التوجيه العام:</span>
                <p className="text-slate-200">{capPlanNotes}</p>
              </div>
            )}

            {correctiveActions.length === 0 ? (
              <div className="py-12 text-center text-slate-400 space-y-2">
                <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
                <p className="text-sm font-bold text-emerald-300">
                  لا توجد أي بنود غير مطابقة في هذا التدقيق (نسبة الامتثال 100%)
                </p>
                <p className="text-xs text-slate-500">
                  كافة المعايير مفحوصة ومطابقة لاشتراطات CBAHI و JCI بالكامل.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-950 text-slate-300 border-b border-slate-800">
                      <th className="p-3">رمز البند</th>
                      <th className="p-3">الملاحظة الميدانية / الخلل</th>
                      <th className="p-3">الإجراء التصحيحي الواجب</th>
                      <th className="p-3">الجهة المكلفة</th>
                      <th className="p-3">المهلة القصوى</th>
                      <th className="p-3">درجة الخطورة</th>
                      <th className="p-3">حالة الإجراء</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {correctiveActions.map((cap) => (
                      <tr key={cap.id} className="hover:bg-slate-800/40">
                        <td className="p-3 font-mono font-bold text-teal-400">{cap.clauseCode}</td>
                        <td className="p-3 text-slate-200 max-w-xs">{cap.defectDescription}</td>
                        <td className="p-3 text-amber-300 max-w-xs">{cap.actionRequired}</td>
                        <td className="p-3 text-slate-300">{cap.assignedDepartment}</td>
                        <td className="p-3 font-mono text-slate-400">{cap.targetDeadline}</td>
                        <td className="p-3">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            cap.riskLevel === 'critical'
                              ? 'bg-rose-950 text-rose-300 border border-rose-700'
                              : cap.riskLevel === 'high'
                              ? 'bg-orange-950 text-orange-300 border border-orange-700'
                              : 'bg-amber-950 text-amber-300 border border-amber-700'
                          }`}>
                            {cap.riskLevel === 'critical' ? 'حرج جداً' : cap.riskLevel === 'high' ? 'عالي الخطورة' : 'متوسط'}
                          </span>
                        </td>
                        <td className="p-3">
                          <span className="px-2 py-0.5 rounded-md bg-amber-950 border border-amber-700 text-amber-300 text-[10px] font-bold">
                            قيد المتابعة والإلزام
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 8. TAB CONTENT: 3. AUDIT HISTORY */}
      {activeTab === 'audit_history' && (
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xl space-y-3">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <ClipboardList className="w-4 h-4 text-teal-400" />
              <span>سجلات التفتيش الشهري المحفوظة في قاعدة البيانات (IndexedDB / department_audits):</span>
            </h3>

            {auditsList.length === 0 ? (
              <div className="py-12 text-center text-slate-400">
                لا توجد سجلات تفتيش محفوظة حتى الآن.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {auditsList.map((audit) => (
                  <div
                    key={audit.id}
                    className="p-4 rounded-2xl border bg-slate-950 border-slate-800 hover:border-teal-700 transition flex flex-col justify-between space-y-3"
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs font-bold text-slate-100">{audit.departmentNameAr}</h4>
                          <span className="text-[10px] font-mono text-slate-400">{audit.auditDate}</span>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-0.5">{audit.departmentCategoryAr}</p>
                      </div>

                      <div className={`px-2.5 py-1 rounded-xl font-mono text-xs font-black border ${
                        audit.compliancePercentage >= 85
                          ? 'bg-emerald-950 border-emerald-600 text-emerald-300'
                          : 'bg-amber-950 border-amber-600 text-amber-300'
                      }`}>
                        {audit.compliancePercentage}%
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-xs text-slate-400 border-t border-slate-850 pt-2">
                      <div className="flex items-center gap-2 text-[11px]">
                        <span className="text-emerald-400">مطابق: {audit.compliantCount}</span>
                        <span>•</span>
                        <span className="text-rose-400">غير مطابق: {audit.nonCompliantCount}</span>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className={`text-[10px] px-2 py-0.5 rounded-full border ${
                          audit.synced 
                            ? 'bg-emerald-950 border-emerald-800 text-emerald-400' 
                            : 'bg-amber-950 border-amber-800 text-amber-400'
                        }`}>
                          {audit.synced ? 'متزامن سحابياً' : 'محفوظ محلياً'}
                        </span>

                        <button
                          type="button"
                          onClick={() => {
                            loadAuditIntoState(audit);
                            setActiveTab('audit_form');
                          }}
                          className="px-2.5 py-1 rounded-lg bg-teal-900/60 hover:bg-teal-800 text-teal-200 text-[11px] font-bold transition cursor-pointer"
                        >
                          فتح وتعديل
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* 9. TAB CONTENT: 4. PRINT / PDF OFFICIAL EXPORT VIEW (Requirement 6) */}
      {activeTab === 'print_preview' && (
        <div className="space-y-4">
          <div className="no-print bg-slate-900 border border-teal-800 p-3 rounded-xl flex items-center justify-between">
            <span className="text-xs text-slate-300">
              تقرير التفتيش الشهري المعتمد جاهز للطباعة المباشرة والتصدير بصيغة PDF مع التوقيع الثلاثي.
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  printExistingElementById('department-audit-print-document', {
                    title: `استمارة التفتيش الشهري - ${selectedDeptTemplate.departmentNameAr}`,
                    department: selectedDeptTemplate.departmentNameAr,
                    date: auditDate,
                    refNumber: `AZAL-MDI-${selectedDeptTemplate.departmentId.toUpperCase()}`
                  });
                }}
                className="px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold rounded-xl transition flex items-center gap-1.5 shadow-md cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>طباعة النموذج الرسمي وتصدير PDF</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('audit_form')}
                className="px-3 py-2 bg-slate-800 text-slate-300 text-xs rounded-xl font-bold cursor-pointer"
              >
                العودة للاستمارة
              </button>
            </div>
          </div>

          {/* Printable Official Document */}
          <div id="department-audit-print-document" className="bg-white text-gray-950 p-6 sm:p-8 rounded-2xl shadow-2xl space-y-6 print:m-0 print:p-0 print:shadow-none print:border-none border border-gray-300 text-right">
            {/* Official Header */}
            <div className="border-b-2 border-teal-900 pb-4 flex items-center justify-between">
              <div>
                <h2 className="text-base font-black text-teal-900">مستشفى آزال النموذجي - صنعاء</h2>
                <h3 className="text-xs font-bold text-gray-700">إدارة الأمن والسلامة وإدارة المرافق (FMS)</h3>
                <p className="text-[11px] text-gray-600">استمارة التفتيش الشهري والتدقيق الميداني الشامل للأقسام (معايير CBAHI / JCI)</p>
              </div>

              <div className="text-left font-mono text-xs">
                <div className="font-bold text-teal-900">AZAL-MDI-{selectedDeptTemplate.departmentId}</div>
                <div className="text-gray-600">التاريخ: {auditDate}</div>
                <div className="text-gray-600">القسم: {selectedDeptTemplate.departmentNameAr}</div>
              </div>
            </div>

            {/* Score & Compliance Header */}
            <div className="bg-gray-100 p-3 rounded-xl flex items-center justify-between text-xs border border-gray-300">
              <div>
                <span>الموقع الميداني: <strong>{selectedDeptTemplate.floorLocation}</strong></span>
                <span className="mx-3">|</span>
                <span>التصنيف: <strong>{selectedDeptTemplate.departmentCategoryAr}</strong></span>
              </div>
              <div className="text-sm font-black text-teal-900">
                نسبة الامتثال المحتسبة: {complianceStats.percentage}% ({complianceStats.compliant} مطابق من {complianceStats.total} بنود)
              </div>
            </div>

            {/* General Plan summary notes if present */}
            {capPlanNotes && (
              <div className="bg-amber-50 border border-amber-300 p-3 rounded-lg text-xs space-y-1">
                <span className="font-bold text-amber-900">خطة الإجراء التصحيحي العامة المعتمدة (CAP):</span>
                <p className="text-gray-800">{capPlanNotes}</p>
              </div>
            )}

            {/* Items Table */}
            <table className="w-full text-right text-xs border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100 text-gray-800 border-b border-gray-300">
                  <th className="border border-gray-300 p-2 w-16">الرمز</th>
                  <th className="border border-gray-300 p-2 w-20">المعيار</th>
                  <th className="border border-gray-300 p-2">نص البند والاشتراط المعياري</th>
                  <th className="border border-gray-300 p-2 w-24 text-center">النتيجة</th>
                  <th className="border border-gray-300 p-2">توصيف الخلل والإجراء التصحيحي (CAP)</th>
                </tr>
              </thead>
              <tbody>
                {currentItems.map((it) => (
                  <tr key={it.id} className="border-b border-gray-300">
                    <td className="border border-gray-300 p-2 font-mono font-bold">{it.code}</td>
                    <td className="border border-gray-300 p-2 font-mono">{it.standardRef}</td>
                    <td className="border border-gray-300 p-2">{it.clauseText}</td>
                    <td className="border border-gray-300 p-2 text-center font-bold">
                      {it.status === 'compliant' ? 'مطابق ✔' : it.status === 'non_compliant' ? 'غير مطابق ✖' : 'غير منطبق -'}
                    </td>
                    <td className="border border-gray-300 p-2 text-gray-700">
                      {it.status === 'non_compliant' 
                        ? `${it.defectDescription || 'لوحظ عدم الامتثال'} | الإجراء: ${it.assignedAction || 'معالجة فورية'}`
                        : 'مطابق للاشتراطات الفنية والسلامة.'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* Triple Signature Block (Requirement 6) */}
            <div className="pt-4">
              <h4 className="text-xs font-bold text-teal-900 mb-2 border-b border-gray-300 pb-1">
                التوقيع الثلاثي المعتمد للتفتيش الميداني:
              </h4>
              <div className="grid grid-cols-3 gap-3 text-xs text-center">
                {/* 1. Safety Head */}
                <div className="border border-teal-800 p-3 rounded-lg bg-teal-50">
                  <span className="font-bold text-teal-900 block text-[11px]">رئيس قسم الأمن والسلامة:</span>
                  <p className="font-bold text-teal-950 mt-1">{safetyHeadName}</p>
                  <p className="text-[9px] text-teal-700 font-mono mt-1">
                    {safetySigned ? `مُعتمد رسمياً (${safetySignTime})` : 'مُعتمد'}
                  </p>
                </div>

                {/* 2. Maintenance Rep */}
                <div className="border border-gray-300 p-3 rounded-lg bg-gray-50">
                  <span className="font-bold text-gray-800 block text-[11px]">ممثل قسم الصيانة:</span>
                  <p className="font-bold text-gray-900 mt-1">{maintenanceName || 'عارف الصلوي'}</p>
                  <p className="text-[9px] text-gray-500 font-mono mt-1">
                    {maintenanceSigned ? `موقع إلكترونياً (${maintenanceSignTime})` : 'التوقيع: معتمد'}
                  </p>
                </div>

                {/* 3. Department Supervisor */}
                <div className="border border-gray-300 p-3 rounded-lg bg-gray-50">
                  <span className="font-bold text-gray-800 block text-[11px]">مشرف القسم / هيئة التمريض:</span>
                  <p className="font-bold text-gray-900 mt-1">{supervisorName || 'د/ نبيل عصار'}</p>
                  <p className="text-[9px] text-gray-500 font-mono mt-1">
                    {supervisorSigned ? `موقع إلكترونياً (${supervisorSignTime})` : 'التوقيع: معتمد'}
                  </p>
                </div>
              </div>
            </div>

            {/* Official Hospital Leadership Sign-off */}
            <div className="grid grid-cols-3 gap-3 pt-3 border-t border-gray-300 text-xs text-center">
              <div className="border border-gray-200 p-2 rounded-lg bg-gray-50">
                <span className="font-bold text-teal-800 block text-[10px]">منسق الجودة والاعتماد:</span>
                <p className="font-bold text-gray-900 mt-0.5">د/ علي الظبيبي</p>
                <p className="text-[9px] text-teal-700 font-mono">CBAHI Coordinator</p>
              </div>

              <div className="border border-gray-200 p-2 rounded-lg bg-gray-50">
                <span className="font-bold text-teal-800 block text-[10px]">المدير الطبي:</span>
                <p className="font-bold text-gray-900 mt-0.5">د/ أحمد الأهدل</p>
                <p className="text-[9px] text-teal-700 font-mono">Medical Director</p>
              </div>

              <div className="border border-gray-200 p-2 rounded-lg bg-gray-50">
                <span className="font-bold text-teal-900 block text-[10px]">مدير عام المستشفى:</span>
                <p className="font-black text-teal-950 mt-0.5">د/ محمد السراجي</p>
                <p className="text-[9px] text-teal-800 font-mono">Hospital General Director</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
