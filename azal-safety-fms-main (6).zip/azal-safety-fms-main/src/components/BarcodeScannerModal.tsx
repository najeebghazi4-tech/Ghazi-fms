import React, { useState, useEffect, useRef } from 'react';
import { X, QrCode, Camera, CheckCircle2, AlertCircle, Scan, Sparkles } from 'lucide-react';
import { ISBARData } from '../types';

interface BarcodeScannerModalProps {
  patients: ISBARData[];
  onClose: () => void;
  onPatientFound: (patient: ISBARData) => void;
}

export const BarcodeScannerModal: React.FC<BarcodeScannerModalProps> = ({
  patients,
  onClose,
  onPatientFound,
}) => {
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState('');
  const [manualCode, setManualCode] = useState('');
  const [scannedSuccess, setScannedSuccess] = useState<ISBARData | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    let stream: MediaStream | null = null;
    const startCamera = async () => {
      try {
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
          stream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: 'environment' },
          });
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
            videoRef.current.play();
            setCameraActive(true);
          }
        }
      } catch (err) {
        setCameraError('تعذر الوصول للكاميرا (قد يتطلب أذونات في المتصفح أو بيئة آمنة HTTPS). يمكنك استخدام المسح السريع أدناه.');
      }
    };

    startCamera();

    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  const triggerBeepAndVibrate = () => {
    if (typeof window !== 'undefined' && window.navigator && window.navigator.vibrate) {
      try {
        window.navigator.vibrate([100, 30, 100]);
      } catch (e) {}
    }
  };

  const handleSelectPatient = (patient: ISBARData) => {
    triggerBeepAndVibrate();
    setScannedSuccess(patient);
    setTimeout(() => {
      onPatientFound(patient);
      onClose();
    }, 800);
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualCode.trim()) return;
    const found = patients.find(
      (p) =>
        p.mrn.toLowerCase().includes(manualCode.trim().toLowerCase()) ||
        p.bedNumber.toLowerCase().includes(manualCode.trim().toLowerCase()) ||
        p.fullName.includes(manualCode.trim())
    );
    if (found) {
      handleSelectPatient(found);
    } else {
      setCameraError('لم يتم العثور على مريض بهذا الرقم أو السرير');
    }
  };

  return (
    <div id="barcode-scanner-modal" className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 text-right">
      <div className="bg-slate-900 border border-teal-600/60 rounded-3xl w-full max-w-md overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-teal-950 border border-teal-800 text-teal-400">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100">ماسح باركود سوار المريض والسرير</h3>
              <p className="text-[11px] text-slate-400">تحقق فوري بجانب السرير (Bedside Barcode Verification)</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-100"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 space-y-4">
          {/* Camera Viewfinder / Simulation Box */}
          <div className="relative w-full h-52 bg-slate-950 rounded-2xl border-2 border-teal-500/40 overflow-hidden flex items-center justify-center">
            {cameraActive ? (
              <video
                ref={videoRef}
                className="w-full h-full object-cover"
                playsInline
                muted
              />
            ) : (
              <div className="flex flex-col items-center justify-center text-center p-4">
                <Camera className="w-10 h-10 text-teal-500/60 mb-2 animate-pulse" />
                <span className="text-xs font-semibold text-slate-300">
                  كاميرا الماسح الضوئي لأجهزة الأندرويد
                </span>
                <span className="text-[11px] text-slate-500 mt-1 max-w-xs">
                  وجّه الكاميرا نحو باركود سوار المعصم أو اضغط على أحد الأسرّة بالأسفل
                </span>
              </div>
            )}

            {/* Viewfinder Laser Line Animation */}
            <div className="absolute inset-x-8 top-1/2 -translate-y-1/2 h-0.5 bg-rose-500 shadow-[0_0_12px_#ef4444] animate-pulse" />

            {/* Corner Target Brackets */}
            <div className="absolute top-4 left-4 w-6 h-6 border-t-2 border-l-2 border-teal-400 rounded-tl-lg" />
            <div className="absolute top-4 right-4 w-6 h-6 border-t-2 border-r-2 border-teal-400 rounded-tr-lg" />
            <div className="absolute bottom-4 left-4 w-6 h-6 border-b-2 border-l-2 border-teal-400 rounded-bl-lg" />
            <div className="absolute bottom-4 right-4 w-6 h-6 border-b-2 border-r-2 border-teal-400 rounded-br-lg" />

            {/* Success Overlay */}
            {scannedSuccess && (
              <div className="absolute inset-0 bg-emerald-950/90 flex flex-col items-center justify-center text-emerald-300 animate-fade-in z-20">
                <CheckCircle2 className="w-12 h-12 mb-2" />
                <span className="text-sm font-bold">تم التعرف على المريض بنجاح!</span>
                <span className="text-xs text-emerald-200 mt-0.5">{scannedSuccess.fullName}</span>
              </div>
            )}
          </div>

          {cameraError && (
            <div className="p-2.5 rounded-xl bg-amber-950/40 border border-amber-800/60 text-amber-300 text-[11px] flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{cameraError}</span>
            </div>
          )}

          {/* Quick Bedside QR / Barcode Simulator Buttons */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-300 block flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-teal-400" />
              <span>أسرّة المرضى المتاحة للمسح السريع المباشر:</span>
            </span>

            <div className="grid grid-cols-2 gap-2">
              {patients.map((p) => (
                <button
                  key={p.patientId}
                  type="button"
                  onClick={() => handleSelectPatient(p)}
                  className="p-2.5 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-right transition-all flex items-center justify-between group active:scale-95"
                >
                  <div className="truncate">
                    <span className="block text-xs font-bold text-slate-200 group-hover:text-teal-300 truncate">
                      {p.bedNumber}
                    </span>
                    <span className="block text-[11px] text-slate-400 truncate">
                      {p.fullName}
                    </span>
                    <span className="block text-[10px] text-teal-400/80 font-mono">
                      {p.mrn}
                    </span>
                  </div>
                  <Scan className="w-4 h-4 text-teal-500/70 group-hover:text-teal-400 shrink-0" />
                </button>
              ))}
            </div>
          </div>

          {/* Manual MRN search input */}
          <form onSubmit={handleManualSubmit} className="pt-2 border-t border-slate-800 flex gap-2">
            <input
              type="text"
              placeholder="إدخال رقم الملف MRN أو السرير يدوياً..."
              value={manualCode}
              onChange={(e) => setManualCode(e.target.value)}
              className="flex-1 bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-slate-100 placeholder-slate-500 font-mono"
            />
            <button
              type="submit"
              className="px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded-xl text-xs font-bold transition"
            >
              بحث
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
