import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { 
  X, 
  Printer, 
  CheckSquare, 
  Square, 
  Sliders, 
  Sparkles, 
  Download,
  Filter,
  CheckCircle2,
  Building2
} from 'lucide-react';
import { PpmAsset, PPM_DEPARTMENTS, PpmDepartmentCategory } from '../data/azalPpmAssetsData';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';

interface BarcodeA4PrintModalProps {
  assets: PpmAsset[];
  initialCategory?: PpmDepartmentCategory | 'all';
  onClose: () => void;
}

export const BarcodeA4PrintModal: React.FC<BarcodeA4PrintModalProps> = ({
  assets,
  initialCategory = 'all',
  onClose
}) => {
  const [selectedDept, setSelectedDept] = useState<PpmDepartmentCategory | 'all'>(initialCategory);
  const [selectedAssetIds, setSelectedAssetIds] = useState<string[]>([]);
  const [qrCodeDataUrls, setQrCodeDataUrls] = useState<Record<string, string>>({});
  const [gridColumns, setGridColumns] = useState<2 | 3>(2);
  const [isGeneratingQr, setIsGeneratingQr] = useState(true);

  // Filter assets based on department
  const filteredAssets = assets.filter((a) => {
    if (selectedDept === 'all') return true;
    return a.category === selectedDept;
  });

  // Select all filtered by default
  useEffect(() => {
    setSelectedAssetIds(filteredAssets.map((a) => a.id));
  }, [selectedDept]);

  // Generate high-resolution QR codes for all filtered assets
  useEffect(() => {
    let isCancelled = false;
    setIsGeneratingQr(true);

    async function generateAll() {
      const urls: Record<string, string> = {};
      for (const asset of filteredAssets) {
        try {
          // QR code payload contains the clean asset tag (e.g. AZ-GEN-01)
          // or standard asset URL that resolves in the portal
          const payload = `${asset.asset_tag}`;
          const url = await QRCode.toDataURL(payload, {
            width: 260,
            margin: 1,
            color: {
              dark: '#0f172a',
              light: '#ffffff'
            },
            errorCorrectionLevel: 'H'
          });
          urls[asset.id] = url;
        } catch (e) {
          console.error('QR Gen error:', e);
        }
      }
      if (!isCancelled) {
        setQrCodeDataUrls(urls);
        setIsGeneratingQr(false);
      }
    }

    generateAll();

    return () => {
      isCancelled = true;
    };
  }, [filteredAssets]);

  const toggleSelectAsset = (id: string) => {
    setSelectedAssetIds((prev) => 
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleSelectAll = () => {
    if (selectedAssetIds.length === filteredAssets.length) {
      setSelectedAssetIds([]);
    } else {
      setSelectedAssetIds(filteredAssets.map((a) => a.id));
    }
  };

  const handlePrint = () => {
    triggerSuccessFeedback();
    window.print();
  };

  const selectedList = filteredAssets.filter((a) => selectedAssetIds.includes(a.id));

  return (
    <div 
      id="barcode-a4-print-modal"
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 text-right overflow-y-auto"
    >
      <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-5xl overflow-hidden shadow-2xl flex flex-col max-h-[94vh] animate-in fade-in zoom-in-95">
        
        {/* Modal Controls Header (Hidden on Print) */}
        <div className="no-print bg-slate-950 p-4 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <Printer className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-white font-extrabold text-base sm:text-lg">
                طباعة ملصقات الباركود والـ QR للأصول (A4 Labels Sheet)
              </h3>
              <p className="text-xs text-slate-400">
                شبكة ملصقات هندسية معتمدة لمستشفى آزال النموذجي جاهزة للطباعة واللصق المباشر
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              disabled={selectedList.length === 0 || isGeneratingQr}
              className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs sm:text-sm font-bold px-4 py-2.5 rounded-xl shadow-lg shadow-emerald-900/30 flex items-center gap-2 transition-transform active:scale-95"
            >
              <Printer className="w-4 h-4" />
              <span>طباعة الملصقات فوراً ({selectedList.length})</span>
            </button>

            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 p-2 rounded-xl transition-colors"
              title="إغلاق"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filter & Options Bar (Hidden on Print) */}
        <div className="no-print bg-slate-900/90 border-b border-slate-800 p-3 sm:p-4 flex flex-wrap items-center justify-between gap-3 text-xs">
          
          {/* Department Filter */}
          <div className="flex items-center gap-2 overflow-x-auto max-w-full pb-1">
            <button
              onClick={() => setSelectedDept('all')}
              className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-colors ${
                selectedDept === 'all'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              كافة الأقسام ({assets.length})
            </button>
            {PPM_DEPARTMENTS.map((dept) => {
              const count = assets.filter((a) => a.category === dept.id).length;
              return (
                <button
                  key={dept.id}
                  onClick={() => setSelectedDept(dept.id)}
                  className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                    selectedDept === dept.id
                      ? 'bg-emerald-600 text-white'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  <span>{dept.nameAr}</span>
                  <span className="text-[10px] bg-black/30 px-1.5 py-0.2 rounded-full font-mono">
                    {count}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Grid Layout & Select All */}
          <div className="flex items-center gap-3">
            <button
              onClick={handleSelectAll}
              className="text-slate-300 hover:text-white flex items-center gap-1.5 font-bold bg-slate-800 px-3 py-1.5 rounded-xl"
            >
              {selectedAssetIds.length === filteredAssets.length ? (
                <CheckSquare className="w-4 h-4 text-emerald-400" />
              ) : (
                <Square className="w-4 h-4 text-slate-400" />
              )}
              <span>تحديد الكل ({filteredAssets.length})</span>
            </button>

            <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-xl border border-slate-700">
              <span className="text-[11px] text-slate-400 px-2">تخطيط الأعمدة:</span>
              <button
                onClick={() => setGridColumns(2)}
                className={`px-2.5 py-1 rounded-lg font-bold ${
                  gridColumns === 2 ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                عمودين (2x)
              </button>
              <button
                onClick={() => setGridColumns(3)}
                className={`px-2.5 py-1 rounded-lg font-bold ${
                  gridColumns === 3 ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                3 أعمدة (3x)
              </button>
            </div>
          </div>
        </div>

        {/* Printable Labels Canvas */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-950/50 print:bg-white print:p-0 print:overflow-visible">
          {isGeneratingQr ? (
            <div className="flex flex-col items-center justify-center py-16 text-slate-400">
              <Sparkles className="w-8 h-8 text-emerald-400 animate-spin mb-3" />
              <p className="text-sm font-bold">جاري توليد باركودات الأصول عالية الدقة...</p>
            </div>
          ) : selectedList.length === 0 ? (
            <div className="text-center py-16 text-slate-500 text-sm">
              لم يتم اختيار أي جهاز للطباعة. يرجى تحديد الأجهزة من القائمة بالأعلى.
            </div>
          ) : (
            <div className={`grid gap-4 print:gap-3 ${gridColumns === 2 ? 'grid-cols-1 sm:grid-cols-2' : 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3'}`}>
              {selectedList.map((asset) => (
                <div
                  key={asset.id}
                  className="bg-white text-slate-900 border-2 border-slate-800 rounded-2xl p-3.5 shadow-md print:shadow-none print:border-black flex flex-col justify-between relative page-break-inside-avoid break-inside-avoid"
                  style={{ minHeight: '180px' }}
                >
                  {/* Cutting Guides Corner Marks */}
                  <div className="absolute top-1 right-1 w-2.5 h-2.5 border-t-2 border-r-2 border-slate-400 pointer-events-none"></div>
                  <div className="absolute top-1 left-1 w-2.5 h-2.5 border-t-2 border-l-2 border-slate-400 pointer-events-none"></div>
                  <div className="absolute bottom-1 right-1 w-2.5 h-2.5 border-b-2 border-r-2 border-slate-400 pointer-events-none"></div>
                  <div className="absolute bottom-1 left-1 w-2.5 h-2.5 border-b-2 border-l-2 border-slate-400 pointer-events-none"></div>

                  {/* Top Hospital Branding Header */}
                  <div className="flex items-center justify-between border-b-2 border-emerald-600 pb-1.5 mb-2">
                    <div className="text-right leading-tight">
                      <div className="font-extrabold text-[12px] text-slate-900">مستشفى آزال النموذجي</div>
                      <div className="text-[9px] font-bold text-emerald-700">إدارة السلامة وإدارة المرافق (FMS)</div>
                    </div>
                    <div className="text-left text-[9px] font-mono font-bold text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-300">
                      CBAHI ACCREDITED
                    </div>
                  </div>

                  {/* Middle Main Content: QR Code + Asset Details */}
                  <div className="flex items-center gap-3">
                    {/* QR Code Container */}
                    <div className="shrink-0 bg-white border border-slate-300 p-1 rounded-xl shadow-xs flex flex-col items-center">
                      {qrCodeDataUrls[asset.id] ? (
                        <img
                          src={qrCodeDataUrls[asset.id]}
                          alt={`QR Code ${asset.asset_tag}`}
                          className="w-24 h-24 sm:w-28 sm:h-28 object-contain"
                        />
                      ) : (
                        <div className="w-24 h-24 bg-slate-100 animate-pulse rounded"></div>
                      )}
                      <span className="text-[9px] font-mono font-bold text-slate-700 mt-0.5">
                        SCAN TO INSPECT
                      </span>
                    </div>

                    {/* Asset Details */}
                    <div className="flex-1 min-w-0 text-right space-y-1">
                      {/* Asset Code Monospace Display */}
                      <div className="inline-block bg-slate-900 text-white font-mono font-black text-xs sm:text-sm px-2.5 py-0.5 rounded-lg tracking-wider">
                        {asset.asset_tag}
                      </div>

                      <h4 className="font-black text-xs sm:text-sm text-slate-950 line-clamp-2 leading-tight">
                        {asset.name}
                      </h4>

                      <div className="text-[10px] text-slate-600 font-semibold truncate">
                        {asset.categoryNameAr}
                      </div>

                      <div className="text-[10px] text-slate-700 flex items-center gap-1 font-medium">
                        <span className="font-bold">الموقع:</span>
                        <span className="truncate">{asset.location}</span>
                      </div>

                      <div className="flex items-center gap-2 pt-0.5 text-[9.5px]">
                        <span className="bg-emerald-100 text-emerald-800 px-1.5 py-0.2 rounded font-bold border border-emerald-300">
                          الدورية: {asset.frequency}
                        </span>
                        {asset.model && (
                          <span className="bg-slate-100 text-slate-700 px-1.5 py-0.2 rounded font-mono truncate max-w-[120px]">
                            {asset.model}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Bottom Verification Footer */}
                  <div className="border-t border-slate-200 mt-2 pt-1 flex items-center justify-between text-[8.5px] text-slate-500 font-medium">
                    <span>ملصق معتمد لبرنامج الصيانة الوقائية المزمنة PPM</span>
                    <span className="font-mono">AZAL-PPM-2026</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Modal Footer (Hidden on Print) */}
        <div className="no-print bg-slate-950 p-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span>عدد الملصقات الجاهزة للطباعة:</span>
            <span className="text-white font-bold font-mono text-sm">{selectedList.length}</span>
            <span>ملصق</span>
          </div>

          <div className="text-[11px] text-slate-500">
            تلميح: يتم تنسيق أبعاد الملصقات تلقائياً لتناسب ورق A4 العادي أو ورق الملصقات المقصوص مسبقاً
          </div>
        </div>
      </div>

      {/* Print Specific CSS to ensure clean A4 sticker layout */}
      <style dangerouslySetInnerHTML={{ __html: `
        @media print {
          body * {
            visibility: hidden;
          }
          #barcode-a4-print-modal,
          #barcode-a4-print-modal * {
            visibility: visible;
          }
          #barcode-a4-print-modal {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            height: auto;
            background: white !important;
            padding: 0 !important;
            margin: 0 !important;
            overflow: visible !important;
            z-index: 99999;
          }
          .no-print {
            display: none !important;
          }
          @page {
            size: A4 portrait;
            margin: 8mm;
          }
        }
      `}} />
    </div>
  );
};
