import React, { useState } from 'react';
import { 
  Settings, 
  Smartphone, 
  Download, 
  ShieldCheck, 
  Lock, 
  Clock, 
  EyeOff, 
  Database, 
  RotateCcw, 
  Check, 
  Share2, 
  FileSpreadsheet,
  Info
} from 'lucide-react';
import { StaffUser } from '../types';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface SettingsViewProps {
  currentUser: StaffUser;
  staffList: StaffUser[];
  autoLockMinutes: number;
  onChangeAutoLock: (minutes: number) => void;
  privacyMode: boolean;
  onTogglePrivacy: () => void;
  onResetData: () => void;
  onExportData: () => void;
  isOnline: boolean;
  onOpenLogoModal: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  currentUser,
  staffList,
  autoLockMinutes,
  onChangeAutoLock,
  privacyMode,
  onTogglePrivacy,
  onResetData,
  onExportData,
  isOnline,
  onOpenLogoModal,
}) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const [resetConfirm, setResetConfirm] = useState(false);

  return (
    <div id="settings-view" className="space-y-4 pb-20 text-right">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-lg flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-teal-950 border border-teal-800 text-teal-400">
            <Settings className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-100">
              إعدادات النظام وأمان أجهزة الأندرويد
            </h2>
            <p className="text-xs text-slate-400">
              تكوين التشفير، مهلة القفل الآلي، تثبيت التطبيق على الهواتف والأجهزة اللوحية
            </p>
          </div>
        </div>
      </div>

      {/* Android & PWA Installation Card (Prominent per user request "ويكون للأندرويد") */}
      <div className="bg-gradient-to-br from-slate-900 to-teal-950/40 border border-teal-700/60 rounded-2xl p-4 shadow-md space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-teal-600 text-white shadow-md">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100">
                تطبيق أندرويد المستقل (Android PWA Standalone)
              </h3>
              <p className="text-[11px] text-teal-300">
                تشغيل كامل بدون شريط متصفح مع دعم وضع عدم الاتصال (Offline) والمسح السريع
              </p>
            </div>
          </div>

          {isInstalled && (
            <span className="bg-emerald-950 text-emerald-300 border border-emerald-800 text-xs px-2.5 py-1 rounded-full font-bold flex items-center gap-1">
              <Check className="w-3.5 h-3.5" />
              <span>مثبت كـ تطبيق مستقل</span>
            </span>
          )}
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          تم تصميم النظام ليعمل كتطبيق أندرويد متكامل (Progressive Web App). عند تثبيته على أجهزة التمريض اللوحية أو هواتف الأطباء، سيعمل بشاشة كاملة مع دعم الإشعارات وقفل الشاشة البيومتري حتى بدون اتصال إنترنت دائم.
        </p>

        <div className="flex flex-wrap items-center gap-2 pt-1">
          {isInstallable && (
            <button
              type="button"
              onClick={install}
              className="px-5 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 active:bg-teal-700 text-white text-xs font-bold shadow-lg shadow-teal-950 flex items-center gap-2 transition"
            >
              <Download className="w-4 h-4" />
              <span>تثبيت التطبيق على أندرويد الآن</span>
            </button>
          )}

          {!isInstallable && !isInstalled && (
            <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800 text-xs text-slate-300 w-full space-y-1">
              <div className="font-bold text-teal-400">طريقة التثبيت السريعة على هاتف أو لوحي أندرويد:</div>
              <div>1. اضغط على خيارات المتصفح (الثلاث نقاط ⋮ بأعلى شاشة كروم).</div>
              <div>2. اختر <strong>"تثبيت التطبيق"</strong> أو <strong>"إضافة إلى الشاشة الرئيسية" (Install App)</strong>.</div>
            </div>
          )}

          {isIOS && (
            <button
              type="button"
              onClick={() => setShowIOSGuide(true)}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium"
            >
              تعليمات التثبيت لأجهزة Apple iOS
            </button>
          )}
        </div>
      </div>

      {/* Security & Clinical Privacy Settings Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md space-y-4">
        <h3 className="text-xs font-bold text-teal-400 flex items-center gap-1.5">
          <ShieldCheck className="w-4 h-4" />
          <span>أمان الجلسة والخصوصية الطبية (HIPAA & CBAHI Standards)</span>
        </h3>

        <div className="space-y-3 text-xs">
          {/* Auto Lock Timeout */}
          <div className="flex items-center justify-between p-3 bg-slate-950 rounded-xl border border-slate-800">
            <div>
              <span className="font-bold text-slate-200 block">مهلة القفل الآلي للشاشة السريرية:</span>
              <span className="text-[11px] text-slate-400">
                يقفل الشاشة ويطلب الرمز السري PIN تلقائياً عند عدم لمس الشاشة لمنع تلصص الزوار
              </span>
            </div>
            <select
              value={autoLockMinutes}
              onChange={(e) => onChangeAutoLock(Number(e.target.value))}
              className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-teal-300 font-bold"
            >
              <option value={10}>10 دقائق (المعيار المعتمد للمستشفى)</option>
              <option value={15}>15 دقيقة</option>
              <option value={5}>5 دقائق</option>
              <option value={2}>دقيقتان</option>
              <option value={1}>دقيقة واحدة</option>
              <option value={0}>تعطيل القفل التلقائي (تجريبي)</option>
            </select>
          </div>

          {/* Privacy Masking Toggle */}
          <div className="flex items-center justify-between p-3 bg-slate-950 rounded-xl border border-slate-800">
            <div>
              <span className="font-bold text-slate-200 block">وضع التمويه والخصوصية (Privacy Shield):</span>
              <span className="text-[11px] text-slate-400">
                حماية خصوصية السجلات والشاشات في الممرات والمناطق العامة
              </span>
            </div>
            <button
              type="button"
              onClick={onTogglePrivacy}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition border ${
                privacyMode
                  ? 'bg-amber-950 text-amber-300 border-amber-800'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}
            >
              {privacyMode ? 'مفعّل الآن' : 'معطّل'}
            </button>
          </div>

          {/* User Profile Card */}
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
            <span className="font-bold text-slate-200 block mb-2">المستخدم النشط حالياً:</span>
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl ${currentUser.avatarColor} text-white font-bold flex items-center justify-center`}>
                {currentUser.name.slice(0, 2)}
              </div>
              <div>
                <span className="font-bold text-slate-100 block">{currentUser.name}</span>
                <span className="text-teal-400 text-[11px] block">{currentUser.roleTitleAr}</span>
                <span className="text-slate-500 text-[10px] font-mono">الرقم الوظيفي: {currentUser.badgeNumber} • رمز PIN: {currentUser.pin}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Data Backup & Export Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3">
        <h3 className="text-xs font-bold text-teal-400 flex items-center gap-1.5">
          <Database className="w-4 h-4" />
          <span>تصدير البيانات والنسخ الاحتياطي (Backup & Export)</span>
        </h3>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={onExportData}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-2 transition"
          >
            <Download className="w-4 h-4 text-teal-400" />
            <span>تصدير نسخة احتياطية من السجلات (JSON Encrypted)</span>
          </button>

          {!resetConfirm ? (
            <button
              type="button"
              onClick={() => setResetConfirm(true)}
              className="px-4 py-2 rounded-xl bg-rose-950/60 hover:bg-rose-900/80 border border-rose-700/80 text-rose-300 text-xs font-bold flex items-center gap-1.5 transition shadow-sm"
            >
              <RotateCcw className="w-4 h-4 text-rose-400" />
              <span>مسح وتصفير كافة البيانات التجريبية (بدء العمل الفعلي من الصفر)</span>
            </button>
          ) : (
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 p-3 bg-rose-950/90 border border-rose-700 rounded-xl">
              <span className="text-xs text-rose-200 font-bold">
                ⚠️ هل تؤكد مسح وتصفير كافة السجلات التجريبية نهائياً للبدء بالعمل الفعلي؟
              </span>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    onResetData();
                    setResetConfirm(false);
                  }}
                  className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-lg text-xs font-black shadow"
                >
                  نعم، تصفير والبدء من الصفر
                </button>
                <button
                  type="button"
                  onClick={() => setResetConfirm(false)}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs"
                >
                  إلغاء
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Azal Model Hospital Identity & Emergency Hotlines Card */}
      <div className="bg-gradient-to-r from-teal-950 via-slate-900 to-slate-900 border border-teal-800/70 rounded-2xl p-4 shadow-md space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white border border-slate-200 p-1 flex items-center justify-center shadow-md shrink-0">
              <img
                src="/icon.svg"
                alt="شعار مستشفى أزال - الرعاية الكاملة"
                className="w-full h-full object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-slate-100">
                  مستشفى أزال النموذجي • إدارة الأمن والسلامة
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-700/70">
                  الرعاية الكاملة
                </span>
              </div>
              <p className="text-xs text-teal-400">
                المنظومة الإلكترونية المعتمدة لسلامة المرضى والمنشأة
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onOpenLogoModal}
            className="px-3.5 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-slate-950 rounded-xl text-xs font-black flex items-center gap-1.5 transition self-start sm:self-auto shadow-md"
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>عرض وتنزيل شعار أزال الرسمي</span>
          </button>
        </div>

        {/* Emergency Hotlines within Azal Hospital */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          <div className="bg-slate-950/80 p-2 rounded-xl border border-slate-800">
            <span className="text-[10px] text-slate-400 block">طوارئ المستشفى الداخلي</span>
            <span className="text-sm font-black text-rose-400 font-mono">111 / 999</span>
          </div>
          <div className="bg-slate-950/80 p-2 rounded-xl border border-slate-800">
            <span className="text-[10px] text-slate-400 block">غرفة المراقبة والتحكم CCTV</span>
            <span className="text-sm font-black text-amber-400 font-mono">تحويلة 204</span>
          </div>
          <div className="bg-slate-950/80 p-2 rounded-xl border border-slate-800">
            <span className="text-[10px] text-slate-400 block">محطة الأكسجين والغازات</span>
            <span className="text-sm font-black text-teal-400 font-mono">تحويلة 305</span>
          </div>
          <div className="bg-slate-950/80 p-2 rounded-xl border border-slate-800">
            <span className="text-[10px] text-slate-400 block">الدفاع المدني الخارجي</span>
            <span className="text-sm font-black text-sky-400 font-mono">191</span>
          </div>
        </div>
      </div>

      {/* System Technical Info */}
      <div className="p-4 bg-slate-950/70 border border-slate-800/80 rounded-2xl text-xs text-slate-400 space-y-1">
        <div className="flex items-center gap-1.5 text-slate-300 font-bold">
          <Info className="w-4 h-4 text-teal-400" />
          <span>معلومات نظام استلام وتسليم المستشفيات الآمن (SafeHandoff Enterprise):</span>
        </div>
        <div>الإصدار السريري: 3.4.0 (Android PWA Edition - 2026)</div>
        <div>معيار التسليم: ISBAR / SBAR المعتمد من منظمة الصحة العالمية (WHO) والمركز السعودي لاعتماد المنشآت الصحية (CBAHI)</div>
        <div>نوع التشفير: حماية الجلسة السريرية مع سجل تدقيق غير قابل للإلغاء (Cryptographic Audit Trail)</div>
      </div>
    </div>
  );
};
