import React, { useState } from 'react';
import { 
  FileText, 
  Printer, 
  Download, 
  Calendar, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  ShieldCheck, 
  Flame, 
  Building2, 
  Copy, 
  Check, 
  TrendingUp,
  Layers, 
  XCircle, 
  Share2,
  ExternalLink,
  Filter,
  Sparkles,
  RotateCcw,
  MapPin,
  Gauge,
  Activity,
  Droplets,
  Wind,
  Zap,
  CheckSquare,
  Search,
  ChevronDown,
  ListFilter,
  Target
} from 'lucide-react';
import { 
  SafetyTourRecord, 
  SafetyViolationNotice, 
  FireExtinguisherItem, 
  StaffUser, 
  ReportPeriodFilter,
  SafetyIncidentReport
} from '../types';
import { AZAL_DEPARTMENTS } from '../data/azalSafetyUpgradeData';
import { 
  AZAL_HOSPITAL_PATROL_CHECKPOINTS, 
  AZAL_MASTER_FIRE_EXTINGUISHERS, 
  calculateCensusBreakdown, 
  HospitalPatrolCheckpoint 
} from '../data/azalHospitalSafetyRegistry';
import { getPublicAppBaseUrl } from '../utils/phoneUtils';
import { AzalLogo } from './AzalLogo';
import { VoiceDictationButton } from './VoiceDictationButton';
import { CbahiFocusPdcaModal } from './CbahiFocusPdcaModal';
import { offlineStorage } from '../services/offlineStorage';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';
import { printExistingElementById } from '../utils/printUtils';

interface GeneralManagerReportsViewProps {
  tours: SafetyTourRecord[];
  violations: SafetyViolationNotice[];
  extinguishers: FireExtinguisherItem[];
  currentUser: StaffUser;
  incidents?: SafetyIncidentReport[];
  onClose?: () => void;
  isModal?: boolean;
  isStandalonePrint?: boolean;
}

export const GeneralManagerReportsView: React.FC<GeneralManagerReportsViewProps> = ({
  tours,
  violations,
  extinguishers,
  currentUser,
  incidents,
  onClose,
  isModal = false,
  isStandalonePrint = false,
}) => {
  const [period, setPeriod] = useState<ReportPeriodFilter>('all');
  const [departmentFilter, setDepartmentFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [extTypeFilter, setExtTypeFilter] = useState<string>('all');
  const [extStatusFilter, setExtStatusFilter] = useState<string>('all');
  const [extSearchTerm, setExtSearchTerm] = useState<string>('');
  const [patrolSearchTerm, setPatrolSearchTerm] = useState<string>('');
  const [copiedMemo, setCopiedMemo] = useState(false);
  const [printAlert, setPrintAlert] = useState<string | null>(null);
  const [showFocusPdcaModal, setShowFocusPdcaModal] = useState(false);
  const [incidentsList, setIncidentsList] = useState<SafetyIncidentReport[]>(() => incidents || []);

  React.useEffect(() => {
    if (incidents && incidents.length > 0) {
      setIncidentsList(incidents);
      return;
    }
    try {
      const saved = localStorage.getItem('azal_safety_incidents_v1');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          setIncidentsList(parsed);
        }
      }
    } catch {
      // safe fallback
    }
  }, [incidents]);

  // Customizable recommendations that the safety officer can edit live before printing
  const [customRecommendations, setCustomRecommendations] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('azal_manual_safety_recommendations_v2');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.map((item: any) =>
            typeof item === 'string'
              ? item
              : `${item.text} [الجهة المعنية: ${item.targetDepartment || 'إدارة المستشفى'}]`
          );
        }
      }
    } catch {
      // fallback
    }
    return [
      'إلزام الأقسام ذات الإشعارات المعلقة (خصوصاً قسم الخدمات المساندة والنظافة) بفتح ممرات الطوارئ فوراً تحت طائلة المساءلة الإدارية.',
      'التوجيه العاجل لقسم الصيانة العامة بإصلاح قفل لوحة الكهرباء DB-G04 وتأمين الأسلاك قبل نهاية مهلة الـ 48 ساعة.',
      'اعتماد أمر شراء وتعبئة طفايات الحريق في المطبخ والقبو (رغوة كيميائية 9 لتر) لضمان تحقيق نسبة جاهزية 100%.',
      'استمرار الجولات التفتيشية الليلية المفاجئة للتأكد من انضباط مخارج الطوارئ وعدم تكديس العهد أو الأدوات الطبية في الممرات.',
      'إلزام مشرفي الورديات بالتبليغ الفوري عن أي عطل في شبكة إنذار الحريق أو محابس شبكة الغازات الطبية.'
    ];
  });
  const [newRecInput, setNewRecInput] = useState('');

  // Safe timestamp parser to handle numbers, ISO strings, or Date formats
  const getItemTimestamp = (item: { timestamp?: number | string; createdAt?: string; tourDate?: string }): number => {
    if (typeof item.timestamp === 'number' && !isNaN(item.timestamp)) return item.timestamp;
    if (typeof item.timestamp === 'string') {
      const p = Date.parse(item.timestamp);
      if (!isNaN(p)) return p;
    }
    if (item.createdAt) {
      const p = Date.parse(item.createdAt.replace(' ', 'T'));
      if (!isNaN(p)) return p;
    }
    if (item.tourDate) {
      const p = Date.parse(item.tourDate.replace(' ', 'T'));
      if (!isNaN(p)) return p;
    }
    return 0;
  };

  const now = Date.now();
  const getPeriodThreshold = (p: ReportPeriodFilter) => {
    switch (p) {
      case 'daily':
        return 1 * 24 * 60 * 60 * 1000;
      case 'weekly':
        return 7 * 24 * 60 * 60 * 1000;
      case 'monthly':
        return 30 * 24 * 60 * 60 * 1000;
      case 'quarterly':
        return 90 * 24 * 60 * 60 * 1000;
      case 'yearly':
        return 365 * 24 * 60 * 60 * 1000;
      case 'all':
      default:
        return Infinity;
    }
  };

  // Period Titles & Metadata
  const periodMeta: Record<ReportPeriodFilter, { title: string; subtitle: string; code: string; label: string }> = {
    all: {
      title: 'السجل العام الشامل لمنظومة السلامة (كافة الفترات)',
      subtitle: 'عرض وتوثيق كافة الجولات الميدانية والمخالفات المسجلة بالنظام دون حصر زمني',
      code: 'ALL',
      label: 'عرض الكل'
    },
    daily: {
      title: 'التقرير اليومي للسلامة والصحة المهنية',
      subtitle: 'موجز الـ 24 ساعة الماضية لمتابعة الملاحظات الطارئة',
      code: 'DLY',
      label: 'يومي (24h)'
    },
    weekly: {
      title: 'التقرير الأسبوعي الميداني للسلامة',
      subtitle: 'متابعة أسبوعية دورية لإنجاز التكليفات وجاهزية الأقسام',
      code: 'WK',
      label: 'أسبوعي (7d)'
    },
    monthly: {
      title: 'التقرير الشهري الشامل للأمن والسلامة المهنية',
      subtitle: 'التقرير الرقابي المعتمد للتقييم ومساءلة الأقسام بالمستشفى',
      code: 'MTH',
      label: 'شهري (30d)'
    },
    quarterly: {
      title: 'التقرير الفصلي لتقييم المخاطر والسلامة (كل 3 أشهر)',
      subtitle: 'مراجعة استراتيجية ربع سنوية لمنظومة السلامة ومعايير الجودة',
      code: 'QTR',
      label: 'فصلي (90d)'
    },
    yearly: {
      title: 'التقرير السنوي الختامي لمنظومة الأمن والسلامة',
      subtitle: 'الحصيلة السنوية للجاهزية، الحوادث، وإنجازات السلامة',
      code: 'ANN',
      label: 'سنوي (1y)'
    }
  };

  // Pre-calculate count for badges on period selector
  const countViolationsForPeriod = (p: ReportPeriodFilter): number => {
    if (p === 'all') return violations.length;
    const threshold = getPeriodThreshold(p);
    return violations.filter((v) => {
      const t = getItemTimestamp(v);
      if (t === 0) return true;
      return now - t <= threshold;
    }).length;
  };

  // Filtered lists
  const currentThreshold = getPeriodThreshold(period);

  const filteredTours = tours.filter((t) => {
    if (period === 'all') return true;
    const itemTime = getItemTimestamp(t);
    if (itemTime === 0) return true;
    return now - itemTime <= currentThreshold;
  });

  const filteredViolations = violations.filter((v) => {
    // 1. Period filter
    if (period !== 'all') {
      const itemTime = getItemTimestamp(v);
      if (itemTime !== 0 && now - itemTime > currentThreshold) {
        return false;
      }
    }
    // 2. Department filter
    if (departmentFilter !== 'all' && v.department !== departmentFilter) {
      return false;
    }
    // 3. Status filter
    if (statusFilter === 'overdue' && v.status !== 'overdue') return false;
    if (statusFilter === 'pending' && v.status !== 'pending') return false;
    if (statusFilter === 'resolved' && v.status !== 'resolved' && v.status !== 'responded') return false;

    return true;
  });

  // Calculate Key Executive Metrics
  const resolvedList = filteredViolations.filter((v) => v.status === 'resolved' || v.status === 'responded');
  const pendingList = filteredViolations.filter((v) => v.status === 'pending');
  const overdueList = filteredViolations.filter((v) => v.status === 'overdue');

  const totalViolations = filteredViolations.length;
  const resolutionRate = totalViolations > 0 ? Math.round((resolvedList.length / totalViolations) * 100) : 100;

  // Extinguishers master census and active registry (fallback to master baseline if store empty)
  const activeExtinguishers = (extinguishers && extinguishers.length > 0) ? extinguishers : AZAL_MASTER_FIRE_EXTINGUISHERS;
  const censusStats = calculateCensusBreakdown(activeExtinguishers);
  const totalExtinguishers = censusStats.total;
  const validExtinguishers = censusStats.operationalCount;
  const extinguisherReadinessRate = censusStats.operationalRate;

  // Active Patrol Checkpoints (merged with real recorded tours if available)
  const patrolCheckpoints: HospitalPatrolCheckpoint[] = AZAL_HOSPITAL_PATROL_CHECKPOINTS.map((chk) => {
    const matchedTour = filteredTours.find(
      (t) => t.department === chk.department || (t.customDepartment && t.customDepartment.includes(chk.department))
    );
    if (matchedTour) {
      return {
        ...chk,
        lastChecked: new Date(matchedTour.timestamp).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }) + ' - ' + (matchedTour.tourDate || new Date().toISOString().split('T')[0]),
        hasViolation: matchedTour.hasViolation,
        status: matchedTour.hasViolation ? 'attention_required' : 'completed',
        statusAr: matchedTour.hasViolation ? 'رُصدت ملاحظة ⚠️' : 'منجز ومطابق 🟢',
        notes: matchedTour.notes || chk.notes,
        inspectorName: matchedTour.inspectorName || chk.inspectorName
      };
    }
    return chk;
  });

  const displayCheckpoints = patrolCheckpoints.filter((chk) => {
    if (!patrolSearchTerm.trim()) return true;
    const q = patrolSearchTerm.toLowerCase();
    return chk.checkpointName.toLowerCase().includes(q) ||
           chk.department.toLowerCase().includes(q) ||
           chk.zone.toLowerCase().includes(q) ||
           chk.notes.toLowerCase().includes(q);
  });

  const displayExtinguishers = activeExtinguishers.filter((e) => {
    if (extTypeFilter !== 'all' && e.type !== extTypeFilter) return false;
    if (extStatusFilter === 'operational' && (e.conditionStatus !== 'valid' || e.gaugeStatus !== 'normal')) return false;
    if (extStatusFilter === 'maintenance' && (e.conditionStatus === 'valid' && e.gaugeStatus === 'normal')) return false;
    if (!extSearchTerm.trim()) return true;
    const q = extSearchTerm.toLowerCase();
    return e.serialNumber.toLowerCase().includes(q) ||
           e.location.toLowerCase().includes(q) ||
           (e.zone && e.zone.toLowerCase().includes(q)) ||
           e.typeAr.toLowerCase().includes(q) ||
           e.notes.toLowerCase().includes(q);
  });

  // -------------------------------------------------------------
  // Printing & Exporting Methods
  // -------------------------------------------------------------

  const handlePrint = () => {
    try {
      triggerSuccessFeedback();
      printExistingElementById('printable-report-area', {
        title: `${periodMeta[period].title} - مستشفى آزال النموذجي`,
        subtitle: 'تقرير الإدارة العامة الدوري • إدارة السلامة وإدارة المرافق FMS • الجودة والاعتماد CBAHI',
        refNumber: `AZAL-GM-REPORT-${period.toUpperCase()}-2026`
      });
    } catch (e) {
      console.warn('Print error:', e);
      setPrintAlert('تمت محاولة الطباعة، يمكنك أيضاً استخدام زر "تحميل ملف التقرير" لطباعة أو حفظ التقرير بصيغة HTML/PDF.');
    }
  };

  const handleOpenStandalonePrint = () => {
    try {
      const publicUrl = `${getPublicAppBaseUrl()}/#print-report`;
      if (typeof window !== 'undefined') {
        const win = window.open(publicUrl, '_blank', 'noopener,noreferrer');
        if (!win) {
          // If popup is blocked in iframe, trigger direct download of the print sheet
          handleDownloadHtmlReport();
        }
      }
    } catch (e) {
      console.warn('Popup blocked, falling back to report download:', e);
      handleDownloadHtmlReport();
    }
  };

  const handleDownloadHtmlReport = () => {
    const reportElem = document.getElementById('printable-report-area');
    if (!reportElem) {
      handlePrint();
      return;
    }

    const reportHtml = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${periodMeta[period].title} - مستشفى آزال النموذجي</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
  <style>
    * { box-sizing: border-box; }
    body {
      font-family: 'Cairo', system-ui, -apple-system, sans-serif;
      background: #0f172a;
      color: #f1f5f9;
      margin: 0;
      padding: 20px;
      direction: rtl;
    }
    @page { size: A4 portrait; margin: 10mm; }
    @media print {
      body { 
        padding: 0; 
        background: #ffffff !important; 
        color: #0f172a !important; 
      }
      .no-print { display: none !important; }
      .report-sheet {
        border: none !important;
        box-shadow: none !important;
        padding: 0 !important;
        background: #ffffff !important;
        color: #0f172a !important;
      }
      .printable-card, .printable-report-sheet {
        background: #ffffff !important;
        color: #0f172a !important;
        border: 1px solid #cbd5e1 !important;
      }
      table.printable-table, table {
        width: 100% !important;
        border-collapse: collapse !important;
        page-break-inside: auto !important;
      }
      table.printable-table thead, table thead {
        display: table-header-group !important;
      }
      table.printable-table tr, table tr {
        page-break-inside: avoid !important;
        break-inside: avoid !important;
      }
      table.printable-table th, table th {
        background: #f1f5f9 !important;
        color: #0f172a !important;
        border: 1px solid #94a3b8 !important;
        padding: 6px 8px !important;
        font-weight: bold !important;
      }
      table.printable-table td, table td {
        border: 1px solid #cbd5e1 !important;
        color: #0f172a !important;
        padding: 6px 8px !important;
      }
      .text-slate-100, .text-slate-200, .text-slate-300, .text-slate-400 {
        color: #1e293b !important;
      }
      .bg-slate-900, .bg-slate-950 {
        background: #ffffff !important;
      }
    }
    .print-actions {
      max-width: 1000px;
      margin: 0 auto 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 12px 18px;
      background: #1e293b;
      color: #ffffff;
      border-radius: 14px;
      border: 1px solid #334155;
    }
    .print-btn {
      background: #0d9488;
      color: #ffffff;
      border: none;
      padding: 9px 22px;
      font-size: 13px;
      font-weight: bold;
      border-radius: 10px;
      cursor: pointer;
      font-family: inherit;
      transition: background 0.2s;
    }
    .print-btn:hover {
      background: #0f766e;
    }
    .report-sheet {
      max-width: 1000px;
      margin: 0 auto;
      border: 1px solid #334155;
      border-radius: 20px;
      padding: 28px;
      background: #0f172a;
      color: #f1f5f9;
      box-shadow: 0 10px 30px rgba(0,0,0,0.4);
    }
    table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 11.5px; }
    th { background: #1e293b; color: #f8fafc; padding: 8px 10px; border: 1px solid #334155; font-weight: bold; text-align: right; }
    td { padding: 8px 10px; border: 1px solid #334155; text-align: right; }
    .print-avoid-break { page-break-inside: avoid; break-inside: avoid; }
  </style>
</head>
<body>
  <div class="no-print print-actions">
    <div>
      <strong style="font-size: 14px;">مستشفى آزال النموذجي • تقرير الإدارة العامة الرسمي</strong>
      <span style="display:block; font-size: 11px; opacity: 0.8;">نسخة محفوظة قابلة للطباعة A4 والحفظ كـ PDF</span>
    </div>
    <button class="print-btn" onclick="window.print()">طباعة فورية / حفظ كـ PDF</button>
  </div>
  <div class="report-sheet">
    ${reportElem.innerHTML}
  </div>
  <script>
    // Automatically open print dialog when opened in browser
    window.addEventListener('load', function() {
      setTimeout(function() { window.print(); }, 400);
    });
  </script>
</body>
</html>`;

    const blob = new Blob([reportHtml], { type: 'text/html;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `تقرير_الأمن_والسلامة_مستشفى_آزال_${periodMeta[period].code}_${new Date().toISOString().split('T')[0]}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleWhatsAppShare = () => {
    const text = `*تقرير السلامة الميدانية وحصر الجاهزية المعتمدة (${periodMeta[period].title})*
مستشفى آزال النموذجي - إدارة الأمن والسلامة

1. إفادات المعالجة المعتمدة بالروابط (الأقسام المستجيبة):
${resolvedList.length > 0 ? resolvedList.map((v) => `• ${v.department} (${v.id}): ${v.resolutionNote || 'تمت المعالجة'} - المنفذ: ${v.resolvedBy || 'المسؤول المناوب'}`).join('\n') : '• لا توجد إفادات معالجة جديدة حالياً'}
• نسبة إنجاز وتصحيح الملاحظات: ${resolutionRate}% (${resolvedList.length} مخالفة وملاحظة معالجة وموثقة).

2. جاهزية شبكة مطافئ الحريق الشاملة:
• إجمالي الأسطوانات والعربات المحصورة: ${censusStats.total} أسطوانة وعربة
• نسبة الجاهزية التشغيلية: ${censusStats.operationalRate}% (${censusStats.operationalCount} صالحة وسليمة)
• بحاجة لصيانة دورية أو تعبئة: ${censusStats.needsMaintenanceCount} أسطوانة

3. مسارات الجولات التفتيشية وبلاغات الصباح:
• عدد نقاط التفتيش المعتمدة: ${patrolCheckpoints.length} مسار رقابي
• تم التعامل والتأمين الفوري لكافة البلاغات الميدانية (تسريب مائي، منظمات الغازات، إضاءة الطوارئ).

أبرز التوصيات المرفوعة:
${customRecommendations.map((r, i) => `${i + 1}. ${r}`).join('\n')}

رابط التقرير الكامل في النظام:
${getPublicAppBaseUrl()}/#print-report

إعداد ورفع:
رئيس قسم الأمن والسلامة / م. نجيب غازي`;

    if (typeof window !== 'undefined') {
      window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
    }
  };

  const handleAddRecommendation = () => {
    if (!newRecInput.trim()) return;
    setCustomRecommendations((prev) => [...prev, newRecInput.trim()]);
    setNewRecInput('');
  };

  const handleRemoveRecommendation = (index: number) => {
    setCustomRecommendations((prev) => prev.filter((_, i) => i !== index));
  };

  const handleCopyMemoText = () => {
    const text = `الموضوع: تقرير السلامة الميدانية وحصر الجاهزية (${periodMeta[period].title})
مستشفى آزال النموذجي - إدارة الأمن والسلامة

• مسارات جولات السلامة الميدانية: ${patrolCheckpoints.length} مسار تفتيش معتمد.
• سجل وحصر طفايات الحريق الشامل: ${censusStats.total} أسطوانة وعربة موزعة (نسبة الجاهزية: ${censusStats.operationalRate}% - ${censusStats.operationalCount} صالحة، ${censusStats.needsMaintenanceCount} بحاجة لصيانة وتعبئة).
• إجمالي المخالفات والملاحظات المرصودة: ${totalViolations} مخالفة.
  - المخالفات المنجزة والمصححة: ${resolvedList.length} (بنسبة ${resolutionRate}%).
  - المخالفات قيد الإجراء ضمن المهلة: ${pendingList.length}.
  - المخالفات المتأخرة / لم يُرد عليها حتى الآن: ${overdueList.length}.

أبرز التوصيات العاجلة المرفوعة:
${customRecommendations.map((r, i) => `${i + 1}. ${r}`).join('\n')}

إعداد ورفع:
م/ نجيب قاسم غازي (رئيس قسم السلامة وإدارة المرافق FMS)`;

    navigator.clipboard.writeText(text);
    setCopiedMemo(true);
    setTimeout(() => setCopiedMemo(false), 2500);
  };

  return (
    <div className={`space-y-4 text-right ${isModal ? '' : 'pb-16'}`} id="executive-reports-container">
      {/* Interactive Controls Bar (Hidden during Print) */}
      <div className="no-print bg-gradient-to-r from-teal-950 via-slate-900 to-slate-900 border border-teal-800/60 rounded-2xl p-4 shadow-xl space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-teal-950 border border-teal-700 text-teal-400 shadow-sm">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-slate-100">
                  وحدة تقارير الإدارة العامة الرسمية (Direct Executive Reporting)
                </h3>
                <span className="text-[10px] bg-teal-900 text-teal-200 border border-teal-700 px-2 py-0.5 rounded-full font-bold font-mono">
                  نسخة المدير العام
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                إصدار وتخصيص تقارير السلامة الدورية، نسب الجاهزية، ومساءلة الأقسام المقصرة مع جاهزية الطباعة A4 وتصدير PDF
              </p>
            </div>
          </div>

          {/* Action Buttons Suite */}
          <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
            {/* Executive Summary A4 Report Page */}
            <button
              type="button"
              onClick={() => {
                window.location.hash = '#print-report';
              }}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-600 via-teal-600 to-emerald-600 hover:from-amber-500 hover:to-emerald-500 text-white text-xs font-black shadow-lg shadow-teal-950 flex items-center gap-1.5 transition active:scale-95 ring-1 ring-amber-400/50"
              title="فتح موجز مؤشرات السلامة والجاهزية التنفيذي A4 صفحة واحدة للمدير العام"
            >
              <TrendingUp className="w-4 h-4 text-amber-200" />
              <span>موجز المؤشرات التنفيذي A4 (صفحة واحدة)</span>
            </button>

            {/* 1. Direct Print */}
            <button
              type="button"
              onClick={handlePrint}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white text-xs font-black shadow-lg shadow-teal-950 flex items-center gap-1.5 transition active:scale-95"
              title="طباعة فورية أو تصدير بصيغة PDF معدة لورق A4"
            >
              <Printer className="w-4 h-4" />
              <span>طباعة فورية (A4)</span>
            </button>

            {/* 2. Standalone Print Page (For Mobile Chrome / Iframe fallback) */}
            <button
              type="button"
              onClick={handleOpenStandalonePrint}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-300 border border-slate-700 text-xs font-bold flex items-center gap-1.5 transition active:scale-95 shadow-sm"
              title="فتح التقرير في نافذة مستقلة خالية من الإطارات لتسهيل حفظ PDF عبر الجوال"
            >
              <ExternalLink className="w-4 h-4 text-teal-400" />
              <span>صفحة طباعة مستقلة</span>
            </button>

            {/* 3. Offline HTML / PDF Download */}
            <button
              type="button"
              onClick={handleDownloadHtmlReport}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-blue-300 border border-slate-700 text-xs font-bold flex items-center gap-1.5 transition active:scale-95 shadow-sm"
              title="تنزيل التقرير كملف صفحة مستقلة جاهزة للحفظ والطباعة أوفلاين"
            >
              <Download className="w-4 h-4 text-blue-400" />
              <span>تنزيل التقرير (HTML/PDF)</span>
            </button>

            {/* CBAHI FOCUS-PDCA Quality KPI Export */}
            <button
              type="button"
              onClick={() => setShowFocusPdcaModal(true)}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-teal-600 to-indigo-600 hover:from-teal-500 hover:to-indigo-500 text-white text-xs font-black flex items-center gap-1.5 transition active:scale-95 shadow-md ring-1 ring-teal-400/40"
              title="تصدير تقرير FOCUS-PDCA التحليلي الشامل لمؤشرات أداء سباهي (CBAHI FMS Quality KPIs)"
            >
              <Target className="w-4 h-4 text-teal-200" />
              <span>تصدير FOCUS-PDCA (CBAHI)</span>
            </button>

            {/* 4. WhatsApp Share */}
            <button
              type="button"
              onClick={handleWhatsAppShare}
              className="px-3 py-2 rounded-xl bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 text-xs font-bold flex items-center gap-1.5 transition active:scale-95 shadow-sm"
              title="إرسال ملخص التقرير والتوصيات مباشرة للمدير العام عبر واتساب"
            >
              <Share2 className="w-4 h-4 text-emerald-400" />
              <span>واتساب للمدير العام</span>
            </button>

            {/* 5. Copy Memo */}
            <button
              type="button"
              onClick={handleCopyMemoText}
              className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold flex items-center gap-1.5 transition active:scale-95 shadow-sm"
              title="نسخ ملخص التقرير كمذكرة إدارية نصية"
            >
              {copiedMemo ? (
                <>
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span className="text-emerald-400">تم النسخ</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 text-teal-400" />
                  <span>نسخ كمذكرة</span>
                </>
              )}
            </button>

            {onClose && (
              <button
                type="button"
                onClick={onClose}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition"
                title="إغلاق النافذة"
              >
                <XCircle className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>

        {/* Mobile / Helper Guidance Banner */}
        <div className="bg-teal-950/40 border border-teal-800/40 rounded-xl p-2.5 px-3 flex flex-wrap items-center justify-between gap-2 text-xs text-teal-200">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-teal-400 shrink-0" />
            <span>
              <strong>خيارات التصدير:</strong> تدعم المنظومة الطباعة المباشرة بورق A4، أو فتح التقرير في نافذة مستقلة لتجاوز قيود متصفح الجوال، أو تنزيل ملف التقرير المستقل بضغطة زر.
            </span>
          </div>
          {printAlert && (
            <div className="w-full bg-amber-950/80 border border-amber-700 text-amber-200 p-2 rounded-lg text-xs mt-1">
              ⚠️ {printAlert}
            </div>
          )}
        </div>

        {/* Filters Bar: Periods + Department + Status */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          {/* Period Selector Buttons with dynamic badges */}
          <div className="flex flex-wrap items-center gap-1 bg-slate-950/80 border border-slate-800 p-1 rounded-xl">
            <span className="text-[11px] text-slate-400 px-2 font-semibold">الفترة:</span>
            
            {(['all', 'daily', 'weekly', 'monthly', 'quarterly', 'yearly'] as ReportPeriodFilter[]).map((p) => {
              const count = countViolationsForPeriod(p);
              const isSelected = period === p;
              return (
                <button
                  key={p}
                  type="button"
                  onClick={() => setPeriod(p)}
                  className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                    isSelected
                      ? 'bg-teal-600 text-white shadow-md'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <span>{periodMeta[p].label}</span>
                  <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded-full ${
                    isSelected ? 'bg-teal-950 text-teal-200' : 'bg-slate-800 text-slate-400'
                  }`}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Targeted Filters: Department & Status */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Department Filter */}
            <div className="flex items-center gap-1 bg-slate-950/80 border border-slate-800 px-2.5 py-1 rounded-xl text-xs">
              <Filter className="w-3.5 h-3.5 text-teal-400" />
              <select
                value={departmentFilter}
                onChange={(e) => setDepartmentFilter(e.target.value)}
                className="bg-transparent text-slate-200 text-xs focus:outline-none cursor-pointer"
              >
                <option value="all" className="bg-slate-900 text-slate-200">كافة الأقسام</option>
                {AZAL_DEPARTMENTS.map((dept) => (
                  <option key={dept} value={dept} className="bg-slate-900 text-slate-200">
                    {dept}
                  </option>
                ))}
              </select>
            </div>

            {/* Status Filter */}
            <div className="flex items-center gap-1 bg-slate-950/80 border border-slate-800 px-2.5 py-1 rounded-xl text-xs">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="bg-transparent text-slate-200 text-xs focus:outline-none cursor-pointer"
              >
                <option value="all" className="bg-slate-900 text-slate-200">كافة الحالات</option>
                <option value="overdue" className="bg-slate-900 text-rose-300">المتأخرة فقط 🔴 ({overdueList.length})</option>
                <option value="pending" className="bg-slate-900 text-amber-300">قيد المتابعة 🟡 ({pendingList.length})</option>
                <option value="resolved" className="bg-slate-900 text-emerald-300">المنجزة 🟢 ({resolvedList.length})</option>
              </select>
            </div>

            {/* Reset Filters button */}
            {(departmentFilter !== 'all' || statusFilter !== 'all' || period !== 'all') && (
              <button
                type="button"
                onClick={() => {
                  setPeriod('all');
                  setDepartmentFilter('all');
                  setStatusFilter('all');
                }}
                className="px-2.5 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold flex items-center gap-1 transition"
                title="إعادة ضبط الفلاتر"
              >
                <RotateCcw className="w-3 h-3" />
                <span>إعادة ضبط</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* =========================================================================
       * THE OFFICIAL EXECUTIVE REPORT SHEET (READY FOR ON-SCREEN & A4 PRINT)
       * ========================================================================= */}
      <div 
        id="printable-report-area" 
        className={`printable-report-sheet ${
          isStandalonePrint ? 'bg-white text-slate-900 p-6' : 'bg-slate-900 text-slate-100 p-6 sm:p-8'
        } border border-slate-800 rounded-3xl space-y-6 shadow-2xl transition`}
      >
        {/* 1. Official Institutional Letterhead */}
        <div className="border-b-2 border-slate-700 pb-5 space-y-3">
          <div className="flex items-center justify-between gap-4">
            {/* Right: Ministry & Hospital info */}
            <div className="flex items-center gap-3">
              <AzalLogo variant="horizontal" size="md" transparent={true} />
              <div>
                <span className="text-[11px] font-bold text-slate-400 block">الجمهورية اليمنية</span>
                <span className="text-xs font-bold text-teal-400 block">
                  إدارة الأمن والسلامة وإدارة المرافق (FMS) • معتمد سباهي
                </span>
              </div>
            </div>

            {/* Left: Administrative Filing Data */}
            <div className="text-left font-mono text-[11px] text-slate-400 space-y-1 bg-slate-950/60 p-2.5 rounded-xl border border-slate-800">
              <div><strong>رقم المرجع:</strong> AZAL-REP-{new Date().getFullYear()}-{periodMeta[period].code}-09</div>
              <div><strong>تاريخ الإصدار:</strong> {new Date().toLocaleDateString('ar-EG', { dateStyle: 'full' })}</div>
              <div><strong>درجة السرية:</strong> <span className="text-amber-400 font-bold">تقرير رقابي للمدير العام</span></div>
              <div className="text-emerald-400 font-bold">الحالة: معتمد ومزامَن إلكترونياً ⚡</div>
            </div>
          </div>

        </div>

        {/* Formal Executive Header */}
        <div className="printable-card bg-slate-950 border border-teal-800/80 rounded-2xl p-4 sm:p-5 space-y-3 shadow-lg">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
            <div>
              <h2 className="text-base sm:text-lg font-black text-slate-100 tracking-tight">
                تقرير المتابعة الميدانية وجاهزية منظومة السلامة والإطفاء
              </h2>
              <div className="text-xs font-bold text-teal-400 mt-0.5">
                إدارة الأمن والسلامة • مستشفى آزال النموذجي
              </div>
            </div>
            <div className="text-[11px] font-mono text-teal-300 bg-teal-950/80 px-3 py-1 rounded-xl border border-teal-800">
              {periodMeta[period].title}
            </div>
          </div>

          <div className="bg-slate-900/90 border-r-4 border-teal-500 p-3 rounded-xl">
            <span className="font-black text-teal-300 text-xs sm:text-sm">الموضوع: </span>
            <span className="text-xs sm:text-sm font-bold text-slate-100">
              تقرير السلامة الميدانية وحصر الجاهزية المعتمدة ({periodMeta[period].title})
            </span>
          </div>

          <p className="text-slate-300 text-xs sm:text-[13px] leading-relaxed text-justify">
            خلاصة نتائج جولات التفتيش المستمرة، وإفادات الإنجاز الميدانية المعتمدة بالروابط الرقمية، إلى جانب الحصر الفني الدقيق لشبكة أسطوانات وعربات الإطفاء البالغ عددها ({censusStats.total} أسطوانة) ومستوى جاهزيتها التشغيلية البالغة ({censusStats.operationalRate}%).
          </p>
        </div>

        {/* Executive Summary Card: Fire Extinguishers & Safety Census (Top Summary) */}
        <div className="printable-card bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border-2 border-teal-600/60 p-4 sm:p-5 rounded-2xl space-y-3.5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-teal-950/80 border border-teal-700/60 text-teal-300">
                <Flame className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-black text-teal-300 flex items-center gap-2">
                  <span>بطاقة الملخص التنفيذي لمنظومة مطافئ الحريق والسلامة</span>
                  <span className="text-[10px] bg-teal-950 text-teal-300 px-2.5 py-0.5 rounded-full border border-teal-800 font-mono">
                    حصر رسمي معتمد
                  </span>
                </h3>
                <p className="text-xs text-slate-400">
                  مستشفى آزال النموذجي • الحصر الرقمي الشامل للمطافئ ومسارات الجولات الميدانية
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-300 font-medium">المفتش والضابط المعتمد:</span>
              <span className="text-xs font-bold text-teal-300 bg-teal-950/90 px-3 py-1 rounded-xl border border-teal-800">
                م/ نجيب غازي - رئيس قسم الأمن والسلامة
              </span>
            </div>
          </div>

          {/* 3 Top-Level Executive Metric Blocks */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {/* Metric 1: Total Extinguishers */}
            <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 text-center space-y-1">
              <span className="text-xs font-medium text-slate-400 block">إجمالي عدد الطفايات (Total Extinguishers)</span>
              <div className="text-2xl sm:text-3xl font-black font-mono text-slate-100">
                {censusStats.total} <span className="text-xs font-sans text-teal-400 font-normal">أسطوانة وعربة</span>
              </div>
              <span className="text-[11px] text-slate-400 block">موزعة على كافة أجنحة وأدوار المستشفى</span>
            </div>

            {/* Metric 2: Operational Readiness Rate % */}
            <div className="p-3.5 rounded-xl bg-emerald-950/30 border border-emerald-800/70 text-center space-y-1">
              <span className="text-xs font-medium text-emerald-300 block">نسبة الجاهزية والتشغيل (Operational %)</span>
              <div className="text-2xl sm:text-3xl font-black font-mono text-emerald-400">
                {censusStats.operationalRate}%
              </div>
              <span className="text-[11px] text-emerald-400/80 block font-semibold">
                {censusStats.operationalCount} أسطوانة صالحة وسليمة فوراً
              </span>
            </div>

            {/* Metric 3: Needs Maintenance / Recharge */}
            <div className="p-3.5 rounded-xl bg-amber-950/30 border border-amber-800/70 text-center space-y-1">
              <span className="text-xs font-medium text-amber-300 block">بحاجة لصيانة / إعادة تعبئة (Needs Maintenance)</span>
              <div className="text-2xl sm:text-3xl font-black font-mono text-amber-400">
                {censusStats.needsMaintenanceCount} <span className="text-xs font-sans text-amber-300 font-normal">أسطوانة</span>
              </div>
              <span className="text-[11px] text-amber-400/80 block font-semibold">
                ضمن خطة الصيانة والتعبئة الفورية
              </span>
            </div>
          </div>

          {/* Statistical Breakdown Pills: Types & Capacities */}
          <div className="pt-2 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-[11px] text-slate-400 font-bold ml-1">توزيع الأنواع:</span>
              <span className="px-2 py-0.5 rounded-lg bg-blue-950/80 border border-blue-800 text-blue-300 text-[11px] font-mono">
                بودرة جافة ABC: {censusStats.byType.dry_powder.count}
              </span>
              <span className="px-2 py-0.5 rounded-lg bg-slate-800 border border-slate-700 text-slate-200 text-[11px] font-mono">
                ثاني أكسيد الكربون CO2: {censusStats.byType.co2.count}
              </span>
              <span className="px-2 py-0.5 rounded-lg bg-amber-950/80 border border-amber-800 text-amber-300 text-[11px] font-mono">
                رغوة AFFF: {censusStats.byType.foam.count}
              </span>
              <span className="px-2 py-0.5 rounded-lg bg-cyan-950/80 border border-cyan-800 text-cyan-300 text-[11px] font-mono">
                ماء تحت الضغط: {censusStats.byType.water.count}
              </span>
              <span className="px-2 py-0.5 rounded-lg bg-emerald-950/80 border border-emerald-800 text-emerald-300 text-[11px] font-mono">
                مواد كيميائية رطبة K: {censusStats.byType.wet_chemical.count}
              </span>
            </div>
            <div className="text-[11px] text-slate-400 font-mono">
              الأحجام: 2kg, 5kg, 6kg, 6L, 9L/kg, 25kg, 50kg
            </div>
          </div>
        </div>

        {/* 2. Executive Summary Digital KPI Dashboard */}
        <div className="space-y-2.5">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-200 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-teal-400" />
              <span>أولاً: لوحة المؤشرات الرقمية الملخصة (Executive KPI Dashboard)</span>
            </h3>
            <span className="text-[11px] text-slate-400 font-mono">
              مؤشر الامتثال العام: <strong className="text-emerald-400 text-xs">{resolutionRate}%</strong>
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
            {/* Card 1: Total Tours */}
            <div className="printable-card bg-slate-950 border border-slate-800 p-3 rounded-2xl space-y-1 text-center">
              <span className="text-[10px] text-slate-400 block font-medium">الجولات المنفذة</span>
              <span className="text-xl font-black font-mono text-slate-100 block">
                {filteredTours.length}
              </span>
              <span className="text-[9px] text-teal-400 block font-bold">جولة تفتيشية</span>
            </div>

            {/* Card 2: Extinguishers Inspected */}
            <div className="printable-card bg-slate-950 border border-slate-800 p-3 rounded-2xl space-y-1 text-center">
              <span className="text-[10px] text-slate-400 block font-medium">الطفايات المفحوصة</span>
              <span className="text-xl font-black font-mono text-slate-100 block">
                {totalExtinguishers}
              </span>
              <span className="text-[9px] text-blue-400 block font-bold">طفاية بمواقعها</span>
            </div>

            {/* Card 3: Extinguishers Readiness Rate */}
            <div className="printable-card bg-slate-950 border border-slate-800 p-3 rounded-2xl space-y-1 text-center">
              <span className="text-[10px] text-slate-400 block font-medium">نسبة جاهزية الطفايات</span>
              <span className={`text-xl font-black font-mono block ${extinguisherReadinessRate >= 90 ? 'text-emerald-400' : 'text-amber-400'}`}>
                {extinguisherReadinessRate}%
              </span>
              <span className="text-[9px] text-slate-400 block">ضغط وصلاحية</span>
            </div>

            {/* Card 4: Total Violations */}
            <div className="printable-card bg-slate-950 border border-slate-800 p-3 rounded-2xl space-y-1 text-center">
              <span className="text-[10px] text-slate-400 block font-medium">إجمالي المخالفات</span>
              <span className="text-xl font-black font-mono text-slate-100 block">
                {totalViolations}
              </span>
              <span className="text-[9px] text-amber-400 block font-bold">ملاحظة مرصودة</span>
            </div>

            {/* Card 5: Resolved Violations */}
            <div className="printable-card bg-emerald-950/20 border border-emerald-800/60 p-3 rounded-2xl space-y-1 text-center">
              <span className="text-[10px] text-emerald-300 block font-medium">المخالفات المنجزة 🟢</span>
              <span className="text-xl font-black font-mono text-emerald-400 block">
                {resolvedList.length}
              </span>
              <span className="text-[9px] text-emerald-400/80 block font-bold">معالجة بالكامل</span>
            </div>

            {/* Card 6: Overdue / Delayed Violations */}
            <div className="printable-card bg-rose-950/30 border border-rose-800/80 p-3 rounded-2xl space-y-1 text-center">
              <span className="text-[10px] text-rose-300 block font-bold">المتأخرة / لم يُرد 🔴</span>
              <span className="text-xl font-black font-mono text-rose-400 block">
                {overdueList.length}
              </span>
              <span className="text-[9px] text-rose-400 block font-bold">تستوجب المساءلة</span>
            </div>
          </div>
        </div>

        {/* 3. Detailed Violations & Department Interaction Table */}
        <div className="space-y-2.5">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-200 flex items-center gap-2">
              <Layers className="w-4 h-4 text-teal-400" />
              <span>ثانياً: جدول تفصيلي للمخالفات والإشعارات وحالة تفاعل الأقسام</span>
            </h3>
            <span className="text-[11px] text-slate-400">
              (عرض {filteredViolations.length} من أصل {violations.length} مخالفة مسجلة)
            </span>
          </div>

          <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-950">
            <table className="printable-table w-full text-right text-xs">
              <thead>
                <tr className="bg-slate-900 border-b border-slate-800 text-slate-300 font-bold">
                  <th className="p-2.5 w-12 text-center">م</th>
                  <th className="p-2.5 w-28">رقم الإشعار</th>
                  <th className="p-2.5">القسم والموقع الدقيق</th>
                  <th className="p-2.5">الجهة المكلفة / المسؤول</th>
                  <th className="p-2.5 w-28 font-mono">تاريخ الإشعار والمهلة</th>
                  <th className="p-2.5">وصف المخالفة أو الإهمال</th>
                  <th className="p-2.5 w-52">حالة التفاعل والموقف الإداري</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredViolations.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-slate-400 font-medium">
                      <div className="flex flex-col items-center justify-center gap-2 max-w-md mx-auto">
                        <ShieldCheck className="w-8 h-8 text-teal-400/80" />
                        <p className="text-sm font-bold text-slate-200">
                          لا توجد مخالفات أو ملاحظات مسجلة مطابقة للفترة المحددة ({periodMeta[period].title})
                        </p>
                        <p className="text-xs text-slate-400">
                          إجمالي المخالفات المسجلة في النظام ككل: ({violations.length}) مخالفة.
                        </p>
                        <button
                          type="button"
                          onClick={() => {
                            setPeriod('all');
                            setDepartmentFilter('all');
                            setStatusFilter('all');
                          }}
                          className="no-print mt-2 px-4 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold transition shadow-sm"
                        >
                          عرض كافة سجلات المستشفى الشاملة ({violations.length})
                        </button>
                      </div>
                    </td>
                  </tr>
                ) : (
                  filteredViolations.map((v, index) => {
                    const isOverdue = v.status === 'overdue';
                    const isResolved = v.status === 'resolved' || v.status === 'responded';
                    const isPending = v.status === 'pending';
                    const assignedName = v.assignedToCustom || v.assignedTo;

                    return (
                      <tr 
                        key={v.id} 
                        className={
                          isOverdue 
                            ? 'bg-rose-950/25 border-r-4 border-r-rose-600' 
                            : isResolved 
                            ? 'bg-emerald-950/10' 
                            : 'bg-amber-950/10'
                        }
                      >
                        {/* Index */}
                        <td className="p-2.5 text-center font-mono font-bold text-slate-400">
                          {index + 1}
                        </td>

                        {/* ID */}
                        <td className="p-2.5 font-mono font-bold text-slate-300 whitespace-nowrap">
                          {v.id}
                        </td>

                        {/* Department & Location */}
                        <td className="p-2.5">
                          <span className="font-bold text-slate-100 block">{v.department}</span>
                          <span className="text-[11px] text-slate-400 block">{v.locationDetail}</span>
                        </td>

                        {/* Assigned Party */}
                        <td className="p-2.5">
                          <span className="font-semibold text-slate-200 block">{assignedName}</span>
                          {v.recipientPhone && (
                            <span className="text-[10px] font-mono text-slate-400 block dir-ltr text-right">
                              {v.recipientPhone}
                            </span>
                          )}
                        </td>

                        {/* Date & Deadline */}
                        <td className="p-2.5 font-mono text-[11px] text-slate-400 whitespace-nowrap">
                          <div>{v.createdAt}</div>
                          <div className="text-[10px] text-amber-400">مهلة: {v.deadlineHours}h</div>
                        </td>

                        {/* Description */}
                        <td className="p-2.5 text-slate-300 leading-relaxed">
                          <p>{v.description}</p>
                          {v.resolutionNote && (
                            <div className="mt-1 p-1.5 rounded-lg bg-emerald-950/40 border border-emerald-800/60 text-emerald-300 text-[11px]">
                              <strong>إفادة الإنجاز:</strong> {v.resolutionNote}
                            </div>
                          )}
                        </td>

                        {/* Department Interaction Status (CRITICAL REQUIREMENT HIGHLIGHT) */}
                        <td className="p-2.5">
                          {isOverdue && (
                            <div className="p-2 rounded-xl bg-rose-900/60 border-2 border-rose-600 text-rose-100 space-y-1">
                              <span className="inline-flex items-center gap-1 font-black text-rose-200 text-xs uppercase block">
                                <AlertTriangle className="w-3.5 h-3.5 text-rose-300 shrink-0" />
                                <span>🔴 تقصير إداري / متأخر</span>
                              </span>
                              {/* EXPLICIT REQUIRED PHRASE IN BOLD RED */}
                              <p className="font-black text-rose-100 text-[11px] leading-tight underline decoration-rose-400">
                                "معلق / لم يتم الرد أو اتخاذ إجراء حتى تاريخه"
                              </p>
                              <div className="text-[10px] text-rose-300 font-mono">
                                تجاوزت المهلة المحددة ({v.deadlineAt})
                              </div>
                            </div>
                          )}

                          {isResolved && (
                            <div className="p-2 rounded-xl bg-emerald-950/40 border border-emerald-800 text-emerald-200 space-y-0.5">
                              <span className="inline-flex items-center gap-1 font-bold text-emerald-300 text-xs">
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                                <span>🟢 تم الإنجاز والمعالجة</span>
                              </span>
                              <div className="text-[10px] text-slate-300">
                                بواسطة: {v.resolvedBy || 'الجهة المكلفة'}
                              </div>
                            </div>
                          )}

                          {isPending && (
                            <div className="p-2 rounded-xl bg-amber-950/40 border border-amber-800 text-amber-200 space-y-0.5">
                              <span className="inline-flex items-center gap-1 font-bold text-amber-300 text-xs">
                                <Clock className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                                <span>🟡 قيد الإجراء والمتابعة</span>
                              </span>
                              <div className="text-[10px] text-slate-400 font-mono">
                                المهلة تنتهي: {v.deadlineAt}
                              </div>
                            </div>
                          )}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* 3. Safety Inspection Rounds & Patrol Locations */}
        <div className="space-y-2.5 print-avoid-break">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h3 className="text-xs sm:text-sm font-bold text-slate-200 flex items-center gap-2">
                <MapPin className="w-4 h-4 text-teal-400" />
                <span>ثالثاً: أماكن ومسارات جولات السلامة الميدانية (Safety Inspection Rounds & Patrol Locations)</span>
              </h3>
              <p className="text-[11px] text-slate-400">
                حصر وتوثيق مسارات التفتيش الميدانية الدورية المعتمدة عبر كافة مناطق وأقسام المستشفى الحيوية
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] text-teal-300 font-mono bg-teal-950/80 border border-teal-800 px-2.5 py-1 rounded-xl">
                إجمالي المسارات المعتمدة: ({patrolCheckpoints.length}) مساراً
              </span>
              {/* Search bar (hidden in print) */}
              <div className="no-print relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-2" />
                <input
                  type="text"
                  value={patrolSearchTerm}
                  onChange={(e) => setPatrolSearchTerm(e.target.value)}
                  placeholder="بحث في نقاط التفتيش..."
                  className="bg-slate-950 border border-slate-800 rounded-xl pr-8 pl-3 py-1 text-xs text-slate-200 focus:outline-none focus:border-teal-600 w-44"
                />
              </div>
            </div>
          </div>

          <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-950">
            <div className="overflow-x-auto">
              <table className="printable-table w-full text-right text-xs">
                <thead>
                  <tr className="bg-slate-900 border-b border-slate-800 text-slate-300 font-bold">
                    <th className="p-2.5 w-10 text-center">م</th>
                    <th className="p-2.5 w-36">نقطة التفتيش والمسار</th>
                    <th className="p-2.5 w-44">القسم والموقع الدقيق</th>
                    <th className="p-2.5 w-32 font-mono">تاريخ وتوقيت الجولة</th>
                    <th className="p-2.5 w-36">ضابط السلامة / المفتش</th>
                    <th className="p-2.5 w-32 text-center">حالة المسار والجولة</th>
                    <th className="p-2.5">البنود المفحوصة والملاحظات الميدانية</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {displayCheckpoints.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="p-6 text-center text-slate-400">
                        لا توجد نتائج مطابقة لبحث مسارات التفتيش
                      </td>
                    </tr>
                  ) : (
                    displayCheckpoints.map((chk, idx) => {
                      const isAttention = chk.status === 'attention_required';
                      const isScheduled = chk.status === 'scheduled';
                      const isCompleted = chk.status === 'completed';

                      return (
                        <tr key={chk.id} className="hover:bg-slate-900/40 transition">
                          <td className="p-2.5 text-center font-mono text-slate-400 font-bold">
                            {idx + 1}
                          </td>
                          <td className="p-2.5 font-bold text-slate-200">
                            <div className="flex items-center gap-1.5">
                              <MapPin className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                              <span>{chk.checkpointName}</span>
                            </div>
                            <span className="text-[10px] text-teal-400/80 font-mono block">
                              كود: {chk.id}
                            </span>
                          </td>
                          <td className="p-2.5 text-slate-300">
                            <span className="font-semibold text-slate-100 block">{chk.department}</span>
                            <span className="text-[11px] text-slate-400 block">{chk.zone}</span>
                          </td>
                          <td className="p-2.5 font-mono text-slate-300 text-[11px]">
                            <div>{chk.lastChecked}</div>
                            <span className="text-[10px] text-slate-500">فحص دوري معتمد</span>
                          </td>
                          <td className="p-2.5 text-slate-300 text-xs font-medium">
                            <div className="font-bold text-teal-300">{chk.inspectorName}</div>
                            <span className="text-[10px] text-slate-400">رئيس قسم الأمن والسلامة</span>
                          </td>
                          <td className="p-2.5 text-center">
                            {isCompleted && (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-emerald-950/80 border border-emerald-800 text-emerald-300 text-[11px] font-bold">
                                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                                <span>منجز ومطابق</span>
                              </span>
                            )}
                            {isAttention && (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-950/80 border border-amber-800 text-amber-300 text-[11px] font-bold">
                                <AlertTriangle className="w-3 h-3 text-amber-400" />
                                <span>يتطلب متابعة</span>
                              </span>
                            )}
                            {isScheduled && (
                              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-blue-950/80 border border-blue-800 text-blue-300 text-[11px] font-bold">
                                <Clock className="w-3 h-3 text-blue-400" />
                                <span>مجدول دورياً</span>
                              </span>
                            )}
                          </td>
                          <td className="p-2.5 text-slate-300 leading-relaxed text-[11px]">
                            <div className="text-slate-200 mb-1 font-medium">{chk.notes}</div>
                            <div className="flex flex-wrap gap-1">
                              {chk.tasks.map((task, tIdx) => (
                                <span key={tIdx} className="text-[10px] bg-slate-900 px-2 py-0.5 rounded-lg border border-slate-800 text-slate-400 font-mono">
                                  ✓ {task}
                                </span>
                              ))}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* 4. Fire Extinguishers Registry & Census */}
        <div className="space-y-3 print-avoid-break">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-2">
            <div>
              <h3 className="text-xs sm:text-sm font-bold text-slate-200 flex items-center gap-2">
                <Flame className="w-4 h-4 text-rose-400" />
                <span>رابعاً: سجل وحصر مطافئ الحريق الشامل وإحصائيات الجاهزية (Fire Extinguishers Registry & Census)</span>
              </h3>
              <p className="text-[11px] text-slate-400">
                حصر فني ميداني تفصيلي لكافة أسطوانات وعربات الإطفاء ({censusStats.total} أسطوانة) مع فحص الضغط وجداول الصيانة
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] text-emerald-300 font-mono bg-emerald-950/80 border border-emerald-800 px-3 py-1 rounded-xl font-bold">
                الجاهزية التشغيلية: {censusStats.operationalRate}% ({censusStats.operationalCount} صالحة)
              </span>
              {censusStats.needsMaintenanceCount > 0 && (
                <span className="text-[11px] text-amber-300 font-mono bg-amber-950/80 border border-amber-800 px-3 py-1 rounded-xl font-bold">
                  تحتاج صيانة: ({censusStats.needsMaintenanceCount})
                </span>
              )}
            </div>
          </div>

          {/* Extinguisher Statistical Census Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
            {/* Type 1: Dry Powder */}
            <div className="printable-card bg-slate-950 border border-slate-800 p-3 rounded-2xl text-center space-y-1">
              <span className="text-[11px] text-slate-400 block font-medium">بودرة جافة ABC</span>
              <div className="text-xl font-black font-mono text-blue-400">
                {censusStats.byType.dry_powder.count} <span className="text-[10px] text-slate-400 font-sans">أسطوانة</span>
              </div>
              <span className="text-[9px] text-slate-400 block">
                أحجام 2kg, 6kg, 25kg عربة
              </span>
            </div>

            {/* Type 2: CO2 */}
            <div className="printable-card bg-slate-950 border border-slate-800 p-3 rounded-2xl text-center space-y-1">
              <span className="text-[11px] text-slate-400 block font-medium">ثاني أكسيد الكربون CO2</span>
              <div className="text-xl font-black font-mono text-slate-200">
                {censusStats.byType.co2.count} <span className="text-[10px] text-slate-400 font-sans">أسطوانة</span>
              </div>
              <span className="text-[9px] text-slate-400 block">
                أحجام 2kg, 5kg, 20kg للكهرباء
              </span>
            </div>

            {/* Type 3: Foam */}
            <div className="printable-card bg-slate-950 border border-slate-800 p-3 rounded-2xl text-center space-y-1">
              <span className="text-[11px] text-slate-400 block font-medium">رغوة ميكانيكية AFFF</span>
              <div className="text-xl font-black font-mono text-amber-400">
                {censusStats.byType.foam.count} <span className="text-[10px] text-slate-400 font-sans">أسطوانة</span>
              </div>
              <span className="text-[9px] text-slate-400 block">
                أحجام 9L, 50L عربة للمحروقات
              </span>
            </div>

            {/* Type 4: Water */}
            <div className="printable-card bg-slate-950 border border-slate-800 p-3 rounded-2xl text-center space-y-1">
              <span className="text-[11px] text-slate-400 block font-medium">ماء مضغوط Water</span>
              <div className="text-xl font-black font-mono text-cyan-400">
                {censusStats.byType.water.count} <span className="text-[10px] text-slate-400 font-sans">أسطوانة</span>
              </div>
              <span className="text-[9px] text-slate-400 block">
                حجم 9 لتر للمواد الصلبة
              </span>
            </div>

            {/* Type 5: Wet Chemical */}
            <div className="printable-card bg-slate-950 border border-slate-800 p-3 rounded-2xl text-center space-y-1">
              <span className="text-[11px] text-slate-400 block font-medium">كيميائية رطبة K</span>
              <div className="text-xl font-black font-mono text-emerald-400">
                {censusStats.byType.wet_chemical.count} <span className="text-[10px] text-slate-400 font-sans">أسطوانة</span>
              </div>
              <span className="text-[9px] text-slate-400 block">
                فئة K لزيوت المطبخ والمطاعم
              </span>
            </div>
          </div>

          {/* Interactive Filters for Extinguisher Inventory (Hidden during print) */}
          <div className="no-print flex flex-wrap items-center justify-between gap-2 bg-slate-950/70 p-2 rounded-xl border border-slate-800 text-xs">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-slate-400 text-[11px] flex items-center gap-1">
                <Filter className="w-3.5 h-3.5 text-teal-400" />
                <span>تصفية السجل:</span>
              </span>

              {/* Type Filter */}
              <select
                value={extTypeFilter}
                onChange={(e) => setExtTypeFilter(e.target.value)}
                className="bg-slate-900 border border-slate-700 text-slate-200 px-2 py-1 rounded-lg text-xs cursor-pointer"
              >
                <option value="all">كافة الأنواع</option>
                <option value="dry_powder">بودرة جافة ABC</option>
                <option value="co2">ثاني أكسيد الكربون CO2</option>
                <option value="foam">رغوة ميكانيكية AFFF</option>
                <option value="water">ماء مضغوط Water</option>
                <option value="wet_chemical">مواد كيميائية رطبة Class K</option>
              </select>

              {/* Status Filter */}
              <select
                value={extStatusFilter}
                onChange={(e) => setExtStatusFilter(e.target.value)}
                className="bg-slate-900 border border-slate-700 text-slate-200 px-2 py-1 rounded-lg text-xs cursor-pointer"
              >
                <option value="all">كافة الحالات</option>
                <option value="operational">صالحة وجاهزة فوراً 🟢</option>
                <option value="maintenance">تحتاج صيانة / تعبئة ⚠️</option>
              </select>

              {(extTypeFilter !== 'all' || extStatusFilter !== 'all' || extSearchTerm) && (
                <button
                  type="button"
                  onClick={() => {
                    setExtTypeFilter('all');
                    setExtStatusFilter('all');
                    setExtSearchTerm('');
                  }}
                  className="text-slate-400 hover:text-rose-300 text-[11px] font-bold"
                >
                  إلغاء التصفية ✕
                </button>
              )}
            </div>

            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-2" />
              <input
                type="text"
                value={extSearchTerm}
                onChange={(e) => setExtSearchTerm(e.target.value)}
                placeholder="بحث برقم الطفاية أو الموقع..."
                className="bg-slate-900 border border-slate-700 rounded-lg pr-8 pl-3 py-1 text-xs text-slate-200 focus:outline-none focus:border-teal-500 w-52"
              />
            </div>
          </div>

          {/* Extinguishers Detailed Inventory Table */}
          <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-950">
            <div className="overflow-x-auto">
              <table className="printable-table w-full text-right text-xs">
                <thead>
                  <tr className="bg-slate-900 border-b border-slate-800 text-slate-300 font-bold">
                    <th className="p-2.5 w-10 text-center">م</th>
                    <th className="p-2.5 w-28 font-mono">كود ورقم الطفاية</th>
                    <th className="p-2.5 w-48">الموقع التفصيلي الدقيق</th>
                    <th className="p-2.5 w-32">نوع الطفاية</th>
                    <th className="p-2.5 w-20 text-center font-mono">الحجم / السعة</th>
                    <th className="p-2.5 w-28 text-center">مؤشر قياس الضغط</th>
                    <th className="p-2.5 w-28 text-center">الحالة الفنية</th>
                    <th className="p-2.5 w-28 font-mono text-center">تاريخ الفحص الأخير</th>
                    <th className="p-2.5 w-28 font-mono text-center">تاريخ الاستحقاق القادم</th>
                    <th className="p-2.5 w-32">المفتش المعتمد</th>
                    <th className="p-2.5">ملاحظات الفحص والجاهزية</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {displayExtinguishers.length === 0 ? (
                    <tr>
                      <td colSpan={11} className="p-6 text-center text-slate-400">
                        لا توجد طفايات مطابقة للتصفية أو البحث
                      </td>
                    </tr>
                  ) : (
                    displayExtinguishers.map((ext, idx) => {
                      const isOperational = ext.conditionStatus === 'valid' && ext.gaugeStatus === 'normal';
                      const isLow = ext.gaugeStatus === 'low';
                      const isRecharge = ext.gaugeStatus === 'recharge';

                      return (
                        <tr key={ext.id} className="hover:bg-slate-900/40 transition">
                          <td className="p-2.5 text-center font-mono text-slate-400 font-bold">
                            {idx + 1}
                          </td>
                          <td className="p-2.5 font-mono font-bold text-teal-300 text-xs">
                            {ext.serialNumber}
                          </td>
                          <td className="p-2.5 text-slate-200">
                            <span className="font-semibold block">{ext.location}</span>
                            <span className="text-[10px] text-slate-400 block">{ext.zone || ext.department} - {ext.floor || 'الدور المعتمد'}</span>
                          </td>
                          <td className="p-2.5 text-slate-300">
                            <span className="font-bold text-slate-100 block">{ext.typeAr}</span>
                            <span className="text-[10px] text-slate-500 font-mono block">{ext.type}</span>
                          </td>
                          <td className="p-2.5 text-center font-mono font-bold text-slate-200">
                            {ext.capacity || '6 كجم'}
                          </td>
                          <td className="p-2.5 text-center">
                            {ext.gaugeStatus === 'normal' && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-emerald-950/80 border border-emerald-800 text-emerald-300 text-[10px] font-bold">
                                <Gauge className="w-3 h-3 text-emerald-400" />
                                <span>طبيعي 🟢</span>
                              </span>
                            )}
                            {isLow && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-amber-950/80 border border-amber-800 text-amber-300 text-[10px] font-bold">
                                <Gauge className="w-3 h-3 text-amber-400" />
                                <span>منخفض 🟡</span>
                              </span>
                            )}
                            {isRecharge && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-rose-950/80 border border-rose-800 text-rose-300 text-[10px] font-bold">
                                <Gauge className="w-3 h-3 text-rose-400" />
                                <span>إعادة شحن 🔴</span>
                              </span>
                            )}
                          </td>
                          <td className="p-2.5 text-center">
                            {isOperational ? (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-emerald-950/80 border border-emerald-800 text-emerald-300 text-[10px] font-bold">
                                <Check className="w-3 h-3 text-emerald-400" />
                                <span>صالحة وجاهزة</span>
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-amber-950/80 border border-amber-800 text-amber-300 text-[10px] font-bold">
                                <AlertTriangle className="w-3 h-3 text-amber-400" />
                                <span>تحتاج صيانة وتعبئة</span>
                              </span>
                            )}
                          </td>
                          <td className="p-2.5 text-center font-mono text-slate-300 text-[11px]">
                            {ext.lastInspectedDate || ext.lastInspectedAt || ext.lastInspectionDate || '-'}
                          </td>
                          <td className="p-2.5 text-center font-mono text-teal-300 text-[11px] font-bold">
                            {ext.nextInspectionDue || ext.expiryDate}
                          </td>
                          <td className="p-2.5 text-slate-300 text-xs font-medium">
                            <div className="font-bold text-teal-300">{ext.inspectedBy || 'م/ نجيب غازي'}</div>
                            <span className="text-[10px] text-slate-400">ضابط السلامة</span>
                          </td>
                          <td className="p-2.5 text-slate-300 text-[11px] leading-relaxed">
                            {ext.notes}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* 5. Summary of Recommendations & Urgent Safety Requirements */}
        <div 
          id="recommendations-summary-section"
          className="printable-card recommendations-print-section bg-slate-950 border border-teal-800/80 rounded-2xl p-4 sm:p-5 space-y-3"
        >
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="text-xs font-bold text-teal-300 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-teal-400" />
              <span>خامساً: ملخص التوصيات والمتطلبات العاجلة للسلامة المرفوعة للمدير العام</span>
            </h3>
            <span className="text-[10px] text-slate-400 font-mono">التوجيه الإداري الفوري مطلوب</span>
          </div>

          <ol className="list-decimal list-inside space-y-1.5 text-xs text-slate-200 leading-relaxed">
            {customRecommendations.map((rec, idx) => (
              <li key={idx} className="flex items-start justify-between gap-2 group">
                <div className="flex items-start gap-2">
                  <span className="font-bold text-teal-400 font-mono">{idx + 1}.</span>
                  <span>{rec}</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleRemoveRecommendation(idx)}
                  className="no-print text-slate-500 hover:text-rose-400 text-[10px] px-1 transition opacity-0 group-hover:opacity-100"
                  title="حذف هذا البند"
                >
                  ✕
                </button>
              </li>
            ))}
          </ol>

          {/* Inline adder for extra safety officer directives (Hidden in print) */}
          <div className="no-print pt-2 flex items-center gap-2">
            <div className="relative flex-1 flex items-center">
              <input
                type="text"
                value={newRecInput}
                onChange={(e) => setNewRecInput(e.target.value)}
                placeholder="إضافة توصية إدارية خاصة إضافية للعرض على المدير العام... (يمكنك الإملاء بالصوت)"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl pr-3 pl-11 py-1.5 text-xs text-slate-100 focus:outline-none focus:border-teal-500"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddRecommendation();
                  }
                }}
              />
              <div className="absolute left-1.5 top-1">
                <VoiceDictationButton
                  value={newRecInput}
                  onChange={setNewRecInput}
                  title="إملاء صوتي للتوصية الإدارية"
                />
              </div>
            </div>
            <button
              type="button"
              onClick={handleAddRecommendation}
              className="px-3 py-1.5 bg-teal-700 hover:bg-teal-600 text-white rounded-xl text-xs font-bold transition shrink-0"
            >
              + إضافة توصية
            </button>
          </div>
        </div>

        {/* 6. Official Submission Sign-Off Footer */}
        <div className="print-avoid-break pt-4 border-t-2 border-slate-700 space-y-3">
          <div className="printable-card bg-slate-950 border border-teal-800/80 p-4 sm:p-5 rounded-2xl space-y-3">
            <div className="flex flex-wrap items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs font-bold text-teal-300">
                الجهة المُعِدّة والرافعة للتقرير: قسم الأمن والسلامة المهنية
              </span>
              <span className="text-[11px] text-slate-400 font-mono">
                تاريخ الرفع الرسمي: {new Date().toLocaleDateString('ar-EG', { dateStyle: 'full' })}
              </span>
            </div>
            <div className="flex flex-wrap items-center justify-between gap-4 pt-1">
              <div className="space-y-1 text-xs">
                <div className="text-slate-100 font-bold text-sm sm:text-base">
                  إعداد ورفع: م/ نجيب قاسم غازي (رئيس قسم السلامة وإدارة المرافق FMS)
                </div>
                <div className="text-teal-400 text-xs font-semibold">
                  إدارة السلامة وإدارة المرافق (FMS) • مستشفى آزال النموذجي
                </div>
                <p className="text-slate-400 text-[11px] pt-1">
                  تم التدقيق الميداني والمطابقة الرقمية وفقاً لأحدث معايير السلامة المهنية ومكافحة الحريق والأنظمة الصحية المعتمدة.
                </p>
              </div>

              <div className="flex items-center gap-3">
                <div className="px-3 py-1.5 rounded-xl bg-teal-950 border border-teal-700 text-teal-300 text-xs font-mono font-bold">
                  معتمد وموثق رقمياً • OSH-SEC-VERIFIED
                </div>
              </div>
            </div>
          </div>

          <div className="text-center text-[10px] text-slate-400 pt-1 font-mono">
            نظام إدارة الأمن والسلامة الرقمي • مستشفى آزال النموذجي • صنعاء - الجمهورية اليمنية
          </div>
        </div>
      </div>

      {/* CBAHI FOCUS-PDCA Modal */}
      {showFocusPdcaModal && (
        <CbahiFocusPdcaModal
          incidents={incidentsList}
          tours={tours}
          violations={violations}
          extinguishers={extinguishers}
          currentUser={currentUser}
          onClose={() => setShowFocusPdcaModal(false)}
        />
      )}
    </div>
  );
};
