import React, { useState, useEffect } from 'react';
import { 
  Lock, 
  Key, 
  User, 
  Building2, 
  Activity, 
  Server, 
  Flame, 
  Video, 
  Briefcase, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowLeft,
  ShieldCheck,
  Eye,
  EyeOff,
  Sparkles,
  RefreshCw
} from 'lucide-react';
import { PpmDepartmentCategory, PPM_DEPARTMENTS } from '../data/azalPpmAssetsData';
import { verifyDepartmentPin } from '../services/supabaseClient';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';

export interface DepartmentSession {
  engineerName: string;
  departmentId: PpmDepartmentCategory;
  departmentCode: string;
  departmentNameAr: string;
  departmentNameEn: string;
  token: string;
  loginTime: string;
}

export const SESSION_STORAGE_DEPT_KEY = 'azal_dept_pin_session';

export function getStoredDepartmentSession(): DepartmentSession | null {
  try {
    const raw = sessionStorage.getItem(SESSION_STORAGE_DEPT_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.departmentId && parsed.engineerName) {
        return parsed;
      }
    }
  } catch (e) {
    console.warn('Failed to read department session from sessionStorage:', e);
  }
  return null;
}

export function saveDepartmentSession(session: DepartmentSession): void {
  try {
    sessionStorage.setItem(SESSION_STORAGE_DEPT_KEY, JSON.stringify(session));
  } catch (e) {
    console.warn('Failed to save department session to sessionStorage:', e);
  }
}

export function clearDepartmentSession(): void {
  try {
    sessionStorage.removeItem(SESSION_STORAGE_DEPT_KEY);
  } catch (e) {
    console.warn('Failed to clear department session from sessionStorage:', e);
  }
}

interface DepartmentPinLoginProps {
  initialDepartment?: PpmDepartmentCategory | 'all';
  initialEngineerName?: string;
  onLoginSuccess: (session: DepartmentSession) => void;
  onCancel?: () => void;
  title?: string;
  subtitle?: string;
  isModal?: boolean;
}

export const DepartmentPinLogin: React.FC<DepartmentPinLoginProps> = ({
  initialDepartment = 'general_facilities',
  initialEngineerName = '',
  onLoginSuccess,
  onCancel,
  title = 'بوابة تسجيل دخول الأقسام الهندسية (PIN Access)',
  subtitle = 'يرجى اختيار القسم وتأكيد هوية المهندس المناوب وإدخال رمز المرور السري للتحقق عبر Supabase',
  isModal = false,
}) => {
  const [selectedDept, setSelectedDept] = useState<PpmDepartmentCategory>(
    initialDepartment !== 'all' ? initialDepartment : 'general_facilities'
  );
  const [engineerName, setEngineerName] = useState(initialEngineerName);
  const [pin, setPin] = useState('');
  const [showPin, setShowPin] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);

  // Sync if initial props change
  useEffect(() => {
    if (initialDepartment && initialDepartment !== 'all') {
      setSelectedDept(initialDepartment);
    }
  }, [initialDepartment]);

  useEffect(() => {
    if (initialEngineerName && !engineerName) {
      setEngineerName(initialEngineerName);
    }
  }, [initialEngineerName]);

  const getDepartmentIcon = (deptId: PpmDepartmentCategory) => {
    switch (deptId) {
      case 'general_facilities':
        return <Building2 className="w-5 h-5" />;
      case 'biomedical':
        return <Activity className="w-5 h-5" />;
      case 'it_networks':
        return <Server className="w-5 h-5" />;
      case 'medical_gases':
        return <Flame className="w-5 h-5" />;
      case 'cctv_security':
        return <Video className="w-5 h-5" />;
      case 'contractor_assets':
        return <Briefcase className="w-5 h-5" />;
      default:
        return <Building2 className="w-5 h-5" />;
    }
  };

  const handleVerifyAndLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const cleanName = engineerName.trim();
    if (!cleanName) {
      setErrorMessage('يرجى إدخال اسم المهندس أو الفني المناوب المسؤول عن القسم.');
      return;
    }

    const cleanPin = pin.trim();
    if (!cleanPin) {
      setErrorMessage('يرجى إدخال رمز المرور السري (PIN) الخاص بالقسم.');
      return;
    }

    setIsVerifying(true);

    try {
      // Live verification against Supabase department_access_pins table
      const res = await verifyDepartmentPin(selectedDept, cleanPin);

      if (res.valid) {
        setIsSuccess(true);
        triggerSuccessFeedback();

        const currentDeptInfo = PPM_DEPARTMENTS.find((d) => d.id === selectedDept);
        const session: DepartmentSession = {
          engineerName: cleanName,
          departmentId: selectedDept,
          departmentCode: selectedDept,
          departmentNameAr: res.departmentName || currentDeptInfo?.nameAr || 'القسم المعتمد',
          departmentNameEn: currentDeptInfo?.nameEn || selectedDept,
          token: `SEC-PIN-${Date.now()}`,
          loginTime: new Date().toISOString()
        };

        // Save session in sessionStorage
        saveDepartmentSession(session);

        setTimeout(() => {
          onLoginSuccess(session);
        }, 500);
      } else {
        setErrorMessage(res.message || 'عفواً، رمز المرور غير صحيح أو لا ينتمي لهذا القسم.');
      }
    } catch (err) {
      console.error('Department PIN verification error:', err);
      setErrorMessage('حدث خطأ في الاتصال بالخادم أثناء التحقق. يرجى المحاولة مرة ثانية.');
    } finally {
      setIsVerifying(false);
    }
  };

  const currentDeptInfo = PPM_DEPARTMENTS.find((d) => d.id === selectedDept) || PPM_DEPARTMENTS[0];

  const content = (
    <div className="w-full max-w-xl mx-auto bg-slate-900 border border-slate-700/80 rounded-3xl p-5 sm:p-7 shadow-2xl relative overflow-hidden" dir="rtl">
      {/* Background Ambience */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-teal-500/10 rounded-full blur-3xl pointer-events-none -mr-16 -mt-16" />
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none -ml-16 -mb-16" />

      {/* Header */}
      <div className="text-center space-y-2 mb-6 relative">
        <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-teal-500/15 border border-teal-500/30 text-teal-400 shadow-lg shadow-teal-950/40 mb-1">
          <ShieldCheck className="w-7 h-7" />
        </div>
        <h3 className="text-lg sm:text-xl font-black text-white flex items-center justify-center gap-2">
          <span>{title}</span>
        </h3>
        <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto leading-relaxed">
          {subtitle}
        </p>
      </div>

      <form onSubmit={handleVerifyAndLogin} className="space-y-5 relative">
        {/* Step 1: Select Department (6 Grid Badges) */}
        <div className="space-y-2">
          <label className="block text-xs font-bold text-slate-300 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Building2 className="w-3.5 h-3.5 text-teal-400" />
              <span>1. اختر القسم الهندسي المطلوب الدخول إليه:</span>
            </span>
            <span className="text-[10px] text-teal-400 font-mono">6 أقسام معتمدة</span>
          </label>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {PPM_DEPARTMENTS.map((dept) => {
              const isSelected = selectedDept === dept.id;
              return (
                <button
                  key={dept.id}
                  type="button"
                  onClick={() => {
                    setSelectedDept(dept.id);
                    setErrorMessage(null);
                  }}
                  className={`p-2.5 rounded-2xl border text-right transition-all flex flex-col justify-between gap-1.5 ${
                    isSelected
                      ? 'bg-teal-950/60 border-teal-400 ring-2 ring-teal-400/30 text-white shadow-lg shadow-teal-950'
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200 hover:bg-slate-900'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className={`p-1.5 rounded-xl border ${
                      isSelected
                        ? 'bg-teal-500/20 border-teal-400/40 text-teal-300'
                        : 'bg-slate-800 border-slate-700 text-slate-400'
                    }`}>
                      {getDepartmentIcon(dept.id)}
                    </span>
                    {isSelected && (
                      <CheckCircle2 className="w-4 h-4 text-teal-400" />
                    )}
                  </div>
                  <div>
                    <h5 className="text-[11px] font-bold line-clamp-1 leading-snug text-slate-100">
                      {dept.nameAr}
                    </h5>
                    <span className="text-[9px] font-mono text-slate-400 block line-clamp-1">
                      {dept.nameEn}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Department Confirmation Chip */}
        <div className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-teal-500/15 text-teal-400 border border-teal-500/30">
              {getDepartmentIcon(selectedDept)}
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block">القسم المحدد حالياً:</span>
              <strong className="text-xs sm:text-sm text-teal-300 font-bold">
                {currentDeptInfo.nameAr}
              </strong>
            </div>
          </div>
          <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-teal-950 border border-teal-800 text-teal-300">
            {selectedDept}
          </span>
        </div>

        {/* Step 2: Duty Engineer Name */}
        <div className="space-y-1.5">
          <label className="block text-xs font-bold text-slate-300 flex items-center gap-1.5">
            <User className="w-3.5 h-3.5 text-teal-400" />
            <span>2. اسم المهندس / الفني المناوب:</span>
            <span className="text-rose-400">*</span>
          </label>
          <div className="relative">
            <input
              type="text"
              value={engineerName}
              onChange={(e) => {
                setEngineerName(e.target.value);
                if (errorMessage) setErrorMessage(null);
              }}
              placeholder="مثال: م. حسام العنسي / فني الصيانة..."
              className="w-full bg-slate-950 border border-slate-700 rounded-2xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-teal-400 transition"
              required
            />
          </div>
        </div>

        {/* Step 3: Secret PIN Input */}
        <div className="space-y-1.5">
          <label className="block text-xs font-bold text-slate-300 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Key className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-amber-300">
                3. رمز المرور السري (PIN) الخاص بقسم {currentDeptInfo.nameAr}:
              </span>
              <span className="text-rose-400">*</span>
            </span>
          </label>
          <div className="relative">
            <input
              type={showPin ? 'text' : 'password'}
              inputMode="numeric"
              maxLength={10}
              value={pin}
              onChange={(e) => {
                setPin(e.target.value);
                if (errorMessage) setErrorMessage(null);
              }}
              placeholder={`أدخل الرمز السري لقسم ${currentDeptInfo.nameAr}...`}
              className="w-full bg-slate-950 border border-slate-700 rounded-2xl px-4 py-3 pl-12 text-sm text-white font-mono tracking-widest placeholder-slate-500 focus:outline-none focus:border-amber-400 transition"
              required
            />
            <button
              type="button"
              onClick={() => setShowPin(!showPin)}
              className="absolute left-3.5 top-3.5 text-slate-400 hover:text-slate-200 transition"
              title={showPin ? 'إخفاء الرمز' : 'إظهار الرمز'}
            >
              {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Error Notification Alert */}
        {errorMessage && (
          <div className="p-3.5 rounded-2xl bg-rose-950/90 border border-rose-600 text-rose-200 text-xs font-bold flex items-center gap-3 animate-shake">
            <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
            <div className="flex-1">
              <span>{errorMessage}</span>
            </div>
          </div>
        )}

        {/* Success Banner */}
        {isSuccess && (
          <div className="p-3 rounded-2xl bg-emerald-950/90 border border-emerald-500 text-emerald-300 text-xs font-bold flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span>تم التحقق من الرمز بنجاح! جاري تسجيل الدخول وفتح لوحة الأصول...</span>
          </div>
        )}

        {/* Action Buttons */}
        <div className="pt-2 flex items-center gap-3">
          {onCancel && (
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs sm:text-sm font-bold transition flex-1 sm:flex-initial"
            >
              إلغاء
            </button>
          )}

          <button
            type="submit"
            disabled={isVerifying || isSuccess}
            className={`flex-1 py-3.5 px-6 rounded-2xl font-bold text-xs sm:text-sm text-white transition-all flex items-center justify-center gap-2 shadow-lg ${
              isSuccess
                ? 'bg-emerald-500 shadow-emerald-950'
                : 'bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 shadow-teal-950 active:scale-98'
            }`}
          >
            {isVerifying ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>جاري التحقق من Supabase...</span>
              </>
            ) : isSuccess ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>تم الدخول بنجاح ✓</span>
              </>
            ) : (
              <>
                <Lock className="w-4 h-4" />
                <span>تحقق ودخول إلى لوحة القسم</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );

  if (isModal) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-sm overflow-y-auto">
        <div className="my-auto w-full max-w-xl">
          {content}
        </div>
      </div>
    );
  }

  return content;
};
