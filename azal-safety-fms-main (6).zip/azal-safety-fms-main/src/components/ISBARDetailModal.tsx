import React, { useState } from 'react';
import { 
  X, 
  Check, 
  AlertTriangle, 
  Activity, 
  FileText, 
  CheckSquare, 
  Printer, 
  Plus, 
  Trash2, 
  ShieldCheck, 
  User, 
  Heart, 
  Syringe, 
  Stethoscope,
  ArrowLeftRight
} from 'lucide-react';
import { ISBARData, VitalSigns, InvasiveLine } from '../types';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';
import { executeSmartPrint } from '../utils/printUtils';

interface ISBARDetailModalProps {
  patient: ISBARData;
  privacyMode: boolean;
  onClose: () => void;
  onSavePatient: (updated: ISBARData) => void;
  onOpenHandoverModal: (patient: ISBARData) => void;
}

type ISBARTab = 'I' | 'S' | 'B' | 'A' | 'R';

export const ISBARDetailModal: React.FC<ISBARDetailModalProps> = ({
  patient,
  privacyMode,
  onClose,
  onSavePatient,
  onOpenHandoverModal,
}) => {
  const [activeTab, setActiveTab] = useState<ISBARTab>('I');
  const [formData, setFormData] = useState<ISBARData>({ ...patient });
  const [newAllergy, setNewAllergy] = useState('');
  const [newTaskText, setNewTaskText] = useState('');
  const [newTaskUrgency, setNewTaskUrgency] = useState<'high' | 'medium' | 'routine'>('high');
  const [saveToast, setSaveToast] = useState(false);

  const handleVitalChange = (field: keyof VitalSigns, value: number) => {
    setFormData((prev) => ({
      ...prev,
      vitals: {
        ...prev.vitals,
        [field]: value,
        recordedAt: 'الآن (محدث)',
      },
    }));
  };

  const handleToggleTask = (taskId: string) => {
    setFormData((prev) => ({
      ...prev,
      pendingTasks: prev.pendingTasks.map((t) =>
        t.id === taskId ? { ...t, isCompleted: !t.isCompleted } : t
      ),
    }));
  };

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskText.trim()) return;
    const newTask = {
      id: `task-${Date.now()}`,
      text: newTaskText.trim(),
      urgency: newTaskUrgency,
      category: 'procedure' as const,
      isCompleted: false,
    };
    setFormData((prev) => ({
      ...prev,
      pendingTasks: [newTask, ...prev.pendingTasks],
    }));
    setNewTaskText('');
  };

  const handleAddAllergy = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAllergy.trim()) return;
    setFormData((prev) => ({
      ...prev,
      allergies: [...prev.allergies, newAllergy.trim()],
    }));
    setNewAllergy('');
  };

  const handleRemoveAllergy = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      allergies: prev.allergies.filter((_, i) => i !== index),
    }));
  };

  const handleSave = () => {
    onSavePatient(formData);
    setSaveToast(true);
    triggerSuccessFeedback();
    setTimeout(() => setSaveToast(false), 2000);
  };

  const handlePrint = () => {
    triggerSuccessFeedback();

    const bodyHtml = `
      <div style="background:#f8fafc; border:1px solid #cbd5e1; border-radius:8px; padding:16px; margin-bottom:16px;">
        <div style="display:flex; justify-content:space-between; border-bottom:1px solid #e2e8f0; padding-bottom:8px; margin-bottom:12px;">
          <div>
            <h2 style="font-size:16px; font-weight:bold; color:#0f172a; margin:0;">${displayName}</h2>
            <div style="font-size:12px; color:#64748b; margin-top:2px;">MRN: <strong>${formData.mrn}</strong> • العمر: ${formData.age} سنة • الجنس: ${formData.gender === 'male' ? 'ذكر' : 'أنثى'}</div>
          </div>
          <div style="text-align:left;">
            <div style="font-size:12px; font-weight:bold; color:#0d9488;">القسم: ${formData.department}</div>
            <div style="font-size:11px; color:#64748b;">سرير رقم: ${formData.bedNumber} • الطبيب: ${formData.attendingPhysician}</div>
          </div>
        </div>

        <div class="summary-grid" style="margin-bottom:12px;">
          <div class="summary-card"><div class="val" style="font-size:14px;">${formData.vitalSigns?.bp || '-'}</div><div class="lbl">ضغط الدم (BP)</div></div>
          <div class="summary-card"><div class="val" style="font-size:14px;">${formData.vitalSigns?.hr || '-'} bpm</div><div class="lbl">النبض (HR)</div></div>
          <div class="summary-card"><div class="val" style="font-size:14px;">${formData.vitalSigns?.spo2 || '-'}%</div><div class="lbl">الأكسجين (SpO2)</div></div>
          <div class="summary-card"><div class="val" style="font-size:14px;">${formData.vitalSigns?.temp || '-'}°C</div><div class="lbl">الحرارة (Temp)</div></div>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; font-size:12px; margin-top:12px;">
          <div style="border:1px solid #e2e8f0; border-radius:6px; padding:10px; background:#fff;">
            <strong style="color:#0d9488; display:block; margin-bottom:4px;">1. التعريف والحالة الراهنة (Situation):</strong>
            <p style="margin:0; color:#334155;">${formData.situation || 'مستقر'}</p>
          </div>
          <div style="border:1px solid #e2e8f0; border-radius:6px; padding:10px; background:#fff;">
            <strong style="color:#0d9488; display:block; margin-bottom:4px;">2. الخلفية السريرية (Background):</strong>
            <p style="margin:0; color:#334155;">${formData.background || 'لا توجد سوابق حرجة'}</p>
          </div>
          <div style="border:1px solid #e2e8f0; border-radius:6px; padding:10px; background:#fff;">
            <strong style="color:#0d9488; display:block; margin-bottom:4px;">3. التقييم التمريضي (Assessment):</strong>
            <p style="margin:0; color:#334155;">${formData.assessment || 'تحت الملاحظة المستمرة'}</p>
          </div>
          <div style="border:1px solid #e2e8f0; border-radius:6px; padding:10px; background:#fff;">
            <strong style="color:#0d9488; display:block; margin-bottom:4px;">4. التوصيات وخطة التسليم (Recommendation):</strong>
            <p style="margin:0; color:#334155;">${formData.recommendation || 'متابعة العلامات الحيوية'}</p>
          </div>
        </div>

        ${formData.allergies && formData.allergies.length > 0 ? `
          <div style="margin-top:12px; padding:8px 12px; background:#fef2f2; border:1px solid #fecaca; border-radius:6px; font-size:12px; color:#991b1b;">
            <strong>⚠ الحساسية والتحذيرات:</strong> ${formData.allergies.join('، ')}
          </div>
        ` : ''}
      </div>
    `;

    executeSmartPrint(bodyHtml, {
      title: `بطاقة التسليم السريري للمريض (ISBAR Clinical Handover) - ${formData.mrn}`,
      subtitle: 'مستشفى آزال النموذجي • هيئة التمريض السريري • معيار السلامة الوطنية CBAHI',
      refNumber: `AZAL-ISBAR-${formData.mrn}`
    });
  };

  // Privacy display helpers
  const displayName = privacyMode
    ? formData.fullName.split(' ').map((w, i) => (i === 0 ? w[0] + '***' : w)).join(' ')
    : formData.fullName;

  return (
    <div id="isbar-modal-overlay" className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-3xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Top Bar */}
        <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-teal-950 border border-teal-800 text-teal-400">
              <Stethoscope className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-slate-100">{displayName}</h2>
                <span className="text-xs font-mono text-teal-400 bg-teal-950 px-2 py-0.5 rounded border border-teal-800">
                  {formData.bedNumber}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-mono">
                {privacyMode ? formData.mrn.replace(/\d(?=\d{2})/g, '*') : formData.mrn} • {formData.department}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrint}
              title="طباعة تقرير التسليم"
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-100 transition"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* ISBAR Step Navigation Tabs (Android Material Tabs) */}
        <div className="grid grid-cols-5 bg-slate-950/70 border-b border-slate-800 text-center font-medium text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('I')}
            className={`py-2.5 px-1 border-b-2 transition-all flex flex-col sm:flex-row items-center justify-center gap-1 ${
              activeTab === 'I'
                ? 'border-teal-400 text-teal-300 font-bold bg-teal-950/30'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="font-mono text-xs px-1.5 py-0.5 rounded bg-slate-800">I</span>
            <span>التعريف</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('S')}
            className={`py-2.5 px-1 border-b-2 transition-all flex flex-col sm:flex-row items-center justify-center gap-1 ${
              activeTab === 'S'
                ? 'border-teal-400 text-teal-300 font-bold bg-teal-950/30'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="font-mono text-xs px-1.5 py-0.5 rounded bg-slate-800">S</span>
            <span>الحالة</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('B')}
            className={`py-2.5 px-1 border-b-2 transition-all flex flex-col sm:flex-row items-center justify-center gap-1 ${
              activeTab === 'B'
                ? 'border-teal-400 text-teal-300 font-bold bg-teal-950/30'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="font-mono text-xs px-1.5 py-0.5 rounded bg-slate-800">B</span>
            <span>الخلفية</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('A')}
            className={`py-2.5 px-1 border-b-2 transition-all flex flex-col sm:flex-row items-center justify-center gap-1 ${
              activeTab === 'A'
                ? 'border-teal-400 text-teal-300 font-bold bg-teal-950/30'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="font-mono text-xs px-1.5 py-0.5 rounded bg-slate-800">A</span>
            <span>التقييم</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('R')}
            className={`py-2.5 px-1 border-b-2 transition-all flex flex-col sm:flex-row items-center justify-center gap-1 ${
              activeTab === 'R'
                ? 'border-teal-400 text-teal-300 font-bold bg-teal-950/30'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="font-mono text-xs px-1.5 py-0.5 rounded bg-slate-800">R</span>
            <span>التوصيات</span>
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 text-right">
          {/* TAB I: Introduction (التعريف بالهوية) */}
          {activeTab === 'I' && (
            <div className="space-y-4">
              <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 space-y-3">
                <h3 className="text-xs font-bold text-teal-400 flex items-center gap-1.5">
                  <User className="w-4 h-4" />
                  <span>بيانات التعريف وهوية المريض (Introduction)</span>
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="text-slate-400 block mb-1">اسم المريض الكامل:</label>
                    <input
                      type="text"
                      value={formData.fullName}
                      onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1">رقم الملف الطبي (MRN):</label>
                    <input
                      type="text"
                      value={formData.mrn}
                      onChange={(e) => setFormData({ ...formData, mrn: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100 font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1">السرير / الغرفة:</label>
                    <input
                      type="text"
                      value={formData.bedNumber}
                      onChange={(e) => setFormData({ ...formData, bedNumber: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100 font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1">القسم الطبي:</label>
                    <input
                      type="text"
                      value={formData.department}
                      onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1">الطبيب المعالج / الاستشاري:</label>
                    <input
                      type="text"
                      value={formData.attendingPhysician}
                      onChange={(e) => setFormData({ ...formData, attendingPhysician: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100"
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1">تاريخ الدخول للمستشفى:</label>
                    <input
                      type="date"
                      value={formData.admissionDate}
                      onChange={(e) => setFormData({ ...formData, admissionDate: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100 font-mono"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB S: Situation (الحالة الراهنة) */}
          {activeTab === 'S' && (
            <div className="space-y-4">
              <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 space-y-3">
                <h3 className="text-xs font-bold text-teal-400 flex items-center gap-1.5">
                  <Activity className="w-4 h-4" />
                  <span>الحالة الراهنة ومستوى الخطورة (Situation)</span>
                </h3>

                <div>
                  <label className="text-xs text-slate-400 block mb-1">التشخيص الطبي الحالي:</label>
                  <textarea
                    rows={2}
                    value={formData.primaryDiagnosis}
                    onChange={(e) => setFormData({ ...formData, primaryDiagnosis: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-xs text-slate-100"
                  />
                </div>

                <div>
                  <label className="text-xs text-slate-400 block mb-1">ملخص الحالة خلال الوردية:</label>
                  <textarea
                    rows={3}
                    value={formData.currentConditionSummary}
                    onChange={(e) => setFormData({ ...formData, currentConditionSummary: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-xs text-slate-100"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div>
                    <label className="text-slate-400 block mb-1">مستوى الحدة السريرية (Acuity):</label>
                    <select
                      value={formData.acuity}
                      onChange={(e) => setFormData({ ...formData, acuity: e.target.value as any })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100 font-medium"
                    >
                      <option value="critical">أحمر (حرج - Acuity 1)</option>
                      <option value="guard">برتقالي (مراقبة - Acuity 2)</option>
                      <option value="stable">أخضر (مستقر - Acuity 3)</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-slate-400 block mb-1">حالة الإنعاش (Code Status):</label>
                    <select
                      value={formData.codeStatus}
                      onChange={(e) => setFormData({ ...formData, codeStatus: e.target.value as any })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100"
                    >
                      <option value="full_code">إنعاش كامل (Full Code)</option>
                      <option value="dnr">عدم الإنعاش (DNR)</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-slate-400 block mb-1">احتياطات العزل الطبي:</label>
                    <select
                      value={formData.isolation}
                      onChange={(e) => setFormData({ ...formData, isolation: e.target.value as any })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100"
                    >
                      <option value="none">بدون عزل (قياسي)</option>
                      <option value="contact">عزل تلامس (Contact)</option>
                      <option value="droplet">عزل رذاذ (Droplet)</option>
                      <option value="airborne">عزل هوائي (Airborne N95)</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB B: Background (الخلفية المرضية) */}
          {activeTab === 'B' && (
            <div className="space-y-4">
              {/* Allergies Box */}
              <div className="bg-rose-950/20 border border-rose-900/60 p-3.5 rounded-xl space-y-3">
                <h3 className="text-xs font-bold text-rose-300 flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-rose-400" />
                  <span>الحساسيات المسجلة (High Alert Allergies)</span>
                </h3>

                <div className="flex flex-wrap gap-2">
                  {formData.allergies.map((alg, index) => (
                    <span
                      key={index}
                      className="bg-rose-950/80 border border-rose-800 text-rose-200 text-xs px-2.5 py-1 rounded-lg flex items-center gap-1.5"
                    >
                      <span>{alg}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveAllergy(index)}
                        className="text-rose-400 hover:text-rose-100"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </span>
                  ))}
                </div>

                <form onSubmit={handleAddAllergy} className="flex gap-2">
                  <input
                    type="text"
                    placeholder="إضافة تحسس دوائي أو غذائي جديد..."
                    value={newAllergy}
                    onChange={(e) => setNewAllergy(e.target.value)}
                    className="flex-1 bg-slate-900 border border-rose-800/70 rounded-lg p-2 text-xs text-slate-100 placeholder-slate-500"
                  />
                  <button
                    type="submit"
                    className="bg-rose-700 hover:bg-rose-600 text-white px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>إضافة</span>
                  </button>
                </form>
              </div>

              {/* Medical & Surgical History */}
              <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 space-y-3 text-xs">
                <h3 className="text-xs font-bold text-teal-400">التاريخ المرضي والجراحي السابق</h3>
                <div>
                  <label className="text-slate-400 block mb-1">الأمراض المزمنة (Medical History):</label>
                  <input
                    type="text"
                    value={formData.medicalHistory.join('، ')}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        medicalHistory: e.target.value.split('،').map((s) => s.trim()),
                      })
                    }
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">العمليات الجراحية السابقة:</label>
                  <input
                    type="text"
                    value={formData.surgicalHistory.join('، ')}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        surgicalHistory: e.target.value.split('،').map((s) => s.trim()),
                      })
                    }
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">الحمية الغذائية الحالية:</label>
                  <input
                    type="text"
                    value={formData.currentDiet}
                    onChange={(e) => setFormData({ ...formData, currentDiet: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB A: Assessment (التقييم السريري) */}
          {activeTab === 'A' && (
            <div className="space-y-4">
              <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 space-y-3">
                <h3 className="text-xs font-bold text-teal-400 flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Heart className="w-4 h-4 text-rose-400" />
                    <span>العلامات الحيوية المقاسة (Vital Signs)</span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">
                    آخر تسجيل: {formData.vitals.recordedAt}
                  </span>
                </h3>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
                  <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                    <label className="text-slate-400 block mb-1 text-[11px]">ضغط الدم الانقباضي (SYS):</label>
                    <input
                      type="number"
                      value={formData.vitals.bpSystolic}
                      onChange={(e) => handleVitalChange('bpSystolic', Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 text-center font-mono font-bold text-slate-100"
                    />
                  </div>

                  <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                    <label className="text-slate-400 block mb-1 text-[11px]">ضغط الدم الانبساطي (DIA):</label>
                    <input
                      type="number"
                      value={formData.vitals.bpDiastolic}
                      onChange={(e) => handleVitalChange('bpDiastolic', Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 text-center font-mono font-bold text-slate-100"
                    />
                  </div>

                  <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                    <label className="text-slate-400 block mb-1 text-[11px]">معدل النبض (HR bpm):</label>
                    <input
                      type="number"
                      value={formData.vitals.heartRate}
                      onChange={(e) => handleVitalChange('heartRate', Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 text-center font-mono font-bold text-slate-100"
                    />
                  </div>

                  <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                    <label className="text-slate-400 block mb-1 text-[11px]">الأكسجين (SpO2 %):</label>
                    <input
                      type="number"
                      value={formData.vitals.oxygenSat}
                      onChange={(e) => handleVitalChange('oxygenSat', Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 text-center font-mono font-bold text-slate-100"
                    />
                  </div>

                  <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                    <label className="text-slate-400 block mb-1 text-[11px]">الحرارة (°C):</label>
                    <input
                      type="number"
                      step="0.1"
                      value={formData.vitals.temperature}
                      onChange={(e) => handleVitalChange('temperature', Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 text-center font-mono font-bold text-slate-100"
                    />
                  </div>

                  <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                    <label className="text-slate-400 block mb-1 text-[11px]">معدل التنفس (RR /min):</label>
                    <input
                      type="number"
                      value={formData.vitals.respRate}
                      onChange={(e) => handleVitalChange('respRate', Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 text-center font-mono font-bold text-slate-100"
                    />
                  </div>

                  <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                    <label className="text-slate-400 block mb-1 text-[11px]">درجة الألم (Pain 0-10):</label>
                    <input
                      type="number"
                      min="0"
                      max="10"
                      value={formData.vitals.painScore}
                      onChange={(e) => handleVitalChange('painScore', Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 text-center font-mono font-bold text-slate-100"
                    />
                  </div>

                  <div className="bg-slate-900 p-2 rounded-lg border border-slate-800">
                    <label className="text-slate-400 block mb-1 text-[11px]">مقياس الوعي (GCS 3-15):</label>
                    <input
                      type="number"
                      min="3"
                      max="15"
                      value={formData.vitals.gcs}
                      onChange={(e) => handleVitalChange('gcs', Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 text-center font-mono font-bold text-slate-100"
                    />
                  </div>
                </div>
              </div>

              {/* Lines and Tubes */}
              <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 space-y-2 text-xs">
                <h3 className="text-xs font-bold text-teal-400 flex items-center gap-1.5">
                  <Syringe className="w-4 h-4 text-teal-400" />
                  <span>القساطر والأنابيب المتصلة (Lines, Drains & Tubes)</span>
                </h3>
                {formData.invasiveLines.map((line) => (
                  <div
                    key={line.id}
                    className="flex items-center justify-between p-2 rounded-lg bg-slate-900 border border-slate-800"
                  >
                    <div>
                      <span className="font-bold text-slate-200">{line.typeAr}</span>
                      <span className="text-slate-400 text-[11px] block">{line.location} (أدخلت بتاريخ: {line.insertedDate})</span>
                    </div>
                    <span className={`text-[10px] px-2 py-0.5 rounded font-medium ${line.status === 'clean' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-amber-950 text-amber-300 border border-amber-800'}`}>
                      {line.status === 'clean' ? 'نظيفة ومثبتة' : 'واجبة التغيير'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB R: Recommendation (التوصيات والمهام المعلقة) */}
          {activeTab === 'R' && (
            <div className="space-y-4">
              {/* Critical Alert Notes */}
              <div className="bg-amber-950/20 border border-amber-900/60 p-3.5 rounded-xl space-y-2">
                <label className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  <span>تنبيهات وملاحظات حرجة للوردية القادمة:</span>
                </label>
                <textarea
                  rows={2}
                  value={formData.criticalAlertNotes}
                  onChange={(e) => setFormData({ ...formData, criticalAlertNotes: e.target.value })}
                  className="w-full bg-slate-900 border border-amber-800/70 rounded-lg p-2 text-xs text-slate-100"
                />
              </div>

              {/* Pending Tasks Checklist */}
              <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 space-y-3">
                <h3 className="text-xs font-bold text-teal-400 flex items-center gap-1.5">
                  <CheckSquare className="w-4 h-4" />
                  <span>قائمة المهام السريرية المعلقة (Pending Tasks)</span>
                </h3>

                <div className="space-y-2">
                  {formData.pendingTasks.map((task) => (
                    <div
                      key={task.id}
                      onClick={() => handleToggleTask(task.id)}
                      className={`p-2.5 rounded-xl border cursor-pointer flex items-start gap-2.5 transition-all ${
                        task.isCompleted
                          ? 'bg-slate-950/50 border-slate-800 text-slate-500 line-through'
                          : 'bg-slate-900 border-slate-700 text-slate-200 hover:border-teal-600'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={task.isCompleted}
                        onChange={() => {}}
                        className="mt-0.5 h-4 w-4 rounded bg-slate-800 border-slate-700 text-teal-500 focus:ring-teal-400"
                      />
                      <div className="flex-1 text-xs">
                        <span className="leading-relaxed">{task.text}</span>
                        <div className="mt-1 flex items-center gap-2">
                          <span className={`text-[10px] px-1.5 py-0.2 rounded font-semibold ${
                            task.urgency === 'high'
                              ? 'bg-rose-950 text-rose-300'
                              : task.urgency === 'medium'
                              ? 'bg-amber-950 text-amber-300'
                              : 'bg-slate-800 text-slate-400'
                          }`}>
                            {task.urgency === 'high' ? 'عاجل جداً' : task.urgency === 'medium' ? 'أولوية متوسطة' : 'روتيني'}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Add new task */}
                <form onSubmit={handleAddTask} className="flex gap-2 pt-2 border-t border-slate-800">
                  <input
                    type="text"
                    placeholder="إضافة مهمة جديدة للوردية القادمة (تحليل، دواء، استشارة)..."
                    value={newTaskText}
                    onChange={(e) => setNewTaskText(e.target.value)}
                    className="flex-1 bg-slate-900 border border-slate-700 rounded-lg p-2 text-xs text-slate-100 placeholder-slate-500"
                  />
                  <select
                    value={newTaskUrgency}
                    onChange={(e) => setNewTaskUrgency(e.target.value as any)}
                    className="bg-slate-900 border border-slate-700 rounded-lg p-2 text-xs text-slate-300"
                  >
                    <option value="high">عاجل</option>
                    <option value="medium">متوسط</option>
                    <option value="routine">روتيني</option>
                  </select>
                  <button
                    type="submit"
                    className="bg-teal-600 hover:bg-teal-500 text-white px-3 py-1.5 rounded-lg text-xs font-bold"
                  >
                    إضافة
                  </button>
                </form>
              </div>

              {/* Discharge Plan */}
              <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800 space-y-1 text-xs">
                <label className="text-slate-400 block font-semibold">خطة الخروج / النقل المستقبلية (Discharge / Transfer Plan):</label>
                <input
                  type="text"
                  value={formData.dischargePlan}
                  onChange={(e) => setFormData({ ...formData, dischargePlan: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-slate-100"
                />
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer Controls */}
        <div className="bg-slate-950 p-3 border-t border-slate-800 flex items-center justify-between gap-2">
          {saveToast && (
            <span className="text-xs text-emerald-400 font-bold flex items-center gap-1 animate-fade-in">
              <Check className="w-4 h-4" />
              <span>تم حفظ التعديلات السريرية بنجاح</span>
            </span>
          )}
          {!saveToast && <div />}

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleSave}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition"
            >
              حفظ التعديلات
            </button>

            <button
              type="button"
              onClick={() => {
                onSavePatient(formData);
                onOpenHandoverModal(formData);
              }}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white text-xs font-bold shadow-md flex items-center gap-1.5 transition"
            >
              <ArrowLeftRight className="w-4 h-4" />
              <span>بدء التوقيع المزدوج للتسليم والاستلام</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
