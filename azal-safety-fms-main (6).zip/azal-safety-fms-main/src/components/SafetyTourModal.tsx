import React, { useState, useRef } from 'react';
import { 
  ShieldCheck, 
  AlertTriangle, 
  Camera, 
  CheckSquare, 
  Square, 
  Plus, 
  X, 
  Save, 
  Building2, 
  UserCheck, 
  Clock, 
  UploadCloud,
  Image as ImageIcon
} from 'lucide-react';
import { SafetyTourRecord, SafetyViolationNotice, StaffUser } from '../types';
import { AZAL_DEPARTMENTS, SAFETY_TOUR_TASKS, ASSIGNED_PARTIES } from '../data/azalSafetyUpgradeData';
import { 
  sanitizeInput, 
  validateImageFile, 
  generateSecureViolationId 
} from '../utils/securityUtils';
import { VoiceDictationButton } from './VoiceDictationButton';

interface SafetyTourModalProps {
  currentUser: StaffUser;
  initialTour?: SafetyTourRecord | null;
  onClose: () => void;
  onSaveTour: (tour: SafetyTourRecord, autoViolation?: SafetyViolationNotice) => void;
}

export const SafetyTourModal: React.FC<SafetyTourModalProps> = ({
  currentUser,
  initialTour,
  onClose,
  onSaveTour,
}) => {
  // Tour main fields
  const [department, setDepartment] = useState(initialTour ? initialTour.department : AZAL_DEPARTMENTS[0]);
  const [isCustomDepartment, setIsCustomDepartment] = useState(
    Boolean(initialTour?.customDepartment || (initialTour && !AZAL_DEPARTMENTS.includes(initialTour.department)))
  );
  const [customDepartmentName, setCustomDepartmentName] = useState(initialTour?.customDepartment || (initialTour && !AZAL_DEPARTMENTS.includes(initialTour.department) ? initialTour.department : ''));
  const [inspectorName, setInspectorName] = useState(initialTour?.inspectorName || 'م/ نجيب غازي');
  const [inspectorRole, setInspectorRole] = useState(initialTour?.inspectorRole || 'رئيس قسم الأمن والسلامة');
  const [tourDate, setTourDate] = useState(initialTour?.tourDate || new Date().toISOString().split('T')[0]);

  // Tasks Multi-select
  const [selectedTasks, setSelectedTasks] = useState<string[]>(
    initialTour?.tasks || [
      SAFETY_TOUR_TASKS[0],
      SAFETY_TOUR_TASKS[1],
      SAFETY_TOUR_TASKS[2],
      SAFETY_TOUR_TASKS[3],
    ]
  );

  const [tourNotes, setTourNotes] = useState(initialTour?.notes || 'تم إجراء الجولة الميدانية والتأكد من مطابقة اشتراطات السلامة العامة.');

  // Immediate Violation Toggle
  const [hasViolation, setHasViolation] = useState(Boolean(initialTour?.hasViolation));
  const [violationDescription, setViolationDescription] = useState('');
  const [requiredAction, setRequiredAction] = useState('');
  const [violationSeverity, setViolationSeverity] = useState<'low' | 'medium' | 'high' | 'critical'>('high');
  const [violationLocationDetail, setViolationLocationDetail] = useState('');
  const [assignedTo, setAssignedTo] = useState(ASSIGNED_PARTIES[0]);
  const [isCustomAssignedTo, setIsCustomAssignedTo] = useState(false);
  const [customAssignedToText, setCustomAssignedToText] = useState('');
  const [deadlineHours, setDeadlineHours] = useState<number>(24);
  const [violationPhotoUrl, setViolationPhotoUrl] = useState<string>('');
  const [recipientPhone, setRecipientPhone] = useState<string>('');

  const fileInputRef = useRef<HTMLInputElement>(null);

  const toggleTask = (task: string) => {
    if (selectedTasks.includes(task)) {
      setSelectedTasks(selectedTasks.filter((t) => t !== task));
    } else {
      setSelectedTasks([...selectedTasks, task]);
    }
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Strict file validation: MIME, size, magic bytes
      const validation = await validateImageFile(file, 5);
      if (!validation.valid) {
        alert(validation.error || 'الملف المرفوع غير صالح.');
        if (fileInputRef.current) fileInputRef.current.value = '';
        return;
      }

      const reader = new FileReader();
      reader.onload = () => {
        setViolationPhotoUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const cleanCustomDept = sanitizeInput(customDepartmentName);
    const resolvedDept = isCustomDepartment && cleanCustomDept
      ? cleanCustomDept
      : department;

    const tourId = initialTour?.id || `tour-${Date.now()}`;
    let autoViolation: SafetyViolationNotice | undefined = undefined;

    if (hasViolation) {
      const cleanDesc = sanitizeInput(violationDescription);
      if (!cleanDesc) {
        alert('يرجى كتابة وصف المخالفة المرصودة');
        return;
      }

      // Generate cryptographically secure UUID v4 violation ID and unguessable token
      const { id: violationId, publicToken } = generateSecureViolationId();
      const now = new Date();
      const deadlineDate = new Date(now.getTime() + deadlineHours * 60 * 60 * 1000);

      autoViolation = {
        id: violationId,
        publicToken,
        tourId,
        createdAt: now.toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' }),
        timestamp: now.getTime(),
        department: resolvedDept,
        locationDetail: sanitizeInput(violationLocationDetail) || `في نطاق ${resolvedDept}`,
        assignedTo: isCustomAssignedTo ? 'أخرى' : assignedTo,
        assignedToCustom: isCustomAssignedTo ? sanitizeInput(customAssignedToText) : undefined,
        recipientPhone: sanitizeInput(recipientPhone) || undefined,
        description: cleanDesc,
        requiredAction: sanitizeInput(requiredAction) || undefined,
        severity: violationSeverity,
        beforePhotoUrl: violationPhotoUrl,
        deadlineHours,
        deadlineAt: deadlineDate.toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' }),
        status: 'pending',
        synced: false,
      };
    }

    const newTour: SafetyTourRecord = {
      id: tourId,
      department: resolvedDept,
      customDepartment: isCustomDepartment ? cleanCustomDept : undefined,
      inspectorName: sanitizeInput(inspectorName),
      inspectorRole: sanitizeInput(inspectorRole),
      tourDate,
      timestamp: Date.now(),
      tasks: selectedTasks,
      hasViolation,
      violationId: autoViolation?.id,
      notes: sanitizeInput(tourNotes),
      synced: false,
    };

    onSaveTour(newTour, autoViolation);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-3 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl my-auto animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-gradient-to-r from-teal-950 via-slate-900 to-slate-900 p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-teal-950 border border-teal-700 text-teal-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <span>{initialTour ? 'تعديل سجل جولة تفتيش السلامة الميدانية' : 'نموذج تسجيل جولة تفتيش السلامة الميدانية'}</span>
                <span className="text-[10px] bg-teal-900 text-teal-300 px-2 py-0.5 rounded font-mono font-bold">
                  {initialTour ? initialTour.id : 'OSH Tour'}
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                مستشفى آزال النموذجي • إدارة الأمن والسلامة
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 space-y-4 text-xs text-right max-h-[80vh] overflow-y-auto">
          {/* Department & Inspector Info */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Department Selection with Custom Add Option */}
            <div>
              <label className="block text-slate-300 font-bold mb-1">
                القسم المستهدف بالجولة <span className="text-teal-400">*</span>
              </label>
              {!isCustomDepartment ? (
                <div className="space-y-1.5">
                  <select
                    value={department}
                    onChange={(e) => {
                      if (e.target.value === '__add_new__') {
                        setIsCustomDepartment(true);
                      } else {
                        setDepartment(e.target.value);
                      }
                    }}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 text-xs focus:outline-none focus:border-teal-500"
                  >
                    {AZAL_DEPARTMENTS.map((dept) => (
                      <option key={dept} value={dept}>
                        {dept}
                      </option>
                    ))}
                    <option value="__add_new__" className="text-teal-400 font-bold">
                      ➕ [إضافة قسم جديد يدوياً...]
                    </option>
                  </select>
                </div>
              ) : (
                <div className="flex items-center gap-1.5">
                  <input
                    type="text"
                    required
                    placeholder="اكتب اسم القسم الجديد يدوياً..."
                    value={customDepartmentName}
                    onChange={(e) => setCustomDepartmentName(e.target.value)}
                    className="flex-1 bg-slate-950 border border-teal-600 rounded-xl px-3 py-2 text-slate-100 text-xs focus:outline-none focus:ring-1 focus:ring-teal-500"
                    autoFocus
                  />
                  <button
                    type="button"
                    onClick={() => setIsCustomDepartment(false)}
                    className="px-2.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs"
                    title="الرجوع للقائمة"
                  >
                    إلغاء
                  </button>
                </div>
              )}
            </div>

            {/* Inspector Name */}
            <div>
              <label className="block text-slate-300 font-bold mb-1">
                اسم المفتش المسؤول <span className="text-teal-400">*</span>
              </label>
              <input
                type="text"
                required
                value={inspectorName}
                onChange={(e) => setInspectorName(e.target.value)}
                placeholder="اسم ضابط أو مفتش السلامة"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 text-xs focus:outline-none focus:border-teal-500"
              />
            </div>
          </div>

          {/* Tour Date & Role */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-300 font-bold mb-1">
                تاريخ الجولة الميدانية
              </label>
              <input
                type="date"
                value={tourDate}
                onChange={(e) => setTourDate(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 text-xs focus:outline-none focus:border-teal-500 font-mono"
              />
            </div>
            <div>
              <label className="block text-slate-300 font-bold mb-1">
                الصفة / الوظيفة
              </label>
              <input
                type="text"
                value={inspectorRole}
                onChange={(e) => setInspectorRole(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 text-xs focus:outline-none focus:border-teal-500"
              />
            </div>
          </div>

          {/* Multi-Select Tasks Checklist */}
          <div>
            <label className="block text-slate-300 font-bold mb-1.5 flex items-center justify-between">
              <span>مهام التفتيش والفحص المنجزة في الجولة (خيارات متعددة):</span>
              <span className="text-teal-400 text-[11px]">
                تم تحديد ({selectedTasks.length}) من ({SAFETY_TOUR_TASKS.length})
              </span>
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 bg-slate-950/70 border border-slate-800 rounded-xl p-3">
              {SAFETY_TOUR_TASKS.map((task) => {
                const isSelected = selectedTasks.includes(task);
                return (
                  <button
                    key={task}
                    type="button"
                    onClick={() => toggleTask(task)}
                    className={`flex items-start gap-2.5 p-2 rounded-lg text-right transition border ${
                      isSelected
                        ? 'bg-teal-950/60 border-teal-700/80 text-teal-200'
                        : 'bg-slate-900/60 border-slate-800/80 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {isSelected ? (
                      <CheckSquare className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
                    ) : (
                      <Square className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                    )}
                    <span className="text-xs leading-relaxed">{task}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* General Tour Notes */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-slate-300 font-bold">
                ملاحظات عامة حول الجولة
              </label>
              <VoiceDictationButton
                value={tourNotes}
                onChange={setTourNotes}
                showLabel
                title="إملاء صوتي لملاحظات الجولة الميدانية"
              />
            </div>
            <textarea
              rows={2}
              value={tourNotes}
              onChange={(e) => setTourNotes(e.target.value)}
              placeholder="اكتب أو أملِ صوتياً أي ملاحظات إضافية حول التزام القسم والكوادر..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-slate-100 text-xs focus:outline-none focus:border-teal-500"
            />
          </div>

          {/* TOGGLE SWITCH: Immediate Violation Reporting */}
          <div className="border-t border-slate-800 pt-3">
            <div className="bg-gradient-to-r from-rose-950/50 via-slate-900 to-slate-900 border border-rose-900/60 rounded-xl p-3.5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-rose-950 border border-rose-700 text-rose-400">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-rose-200">
                    رصد مخالفة فورية أثناء الجولة؟
                  </h4>
                  <p className="text-[11px] text-slate-400">
                    تفعيل هذا الخيار سيقوم بإنشاء إشعار مخالفة رسمي آلياً وربطه بنظام المتابعة والإرسال
                  </p>
                </div>
              </div>

              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={hasViolation}
                  onChange={(e) => setHasViolation(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-rose-600"></div>
              </label>
            </div>

            {/* Expanded Violation Details when toggled */}
            {hasViolation && (
              <div className="mt-3 p-3.5 bg-rose-950/20 border border-rose-800/70 rounded-xl space-y-3 animate-in fade-in slide-in-from-top-2 duration-200">
                <div className="flex items-center justify-between border-b border-rose-900/50 pb-2">
                  <span className="font-bold text-rose-300 text-xs flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-rose-400" />
                    <span>تفاصيل المخالفة المرصودة (يتم إنشاء إشعار رسمي آلياً):</span>
                  </span>
                  <span className="text-[10px] bg-rose-950 text-rose-300 border border-rose-800 px-2 py-0.5 rounded font-mono">
                    Auto-Violation Notice
                  </span>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-slate-200 font-bold">
                      وصف المخالفة المرصودة <span className="text-rose-400">*</span>
                    </label>
                    <VoiceDictationButton
                      value={violationDescription}
                      onChange={setViolationDescription}
                      showLabel
                      title="إملاء صوتي لوصف المخالفة"
                    />
                  </div>
                  <textarea
                    rows={2}
                    required={hasViolation}
                    value={violationDescription}
                    onChange={(e) => setViolationDescription(e.target.value)}
                    placeholder="مثال: وجود عائق يسد مخرج الطوارئ، تسريب مياه، غطاء لوحة كهرباء مفتوح... (يمكنك الإملاء صوتياً)"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-slate-100 text-xs focus:outline-none focus:border-rose-500"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-slate-200 font-bold">
                      الإجراء المطلوب (Required Action)
                    </label>
                    <VoiceDictationButton
                      value={requiredAction}
                      onChange={setRequiredAction}
                      title="إملاء صوتي للإجراء المطلوب"
                    />
                  </div>
                  <input
                    type="text"
                    value={requiredAction}
                    onChange={(e) => setRequiredAction(e.target.value)}
                    placeholder="مثال: إخلاء المخرج فوراً، صيانة التمديدات وتأمين الموقع وإرفاق صورة الإنجاز..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 text-xs focus:outline-none focus:border-rose-500"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-slate-200 font-bold">
                        الموقع الدقيق داخل القسم
                      </label>
                      <VoiceDictationButton
                        value={violationLocationDetail}
                        onChange={setViolationLocationDetail}
                        title="إملاء صوتي لتحديد الموقع"
                      />
                    </div>
                    <input
                      type="text"
                      value={violationLocationDetail}
                      onChange={(e) => setViolationLocationDetail(e.target.value)}
                      placeholder="مثال: بجوار مخرج الطوارئ الشرقي"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 text-xs focus:outline-none focus:border-rose-500"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-200 font-bold mb-1">
                      مستوى الخطورة
                    </label>
                    <select
                      value={violationSeverity}
                      onChange={(e) => setViolationSeverity(e.target.value as any)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 text-xs focus:outline-none focus:border-rose-500"
                    >
                      <option value="low">منخفض (Low)</option>
                      <option value="medium">متوسط (Medium)</option>
                      <option value="high">مرتفع (High)</option>
                      <option value="critical">حرج جداً (Critical)</option>
                    </select>
                  </div>
                </div>

                {/* Assigned Party with [أخرى...] custom option */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-200 font-bold mb-1">
                      الجهة المكلفة بالمعالجة <span className="text-rose-400">*</span>
                    </label>
                    {!isCustomAssignedTo ? (
                      <select
                        value={assignedTo}
                        onChange={(e) => {
                          if (e.target.value === '__other__') {
                            setIsCustomAssignedTo(true);
                          } else {
                            setAssignedTo(e.target.value);
                          }
                        }}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 text-xs focus:outline-none focus:border-rose-500"
                      >
                        {ASSIGNED_PARTIES.map((party) => (
                          <option key={party} value={party}>
                            {party}
                          </option>
                        ))}
                        <option value="__other__" className="text-rose-400 font-bold">
                          ➕ [أخرى... كتابة الجهة يدوياً]
                        </option>
                      </select>
                    ) : (
                      <div className="flex items-center gap-1.5">
                        <input
                          type="text"
                          required
                          placeholder="اكتب اسم الجهة المكلفة يدوياً..."
                          value={customAssignedToText}
                          onChange={(e) => setCustomAssignedToText(e.target.value)}
                          className="flex-1 bg-slate-950 border border-rose-500 rounded-xl px-3 py-2 text-slate-100 text-xs focus:outline-none"
                          autoFocus
                        />
                        <button
                          type="button"
                          onClick={() => setIsCustomAssignedTo(false)}
                          className="px-2 py-1.5 bg-slate-800 text-slate-300 rounded-xl text-xs"
                        >
                          إلغاء
                        </button>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-slate-200 font-bold mb-1">
                      المهلة الزمنية للإنجاز والمعالجة
                    </label>
                    <select
                      value={deadlineHours}
                      onChange={(e) => setDeadlineHours(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 text-xs focus:outline-none focus:border-rose-500"
                    >
                      <option value={12}>12 ساعة (عاجل جداً)</option>
                      <option value={24}>24 ساعة (يوم واحد)</option>
                      <option value={48}>48 ساعة (يومان)</option>
                      <option value={72}>72 ساعة (3 أيام)</option>
                      <option value={168}>أسبوع كامل (7 أيام)</option>
                    </select>
                  </div>
                </div>

                {/* Photo Capture / Upload */}
                <div>
                  <label className="block text-slate-200 font-bold mb-1">
                    توثيق فوتوغرافي للمخالفة (التقاط صورة أو رفع ملف)
                  </label>
                  <div className="flex items-center gap-3">
                    <input
                      type="file"
                      ref={fileInputRef}
                      accept="image/*"
                      capture="environment"
                      onChange={handlePhotoUpload}
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold border border-slate-700 flex items-center gap-2 transition"
                    >
                      <Camera className="w-4 h-4 text-rose-400" />
                      <span>{violationPhotoUrl ? 'تغيير الصورة الملتقطة' : 'التقاط / رفع صورة المخالفة'}</span>
                    </button>

                    {violationPhotoUrl && (
                      <div className="flex items-center gap-2">
                        <img
                          src={violationPhotoUrl}
                          alt="معاينة المخالفة"
                          className="w-10 h-10 object-cover rounded-lg border border-rose-700"
                        />
                        <button
                          type="button"
                          onClick={() => setViolationPhotoUrl('')}
                          className="text-slate-400 hover:text-rose-400 text-xs"
                        >
                          حذف الصورة
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Footer Buttons */}
          <div className="border-t border-slate-800 pt-3 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold transition"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-6 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-bold transition flex items-center gap-2 shadow-lg shadow-teal-950"
            >
              <Save className="w-4 h-4" />
              <span>
                {initialTour ? 'اعتماد وحفظ التعديلات' : (hasViolation ? 'حفظ الجولة وإنشاء إشعار المخالفة آلياً' : 'حفظ واعتماد الجولة')}
              </span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
