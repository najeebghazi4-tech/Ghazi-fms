import React, { useState, useEffect, useMemo } from 'react';
import { supabase } from '../services/supabaseClient';
import { 
  Wrench, 
  Trash2, 
  Edit3, 
  Plus, 
  X, 
  Search, 
  CheckCircle2, 
  AlertTriangle, 
  Layers, 
  Box, 
  Cpu, 
  Building2,
  FileText,
  AlertOctagon,
  Camera,
  UploadCloud,
  Printer,
  ShieldCheck,
  Clock,
  Filter,
  CheckSquare,
  Sparkles,
  RefreshCw,
  Eye,
  Activity,
  Server,
  Flame,
  Video,
  Briefcase,
  Lock,
  Key,
  Unlock
} from 'lucide-react';
import { MedicalRecallsQuarantineView } from './MedicalRecallsQuarantineView';
import { 
  PpmAsset, 
  PpmDepartmentCategory, 
  PPM_DEPARTMENTS, 
  MASTER_PPM_ASSETS 
} from '../data/azalPpmAssetsData';
import { 
  calculatePpmStatus, 
  AntiFraudScanProof,
  PpmStatusType 
} from '../utils/ppmDueEngine';
import { StrictAntiFraudScanner } from './StrictAntiFraudScanner';
import { BarcodeA4PrintModal } from './BarcodeA4PrintModal';
import { AssetImportModal } from './AssetImportModal';
import { SecurePpmLiveInspectionModal } from './SecurePpmLiveInspectionModal';
import { 
  DepartmentPinLogin, 
  DepartmentSession, 
  getStoredDepartmentSession, 
  saveDepartmentSession, 
  clearDepartmentSession 
} from './DepartmentPinLogin';
import { triggerSuccessFeedback } from '../utils/feedbackUtils';
import { executeSmartPrint } from '../utils/printUtils';

interface TemplateItem {
  id: number;
  item_text: string;
  order_index: number;
}

interface Template {
  id: number;
  title: string;
  category: string;
  frequency: string;
  program_type: 'medical' | 'utility';
  pm_template_items?: TemplateItem[];
}

export interface EquipmentItem {
  id: number | string;
  name: string;
  asset_tag: string;
  department: string;
  frequency: string;
  program_type: 'medical' | 'utility';
  created_at?: string;
}

interface PreventiveMaintenanceViewProps {
  onClose?: () => void;
  isStandalonePublicRoute?: boolean;
  lockedMode?: 'utility' | 'medical';
  technicianName?: string;
  onLogout?: () => void;
  onLogAudit?: (action: string, actionAr: string, details: string) => void;
}

const LOCAL_STORAGE_PPM_ASSETS_KEY = 'azal_ppm_master_assets_v2';

export function PreventiveMaintenanceView({
  onClose,
  isStandalonePublicRoute,
  lockedMode,
  technicianName,
  onLogout,
  onLogAudit,
}: PreventiveMaintenanceViewProps = {}) {
  // Main Tabs
  const [activeTab, setActiveTab] = useState<'ppm_schedule' | 'templates' | 'recalls'>('ppm_schedule');
  
  // Master Assets State
  const [ppmAssets, setPpmAssets] = useState<PpmAsset[]>(() => {
    try {
      const stored = localStorage.getItem(LOCAL_STORAGE_PPM_ASSETS_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Could not read cached PPM assets:', e);
    }
    return MASTER_PPM_ASSETS;
  });

  // Department Category Filter (The 6 CBAHI FMS Categories)
  const [selectedCategory, setSelectedCategory] = useState<PpmDepartmentCategory | 'all'>('all');
  
  // Delay Status Quick Filter
  const [statusFilter, setStatusFilter] = useState<'all' | PpmStatusType>('all');
  
  // Search query
  const [searchQuery, setSearchQuery] = useState('');

  // Modals
  const [showLiveScanner, setShowLiveScanner] = useState(false);
  const [showA4PrintModal, setShowA4PrintModal] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);
  const [activeAuditAsset, setActiveAuditAsset] = useState<{ asset: PpmAsset; proof?: AntiFraudScanProof | null } | null>(null);

  // Department PIN Authentication Session (from sessionStorage)
  const [deptSession, setDeptSession] = useState<DepartmentSession | null>(() => getStoredDepartmentSession());
  const [showDeptLoginModal, setShowDeptLoginModal] = useState(false);
  const [targetLoginDept, setTargetLoginDept] = useState<PpmDepartmentCategory | 'all'>('all');
  const [pendingInspectionAsset, setPendingInspectionAsset] = useState<{ asset: PpmAsset; proof?: AntiFraudScanProof | null } | null>(null);

  // Synchronize inspector name from session if available
  useEffect(() => {
    if (deptSession?.engineerName && !inspectorName) {
      setInspectorName(deptSession.engineerName);
    }
  }, [deptSession]);

  // Template Checklists View (Legacy/Supplemental view)
  const [templates, setTemplates] = useState<Template[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  const [checklistValues, setChecklistValues] = useState<{ [key: number]: 'سليم' | 'غير سليم' | 'غير منطبق' }>({});
  const [inspectorName, setInspectorName] = useState(technicianName || '');
  const [generalNotes, setGeneralNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Equipment edit/delete state
  const [editingAsset, setEditingAsset] = useState<PpmAsset | null>(null);
  const [deleteConfirmAsset, setDeleteConfirmAsset] = useState<PpmAsset | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newAssetForm, setNewAssetForm] = useState<Partial<PpmAsset>>({
    asset_tag: '',
    name: '',
    category: 'general_facilities',
    location: '',
    frequency: 'شهري',
    model: '',
    serial_number: ''
  });

  // Save to LocalStorage whenever ppmAssets changes
  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_PPM_ASSETS_KEY, JSON.stringify(ppmAssets));
    } catch (e) {
      console.warn('Failed to cache PPM assets to localStorage:', e);
    }
  }, [ppmAssets]);

  // Sync technician name
  useEffect(() => {
    if (technicianName && !inspectorName) {
      setInspectorName(technicianName);
    }
  }, [technicianName]);

  // Load supplemental templates from Supabase
  useEffect(() => {
    const loadTemplates = async () => {
      try {
        const { data, error } = await supabase
          .from('pm_templates')
          .select('*, pm_template_items(*)');
        if (data) {
          setTemplates(data as Template[]);
        }
      } catch (e) {
        console.warn('Error loading templates:', e);
      }
    };
    loadTemplates();
  }, []);

  // Summary Metrics calculated dynamically via PPM Due Engine
  const metrics = useMemo(() => {
    let overdueCount = 0;
    let dueTodayCount = 0;
    let completedCount = 0;

    ppmAssets.forEach((asset) => {
      const { status } = calculatePpmStatus(asset);
      if (status === 'overdue') overdueCount++;
      else if (status === 'due_today') dueTodayCount++;
      else completedCount++;
    });

    return {
      total: ppmAssets.length,
      overdue: overdueCount,
      dueToday: dueTodayCount,
      completed: completedCount,
      complianceRate: ppmAssets.length > 0 ? Math.round(((ppmAssets.length - overdueCount) / ppmAssets.length) * 100) : 100
    };
  }, [ppmAssets]);

  // Statistics broken down for each of the 6 official departments
  const departmentStats = useMemo(() => {
    return PPM_DEPARTMENTS.map((dept) => {
      const deptAssets = ppmAssets.filter((a) => a.category === dept.id);
      let completed = 0;
      let dueToday = 0;
      let overdue = 0;
      let maxOverdueDays = 0;
      let totalOverdueDays = 0;

      deptAssets.forEach((asset) => {
        const res = calculatePpmStatus(asset);
        if (res.status === 'completed') {
          completed++;
        } else if (res.status === 'due_today') {
          dueToday++;
        } else if (res.status === 'overdue') {
          overdue++;
          totalOverdueDays += res.overdueDays;
          if (res.overdueDays > maxOverdueDays) {
            maxOverdueDays = res.overdueDays;
          }
        }
      });

      const complianceRate = deptAssets.length > 0
        ? Math.round(((deptAssets.length - overdue) / deptAssets.length) * 100)
        : 100;

      return {
        dept,
        total: deptAssets.length,
        completed,
        dueToday,
        overdue,
        maxOverdueDays,
        totalOverdueDays,
        complianceRate
      };
    });
  }, [ppmAssets]);

  // Print periodic PPM achievement and monitoring report in official A4 format
  const handlePrintAchievementReportA4 = () => {
    triggerSuccessFeedback();
    const todayStr = new Date().toISOString().split('T')[0];
    const timeStr = new Date().toLocaleTimeString('ar-YE', { hour: '2-digit', minute: '2-digit' });

    // Summary table rows across the 6 departments
    const summaryRowsHtml = departmentStats.map((ds) => `
      <tr style="border-bottom: 1px solid #e2e8f0; text-align: center;">
        <td style="padding: 8px; text-align: right; font-weight: bold; color: #1e293b;">
          ${ds.dept.nameAr}
        </td>
        <td style="padding: 8px; font-weight: bold; font-family: monospace;">${ds.total}</td>
        <td style="padding: 8px; color: #16a34a; font-weight: bold; background: #f0fdf4;">${ds.completed}</td>
        <td style="padding: 8px; color: #d97706; font-weight: bold; background: #fffbeb;">${ds.dueToday}</td>
        <td style="padding: 8px; color: ${ds.overdue > 0 ? '#dc2626' : '#64748b'}; font-weight: bold; background: ${ds.overdue > 0 ? '#fef2f2' : 'transparent'};">
          ${ds.overdue > 0 ? `${ds.overdue} (+${ds.maxOverdueDays} يوم تأخير)` : '0'}
        </td>
        <td style="padding: 8px; font-weight: bold; color: ${ds.complianceRate >= 90 ? '#16a34a' : ds.complianceRate >= 75 ? '#d97706' : '#dc2626'};">
          ${ds.complianceRate}%
        </td>
      </tr>
    `).join('');

    // Detailed assets rows
    const assetsRowsHtml = filteredAssets.map((asset, idx) => {
      const statusRes = calculatePpmStatus(asset);
      const isOverdue = statusRes.status === 'overdue';
      const isDueToday = statusRes.status === 'due_today';
      const statusLabel = isOverdue
        ? `<span style="color: #dc2626; font-weight: bold;">متأخر (${statusRes.overdueDays} يوم) ❌</span>`
        : isDueToday
        ? `<span style="color: #d97706; font-weight: bold;">مستحق اليوم ⏳</span>`
        : `<span style="color: #16a34a; font-weight: bold;">منجز وسارٍ ✅</span>`;

      return `
        <tr style="border-bottom: 1px solid #f1f5f9; font-size: 11px; background: ${idx % 2 === 0 ? '#ffffff' : '#f8fafc'};">
          <td style="padding: 6px; font-family: monospace; font-weight: bold; color: #0f766e;">${asset.asset_tag}</td>
          <td style="padding: 6px; font-weight: bold; color: #1e293b;">${asset.name}</td>
          <td style="padding: 6px; color: #475569;">${asset.categoryNameAr}</td>
          <td style="padding: 6px; color: #475569;">${asset.location}</td>
          <td style="padding: 6px; color: #0369a1; font-weight: 600;">${asset.frequency}</td>
          <td style="padding: 6px; font-family: monospace; color: #64748b;">${asset.last_pm_date || '-'}</td>
          <td style="padding: 6px; font-family: monospace; font-weight: bold;">${asset.next_pm_due}</td>
          <td style="padding: 6px;">${statusLabel}</td>
        </tr>
      `;
    }).join('');

    const contentHtml = `
      <div style="direction: rtl; text-align: right; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">
        <!-- Header Banner -->
        <div style="border-bottom: 2px solid #0f766e; padding-bottom: 12px; margin-bottom: 18px; display: flex; justify-content: space-between; align-items: center;">
          <div>
            <h1 style="margin: 0; color: #0f766e; font-size: 20px; font-weight: 800;">
              تقرير إنجاز ومراقبة الصيانة الوقائية الدوري لمسؤول السلامة (CBAHI FMS PPM Audit Report)
            </h1>
            <p style="margin: 4px 0 0 0; color: #475569; font-size: 12px;">
              مستشفى آزال النموذجي • إدارة المرافق والسلامة (FMS) • المنظومة الرقمية بالباركود المباشر
            </p>
          </div>
          <div style="text-align: left; font-size: 11px; color: #64748b;">
            <div><strong>تاريخ التقرير:</strong> ${todayStr} • ${timeStr}</div>
            <div><strong>القسم المفلتر:</strong> ${selectedCategory === 'all' ? 'كافة الأقسام الستة' : (PPM_DEPARTMENTS.find(d => d.id === selectedCategory)?.nameAr || '')}</div>
            <div><strong>حالة الفرز:</strong> ${statusFilter === 'all' ? 'الكل' : statusFilter === 'overdue' ? 'المتأخر' : statusFilter === 'due_today' ? 'المستحق اليوم' : 'المنجز'}</div>
          </div>
        </div>

        <!-- Overall KPI Cards Grid -->
        <div style="display: flex; gap: 10px; margin-bottom: 20px;">
          <div style="flex: 1; border: 1px solid #cbd5e1; border-radius: 8px; padding: 10px; text-align: center; background: #f8fafc;">
            <div style="font-size: 11px; color: #64748b; font-weight: bold;">إجمالي أجهزة المستشفى</div>
            <div style="font-size: 20px; font-weight: 900; color: #0f172a; margin-top: 2px;">${metrics.total}</div>
          </div>
          <div style="flex: 1; border: 1px solid #bbf7d0; border-radius: 8px; padding: 10px; text-align: center; background: #f0fdf4;">
            <div style="font-size: 11px; color: #16a34a; font-weight: bold;">المنجز وساري المفعول</div>
            <div style="font-size: 20px; font-weight: 900; color: #16a34a; margin-top: 2px;">${metrics.completed}</div>
          </div>
          <div style="flex: 1; border: 1px solid #fde68a; border-radius: 8px; padding: 10px; text-align: center; background: #fffbeb;">
            <div style="font-size: 11px; color: #d97706; font-weight: bold;">مستحق الفحص اليوم</div>
            <div style="font-size: 20px; font-weight: 900; color: #d97706; margin-top: 2px;">${metrics.dueToday}</div>
          </div>
          <div style="flex: 1; border: 1px solid #fecaca; border-radius: 8px; padding: 10px; text-align: center; background: #fef2f2;">
            <div style="font-size: 11px; color: #dc2626; font-weight: bold;">متأخر الفحص الدوري</div>
            <div style="font-size: 20px; font-weight: 900; color: #dc2626; margin-top: 2px;">${metrics.overdue}</div>
          </div>
          <div style="flex: 1; border: 1px solid #99f6e4; border-radius: 8px; padding: 10px; text-align: center; background: #f0fdfa;">
            <div style="font-size: 11px; color: #0f766e; font-weight: bold;">نسبة الامتثال العامة</div>
            <div style="font-size: 20px; font-weight: 900; color: #0f766e; margin-top: 2px;">${metrics.complianceRate}%</div>
          </div>
        </div>

        <!-- 6 Department Breakdown Table -->
        <h3 style="font-size: 14px; font-weight: bold; color: #1e293b; margin: 0 0 8px 0;">
          جدول مؤشرات الأداء للأقسام الستة (الأجهزة - المنجز - المستحق - المتأخر مع عداد الأيام):
        </h3>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 24px; font-size: 12px; border: 1px solid #e2e8f0;">
          <thead>
            <tr style="background: #0f766e; color: #ffffff;">
              <th style="padding: 8px; text-align: right;">القسم المعني</th>
              <th style="padding: 8px; text-align: center;">إجمالي الأجهزة</th>
              <th style="padding: 8px; text-align: center;">المنجز (أخضر)</th>
              <th style="padding: 8px; text-align: center;">المستحق (برتقالي)</th>
              <th style="padding: 8px; text-align: center;">المتأخر مع عداد الأيام (أحمر)</th>
              <th style="padding: 8px; text-align: center;">نسبة الالتزام</th>
            </tr>
          </thead>
          <tbody>
            ${summaryRowsHtml}
          </tbody>
        </table>

        <!-- Detailed Equipment Inventory List -->
        <h3 style="font-size: 14px; font-weight: bold; color: #1e293b; margin: 0 0 8px 0;">
          قائمة الأجهزة والمعدات (${filteredAssets.length} جهاز):
        </h3>
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 24px; font-size: 11px; border: 1px solid #e2e8f0;">
          <thead>
            <tr style="background: #334155; color: #ffffff;">
              <th style="padding: 6px; text-align: right;">كود الأصل</th>
              <th style="padding: 6px; text-align: right;">اسم الجهاز والنظام</th>
              <th style="padding: 6px; text-align: right;">القسم</th>
              <th style="padding: 6px; text-align: right;">الموقع</th>
              <th style="padding: 6px; text-align: right;">الدورية</th>
              <th style="padding: 6px; text-align: center;">آخر فحص</th>
              <th style="padding: 6px; text-align: center;">الموعد القادم</th>
              <th style="padding: 6px; text-align: center;">حالة الصيانة والتأخير</th>
            </tr>
          </thead>
          <tbody>
            ${assetsRowsHtml}
          </tbody>
        </table>

        <!-- Approvals & Signatures Box -->
        <div style="margin-top: 30px; padding-top: 15px; border-top: 1px solid #cbd5e1; display: flex; justify-content: space-between;">
          <div style="text-align: center; width: 30%;">
            <p style="margin: 0 0 35px 0; font-weight: bold; font-size: 12px;">مهندس الصيانة الوقائية</p>
            <p style="margin: 0; font-size: 11px; color: #64748b;">م. حسام العنسي</p>
          </div>
          <div style="text-align: center; width: 30%;">
            <p style="margin: 0 0 35px 0; font-weight: bold; font-size: 12px;">مسؤول السلامة وإدارة المرافق (FMS)</p>
            <p style="margin: 0; font-size: 11px; color: #64748b;">م. نجيب غازي</p>
          </div>
          <div style="text-align: center; width: 30%;">
            <p style="margin: 0 0 35px 0; font-weight: bold; font-size: 12px;">المدير العام لمستشفى آزال</p>
            <p style="margin: 0; font-size: 11px; color: #64748b;">د. محمد السراجي</p>
          </div>
        </div>
      </div>
    `;

    executeSmartPrint(contentHtml, {
      title: 'تقرير إنجاز ومراقبة الصيانة الوقائية الدوري A4',
      subtitle: 'مستشفى آزال النموذجي • إدارة المرافق وسلامة البيئة FMS',
      refNumber: `AZAL-FMS-PPM-${todayStr}`,
      date: todayStr,
      inspectorName: inspectorName || 'مسؤول السلامة FMS',
      department: selectedCategory === 'all' ? 'كافة الأقسام الستة' : selectedCategory
    });
  };

  // Filtered Assets list
  const filteredAssets = useMemo(() => {
    return ppmAssets.filter((asset) => {
      // Category filter
      if (selectedCategory !== 'all' && asset.category !== selectedCategory) {
        return false;
      }

      // Status filter
      if (statusFilter !== 'all') {
        const { status } = calculatePpmStatus(asset);
        if (status !== statusFilter) return false;
      }

      // Search filter
      if (searchQuery.trim() !== '') {
        const q = searchQuery.toLowerCase().trim();
        const matchTag = asset.asset_tag.toLowerCase().includes(q);
        const matchName = asset.name.toLowerCase().includes(q);
        const matchLoc = asset.location.toLowerCase().includes(q);
        const matchDept = asset.categoryNameAr.toLowerCase().includes(q);
        const matchModel = asset.model?.toLowerCase().includes(q);
        return matchTag || matchName || matchLoc || matchDept || matchModel;
      }

      return true;
    });
  }, [ppmAssets, selectedCategory, statusFilter, searchQuery]);

  // Asset Inspection Security Request
  const handleRequestInspectAsset = (asset: PpmAsset, proof: AntiFraudScanProof | null = null) => {
    setActiveAuditAsset({ asset, proof });
  };

  // Live scanner success handler
  const handleLiveScanSuccess = (asset: PpmAsset, proof: AntiFraudScanProof) => {
    setShowLiveScanner(false);
    triggerSuccessFeedback();
    setMessage({
      type: 'success',
      text: `تمت القراءة الحية لباركود (${asset.asset_tag}) بنجاح! تم التعرف على قسم: ${asset.categoryNameAr}.`
    });
    // Open inspection modal with live scan proof directly
    setActiveAuditAsset({ asset, proof });
  };

  // Import assets success handler
  const handleImportSuccess = (imported: PpmAsset[]) => {
    setPpmAssets((prev) => {
      const existingTags = new Set(prev.map((a) => a.asset_tag));
      const newItems = imported.filter((item) => !existingTags.has(item.asset_tag));
      const updatedExisting = prev.map((item) => {
        const found = imported.find((imp) => imp.asset_tag === item.asset_tag);
        return found || item;
      });
      return [...updatedExisting, ...newItems];
    });

    setMessage({
      type: 'success',
      text: `تم استيراد وحفظ (${imported.length}) أصل ومعدة في المنظومة بنجاح!`
    });

    if (onLogAudit) {
      onLogAudit(
        'IMPORT_PPM_ASSETS',
        'استيراد أصول الخطة الوقائية',
        `تم استيراد (${imported.length}) معدة ونظام من ملف وتحديث جدول الصيانة المزمنة.`
      );
    }
  };

  // Inspection audit save success handler
  const handleAuditSaveSuccess = (updatedAsset: PpmAsset, auditRecord: any) => {
    setPpmAssets((prev) => prev.map((a) => (a.id === updatedAsset.id ? updatedAsset : a)));
    setActiveAuditAsset(null);
    setMessage({
      type: 'success',
      text: `تم توثيق فحص الأصل (${updatedAsset.asset_tag}) واعتماد الموعد القادم: ${updatedAsset.next_pm_due} ✅`
    });

    // Save to Supabase audit log
    try {
      supabase.from('pm_audit_records').insert([auditRecord]).then(() => {});
    } catch (e) {
      console.warn('Supabase audit insert:', e);
    }

    if (onLogAudit) {
      onLogAudit(
        'PPM_INSPECTION_COMPLETED',
        'توثيق فحص وقائي بمسح حي',
        `تم فحص ومعايرة (${updatedAsset.name}) [${updatedAsset.asset_tag}] - النتيجة: [${auditRecord.overall_outcome}].`
      );
    }
  };

  // Add/edit asset handler
  const handleSaveAsset = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAssetForm.asset_tag || !newAssetForm.name) return;

    const todayStr = new Date().toISOString().split('T')[0];
    const categoryInfo = PPM_DEPARTMENTS.find((d) => d.id === newAssetForm.category) || PPM_DEPARTMENTS[0];

    if (editingAsset) {
      setPpmAssets((prev) =>
        prev.map((a) =>
          a.id === editingAsset.id
            ? {
                ...a,
                asset_tag: newAssetForm.asset_tag!.trim().toUpperCase(),
                name: newAssetForm.name!.trim(),
                category: newAssetForm.category as PpmDepartmentCategory,
                categoryNameAr: categoryInfo.nameAr,
                location: newAssetForm.location || a.location,
                frequency: newAssetForm.frequency as PpmAsset['frequency'],
                model: newAssetForm.model,
                serial_number: newAssetForm.serial_number
              }
            : a
        )
      );
      setMessage({ type: 'success', text: `تم تحديث بيانات الأصل (${newAssetForm.asset_tag}) بنجاح.` });
    } else {
      const created: PpmAsset = {
        id: `azal-asset-${Date.now()}`,
        asset_tag: newAssetForm.asset_tag.trim().toUpperCase(),
        name: newAssetForm.name.trim(),
        category: newAssetForm.category as PpmDepartmentCategory,
        categoryNameAr: categoryInfo.nameAr,
        location: newAssetForm.location || 'مبنى المستشفى الرئيسي',
        frequency: (newAssetForm.frequency as PpmAsset['frequency']) || 'شهري',
        frequencyDays: 30,
        last_pm_date: todayStr,
        next_pm_due: todayStr,
        responsible_role: 'فني الصيانة والمرافق FMS',
        model: newAssetForm.model,
        serial_number: newAssetForm.serial_number,
        checklist_steps: [
          { id: 1, step_text: 'الفحص البصري والتشغيلي العام للهيكل والتوصيلات', expected_value: 'سليم ومطابق' },
          { id: 2, step_text: 'اختبار كفاءة التشغيل تحت الحمل والأداء القياسي', expected_value: 'يعمل بكفاءة 100%' },
          { id: 3, step_text: 'معايرة المؤشرات وقراءات السلامة والتأريض', expected_value: 'معاير ومطابق' }
        ]
      };
      setPpmAssets((prev) => [created, ...prev]);
      setMessage({ type: 'success', text: `تمت إضافة الأصل الجديد (${created.asset_tag}) بنجاح.` });
    }

    setShowAddModal(false);
    setEditingAsset(null);
  };

  // Delete asset handler
  const handleConfirmDelete = () => {
    if (!deleteConfirmAsset) return;
    setPpmAssets((prev) => prev.filter((a) => a.id !== deleteConfirmAsset.id));
    setMessage({ type: 'success', text: `تم حذف الأصل (${deleteConfirmAsset.asset_tag}) من المنظومة.` });
    setDeleteConfirmAsset(null);
  };

  // Category Icon helper
  const getCategoryIcon = (catId: PpmDepartmentCategory) => {
    switch (catId) {
      case 'general_facilities':
        return <Building2 className="w-4 h-4" />;
      case 'biomedical':
        return <Activity className="w-4 h-4" />;
      case 'it_networks':
        return <Server className="w-4 h-4" />;
      case 'medical_gases':
        return <Flame className="w-4 h-4" />;
      case 'cctv_security':
        return <Video className="w-4 h-4" />;
      case 'contractor_assets':
        return <Briefcase className="w-4 h-4" />;
      default:
        return <Wrench className="w-4 h-4" />;
    }
  };

  // IF NO ACTIVE DEPARTMENT PIN SESSION: ENFORCE DEPARTMENT PIN LOGIN GATEWAY
  if (!deptSession) {
    return (
      <div className="max-w-4xl mx-auto p-3 sm:p-6 space-y-6 text-slate-100 animate-fadeIn" dir="rtl">
        {/* Top bar with close/logout */}
        {(onClose || onLogout) && (
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <span className="text-xs bg-emerald-950 text-emerald-400 border border-emerald-800 px-3 py-1 rounded-full font-bold flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5" />
              منظومة الصيانة الوقائية المزمنة CBAHI FMS • بوابة التحقق بالرمز السري للقسم
            </span>
            <div className="flex items-center gap-2">
              {onLogout && (
                <button
                  type="button"
                  onClick={onLogout}
                  className="px-3 py-1.5 bg-rose-950/80 hover:bg-rose-900 border border-rose-700 text-rose-300 hover:text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5"
                >
                  <span>تسجيل الخروج 🔒</span>
                </button>
              )}
              {onClose && (
                <button
                  type="button"
                  onClick={onClose}
                  className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-bold transition flex items-center gap-1"
                >
                  ✕ إغلاق
                </button>
              )}
            </div>
          </div>
        )}

        <DepartmentPinLogin
          initialDepartment={lockedMode === 'medical' ? 'biomedical' : 'general_facilities'}
          initialEngineerName={inspectorName || technicianName || ''}
          title="بوابة التحقق وتسجيل دخول الأقسام الهندسية (Department PIN Gateway)"
          subtitle="يمنع استعراض أجهزة القسم أو توثيق واعتماد جداول الصيانة الوقائية إلا بعد اختيار القسم وإدخال اسم المهندس والرمز السري (PIN) ومطابقته مع جدول department_access_pins في Supabase"
          isModal={false}
          onLoginSuccess={(session) => {
            saveDepartmentSession(session);
            setDeptSession(session);
            setInspectorName(session.engineerName);
            setSelectedCategory(session.departmentId);
            setMessage({
              type: 'success',
              text: `مرحباً م. ${session.engineerName} • تم التحقق من رمز المرور وتفعيل صلاحيات (${session.departmentNameAr}) بنجاح! 🔑`
            });
            triggerSuccessFeedback();
          }}
          onCancel={onClose}
        />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-3 sm:p-5 space-y-6 text-slate-100" dir="rtl">
      
      {/* Top Banner & Main Nav */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl relative overflow-hidden">
        {/* Glow Accent */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>

        {/* Top bar with close/logout if provided */}
        {(onClose || onLogout) && (
          <div className="flex items-center justify-between gap-2 mb-4 pb-3 border-b border-slate-800">
            <span className="text-xs bg-emerald-950 text-emerald-400 border border-emerald-800 px-3 py-1 rounded-full font-bold flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5" />
              منظومة الصيانة الوقائية المزمنة CBAHI FMS • إدارة السلامة والتشغيل
            </span>
            <div className="flex items-center gap-2">
              {onLogout && (
                <button
                  type="button"
                  onClick={onLogout}
                  className="px-3 py-1.5 bg-rose-950/80 hover:bg-rose-900 border border-rose-700 text-rose-300 hover:text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5"
                >
                  <span>تسجيل الخروج 🔒</span>
                </button>
              )}
              {onClose && (
                <button
                  type="button"
                  onClick={onClose}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-bold transition"
                >
                  ✕ إغلاق
                </button>
              )}
            </div>
          </div>
        )}

        {/* Header Content & Action Buttons */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
                <span>⚙️</span> منظومة الصيانة الوقائية المزمنة (PPM Due Engine)
              </h2>
              <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[11px] px-2.5 py-0.5 rounded-full font-bold">
                Anti-Fraud Live Sensor
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              مستشفى آزال النموذجي • الخطة التشغيلية المزمنة لإدارة المرافق والأنظمة الطبية وفق معايير سباهي (CBAHI FMS)
            </p>
          </div>

          {/* Primary Operations Bar */}
          <div className="flex flex-wrap items-center gap-2">
            {/* 1. Strict Anti-Fraud Live Scanner Button: Start Inspection */}
            <button
              type="button"
              id="btn-start-periodic-inspection"
              onClick={() => setShowLiveScanner(true)}
              className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs sm:text-sm font-bold px-4 py-2.5 rounded-2xl shadow-lg shadow-emerald-950 flex items-center gap-2 transition-transform active:scale-95 border border-emerald-400/40"
              title="يفتح حصرياً الكاميرا المباشرة لقراءة الـ QR الخاص بالجهاز (تعطيل رفع الصور نهائياً)"
            >
              <Camera className="w-4 h-4" />
              <span>بدء الفحص الدوري</span>
              <span className="text-[10px] bg-emerald-700/80 px-1.5 py-0.5 rounded-md font-mono">LIVE QR</span>
            </button>

            {/* 2. Print Periodic Achievement Report in A4 format */}
            <button
              type="button"
              id="btn-print-achievement-report-a4"
              onClick={handlePrintAchievementReportA4}
              className="bg-slate-800 hover:bg-slate-700 text-emerald-400 hover:text-emerald-300 border border-emerald-500/40 text-xs sm:text-sm font-bold px-3.5 py-2.5 rounded-2xl shadow-md transition-transform active:scale-95 flex items-center gap-1.5"
              title="طباعة تقرير الإنجاز الدوري بصيغة A4 لمسؤول السلامة وإدارة المرافق"
            >
              <Printer className="w-4 h-4 text-emerald-400" />
              <span>طباعة تقرير الإنجاز الدوري A4</span>
            </button>

            {/* 3. Import Assets from Excel/CSV/PDF */}
            <button
              type="button"
              onClick={() => setShowImportModal(true)}
              className="bg-blue-600 hover:bg-blue-500 text-white text-xs sm:text-sm font-bold px-3.5 py-2.5 rounded-2xl shadow-lg shadow-blue-950 flex items-center gap-1.5 transition-transform active:scale-95"
            >
              <UploadCloud className="w-4 h-4" />
              <span>استيراد الأجهزة من ملف</span>
            </button>

            {/* 4. Print Barcode Labels A4 Sheet */}
            <button
              type="button"
              onClick={() => setShowA4PrintModal(true)}
              className="bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 text-xs sm:text-sm font-bold px-3.5 py-2.5 rounded-2xl transition-colors flex items-center gap-1.5"
            >
              <Printer className="w-4 h-4 text-slate-400" />
              <span>ملصقات الباركود A4</span>
            </button>

            {/* 4. Manual Add Device */}
            <button
              type="button"
              onClick={() => {
                setEditingAsset(null);
                setNewAssetForm({
                  asset_tag: '',
                  name: '',
                  category: selectedCategory !== 'all' ? selectedCategory : 'general_facilities',
                  location: '',
                  frequency: 'شهري',
                  model: '',
                  serial_number: ''
                });
                setShowAddModal(true);
              }}
              className="bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 p-2.5 rounded-2xl transition-colors"
              title="إضافة أصل يدوياً"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

          {/* High-Level View Switcher Tabs */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 mt-5 pt-4 border-t border-slate-800">
          <button
            onClick={() => setActiveTab('ppm_schedule')}
            className={`py-2.5 px-3 rounded-2xl font-bold text-xs sm:text-sm transition flex items-center justify-center gap-2 ${
              activeTab === 'ppm_schedule'
                ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-950'
                : 'bg-slate-800/80 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>جدول الأصول والخطة المزمنة ({ppmAssets.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('templates')}
            className={`py-2.5 px-3 rounded-2xl font-bold text-xs sm:text-sm transition flex items-center justify-center gap-2 ${
              activeTab === 'templates'
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-950'
                : 'bg-slate-800/80 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>نماذج التفتيش الميداني القديمة ({templates.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('recalls')}
            className={`py-2.5 px-3 rounded-2xl font-bold text-xs sm:text-sm transition flex items-center justify-center gap-2 ${
              activeTab === 'recalls'
                ? 'bg-rose-600 text-white shadow-lg shadow-rose-950'
                : 'bg-slate-800/80 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
            }`}
          >
            <AlertOctagon className="w-4 h-4 text-rose-400" />
            <span>تحريز الأجهزة والاستدعاء (SMDA)</span>
          </button>
        </div>

        {/* Department PIN Authentication Session Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 mt-4 pt-3 border-t border-slate-800/80 bg-slate-950/60 p-3 rounded-2xl">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-xl bg-teal-500/15 text-teal-400 border border-teal-500/30">
              <ShieldCheck className="w-4 h-4" />
            </div>
            {deptSession ? (
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-bold text-slate-300">المهندس المناوب المعتمد:</span>
                <span className="text-xs font-black text-white bg-slate-800 px-2.5 py-0.5 rounded-lg border border-slate-700">
                  {deptSession.engineerName}
                </span>
                <span className="text-xs text-teal-400 font-bold bg-teal-950/80 px-2.5 py-0.5 rounded-lg border border-teal-800 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>{deptSession.departmentNameAr}</span>
                </span>
                <span className="text-[10px] text-slate-500 font-mono">
                  (جلسة نشطة • {new Date(deptSession.loginTime).toLocaleTimeString('ar-YE', { hour: '2-digit', minute: '2-digit' })})
                </span>
              </div>
            ) : (
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs text-amber-300 font-bold flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                  <span>لم يتم تسجيل دخول مهندس القسم بالـ PIN</span>
                </span>
                <span className="text-[10px] text-slate-400">
                  (يتطلب إدخال الرمز السري من جدول department_access_pins لبدء الفحص)
                </span>
              </div>
            )}
          </div>

          <div className="flex items-center gap-2">
            {deptSession ? (
              <>
                <button
                  type="button"
                  onClick={() => {
                    setTargetLoginDept(selectedCategory !== 'all' ? selectedCategory : 'general_facilities');
                    setShowDeptLoginModal(true);
                  }}
                  className="px-3 py-1.5 bg-teal-950 hover:bg-teal-900 text-teal-300 border border-teal-700/80 rounded-xl text-xs font-bold transition flex items-center gap-1.5"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>تبديل القسم</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    clearDepartmentSession();
                    setDeptSession(null);
                    setMessage({ type: 'success', text: 'تم تسجيل خروج مهندس القسم بنجاح من sessionStorage.' });
                  }}
                  className="px-3 py-1.5 bg-rose-950/70 hover:bg-rose-900 text-rose-300 border border-rose-800 rounded-xl text-xs font-bold transition"
                >
                  خروج 🔒
                </button>
              </>
            ) : (
              <button
                type="button"
                onClick={() => {
                  setTargetLoginDept(selectedCategory !== 'all' ? selectedCategory : 'general_facilities');
                  setShowDeptLoginModal(true);
                }}
                className="px-3.5 py-1.5 bg-gradient-to-r from-amber-600 to-teal-600 hover:from-amber-500 hover:to-teal-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-md shadow-amber-950 active:scale-95"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>تسجيل دخول القسم (PIN Login) 🔑</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Toast Alert Message */}
      {message && (
        <div
          className={`p-4 rounded-2xl text-xs sm:text-sm font-bold text-center border flex items-center justify-center gap-2 ${
            message.type === 'success'
              ? 'bg-emerald-950/70 border-emerald-500/80 text-emerald-300'
              : 'bg-rose-950/70 border-rose-500/80 text-rose-300'
          }`}
        >
          {message.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
          <span>{message.text}</span>
        </div>
      )}

      {/* TAB 1: PPM SCHEDULE & ASSETS INVENTORY (MAIN FOCUS) */}
      {activeTab === 'ppm_schedule' && (
        <div className="space-y-5">
          
          {/* Real-time KPI Stats Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {/* Total Assets */}
            <div 
              onClick={() => { setStatusFilter('all'); setSelectedCategory('all'); }}
              className="bg-slate-900 border border-slate-800 hover:border-slate-700 p-4 rounded-3xl cursor-pointer transition shadow-md flex items-center justify-between"
            >
              <div>
                <span className="text-[11px] font-semibold text-slate-400 block">إجمالي أصول المستشفى</span>
                <span className="text-2xl font-black text-white font-mono mt-0.5 block">{metrics.total}</span>
                <span className="text-[10px] text-slate-500 mt-1 block">معدات وأنظمة مشمولة</span>
              </div>
              <div className="w-10 h-10 rounded-2xl bg-slate-800 flex items-center justify-center text-slate-300">
                <Box className="w-5 h-5" />
              </div>
            </div>

            {/* Overdue (Critical) */}
            <div 
              onClick={() => setStatusFilter('overdue')}
              className={`border p-4 rounded-3xl cursor-pointer transition shadow-md flex items-center justify-between ${
                statusFilter === 'overdue'
                  ? 'bg-rose-950/50 border-rose-500 shadow-rose-950/50'
                  : 'bg-slate-900 border-slate-800 hover:border-rose-500/40'
              }`}
            >
              <div>
                <span className="text-[11px] font-bold text-rose-400 block flex items-center gap-1">
                  <span>متأخر الفحص ❌</span>
                </span>
                <span className="text-2xl font-black text-rose-400 font-mono mt-0.5 block">{metrics.overdue}</span>
                <span className="text-[10px] text-rose-300/80 mt-1 block">يحتاج مسح ميداني عاجل</span>
              </div>
              <div className="w-10 h-10 rounded-2xl bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-rose-400">
                <AlertOctagon className="w-5 h-5" />
              </div>
            </div>

            {/* Due Today */}
            <div 
              onClick={() => setStatusFilter('due_today')}
              className={`border p-4 rounded-3xl cursor-pointer transition shadow-md flex items-center justify-between ${
                statusFilter === 'due_today'
                  ? 'bg-amber-950/50 border-amber-500 shadow-amber-950/50'
                  : 'bg-slate-900 border-slate-800 hover:border-amber-500/40'
              }`}
            >
              <div>
                <span className="text-[11px] font-bold text-amber-400 block">مستحق اليوم ⏳</span>
                <span className="text-2xl font-black text-amber-400 font-mono mt-0.5 block">{metrics.dueToday}</span>
                <span className="text-[10px] text-amber-300/80 mt-1 block">جدول وردية اليوم</span>
              </div>
              <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
                <Clock className="w-5 h-5" />
              </div>
            </div>

            {/* On Track / Completed */}
            <div 
              onClick={() => setStatusFilter('completed')}
              className={`border p-4 rounded-3xl cursor-pointer transition shadow-md flex items-center justify-between ${
                statusFilter === 'completed'
                  ? 'bg-emerald-950/50 border-emerald-500 shadow-emerald-950/50'
                  : 'bg-slate-900 border-slate-800 hover:border-emerald-500/40'
              }`}
            >
              <div>
                <span className="text-[11px] font-bold text-emerald-400 block">منجز / سارٍ ✅</span>
                <span className="text-2xl font-black text-emerald-400 font-mono mt-0.5 block">{metrics.completed}</span>
                <span className="text-[10px] text-emerald-400/80 mt-1 block">نسبة الالتزام: {metrics.complianceRate}%</span>
              </div>
              <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <CheckCircle2 className="w-5 h-5" />
              </div>
            </div>
          </div>

          {/* REQUIREMENT 2 & 3: The 6 Official Departments Monitoring Cards for Safety Officer */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-5 space-y-4 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
              <div>
                <div className="flex items-center gap-2 font-black text-white text-sm sm:text-base">
                  <ShieldCheck className="w-5 h-5 text-emerald-400" />
                  <span>شاشة المراقبة لمسؤول السلامة وإدارة المرافق (الأقسام الستة):</span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  إحصائيات تفصيلية للأجهزة ونسب الإنجاز والتأخير لكل قسم مع إمكانية الفرز والطباعة الفورية
                </p>
              </div>

              {/* Reset / All Departments Pill */}
              <button
                type="button"
                onClick={() => setSelectedCategory('all')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 self-start sm:self-auto border ${
                  selectedCategory === 'all'
                    ? 'bg-emerald-600 text-white border-emerald-500 shadow-md shadow-emerald-950'
                    : 'bg-slate-800 text-slate-300 border-slate-700 hover:text-white hover:bg-slate-750'
                }`}
              >
                <span>🌐 كافة الأقسام ({ppmAssets.length})</span>
              </button>
            </div>

            {/* 6 Official Department Statistical Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {departmentStats.map((ds) => {
                const isSelected = selectedCategory === ds.dept.id;

                return (
                  <div
                    key={ds.dept.id}
                    onClick={() => setSelectedCategory(isSelected ? 'all' : ds.dept.id)}
                    className={`rounded-2xl p-3.5 border transition cursor-pointer relative flex flex-col justify-between gap-2.5 ${
                      isSelected
                        ? 'bg-slate-850 border-emerald-500 ring-2 ring-emerald-500/40 shadow-lg shadow-emerald-950/40'
                        : 'bg-slate-950/70 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
                    }`}
                  >
                    {/* Header: Icon + Department Name + Rate */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className={`p-2 rounded-xl border ${
                          isSelected 
                            ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300' 
                            : 'bg-slate-800/80 border-slate-700 text-slate-300'
                        }`}>
                          {getCategoryIcon(ds.dept.id)}
                        </div>
                        <div>
                          <h4 className="text-xs sm:text-sm font-bold text-white line-clamp-1">
                            {ds.dept.nameAr}
                          </h4>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {ds.dept.nameEn}
                          </span>
                        </div>
                      </div>

                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-lg border font-mono ${
                        ds.complianceRate >= 90
                          ? 'bg-emerald-950/70 text-emerald-300 border-emerald-800'
                          : ds.complianceRate >= 75
                          ? 'bg-amber-950/70 text-amber-300 border-amber-800'
                          : 'bg-rose-950/70 text-rose-300 border-rose-800'
                      }`}>
                        {ds.complianceRate}% التزام
                      </span>
                    </div>

                    {/* 4 Statistical Slots: Total - Completed - Due - Overdue */}
                    <div className="grid grid-cols-4 gap-1.5 pt-1 text-center font-mono">
                      {/* Total */}
                      <div className="bg-slate-900/90 rounded-xl p-1.5 border border-slate-800/80">
                        <span className="text-[9px] text-slate-400 block">إجمالي</span>
                        <span className="text-xs sm:text-sm font-black text-white">{ds.total}</span>
                      </div>

                      {/* Completed (Green) */}
                      <div className="bg-emerald-950/40 rounded-xl p-1.5 border border-emerald-900/60">
                        <span className="text-[9px] text-emerald-400 block">منجز</span>
                        <span className="text-xs sm:text-sm font-black text-emerald-400">{ds.completed}</span>
                      </div>

                      {/* Due Today (Orange) */}
                      <div className="bg-amber-950/40 rounded-xl p-1.5 border border-amber-900/60">
                        <span className="text-[9px] text-amber-400 block">مستحق</span>
                        <span className="text-xs sm:text-sm font-black text-amber-400">{ds.dueToday}</span>
                      </div>

                      {/* Overdue with Days Counter (Red) */}
                      <div className={`rounded-xl p-1.5 border ${
                        ds.overdue > 0 
                          ? 'bg-rose-950/60 border-rose-800/80' 
                          : 'bg-slate-900/90 border-slate-800/80'
                      }`}>
                        <span className={`text-[9px] block ${ds.overdue > 0 ? 'text-rose-400 font-bold' : 'text-slate-400'}`}>
                          متأخر
                        </span>
                        <span className={`text-xs sm:text-sm font-black ${ds.overdue > 0 ? 'text-rose-400' : 'text-slate-400'}`}>
                          {ds.overdue}
                        </span>
                      </div>
                    </div>

                    {/* Overdue Warning & Days Counter */}
                    {ds.overdue > 0 && (
                      <div className="text-[10px] bg-rose-950/60 border border-rose-900/80 text-rose-300 px-2 py-1 rounded-lg flex items-center justify-between font-mono">
                        <span className="font-bold flex items-center gap-1">
                          <AlertTriangle className="w-3 h-3 text-rose-400 shrink-0" />
                          <span>أقصى تأخير مسجل:</span>
                        </span>
                        <span className="font-black text-rose-200">
                          +{ds.maxOverdueDays} يوم
                        </span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Search and Secondary Filter Row */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="relative flex-1 w-full">
              <Search className="w-4 h-4 text-slate-500 absolute right-3.5 top-3 pointer-events-none" />
              <input
                type="text"
                placeholder="ابحث بكود الأصل (مثل AZ-GEN-01)، اسم الجهاز، الموديل، الغرفة..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-2xl pr-10 pl-4 py-2.5 text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute left-3 top-3 text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Quick Status Filters */}
            <div className="flex items-center gap-1.5 bg-slate-900 p-1 rounded-2xl border border-slate-800 text-xs self-stretch sm:self-auto overflow-x-auto">
              <button
                onClick={() => setStatusFilter('all')}
                className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-colors ${
                  statusFilter === 'all' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                الكل ({ppmAssets.length})
              </button>
              <button
                onClick={() => setStatusFilter('overdue')}
                className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-colors ${
                  statusFilter === 'overdue' ? 'bg-rose-600 text-white' : 'text-rose-400 hover:text-rose-300'
                }`}
              >
                المتأخر فقط ({metrics.overdue})
              </button>
              <button
                onClick={() => setStatusFilter('due_today')}
                className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-colors ${
                  statusFilter === 'due_today' ? 'bg-amber-600 text-white' : 'text-amber-400 hover:text-amber-300'
                }`}
              >
                المستحق اليوم ({metrics.dueToday})
              </button>
              <button
                onClick={() => setStatusFilter('completed')}
                className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-colors ${
                  statusFilter === 'completed' ? 'bg-emerald-600 text-white' : 'text-emerald-400 hover:text-emerald-300'
                }`}
              >
                المنجز ({metrics.completed})
              </button>
            </div>
          </div>

          {/* Master Assets Table with PPM Due Engine Status Badges */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="bg-slate-950 border-b border-slate-800 text-slate-400 font-bold">
                    <th className="py-3.5 px-4 w-12 text-center">#</th>
                    <th className="py-3.5 px-4">كود الأصل (Tag)</th>
                    <th className="py-3.5 px-4">اسم المعدة / النظام</th>
                    <th className="py-3.5 px-4">القسم المعني</th>
                    <th className="py-3.5 px-4">الموقع الفعلي</th>
                    <th className="py-3.5 px-4">دورية الصيانة</th>
                    <th className="py-3.5 px-4">آخر فحص</th>
                    <th className="py-3.5 px-4">موعد الفحص القادم</th>
                    <th className="py-3.5 px-4 text-center">حالة التأخير (PPM Engine)</th>
                    <th className="py-3.5 px-4 text-center">إجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {filteredAssets.map((asset, index) => {
                    const statusRes = calculatePpmStatus(asset);
                    return (
                      <tr key={asset.id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="py-3 px-4 text-slate-500 font-mono text-center">
                          {index + 1}
                        </td>

                        {/* Monospace Code with Live Scan Trigger */}
                        <td className="py-3 px-4 font-mono font-bold text-emerald-400">
                          <button
                            onClick={() => {
                              handleRequestInspectAsset(asset, null);
                            }}
                            className="hover:underline flex items-center gap-1 text-right"
                            title="فتح استمارة الفحص"
                          >
                            <span>{asset.asset_tag}</span>
                          </button>
                        </td>

                        {/* Asset Name & Model */}
                        <td className="py-3 px-4">
                          <div className="font-bold text-white leading-snug">
                            {asset.name}
                          </div>
                          {asset.model && (
                            <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                              {asset.model} {asset.serial_number ? `• S/N: ${asset.serial_number}` : ''}
                            </div>
                          )}
                        </td>

                        {/* Category */}
                        <td className="py-3 px-4 text-slate-300">
                          <span className="inline-block bg-slate-800 text-slate-300 px-2 py-0.5 rounded-lg text-[11px] font-medium border border-slate-700">
                            {asset.categoryNameAr}
                          </span>
                        </td>

                        {/* Location */}
                        <td className="py-3 px-4 text-slate-300 max-w-[140px] truncate" title={asset.location}>
                          {asset.location}
                        </td>

                        {/* Frequency */}
                        <td className="py-3 px-4">
                          <span className="bg-slate-800/90 text-slate-200 px-2 py-0.5 rounded-md text-[11px] font-semibold border border-slate-700">
                            {asset.frequency}
                          </span>
                        </td>

                        {/* Last Inspection Date */}
                        <td className="py-3 px-4 font-mono text-slate-400 text-[11px]">
                          {asset.last_pm_date}
                        </td>

                        {/* Next Due Date */}
                        <td className="py-3 px-4 font-mono font-bold text-slate-200 text-[11px]">
                          {asset.next_pm_due}
                        </td>

                        {/* REQUIREMENT 3: Status Badge calculated by PPM Due Engine */}
                        <td className="py-3 px-4 text-center">
                          <span
                            className={`inline-block px-2.5 py-1 rounded-xl text-[11px] border whitespace-nowrap shadow-xs ${statusRes.badgeBg} ${statusRes.badgeBorder} ${statusRes.badgeText}`}
                          >
                            {statusRes.statusLabelAr}
                          </span>
                        </td>

                        {/* Actions */}
                        <td className="py-3 px-4 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            {/* Open Audit Form */}
                            <button
                              type="button"
                              onClick={() => handleRequestInspectAsset(asset, null)}
                              className="px-2.5 py-1 bg-emerald-600/20 hover:bg-emerald-600 text-emerald-300 hover:text-white border border-emerald-500/30 rounded-lg text-[11px] font-bold transition flex items-center gap-1"
                              title="بدء استمارة الفحص"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>فحص</span>
                            </button>

                            {/* Edit */}
                            <button
                              type="button"
                              onClick={() => {
                                setEditingAsset(asset);
                                setNewAssetForm({
                                  asset_tag: asset.asset_tag,
                                  name: asset.name,
                                  category: asset.category,
                                  location: asset.location,
                                  frequency: asset.frequency,
                                  model: asset.model,
                                  serial_number: asset.serial_number
                                });
                                setShowAddModal(true);
                              }}
                              className="p-1.5 bg-slate-800 hover:bg-blue-600 text-blue-400 hover:text-white rounded-lg transition"
                              title="تعديل بيانات الأصل"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>

                            {/* Delete */}
                            <button
                              type="button"
                              onClick={() => setDeleteConfirmAsset(asset)}
                              className="p-1.5 bg-slate-800 hover:bg-rose-600 text-rose-400 hover:text-white rounded-lg transition"
                              title="حذف الأصل"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}

                  {filteredAssets.length === 0 && (
                    <tr>
                      <td colSpan={10} className="py-12 text-center text-slate-500 text-sm">
                        لا توجد أصول مطابقة لمعايير البحث أو الفلترة المحددة.
                        <div className="mt-2">
                          <button
                            onClick={() => {
                              setSelectedCategory('all');
                              setStatusFilter('all');
                              setSearchQuery('');
                            }}
                            className="text-emerald-400 hover:underline text-xs font-bold"
                          >
                            إعادة ضبط الفلاتر وعرض كافة الأجهزة
                          </button>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Table Footer with Summary */}
            <div className="bg-slate-950 px-4 py-3 border-t border-slate-800 flex flex-wrap items-center justify-between text-xs text-slate-400 gap-2">
              <div className="flex items-center gap-2">
                <span>المعروض حالياً:</span>
                <span className="text-white font-mono font-bold">{filteredAssets.length}</span>
                <span>من إجمالي</span>
                <span className="text-white font-mono font-bold">{ppmAssets.length}</span>
                <span>أصل ومعدة</span>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => setShowA4PrintModal(true)}
                  className="text-emerald-400 hover:text-emerald-300 font-bold flex items-center gap-1 text-xs"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>طباعة ملصقات الباركود لهذة القائمة</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: TEMPLATES CHECKLIST INSPECTION (LEGACY/BACKWARD COMPATIBILITY) */}
      {activeTab === 'templates' && (
        <div className="space-y-4">
          {!selectedTemplate ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {templates.map((tpl) => (
                <div
                  key={tpl.id}
                  onClick={() => {
                    setSelectedTemplate(tpl);
                    const initVal: { [key: number]: 'سليم' | 'غير سليم' | 'غير منطبق' } = {};
                    tpl.pm_template_items?.forEach((item) => {
                      initVal[item.id] = 'سليم';
                    });
                    setChecklistValues(initVal);
                    setMessage(null);
                  }}
                  className="bg-slate-900 border border-slate-800 hover:border-blue-500/50 p-4 rounded-2xl cursor-pointer transition shadow hover:shadow-blue-950/30 flex flex-col justify-between space-y-3"
                >
                  <div>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="px-2.5 py-0.5 rounded-full bg-blue-950 text-blue-400 border border-blue-800">
                        {tpl.category}
                      </span>
                      <span className="text-slate-400">{tpl.frequency}</span>
                    </div>
                    <h3 className="font-bold text-sm text-white mt-2">{tpl.title}</h3>
                    <p className="text-xs text-slate-400 mt-1">
                      عدد بنود التدقيق: {tpl.pm_template_items?.length || 0} بنود
                    </p>
                  </div>
                  <button className="w-full py-2 bg-slate-800 hover:bg-blue-600 text-slate-200 hover:text-white rounded-xl text-xs font-bold transition">
                    بدء الفحص الميداني 📋
                  </button>
                </div>
              ))}
              {templates.length === 0 && (
                <div className="col-span-full py-8 text-center text-slate-500 text-sm">
                  لا توجد نماذج مسجلة في هذا القسم حالياً.
                </div>
              )}
            </div>
          ) : (
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                setLoading(true);
                const isCompliant = Object.values(checklistValues).every((v) => v !== 'غير سليم');
                const outcome = isCompliant ? 'مطابق' : 'يحتاج إجراء تصحيحي';

                const auditPayload = {
                  template_id: selectedTemplate.id,
                  technician_name: inspectorName,
                  checklist_results: checklistValues,
                  notes: generalNotes,
                  overall_status: outcome
                };

                const { error } = await supabase.from('pm_audit_records').insert([auditPayload]);
                if (error) {
                  setMessage({ type: 'error', text: 'تعذر الحفظ: ' + error.message });
                } else {
                  triggerSuccessFeedback();
                  setMessage({ type: 'success', text: `تم توثيق الفحص بنجاح! النتيجة: [${outcome}]` });
                  setSelectedTemplate(null);
                }
                setLoading(false);
              }}
              className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-5 shadow-xl"
            >
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div>
                  <span className="text-xs text-blue-400 font-semibold">{selectedTemplate.category} ({selectedTemplate.frequency})</span>
                  <h3 className="text-base font-bold text-white mt-0.5">{selectedTemplate.title}</h3>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedTemplate(null)}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs transition"
                >
                  رجوع للقائمة
                </button>
              </div>

              <div className="space-y-3">
                <h4 className="text-xs font-bold text-slate-300">بنود التدقيق الميداني:</h4>
                {selectedTemplate.pm_template_items
                  ?.sort((a, b) => a.order_index - b.order_index)
                  .map((item) => (
                    <div
                      key={item.id}
                      className="bg-slate-950 border border-slate-800/80 p-3 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <span className="text-xs text-slate-200 leading-relaxed sm:max-w-[60%]">
                        <strong className="text-slate-400 ml-1">#{item.order_index}</strong> {item.item_text}
                      </span>
                      <div className="flex items-center gap-1 self-end sm:self-center">
                        {(['سليم', 'غير سليم', 'غير منطبق'] as const).map((status) => (
                          <button
                            key={status}
                            type="button"
                            onClick={() => setChecklistValues({ ...checklistValues, [item.id]: status })}
                            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                              checklistValues[item.id] === status
                                ? status === 'سليم'
                                  ? 'bg-emerald-600 text-white'
                                  : status === 'غير سليم'
                                  ? 'bg-rose-600 text-white'
                                  : 'bg-slate-700 text-white'
                                : 'bg-slate-900 text-slate-400 hover:bg-slate-800'
                            }`}
                          >
                            {status}
                          </button>
                        ))}
                      </div>
                    </div>
                  ))}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">اسم الفني / المهندس القائم بالفحص *</label>
                  <input
                    type="text"
                    required
                    value={inspectorName}
                    onChange={(e) => setInspectorName(e.target.value)}
                    placeholder="الاسم الكامل"
                    className="w-full bg-slate-950 border border-slate-750 rounded-xl px-3 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">ملاحظات إضافية أو أعطال رُصدت</label>
                  <input
                    type="text"
                    value={generalNotes}
                    onChange={(e) => setGeneralNotes(e.target.value)}
                    placeholder="دون أي تفاصيل تصحيحية..."
                    className="w-full bg-slate-950 border border-slate-750 rounded-xl px-3 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-bold text-sm shadow-lg shadow-blue-950 transition"
              >
                {loading ? 'جاري الحفظ والتوثيق...' : 'اعتماد وحفظ سجل الفحص الوقائي'}
              </button>
            </form>
          )}
        </div>
      )}

      {/* TAB 3: RECALLS & QUARANTINE */}
      {activeTab === 'recalls' && (
        <MedicalRecallsQuarantineView
          technicianName={inspectorName || technicianName}
          onLogAudit={onLogAudit}
        />
      )}

      {/* MODAL 0: DEPARTMENT PIN LOGIN GATEWAY */}
      {showDeptLoginModal && (
        <DepartmentPinLogin
          initialDepartment={targetLoginDept}
          initialEngineerName={inspectorName || technicianName}
          isModal={true}
          onLoginSuccess={(session) => {
            setDeptSession(session);
            setInspectorName(session.engineerName);
            setShowDeptLoginModal(false);
            setMessage({
              type: 'success',
              text: `مرحباً م. ${session.engineerName} • تم التحقق من رمز المرور وتفعيل صلاحيات (${session.departmentNameAr}) بنجاح! 🔑`
            });
            if (pendingInspectionAsset) {
              setActiveAuditAsset(pendingInspectionAsset);
              setPendingInspectionAsset(null);
            }
          }}
          onCancel={() => {
            setShowDeptLoginModal(false);
            setPendingInspectionAsset(null);
          }}
        />
      )}

      {/* MODAL 1: STRICT ANTI-FRAUD LIVE SCANNER */}
      {showLiveScanner && (
        <StrictAntiFraudScanner
          assets={ppmAssets}
          onClose={() => setShowLiveScanner(false)}
          onScanSuccess={handleLiveScanSuccess}
        />
      )}

      {/* MODAL 2: A4 BARCODE LABELS PRINT MODAL */}
      {showA4PrintModal && (
        <BarcodeA4PrintModal
          assets={ppmAssets}
          initialCategory={selectedCategory}
          onClose={() => setShowA4PrintModal(false)}
        />
      )}

      {/* MODAL 3: EXCEL / CSV / PDF ASSET IMPORTER */}
      {showImportModal && (
        <AssetImportModal
          onClose={() => setShowImportModal(false)}
          onImportSuccess={handleImportSuccess}
        />
      )}

      {/* MODAL 4: DETAILED SECURE LIVE INSPECTION AUDIT FORM */}
      {activeAuditAsset && (
        <SecurePpmLiveInspectionModal
          asset={activeAuditAsset.asset}
          scanProof={activeAuditAsset.proof}
          technicianName={inspectorName || technicianName}
          onClose={() => setActiveAuditAsset(null)}
          onSaveSuccess={handleAuditSaveSuccess}
        />
      )}

      {/* MODAL 5: ADD / EDIT ASSET FORM */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-lg w-full p-5 space-y-4 shadow-2xl text-right" dir="rtl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span>{editingAsset ? '✏️ تعديل بيانات أصل' : '➕ إضافة جهاز أو مرفق جديد'}</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveAsset} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 mb-1 font-semibold">كود الأصل / الباركود (Asset Tag) *</label>
                <input
                  type="text"
                  required
                  value={newAssetForm.asset_tag}
                  onChange={(e) => setNewAssetForm({ ...newAssetForm, asset_tag: e.target.value })}
                  placeholder="مثال: AZ-GEN-04 أو AZ-BIO-22"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-emerald-400 font-mono font-bold focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">اسم الجهاز / المعدة / النظام *</label>
                <input
                  type="text"
                  required
                  value={newAssetForm.name}
                  onChange={(e) => setNewAssetForm({ ...newAssetForm, name: e.target.value })}
                  placeholder="مثال: محطة معالجة مياه الغسيل الكلوي RO"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">القسم المسؤول *</label>
                  <select
                    value={newAssetForm.category}
                    onChange={(e) => setNewAssetForm({ ...newAssetForm, category: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-2 text-white focus:outline-none focus:border-emerald-500"
                  >
                    {PPM_DEPARTMENTS.map((dept) => (
                      <option key={dept.id} value={dept.id}>
                        {dept.nameAr}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">دورية الصيانة الوقائية *</label>
                  <select
                    value={newAssetForm.frequency}
                    onChange={(e) => setNewAssetForm({ ...newAssetForm, frequency: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-2 text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="يومي">يومي</option>
                    <option value="أسبوعي">أسبوعي</option>
                    <option value="شهري">شهري</option>
                    <option value="كل 3 أشهر">كل 3 أشهر (ربع سنوي)</option>
                    <option value="كل 6 أشهر">كل 6 أشهر (نصف سنوي)</option>
                    <option value="سنوي">سنوي</option>
                    <option value="موسمي">موسمي</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">الموقع الفعلي / الغرفة / الدور *</label>
                <input
                  type="text"
                  value={newAssetForm.location}
                  onChange={(e) => setNewAssetForm({ ...newAssetForm, location: e.target.value })}
                  placeholder="مثال: الطابق الثاني - جناح العناية المركزة"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">الموديل / الطراز</label>
                  <input
                    type="text"
                    value={newAssetForm.model}
                    onChange={(e) => setNewAssetForm({ ...newAssetForm, model: e.target.value })}
                    placeholder="مثال: Siemens ACUSON S2000"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">الرقم التسلسلي (S/N)</label>
                  <input
                    type="text"
                    value={newAssetForm.serial_number}
                    onChange={(e) => setNewAssetForm({ ...newAssetForm, serial_number: e.target.value })}
                    placeholder="مثال: SN-2025-9921"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="flex gap-2 pt-3 border-t border-slate-800">
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-md shadow-emerald-950"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{editingAsset ? 'حفظ التعديلات' : 'إدراج الأصل في السجل'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs transition"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 6: DELETE ASSET CONFIRMATION */}
      {deleteConfirmAsset && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-slate-900 border border-rose-900 rounded-3xl max-w-sm w-full p-5 space-y-4 shadow-2xl text-right" dir="rtl">
            <div className="w-12 h-12 rounded-2xl bg-rose-950/80 border border-rose-600 text-rose-400 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="text-base font-bold text-white">تأكيد حذف الأصل</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                هل أنت متأكد من رغبتك في حذف الأصل{' '}
                <strong className="text-rose-300 font-bold">"{deleteConfirmAsset.name}"</strong>
                <br />
                كود الأصل: <span className="font-mono text-emerald-400">({deleteConfirmAsset.asset_tag})</span>؟
              </p>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-md shadow-rose-950"
              >
                <Trash2 className="w-4 h-4" />
                <span>تأكيد الحذف</span>
              </button>
              <button
                type="button"
                onClick={() => setDeleteConfirmAsset(null)}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-xl text-xs transition"
              >
                تراجع
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default PreventiveMaintenanceView;
