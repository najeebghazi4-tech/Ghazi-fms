export type UserRole = 'consultant' | 'charge_nurse' | 'staff_nurse' | 'quality_officer' | 'quality_head' | 'safety_head' | 'general_director' | 'usm_tech' | 'mem_engineer';

export interface RolePermissions {
  canEdit: boolean;
  canDelete: boolean;
  canApprove: boolean;
  canPerformRounds: boolean;
  canAccessExecutive: boolean;
  isReadOnly: boolean;
  isSandboxed: boolean;
  sandboxMode?: 'utility' | 'medical';
  hideBottomNav: boolean;
  roleDisplayNameAr: string;
}

export function getRolePermissions(role: UserRole): RolePermissions {
  switch (role) {
    case 'general_director':
      return {
        canEdit: false,
        canDelete: false,
        canApprove: false,
        canPerformRounds: false,
        canAccessExecutive: true,
        isReadOnly: true,
        isSandboxed: false,
        hideBottomNav: false,
        roleDisplayNameAr: 'المدير العام (رقابة إشرافية فقط - Read Only)',
      };
    case 'safety_head':
      return {
        canEdit: true,
        canDelete: true,
        canApprove: true,
        canPerformRounds: true,
        canAccessExecutive: true,
        isReadOnly: false,
        isSandboxed: false,
        hideBottomNav: false,
        roleDisplayNameAr: 'رئيس قسم السلامة وإدارة المرافق (FMS - Full Admin)',
      };
    case 'usm_tech':
      return {
        canEdit: true,
        canDelete: false,
        canApprove: false,
        canPerformRounds: false,
        canAccessExecutive: false,
        isReadOnly: false,
        isSandboxed: true,
        sandboxMode: 'utility',
        hideBottomNav: true,
        roleDisplayNameAr: 'فني صيانة المرافق والخدمات (USM Sandbox)',
      };
    case 'mem_engineer':
      return {
        canEdit: true,
        canDelete: false,
        canApprove: false,
        canPerformRounds: false,
        canAccessExecutive: false,
        isReadOnly: false,
        isSandboxed: true,
        sandboxMode: 'medical',
        hideBottomNav: true,
        roleDisplayNameAr: 'مهندس الأجهزة الطبية الحيوية (MEM Sandbox)',
      };
    case 'quality_head':
    case 'quality_officer':
      return {
        canEdit: true,
        canDelete: false,
        canApprove: true,
        canPerformRounds: true,
        canAccessExecutive: true,
        isReadOnly: false,
        isSandboxed: false,
        hideBottomNav: false,
        roleDisplayNameAr: 'منسق الجودة والاعتماد (CBAHI)',
      };
    default:
      return {
        canEdit: false,
        canDelete: false,
        canApprove: false,
        canPerformRounds: false,
        canAccessExecutive: false,
        isReadOnly: true,
        isSandboxed: false,
        hideBottomNav: false,
        roleDisplayNameAr: 'مستخدم سريري',
      };
  }
}

export interface StaffUser {
  id: string;
  name: string;
  nameEn: string;
  role: UserRole;
  roleTitleAr: string;
  badgeNumber: string;
  department: string;
  pin: string;
  avatarColor: string;
}

export type AcuityLevel = 'critical' | 'guard' | 'stable';

export type CodeStatus = 'full_code' | 'dnr';

export type IsolationType = 'none' | 'contact' | 'droplet' | 'airborne';

export interface VitalSigns {
  recordedAt: string;
  bpSystolic: number;
  bpDiastolic: number;
  heartRate: number;
  respRate: number;
  oxygenSat: number;
  temperature: number;
  painScore: number; // 0-10
  gcs: number; // 3-15
  bloodSugar?: number; // mg/dL
}

export interface InvasiveLine {
  id: string;
  type: string; // 'IV Cannula' | 'Central Line' | 'Foley' | 'NGT' | 'Chest Tube'
  typeAr: string;
  location: string;
  insertedDate: string;
  status: 'clean' | 'due_change' | 'dressing_done';
}

export interface ISBARData {
  // I - Introduction
  patientId: string;
  fullName: string;
  fullNameEn: string;
  mrn: string; // Medical Record Number
  nationalId?: string;
  bedNumber: string;
  department: string;
  age: number;
  gender: 'male' | 'female';
  attendingPhysician: string;
  admissionDate: string;

  // S - Situation
  primaryDiagnosis: string;
  primaryDiagnosisEn: string;
  acuity: AcuityLevel;
  codeStatus: CodeStatus;
  isolation: IsolationType;
  fallRiskScore: 'low' | 'moderate' | 'high';
  currentConditionSummary: string;

  // B - Background
  allergies: string[];
  medicalHistory: string[];
  surgicalHistory: string[];
  currentDiet: string;

  // A - Assessment
  vitals: VitalSigns;
  invasiveLines: InvasiveLine[];
  neurologicalStatus: 'alert' | 'voice' | 'pain' | 'unresponsive';
  respiratorySupport: 'room_air' | 'nasal_cannula' | 'venturi_mask' | 'bipap' | 'ventilator';
  intakeOutputBalance: string; // e.g., '+450 ml / 24h'

  // R - Recommendation
  pendingTasks: {
    id: string;
    text: string;
    urgency: 'high' | 'medium' | 'routine';
    category: 'lab' | 'medication' | 'consult' | 'procedure';
    isCompleted: boolean;
  }[];
  criticalAlertNotes: string;
  dischargePlan: string;
  vitalSigns?: { bp?: string; hr?: number; spo2?: number; temp?: number; [key: string]: any };
  situation?: string;
  background?: string;
  assessment?: string;
  recommendation?: string;
}

export interface HandoverRecord {
  id: string;
  patientId: string;
  shiftType: 'morning' | 'evening' | 'night';
  shiftDate: string;
  outgoingStaff: {
    id: string;
    name: string;
    role: string;
    signedAt: string;
  };
  incomingStaff: {
    id: string;
    name: string;
    role: string;
    signedAt: string;
  };
  clinicalSummary: string;
  specialInstructions: string;
  verificationHash: string; // Cryptographic-like proof
  status: 'completed' | 'disputed';
}

export interface ControlledSubstance {
  id: string;
  name: string;
  nameEn: string;
  strength: string;
  currentCount: number;
  unit: string;
  lastCheckedBy: string;
  lastCheckedAt: string;
  discrepancy: boolean;
}

export interface CrashCartChecklist {
  id: string;
  checkedAt: string;
  defibrillatorBatteryOk: boolean;
  oxygenTankPsi: number; // normal >= 1500
  suctionWorking: boolean;
  laryngoscopeLightOk: boolean;
  lockTagNumber: string;
  checkedBy: string;
  witnessedBy: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  action: string;
  actionAr: string;
  actorId?: string;
  actorName: string;
  actorRole: string;
  patientMrn?: string;
  details: string;
  securitySeverity: 'info' | 'warning' | 'critical';
}

export type EmergencyCodeType = 
  | 'code_red' 
  | 'code_blue' 
  | 'code_yellow' 
  | 'code_black' 
  | 'code_pink' 
  | 'code_orange' 
  | 'code_grey';

export interface EmergencyCodeDefinition {
  type: EmergencyCodeType;
  nameAr: string;
  nameEn: string;
  meaningAr: string;
  colorClass: string;
  bgClass: string;
  borderClass: string;
  actionProtocolAr: string;
}

export interface ActiveEmergencyAlert {
  id: string;
  codeType: EmergencyCodeType;
  activatedAt: string;
  activatedBy: string;
  location: string;
  notes: string;
  status: 'active' | 'cleared';
  clearedAt?: string;
  clearedBy?: string;
}

export interface SafetyInspectionItem {
  id: string;
  category: 'fire' | 'medical_gas' | 'emergency_exits' | 'electrical' | 'cctv_access' | 'biohazard';
  categoryAr: string;
  titleAr: string;
  locationAr: string;
  status: 'pass' | 'fail' | 'needs_attention';
  lastChecked: string;
  inspector: string;
  notes: string;
}

export interface CodeOrangeSpillDetails {
  isCodeOrange: boolean;
  spillType: 'chemical' | 'biological'; // كيميائي أو بيولوجي
  spillSize: 'minor' | 'major'; // بسيط (< 50ml) أو كبير (> 50ml)
  spillKitStatus: 'needed_immediately' | 'already_used' | 'not_needed'; // الحاجة لعدة الانسكاب
  evacuationDone?: boolean;
}

export interface SuspectDescriptionDetails {
  gender: 'male' | 'female' | 'unknown'; // الجنس
  approxHeight: string; // الطول المقدر
  clothing: string; // الملابس والمظهر
  lastSeenLocation: string; // آخر موقع شوهد فيه
  directionOfMovement?: string; // اتجاه الهروب/التحرك
}

export interface MedicalDeviceFailureDetails {
  deviceName: string; // اسم الجهاز الطبي
  assetOrSerialCode?: string; // كود الأصل أو الرقم التسلسلي
  failureType: 'malfunction' | 'misuse' | 'power_failure' | 'needs_calibration'; // عطل فني / سوء استخدام / انقطاع تيار / معايرة
  clinicalImpact?: 'no_harm' | 'delayed_treatment' | 'patient_affected';
}

export interface SmokingViolationDetails {
  violatorType: 'visitor' | 'patient_companion' | 'patient' | 'staff' | 'contractor'; // صفة المخالف
  immediateIntervention: 'verbal_warning' | 'confiscated' | 'security_escort' | 'fine_applied'; // الإجراء المتخذ
  violatorName?: string;
}

export interface SafetyIncidentReport {
  id: string;
  codeNumber: string;
  reportedAt: string;
  reportedBy: string;
  department: string;
  locationDetail: string;
  categoryAr: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  description: string;
  immediateAction: string;
  status: 'open' | 'investigating' | 'resolved';
  assignedOfficer: string;
  category?: string;
  actionTaken?: string;
  resolutionNotes?: string;
  resolvedBy?: string;
  resolvedAt?: string;
  source?: string;
  // CBAHI & FMS Enhanced Fields
  codeOrange?: CodeOrangeSpillDetails;
  suspectDetails?: SuspectDescriptionDetails;
  medicalDeviceDetails?: MedicalDeviceFailureDetails;
  smokingDetails?: SmokingViolationDetails;
  timestamp?: string | number;
  createdAt?: string | number;
  incidentType?: string;
  location?: string;
  isCodeOrangeSpill?: boolean;
  medicalDeviceInvolved?: boolean;
  isSmokingViolation?: boolean;
  afterPhotoUrl?: string;
}

export interface SecurityShiftHandover {
  id: string;
  shiftDate: string;
  shiftType: 'morning' | 'evening' | 'night';
  outgoingGuardName: string;
  incomingGuardName: string;
  walkieTalkiesOperational: number;
  emergencyMasterKeysPresent: boolean;
  cctvAllActive: boolean;
  hospitalGatesSecured: boolean;
  activeIncidentsCount: number;
  specialInstructions: string;
  verificationHash: string;
  signedAt: string;
}

// -------------------------------------------------------------
// New Safety Management System Upgrades
// -------------------------------------------------------------

export interface SafetyTourRecord {
  id: string;
  department: string;
  customDepartment?: string;
  inspectorName: string;
  inspectorRole: string;
  tourDate: string;
  timestamp: number;
  tasks: string[]; // e.g. ['فحص مخارج الطوارئ', 'لوحات الكهرباء', 'الممرات', 'أسطوانات الغاز']
  hasViolation: boolean;
  violationId?: string;
  notes: string;
  synced: boolean;
  checkpointName?: string;
  routeZone?: string;
  routeStatus?: 'completed' | 'scheduled' | 'in_progress' | 'attention_required';
}

export type ViolationStatus = 'pending' | 'overdue' | 'responded' | 'resolved' | 'تمت المعالجة';

export interface SafetyViolationNotice {
  id: string; // e.g. AZAL-VIO-2026-001
  tourId?: string;
  createdAt: string;
  timestamp: number;
  department: string;
  locationDetail: string;
  assignedTo: string;
  assignedToCustom?: string;
  recipientPhone?: string;
  publicToken?: string; // Cryptographically secure unguessable UUID v4 for public URLs
  description: string;
  requiredAction?: string; // Specific required corrective action
  severity: 'low' | 'medium' | 'high' | 'critical';
  beforePhotoUrl?: string;
  deadlineHours: number; // e.g. 24, 48, 72
  deadlineAt: string;
  status: ViolationStatus;
  statusAr?: string; // 'تمت المعالجة' | 'قيد المتابعة' | 'متأخرة'
  firstSentAt?: string;
  secondSentAt?: string;
  // Resolution details
  resolutionNote?: string;
  afterPhotoUrl?: string;
  resolvedBy?: string;
  resolvedAt?: string;
  synced: boolean;
  // Follow-up tracking & smart overdue counter
  followUpCount?: number;
  lastFollowUpAt?: string;
  followUpHistory?: Array<{
    id: string;
    sentAt: string;
    sentBy?: string;
    channel?: string;
    notes?: string;
    count?: number;
  }>;
}

export type ExtinguisherType = 'dry_powder' | 'co2' | 'water' | 'foam' | 'wet_chemical' | 'clean_agent_mri' | 'water_mist_mri' | string;

export interface FireExtinguisherItem {
  id: string;
  serialNumber: string; // e.g. EXT-AZAL-001
  location: string;
  type: ExtinguisherType;
  typeAr: string;
  expiryDate: string;
  weight: string; // e.g. 6 كجم
  gaugeStatus: 'normal' | 'low' | 'recharge';
  conditionStatus: 'valid' | 'needs_maintenance' | 'expired' | 'damaged';
  notes: string;
  lastInspectedAt: string;
  nextInspectionDue?: string;
  capacity?: string;
  zone?: string;
  floor?: string;
  inspectorName: string;
  inspectorRole: string;
  signatureProof: string;
  synced: boolean;
  weightCapacity?: string;
  lastInspectionDate?: string;
  lastInspectedDate?: string;
  department?: string;
  inspectedBy?: string;
  isMrSafeNonMagnetic?: boolean; // طفاية متوافقة مع غرف الرنين المغناطيسي وغير ممغنطة (MR-Safe)
  mriZone?: 'Zone I' | 'Zone II' | 'Zone III' | 'Zone IV (Scanner Room)';
}

// -------------------------------------------------------------
// CBAHI FMS: Negative Pressure & Smoke Test (AIIR Isolation)
// -------------------------------------------------------------
export interface NegativePressureLog {
  id: string;
  roomCode: string; // e.g. AIIR-ICU-01, ENDO-01, TB-LAB-01
  roomName: string; // e.g. غرفة عزل العناية المركزة (1)
  department: string;
  floor: string;
  inspectionDate: string;
  inspectionTime: string;
  pressureValuePa: number; // differential in Pascals (standard <= -2.5 Pa)
  pressureUnit: 'Pa' | 'in_wg';
  gaugeReadingStatus: 'normal_negative' | 'critical_low' | 'positive_leakage';
  smokeTestResult: 'pass_inward' | 'fail_outward' | 'fail_stagnant';
  doorSweepSealIntact: boolean;
  anteroomDoorClosed: boolean;
  exhaustFanOperational: boolean;
  hepaFilterDifferentialOk: boolean;
  airChangesPerHour?: number; // e.g. >= 12 ACH
  overallStatus: 'compliant' | 'warning' | 'failed';
  inspectorName: string;
  inspectorRole: string;
  inspectorBadgeNumber?: string;
  correctiveAction?: string;
  signature?: string;
  createdAt: number;
  synced?: boolean;
}

// -------------------------------------------------------------
// CBAHI FMS: Medical Device Recalls & SMDA Quarantine Protocol
// -------------------------------------------------------------
export interface MedicalRecallNotice {
  id: string; // e.g. SMDA-AZAL-2026-001
  source: string; // تعميم هيئة الأدوية / وزارة الصحة / تنبيه الشركة المصنعة / حادث سريري SMDA
  deviceName: string;
  modelNumber: string;
  manufacturer: string;
  serialNumber: string;
  lotBatchNumber?: string;
  assetTag: string; // رقم الأصل الطبي بالمستشفى
  department: string;
  hazardClass: 'class_1' | 'class_2' | 'class_3' | 'smda_clinical_incident';
  defectDescription: string;
  actionTaken: string;
  quarantinedLocation: string; // مستودع التحريز الطبي
  quarantinedBy: string;
  quarantineDate: string;
  status: 'quarantined' | 'under_investigation' | 'vendor_servicing' | 'repaired_cleared' | 'condemned_disposed';
  stickerPrinted?: boolean;
  notes?: string;
  createdAt: number;
  synced?: boolean;
}

// -------------------------------------------------------------
// CBAHI FMS: Weekly Eyewash & Emergency Shower Flush Registry
// -------------------------------------------------------------
export interface EyewashFlushRecord {
  id: string; // e.g. EW-FLUSH-2026-001
  stationCode?: string; // e.g. EW-LAB-01
  stationId?: string;
  stationName?: string;
  location: string;
  department?: string;
  flushDate: string;
  flushTime?: string;
  flowDurationSeconds?: number; // e.g. 180s (3 minutes)
  flushDurationSeconds?: number;
  waterClarity?: 'clean_clear' | 'sediment_cloudy' | 'rust_tint';
  waterTemperature?: 'tepid' | 'cold' | 'hot'; // ANSI Z358.1 tepid water 16-38C
  dualSprayPatternOk?: boolean;
  dustCoversOperational?: boolean;
  dustCoversIntact?: boolean;
  stayOpenValveOk?: boolean;
  accessUnobstructed?: boolean;
  pathwayUnobstructed?: boolean;
  signageVisible?: boolean;
  waterFlowAdequate?: boolean;
  waterCleanAndClear?: boolean;
  waterTemperatureTepid?: boolean;
  drainageWorking?: boolean;
  overallStatus?: 'pass' | 'minor_issue' | 'out_of_service';
  status?: 'pass' | 'minor_issue' | 'out_of_service' | 'fail' | string;
  inspectorName: string;
  inspectorRole?: string;
  notes?: string;
  actionRequired?: string;
  createdAt: number;
  synced?: boolean;
}

export interface PublicSafetyReport {
  id: string;
  reporterName?: string;
  reporterPhone?: string;
  location: string;
  category: string;
  description: string;
  photoUrl?: string;
  createdAt: string;
  timestamp: number;
  status: 'new' | 'investigating' | 'resolved';
  synced: boolean;
  codeOrange?: CodeOrangeSpillDetails;
  suspectDetails?: SuspectDescriptionDetails;
  medicalDeviceDetails?: MedicalDeviceFailureDetails;
  smokingDetails?: SmokingViolationDetails;
}

export interface DbMigration {
  id: string;
  version: string;
  name: string;
  appliedAt: string;
  status: 'applied' | 'pending';
  details: string;
}

export type ReportPeriodFilter = 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'yearly' | 'all';

// -------------------------------------------------------------
// Department Comprehensive Audit (Offline-First CBAHI / JCI / FMS)
// -------------------------------------------------------------

export type AuditCheckItemStatus = 'compliant' | 'non_compliant' | 'not_applicable';

export interface AuditCheckItem {
  id: string;
  code: string;
  standardRef: 'CBAHI' | 'JCI' | 'FMS' | 'OSHA' | 'MOH';
  clauseText: string;
  category: string;
  status: AuditCheckItemStatus;
  defectDescription?: string;
  photoUrl?: string;
  severity?: 'low' | 'medium' | 'high' | 'critical';
  assignedAction?: string;
}

export interface CorrectiveActionItem {
  id: string;
  itemId: string;
  clauseCode: string;
  defectDescription: string;
  actionRequired: string;
  assignedDepartment: string;
  targetDeadline: string;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  status: 'open' | 'in_progress' | 'resolved';
}

export interface DepartmentAuditRecord {
  id: string;
  departmentId: string;
  departmentNameAr: string;
  departmentCategoryAr: string;
  auditDate: string;
  timestamp: number;
  compliancePercentage: number;
  totalItems: number;
  compliantCount: number;
  nonCompliantCount: number;
  notApplicableCount: number;
  items: AuditCheckItem[];
  signatures: {
    deptSupervisor: {
      name: string;
      title: string;
      signed: boolean;
      signedAt?: string;
    };
    maintenanceRep: {
      name: string;
      title: string;
      signed: boolean;
      signedAt?: string;
    };
    safetyHead: {
      name: string; // 'م/ نجيب غازي'
      title: string; // 'رئيس قسم الأمن والسلامة'
      signed: boolean;
      signedAt?: string;
    };
  };
  capPlan?: string;
  correctiveActions: CorrectiveActionItem[];
  savedLocally: boolean;
  synced: boolean;
  lastModified: number;
}

export interface MonthlyAuditItemRecord {
  id: string | number;
  department_id: string;
  code: string;
  standard_ref: string;
  category: string;
  clause_text: string;
  order_index?: number;
}

export interface MonthlyDeptInspectionRecord {
  id: string;
  department_id: string;
  department_name: string;
  audit_date: string;
  compliance_percentage: number;
  total_items: number;
  compliant_count: number;
  non_compliant_count: number;
  not_applicable_count: number;
  items_data: AuditCheckItem[];
  cap_plan: string;
  corrective_actions: CorrectiveActionItem[];
  safety_engineer_signature: {
    name: string;
    title: string;
    signed: boolean;
    signed_at?: string;
  };
  maintenance_rep_signature: {
    name: string;
    title: string;
    signed: boolean;
    signed_at?: string;
  };
  dept_supervisor_signature: {
    name: string;
    title: string;
    signed: boolean;
    signed_at?: string;
  };
  notes?: string;
  created_at: string;
}

// -------------------------------------------------------------
// Specialized Public Portals (Zero-Auth Hash Routing)
// -------------------------------------------------------------

export interface ContractorPermitNotice {
  id: string; // e.g. AZAL-CTR-2026-001
  permitNumber?: string; // Official approval reference e.g., AZAL-PERMIT-2026-1042
  department: string;
  contractorName: string;
  contactPhone: string;
  workType: 'hot_work' | 'electrical' | 'civil_maintenance' | 'plumbing' | 'hvac' | 'medical_gas' | 'other';
  workTypeCustom?: string;
  workDescription: string;
  workersCount: number;
  workersNames: string;
  expectedStartDate: string;
  expectedEndDate: string;
  safetyMeasures: string[];
  permitPhotoUrl?: string;
  applicantName: string;
  status: 'pending_review' | 'approved' | 'active_work' | 'completed' | 'rejected';
  safetyNotes?: string;
  approvedAt?: string;
  approvedBy?: string;
  approvalPrecautions?: string[];
  workingHours?: string;
  gatePassAllowed?: boolean;
  validUntil?: string;
  createdAt: string;
  timestamp: number;
  synced?: boolean;
  contractorCompany?: string;
  startDate?: string;
  endDate?: string;
  workLocation?: string;
}

export interface IncineratorOperationNotice {
  id: string; // e.g. AZAL-INCIN-2026-001
  supervisorName: string;
  supervisorPhone: string;
  wasteWeightKg: number;
  bagsCount?: number;
  wasteTypes: string[]; // e.g. ['sharps', 'infectious_bio', 'pharmaceutical', 'general']
  operationDateTime: string;
  expectedDurationHours?: number;
  safetyCheckConfirmed: boolean;
  safetyChecks: string[];
  notes?: string;
  photoUrl?: string;
  status: 'scheduled' | 'burning_in_progress' | 'completed' | 'cancelled';
  safetyNotes?: string;
  createdAt: string;
  timestamp: number;
  synced?: boolean;
  batchNumber?: string;
  weightKg?: number;
  operatorName?: string;
  wasteType?: string;
  furnaceTempC?: number;
}

export interface NewHireEmployee {
  id: string;
  fullName: string;
  jobTitle: string;
  department: string;
  phone: string;
}

export interface NewHiresTrainingNotice {
  id: string; // e.g. AZAL-HR-2026-001
  hrOfficerName: string;
  hrOfficerPhone: string;
  startDate: string;
  priority: 'urgent' | 'routine';
  hires: NewHireEmployee[];
  notes?: string;
  status: 'new_request' | 'induction_scheduled' | 'completed';
  scheduledTrainingDate?: string;
  safetyNotes?: string;
  createdAt: string;
  timestamp: number;
  synced?: boolean;
}

export interface NominatedStaff {
  id: string;
  fullName: string;
  jobTitle: string;
  phone: string;
}

export interface TrainingNominationNotice {
  id: string; // e.g. AZAL-NOM-2026-001
  requestingDepartment: string;
  supervisorName: string;
  supervisorPhone: string;
  trainingProgram: 'firefighting_rescue' | 'emergency_codes' | 'osh_standards' | 'biosafety' | 'evacuation_hazmat' | 'other';
  trainingProgramTitleAr: string;
  proposedDate: string;
  proposedShift: 'morning' | 'evening' | 'night';
  nominees: NominatedStaff[];
  justification?: string;
  status: 'received' | 'enrolled' | 'scheduled' | 'completed';
  safetyNotes?: string;
  createdAt: string;
  timestamp: number;
  synced?: boolean;
  staffName?: string;
  department?: string;
  courseName?: string;
}

// -------------------------------------------------------------
// CBAHI & FMS Healthcare Accreditation Modules
// -------------------------------------------------------------

export interface MedicalGasCylinderCheckRecord {
  id: string;
  inspectionDate?: string;
  checkDate?: string;
  timestamp?: number;
  createdAt?: number;
  stationOrWard?: string; // المحطة الرئيسية / الطوارئ / العمليات / العناية المركزية
  location?: string;
  cylinderType?: string;
  inspectorName: string;
  // CBAHI 4 Core Requirements:
  chainedSecured?: boolean; // 1. التثبيت بسلاسل جدارية أو حوامل لمنع السقوط
  chainedAndSecured?: boolean;
  cylinderCount?: number;
  valvesAndCapsSafe?: boolean; // 2. سلامة الصمامات وتوفر أغطية الحماية Protective Caps
  oxygenIsolated?: boolean; // 3. عزل الأكسجين عن الزيوت والشحوم والمواد القابلة للاشتعال
  emptyFullSeparated?: boolean; // 4. فصل الأسطوانات الفارغة عن الممتلئة بلافتات واضحة
  isChainedSecurely?: boolean;
  cylindersChainedSecurely?: boolean;
  valveSafetyCapPresent?: boolean;
  protectiveCapsInstalled?: boolean;
  oxygenIsolatedFromCombustibles?: boolean;
  flammableMaterialsIsolated?: boolean;
  fullEmptySegregated?: boolean;
  emptyAndFullSeparated?: boolean;
  pressureStatus?: string;
  totalCylindersChecked?: number;
  cylinderCounts?: {
    oxygenFull: number;
    oxygenEmpty: number;
    nitrousFull: number;
    nitrousEmpty: number;
    co2Full: number;
    co2Empty: number;
  };
  overallStatus?: 'compliant' | 'requires_action' | 'critical_violation';
  status?: 'compliant' | 'requires_action' | 'critical_violation' | 'passed' | 'conditional' | 'failed' | string;
  notes: string;
  photoUrl?: string;
  synced?: boolean;
}

export type SensitiveAreaKey = 'pharmacy' | 'medical_records' | 'hr_records' | 'cssd' | string;

export interface SensitiveAreaAuditItem {
  id: string;
  areaKey?: SensitiveAreaKey;
  areaNameAr?: string;
  area?: string;
  auditDate: string;
  timestamp?: number;
  createdAt?: number;
  inspectorName: string;
  // Specific checks evaluated (compliant / non_compliant / na)
  accessControlOk?: boolean; // التحكم بالدخول والأقفال/البصمة
  accessControlSecured?: boolean;
  environmentalSafetyOk?: boolean; // الرطوبة / الحرارة / التكييف
  fireSuppressionOk?: boolean; // الحماية من الحريق ومنظومة الإطفاء
  fireProtectionReady?: boolean;
  documentationConfidentialityOk?: boolean; // السجلات والسرية والحفظ الآمن
  confidentialityOrNarcoticsLocked?: boolean;
  ppeAndHygieneOk?: boolean; // معدات الحماية أو عزل المواد
  surveillanceCCTVOperational?: boolean;
  emergencyExitClear?: boolean;
  departmentKey?: string;
  authorizedPersonnelOnly?: boolean;
  emergencyKeyAvailable?: boolean;
  cctvSurveillanceActive?: boolean;
  fireProtectionAvailable?: boolean;
  complianceRate?: number; // 0 - 100%
  scorePercentage?: number;
  status: 'compliant' | 'partial' | 'non_compliant' | 'passed' | 'conditional' | 'failed' | string;
  defectsNoted?: string;
  correctiveAction?: string;
  signedProof?: string;
  notes?: string;
  synced?: boolean;
}

export interface GeneratorFacpInspectionRecord {
  id: string;
  inspectionDate: string;
  timestamp?: number;
  createdAt?: number;
  inspectorName: string;
  inspectionType?: string;
  targetEquipment?: string;
  // Backup Generator checks (CBAHI FMS)
  generatorTestType?: 'weekly_no_load' | 'monthly_with_load' | 'emergency_drill' | string; // 10 دقائق أسبوعياً بدون حمل / 30 دقيقة شهرياً بحمل
  runDurationMinutes?: number; // 10 min weekly / 30 min monthly
  testDurationMinutes?: number;
  generatorFuelLevelPct?: number; // مستوى الديزل %
  fuelLevelPercentage?: number;
  generatorBatteryVoltage?: number; // جهد بطارية البدء (e.g. 24V-27V)
  batteryVoltage?: number;
  oilPressureAndWaterTempOk?: boolean; // ضغط الزيت وحرارة التبريد
  oilPressureAndCoolantTempOk?: boolean;
  atsTransferWorking?: boolean; // لوحة التحويل الأوتوماتيكي ATS
  atsAutomaticTransferOk?: boolean;
  generatorStatus?: 'pass' | 'fail' | 'maintenance_due';
  status?: 'pass' | 'fail' | 'maintenance_due' | string;

  // Fire Alarm Control Panel (FACP) checks
  facpCondition?: 'normal' | 'trouble' | 'alarm' | 'supervisory'; // الحالة العامة
  facpStatus?: 'normal' | 'trouble' | 'alarm' | 'supervisory' | string;
  facpAcPowerHealthy?: boolean; // تيار كهربائي رئيسي سليم
  facpStandbyBatteryHealthy?: boolean; // بطاريات الطوارئ الاحتياطية سليمة
  smokeDetectorsSampleTested?: boolean; // عينة كواشف الدخان والحرارة
  facpSmokeDetectorsTested?: boolean;
  bellsAndStrobesTested?: boolean; // الأجراس والسماعات الصوتية والفلاشات
  facpAudioVisualAlertsOk?: boolean;
  notes: string;
  synced?: boolean;
}

// -------------------------------------------------------------
// Admin Dashboard Security Registers
// -------------------------------------------------------------

export interface HospitalPropertyGatePass {
  id: string; // e.g. PASS-2026-001
  passNumber?: string;
  gatePassNumber?: string;
  itemDescription: string; // وصف الجهاز أو العهدة
  serialOrAssetNumber?: string; // كود الأصل أو الرقم التسلسلي
  assetOrSerialTag?: string;
  quantity?: number;
  department: string;
  destination?: string;
  exitPurpose?: string;
  reasonForExit?: 'external_maintenance' | 'loan_to_branch' | 'replacement' | 'disposal' | 'other' | string;
  reasonDetail?: string;
  authorizedBy?: string; // المسؤول المفوّض (المدير / رئيس الصيانة / السلامة)
  approvingManager?: string;
  carrierName?: string; // اسم المندوب أو الموظف المستلم
  recipientName?: string;
  recipientPhone?: string;
  carrierIdNumber?: string; // رقم بطاقة الهوية
  carrierPhone?: string;
  exitDate: string;
  expectedReturnDate?: string;
  actualReturnDate?: string;
  actualReturnedDate?: string;
  status: 'exited' | 'returned' | 'overdue' | string;
  securityGuardOnDuty?: string;
  securityOfficerOnGate?: string;
  notes?: string;
  createdAt?: number;
  synced?: boolean;
}

export interface PatientValuablesDetails {
  patientName: string;
  mrn?: string; // Medical Record Number (رقم الملف الطبي)
  patientMrn?: string;
  department?: string;
  roomBed?: string;
  admissionDate?: string;
  patientAdmissionDate?: string;
  holdingDeadlineDate: string; // Calculated holding deadline: admission/deposit date + 180 days
  is180DayHoldingExceeded?: boolean;
  cashAmountYer?: number;
  cashAmountSar?: number;
  cashAmountUsd?: number;
  cashAmountYemen?: number;
  cashAmountSaudi?: number;
  cashAmountDollar?: number;
  cashDetailsNotes?: string;
  goldOrJewelryDetails?: string;
  electronicsDetails?: string;
  goldJewelryItems?: Array<{
    type: string; // خاتم، سلسال، ساعة، حلق
    description: string;
    piecesCount: number;
    estimatedWeight?: string;
  }>;
  tamperEvidentBagNumber?: string; // رقم كيس الأمانات الأمني المحكم
  securityBagSealNumber?: string;
  safeLockerNumber?: string; // رقم الخزنة
  depositedBy?: string; // المريض / المرافق / التمريض
  depositorPhone?: string;
  depositorIdNumber?: string;
  witnessStaffName?: string;
  legalDispositionNotes?: string;
}

export interface LostAndFoundItem {
  id: string; // e.g. LF-2026-001
  codeNumber?: string;
  itemReference?: string;
  recordType?: 'patient_belongings' | 'general_lost_found';
  patientValuables?: PatientValuablesDetails;
  holdingDeadlineDate?: string;
  is180DayHoldingExceeded?: boolean;
  itemCategory: 'phone_electronics' | 'wallet_money' | 'jewelry' | 'official_documents' | 'clothing_luggage' | 'medical_device' | 'other' | string;
  itemCategoryAr?: string;
  description: string; // وصف تفصيلي (اللون، العلامات المميزة)
  foundLocation: string; // الموقع الدقيق الذي عُثر فيه
  foundDate: string;
  foundTime?: string;
  foundByPerson?: string; // اسم من وجد الغرض
  finderName?: string;
  foundByContact?: string;
  receivedBySecurityGuard?: string; // حارس / ضابط الأمن المستلم
  storageLockerNumber?: string; // رقم الخزنة أو الدولاب
  custodyLocation?: string;
  status: 'safekeeping' | 'claimed_by_owner' | 'disposed_or_donated' | string;
  claimedByOwnerName?: string;
  claimedByOwnerId?: string;
  claimedByOwnerPhone?: string;
  claimedByName?: string;
  claimedByPhone?: string;
  claimedByIdNumber?: string;
  claimedBy?: string;
  claimedDate?: string;
  claimantPhone?: string;
  claimedAtDate?: string;
  handedOverDate?: string;
  securityOfficerHandover?: string;
  notes?: string;
  createdAt?: number;
  synced?: boolean;
}

export type LostAndFoundItemRecord = LostAndFoundItem;

// -------------------------------------------------------------
// Chemical Safety & Digital MSDS Module (FMS-APP-070EA)
// -------------------------------------------------------------

export interface Nfpa704Diamond {
  health: number; // 0 - 4 (Blue)
  flammability: number; // 0 - 4 (Red)
  instability: number; // 0 - 4 (Yellow)
  special?: string; // e.g. 'OX', 'COR', 'W', 'BIO' (White)
  specialAr?: string;
}

export interface ChemicalPpeRequirements {
  eyeFace: string; // حماية العين والوجه
  gloves: string; // قفازات اليدين الموصى بها
  respiratory: string; // الحماية التنفسية والكمامات
  body: string; // المريلة والملابس المقاومة
  footwear?: string; // حذاء أمان واقٍ
}

export interface ChemicalFirstAid {
  eyeContact: string; // ملامسة العين
  skinContact: string; // ملامسة الجلد
  inhalation: string; // الاستنشاق
  ingestion: string; // الابتلاع
}

export interface ChemicalSpillResponse {
  minorSpill: string; // انسكاب بسيط (< 50 مل)
  majorSpill: string; // انسكاب كبير (> 50 مل - كود برتقالي)
  neutralizer: string; // مادة المحايدة أو التثبيت
  wasteDisposal: string; // التخلص من النفايات وأكياس العزل
  spillKitRequired: string; // عدة الانسكاب المطلوبة
}

export interface ChemicalStorageInfo {
  storageConditions: string; // شروط الحفظ ودرجة الحرارة
  incompatibilities: string; // المواد المحظور تخزينها بجوارها
  ventilationRequired: string; // متطلبات التهوية وهود الأبخرة
}

export interface ChemicalMsdsItem {
  id: string;
  nameAr: string;
  nameEn: string;
  commonNameAr?: string;
  casNumber: string;
  chemicalFormula?: string;
  concentration?: string;
  primaryDepartments: string[];
  fmsPolicyCode: string; // e.g. 'FMS-APP-070EA'
  signalWord: 'خطر (Danger)' | 'تحذير (Warning)';
  nfpa704: Nfpa704Diamond;
  hazardClassifications: string[];
  hazardStatements: string[];
  precautionaryStatements: string[];
  requiredPpe: ChemicalPpeRequirements;
  firstAid: ChemicalFirstAid;
  spillResponse: ChemicalSpillResponse;
  storage: ChemicalStorageInfo;
  emergencyContact: string; // '777738138'
  isCustom?: boolean;
  synced?: boolean;
  updatedAt?: string;
}

// -------------------------------------------------------------
// Fire Drill Evaluation & Evacuation Module (FMS-PLAN-008EA & FMS-PLAN-0011EA)
// -------------------------------------------------------------

export interface RaceCriterionAudit {
  status: 'compliant' | 'partial' | 'non_compliant';
  notes: string;
  score: number; // 0 to 25 points
}

export interface RaceAuditGroup {
  rescue: RaceCriterionAudit; // إنقاذ الأرواح في دائرة الخطر المباشر
  alarm: RaceCriterionAudit; // تفعيل الإنذار والنداء الصوتي Code Red والاتصال
  confine: RaceCriterionAudit; // احتواء الحريق وإغلاق الأبواب والنوافذ
  evacuate: RaceCriterionAudit; // الإخلاء التام المنظم أو الإطفاء الموضعي
}

export interface PassAuditGroup {
  pull: boolean; // سحب مسمار الأمان Pull
  aim: boolean; // توجيه الخرطوم لقاعدة اللهب Aim
  squeeze: boolean; // الضغط على المقبض Squeeze
  sweep: boolean; // التحريك يمنة ويسرة Sweep
  usedExtinguisherType: string; // ثنائي أكسيد الكربون CO2 / بودرة كيميائية جافة
  techniqueCompliant: boolean;
  notes: string;
}

export interface FocusPdcaImprovementModel {
  find: string; // رصد وتحديد فرصة التحسين أو الثغرة الميدانية
  organize: string; // الفريق المسؤول عن التحسين والمتابعة
  clarify: string; // توضيح مسار العمل والإجراء المعمول به
  understand: string; // فهم وتحليل الأسباب الجذرية (Root Cause Analysis)
  select: string; // اختيار الحل الوقائي الأنسب
  plan: string; // خطة التدخل وجدولة التدريب
  do: string; // تنفيذ الإجراء التصحيحي وإعادة تأهيل الكادر
  check: string; // قياس الأثر ومعدل الاستجابة في الفرضية القادمة
  act: string; // تعميم المعيار واعتماده ضمن سياسات المستشفى المستمرة
}

export interface FireDrillRecord {
  id: string;
  drillCode: string; // e.g. 'FD-2026-01'
  policyCodes: string[]; // ['FMS-PLAN-008EA', 'FMS-PLAN-0011EA']
  title: string;
  scenario: string;
  date: string; // YYYY-MM-DD
  shift: 'morning' | 'evening' | 'night';
  department: string;
  floor: string;
  evacuationType: 'horizontal' | 'vertical'; // أفقي للطابق / رأسي إلى نقطة التجمع
  assemblyPointLocation: string; // نقطة التجمع الخارجية أو المجاورة
  
  // Timing parameters
  codeRedAnnouncedAt: string; // HH:mm:ss
  fireTeamArrivedAt: string; // HH:mm:ss
  evacuationCompletedAt: string; // HH:mm:ss
  drillEndedAt: string; // HH:mm:ss
  calculatedEvacuationMinutes: number;
  calculatedResponseMinutes: number;

  // Personnel & room audits
  totalParticipantsCount: number;
  simulatedPatientsCount: number;
  emptyRoomTagsVerified: boolean; // تأكيد وضع بطاقات (خالية / Empty) على أبواب الغرف
  emptyRoomTagsNotes?: string;

  // Evaluation groups
  raceAudit: RaceAuditGroup;
  passAudit: PassAuditGroup;
  focusPdca: FocusPdcaImprovementModel;

  // Scoring & Endorsement
  totalScore: number; // 0 - 100
  rating: 'ممتاز (Excellent)' | 'جيد جداً (Very Good)' | 'مقبول (Acceptable)' | 'يحتاج تحسين فوري (Needs Improvement)';
  
  safetyOfficerName: string; // م/ نجيب غازي
  safetyOfficerRole: string; // مسؤول السلامة والصحة المهنية
  safetyOfficerSigned: boolean;
  safetyOfficerSignedAt?: string;

  medicalDirectorName: string; // د/ محمد السراجي
  medicalDirectorRole: string; // مدير عام المستشفى ورئيس لجنة السلامة العليا
  medicalDirectorSigned: boolean;
  medicalDirectorSignedAt?: string;

  status: 'draft' | 'approved' | 'closed';
  createdAt: string;
  updatedAt: string;
}

// -------------------------------------------------------------
// Annual Comprehensive CBAHI Accreditation Executive Report
// -------------------------------------------------------------

export interface AnnualCbahieExecutiveSummary {
  reportYear: number;
  generatedDate: string;
  hospitalName: string;
  code: string; // CBAHI-FMS-ANNUAL-2026

  // Incidents & OVR Stats
  incidentsStats: {
    totalReported: number;
    resolvedCount: number;
    resolutionRate: number;
    criticalIncidents: number;
    averageClosureTimeHours: number;
  };

  // Critical Areas Inspection
  criticalAreasAudit: {
    icuStatus: string;
    cssdStatus: string;
    centralLabStatus: string;
    medicalGasPlantStatus: string;
    incineratorStatus: string;
    overallCompliancePercentage: number;
  };

  // Engineering & Life Safety Systems
  engineeringLifeSafety: {
    backupGeneratorWeeklyRunRate: number; // e.g. 98%
    generatorSimulatedLoadTestPassed: boolean;
    facpPanelInspectionsCount: number;
    facpOperationalRate: number; // e.g. 100%
    extinguishersAuditedCount: number;
    extinguishersValidPercentage: number;
  };

  // Fire Drills Summary
  fireDrillsSummary: {
    totalDrillsExecuted: number;
    averageEvacuationTimeMinutes: number;
    averageScore: number;
    passedRoundsPercentage: number;
    keyImprovementFocus: string;
  };

  // Official Endorsement Signatures
  signatures: {
    qualityCoordinator: {
      name: string; // د/ علي الظبيبي
      title: string; // منسق الجودة والاعتماد
      signed: boolean;
      date: string;
    };
    medicalDirector?: {
      name: string; // د/ أحمد الأهدل
      title: string; // المدير الطبي
      signed: boolean;
      date: string;
    };
    safetyOfficer: {
      name: string; // م/ نجيب غازي
      title: string; // رئيس لجنة السلامة وإدارة المرافق (FMS)
      signed: boolean;
      date: string;
    };
    generalDirector: {
      name: string; // د/ محمد السراجي
      title: string; // مدير عام المستشفى
      signed: boolean;
      date: string;
    };
  };
}

// ---------------------------------------------------------------------------
// Safety Training Schedule & Penalties Log (Supabase Tables)
// ---------------------------------------------------------------------------
export type TrainingStatus = 'مجدول' | 'مكتمل' | 'مؤجل';

export interface SafetyTraining {
  id: string | number;
  course_name: string;
  target_audience: string;
  training_day: string;
  training_date: string;
  training_time: string;
  duration_hours: number;
  trainer_name: string;
  location: string;
  status: TrainingStatus;
  attendees_count: number;
  notes?: string;
  created_at?: string;
}

export interface TrainingCertificateRecord {
  id: string;
  certificate_serial: string; // e.g. AZAL-FMS-CERT-2026-0101
  trainee_name: string; // اسم المتدرب
  department: string; // القسم / الإدارة
  job_title?: string; // المسمى الوظيفي
  course_name: string; // اسم الدورة التدريبية
  training_date: string; // تاريخ انعقاد الدورة
  duration_hours: number; // عدد الساعات التدريبية
  trainer_name: string; // مدرب الدورة / المشرف الميداني
  safety_head_name: string; // م/ نجيب قاسم غازي
  general_manager_name: string; // مدير عام المستشفى (د/ محمد السراجي)
  issue_date: string; // تاريخ تحرير الشهادة
  grade_or_evaluation?: string; // التقدير: ممتاز / اجتياز بتفوق
  qr_code_payload?: string; // بيانات التحقق السريع
  notes?: string;
  created_at?: string;
}

export type PenaltyType = 'تنبيه شفهي' | 'لفت نظر' | 'إنذار كتابي' | 'خصم مالي' | 'إيقاف مؤقت';

export interface PenaltyRecord {
  id: string | number;
  violator_name: string;
  department: string;
  job_title: string;
  reference_notice_id: string;
  violation_type: string;
  penalty_type: PenaltyType;
  penalty_details: string;
  approved_by: string;
  notes?: string;
  penalty_date: string;
  created_at?: string;
}

// ---------------------------------------------------------------------------
// Daily Operational Log (Supabase: daily_safety_actions)
// ---------------------------------------------------------------------------
export interface DailySafetyAction {
  id: string;
  title: string; // عنوان النشاط / العمل المنجز (نص حر)
  category: string; // التصنيف (تولبكس، نفايات، جولة، تدريب، متابعة، إلخ)
  action_date: string; // YYYY-MM-DD
  action_time: string; // HH:mm
  details: string; // تفاصيل العمل والنقاط والبنود الميدانية بحرية تامة
  image_url?: string; // صورة لتوثيق العمل الميداني
  logged_by: string; // اسم المستخدم / القائم بالتوثيق
  is_gas_cylinder_violation?: boolean;
  gas_violation_department?: string;
  gas_violation_severity?: 'low' | 'medium' | 'high' | 'critical';
  gas_violation_notice_id?: string;
  created_at?: string;
}

// ---------------------------------------------------------------------------
// Safety Committee Hub (Supabase: safety_committee_meetings)
// ---------------------------------------------------------------------------
export type CommitteeMeetingStatus = 'scheduled' | 'completed' | 'postponed';

export interface SafetyCommitteeMeeting {
  id: string;
  title: string; // عنوان الاجتماع
  meeting_date: string; // YYYY-MM-DD
  meeting_time: string; // HH:mm
  location: string; // مكان الانعقاد
  agenda: string; // جدول الأعمال
  attendees: string; // الأعضاء الحاضرون / الممثلون
  status: CommitteeMeetingStatus;
  decisions_recommendations?: string; // القرارات والتوصيات
  minutes_image_url?: string; // صورة محضر الاجتماع الرسمي الموقع
  recorded_by: string;
  notes?: string;
  created_at?: string;
}

// ---------------------------------------------------------------------------
// CBAHI Central Compliance Registers (سجلات سباهي المركزية)
// ---------------------------------------------------------------------------

export interface CbahiFireDrill {
  id: string;
  drill_code: string; // e.g. DRILL-FMS18-2026-03
  drill_date: string; // YYYY-MM-DD
  shift: 'morning' | 'evening' | 'night';
  department: string;
  evacuation_time_seconds: number; // زمن الإخلاء بالثواني
  race_applied: boolean; // مؤشر تطبيق RACE (Rescue, Alarm, Confine, Evacuate)
  race_score?: number; // 0 - 100
  race_notes?: string;
  pass_applied: boolean; // مؤشر استخدام الطفايات PASS (Pull, Aim, Squeeze, Sweep)
  pass_score?: number; // 0 - 100
  pass_notes?: string;
  gas_isolated: boolean; // عزل صمامات الغازات الطبية
  electricity_isolated: boolean; // عزل القواطع الكهربائية المعنية
  participants_count: number; // عدد الكوادر المشاركة
  simulated_victims_count: number; // عدد الحالات الوهمية المنقولة
  evaluation_rating: 'excellent' | 'very_good' | 'good' | 'needs_improvement';
  evaluation_score: number; // 0 - 100
  supervisor_name: string; // المشرف على الفرضية (م/ نجيب غازي)
  medical_director_approved: boolean; // اعتماد المدير الطبي
  notes?: string;
  recommendations?: string;
  created_at?: string;
  synced?: boolean;
}

export interface CbahiGeneratorTest {
  id: string;
  test_code: string; // e.g. GEN-FMS31-2026-W37
  test_date: string; // YYYY-MM-DD
  test_time?: string;
  test_type: 'weekly_no_load' | 'monthly_with_load' | 'emergency_drill'; // أسبوعي 10 دقائق بدون حمل / شهري 30 دقيقة بحمل
  duration_minutes: number; // 10 or 30
  auto_start_time_seconds: number; // زمن الإقلاع والتحويل التلقائي ATS بالثواني (سباهي ≤ 10 ثواني)
  generator_name: string; // المولد الرئيسي Cummins 500kVA أو Perkins 350kVA
  voltage_v: number; // الجهد الكهربائي (380V - 400V)
  frequency_hz: number; // التردد (50.0 Hz)
  oil_pressure_bar: number; // ضغط الزيت (bar)
  water_coolant_temp_c: number; // حرارة ماء التبريد (°C)
  fuel_level_percentage: number; // مستوى الديزل %
  battery_voltage_v: number; // جهد البطاريات (24V - 27V)
  ats_auto_transfer_ok: boolean; // لوحة التحويل التلقائي ATS
  circuit_breakers_ok: boolean; // سلامة القواطع والتأريض
  exhaust_leak_free: boolean; // خلو العادم من التسريبات
  test_result: 'pass' | 'fail' | 'needs_maintenance';
  operator_name: string; // الفني المسؤول (م/ عارف الصلوي)
  supervisor_name: string; // م/ نجيب غازي
  notes?: string;
  created_at?: string;
  synced?: boolean;
}

export interface CbahiWaterTest {
  id: string;
  sample_code: string; // e.g. WTR-FMS37-2026-09
  test_date: string; // YYYY-MM-DD
  water_source: 'main_network' | 'ground_tank' | 'roof_tanks' | 'ro_hemodialysis' | 'kitchen_source' | 'endoscopy_unit';
  water_source_ar: string; // اسم مصدر المياه
  test_type: 'bacterial' | 'chemical'; // فحص بكتيري (شهري) / كيميائي (نصف سنوي)
  frequency: 'monthly' | 'semi_annual';
  ph_level: number; // 6.5 - 8.5
  residual_chlorine_ppm: number; // 0.2 - 0.5 ppm
  tds_ppm: number; // الأملاح الذائبة الكلية TDS
  turbidity_ntu: number; // العكارة (NTU)
  total_coliform_cfu: number; // بكتيريا القولون (0 CFU/100ml)
  e_coli_cfu: number; // إشريكية قولونية (0 CFU/100ml)
  legionella_tested: boolean; // فحص بكتيريا الليجيونيلا
  legionella_result?: 'negative' | 'positive';
  laboratory_name: string; // اسم المختبر المعتمد
  sample_collector: string; // جامع العينة
  test_status: 'compliant' | 'non_compliant' | 'pending_lab';
  corrective_action?: string; // الإجراء التصحيحي في حال عدم المطابقة
  notes?: string;
  created_at?: string;
  synced?: boolean;
}

export interface CbahiCapAction {
  id: string;
  deficiency: string;
  corrective_action: string;
  responsible_person: string;
  department: string;
  target_date: string;
  status: 'pending' | 'in_progress' | 'completed';
  verified_by?: string;
}

export interface CbahiSafetyCommitteeItem {
  id: string;
  record_type: 'meeting' | 'quarterly_tour'; // محضر اجتماع أو جولة تفتيش ربع سنوية
  meeting_number?: number; // الاجتماع رقم 1 إلى 10 (سنوياً)
  date: string; // YYYY-MM-DD
  quarter: 'Q1' | 'Q2' | 'Q3' | 'Q4';
  title: string;
  location: string;
  chairperson: string; // د/ محمد السراجي - رئيس اللجنة
  secretary: string; // م/ نجيب غازي - مقرر اللجنة
  quality_coordinator: string; // د/ نبيل عصار - منسق الجودة
  attendees_count: number;
  attendees_list: string[];
  agenda_topics: string[];
  decisions_and_recommendations: string[];
  cap_actions: CbahiCapAction[];
  minutes_file_attached: boolean;
  status: 'draft' | 'approved' | 'completed';
  notes?: string;
  created_at?: string;
  synced?: boolean;
}

export interface CbahiStandardItem {
  code: string; // FMS.1 to FMS.39
  titleAr: string;
  titleEn: string;
  category: string;
  description: string;
  requiredDocuments: string[];
  esr: boolean; // Essential Safety Requirement (متطلب سلامة أساسي)
  complianceRate: number; // 0 - 100%
  status: 'full' | 'partial' | 'non_compliant';
  lastAuditDate: string;
  auditedBy: string;
  evidenceRef: string;
}

// ---------------------------------------------------------------------------
// FMS Operational Plans (Supabase: fms_operational_plans)
// ---------------------------------------------------------------------------
export type PlanFrequency = 'annual' | 'quarterly' | 'monthly' | 'weekly';
export type PlanQuarter = 'Q1' | 'Q2' | 'Q3' | 'Q4';
export type PlanTaskStatus = 'pending' | 'in_progress' | 'completed' | 'delayed';
export type PlanPriority = 'low' | 'medium' | 'high' | 'critical';

export interface FmsPlanTask {
  id: string;
  title: string; // عنوان المهمة التنفيذية
  category: string; // صيانة وقائية، تدريب، جولات تفتيش، بيئة ومرافق، سلامة مهنية، نفايات
  standardRef?: string; // CBAHI FMS.1, JCI, OSHA, NFPA
  assignedTo: string; // الشخص أو القسم المسؤول
  assignedDept?: string; // القسم المعني
  dueDate: string; // YYYY-MM-DD
  status: PlanTaskStatus;
  priority: PlanPriority;
  kpiIndicator?: string; // مؤشر قياس الأداء
  completionPercentage?: number; // 0 - 100%
  notes?: string;
}

export interface FmsOperationalPlan {
  id: string;
  frequency: PlanFrequency; // annual | quarterly | monthly | weekly
  year: number; // e.g. 2026
  quarter?: PlanQuarter; // Q1, Q2, Q3, Q4
  month?: number; // 1 - 12
  monthNameAr?: string; // e.g. سبتمبر 2026
  weekNumber?: number; // 1 - 4
  title: string; // عنوان الخطة التشغيلية
  description: string; // ملخص الخطة والهدف
  strategicObjective?: string; // الهدف الاستراتيجي
  standardCategory: string; // CBAHI FMS, JCI, NFPA, MoH
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  targetKpi: string; // المؤشر المستهدف (مثل: نسبة التغطية ≥ 95%)
  achievedKpi?: string; // المؤشر المحقق
  status: 'draft' | 'approved' | 'active' | 'completed';
  preparedBy: string; // م/ نجيب غازي
  reviewedBy: string; // عارف الصلوي
  approvedBy: string; // الإدارة العامة / الجودة
  tasks: FmsPlanTask[];
  overallProgress: number; // 0 - 100%
  created_at?: string;
  updated_at?: string;
}

// ---------------------------------------------------------------------------
// Hospital Risk Assessment & Matrix (سجل ومصفوفة تقييم المخاطر بالمستشفى)
// ---------------------------------------------------------------------------
export type RiskCategory = 
  | 'facilities' 
  | 'fire_safety' 
  | 'medical_equipment' 
  | 'hazardous_materials' 
  | 'security' 
  | 'clinical_safety';

export type RiskLikelihood = 1 | 2 | 3 | 4 | 5;
export type RiskSeverity = 1 | 2 | 3 | 4 | 5;
export type RiskLevel = 'low' | 'moderate' | 'high' | 'critical';
export type RiskStatus = 'open' | 'in_progress' | 'controlled';

export interface HospitalRiskItem {
  id: string;
  risk_code: string; // e.g. RSK-2026-001
  department: string; // القسم المعني
  category: RiskCategory;
  category_name_ar: string;
  title: string; // عنوان الخطر
  hazard_description: string; // وصف الخطر والتهديد المحتمل
  consequences?: string; // الآثار والتبعات المتوقعة
  initial_likelihood: RiskLikelihood; // 1 - 5
  initial_severity: RiskSeverity; // 1 - 5
  initial_risk_score: number; // 1 - 25 (L * S)
  initial_risk_level: RiskLevel; // low, moderate, high, critical
  current_controls: string; // الضوابط الحالية القائمة
  action_plan: string; // خطة الإجراءات الوقائية والتصحيحية
  responsible_person: string; // الشخص / المنصب المسؤول
  responsible_dept?: string; // القسم المسؤول
  target_date: string; // YYYY-MM-DD
  completion_percentage: number; // 0 - 100%
  residual_likelihood?: RiskLikelihood;
  residual_severity?: RiskSeverity;
  residual_risk_score?: number;
  residual_risk_level?: RiskLevel;
  status: RiskStatus; // open, in_progress, controlled
  last_review_date?: string;
  reviewed_by?: string;
  notes?: string;
  created_at?: string;
  updated_at?: string;
}







